/*      */ package com.itextpdf.testutils;
/*      */ 
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.io.RandomAccessSourceFactory;
/*      */ import com.itextpdf.text.pdf.PRIndirectReference;
/*      */ import com.itextpdf.text.pdf.PRStream;
/*      */ import com.itextpdf.text.pdf.PRTokeniser;
/*      */ import com.itextpdf.text.pdf.PdfAnnotation.PdfImportedLink;
/*      */ import com.itextpdf.text.pdf.PdfArray;
/*      */ import com.itextpdf.text.pdf.PdfBoolean;
/*      */ import com.itextpdf.text.pdf.PdfContentByte;
/*      */ import com.itextpdf.text.pdf.PdfContentParser;
/*      */ import com.itextpdf.text.pdf.PdfDictionary;
/*      */ import com.itextpdf.text.pdf.PdfIndirectReference;
/*      */ import com.itextpdf.text.pdf.PdfLiteral;
/*      */ import com.itextpdf.text.pdf.PdfName;
/*      */ import com.itextpdf.text.pdf.PdfNumber;
/*      */ import com.itextpdf.text.pdf.PdfObject;
/*      */ import com.itextpdf.text.pdf.PdfReader;
/*      */ import com.itextpdf.text.pdf.PdfStamper;
/*      */ import com.itextpdf.text.pdf.PdfString;
/*      */ import com.itextpdf.text.pdf.RandomAccessFileOrArray;
/*      */ import com.itextpdf.text.pdf.RefKey;
/*      */ import com.itextpdf.text.pdf.parser.ContentByteUtils;
/*      */ import com.itextpdf.text.pdf.parser.ImageRenderInfo;
/*      */ import com.itextpdf.text.pdf.parser.InlineImageInfo;
/*      */ import com.itextpdf.text.pdf.parser.InlineImageUtils;
/*      */ import com.itextpdf.text.pdf.parser.PdfContentStreamProcessor;
/*      */ import com.itextpdf.text.pdf.parser.RenderListener;
/*      */ import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
/*      */ import com.itextpdf.text.pdf.parser.TaggedPdfReaderTool;
/*      */ import com.itextpdf.text.pdf.parser.TextExtractionStrategy;
/*      */ import com.itextpdf.text.pdf.parser.TextRenderInfo;
/*      */ import com.itextpdf.text.xml.XMLUtil;
/*      */ import com.itextpdf.xmp.XMPException;
/*      */ import com.itextpdf.xmp.XMPMeta;
/*      */ import com.itextpdf.xmp.XMPMetaFactory;
/*      */ import com.itextpdf.xmp.XMPUtils;
/*      */ import com.itextpdf.xmp.options.SerializeOptions;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeSet;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompareTool
/*      */ {
/*      */   private String gsExec;
/*      */   private String compareExec;
/*      */   
/*      */   private class ObjectPath
/*      */   {
/*      */     protected RefKey baseCmpObject;
/*      */     protected RefKey baseOutObject;
/*  119 */     protected Stack<PathItem> path = new Stack();
/*  120 */     protected Stack<Pair<RefKey>> indirects = new Stack();
/*      */     
/*      */     public ObjectPath() {}
/*      */     
/*      */     protected ObjectPath(RefKey baseCmpObject, RefKey baseOutObject)
/*      */     {
/*  126 */       this.baseCmpObject = baseCmpObject;
/*  127 */       this.baseOutObject = baseOutObject;
/*      */     }
/*      */     
/*      */     private ObjectPath(RefKey baseCmpObject, Stack<PathItem> baseOutObject) {
/*  131 */       this.baseCmpObject = baseCmpObject;
/*  132 */       this.baseOutObject = baseOutObject;
/*  133 */       this.path = path;
/*      */     }
/*      */     
/*      */     private class Pair<T> {
/*      */       private T first;
/*      */       private T second;
/*      */       
/*      */       public Pair(T first) {
/*  141 */         this.first = first;
/*  142 */         this.second = second;
/*      */       }
/*      */       
/*      */       public int hashCode()
/*      */       {
/*  147 */         return this.first.hashCode() * 31 + this.second.hashCode();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  152 */       public boolean equals(Object obj) { return ((obj instanceof Pair)) && (this.first.equals(((Pair)obj).first)) && (this.second.equals(((Pair)obj).second)); }
/*      */     }
/*      */     
/*      */     private abstract class PathItem { private PathItem() {}
/*      */       
/*      */       protected abstract Node toXmlNode(Document paramDocument);
/*      */     }
/*      */     
/*      */     private class DictPathItem extends CompareTool.ObjectPath.PathItem { String key;
/*      */       
/*  162 */       public DictPathItem(String key) { super(null);
/*  163 */         this.key = key;
/*      */       }
/*      */       
/*      */       public String toString()
/*      */       {
/*  168 */         return "Dict key: " + this.key;
/*      */       }
/*      */       
/*      */       public int hashCode()
/*      */       {
/*  173 */         return this.key.hashCode();
/*      */       }
/*      */       
/*      */       public boolean equals(Object obj)
/*      */       {
/*  178 */         return ((obj instanceof DictPathItem)) && (this.key.equals(((DictPathItem)obj).key));
/*      */       }
/*      */       
/*      */       protected Node toXmlNode(Document document)
/*      */       {
/*  183 */         Node element = document.createElement("dictKey");
/*  184 */         element.appendChild(document.createTextNode(this.key));
/*  185 */         return element;
/*      */       }
/*      */     }
/*      */     
/*      */     private class ArrayPathItem extends CompareTool.ObjectPath.PathItem { int index;
/*      */       
/*  191 */       public ArrayPathItem(int index) { super(null);
/*  192 */         this.index = index;
/*      */       }
/*      */       
/*      */       public String toString()
/*      */       {
/*  197 */         return "Array index: " + String.valueOf(this.index);
/*      */       }
/*      */       
/*      */       public int hashCode()
/*      */       {
/*  202 */         return this.index;
/*      */       }
/*      */       
/*      */       public boolean equals(Object obj)
/*      */       {
/*  207 */         return ((obj instanceof ArrayPathItem)) && (this.index == ((ArrayPathItem)obj).index);
/*      */       }
/*      */       
/*      */       protected Node toXmlNode(Document document)
/*      */       {
/*  212 */         Node element = document.createElement("arrayIndex");
/*  213 */         element.appendChild(document.createTextNode(String.valueOf(this.index)));
/*  214 */         return element;
/*      */       }
/*      */     }
/*      */     
/*      */     private class OffsetPathItem extends CompareTool.ObjectPath.PathItem { int offset;
/*      */       
/*  220 */       public OffsetPathItem(int offset) { super(null);
/*  221 */         this.offset = offset;
/*      */       }
/*      */       
/*      */       public String toString()
/*      */       {
/*  226 */         return "Offset: " + String.valueOf(this.offset);
/*      */       }
/*      */       
/*      */       public int hashCode()
/*      */       {
/*  231 */         return this.offset;
/*      */       }
/*      */       
/*      */       public boolean equals(Object obj)
/*      */       {
/*  236 */         return ((obj instanceof OffsetPathItem)) && (this.offset == ((OffsetPathItem)obj).offset);
/*      */       }
/*      */       
/*      */       protected Node toXmlNode(Document document)
/*      */       {
/*  241 */         Node element = document.createElement("offset");
/*  242 */         element.appendChild(document.createTextNode(String.valueOf(this.offset)));
/*  243 */         return element;
/*      */       }
/*      */     }
/*      */     
/*      */     public ObjectPath resetDirectPath(RefKey baseCmpObject, RefKey baseOutObject) {
/*  248 */       ObjectPath newPath = new ObjectPath(CompareTool.this, baseCmpObject, baseOutObject);
/*  249 */       newPath.indirects = ((Stack)this.indirects.clone());
/*  250 */       newPath.indirects.add(new Pair(baseCmpObject, baseOutObject));
/*  251 */       return newPath;
/*      */     }
/*      */     
/*      */     public boolean isComparing(RefKey baseCmpObject, RefKey baseOutObject) {
/*  255 */       return this.indirects.contains(new Pair(baseCmpObject, baseOutObject));
/*      */     }
/*      */     
/*      */     public void pushArrayItemToPath(int index) {
/*  259 */       this.path.add(new ArrayPathItem(index));
/*      */     }
/*      */     
/*      */     public void pushDictItemToPath(String key) {
/*  263 */       this.path.add(new DictPathItem(key));
/*      */     }
/*      */     
/*      */     public void pushOffsetToPath(int offset) {
/*  267 */       this.path.add(new OffsetPathItem(offset));
/*      */     }
/*      */     
/*      */     public void pop() {
/*  271 */       this.path.pop();
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  276 */       StringBuilder sb = new StringBuilder();
/*  277 */       sb.append(String.format("Base cmp object: %s obj. Base out object: %s obj", new Object[] { this.baseCmpObject, this.baseOutObject }));
/*  278 */       for (PathItem pathItem : this.path) {
/*  279 */         sb.append("\n");
/*  280 */         sb.append(pathItem.toString());
/*      */       }
/*  282 */       return sb.toString();
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/*  287 */       int hashCode1 = this.baseCmpObject != null ? this.baseCmpObject.hashCode() : 1;
/*  288 */       int hashCode2 = this.baseOutObject != null ? this.baseOutObject.hashCode() : 1;
/*  289 */       int hashCode = hashCode1 * 31 + hashCode2;
/*  290 */       for (PathItem pathItem : this.path) {
/*  291 */         hashCode *= 31;
/*  292 */         hashCode += pathItem.hashCode();
/*      */       }
/*  294 */       return hashCode;
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/*  300 */       return ((obj instanceof ObjectPath)) && (this.baseCmpObject.equals(((ObjectPath)obj).baseCmpObject)) && (this.baseOutObject.equals(((ObjectPath)obj).baseOutObject)) && (this.path.equals(((ObjectPath)obj).path));
/*      */     }
/*      */     
/*      */     protected Object clone()
/*      */     {
/*  305 */       return new ObjectPath(CompareTool.this, this.baseCmpObject, this.baseOutObject, (Stack)this.path.clone());
/*      */     }
/*      */     
/*      */     public Node toXmlNode(Document document) {
/*  309 */       Element element = document.createElement("path");
/*  310 */       Element baseNode = document.createElement("base");
/*  311 */       baseNode.setAttribute("cmp", this.baseCmpObject.toString() + " obj");
/*  312 */       baseNode.setAttribute("out", this.baseOutObject.toString() + " obj");
/*  313 */       element.appendChild(baseNode);
/*  314 */       for (PathItem pathItem : this.path) {
/*  315 */         element.appendChild(pathItem.toXmlNode(document));
/*      */       }
/*  317 */       return element;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class CompareResult
/*      */   {
/*  323 */     protected Map<CompareTool.ObjectPath, String> differences = new LinkedHashMap();
/*  324 */     protected int messageLimit = 1;
/*      */     
/*      */     public CompareResult(int messageLimit) {
/*  327 */       this.messageLimit = messageLimit;
/*      */     }
/*      */     
/*      */     public boolean isOk() {
/*  331 */       return this.differences.size() == 0;
/*      */     }
/*      */     
/*      */     public int getErrorCount() {
/*  335 */       return this.differences.size();
/*      */     }
/*      */     
/*      */     protected boolean isMessageLimitReached() {
/*  339 */       return this.differences.size() >= this.messageLimit;
/*      */     }
/*      */     
/*      */     public String getReport() {
/*  343 */       StringBuilder sb = new StringBuilder();
/*  344 */       boolean firstEntry = true;
/*  345 */       for (Map.Entry<CompareTool.ObjectPath, String> entry : this.differences.entrySet()) {
/*  346 */         if (!firstEntry)
/*  347 */           sb.append("-----------------------------").append("\n");
/*  348 */         CompareTool.ObjectPath diffPath = (CompareTool.ObjectPath)entry.getKey();
/*  349 */         sb.append((String)entry.getValue()).append("\n").append(diffPath.toString()).append("\n");
/*  350 */         firstEntry = false;
/*      */       }
/*  352 */       return sb.toString();
/*      */     }
/*      */     
/*      */     protected void addError(CompareTool.ObjectPath path, String message) {
/*  356 */       if (this.differences.size() < this.messageLimit) {
/*  357 */         this.differences.put((CompareTool.ObjectPath)path.clone(), message);
/*      */       }
/*      */     }
/*      */     
/*      */     public void writeReportToXml(OutputStream stream) throws ParserConfigurationException, TransformerException {
/*  362 */       Document xmlReport = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
/*  363 */       Element root = xmlReport.createElement("report");
/*  364 */       Element errors = xmlReport.createElement("errors");
/*  365 */       errors.setAttribute("count", String.valueOf(this.differences.size()));
/*  366 */       root.appendChild(errors);
/*  367 */       for (Map.Entry<CompareTool.ObjectPath, String> entry : this.differences.entrySet()) {
/*  368 */         Node errorNode = xmlReport.createElement("error");
/*  369 */         Node message = xmlReport.createElement("message");
/*  370 */         message.appendChild(xmlReport.createTextNode((String)entry.getValue()));
/*  371 */         Node path = ((CompareTool.ObjectPath)entry.getKey()).toXmlNode(xmlReport);
/*  372 */         errorNode.appendChild(message);
/*  373 */         errorNode.appendChild(path);
/*  374 */         errors.appendChild(errorNode);
/*      */       }
/*  376 */       xmlReport.appendChild(root);
/*      */       
/*  378 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/*  379 */       Transformer transformer = tFactory.newTransformer();
/*  380 */       transformer.setOutputProperty("indent", "yes");
/*  381 */       DOMSource source = new DOMSource(xmlReport);
/*  382 */       StreamResult result = new StreamResult(stream);
/*  383 */       transformer.transform(source, result);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  389 */   private final String gsParams = " -dNOPAUSE -dBATCH -sDEVICE=png16m -r150 -sOutputFile=<outputfile> <inputfile>";
/*  390 */   private final String compareParams = " \"<image1>\" \"<image2>\" \"<difference>\"";
/*      */   
/*      */   private static final String cannotOpenTargetDirectory = "Cannot open target directory for <filename>.";
/*      */   
/*      */   private static final String gsFailed = "GhostScript failed for <filename>.";
/*      */   
/*      */   private static final String unexpectedNumberOfPages = "Unexpected number of pages for <filename>.";
/*      */   
/*      */   private static final String differentPages = "File <filename> differs on page <pagenumber>.";
/*      */   
/*      */   private static final String undefinedGsPath = "Path to GhostScript is not specified. Please use -DgsExec=<path_to_ghostscript> (e.g. -DgsExec=\"C:/Program Files/gs/gs9.14/bin/gswin32c.exe\")";
/*      */   private static final String ignoredAreasPrefix = "ignored_areas_";
/*      */   private String cmpPdf;
/*      */   private String cmpPdfName;
/*      */   private String cmpImage;
/*      */   private String outPdf;
/*      */   private String outPdfName;
/*      */   private String outImage;
/*      */   List<PdfDictionary> outPages;
/*      */   List<RefKey> outPagesRef;
/*      */   List<PdfDictionary> cmpPages;
/*      */   List<RefKey> cmpPagesRef;
/*  412 */   private int compareByContentErrorsLimit = 1;
/*  413 */   private boolean generateCompareByContentXmlReport = false;
/*  414 */   private String xmlReportName = "report";
/*  415 */   private double floatComparisonError = 0.0D;
/*      */   
/*  417 */   private boolean absoluteError = true;
/*      */   
/*      */   public CompareTool() {
/*  420 */     this.gsExec = System.getProperty("gsExec");
/*  421 */     this.compareExec = System.getProperty("compareExec");
/*      */   }
/*      */   
/*      */   private String compare(String outPath, String differenceImagePrefix, Map<Integer, List<Rectangle>> ignoredAreas) throws IOException, InterruptedException, DocumentException {
/*  425 */     return compare(outPath, differenceImagePrefix, ignoredAreas, null);
/*      */   }
/*      */   
/*      */   private String compare(String outPath, String differenceImagePrefix, Map<Integer, List<Rectangle>> ignoredAreas, List<Integer> equalPages) throws IOException, InterruptedException, DocumentException
/*      */   {
/*  430 */     if (this.gsExec == null)
/*  431 */       return "Path to GhostScript is not specified. Please use -DgsExec=<path_to_ghostscript> (e.g. -DgsExec=\"C:/Program Files/gs/gs9.14/bin/gswin32c.exe\")";
/*  432 */     if (!new File(this.gsExec).exists()) {
/*  433 */       return new File(this.gsExec).getAbsolutePath() + " does not exist";
/*      */     }
/*  435 */     if (!outPath.endsWith("/"))
/*  436 */       outPath = outPath + "/";
/*  437 */     File targetDir = new File(outPath);
/*      */     
/*      */ 
/*      */ 
/*  441 */     if (!targetDir.exists()) {
/*  442 */       targetDir.mkdirs();
/*      */     } else {
/*  444 */       File[] imageFiles = targetDir.listFiles(new PngFileFilter());
/*  445 */       for (File file : imageFiles) {
/*  446 */         file.delete();
/*      */       }
/*  448 */       File[] cmpImageFiles = targetDir.listFiles(new CmpPngFileFilter());
/*  449 */       for (File file : cmpImageFiles) {
/*  450 */         file.delete();
/*      */       }
/*      */     }
/*      */     
/*  454 */     File diffFile = new File(outPath + differenceImagePrefix);
/*  455 */     if (diffFile.exists()) {
/*  456 */       diffFile.delete();
/*      */     }
/*      */     
/*  459 */     if ((ignoredAreas != null) && (!ignoredAreas.isEmpty())) {
/*  460 */       PdfReader cmpReader = new PdfReader(this.cmpPdf);
/*  461 */       PdfReader outReader = new PdfReader(this.outPdf);
/*  462 */       PdfStamper outStamper = new PdfStamper(outReader, new FileOutputStream(outPath + "ignored_areas_" + this.outPdfName));
/*  463 */       PdfStamper cmpStamper = new PdfStamper(cmpReader, new FileOutputStream(outPath + "ignored_areas_" + this.cmpPdfName));
/*      */       
/*  465 */       for (Map.Entry<Integer, List<Rectangle>> entry : ignoredAreas.entrySet()) {
/*  466 */         int pageNumber = ((Integer)entry.getKey()).intValue();
/*  467 */         List<Rectangle> rectangles = (List)entry.getValue();
/*      */         
/*  469 */         if ((rectangles != null) && (!rectangles.isEmpty())) {
/*  470 */           outCB = outStamper.getOverContent(pageNumber);
/*  471 */           cmpCB = cmpStamper.getOverContent(pageNumber);
/*      */           
/*  473 */           for (Rectangle rect : rectangles) {
/*  474 */             rect.setBackgroundColor(BaseColor.BLACK);
/*  475 */             outCB.rectangle(rect);
/*  476 */             cmpCB.rectangle(rect);
/*      */           }
/*      */         } }
/*      */       PdfContentByte outCB;
/*      */       PdfContentByte cmpCB;
/*  481 */       outStamper.close();
/*  482 */       cmpStamper.close();
/*      */       
/*  484 */       outReader.close();
/*  485 */       cmpReader.close();
/*      */       
/*  487 */       init(outPath + "ignored_areas_" + this.outPdfName, outPath + "ignored_areas_" + this.cmpPdfName); }
/*      */     File[] cmpImageFiles;
/*      */     File[] imageFiles;
/*  490 */     if (targetDir.exists()) {
/*  491 */       getClass();String gsParams = " -dNOPAUSE -dBATCH -sDEVICE=png16m -r150 -sOutputFile=<outputfile> <inputfile>".replace("<outputfile>", outPath + this.cmpImage).replace("<inputfile>", this.cmpPdf);
/*  492 */       Process p = runProcess(this.gsExec, gsParams);
/*  493 */       BufferedReader bri = new BufferedReader(new InputStreamReader(p.getInputStream()));
/*  494 */       BufferedReader bre = new BufferedReader(new InputStreamReader(p.getErrorStream()));
/*      */       String line;
/*  496 */       while ((line = bri.readLine()) != null) {
/*  497 */         System.out.println(line);
/*      */       }
/*  499 */       bri.close();
/*  500 */       while ((line = bre.readLine()) != null) {
/*  501 */         System.out.println(line);
/*      */       }
/*  503 */       bre.close();
/*  504 */       File[] cmpImageFiles; File[] imageFiles; if (p.waitFor() == 0) {
/*  505 */         getClass();gsParams = " -dNOPAUSE -dBATCH -sDEVICE=png16m -r150 -sOutputFile=<outputfile> <inputfile>".replace("<outputfile>", outPath + this.outImage).replace("<inputfile>", this.outPdf);
/*  506 */         p = runProcess(this.gsExec, gsParams);
/*  507 */         bri = new BufferedReader(new InputStreamReader(p.getInputStream()));
/*  508 */         bre = new BufferedReader(new InputStreamReader(p.getErrorStream()));
/*  509 */         while ((line = bri.readLine()) != null) {
/*  510 */           System.out.println(line);
/*      */         }
/*  512 */         bri.close();
/*  513 */         while ((line = bre.readLine()) != null) {
/*  514 */           System.out.println(line);
/*      */         }
/*  516 */         bre.close();
/*  517 */         int exitValue = p.waitFor();
/*      */         
/*  519 */         if (exitValue == 0) {
/*  520 */           File[] imageFiles = targetDir.listFiles(new PngFileFilter());
/*  521 */           File[] cmpImageFiles = targetDir.listFiles(new CmpPngFileFilter());
/*  522 */           boolean bUnexpectedNumberOfPages = false;
/*  523 */           if (imageFiles.length != cmpImageFiles.length) {
/*  524 */             bUnexpectedNumberOfPages = true;
/*      */           }
/*  526 */           int cnt = Math.min(imageFiles.length, cmpImageFiles.length);
/*  527 */           if (cnt < 1) {
/*  528 */             return "No files for comparing!!!\nThe result or sample pdf file is not processed by GhostScript.";
/*      */           }
/*  530 */           Arrays.sort(imageFiles, new ImageNameComparator());
/*  531 */           Arrays.sort(cmpImageFiles, new ImageNameComparator());
/*  532 */           String differentPagesFail = null;
/*  533 */           for (int i = 0; i < cnt; i++)
/*  534 */             if ((equalPages == null) || (!equalPages.contains(Integer.valueOf(i))))
/*      */             {
/*  536 */               System.out.print("Comparing page " + Integer.toString(i + 1) + " (" + imageFiles[i].getAbsolutePath() + ")...");
/*  537 */               FileInputStream is1 = new FileInputStream(imageFiles[i]);
/*  538 */               FileInputStream is2 = new FileInputStream(cmpImageFiles[i]);
/*  539 */               boolean cmpResult = compareStreams(is1, is2);
/*  540 */               is1.close();
/*  541 */               is2.close();
/*  542 */               if (!cmpResult) {
/*  543 */                 if ((this.compareExec != null) && (new File(this.compareExec).exists())) {
/*  544 */                   getClass();String compareParams = " \"<image1>\" \"<image2>\" \"<difference>\"".replace("<image1>", imageFiles[i].getAbsolutePath()).replace("<image2>", cmpImageFiles[i].getAbsolutePath()).replace("<difference>", outPath + differenceImagePrefix + Integer.toString(i + 1) + ".png");
/*  545 */                   p = runProcess(this.compareExec, compareParams);
/*  546 */                   bre = new BufferedReader(new InputStreamReader(p.getErrorStream()));
/*  547 */                   while ((line = bre.readLine()) != null) {
/*  548 */                     System.out.println(line);
/*      */                   }
/*  550 */                   bre.close();
/*  551 */                   int cmpExitValue = p.waitFor();
/*  552 */                   if (cmpExitValue == 0) {
/*  553 */                     if (differentPagesFail == null) {
/*  554 */                       differentPagesFail = "File <filename> differs on page <pagenumber>.".replace("<filename>", this.outPdf).replace("<pagenumber>", Integer.toString(i + 1));
/*  555 */                       differentPagesFail = differentPagesFail + "\nPlease, examine " + outPath + differenceImagePrefix + Integer.toString(i + 1) + ".png for more details.";
/*      */                     } else {
/*  557 */                       differentPagesFail = "File " + this.outPdf + " differs.\nPlease, examine difference images for more details.";
/*      */                     }
/*      */                   }
/*      */                   else {
/*  561 */                     differentPagesFail = "File <filename> differs on page <pagenumber>.".replace("<filename>", this.outPdf).replace("<pagenumber>", Integer.toString(i + 1));
/*      */                   }
/*      */                 } else {
/*  564 */                   differentPagesFail = "File <filename> differs on page <pagenumber>.".replace("<filename>", this.outPdf).replace("<pagenumber>", Integer.toString(i + 1));
/*  565 */                   differentPagesFail = differentPagesFail + "\nYou can optionally specify path to ImageMagick compare tool (e.g. -DcompareExec=\"C:/Program Files/ImageMagick-6.5.4-2/compare.exe\") to visualize differences.";
/*  566 */                   break;
/*      */                 }
/*  568 */                 System.out.println(differentPagesFail);
/*      */               } else {
/*  570 */                 System.out.println("done.");
/*      */               }
/*      */             }
/*  573 */           if (differentPagesFail != null) {
/*  574 */             return differentPagesFail;
/*      */           }
/*  576 */           if (bUnexpectedNumberOfPages) {
/*  577 */             return "Unexpected number of pages for <filename>.".replace("<filename>", this.outPdf);
/*      */           }
/*      */         } else {
/*  580 */           return "GhostScript failed for <filename>.".replace("<filename>", this.outPdf);
/*      */         }
/*      */       } else {
/*  583 */         return "GhostScript failed for <filename>.".replace("<filename>", this.cmpPdf);
/*      */       }
/*      */     } else {
/*  586 */       return "Cannot open target directory for <filename>.".replace("<filename>", this.outPdf); }
/*      */     File[] cmpImageFiles;
/*      */     File[] imageFiles;
/*  589 */     return null;
/*      */   }
/*      */   
/*      */   private Process runProcess(String execPath, String params) throws IOException, InterruptedException {
/*  593 */     StringTokenizer st = new StringTokenizer(params);
/*  594 */     String[] cmdArray = new String[st.countTokens() + 1];
/*  595 */     cmdArray[0] = execPath;
/*  596 */     for (int i = 1; st.hasMoreTokens(); i++) {
/*  597 */       cmdArray[i] = st.nextToken();
/*      */     }
/*  599 */     Process p = Runtime.getRuntime().exec(cmdArray);
/*      */     
/*  601 */     return p;
/*      */   }
/*      */   
/*      */   public String compare(String outPdf, String cmpPdf, String outPath, String differenceImagePrefix, Map<Integer, List<Rectangle>> ignoredAreas) throws IOException, InterruptedException, DocumentException {
/*  605 */     init(outPdf, cmpPdf);
/*  606 */     return compare(outPath, differenceImagePrefix, ignoredAreas);
/*      */   }
/*      */   
/*      */   public String compare(String outPdf, String cmpPdf, String outPath, String differenceImagePrefix) throws IOException, InterruptedException, DocumentException {
/*  610 */     return compare(outPdf, cmpPdf, outPath, differenceImagePrefix, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CompareTool setCompareByContentErrorsLimit(int compareByContentMaxErrorCount)
/*      */   {
/*  619 */     this.compareByContentErrorsLimit = compareByContentMaxErrorCount;
/*  620 */     return this;
/*      */   }
/*      */   
/*      */   public void setGenerateCompareByContentXmlReport(boolean generateCompareByContentXmlReport) {
/*  624 */     this.generateCompareByContentXmlReport = generateCompareByContentXmlReport;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CompareTool setFloatAbsoluteError(float error)
/*      */   {
/*  633 */     this.floatComparisonError = error;
/*  634 */     this.absoluteError = true;
/*  635 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CompareTool setFloatRelativeError(float error)
/*      */   {
/*  644 */     this.floatComparisonError = error;
/*  645 */     this.absoluteError = false;
/*  646 */     return this;
/*      */   }
/*      */   
/*      */   public String getXmlReportName() {
/*  650 */     return this.xmlReportName;
/*      */   }
/*      */   
/*      */   public void setXmlReportName(String xmlReportName) {
/*  654 */     this.xmlReportName = xmlReportName;
/*      */   }
/*      */   
/*      */   protected String compareByContent(String outPath, String differenceImagePrefix, Map<Integer, List<Rectangle>> ignoredAreas) throws DocumentException, InterruptedException, IOException {
/*  658 */     System.out.print("[itext] INFO  Comparing by content..........");
/*  659 */     PdfReader outReader = new PdfReader(this.outPdf);
/*  660 */     this.outPages = new ArrayList();
/*  661 */     this.outPagesRef = new ArrayList();
/*  662 */     loadPagesFromReader(outReader, this.outPages, this.outPagesRef);
/*      */     
/*  664 */     PdfReader cmpReader = new PdfReader(this.cmpPdf);
/*  665 */     this.cmpPages = new ArrayList();
/*  666 */     this.cmpPagesRef = new ArrayList();
/*  667 */     loadPagesFromReader(cmpReader, this.cmpPages, this.cmpPagesRef);
/*      */     
/*  669 */     if (this.outPages.size() != this.cmpPages.size()) {
/*  670 */       return compare(outPath, differenceImagePrefix, ignoredAreas);
/*      */     }
/*  672 */     CompareResult compareResult = new CompareResult(this.compareByContentErrorsLimit);
/*  673 */     List<Integer> equalPages = new ArrayList(this.cmpPages.size());
/*  674 */     for (int i = 0; i < this.cmpPages.size(); i++) {
/*  675 */       ObjectPath currentPath = new ObjectPath((RefKey)this.cmpPagesRef.get(i), (RefKey)this.outPagesRef.get(i));
/*  676 */       if (compareDictionariesExtended((PdfDictionary)this.outPages.get(i), (PdfDictionary)this.cmpPages.get(i), currentPath, compareResult)) {
/*  677 */         equalPages.add(Integer.valueOf(i));
/*      */       }
/*      */     }
/*  680 */     PdfObject outStructTree = outReader.getCatalog().get(PdfName.STRUCTTREEROOT);
/*  681 */     PdfObject cmpStructTree = cmpReader.getCatalog().get(PdfName.STRUCTTREEROOT);
/*  682 */     RefKey outStructTreeRef = outStructTree == null ? null : new RefKey((PdfIndirectReference)outStructTree);
/*  683 */     RefKey cmpStructTreeRef = cmpStructTree == null ? null : new RefKey((PdfIndirectReference)cmpStructTree);
/*  684 */     compareObjects(outStructTree, cmpStructTree, new ObjectPath(outStructTreeRef, cmpStructTreeRef), compareResult);
/*      */     
/*  686 */     PdfObject outOcProperties = outReader.getCatalog().get(PdfName.OCPROPERTIES);
/*  687 */     PdfObject cmpOcProperties = cmpReader.getCatalog().get(PdfName.OCPROPERTIES);
/*  688 */     RefKey outOcPropertiesRef = (outOcProperties instanceof PdfIndirectReference) ? new RefKey((PdfIndirectReference)outOcProperties) : null;
/*  689 */     RefKey cmpOcPropertiesRef = (cmpOcProperties instanceof PdfIndirectReference) ? new RefKey((PdfIndirectReference)cmpOcProperties) : null;
/*  690 */     compareObjects(outOcProperties, cmpOcProperties, new ObjectPath(outOcPropertiesRef, cmpOcPropertiesRef), compareResult);
/*      */     
/*  692 */     outReader.close();
/*  693 */     cmpReader.close();
/*      */     
/*  695 */     if (this.generateCompareByContentXmlReport) {
/*      */       try {
/*  697 */         compareResult.writeReportToXml(new FileOutputStream(outPath + "/" + this.xmlReportName + ".xml"));
/*      */       }
/*      */       catch (Exception localException) {}
/*      */     }
/*  701 */     if ((equalPages.size() == this.cmpPages.size()) && (compareResult.isOk())) {
/*  702 */       System.out.println("OK");
/*  703 */       System.out.flush();
/*  704 */       return null;
/*      */     }
/*  706 */     System.out.println("Fail");
/*  707 */     System.out.flush();
/*  708 */     String compareByContentReport = "Compare by content report:\n" + compareResult.getReport();
/*  709 */     System.out.println(compareByContentReport);
/*  710 */     System.out.flush();
/*  711 */     String message = compare(outPath, differenceImagePrefix, ignoredAreas, equalPages);
/*  712 */     if ((message == null) || (message.length() == 0))
/*  713 */       return "Compare by content fails. No visual differences";
/*  714 */     return message;
/*      */   }
/*      */   
/*      */   public String compareByContent(String outPdf, String cmpPdf, String outPath, String differenceImagePrefix, Map<Integer, List<Rectangle>> ignoredAreas) throws DocumentException, InterruptedException, IOException
/*      */   {
/*  719 */     init(outPdf, cmpPdf);
/*  720 */     return compareByContent(outPath, differenceImagePrefix, ignoredAreas);
/*      */   }
/*      */   
/*      */   public String compareByContent(String outPdf, String cmpPdf, String outPath, String differenceImagePrefix) throws DocumentException, InterruptedException, IOException {
/*  724 */     return compareByContent(outPdf, cmpPdf, outPath, differenceImagePrefix, null);
/*      */   }
/*      */   
/*      */   private void loadPagesFromReader(PdfReader reader, List<PdfDictionary> pages, List<RefKey> pagesRef) {
/*  728 */     PdfObject pagesDict = reader.getCatalog().get(PdfName.PAGES);
/*  729 */     addPagesFromDict(pagesDict, pages, pagesRef);
/*      */   }
/*      */   
/*      */   private void addPagesFromDict(PdfObject dictRef, List<PdfDictionary> pages, List<RefKey> pagesRef) {
/*  733 */     PdfDictionary dict = (PdfDictionary)PdfReader.getPdfObject(dictRef);
/*  734 */     if (dict.isPages()) {
/*  735 */       PdfArray kids = dict.getAsArray(PdfName.KIDS);
/*  736 */       if (kids == null) return;
/*  737 */       for (PdfObject kid : kids) {
/*  738 */         addPagesFromDict(kid, pages, pagesRef);
/*      */       }
/*  740 */     } else if (dict.isPage()) {
/*  741 */       pages.add(dict);
/*  742 */       pagesRef.add(new RefKey((PRIndirectReference)dictRef));
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean compareObjects(PdfObject outObj, PdfObject cmpObj, ObjectPath currentPath, CompareResult compareResult) throws IOException {
/*  747 */     PdfObject outDirectObj = PdfReader.getPdfObject(outObj);
/*  748 */     PdfObject cmpDirectObj = PdfReader.getPdfObject(cmpObj);
/*      */     
/*  750 */     if ((cmpDirectObj == null) && (outDirectObj == null)) {
/*  751 */       return true;
/*      */     }
/*  753 */     if (outDirectObj == null) {
/*  754 */       compareResult.addError(currentPath, "Expected object was not found.");
/*  755 */       return false; }
/*  756 */     if (cmpDirectObj == null) {
/*  757 */       compareResult.addError(currentPath, "Found object which was not expected to be found.");
/*  758 */       return false; }
/*  759 */     if (cmpDirectObj.type() != outDirectObj.type()) {
/*  760 */       compareResult.addError(currentPath, String.format("Types do not match. Expected: %s. Found: %s.", new Object[] { cmpDirectObj.getClass().getSimpleName(), outDirectObj.getClass().getSimpleName() }));
/*  761 */       return false;
/*      */     }
/*      */     
/*  764 */     if ((cmpObj.isIndirect()) && (outObj.isIndirect())) {
/*  765 */       if (currentPath.isComparing(new RefKey((PdfIndirectReference)cmpObj), new RefKey((PdfIndirectReference)outObj)))
/*  766 */         return true;
/*  767 */       currentPath = currentPath.resetDirectPath(new RefKey((PdfIndirectReference)cmpObj), new RefKey((PdfIndirectReference)outObj));
/*      */     }
/*      */     
/*  770 */     if ((cmpDirectObj.isDictionary()) && (((PdfDictionary)cmpDirectObj).isPage())) {
/*  771 */       if ((!outDirectObj.isDictionary()) || (!((PdfDictionary)outDirectObj).isPage())) {
/*  772 */         if ((compareResult != null) && (currentPath != null))
/*  773 */           compareResult.addError(currentPath, "Expected a page. Found not a page.");
/*  774 */         return false;
/*      */       }
/*  776 */       RefKey cmpRefKey = new RefKey((PRIndirectReference)cmpObj);
/*  777 */       RefKey outRefKey = new RefKey((PRIndirectReference)outObj);
/*      */       
/*  779 */       if ((this.cmpPagesRef.contains(cmpRefKey)) && (this.cmpPagesRef.indexOf(cmpRefKey) == this.outPagesRef.indexOf(outRefKey)))
/*  780 */         return true;
/*  781 */       if ((compareResult != null) && (currentPath != null))
/*  782 */         compareResult.addError(currentPath, String.format("The dictionaries refer to different pages. Expected page number: %s. Found: %s", new Object[] {
/*  783 */           Integer.valueOf(this.cmpPagesRef.indexOf(cmpRefKey)), Integer.valueOf(this.outPagesRef.indexOf(outRefKey)) }));
/*  784 */       return false;
/*      */     }
/*      */     
/*  787 */     if (cmpDirectObj.isDictionary()) {
/*  788 */       if (!compareDictionariesExtended((PdfDictionary)outDirectObj, (PdfDictionary)cmpDirectObj, currentPath, compareResult))
/*  789 */         return false;
/*  790 */     } else if (cmpDirectObj.isStream()) {
/*  791 */       if (!compareStreamsExtended((PRStream)outDirectObj, (PRStream)cmpDirectObj, currentPath, compareResult))
/*  792 */         return false;
/*  793 */     } else if (cmpDirectObj.isArray()) {
/*  794 */       if (!compareArraysExtended((PdfArray)outDirectObj, (PdfArray)cmpDirectObj, currentPath, compareResult))
/*  795 */         return false;
/*  796 */     } else if (cmpDirectObj.isName()) {
/*  797 */       if (!compareNamesExtended((PdfName)outDirectObj, (PdfName)cmpDirectObj, currentPath, compareResult))
/*  798 */         return false;
/*  799 */     } else if (cmpDirectObj.isNumber()) {
/*  800 */       if (!compareNumbersExtended((PdfNumber)outDirectObj, (PdfNumber)cmpDirectObj, currentPath, compareResult))
/*  801 */         return false;
/*  802 */     } else if (cmpDirectObj.isString()) {
/*  803 */       if (!compareStringsExtended((PdfString)outDirectObj, (PdfString)cmpDirectObj, currentPath, compareResult))
/*  804 */         return false;
/*  805 */     } else if (cmpDirectObj.isBoolean()) {
/*  806 */       if (!compareBooleansExtended((PdfBoolean)outDirectObj, (PdfBoolean)cmpDirectObj, currentPath, compareResult))
/*  807 */         return false;
/*  808 */     } else if ((cmpDirectObj instanceof PdfLiteral)) {
/*  809 */       if (!compareLiteralsExtended((PdfLiteral)outDirectObj, (PdfLiteral)cmpDirectObj, currentPath, compareResult))
/*  810 */         return false;
/*  811 */     } else if ((!outDirectObj.isNull()) || (!cmpDirectObj.isNull()))
/*      */     {
/*  813 */       throw new UnsupportedOperationException();
/*      */     }
/*  815 */     return true;
/*      */   }
/*      */   
/*      */   public boolean compareDictionaries(PdfDictionary outDict, PdfDictionary cmpDict) throws IOException {
/*  819 */     return compareDictionariesExtended(outDict, cmpDict, null, null);
/*      */   }
/*      */   
/*      */   private boolean compareDictionariesExtended(PdfDictionary outDict, PdfDictionary cmpDict, ObjectPath currentPath, CompareResult compareResult) throws IOException {
/*  823 */     if (((cmpDict != null) && (outDict == null)) || ((outDict != null) && (cmpDict == null))) {
/*  824 */       compareResult.addError(currentPath, "One of the dictionaries is null, the other is not.");
/*  825 */       return false;
/*      */     }
/*  827 */     boolean dictsAreSame = true;
/*      */     
/*  829 */     Set<PdfName> mergedKeys = new TreeSet(cmpDict.getKeys());
/*  830 */     mergedKeys.addAll(outDict.getKeys());
/*      */     
/*  832 */     for (PdfName key : mergedKeys)
/*  833 */       if ((key.compareTo(PdfName.PARENT) != 0) && (key.compareTo(PdfName.P) != 0) && (
/*  834 */         (!outDict.isStream()) || (!cmpDict.isStream()) || ((!key.equals(PdfName.FILTER)) && (!key.equals(PdfName.LENGTH))))) {
/*  835 */         if ((key.compareTo(PdfName.BASEFONT) == 0) || (key.compareTo(PdfName.FONTNAME) == 0)) {
/*  836 */           PdfObject cmpObj = cmpDict.getDirectObject(key);
/*  837 */           if ((cmpObj.isName()) && (cmpObj.toString().indexOf('+') > 0)) {
/*  838 */             PdfObject outObj = outDict.getDirectObject(key);
/*  839 */             if ((!outObj.isName()) || (outObj.toString().indexOf('+') == -1)) {
/*  840 */               if ((compareResult != null) && (currentPath != null))
/*  841 */                 compareResult.addError(currentPath, String.format("PdfDictionary %s entry: Expected: %s. Found: %s", new Object[] { key.toString(), cmpObj.toString(), outObj.toString() }));
/*  842 */               dictsAreSame = false;
/*      */             }
/*  844 */             String cmpName = cmpObj.toString().substring(cmpObj.toString().indexOf('+'));
/*  845 */             String outName = outObj.toString().substring(outObj.toString().indexOf('+'));
/*  846 */             if (cmpName.equals(outName)) continue;
/*  847 */             if ((compareResult != null) && (currentPath != null))
/*  848 */               compareResult.addError(currentPath, String.format("PdfDictionary %s entry: Expected: %s. Found: %s", new Object[] { key.toString(), cmpObj.toString(), outObj.toString() }));
/*  849 */             dictsAreSame = false; continue;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  855 */         if ((this.floatComparisonError != 0.0D) && (cmpDict.isPage()) && (outDict.isPage()) && (key.equals(PdfName.CONTENTS))) {
/*  856 */           if (!compareContentStreamsByParsingExtended(outDict.getDirectObject(key), cmpDict.getDirectObject(key), 
/*  857 */             (PdfDictionary)outDict.getDirectObject(PdfName.RESOURCES), (PdfDictionary)cmpDict.getDirectObject(PdfName.RESOURCES), currentPath, compareResult))
/*      */           {
/*  859 */             dictsAreSame = false;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  864 */           if (currentPath != null)
/*  865 */             currentPath.pushDictItemToPath(key.toString());
/*  866 */           dictsAreSame = (compareObjects(outDict.get(key), cmpDict.get(key), currentPath, compareResult)) && (dictsAreSame);
/*  867 */           if (currentPath != null)
/*  868 */             currentPath.pop();
/*  869 */           if ((!dictsAreSame) && ((currentPath == null) || (compareResult == null) || (compareResult.isMessageLimitReached())))
/*  870 */             return false;
/*      */         } }
/*  872 */     return dictsAreSame;
/*      */   }
/*      */   
/*      */   public boolean compareContentStreamsByParsing(PdfObject outObj, PdfObject cmpObj) throws IOException {
/*  876 */     return compareContentStreamsByParsingExtended(outObj, cmpObj, null, null, null, null);
/*      */   }
/*      */   
/*      */   public boolean compareContentStreamsByParsing(PdfObject outObj, PdfObject cmpObj, PdfDictionary outResources, PdfDictionary cmpResources) throws IOException {
/*  880 */     return compareContentStreamsByParsingExtended(outObj, cmpObj, outResources, cmpResources, null, null);
/*      */   }
/*      */   
/*      */   private boolean compareContentStreamsByParsingExtended(PdfObject outObj, PdfObject cmpObj, PdfDictionary outResources, PdfDictionary cmpResources, ObjectPath currentPath, CompareResult compareResult) throws IOException {
/*  884 */     if (outObj.type() != outObj.type()) {
/*  885 */       compareResult.addError(currentPath, String.format("PdfObject. Types are different. Expected: %s. Found: %s", new Object[] {
/*  886 */         Integer.valueOf(cmpObj.type()), Integer.valueOf(outObj.type()) }));
/*  887 */       return false;
/*      */     }
/*      */     
/*  890 */     if (outObj.isArray()) {
/*  891 */       PdfArray outArr = (PdfArray)outObj;
/*  892 */       PdfArray cmpArr = (PdfArray)cmpObj;
/*  893 */       if (cmpArr.size() != outArr.size()) {
/*  894 */         compareResult.addError(currentPath, String.format("PdfArray. Sizes are different. Expected: %s. Found: %s", new Object[] {
/*  895 */           Integer.valueOf(cmpArr.size()), Integer.valueOf(outArr.size()) }));
/*  896 */         return false;
/*      */       }
/*  898 */       for (int i = 0; i < cmpArr.size(); i++) {
/*  899 */         if (!compareContentStreamsByParsingExtended(outArr.getPdfObject(i), cmpArr.getPdfObject(i), outResources, cmpResources, currentPath, compareResult)) {
/*  900 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  906 */     PRTokeniser cmpTokeniser = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(ContentByteUtils.getContentBytesFromContentObject(cmpObj))));
/*      */     
/*  908 */     PRTokeniser outTokeniser = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(ContentByteUtils.getContentBytesFromContentObject(outObj))));
/*      */     
/*  910 */     PdfContentParser cmpPs = new PdfContentParser(cmpTokeniser);
/*  911 */     PdfContentParser outPs = new PdfContentParser(outTokeniser);
/*      */     
/*  913 */     ArrayList<PdfObject> cmpOperands = new ArrayList();
/*  914 */     ArrayList<PdfObject> outOperands = new ArrayList();
/*      */     
/*  916 */     while (cmpPs.parse(cmpOperands).size() > 0) {
/*  917 */       outPs.parse(outOperands);
/*  918 */       if (cmpOperands.size() != outOperands.size()) {
/*  919 */         compareResult.addError(currentPath, String.format("PdfObject. Different commands lengths. Expected: %s. Found: %s", new Object[] {
/*  920 */           Integer.valueOf(cmpOperands.size()), Integer.valueOf(outOperands.size()) }));
/*  921 */         return false;
/*      */       }
/*  923 */       if ((cmpOperands.size() == 1) && (compareLiterals((PdfLiteral)cmpOperands.get(0), new PdfLiteral("BI"))) && (compareLiterals((PdfLiteral)outOperands.get(0), new PdfLiteral("BI")))) {
/*  924 */         PRStream cmpStr = (PRStream)cmpObj;
/*  925 */         PRStream outStr = (PRStream)outObj;
/*  926 */         if ((null != outStr.getDirectObject(PdfName.RESOURCES)) && (null != cmpStr.getDirectObject(PdfName.RESOURCES))) {
/*  927 */           outResources = (PdfDictionary)outStr.getDirectObject(PdfName.RESOURCES);
/*  928 */           cmpResources = (PdfDictionary)cmpStr.getDirectObject(PdfName.RESOURCES);
/*      */         }
/*  930 */         if (!compareInlineImagesExtended(outPs, cmpPs, outResources, cmpResources, currentPath, compareResult)) {
/*  931 */           return false;
/*      */         }
/*      */       }
/*      */       else {
/*  935 */         for (int i = 0; i < cmpOperands.size(); i++) {
/*  936 */           if (!compareObjects((PdfObject)outOperands.get(i), (PdfObject)cmpOperands.get(i), currentPath, compareResult))
/*  937 */             return false;
/*      */         }
/*      */       }
/*      */     }
/*  941 */     return true;
/*      */   }
/*      */   
/*      */   private boolean compareInlineImagesExtended(PdfContentParser outPs, PdfContentParser cmpPs, PdfDictionary outDict, PdfDictionary cmpDict, ObjectPath currentPath, CompareResult compareResult) throws IOException {
/*  945 */     InlineImageInfo cmpInfo = InlineImageUtils.parseInlineImage(cmpPs, cmpDict);
/*  946 */     InlineImageInfo outInfo = InlineImageUtils.parseInlineImage(outPs, outDict);
/*      */     
/*  948 */     return (compareObjects(outInfo.getImageDictionary(), cmpInfo.getImageDictionary(), currentPath, compareResult)) && (Arrays.equals(outInfo.getSamples(), cmpInfo.getSamples()));
/*      */   }
/*      */   
/*      */   public boolean compareStreams(PRStream outStream, PRStream cmpStream) throws IOException {
/*  952 */     return compareStreamsExtended(outStream, cmpStream, null, null);
/*      */   }
/*      */   
/*      */   private boolean compareStreamsExtended(PRStream outStream, PRStream cmpStream, ObjectPath currentPath, CompareResult compareResult) throws IOException {
/*  956 */     boolean decodeStreams = PdfName.FLATEDECODE.equals(outStream.get(PdfName.FILTER));
/*  957 */     byte[] outStreamBytes = PdfReader.getStreamBytesRaw(outStream);
/*  958 */     byte[] cmpStreamBytes = PdfReader.getStreamBytesRaw(cmpStream);
/*  959 */     if (decodeStreams) {
/*  960 */       outStreamBytes = PdfReader.decodeBytes(outStreamBytes, outStream);
/*  961 */       cmpStreamBytes = PdfReader.decodeBytes(cmpStreamBytes, cmpStream);
/*      */     }
/*  963 */     if ((this.floatComparisonError != 0.0D) && 
/*  964 */       (PdfName.XOBJECT.equals(cmpStream.getDirectObject(PdfName.TYPE))) && 
/*  965 */       (PdfName.XOBJECT.equals(outStream.getDirectObject(PdfName.TYPE))) && 
/*  966 */       (PdfName.FORM.equals(cmpStream.getDirectObject(PdfName.SUBTYPE))) && 
/*  967 */       (PdfName.FORM.equals(outStream.getDirectObject(PdfName.SUBTYPE))))
/*      */     {
/*  969 */       return (compareContentStreamsByParsingExtended(outStream, cmpStream, outStream.getAsDict(PdfName.RESOURCES), cmpStream.getAsDict(PdfName.RESOURCES), currentPath, compareResult)) && (compareDictionariesExtended(outStream, cmpStream, currentPath, compareResult));
/*      */     }
/*  971 */     if (Arrays.equals(outStreamBytes, cmpStreamBytes)) {
/*  972 */       return compareDictionariesExtended(outStream, cmpStream, currentPath, compareResult);
/*      */     }
/*  974 */     if (cmpStreamBytes.length != outStreamBytes.length) {
/*  975 */       if ((compareResult != null) && (currentPath != null)) {
/*  976 */         compareResult.addError(currentPath, String.format("PRStream. Lengths are different. Expected: %s. Found: %s", new Object[] { Integer.valueOf(cmpStreamBytes.length), Integer.valueOf(outStreamBytes.length) }));
/*      */       }
/*      */     } else {
/*  979 */       for (int i = 0; i < cmpStreamBytes.length; i++) {
/*  980 */         if (cmpStreamBytes[i] != outStreamBytes[i]) {
/*  981 */           int l = Math.max(0, i - 10);
/*  982 */           int r = Math.min(cmpStreamBytes.length, i + 10);
/*  983 */           if ((compareResult != null) && (currentPath != null)) {
/*  984 */             currentPath.pushOffsetToPath(i);
/*  985 */             compareResult.addError(currentPath, String.format("PRStream. The bytes differ at index %s. Expected: %s (%s). Found: %s (%s)", new Object[] {
/*  986 */               Integer.valueOf(i), new String(new byte[] { cmpStreamBytes[i] }), new String(cmpStreamBytes, l, r - l).replaceAll("\\n", "\\\\n"), new String(new byte[] { outStreamBytes[i] }), new String(outStreamBytes, l, r - l)
/*  987 */               .replaceAll("\\n", "\\\\n") }));
/*  988 */             currentPath.pop();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  993 */     return false;
/*      */   }
/*      */   
/*      */   public boolean compareArrays(PdfArray outArray, PdfArray cmpArray)
/*      */     throws IOException
/*      */   {
/*  999 */     return compareArraysExtended(outArray, cmpArray, null, null);
/*      */   }
/*      */   
/*      */   private boolean compareArraysExtended(PdfArray outArray, PdfArray cmpArray, ObjectPath currentPath, CompareResult compareResult) throws IOException {
/* 1003 */     if (outArray == null) {
/* 1004 */       if ((compareResult != null) && (currentPath != null))
/* 1005 */         compareResult.addError(currentPath, "Found null. Expected PdfArray.");
/* 1006 */       return false; }
/* 1007 */     if (outArray.size() != cmpArray.size()) {
/* 1008 */       if ((compareResult != null) && (currentPath != null))
/* 1009 */         compareResult.addError(currentPath, String.format("PdfArrays. Lengths are different. Expected: %s. Found: %s.", new Object[] { Integer.valueOf(cmpArray.size()), Integer.valueOf(outArray.size()) }));
/* 1010 */       return false;
/*      */     }
/* 1012 */     boolean arraysAreEqual = true;
/* 1013 */     for (int i = 0; i < cmpArray.size(); i++) {
/* 1014 */       if (currentPath != null)
/* 1015 */         currentPath.pushArrayItemToPath(i);
/* 1016 */       arraysAreEqual = (compareObjects(outArray.getPdfObject(i), cmpArray.getPdfObject(i), currentPath, compareResult)) && (arraysAreEqual);
/* 1017 */       if (currentPath != null)
/* 1018 */         currentPath.pop();
/* 1019 */       if ((!arraysAreEqual) && ((currentPath == null) || (compareResult == null) || (compareResult.isMessageLimitReached()))) {
/* 1020 */         return false;
/*      */       }
/*      */     }
/* 1023 */     return arraysAreEqual;
/*      */   }
/*      */   
/*      */   public boolean compareNames(PdfName outName, PdfName cmpName) {
/* 1027 */     return cmpName.compareTo(outName) == 0;
/*      */   }
/*      */   
/*      */   private boolean compareNamesExtended(PdfName outName, PdfName cmpName, ObjectPath currentPath, CompareResult compareResult) {
/* 1031 */     if (cmpName.compareTo(outName) == 0) {
/* 1032 */       return true;
/*      */     }
/* 1034 */     if ((compareResult != null) && (currentPath != null))
/* 1035 */       compareResult.addError(currentPath, String.format("PdfName. Expected: %s. Found: %s", new Object[] { cmpName.toString(), outName.toString() }));
/* 1036 */     return false;
/*      */   }
/*      */   
/*      */   public boolean compareNumbers(PdfNumber outNumber, PdfNumber cmpNumber)
/*      */   {
/* 1041 */     double difference = Math.abs(outNumber.doubleValue() - cmpNumber.doubleValue());
/* 1042 */     if ((!this.absoluteError) && (cmpNumber.doubleValue() != 0.0D)) {
/* 1043 */       difference /= cmpNumber.doubleValue();
/*      */     }
/* 1045 */     return difference <= this.floatComparisonError;
/*      */   }
/*      */   
/*      */   private boolean compareNumbersExtended(PdfNumber outNumber, PdfNumber cmpNumber, ObjectPath currentPath, CompareResult compareResult) {
/* 1049 */     if (compareNumbers(outNumber, cmpNumber)) {
/* 1050 */       return true;
/*      */     }
/* 1052 */     if ((compareResult != null) && (currentPath != null))
/* 1053 */       compareResult.addError(currentPath, String.format("PdfNumber. Expected: %s. Found: %s", new Object[] { cmpNumber, outNumber }));
/* 1054 */     return false;
/*      */   }
/*      */   
/*      */   public boolean compareStrings(PdfString outString, PdfString cmpString)
/*      */   {
/* 1059 */     return Arrays.equals(cmpString.getBytes(), outString.getBytes());
/*      */   }
/*      */   
/*      */   private boolean compareStringsExtended(PdfString outString, PdfString cmpString, ObjectPath currentPath, CompareResult compareResult) {
/* 1063 */     if (Arrays.equals(cmpString.getBytes(), outString.getBytes())) {
/* 1064 */       return true;
/*      */     }
/* 1066 */     String cmpStr = cmpString.toUnicodeString();
/* 1067 */     String outStr = outString.toUnicodeString();
/* 1068 */     if (cmpStr.length() != outStr.length()) {
/* 1069 */       if ((compareResult != null) && (currentPath != null))
/* 1070 */         compareResult.addError(currentPath, String.format("PdfString. Lengths are different. Expected: %s. Found: %s", new Object[] { Integer.valueOf(cmpStr.length()), Integer.valueOf(outStr.length()) }));
/*      */     } else {
/* 1072 */       for (int i = 0; i < cmpStr.length(); i++) {
/* 1073 */         if (cmpStr.charAt(i) != outStr.charAt(i)) {
/* 1074 */           int l = Math.max(0, i - 10);
/* 1075 */           int r = Math.min(cmpStr.length(), i + 10);
/* 1076 */           if ((compareResult == null) || (currentPath == null)) break;
/* 1077 */           currentPath.pushOffsetToPath(i);
/* 1078 */           compareResult.addError(currentPath, String.format("PdfString. Characters differ at position %s. Expected: %s (%s). Found: %s (%s).", new Object[] {
/* 1079 */             Integer.valueOf(i), Character.toString(cmpStr.charAt(i)), cmpStr.substring(l, r).replace("\n", "\\n"), 
/* 1080 */             Character.toString(outStr.charAt(i)), outStr.substring(l, r).replace("\n", "\\n") }));
/* 1081 */           currentPath.pop(); break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1087 */     return false;
/*      */   }
/*      */   
/*      */   public boolean compareLiterals(PdfLiteral outLiteral, PdfLiteral cmpLiteral)
/*      */   {
/* 1092 */     return Arrays.equals(cmpLiteral.getBytes(), outLiteral.getBytes());
/*      */   }
/*      */   
/*      */   private boolean compareLiteralsExtended(PdfLiteral outLiteral, PdfLiteral cmpLiteral, ObjectPath currentPath, CompareResult compareResult) {
/* 1096 */     if (compareLiterals(outLiteral, cmpLiteral)) {
/* 1097 */       return true;
/*      */     }
/* 1099 */     if ((compareResult != null) && (currentPath != null)) {
/* 1100 */       compareResult.addError(currentPath, String.format("PdfLiteral. Expected: %s. Found: %s", new Object[] { cmpLiteral, outLiteral }));
/*      */     }
/* 1102 */     return false;
/*      */   }
/*      */   
/*      */   public boolean compareBooleans(PdfBoolean outBoolean, PdfBoolean cmpBoolean)
/*      */   {
/* 1107 */     return Arrays.equals(cmpBoolean.getBytes(), outBoolean.getBytes());
/*      */   }
/*      */   
/*      */   private boolean compareBooleansExtended(PdfBoolean outBoolean, PdfBoolean cmpBoolean, ObjectPath currentPath, CompareResult compareResult) {
/* 1111 */     if (cmpBoolean.booleanValue() == outBoolean.booleanValue()) {
/* 1112 */       return true;
/*      */     }
/* 1114 */     if ((compareResult != null) && (currentPath != null))
/* 1115 */       compareResult.addError(currentPath, String.format("PdfBoolean. Expected: %s. Found: %s.", new Object[] { Boolean.valueOf(cmpBoolean.booleanValue()), Boolean.valueOf(outBoolean.booleanValue()) }));
/* 1116 */     return false;
/*      */   }
/*      */   
/*      */   public String compareXmp(byte[] xmp1, byte[] xmp2)
/*      */   {
/* 1121 */     return compareXmp(xmp1, xmp2, false);
/*      */   }
/*      */   
/*      */   public String compareXmp(byte[] xmp1, byte[] xmp2, boolean ignoreDateAndProducerProperties) {
/*      */     try {
/* 1126 */       if (ignoreDateAndProducerProperties) {
/* 1127 */         XMPMeta xmpMeta = XMPMetaFactory.parseFromBuffer(xmp1);
/*      */         
/* 1129 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/xap/1.0/", "CreateDate", true, true);
/* 1130 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/xap/1.0/", "ModifyDate", true, true);
/* 1131 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/xap/1.0/", "MetadataDate", true, true);
/* 1132 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/pdf/1.3/", "Producer", true, true);
/*      */         
/* 1134 */         xmp1 = XMPMetaFactory.serializeToBuffer(xmpMeta, new SerializeOptions(8192));
/*      */         
/* 1136 */         xmpMeta = XMPMetaFactory.parseFromBuffer(xmp2);
/* 1137 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/xap/1.0/", "CreateDate", true, true);
/* 1138 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/xap/1.0/", "ModifyDate", true, true);
/* 1139 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/xap/1.0/", "MetadataDate", true, true);
/* 1140 */         XMPUtils.removeProperties(xmpMeta, "http://ns.adobe.com/pdf/1.3/", "Producer", true, true);
/*      */         
/* 1142 */         xmp2 = XMPMetaFactory.serializeToBuffer(xmpMeta, new SerializeOptions(8192));
/*      */       }
/*      */       
/* 1145 */       if (!compareXmls(xmp1, xmp2)) {
/* 1146 */         return "The XMP packages different!";
/*      */       }
/*      */     } catch (XMPException xmpExc) {
/* 1149 */       return "XMP parsing failure!";
/*      */     } catch (IOException ioExc) {
/* 1151 */       return "XMP parsing failure!";
/*      */     } catch (ParserConfigurationException parseExc) {
/* 1153 */       return "XMP parsing failure!";
/*      */     } catch (SAXException parseExc) {
/* 1155 */       return "XMP parsing failure!";
/*      */     }
/* 1157 */     return null;
/*      */   }
/*      */   
/*      */   public String compareXmp(String outPdf, String cmpPdf) {
/* 1161 */     return compareXmp(outPdf, cmpPdf, false);
/*      */   }
/*      */   
/*      */   public String compareXmp(String outPdf, String cmpPdf, boolean ignoreDateAndProducerProperties) {
/* 1165 */     init(outPdf, cmpPdf);
/* 1166 */     PdfReader cmpReader = null;
/* 1167 */     PdfReader outReader = null;
/*      */     try {
/* 1169 */       cmpReader = new PdfReader(this.cmpPdf);
/* 1170 */       outReader = new PdfReader(this.outPdf);
/* 1171 */       byte[] cmpBytes = cmpReader.getMetadata();outBytes = outReader.getMetadata();
/* 1172 */       return compareXmp(cmpBytes, outBytes, ignoreDateAndProducerProperties);
/*      */     } catch (IOException e) { byte[] outBytes;
/* 1174 */       return "XMP parsing failure!";
/*      */     }
/*      */     finally {
/* 1177 */       if (cmpReader != null)
/* 1178 */         cmpReader.close();
/* 1179 */       if (outReader != null)
/* 1180 */         outReader.close();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean compareXmls(byte[] xml1, byte[] xml2) throws ParserConfigurationException, SAXException, IOException {
/* 1185 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 1186 */     dbf.setNamespaceAware(true);
/* 1187 */     dbf.setCoalescing(true);
/* 1188 */     dbf.setIgnoringElementContentWhitespace(true);
/* 1189 */     dbf.setIgnoringComments(true);
/* 1190 */     DocumentBuilder db = dbf.newDocumentBuilder();
/*      */     
/* 1192 */     Document doc1 = db.parse(new ByteArrayInputStream(xml1));
/* 1193 */     doc1.normalizeDocument();
/*      */     
/* 1195 */     Document doc2 = db.parse(new ByteArrayInputStream(xml2));
/* 1196 */     doc2.normalizeDocument();
/*      */     
/* 1198 */     return doc2.isEqualNode(doc1);
/*      */   }
/*      */   
/*      */   public String compareDocumentInfo(String outPdf, String cmpPdf) throws IOException {
/* 1202 */     System.out.print("[itext] INFO  Comparing document info.......");
/* 1203 */     String message = null;
/* 1204 */     PdfReader outReader = new PdfReader(outPdf);
/* 1205 */     PdfReader cmpReader = new PdfReader(cmpPdf);
/* 1206 */     String[] cmpInfo = convertInfo(cmpReader.getInfo());
/* 1207 */     String[] outInfo = convertInfo(outReader.getInfo());
/* 1208 */     for (int i = 0; i < cmpInfo.length; i++) {
/* 1209 */       if (!cmpInfo[i].equals(outInfo[i])) {
/* 1210 */         message = "Document info fail";
/* 1211 */         break;
/*      */       }
/*      */     }
/* 1214 */     outReader.close();
/* 1215 */     cmpReader.close();
/*      */     
/* 1217 */     if (message == null) {
/* 1218 */       System.out.println("OK");
/*      */     } else
/* 1220 */       System.out.println("Fail");
/* 1221 */     System.out.flush();
/* 1222 */     return message;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean linksAreSame(PdfAnnotation.PdfImportedLink cmpLink, PdfAnnotation.PdfImportedLink outLink)
/*      */   {
/* 1228 */     if (cmpLink.getDestinationPage() != outLink.getDestinationPage())
/* 1229 */       return false;
/* 1230 */     if (!cmpLink.getRect().toString().equals(outLink.getRect().toString())) {
/* 1231 */       return false;
/*      */     }
/* 1233 */     Map<PdfName, PdfObject> cmpParams = cmpLink.getParameters();
/* 1234 */     Map<PdfName, PdfObject> outParams = outLink.getParameters();
/* 1235 */     if (cmpParams.size() != outParams.size()) {
/* 1236 */       return false;
/*      */     }
/* 1238 */     for (Map.Entry<PdfName, PdfObject> cmpEntry : cmpParams.entrySet()) {
/* 1239 */       PdfObject cmpObj = (PdfObject)cmpEntry.getValue();
/* 1240 */       if (!outParams.containsKey(cmpEntry.getKey()))
/* 1241 */         return false;
/* 1242 */       PdfObject outObj = (PdfObject)outParams.get(cmpEntry.getKey());
/* 1243 */       if (cmpObj.type() != outObj.type()) {
/* 1244 */         return false;
/*      */       }
/* 1246 */       switch (cmpObj.type()) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 8: 
/* 1252 */         if (!cmpObj.toString().equals(outObj.toString())) {
/* 1253 */           return false;
/*      */         }
/*      */         break;
/*      */       }
/*      */     }
/* 1258 */     return true;
/*      */   }
/*      */   
/*      */   public String compareLinks(String outPdf, String cmpPdf) throws IOException {
/* 1262 */     System.out.print("[itext] INFO  Comparing link annotations....");
/* 1263 */     String message = null;
/* 1264 */     PdfReader outReader = new PdfReader(outPdf);
/* 1265 */     PdfReader cmpReader = new PdfReader(cmpPdf);
/* 1266 */     for (int i = 0; (i < outReader.getNumberOfPages()) && (i < cmpReader.getNumberOfPages()); i++) {
/* 1267 */       List<PdfAnnotation.PdfImportedLink> outLinks = outReader.getLinks(i + 1);
/* 1268 */       List<PdfAnnotation.PdfImportedLink> cmpLinks = cmpReader.getLinks(i + 1);
/* 1269 */       if (cmpLinks.size() != outLinks.size()) {
/* 1270 */         message = String.format("Different number of links on page %d.", new Object[] { Integer.valueOf(i + 1) });
/* 1271 */         break;
/*      */       }
/* 1273 */       for (int j = 0; j < cmpLinks.size(); j++) {
/* 1274 */         if (!linksAreSame((PdfAnnotation.PdfImportedLink)cmpLinks.get(j), (PdfAnnotation.PdfImportedLink)outLinks.get(j))) {
/* 1275 */           message = String.format("Different links on page %d.\n%s\n%s", new Object[] { Integer.valueOf(i + 1), ((PdfAnnotation.PdfImportedLink)cmpLinks.get(j)).toString(), ((PdfAnnotation.PdfImportedLink)outLinks.get(j)).toString() });
/* 1276 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1280 */     outReader.close();
/* 1281 */     cmpReader.close();
/* 1282 */     if (message == null) {
/* 1283 */       System.out.println("OK");
/*      */     } else
/* 1285 */       System.out.println("Fail");
/* 1286 */     System.out.flush();
/* 1287 */     return message;
/*      */   }
/*      */   
/*      */   public String compareTagStructures(String outPdf, String cmpPdf) throws IOException, ParserConfigurationException, SAXException {
/* 1291 */     System.out.print("[itext] INFO  Comparing tag structures......");
/*      */     
/* 1293 */     String outXml = outPdf.replace(".pdf", ".xml");
/* 1294 */     String cmpXml = outPdf.replace(".pdf", ".cmp.xml");
/*      */     
/* 1296 */     String message = null;
/* 1297 */     PdfReader reader = new PdfReader(outPdf);
/* 1298 */     FileOutputStream xmlOut1 = new FileOutputStream(outXml);
/* 1299 */     new CmpTaggedPdfReaderTool().convertToXml(reader, xmlOut1);
/* 1300 */     reader.close();
/* 1301 */     reader = new PdfReader(cmpPdf);
/* 1302 */     FileOutputStream xmlOut2 = new FileOutputStream(cmpXml);
/* 1303 */     new CmpTaggedPdfReaderTool().convertToXml(reader, xmlOut2);
/* 1304 */     reader.close();
/* 1305 */     if (!compareXmls(outXml, cmpXml)) {
/* 1306 */       message = "The tag structures are different.";
/*      */     }
/* 1308 */     xmlOut1.close();
/* 1309 */     xmlOut2.close();
/* 1310 */     if (message == null) {
/* 1311 */       System.out.println("OK");
/*      */     } else
/* 1313 */       System.out.println("Fail");
/* 1314 */     System.out.flush();
/* 1315 */     return message;
/*      */   }
/*      */   
/*      */   private String[] convertInfo(HashMap<String, String> info) {
/* 1319 */     String[] convertedInfo = { "", "", "", "" };
/* 1320 */     for (Map.Entry<String, String> entry : info.entrySet()) {
/* 1321 */       if ("title".equalsIgnoreCase((String)entry.getKey())) {
/* 1322 */         convertedInfo[0] = ((String)entry.getValue());
/* 1323 */       } else if ("author".equalsIgnoreCase((String)entry.getKey())) {
/* 1324 */         convertedInfo[1] = ((String)entry.getValue());
/* 1325 */       } else if ("subject".equalsIgnoreCase((String)entry.getKey())) {
/* 1326 */         convertedInfo[2] = ((String)entry.getValue());
/* 1327 */       } else if ("keywords".equalsIgnoreCase((String)entry.getKey())) {
/* 1328 */         convertedInfo[3] = ((String)entry.getValue());
/*      */       }
/*      */     }
/* 1331 */     return convertedInfo;
/*      */   }
/*      */   
/*      */   public boolean compareXmls(String xml1, String xml2) throws ParserConfigurationException, SAXException, IOException {
/* 1335 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 1336 */     dbf.setNamespaceAware(true);
/* 1337 */     dbf.setCoalescing(true);
/* 1338 */     dbf.setIgnoringElementContentWhitespace(true);
/* 1339 */     dbf.setIgnoringComments(true);
/* 1340 */     DocumentBuilder db = dbf.newDocumentBuilder();
/*      */     
/* 1342 */     Document doc1 = db.parse(new File(xml1));
/* 1343 */     doc1.normalizeDocument();
/*      */     
/* 1345 */     Document doc2 = db.parse(new File(xml2));
/* 1346 */     doc2.normalizeDocument();
/*      */     
/* 1348 */     return doc2.isEqualNode(doc1);
/*      */   }
/*      */   
/*      */   private void init(String outPdf, String cmpPdf) {
/* 1352 */     this.outPdf = outPdf;
/* 1353 */     this.cmpPdf = cmpPdf;
/* 1354 */     this.outPdfName = new File(outPdf).getName();
/* 1355 */     this.cmpPdfName = new File(cmpPdf).getName();
/* 1356 */     this.outImage = (this.outPdfName + "-%03d.png");
/* 1357 */     if (this.cmpPdfName.startsWith("cmp_")) this.cmpImage = (this.cmpPdfName + "-%03d.png"); else
/* 1358 */       this.cmpImage = ("cmp_" + this.cmpPdfName + "-%03d.png");
/*      */   }
/*      */   
/*      */   private boolean compareStreams(InputStream is1, InputStream is2) throws IOException {
/* 1362 */     byte[] buffer1 = new byte[65536];
/* 1363 */     byte[] buffer2 = new byte[65536];
/*      */     
/*      */     for (;;)
/*      */     {
/* 1367 */       int len1 = is1.read(buffer1);
/* 1368 */       int len2 = is2.read(buffer2);
/* 1369 */       if (len1 != len2)
/* 1370 */         return false;
/* 1371 */       if (!Arrays.equals(buffer1, buffer2))
/* 1372 */         return false;
/* 1373 */       if (len1 == -1)
/*      */         break;
/*      */     }
/* 1376 */     return true;
/*      */   }
/*      */   
/*      */   class PngFileFilter implements FileFilter {
/*      */     PngFileFilter() {}
/*      */     
/* 1382 */     public boolean accept(File pathname) { String ap = pathname.getAbsolutePath();
/* 1383 */       boolean b1 = ap.endsWith(".png");
/* 1384 */       boolean b2 = ap.contains("cmp_");
/* 1385 */       return (b1) && (!b2) && (ap.contains(CompareTool.this.outPdfName));
/*      */     }
/*      */   }
/*      */   
/*      */   class CmpPngFileFilter implements FileFilter { CmpPngFileFilter() {}
/*      */     
/* 1391 */     public boolean accept(File pathname) { String ap = pathname.getAbsolutePath();
/* 1392 */       boolean b1 = ap.endsWith(".png");
/* 1393 */       boolean b2 = ap.contains("cmp_");
/* 1394 */       return (b1) && (b2) && (ap.contains(CompareTool.this.cmpPdfName));
/*      */     }
/*      */   }
/*      */   
/*      */   class ImageNameComparator implements Comparator<File> { ImageNameComparator() {}
/*      */     
/* 1400 */     public int compare(File f1, File f2) { String f1Name = f1.getAbsolutePath();
/* 1401 */       String f2Name = f2.getAbsolutePath();
/* 1402 */       return f1Name.compareTo(f2Name);
/*      */     }
/*      */   }
/*      */   
/*      */   class CmpTaggedPdfReaderTool extends TaggedPdfReaderTool
/*      */   {
/* 1408 */     Map<PdfDictionary, Map<Integer, String>> parsedTags = new HashMap();
/*      */     
/*      */     CmpTaggedPdfReaderTool() {}
/*      */     
/*      */     public void parseTag(String tag, PdfObject object, PdfDictionary page) throws IOException {
/* 1413 */       if ((object instanceof PdfNumber))
/*      */       {
/* 1415 */         if (!this.parsedTags.containsKey(page)) {
/* 1416 */           CompareTool.CmpMarkedContentRenderFilter listener = new CompareTool.CmpMarkedContentRenderFilter(CompareTool.this);
/*      */           
/* 1418 */           PdfContentStreamProcessor processor = new PdfContentStreamProcessor(listener);
/*      */           
/* 1420 */           processor.processContent(PdfReader.getPageContent(page), page
/* 1421 */             .getAsDict(PdfName.RESOURCES));
/*      */           
/* 1423 */           this.parsedTags.put(page, listener.getParsedTagContent());
/*      */         }
/*      */         
/* 1426 */         String tagContent = "";
/* 1427 */         if (((Map)this.parsedTags.get(page)).containsKey(Integer.valueOf(((PdfNumber)object).intValue()))) {
/* 1428 */           tagContent = (String)((Map)this.parsedTags.get(page)).get(Integer.valueOf(((PdfNumber)object).intValue()));
/*      */         }
/* 1430 */         this.out.print(XMLUtil.escapeXML(tagContent, true));
/*      */       }
/*      */       else {
/* 1433 */         super.parseTag(tag, object, page);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1439 */     public void inspectChildDictionary(PdfDictionary k) throws IOException { inspectChildDictionary(k, true); }
/*      */   }
/*      */   
/*      */   class CmpMarkedContentRenderFilter implements RenderListener {
/*      */     CmpMarkedContentRenderFilter() {}
/*      */     
/* 1445 */     Map<Integer, TextExtractionStrategy> tagsByMcid = new HashMap();
/*      */     
/*      */     public Map<Integer, String> getParsedTagContent() {
/* 1448 */       Map<Integer, String> content = new HashMap();
/* 1449 */       for (Iterator localIterator = this.tagsByMcid.keySet().iterator(); localIterator.hasNext();) { int id = ((Integer)localIterator.next()).intValue();
/* 1450 */         content.put(Integer.valueOf(id), ((TextExtractionStrategy)this.tagsByMcid.get(Integer.valueOf(id))).getResultantText());
/*      */       }
/* 1452 */       return content;
/*      */     }
/*      */     
/*      */     public void beginTextBlock() {
/* 1456 */       for (Iterator localIterator = this.tagsByMcid.keySet().iterator(); localIterator.hasNext();) { int id = ((Integer)localIterator.next()).intValue();
/* 1457 */         ((TextExtractionStrategy)this.tagsByMcid.get(Integer.valueOf(id))).beginTextBlock();
/*      */       }
/*      */     }
/*      */     
/*      */     public void renderText(TextRenderInfo renderInfo) {
/* 1462 */       Integer mcid = renderInfo.getMcid();
/* 1463 */       if ((mcid != null) && (this.tagsByMcid.containsKey(mcid))) {
/* 1464 */         ((TextExtractionStrategy)this.tagsByMcid.get(mcid)).renderText(renderInfo);
/*      */       }
/* 1466 */       else if (mcid != null) {
/* 1467 */         this.tagsByMcid.put(mcid, new SimpleTextExtractionStrategy());
/* 1468 */         ((TextExtractionStrategy)this.tagsByMcid.get(mcid)).renderText(renderInfo);
/*      */       }
/*      */     }
/*      */     
/*      */     public void endTextBlock() {
/* 1473 */       for (Iterator localIterator = this.tagsByMcid.keySet().iterator(); localIterator.hasNext();) { int id = ((Integer)localIterator.next()).intValue();
/* 1474 */         ((TextExtractionStrategy)this.tagsByMcid.get(Integer.valueOf(id))).endTextBlock();
/*      */       }
/*      */     }
/*      */     
/*      */     public void renderImage(ImageRenderInfo renderInfo) {}
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/testutils/CompareTool.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */