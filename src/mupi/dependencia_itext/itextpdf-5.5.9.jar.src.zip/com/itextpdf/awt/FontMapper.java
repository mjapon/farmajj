package com.itextpdf.awt;

import com.itextpdf.text.pdf.BaseFont;
import java.awt.Font;

public abstract interface FontMapper
{
  public abstract BaseFont awtToPdf(Font paramFont);
  
  public abstract Font pdfToAwt(BaseFont paramBaseFont, int paramInt);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/awt/FontMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */