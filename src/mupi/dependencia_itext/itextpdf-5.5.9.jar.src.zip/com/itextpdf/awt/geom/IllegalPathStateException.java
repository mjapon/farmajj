/*    */ package com.itextpdf.awt.geom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalPathStateException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -5158084205220481094L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IllegalPathStateException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IllegalPathStateException(String s)
/*    */   {
/* 34 */     super(s);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/awt/geom/IllegalPathStateException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */