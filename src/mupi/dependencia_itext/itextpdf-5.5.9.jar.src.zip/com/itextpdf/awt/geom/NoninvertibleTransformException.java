/*    */ package com.itextpdf.awt.geom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoninvertibleTransformException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 6137225240503990466L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NoninvertibleTransformException(String s)
/*    */   {
/* 31 */     super(s);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/awt/geom/NoninvertibleTransformException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */