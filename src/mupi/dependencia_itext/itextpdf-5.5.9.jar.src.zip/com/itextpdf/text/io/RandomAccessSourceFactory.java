/*     */ package com.itextpdf.text.io;
/*     */ 
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.FileChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RandomAccessSourceFactory
/*     */ {
/*  66 */   private boolean forceRead = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private boolean usePlainRandomAccess = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private boolean exclusivelyLockFile = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSourceFactory setForceRead(boolean forceRead)
/*     */   {
/*  90 */     this.forceRead = forceRead;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSourceFactory setUsePlainRandomAccess(boolean usePlainRandomAccess)
/*     */   {
/* 100 */     this.usePlainRandomAccess = usePlainRandomAccess;
/* 101 */     return this;
/*     */   }
/*     */   
/*     */   public RandomAccessSourceFactory setExclusivelyLockFile(boolean exclusivelyLockFile) {
/* 105 */     this.exclusivelyLockFile = exclusivelyLockFile;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSource createSource(byte[] data)
/*     */   {
/* 115 */     return new ArrayRandomAccessSource(data);
/*     */   }
/*     */   
/*     */   public RandomAccessSource createSource(RandomAccessFile raf) throws IOException {
/* 119 */     return new RAFRandomAccessSource(raf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSource createSource(URL url)
/*     */     throws IOException
/*     */   {
/* 129 */     InputStream is = url.openStream();
/*     */     try {
/* 131 */       return createSource(is);
/*     */     } finally {
/*     */       try {
/* 134 */         is.close();
/*     */       }
/*     */       catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public RandomAccessSource createSource(InputStream is)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 146 */       return createSource(StreamUtil.inputStreamToArray(is));
/*     */     } finally {
/*     */       try {
/* 149 */         is.close();
/*     */       }
/*     */       catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSource createBestSource(String filename)
/*     */     throws IOException
/*     */   {
/* 162 */     File file = new File(filename);
/* 163 */     if (!file.canRead()) {
/* 164 */       if ((filename.startsWith("file:/")) || 
/* 165 */         (filename.startsWith("http://")) || 
/* 166 */         (filename.startsWith("https://")) || 
/* 167 */         (filename.startsWith("jar:")) || 
/* 168 */         (filename.startsWith("wsjar:")) || 
/* 169 */         (filename.startsWith("wsjar:")) || 
/* 170 */         (filename.startsWith("vfszip:"))) {
/* 171 */         return createSource(new URL(filename));
/*     */       }
/* 173 */       return createByReadingToMemory(filename);
/*     */     }
/*     */     
/*     */ 
/* 177 */     if (this.forceRead) {
/* 178 */       return createByReadingToMemory(new FileInputStream(filename));
/*     */     }
/*     */     
/* 181 */     String openMode = this.exclusivelyLockFile ? "rw" : "r";
/*     */     
/* 183 */     RandomAccessFile raf = new RandomAccessFile(file, openMode);
/*     */     
/* 185 */     if (this.exclusivelyLockFile) {
/* 186 */       raf.getChannel().lock();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 191 */       return createBestSource(raf);
/*     */     } catch (IOException e) {
/*     */       try {
/* 194 */         raf.close();
/*     */       } catch (IOException localIOException1) {}
/* 196 */       throw e;
/*     */     } catch (RuntimeException e) {
/*     */       try {
/* 199 */         raf.close();
/*     */       } catch (IOException localIOException2) {}
/* 201 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSource createBestSource(RandomAccessFile raf)
/*     */     throws IOException
/*     */   {
/* 215 */     if (this.usePlainRandomAccess) {
/* 216 */       return new RAFRandomAccessSource(raf);
/*     */     }
/*     */     
/* 219 */     if (raf.length() <= 0L) {
/* 220 */       return new RAFRandomAccessSource(raf);
/*     */     }
/*     */     try
/*     */     {
/* 224 */       return createBestSource(raf.getChannel());
/*     */     } catch (MapFailedException e) {}
/* 226 */     return new RAFRandomAccessSource(raf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RandomAccessSource createBestSource(FileChannel channel)
/*     */     throws IOException
/*     */   {
/* 239 */     if (channel.size() <= 67108864L) {
/* 240 */       return new GetBufferedRandomAccessSource(new FileChannelRandomAccessSource(channel));
/*     */     }
/* 242 */     return new GetBufferedRandomAccessSource(new PagedChannelRandomAccessSource(channel));
/*     */   }
/*     */   
/*     */   public RandomAccessSource createRanged(RandomAccessSource source, long[] ranges) throws IOException
/*     */   {
/* 247 */     RandomAccessSource[] sources = new RandomAccessSource[ranges.length / 2];
/* 248 */     for (int i = 0; i < ranges.length; i += 2) {
/* 249 */       sources[(i / 2)] = new WindowRandomAccessSource(source, ranges[i], ranges[(i + 1)]);
/*     */     }
/* 251 */     return new GroupedRandomAccessSource(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RandomAccessSource createByReadingToMemory(String filename)
/*     */     throws IOException
/*     */   {
/* 261 */     InputStream is = StreamUtil.getResourceStream(filename);
/* 262 */     if (is == null)
/* 263 */       throw new IOException(MessageLocalization.getComposedMessage("1.not.found.as.file.or.resource", new Object[] { filename }));
/* 264 */     return createByReadingToMemory(is);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private RandomAccessSource createByReadingToMemory(InputStream is)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 275 */       return new ArrayRandomAccessSource(StreamUtil.inputStreamToArray(is));
/*     */     } finally {
/*     */       try {
/* 278 */         is.close();
/*     */       }
/*     */       catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/io/RandomAccessSourceFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */