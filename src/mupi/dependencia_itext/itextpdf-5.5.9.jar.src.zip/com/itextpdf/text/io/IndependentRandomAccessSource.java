/*    */ package com.itextpdf.text.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IndependentRandomAccessSource
/*    */   implements RandomAccessSource
/*    */ {
/*    */   private final RandomAccessSource source;
/*    */   
/*    */   public IndependentRandomAccessSource(RandomAccessSource source)
/*    */   {
/* 64 */     this.source = source;
/*    */   }
/*    */   
/*    */ 
/*    */   public int get(long position)
/*    */     throws IOException
/*    */   {
/* 71 */     return this.source.get(position);
/*    */   }
/*    */   
/*    */ 
/*    */   public int get(long position, byte[] bytes, int off, int len)
/*    */     throws IOException
/*    */   {
/* 78 */     return this.source.get(position, bytes, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public long length()
/*    */   {
/* 85 */     return this.source.length();
/*    */   }
/*    */   
/*    */   public void close()
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/io/IndependentRandomAccessSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */