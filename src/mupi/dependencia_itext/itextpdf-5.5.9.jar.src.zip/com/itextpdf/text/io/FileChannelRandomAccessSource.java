/*     */ package com.itextpdf.text.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileChannelRandomAccessSource
/*     */   implements RandomAccessSource
/*     */ {
/*     */   private final FileChannel channel;
/*     */   private final MappedChannelRandomAccessSource source;
/*     */   
/*     */   public FileChannelRandomAccessSource(FileChannel channel)
/*     */     throws IOException
/*     */   {
/*  70 */     this.channel = channel;
/*  71 */     if (channel.size() == 0L)
/*  72 */       throw new IOException("File size is 0 bytes");
/*  73 */     this.source = new MappedChannelRandomAccessSource(channel, 0L, channel.size());
/*  74 */     this.source.open();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  83 */     this.source.close();
/*  84 */     this.channel.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int get(long position)
/*     */     throws IOException
/*     */   {
/*  92 */     return this.source.get(position);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int get(long position, byte[] bytes, int off, int len)
/*     */     throws IOException
/*     */   {
/* 100 */     return this.source.get(position, bytes, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long length()
/*     */   {
/* 108 */     return this.source.length();
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/io/FileChannelRandomAccessSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */