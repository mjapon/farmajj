package com.itextpdf.text.io;

import java.io.IOException;

public abstract interface RandomAccessSource
{
  public abstract int get(long paramLong)
    throws IOException;
  
  public abstract int get(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract long length();
  
  public abstract void close()
    throws IOException;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/io/RandomAccessSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */