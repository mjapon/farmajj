/*     */ package com.itextpdf.text.io;
/*     */ 
/*     */ import com.itextpdf.text.pdf.PdfObject;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TempFileCache
/*     */ {
/*     */   private String filename;
/*     */   private RandomAccessFile cache;
/*     */   private ByteArrayOutputStream baos;
/*     */   private byte[] buf;
/*     */   
/*     */   public class ObjectPosition
/*     */   {
/*     */     long offset;
/*     */     int length;
/*     */     
/*     */     ObjectPosition(long offset, int length)
/*     */     {
/*  53 */       this.offset = offset;
/*  54 */       this.length = length;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TempFileCache(String filename)
/*     */     throws IOException
/*     */   {
/*  69 */     this.filename = filename;
/*  70 */     File f = new File(filename);
/*  71 */     File parent = f.getParentFile();
/*  72 */     if (parent != null) {
/*  73 */       parent.mkdirs();
/*     */     }
/*     */     
/*  76 */     this.cache = new RandomAccessFile(filename, "rw");
/*     */     
/*  78 */     this.baos = new ByteArrayOutputStream();
/*     */   }
/*     */   
/*     */   public ObjectPosition put(PdfObject obj) throws IOException {
/*  82 */     this.baos.reset();
/*  83 */     ObjectOutputStream oos = new ObjectOutputStream(this.baos);
/*     */     
/*     */ 
/*  86 */     long offset = this.cache.length();
/*     */     
/*  88 */     oos.writeObject(obj);
/*  89 */     this.cache.seek(offset);
/*  90 */     this.cache.write(this.baos.toByteArray());
/*     */     
/*  92 */     long size = this.cache.length() - offset;
/*     */     
/*  94 */     return new ObjectPosition(offset, (int)size);
/*     */   }
/*     */   
/*     */   public PdfObject get(ObjectPosition pos) throws IOException, ClassNotFoundException {
/*  98 */     PdfObject obj = null;
/*  99 */     if (pos != null) {
/* 100 */       this.cache.seek(pos.offset);
/* 101 */       this.cache.read(getBuffer(pos.length), 0, pos.length);
/*     */       
/* 103 */       ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(getBuffer(pos.length)));
/*     */       try {
/* 105 */         obj = (PdfObject)ois.readObject();
/*     */       } finally {
/* 107 */         ois.close();
/*     */       }
/*     */     }
/*     */     
/* 111 */     return obj;
/*     */   }
/*     */   
/*     */   private byte[] getBuffer(int size) {
/* 115 */     if ((this.buf == null) || (this.buf.length < size)) {
/* 116 */       this.buf = new byte[size];
/*     */     }
/*     */     
/* 119 */     return this.buf;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 123 */     this.cache.close();
/* 124 */     this.cache = null;
/*     */     
/* 126 */     new File(this.filename).delete();
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/io/TempFileCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */