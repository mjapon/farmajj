package com.itextpdf.text.api;

public abstract interface Spaceable
{
  public abstract void setSpacingBefore(float paramFloat);
  
  public abstract void setSpacingAfter(float paramFloat);
  
  public abstract void setPaddingTop(float paramFloat);
  
  public abstract float getSpacingBefore();
  
  public abstract float getSpacingAfter();
  
  public abstract float getPaddingTop();
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/api/Spaceable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */