package com.itextpdf.text.api;

public abstract interface Indentable
{
  public abstract void setIndentationLeft(float paramFloat);
  
  public abstract void setIndentationRight(float paramFloat);
  
  public abstract float getIndentationLeft();
  
  public abstract float getIndentationRight();
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/api/Indentable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */