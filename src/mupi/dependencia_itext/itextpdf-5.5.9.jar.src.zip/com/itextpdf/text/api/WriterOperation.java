package com.itextpdf.text.api;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

public abstract interface WriterOperation
{
  public abstract void write(PdfWriter paramPdfWriter, Document paramDocument)
    throws DocumentException;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/api/WriterOperation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */