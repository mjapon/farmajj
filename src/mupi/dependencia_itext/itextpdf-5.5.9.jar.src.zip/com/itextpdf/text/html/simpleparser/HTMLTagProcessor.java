package com.itextpdf.text.html.simpleparser;

import com.itextpdf.text.DocumentException;
import java.io.IOException;
import java.util.Map;

@Deprecated
public abstract interface HTMLTagProcessor
{
  public abstract void startElement(HTMLWorker paramHTMLWorker, String paramString, Map<String, String> paramMap)
    throws DocumentException, IOException;
  
  public abstract void endElement(HTMLWorker paramHTMLWorker, String paramString)
    throws DocumentException;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/html/simpleparser/HTMLTagProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */