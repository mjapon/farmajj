package com.itextpdf.text.html.simpleparser;

import com.itextpdf.text.Image;
import java.util.HashMap;

@Deprecated
public class ImageStore
  extends HashMap<String, Image>
{
  private static final long serialVersionUID = -148924031490995024L;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/html/simpleparser/ImageStore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */