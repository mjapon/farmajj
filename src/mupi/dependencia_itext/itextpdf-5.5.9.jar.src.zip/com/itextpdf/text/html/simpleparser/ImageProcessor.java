package com.itextpdf.text.html.simpleparser;

import com.itextpdf.text.DocListener;
import com.itextpdf.text.Image;
import java.util.Map;

@Deprecated
public abstract interface ImageProcessor
{
  public abstract boolean process(Image paramImage, Map<String, String> paramMap, ChainedProperties paramChainedProperties, DocListener paramDocListener);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/html/simpleparser/ImageProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */