package com.itextpdf.text.html;

@Deprecated
public class HtmlTags
{
  public static final String A = "a";
  public static final String B = "b";
  public static final String BODY = "body";
  public static final String BLOCKQUOTE = "blockquote";
  public static final String BR = "br";
  public static final String DIV = "div";
  public static final String EM = "em";
  public static final String FONT = "font";
  public static final String H1 = "h1";
  public static final String H2 = "h2";
  public static final String H3 = "h3";
  public static final String H4 = "h4";
  public static final String H5 = "h5";
  public static final String H6 = "h6";
  public static final String HR = "hr";
  public static final String I = "i";
  public static final String IMG = "img";
  public static final String LI = "li";
  public static final String OL = "ol";
  public static final String P = "p";
  public static final String PRE = "pre";
  public static final String S = "s";
  public static final String SPAN = "span";
  public static final String STRIKE = "strike";
  public static final String STRONG = "strong";
  public static final String SUB = "sub";
  public static final String SUP = "sup";
  public static final String TABLE = "table";
  public static final String TD = "td";
  public static final String TH = "th";
  public static final String TR = "tr";
  public static final String U = "u";
  public static final String UL = "ul";
  public static final String ALIGN = "align";
  public static final String BGCOLOR = "bgcolor";
  public static final String BORDER = "border";
  public static final String CELLPADDING = "cellpadding";
  public static final String COLSPAN = "colspan";
  public static final String EXTRAPARASPACE = "extraparaspace";
  public static final String ENCODING = "encoding";
  public static final String FACE = "face";
  public static final String HEIGHT = "height";
  public static final String HREF = "href";
  public static final String HYPHENATION = "hyphenation";
  public static final String IMAGEPATH = "image_path";
  public static final String INDENT = "indent";
  public static final String LEADING = "leading";
  public static final String ROWSPAN = "rowspan";
  public static final String SIZE = "size";
  public static final String SRC = "src";
  public static final String VALIGN = "valign";
  public static final String WIDTH = "width";
  public static final String ALIGN_LEFT = "left";
  public static final String ALIGN_CENTER = "center";
  public static final String ALIGN_RIGHT = "right";
  public static final String ALIGN_JUSTIFY = "justify";
  public static final String ALIGN_JUSTIFIED_ALL = "JustifyAll";
  public static final String ALIGN_TOP = "top";
  public static final String ALIGN_MIDDLE = "middle";
  public static final String ALIGN_BOTTOM = "bottom";
  public static final String ALIGN_BASELINE = "baseline";
  public static final String STYLE = "style";
  public static final String CLASS = "class";
  public static final String COLOR = "color";
  public static final String FONTFAMILY = "font-family";
  public static final String FONTSIZE = "font-size";
  public static final String FONTSTYLE = "font-style";
  public static final String FONTWEIGHT = "font-weight";
  public static final String LINEHEIGHT = "line-height";
  public static final String PADDINGLEFT = "padding-left";
  public static final String TEXTALIGN = "text-align";
  public static final String TEXTDECORATION = "text-decoration";
  public static final String VERTICALALIGN = "vertical-align";
  public static final String BOLD = "bold";
  public static final String ITALIC = "italic";
  public static final String LINETHROUGH = "line-through";
  public static final String NORMAL = "normal";
  public static final String OBLIQUE = "oblique";
  public static final String UNDERLINE = "underline";
  public static final String AFTER = "after";
  public static final String BEFORE = "before";
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/html/HtmlTags.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */