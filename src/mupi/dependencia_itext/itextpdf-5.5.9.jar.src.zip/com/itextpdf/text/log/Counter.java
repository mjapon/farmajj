package com.itextpdf.text.log;

public abstract interface Counter
{
  public abstract Counter getCounter(Class<?> paramClass);
  
  public abstract void read(long paramLong);
  
  public abstract void written(long paramLong);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/log/Counter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */