package com.itextpdf.text.log;

public abstract interface Logger
{
  public abstract Logger getLogger(Class<?> paramClass);
  
  public abstract Logger getLogger(String paramString);
  
  public abstract boolean isLogging(Level paramLevel);
  
  public abstract void warn(String paramString);
  
  public abstract void trace(String paramString);
  
  public abstract void debug(String paramString);
  
  public abstract void info(String paramString);
  
  public abstract void error(String paramString);
  
  public abstract void error(String paramString, Exception paramException);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/log/Logger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */