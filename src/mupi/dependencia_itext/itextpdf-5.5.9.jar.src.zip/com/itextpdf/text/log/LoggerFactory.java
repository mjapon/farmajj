/*     */ package com.itextpdf.text.log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerFactory
/*     */ {
/*  57 */   private static LoggerFactory myself = new LoggerFactory();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Logger getLogger(Class<?> klass)
/*     */   {
/*  67 */     return myself.logger.getLogger(klass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Logger getLogger(String name)
/*     */   {
/*  75 */     return myself.logger.getLogger(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static LoggerFactory getInstance()
/*     */   {
/*  82 */     return myself;
/*     */   }
/*     */   
/*  85 */   private Logger logger = new NoOpLogger();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogger(Logger logger)
/*     */   {
/*  96 */     this.logger = logger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Logger logger()
/*     */   {
/* 105 */     return this.logger;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/log/LoggerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */