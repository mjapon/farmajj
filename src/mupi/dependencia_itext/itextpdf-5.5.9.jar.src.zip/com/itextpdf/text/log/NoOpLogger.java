/*     */ package com.itextpdf.text.log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NoOpLogger
/*     */   implements Logger
/*     */ {
/*     */   public Logger getLogger(Class<?> name)
/*     */   {
/*  58 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void warn(String message) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void trace(String message) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(String message) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void info(String message) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(String message, Exception e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLogging(Level level)
/*     */   {
/*  95 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(String message) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Logger getLogger(String name)
/*     */   {
/* 108 */     return this;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/log/NoOpLogger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */