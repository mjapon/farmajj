package com.itextpdf.text.log;

public enum Level
{
  ERROR,  WARN,  INFO,  DEBUG,  TRACE;
  
  private Level() {}
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/log/Level.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */