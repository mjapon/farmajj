/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.pdf.CMapAwareDocumentFont;
/*     */ import com.itextpdf.text.pdf.PdfName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicsState
/*     */ {
/*     */   Matrix ctm;
/*     */   float characterSpacing;
/*     */   float wordSpacing;
/*     */   float horizontalScaling;
/*     */   float leading;
/*     */   CMapAwareDocumentFont font;
/*     */   float fontSize;
/*     */   int renderMode;
/*     */   float rise;
/*     */   boolean knockout;
/*     */   PdfName colorSpaceFill;
/*     */   PdfName colorSpaceStroke;
/*  82 */   BaseColor fillColor = BaseColor.BLACK;
/*     */   
/*  84 */   BaseColor strokeColor = BaseColor.BLACK;
/*     */   
/*     */ 
/*     */ 
/*     */   private float lineWidth;
/*     */   
/*     */ 
/*     */ 
/*     */   private int lineCapStyle;
/*     */   
/*     */ 
/*     */ 
/*     */   private int lineJoinStyle;
/*     */   
/*     */ 
/*     */ 
/*     */   private float miterLimit;
/*     */   
/*     */ 
/*     */ 
/*     */   private LineDashPattern lineDashPattern;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public GraphicsState()
/*     */   {
/* 111 */     this.ctm = new Matrix();
/* 112 */     this.characterSpacing = 0.0F;
/* 113 */     this.wordSpacing = 0.0F;
/* 114 */     this.horizontalScaling = 1.0F;
/* 115 */     this.leading = 0.0F;
/* 116 */     this.font = null;
/* 117 */     this.fontSize = 0.0F;
/* 118 */     this.renderMode = 0;
/* 119 */     this.rise = 0.0F;
/* 120 */     this.knockout = true;
/* 121 */     this.colorSpaceFill = null;
/* 122 */     this.colorSpaceStroke = null;
/* 123 */     this.fillColor = null;
/* 124 */     this.strokeColor = null;
/* 125 */     this.lineWidth = 1.0F;
/* 126 */     this.lineCapStyle = 0;
/* 127 */     this.lineJoinStyle = 0;
/* 128 */     this.miterLimit = 10.0F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GraphicsState(GraphicsState source)
/*     */   {
/* 138 */     this.ctm = source.ctm;
/* 139 */     this.characterSpacing = source.characterSpacing;
/* 140 */     this.wordSpacing = source.wordSpacing;
/* 141 */     this.horizontalScaling = source.horizontalScaling;
/* 142 */     this.leading = source.leading;
/* 143 */     this.font = source.font;
/* 144 */     this.fontSize = source.fontSize;
/* 145 */     this.renderMode = source.renderMode;
/* 146 */     this.rise = source.rise;
/* 147 */     this.knockout = source.knockout;
/* 148 */     this.colorSpaceFill = source.colorSpaceFill;
/* 149 */     this.colorSpaceStroke = source.colorSpaceStroke;
/* 150 */     this.fillColor = source.fillColor;
/* 151 */     this.strokeColor = source.strokeColor;
/* 152 */     this.lineWidth = source.lineWidth;
/* 153 */     this.lineCapStyle = source.lineCapStyle;
/* 154 */     this.lineJoinStyle = source.lineJoinStyle;
/* 155 */     this.miterLimit = source.miterLimit;
/*     */     
/* 157 */     if (source.lineDashPattern != null) {
/* 158 */       this.lineDashPattern = new LineDashPattern(source.lineDashPattern.getDashArray(), source.lineDashPattern.getDashPhase());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Matrix getCtm()
/*     */   {
/* 168 */     return this.ctm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getCharacterSpacing()
/*     */   {
/* 177 */     return this.characterSpacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getWordSpacing()
/*     */   {
/* 186 */     return this.wordSpacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getHorizontalScaling()
/*     */   {
/* 195 */     return this.horizontalScaling;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getLeading()
/*     */   {
/* 204 */     return this.leading;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CMapAwareDocumentFont getFont()
/*     */   {
/* 213 */     return this.font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getFontSize()
/*     */   {
/* 222 */     return this.fontSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRenderMode()
/*     */   {
/* 231 */     return this.renderMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getRise()
/*     */   {
/* 240 */     return this.rise;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isKnockout()
/*     */   {
/* 249 */     return this.knockout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PdfName getColorSpaceFill()
/*     */   {
/* 256 */     return this.colorSpaceFill;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PdfName getColorSpaceStroke()
/*     */   {
/* 263 */     return this.colorSpaceStroke;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseColor getFillColor()
/*     */   {
/* 271 */     return this.fillColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseColor getStrokeColor()
/*     */   {
/* 279 */     return this.strokeColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getLineWidth()
/*     */   {
/* 288 */     return this.lineWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineWidth(float lineWidth)
/*     */   {
/* 297 */     this.lineWidth = lineWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineCapStyle()
/*     */   {
/* 307 */     return this.lineCapStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineCapStyle(int lineCapStyle)
/*     */   {
/* 317 */     this.lineCapStyle = lineCapStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineJoinStyle()
/*     */   {
/* 327 */     return this.lineJoinStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineJoinStyle(int lineJoinStyle)
/*     */   {
/* 337 */     this.lineJoinStyle = lineJoinStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getMiterLimit()
/*     */   {
/* 346 */     return this.miterLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMiterLimit(float miterLimit)
/*     */   {
/* 355 */     this.miterLimit = miterLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineDashPattern getLineDashPattern()
/*     */   {
/* 364 */     return this.lineDashPattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineDashPattern(LineDashPattern lineDashPattern)
/*     */   {
/* 373 */     this.lineDashPattern = new LineDashPattern(lineDashPattern.getDashArray(), lineDashPattern.getDashPhase());
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/GraphicsState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */