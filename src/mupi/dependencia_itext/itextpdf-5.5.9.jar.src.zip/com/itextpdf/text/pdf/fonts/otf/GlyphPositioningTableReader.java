/*     */ package com.itextpdf.text.pdf.fonts.otf;
/*     */ 
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.pdf.RandomAccessFileOrArray;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlyphPositioningTableReader
/*     */   extends OpenTypeFontTableReader
/*     */ {
/*     */   public GlyphPositioningTableReader(RandomAccessFileOrArray rf, int gposTableLocation)
/*     */     throws IOException
/*     */   {
/*  62 */     super(rf, gposTableLocation);
/*     */   }
/*     */   
/*     */   public void read() throws FontReadingException {
/*  66 */     startReadingTable();
/*     */   }
/*     */   
/*     */   protected void readSubTable(int lookupType, int subTableLocation)
/*     */     throws IOException
/*     */   {
/*  72 */     if (lookupType == 1) {
/*  73 */       readLookUpType_1(subTableLocation);
/*  74 */     } else if (lookupType == 4) {
/*  75 */       readLookUpType_4(subTableLocation);
/*  76 */     } else if (lookupType == 8) {
/*  77 */       readLookUpType_8(subTableLocation);
/*     */     } else {
/*  79 */       System.err.println("The lookupType " + lookupType + " is not yet supported by " + GlyphPositioningTableReader.class.getSimpleName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void readLookUpType_1(int lookupTableLocation) throws IOException
/*     */   {
/*  85 */     this.rf.seek(lookupTableLocation);
/*  86 */     int posFormat = this.rf.readShort();
/*     */     
/*  88 */     if (posFormat == 1) {
/*  89 */       LOG.debug("Reading `Look Up Type 1, Format 1` ....");
/*  90 */       int coverageOffset = this.rf.readShort();
/*  91 */       int valueFormat = this.rf.readShort();
/*     */       
/*     */ 
/*     */ 
/*  95 */       if ((valueFormat & 0x1) == 1) {
/*  96 */         int xPlacement = this.rf.readShort();
/*  97 */         LOG.debug("xPlacement=" + xPlacement);
/*     */       }
/*     */       
/*     */ 
/* 101 */       if ((valueFormat & 0x2) == 2) {
/* 102 */         int yPlacement = this.rf.readShort();
/* 103 */         LOG.debug("yPlacement=" + yPlacement);
/*     */       }
/*     */       
/* 106 */       List<Integer> glyphCodes = readCoverageFormat(lookupTableLocation + coverageOffset);
/*     */       
/* 108 */       LOG.debug("glyphCodes=" + glyphCodes);
/*     */     } else {
/* 110 */       System.err.println("The PosFormat " + posFormat + " for `LookupType 1` is not yet supported by " + GlyphPositioningTableReader.class.getSimpleName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void readLookUpType_4(int lookupTableLocation) throws IOException
/*     */   {
/* 116 */     this.rf.seek(lookupTableLocation);
/*     */     
/* 118 */     int posFormat = this.rf.readShort();
/*     */     
/* 120 */     if (posFormat == 1)
/*     */     {
/* 122 */       LOG.debug("Reading `Look Up Type 4, Format 1` ....");
/*     */       
/* 124 */       int markCoverageOffset = this.rf.readShort();
/* 125 */       int baseCoverageOffset = this.rf.readShort();
/* 126 */       int classCount = this.rf.readShort();
/* 127 */       int markArrayOffset = this.rf.readShort();
/* 128 */       int baseArrayOffset = this.rf.readShort();
/*     */       
/* 130 */       List<Integer> markCoverages = readCoverageFormat(lookupTableLocation + markCoverageOffset);
/* 131 */       LOG.debug("markCoverages=" + markCoverages);
/*     */       
/* 133 */       List<Integer> baseCoverages = readCoverageFormat(lookupTableLocation + baseCoverageOffset);
/* 134 */       LOG.debug("baseCoverages=" + baseCoverages);
/*     */       
/* 136 */       readMarkArrayTable(lookupTableLocation + markArrayOffset);
/*     */       
/* 138 */       readBaseArrayTable(lookupTableLocation + baseArrayOffset, classCount);
/*     */     } else {
/* 140 */       System.err.println("The posFormat " + posFormat + " is not supported by " + GlyphPositioningTableReader.class.getSimpleName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void readLookUpType_8(int lookupTableLocation) throws IOException {
/* 145 */     this.rf.seek(lookupTableLocation);
/*     */     
/* 147 */     int posFormat = this.rf.readShort();
/*     */     
/* 149 */     if (posFormat == 3) {
/* 150 */       LOG.debug("Reading `Look Up Type 8, Format 3` ....");
/* 151 */       readChainingContextPositioningFormat_3(lookupTableLocation);
/*     */     } else {
/* 153 */       System.err.println("The posFormat " + posFormat + " for `Look Up Type 8` is not supported by " + GlyphPositioningTableReader.class.getSimpleName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void readChainingContextPositioningFormat_3(int lookupTableLocation) throws IOException {
/* 158 */     int backtrackGlyphCount = this.rf.readShort();
/* 159 */     LOG.debug("backtrackGlyphCount=" + backtrackGlyphCount);
/* 160 */     List<Integer> backtrackGlyphOffsets = new ArrayList(backtrackGlyphCount);
/*     */     
/* 162 */     for (int i = 0; i < backtrackGlyphCount; i++) {
/* 163 */       int backtrackGlyphOffset = this.rf.readShort();
/* 164 */       backtrackGlyphOffsets.add(Integer.valueOf(backtrackGlyphOffset));
/*     */     }
/*     */     
/* 167 */     int inputGlyphCount = this.rf.readShort();
/* 168 */     LOG.debug("inputGlyphCount=" + inputGlyphCount);
/* 169 */     List<Integer> inputGlyphOffsets = new ArrayList(inputGlyphCount);
/*     */     
/* 171 */     for (int i = 0; i < inputGlyphCount; i++) {
/* 172 */       int inputGlyphOffset = this.rf.readShort();
/* 173 */       inputGlyphOffsets.add(Integer.valueOf(inputGlyphOffset));
/*     */     }
/*     */     
/* 176 */     int lookaheadGlyphCount = this.rf.readShort();
/* 177 */     LOG.debug("lookaheadGlyphCount=" + lookaheadGlyphCount);
/* 178 */     List<Integer> lookaheadGlyphOffsets = new ArrayList(lookaheadGlyphCount);
/*     */     
/* 180 */     for (int i = 0; i < lookaheadGlyphCount; i++) {
/* 181 */       int lookaheadGlyphOffset = this.rf.readShort();
/* 182 */       lookaheadGlyphOffsets.add(Integer.valueOf(lookaheadGlyphOffset));
/*     */     }
/*     */     
/* 185 */     int posCount = this.rf.readShort();
/* 186 */     LOG.debug("posCount=" + posCount);
/*     */     
/* 188 */     List<PosLookupRecord> posLookupRecords = new ArrayList(posCount);
/*     */     
/* 190 */     for (int i = 0; i < posCount; i++) {
/* 191 */       int sequenceIndex = this.rf.readShort();
/* 192 */       int lookupListIndex = this.rf.readShort();
/* 193 */       LOG.debug("sequenceIndex=" + sequenceIndex + ", lookupListIndex=" + lookupListIndex);
/* 194 */       posLookupRecords.add(new PosLookupRecord(sequenceIndex, lookupListIndex));
/*     */     }
/*     */     
/* 197 */     for (i = backtrackGlyphOffsets.iterator(); i.hasNext();) { int backtrackGlyphOffset = ((Integer)i.next()).intValue();
/* 198 */       List<Integer> backtrackGlyphs = readCoverageFormat(lookupTableLocation + backtrackGlyphOffset);
/* 199 */       LOG.debug("backtrackGlyphs=" + backtrackGlyphs);
/*     */     }
/*     */     
/* 202 */     for (i = inputGlyphOffsets.iterator(); i.hasNext();) { int inputGlyphOffset = ((Integer)i.next()).intValue();
/* 203 */       List<Integer> inputGlyphs = readCoverageFormat(lookupTableLocation + inputGlyphOffset);
/* 204 */       LOG.debug("inputGlyphs=" + inputGlyphs);
/*     */     }
/*     */     
/* 207 */     for (i = lookaheadGlyphOffsets.iterator(); i.hasNext();) { int lookaheadGlyphOffset = ((Integer)i.next()).intValue();
/* 208 */       List<Integer> lookaheadGlyphs = readCoverageFormat(lookupTableLocation + lookaheadGlyphOffset);
/* 209 */       LOG.debug("lookaheadGlyphs=" + lookaheadGlyphs);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readMarkArrayTable(int markArrayLocation) throws IOException
/*     */   {
/* 215 */     this.rf.seek(markArrayLocation);
/* 216 */     int markCount = this.rf.readShort();
/* 217 */     List<MarkRecord> markRecords = new ArrayList();
/*     */     
/* 219 */     for (int i = 0; i < markCount; i++) {
/* 220 */       markRecords.add(readMarkRecord());
/*     */     }
/*     */     
/* 223 */     for (MarkRecord markRecord : markRecords) {
/* 224 */       readAnchorTable(markArrayLocation + markRecord.markAnchorOffset);
/*     */     }
/*     */   }
/*     */   
/*     */   private MarkRecord readMarkRecord() throws IOException {
/* 229 */     int markClass = this.rf.readShort();
/* 230 */     int markAnchorOffset = this.rf.readShort();
/* 231 */     return new MarkRecord(markClass, markAnchorOffset);
/*     */   }
/*     */   
/*     */   private void readAnchorTable(int anchorTableLocation) throws IOException {
/* 235 */     this.rf.seek(anchorTableLocation);
/* 236 */     int anchorFormat = this.rf.readShort();
/*     */     
/* 238 */     if (anchorFormat != 1) {
/* 239 */       System.err.println("The extra features of the AnchorFormat " + anchorFormat + " will not be used");
/*     */     }
/*     */     
/* 242 */     int x = this.rf.readShort();
/* 243 */     int y = this.rf.readShort();
/*     */   }
/*     */   
/*     */   private void readBaseArrayTable(int baseArrayTableLocation, int classCount) throws IOException
/*     */   {
/* 248 */     this.rf.seek(baseArrayTableLocation);
/* 249 */     int baseCount = this.rf.readShort();
/* 250 */     Set<Integer> baseAnchors = new HashSet();
/*     */     
/* 252 */     for (int i = 0; i < baseCount; i++)
/*     */     {
/* 254 */       for (int k = 0; k < classCount; k++) {
/* 255 */         int baseAnchor = this.rf.readShort();
/* 256 */         baseAnchors.add(Integer.valueOf(baseAnchor));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 262 */     for (i = baseAnchors.iterator(); i.hasNext();) { int baseAnchor = ((Integer)i.next()).intValue();
/* 263 */       readAnchorTable(baseArrayTableLocation + baseAnchor);
/*     */     }
/*     */   }
/*     */   
/*     */   static class MarkRecord
/*     */   {
/*     */     final int markClass;
/*     */     final int markAnchorOffset;
/*     */     
/*     */     public MarkRecord(int markClass, int markAnchorOffset) {
/* 273 */       this.markClass = markClass;
/* 274 */       this.markAnchorOffset = markAnchorOffset;
/*     */     }
/*     */   }
/*     */   
/*     */   static class PosLookupRecord
/*     */   {
/*     */     final int sequenceIndex;
/*     */     final int lookupListIndex;
/*     */     
/*     */     public PosLookupRecord(int sequenceIndex, int lookupListIndex) {
/* 284 */       this.sequenceIndex = sequenceIndex;
/* 285 */       this.lookupListIndex = lookupListIndex;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/otf/GlyphPositioningTableReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */