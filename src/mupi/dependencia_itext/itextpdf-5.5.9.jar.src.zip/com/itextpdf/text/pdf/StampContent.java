/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StampContent
/*    */   extends PdfContentByte
/*    */ {
/*    */   PdfStamperImp.PageStamp ps;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   PageResources pageResources;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   StampContent(PdfStamperImp stamper, PdfStamperImp.PageStamp ps)
/*    */   {
/* 53 */     super(stamper);
/* 54 */     this.ps = ps;
/* 55 */     this.pageResources = ps.pageResources;
/*    */   }
/*    */   
/*    */   public void setAction(PdfAction action, float llx, float lly, float urx, float ury) {
/* 59 */     ((PdfStamperImp)this.writer).addAnnotation(this.writer.createAnnotation(llx, lly, urx, ury, action, null), this.ps.pageN);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PdfContentByte getDuplicate()
/*    */   {
/* 69 */     return new StampContent((PdfStamperImp)this.writer, this.ps);
/*    */   }
/*    */   
/*    */   PageResources getPageResources() {
/* 73 */     return this.pageResources;
/*    */   }
/*    */   
/*    */   void addAnnotation(PdfAnnotation annot) {
/* 77 */     ((PdfStamperImp)this.writer).addAnnotation(annot, this.ps.pageN);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/StampContent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */