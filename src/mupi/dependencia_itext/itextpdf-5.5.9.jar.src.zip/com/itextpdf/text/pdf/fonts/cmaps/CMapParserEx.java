/*     */ package com.itextpdf.text.pdf.fonts.cmaps;
/*     */ 
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.pdf.PRTokeniser;
/*     */ import com.itextpdf.text.pdf.PdfContentParser;
/*     */ import com.itextpdf.text.pdf.PdfName;
/*     */ import com.itextpdf.text.pdf.PdfNumber;
/*     */ import com.itextpdf.text.pdf.PdfObject;
/*     */ import com.itextpdf.text.pdf.PdfString;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CMapParserEx
/*     */ {
/*  63 */   private static final PdfName CMAPNAME = new PdfName("CMapName");
/*     */   private static final String DEF = "def";
/*     */   private static final String ENDCIDRANGE = "endcidrange";
/*     */   private static final String ENDCIDCHAR = "endcidchar";
/*     */   private static final String ENDBFRANGE = "endbfrange";
/*     */   private static final String ENDBFCHAR = "endbfchar";
/*     */   private static final String USECMAP = "usecmap";
/*     */   private static final int MAXLEVEL = 10;
/*     */   
/*     */   public static void parseCid(String cmapName, AbstractCMap cmap, CidLocation location) throws IOException {
/*  73 */     parseCid(cmapName, cmap, location, 0);
/*     */   }
/*     */   
/*     */   private static void parseCid(String cmapName, AbstractCMap cmap, CidLocation location, int level) throws IOException {
/*  77 */     if (level >= 10)
/*  78 */       return;
/*  79 */     PRTokeniser inp = location.getLocation(cmapName);
/*     */     try {
/*  81 */       ArrayList<PdfObject> list = new ArrayList();
/*  82 */       PdfContentParser cp = new PdfContentParser(inp);
/*  83 */       int maxExc = 50;
/*     */       for (;;) {
/*     */         try {
/*  86 */           cp.parse(list);
/*     */         }
/*     */         catch (Exception ex) {
/*  89 */           maxExc--; if (maxExc >= 0) break label64; }
/*  90 */         break;
/*  91 */         label64: continue;
/*     */         
/*  93 */         if (list.isEmpty())
/*     */           break;
/*  95 */         String last = ((PdfObject)list.get(list.size() - 1)).toString();
/*  96 */         if ((level == 0) && (list.size() == 3) && (last.equals("def"))) {
/*  97 */           PdfObject key = (PdfObject)list.get(0);
/*  98 */           if (PdfName.REGISTRY.equals(key)) {
/*  99 */             cmap.setRegistry(((PdfObject)list.get(1)).toString());
/* 100 */           } else if (PdfName.ORDERING.equals(key)) {
/* 101 */             cmap.setOrdering(((PdfObject)list.get(1)).toString());
/* 102 */           } else if (CMAPNAME.equals(key)) {
/* 103 */             cmap.setName(((PdfObject)list.get(1)).toString());
/* 104 */           } else if (PdfName.SUPPLEMENT.equals(key)) {
/*     */             try {
/* 106 */               cmap.setSupplement(((PdfNumber)list.get(1)).intValue());
/*     */             }
/*     */             catch (Exception localException1) {}
/*     */           }
/*     */         }
/* 111 */         else if (((last.equals("endcidchar")) || (last.equals("endbfchar"))) && (list.size() >= 3)) {
/* 112 */           int lmax = list.size() - 2;
/* 113 */           for (int k = 0; k < lmax; k += 2) {
/* 114 */             if ((list.get(k) instanceof PdfString)) {
/* 115 */               cmap.addChar((PdfString)list.get(k), (PdfObject)list.get(k + 1));
/*     */             }
/*     */           }
/*     */         }
/* 119 */         else if (((last.equals("endcidrange")) || (last.equals("endbfrange"))) && (list.size() >= 4)) {
/* 120 */           int lmax = list.size() - 3;
/* 121 */           for (int k = 0; k < lmax; k += 3) {
/* 122 */             if (((list.get(k) instanceof PdfString)) && ((list.get(k + 1) instanceof PdfString))) {
/* 123 */               cmap.addRange((PdfString)list.get(k), (PdfString)list.get(k + 1), (PdfObject)list.get(k + 2));
/*     */             }
/*     */           }
/*     */         }
/* 127 */         else if ((last.equals("usecmap")) && (list.size() == 2) && ((list.get(0) instanceof PdfName))) {
/* 128 */           parseCid(PdfName.decodeName(((PdfObject)list.get(0)).toString()), cmap, location, level + 1);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 133 */       inp.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void encodeSequence(int size, byte[] seqs, char cid, ArrayList<char[]> planes) {
/* 138 */     size--;
/* 139 */     int nextPlane = 0;
/* 140 */     for (int idx = 0; idx < size; idx++) {
/* 141 */       char[] plane = (char[])planes.get(nextPlane);
/* 142 */       int one = seqs[idx] & 0xFF;
/* 143 */       char c = plane[one];
/* 144 */       if ((c != 0) && ((c & 0x8000) == 0))
/* 145 */         throw new RuntimeException(MessageLocalization.getComposedMessage("inconsistent.mapping", new Object[0]));
/* 146 */       if (c == 0) {
/* 147 */         planes.add(new char['Ā']);
/* 148 */         c = (char)(planes.size() - 1 | 0x8000);
/* 149 */         plane[one] = c;
/*     */       }
/* 151 */       nextPlane = c & 0x7FFF;
/*     */     }
/* 153 */     char[] plane = (char[])planes.get(nextPlane);
/* 154 */     int one = seqs[size] & 0xFF;
/* 155 */     char c = plane[one];
/* 156 */     if ((c & 0x8000) != 0)
/* 157 */       throw new RuntimeException(MessageLocalization.getComposedMessage("inconsistent.mapping", new Object[0]));
/* 158 */     plane[one] = cid;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/cmaps/CMapParserEx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */