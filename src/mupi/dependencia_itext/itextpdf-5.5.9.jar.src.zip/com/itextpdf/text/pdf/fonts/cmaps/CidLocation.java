package com.itextpdf.text.pdf.fonts.cmaps;

import com.itextpdf.text.pdf.PRTokeniser;
import java.io.IOException;

public abstract interface CidLocation
{
  public abstract PRTokeniser getLocation(String paramString)
    throws IOException;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/cmaps/CidLocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */