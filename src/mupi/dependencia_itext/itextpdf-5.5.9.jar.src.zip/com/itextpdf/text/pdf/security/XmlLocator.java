package com.itextpdf.text.pdf.security;

import com.itextpdf.text.DocumentException;
import java.io.IOException;
import org.w3c.dom.Document;

public abstract interface XmlLocator
{
  public abstract Document getDocument();
  
  public abstract void setDocument(Document paramDocument)
    throws IOException, DocumentException;
  
  public abstract String getEncoding();
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/XmlLocator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */