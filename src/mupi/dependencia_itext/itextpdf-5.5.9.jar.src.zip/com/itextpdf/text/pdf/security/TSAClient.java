package com.itextpdf.text.pdf.security;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;

public abstract interface TSAClient
{
  public abstract int getTokenSizeEstimate();
  
  public abstract MessageDigest getMessageDigest()
    throws GeneralSecurityException;
  
  public abstract byte[] getTimeStampToken(byte[] paramArrayOfByte)
    throws Exception;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/TSAClient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */