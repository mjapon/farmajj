/*     */ package com.itextpdf.text.pdf.security;
/*     */ 
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.cert.CRL;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.bouncycastle.asn1.ASN1ObjectIdentifier;
/*     */ import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
/*     */ import org.bouncycastle.cert.X509CertificateHolder;
/*     */ import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
/*     */ import org.bouncycastle.cert.ocsp.BasicOCSPResp;
/*     */ import org.bouncycastle.cert.ocsp.CertificateID;
/*     */ import org.bouncycastle.cert.ocsp.CertificateStatus;
/*     */ import org.bouncycastle.cert.ocsp.OCSPException;
/*     */ import org.bouncycastle.cert.ocsp.SingleResp;
/*     */ import org.bouncycastle.operator.ContentVerifierProvider;
/*     */ import org.bouncycastle.operator.OperatorCreationException;
/*     */ import org.bouncycastle.operator.bc.BcDigestCalculatorProvider;
/*     */ import org.bouncycastle.operator.jcajce.JcaContentVerifierProviderBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OCSPVerifier
/*     */   extends RootStoreVerifier
/*     */ {
/*  82 */   protected static final Logger LOGGER = LoggerFactory.getLogger(OCSPVerifier.class);
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String id_kp_OCSPSigning = "1.3.6.1.5.5.7.3.9";
/*     */   
/*     */ 
/*     */   protected List<BasicOCSPResp> ocsps;
/*     */   
/*     */ 
/*     */ 
/*     */   public OCSPVerifier(CertificateVerifier verifier, List<BasicOCSPResp> ocsps)
/*     */   {
/*  95 */     super(verifier);
/*  96 */     this.ocsps = ocsps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<VerificationOK> verify(X509Certificate signCert, X509Certificate issuerCert, Date signDate)
/*     */     throws GeneralSecurityException, IOException
/*     */   {
/* 112 */     List<VerificationOK> result = new ArrayList();
/* 113 */     int validOCSPsFound = 0;
/*     */     
/* 115 */     if (this.ocsps != null) {
/* 116 */       for (BasicOCSPResp ocspResp : this.ocsps) {
/* 117 */         if (verify(ocspResp, signCert, issuerCert, signDate)) {
/* 118 */           validOCSPsFound++;
/*     */         }
/*     */       }
/*     */     }
/* 122 */     boolean online = false;
/* 123 */     if ((this.onlineCheckingAllowed) && (validOCSPsFound == 0) && 
/* 124 */       (verify(getOcspResponse(signCert, issuerCert), signCert, issuerCert, signDate))) {
/* 125 */       validOCSPsFound++;
/* 126 */       online = true;
/*     */     }
/*     */     
/*     */ 
/* 130 */     LOGGER.info("Valid OCSPs found: " + validOCSPsFound);
/* 131 */     if (validOCSPsFound > 0)
/* 132 */       result.add(new VerificationOK(signCert, getClass(), "Valid OCSPs Found: " + validOCSPsFound + (online ? " (online)" : "")));
/* 133 */     if (this.verifier != null) {
/* 134 */       result.addAll(this.verifier.verify(signCert, issuerCert, signDate));
/*     */     }
/* 136 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify(BasicOCSPResp ocspResp, X509Certificate signCert, X509Certificate issuerCert, Date signDate)
/*     */     throws GeneralSecurityException, IOException
/*     */   {
/* 151 */     if (ocspResp == null) {
/* 152 */       return false;
/*     */     }
/* 154 */     SingleResp[] resp = ocspResp.getResponses();
/* 155 */     for (int i = 0; i < resp.length; i++)
/*     */     {
/* 157 */       if (signCert.getSerialNumber().equals(resp[i].getCertID().getSerialNumber()))
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/* 162 */           if (issuerCert == null) issuerCert = signCert;
/* 163 */           if (!resp[i].getCertID().matchesIssuer(new X509CertificateHolder(issuerCert.getEncoded()), new BcDigestCalculatorProvider())) {
/* 164 */             LOGGER.info("OCSP: Issuers doesn't match.");
/* 165 */             continue;
/*     */           }
/*     */         }
/*     */         catch (OCSPException e) {
/*     */           continue;
/*     */         }
/* 171 */         Date nextUpdate = resp[i].getNextUpdate();
/* 172 */         if (nextUpdate == null) {
/* 173 */           nextUpdate = new Date(resp[i].getThisUpdate().getTime() + 180000L);
/* 174 */           LOGGER.info(String.format("No 'next update' for OCSP Response; assuming %s", new Object[] { nextUpdate }));
/*     */         }
/* 176 */         if (signDate.after(nextUpdate)) {
/* 177 */           LOGGER.info(String.format("OCSP no longer valid: %s after %s", new Object[] { signDate, nextUpdate }));
/*     */         }
/*     */         else
/*     */         {
/* 181 */           Object status = resp[i].getCertStatus();
/* 182 */           if (status == CertificateStatus.GOOD)
/*     */           {
/* 184 */             isValidResponse(ocspResp, issuerCert);
/* 185 */             return true;
/*     */           }
/*     */         } } }
/* 188 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void isValidResponse(BasicOCSPResp ocspResp, X509Certificate issuerCert)
/*     */     throws GeneralSecurityException, IOException
/*     */   {
/* 203 */     X509Certificate responderCert = null;
/*     */     
/*     */ 
/*     */ 
/* 207 */     if (isSignatureValid(ocspResp, issuerCert)) {
/* 208 */       responderCert = issuerCert;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 213 */     if (responderCert == null) {
/* 214 */       if (ocspResp.getCerts() != null)
/*     */       {
/* 216 */         X509CertificateHolder[] certs = ocspResp.getCerts();
/* 217 */         for (X509CertificateHolder cert : certs)
/*     */         {
/*     */           try {
/* 220 */             tempCert = new JcaX509CertificateConverter().getCertificate(cert);
/*     */           } catch (Exception ex) { X509Certificate tempCert;
/* 222 */             continue; }
/*     */           X509Certificate tempCert;
/* 224 */           List<String> keyPurposes = null;
/*     */           try {
/* 226 */             keyPurposes = tempCert.getExtendedKeyUsage();
/* 227 */             if ((keyPurposes != null) && (keyPurposes.contains("1.3.6.1.5.5.7.3.9")) && (isSignatureValid(ocspResp, tempCert))) {
/* 228 */               responderCert = tempCert;
/* 229 */               break;
/*     */             }
/*     */           }
/*     */           catch (CertificateParsingException localCertificateParsingException) {}
/*     */         }
/*     */         
/*     */ 
/* 236 */         if (responderCert == null) {
/* 237 */           throw new VerificationException(issuerCert, "OCSP response could not be verified");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 242 */         if (this.rootStore != null) {
/*     */           try {
/* 244 */             for (aliases = this.rootStore.aliases(); aliases.hasMoreElements();) {
/* 245 */               String alias = (String)aliases.nextElement();
/*     */               try {
/* 247 */                 if (this.rootStore.isCertificateEntry(alias))
/*     */                 {
/* 249 */                   X509Certificate anchor = (X509Certificate)this.rootStore.getCertificate(alias);
/* 250 */                   if (isSignatureValid(ocspResp, anchor)) {
/* 251 */                     responderCert = anchor;
/* 252 */                     break;
/*     */                   }
/*     */                 }
/*     */               } catch (GeneralSecurityException localGeneralSecurityException1) {}
/*     */             }
/*     */           } catch (KeyStoreException e) { Enumeration<String> aliases;
/* 258 */             responderCert = null;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 264 */         if (responderCert == null) {
/* 265 */           throw new VerificationException(issuerCert, "OCSP response could not be verified");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 271 */     responderCert.verify(issuerCert.getPublicKey());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 276 */     if (responderCert.getExtensionValue(OCSPObjectIdentifiers.id_pkix_ocsp_nocheck.getId()) == null) {
/*     */       CRL crl;
/*     */       try {
/* 279 */         crl = CertificateUtil.getCRL(responderCert);
/*     */       } catch (Exception ignored) { CRL crl;
/* 281 */         crl = null;
/*     */       }
/* 283 */       if ((crl != null) && ((crl instanceof X509CRL))) {
/* 284 */         CRLVerifier crlVerifier = new CRLVerifier(null, null);
/* 285 */         crlVerifier.setRootStore(this.rootStore);
/* 286 */         crlVerifier.setOnlineCheckingAllowed(this.onlineCheckingAllowed);
/* 287 */         crlVerifier.verify((X509CRL)crl, responderCert, issuerCert, new Date());
/* 288 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 293 */     responderCert.checkValidity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean verifyResponse(BasicOCSPResp ocspResp, X509Certificate issuerCert)
/*     */   {
/*     */     try
/*     */     {
/* 308 */       isValidResponse(ocspResp, issuerCert);
/* 309 */       return true;
/*     */     } catch (Exception e) {}
/* 311 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSignatureValid(BasicOCSPResp ocspResp, Certificate responderCert)
/*     */   {
/*     */     try
/*     */     {
/* 324 */       ContentVerifierProvider verifierProvider = new JcaContentVerifierProviderBuilder().setProvider("BC").build(responderCert.getPublicKey());
/* 325 */       return ocspResp.isSignatureValid(verifierProvider);
/*     */     } catch (OperatorCreationException e) {
/* 327 */       return false;
/*     */     } catch (OCSPException e) {}
/* 329 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BasicOCSPResp getOcspResponse(X509Certificate signCert, X509Certificate issuerCert)
/*     */   {
/* 341 */     if ((signCert == null) && (issuerCert == null)) {
/* 342 */       return null;
/*     */     }
/* 344 */     OcspClientBouncyCastle ocsp = new OcspClientBouncyCastle();
/* 345 */     BasicOCSPResp ocspResp = ocsp.getBasicOCSPResp(signCert, issuerCert, null);
/* 346 */     if (ocspResp == null) {
/* 347 */       return null;
/*     */     }
/* 349 */     SingleResp[] resp = ocspResp.getResponses();
/* 350 */     for (int i = 0; i < resp.length; i++) {
/* 351 */       Object status = resp[i].getCertStatus();
/* 352 */       if (status == CertificateStatus.GOOD) {
/* 353 */         return ocspResp;
/*     */       }
/*     */     }
/* 356 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/OCSPVerifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */