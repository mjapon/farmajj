package com.itextpdf.text.pdf.interfaces;

import com.itextpdf.text.pdf.PdfAcroForm;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfFormField;

public abstract interface PdfAnnotations
{
  public abstract PdfAcroForm getAcroForm();
  
  public abstract void addAnnotation(PdfAnnotation paramPdfAnnotation);
  
  public abstract void addCalculationOrder(PdfFormField paramPdfFormField);
  
  public abstract void setSigFlags(int paramInt);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/interfaces/PdfAnnotations.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */