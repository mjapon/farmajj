/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShadingColor
/*    */   extends ExtendedColor
/*    */ {
/*    */   private static final long serialVersionUID = 4817929454941328671L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   PdfShadingPattern shadingPattern;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ShadingColor(PdfShadingPattern shadingPattern)
/*    */   {
/* 61 */     super(5, 0.5F, 0.5F, 0.5F);
/* 62 */     this.shadingPattern = shadingPattern;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PdfShadingPattern getPdfShadingPattern()
/*    */   {
/* 70 */     return this.shadingPattern;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 74 */     return ((obj instanceof ShadingColor)) && (((ShadingColor)obj).shadingPattern.equals(this.shadingPattern));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 78 */     return this.shadingPattern.hashCode();
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/ShadingColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */