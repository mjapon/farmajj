/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.Chunk;
/*     */ import com.itextpdf.text.Font;
/*     */ import com.itextpdf.text.Image;
/*     */ import com.itextpdf.text.SplitCharacter;
/*     */ import com.itextpdf.text.TabSettings;
/*     */ import com.itextpdf.text.TabStop;
/*     */ import com.itextpdf.text.Utilities;
/*     */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfChunk
/*     */ {
/*  67 */   private static final char[] singleSpace = { ' ' };
/*     */   
/*     */   private static final float ITALIC_ANGLE = 0.21256F;
/*  70 */   private static final HashSet<String> keysAttributes = new HashSet();
/*     */   
/*     */ 
/*  73 */   private static final HashSet<String> keysNoStroke = new HashSet();
/*     */   private static final String TABSTOP = "TABSTOP";
/*     */   
/*     */   static {
/*  77 */     keysAttributes.add("ACTION");
/*  78 */     keysAttributes.add("UNDERLINE");
/*  79 */     keysAttributes.add("REMOTEGOTO");
/*  80 */     keysAttributes.add("LOCALGOTO");
/*  81 */     keysAttributes.add("LOCALDESTINATION");
/*  82 */     keysAttributes.add("GENERICTAG");
/*  83 */     keysAttributes.add("NEWPAGE");
/*  84 */     keysAttributes.add("IMAGE");
/*  85 */     keysAttributes.add("BACKGROUND");
/*  86 */     keysAttributes.add("PDFANNOTATION");
/*  87 */     keysAttributes.add("SKEW");
/*  88 */     keysAttributes.add("HSCALE");
/*  89 */     keysAttributes.add("SEPARATOR");
/*  90 */     keysAttributes.add("TAB");
/*  91 */     keysAttributes.add("TABSETTINGS");
/*  92 */     keysAttributes.add("CHAR_SPACING");
/*  93 */     keysAttributes.add("WORD_SPACING");
/*  94 */     keysAttributes.add("LINEHEIGHT");
/*  95 */     keysNoStroke.add("SUBSUPSCRIPT");
/*  96 */     keysNoStroke.add("SPLITCHARACTER");
/*  97 */     keysNoStroke.add("HYPHENATION");
/*  98 */     keysNoStroke.add("TEXTRENDERMODE");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 104 */   protected String value = "";
/*     */   
/*     */ 
/* 107 */   protected String encoding = "Cp1252";
/*     */   
/*     */ 
/*     */ 
/*     */   protected PdfFont font;
/*     */   
/*     */ 
/*     */ 
/*     */   protected BaseFont baseFont;
/*     */   
/*     */ 
/*     */ 
/*     */   protected SplitCharacter splitCharacter;
/*     */   
/*     */ 
/* 122 */   protected HashMap<String, Object> attributes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */   protected HashMap<String, Object> noStroke = new HashMap();
/*     */   
/*     */ 
/*     */   protected boolean newlineSplit;
/*     */   
/*     */   protected Image image;
/*     */   
/* 137 */   protected float imageScalePercentage = 1.0F;
/*     */   
/*     */ 
/*     */   protected float offsetX;
/*     */   
/*     */ 
/*     */   protected float offsetY;
/*     */   
/*     */ 
/* 146 */   protected boolean changeLeading = false;
/*     */   
/*     */ 
/* 149 */   protected float leading = 0.0F;
/*     */   
/* 151 */   protected IAccessibleElement accessibleElement = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final float UNDERLINE_THICKNESS = 0.06666667F;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final float UNDERLINE_OFFSET = -0.33333334F;
/*     */   
/*     */ 
/*     */ 
/*     */   PdfChunk(String string, PdfChunk other)
/*     */   {
/* 165 */     this.value = string;
/* 166 */     this.font = other.font;
/* 167 */     this.attributes = other.attributes;
/* 168 */     this.noStroke = other.noStroke;
/* 169 */     this.baseFont = other.baseFont;
/* 170 */     this.changeLeading = other.changeLeading;
/* 171 */     this.leading = other.leading;
/* 172 */     Object[] obj = (Object[])this.attributes.get("IMAGE");
/* 173 */     if (obj == null) {
/* 174 */       this.image = null;
/*     */     } else {
/* 176 */       this.image = ((Image)obj[0]);
/* 177 */       this.offsetX = ((Float)obj[1]).floatValue();
/* 178 */       this.offsetY = ((Float)obj[2]).floatValue();
/* 179 */       this.changeLeading = ((Boolean)obj[3]).booleanValue();
/*     */     }
/* 181 */     this.encoding = this.font.getFont().getEncoding();
/* 182 */     this.splitCharacter = ((SplitCharacter)this.noStroke.get("SPLITCHARACTER"));
/* 183 */     if (this.splitCharacter == null)
/* 184 */       this.splitCharacter = DefaultSplitCharacter.DEFAULT;
/* 185 */     this.accessibleElement = other.accessibleElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfChunk(Chunk chunk, PdfAction action)
/*     */   {
/* 196 */     this.value = chunk.getContent();
/*     */     
/* 198 */     Font f = chunk.getFont();
/* 199 */     float size = f.getSize();
/* 200 */     if (size == -1.0F)
/* 201 */       size = 12.0F;
/* 202 */     this.baseFont = f.getBaseFont();
/* 203 */     int style = f.getStyle();
/* 204 */     if (style == -1) {
/* 205 */       style = 0;
/*     */     }
/* 207 */     if (this.baseFont == null)
/*     */     {
/* 209 */       this.baseFont = f.getCalculatedBaseFont(false);
/*     */     }
/*     */     else
/*     */     {
/* 213 */       if ((style & 0x1) != 0) {
/* 214 */         this.attributes.put("TEXTRENDERMODE", new Object[] { Integer.valueOf(2), new Float(size / 30.0F), null });
/*     */       }
/* 216 */       if ((style & 0x2) != 0)
/* 217 */         this.attributes.put("SKEW", new float[] { 0.0F, 0.21256F });
/*     */     }
/* 219 */     this.font = new PdfFont(this.baseFont, size);
/*     */     
/* 221 */     HashMap<String, Object> attr = chunk.getAttributes();
/* 222 */     if (attr != null) {
/* 223 */       for (Map.Entry<String, Object> entry : attr.entrySet()) {
/* 224 */         String name = (String)entry.getKey();
/* 225 */         if (keysAttributes.contains(name)) {
/* 226 */           this.attributes.put(name, entry.getValue());
/*     */         }
/* 228 */         else if (keysNoStroke.contains(name)) {
/* 229 */           this.noStroke.put(name, entry.getValue());
/*     */         }
/*     */       }
/* 232 */       if ("".equals(attr.get("GENERICTAG"))) {
/* 233 */         this.attributes.put("GENERICTAG", chunk.getContent());
/*     */       }
/*     */     }
/* 236 */     if (f.isUnderlined()) {
/* 237 */       Object[] obj = { null, { 0.0F, 0.06666667F, 0.0F, -0.33333334F, 0.0F } };
/* 238 */       Object[][] unders = Utilities.addToArray((Object[][])this.attributes.get("UNDERLINE"), obj);
/* 239 */       this.attributes.put("UNDERLINE", unders);
/*     */     }
/* 241 */     if (f.isStrikethru()) {
/* 242 */       Object[] obj = { null, { 0.0F, 0.06666667F, 0.0F, 0.33333334F, 0.0F } };
/* 243 */       Object[][] unders = Utilities.addToArray((Object[][])this.attributes.get("UNDERLINE"), obj);
/* 244 */       this.attributes.put("UNDERLINE", unders);
/*     */     }
/* 246 */     if (action != null) {
/* 247 */       this.attributes.put("ACTION", action);
/*     */     }
/* 249 */     this.noStroke.put("COLOR", f.getColor());
/* 250 */     this.noStroke.put("ENCODING", this.font.getFont().getEncoding());
/*     */     
/* 252 */     Float lh = (Float)this.attributes.get("LINEHEIGHT");
/* 253 */     if (lh != null) {
/* 254 */       this.changeLeading = true;
/* 255 */       this.leading = lh.floatValue();
/*     */     }
/*     */     
/* 258 */     Object[] obj = (Object[])this.attributes.get("IMAGE");
/* 259 */     if (obj == null) {
/* 260 */       this.image = null;
/*     */     }
/*     */     else {
/* 263 */       this.attributes.remove("HSCALE");
/* 264 */       this.image = ((Image)obj[0]);
/* 265 */       this.offsetX = ((Float)obj[1]).floatValue();
/* 266 */       this.offsetY = ((Float)obj[2]).floatValue();
/* 267 */       this.changeLeading = ((Boolean)obj[3]).booleanValue();
/*     */     }
/* 269 */     Float hs = (Float)this.attributes.get("HSCALE");
/* 270 */     if (hs != null)
/* 271 */       this.font.setHorizontalScaling(hs.floatValue());
/* 272 */     this.encoding = this.font.getFont().getEncoding();
/* 273 */     this.splitCharacter = ((SplitCharacter)this.noStroke.get("SPLITCHARACTER"));
/* 274 */     if (this.splitCharacter == null)
/* 275 */       this.splitCharacter = DefaultSplitCharacter.DEFAULT;
/* 276 */     this.accessibleElement = chunk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfChunk(Chunk chunk, PdfAction action, TabSettings tabSettings)
/*     */   {
/* 287 */     this(chunk, action);
/* 288 */     if ((tabSettings != null) && (this.attributes.get("TABSETTINGS") == null)) {
/* 289 */       this.attributes.put("TABSETTINGS", tabSettings);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnicodeEquivalent(int c)
/*     */   {
/* 301 */     return this.baseFont.getUnicodeEquivalent(c);
/*     */   }
/*     */   
/*     */   protected int getWord(String text, int start) {
/* 305 */     int len = text.length();
/* 306 */     while ((start < len) && 
/* 307 */       (Character.isLetter(text.charAt(start))))
/*     */     {
/* 309 */       start++;
/*     */     }
/* 311 */     return start;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfChunk split(float width)
/*     */   {
/* 324 */     this.newlineSplit = false;
/* 325 */     if (this.image != null) {
/* 326 */       if (this.image.getScaledWidth() > width) {
/* 327 */         PdfChunk pc = new PdfChunk("￼", this);
/* 328 */         this.value = "";
/* 329 */         this.attributes = new HashMap();
/* 330 */         this.image = null;
/* 331 */         this.font = PdfFont.getDefaultFont();
/* 332 */         return pc;
/*     */       }
/*     */       
/* 335 */       return null;
/*     */     }
/* 337 */     HyphenationEvent hyphenationEvent = (HyphenationEvent)this.noStroke.get("HYPHENATION");
/* 338 */     int currentPosition = 0;
/* 339 */     int splitPosition = -1;
/* 340 */     float currentWidth = 0.0F;
/*     */     
/*     */ 
/*     */ 
/* 344 */     int lastSpace = -1;
/* 345 */     float lastSpaceWidth = 0.0F;
/* 346 */     int length = this.value.length();
/* 347 */     char[] valueArray = this.value.toCharArray();
/* 348 */     char character = '\000';
/* 349 */     BaseFont ft = this.font.getFont();
/* 350 */     boolean surrogate = false;
/* 351 */     if ((ft.getFontType() == 2) && (ft.getUnicodeEquivalent(32) != 32)) {}
/* 352 */     while (currentPosition < length)
/*     */     {
/* 354 */       char cidChar = valueArray[currentPosition];
/* 355 */       character = (char)ft.getUnicodeEquivalent(cidChar);
/*     */       
/* 357 */       if (character == '\n') {
/* 358 */         this.newlineSplit = true;
/* 359 */         String returnValue = this.value.substring(currentPosition + 1);
/* 360 */         this.value = this.value.substring(0, currentPosition);
/* 361 */         if (this.value.length() < 1) {
/* 362 */           this.value = "\001";
/*     */         }
/* 364 */         PdfChunk pc = new PdfChunk(returnValue, this);
/* 365 */         return pc;
/*     */       }
/* 367 */       currentWidth += getCharWidth(cidChar);
/* 368 */       if (character == ' ') {
/* 369 */         lastSpace = currentPosition + 1;
/* 370 */         lastSpaceWidth = currentWidth;
/*     */       }
/* 372 */       if (currentWidth <= width)
/*     */       {
/*     */ 
/* 375 */         if (this.splitCharacter.isSplitCharacter(0, currentPosition, length, valueArray, new PdfChunk[] { this }))
/* 376 */           splitPosition = currentPosition + 1;
/* 377 */         currentPosition++;
/* 378 */         continue;
/*     */         
/*     */ 
/* 381 */         while (currentPosition < length)
/*     */         {
/* 383 */           character = valueArray[currentPosition];
/*     */           
/* 385 */           if ((character == '\r') || (character == '\n')) {
/* 386 */             this.newlineSplit = true;
/* 387 */             int inc = 1;
/* 388 */             if ((character == '\r') && (currentPosition + 1 < length) && (valueArray[(currentPosition + 1)] == '\n'))
/* 389 */               inc = 2;
/* 390 */             String returnValue = this.value.substring(currentPosition + inc);
/* 391 */             this.value = this.value.substring(0, currentPosition);
/* 392 */             if (this.value.length() < 1) {
/* 393 */               this.value = " ";
/*     */             }
/* 395 */             PdfChunk pc = new PdfChunk(returnValue, this);
/* 396 */             return pc;
/*     */           }
/* 398 */           surrogate = Utilities.isSurrogatePair(valueArray, currentPosition);
/* 399 */           if (surrogate) {
/* 400 */             currentWidth += getCharWidth(Utilities.convertToUtf32(valueArray[currentPosition], valueArray[(currentPosition + 1)]));
/*     */           } else
/* 402 */             currentWidth += getCharWidth(character);
/* 403 */           if (character == ' ') {
/* 404 */             lastSpace = currentPosition + 1;
/* 405 */             lastSpaceWidth = currentWidth;
/*     */           }
/* 407 */           if (surrogate)
/* 408 */             currentPosition++;
/* 409 */           if (currentWidth > width) {
/*     */             break;
/*     */           }
/* 412 */           if (this.splitCharacter.isSplitCharacter(0, currentPosition, length, valueArray, null))
/* 413 */             splitPosition = currentPosition + 1;
/* 414 */           currentPosition++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 419 */     if (currentPosition == length) {
/* 420 */       return null;
/*     */     }
/*     */     
/* 423 */     if (splitPosition < 0) {
/* 424 */       String returnValue = this.value;
/* 425 */       this.value = "";
/* 426 */       PdfChunk pc = new PdfChunk(returnValue, this);
/* 427 */       return pc;
/*     */     }
/* 429 */     if ((lastSpace > splitPosition) && (this.splitCharacter.isSplitCharacter(0, 0, 1, singleSpace, null)))
/* 430 */       splitPosition = lastSpace;
/* 431 */     if ((hyphenationEvent != null) && (lastSpace >= 0) && (lastSpace < currentPosition)) {
/* 432 */       int wordIdx = getWord(this.value, lastSpace);
/* 433 */       if (wordIdx > lastSpace) {
/* 434 */         String pre = hyphenationEvent.getHyphenatedWordPre(this.value.substring(lastSpace, wordIdx), this.font.getFont(), this.font.size(), width - lastSpaceWidth);
/* 435 */         String post = hyphenationEvent.getHyphenatedWordPost();
/* 436 */         if (pre.length() > 0) {
/* 437 */           String returnValue = post + this.value.substring(wordIdx);
/* 438 */           this.value = trim(this.value.substring(0, lastSpace) + pre);
/* 439 */           PdfChunk pc = new PdfChunk(returnValue, this);
/* 440 */           return pc;
/*     */         }
/*     */       }
/*     */     }
/* 444 */     String returnValue = this.value.substring(splitPosition);
/* 445 */     this.value = trim(this.value.substring(0, splitPosition));
/* 446 */     PdfChunk pc = new PdfChunk(returnValue, this);
/* 447 */     return pc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfChunk truncate(float width)
/*     */   {
/* 459 */     if (this.image != null) {
/* 460 */       if (this.image.getScaledWidth() > width)
/*     */       {
/* 462 */         if (this.image.isScaleToFitLineWhenOverflow())
/*     */         {
/*     */ 
/* 465 */           setImageScalePercentage(width / this.image.getWidth());
/* 466 */           return null;
/*     */         }
/* 468 */         PdfChunk pc = new PdfChunk("", this);
/* 469 */         this.value = "";
/* 470 */         this.attributes.remove("IMAGE");
/* 471 */         this.image = null;
/* 472 */         this.font = PdfFont.getDefaultFont();
/* 473 */         return pc;
/*     */       }
/*     */       
/* 476 */       return null;
/*     */     }
/*     */     
/* 479 */     int currentPosition = 0;
/* 480 */     float currentWidth = 0.0F;
/*     */     
/*     */ 
/* 483 */     if (width < this.font.width()) {
/* 484 */       String returnValue = this.value.substring(1);
/* 485 */       this.value = this.value.substring(0, 1);
/* 486 */       PdfChunk pc = new PdfChunk(returnValue, this);
/* 487 */       return pc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 492 */     int length = this.value.length();
/* 493 */     boolean surrogate = false;
/* 494 */     while (currentPosition < length)
/*     */     {
/* 496 */       surrogate = Utilities.isSurrogatePair(this.value, currentPosition);
/* 497 */       if (surrogate) {
/* 498 */         currentWidth += getCharWidth(Utilities.convertToUtf32(this.value, currentPosition));
/*     */       } else
/* 500 */         currentWidth += getCharWidth(this.value.charAt(currentPosition));
/* 501 */       if (currentWidth > width)
/*     */         break;
/* 503 */       if (surrogate)
/* 504 */         currentPosition++;
/* 505 */       currentPosition++;
/*     */     }
/*     */     
/*     */ 
/* 509 */     if (currentPosition == length) {
/* 510 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 516 */     if (currentPosition == 0) {
/* 517 */       currentPosition = 1;
/* 518 */       if (surrogate)
/* 519 */         currentPosition++;
/*     */     }
/* 521 */     String returnValue = this.value.substring(currentPosition);
/* 522 */     this.value = this.value.substring(0, currentPosition);
/* 523 */     PdfChunk pc = new PdfChunk(returnValue, this);
/* 524 */     return pc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfFont font()
/*     */   {
/* 536 */     return this.font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   BaseColor color()
/*     */   {
/* 546 */     return (BaseColor)this.noStroke.get("COLOR");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float width()
/*     */   {
/* 556 */     return width(this.value);
/*     */   }
/*     */   
/*     */   float width(String str) {
/* 560 */     if (isAttribute("SEPARATOR")) {
/* 561 */       return 0.0F;
/*     */     }
/* 563 */     if (isImage()) {
/* 564 */       return getImageWidth();
/*     */     }
/*     */     
/* 567 */     float width = this.font.width(str);
/*     */     
/* 569 */     if (isAttribute("CHAR_SPACING")) {
/* 570 */       Float cs = (Float)getAttribute("CHAR_SPACING");
/* 571 */       width += str.length() * cs.floatValue();
/*     */     }
/* 573 */     if (isAttribute("WORD_SPACING")) {
/* 574 */       int numberOfSpaces = 0;
/* 575 */       int idx = -1;
/* 576 */       while ((idx = str.indexOf(' ', idx + 1)) >= 0)
/* 577 */         numberOfSpaces++;
/* 578 */       Float ws = (Float)getAttribute("WORD_SPACING");
/* 579 */       width += numberOfSpaces * ws.floatValue();
/*     */     }
/* 581 */     return width;
/*     */   }
/*     */   
/*     */   float height() {
/* 585 */     if (isImage()) {
/* 586 */       return getImageHeight();
/*     */     }
/* 588 */     return this.font.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNewlineSplit()
/*     */   {
/* 599 */     return this.newlineSplit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getWidthCorrected(float charSpacing, float wordSpacing)
/*     */   {
/* 612 */     if (this.image != null) {
/* 613 */       return this.image.getScaledWidth() + charSpacing;
/*     */     }
/* 615 */     int numberOfSpaces = 0;
/* 616 */     int idx = -1;
/* 617 */     while ((idx = this.value.indexOf(' ', idx + 1)) >= 0)
/* 618 */       numberOfSpaces++;
/* 619 */     return this.font.width(this.value) + this.value.length() * charSpacing + numberOfSpaces * wordSpacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getTextRise()
/*     */   {
/* 627 */     Float f = (Float)getAttribute("SUBSUPSCRIPT");
/* 628 */     if (f != null) {
/* 629 */       return f.floatValue();
/*     */     }
/* 631 */     return 0.0F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float trimLastSpace()
/*     */   {
/* 641 */     BaseFont ft = this.font.getFont();
/* 642 */     if ((ft.getFontType() == 2) && (ft.getUnicodeEquivalent(32) != 32)) {
/* 643 */       if ((this.value.length() > 1) && (this.value.endsWith("\001"))) {
/* 644 */         this.value = this.value.substring(0, this.value.length() - 1);
/* 645 */         return this.font.width(1);
/*     */       }
/*     */       
/*     */     }
/* 649 */     else if ((this.value.length() > 1) && (this.value.endsWith(" "))) {
/* 650 */       this.value = this.value.substring(0, this.value.length() - 1);
/* 651 */       return this.font.width(32);
/*     */     }
/*     */     
/* 654 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public float trimFirstSpace() {
/* 658 */     BaseFont ft = this.font.getFont();
/* 659 */     if ((ft.getFontType() == 2) && (ft.getUnicodeEquivalent(32) != 32)) {
/* 660 */       if ((this.value.length() > 1) && (this.value.startsWith("\001"))) {
/* 661 */         this.value = this.value.substring(1);
/* 662 */         return this.font.width(1);
/*     */       }
/*     */       
/*     */     }
/* 666 */     else if ((this.value.length() > 1) && (this.value.startsWith(" "))) {
/* 667 */       this.value = this.value.substring(1);
/* 668 */       return this.font.width(32);
/*     */     }
/*     */     
/* 671 */     return 0.0F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getAttribute(String name)
/*     */   {
/* 683 */     if (this.attributes.containsKey(name))
/* 684 */       return this.attributes.get(name);
/* 685 */     return this.noStroke.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isAttribute(String name)
/*     */   {
/* 696 */     if (this.attributes.containsKey(name))
/* 697 */       return true;
/* 698 */     return this.noStroke.containsKey(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isStroked()
/*     */   {
/* 708 */     return !this.attributes.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isSeparator()
/*     */   {
/* 717 */     return isAttribute("SEPARATOR");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isHorizontalSeparator()
/*     */   {
/* 726 */     if (isAttribute("SEPARATOR")) {
/* 727 */       Object[] o = (Object[])getAttribute("SEPARATOR");
/* 728 */       return !((Boolean)o[1]).booleanValue();
/*     */     }
/* 730 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isTab()
/*     */   {
/* 739 */     return isAttribute("TAB");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   void adjustLeft(float newValue)
/*     */   {
/* 749 */     Object[] o = (Object[])this.attributes.get("TAB");
/* 750 */     if (o != null) {
/* 751 */       this.attributes.put("TAB", new Object[] { o[0], o[1], o[2], new Float(newValue) });
/*     */     }
/*     */   }
/*     */   
/*     */   static TabStop getTabStop(PdfChunk tab, float tabPosition) {
/* 756 */     TabStop tabStop = null;
/* 757 */     Object[] o = (Object[])tab.attributes.get("TAB");
/* 758 */     if (o != null) {
/* 759 */       Float tabInterval = (Float)o[0];
/* 760 */       if (Float.isNaN(tabInterval.floatValue())) {
/* 761 */         tabStop = TabSettings.getTabStopNewInstance(tabPosition, (TabSettings)tab.attributes.get("TABSETTINGS"));
/*     */       } else {
/* 763 */         tabStop = TabStop.newInstance(tabPosition, tabInterval.floatValue());
/*     */       }
/*     */     }
/* 766 */     return tabStop;
/*     */   }
/*     */   
/*     */   TabStop getTabStop() {
/* 770 */     return (TabStop)this.attributes.get("TABSTOP");
/*     */   }
/*     */   
/*     */   void setTabStop(TabStop tabStop) {
/* 774 */     this.attributes.put("TABSTOP", tabStop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isImage()
/*     */   {
/* 784 */     return this.image != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Image getImage()
/*     */   {
/* 794 */     return this.image;
/*     */   }
/*     */   
/*     */   float getImageHeight() {
/* 798 */     return this.image.getScaledHeight() * this.imageScalePercentage;
/*     */   }
/*     */   
/*     */   float getImageWidth() {
/* 802 */     return this.image.getScaledWidth() * this.imageScalePercentage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getImageScalePercentage()
/*     */   {
/* 810 */     return this.imageScalePercentage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImageScalePercentage(float imageScalePercentage)
/*     */   {
/* 818 */     this.imageScalePercentage = imageScalePercentage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setImageOffsetX(float offsetX)
/*     */   {
/* 828 */     this.offsetX = offsetX;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float getImageOffsetX()
/*     */   {
/* 838 */     return this.offsetX;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setImageOffsetY(float offsetY)
/*     */   {
/* 848 */     this.offsetY = offsetY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float getImageOffsetY()
/*     */   {
/* 858 */     return this.offsetY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setValue(String value)
/*     */   {
/* 868 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 876 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isSpecialEncoding()
/*     */   {
/* 885 */     return (this.encoding.equals("UnicodeBigUnmarked")) || (this.encoding.equals("Identity-H"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getEncoding()
/*     */   {
/* 895 */     return this.encoding;
/*     */   }
/*     */   
/*     */   int length() {
/* 899 */     return this.value.length();
/*     */   }
/*     */   
/*     */   int lengthUtf32() {
/* 903 */     if (!"Identity-H".equals(this.encoding))
/* 904 */       return this.value.length();
/* 905 */     int total = 0;
/* 906 */     int len = this.value.length();
/* 907 */     for (int k = 0; k < len; k++) {
/* 908 */       if (Utilities.isSurrogateHigh(this.value.charAt(k)))
/* 909 */         k++;
/* 910 */       total++;
/*     */     }
/* 912 */     return total;
/*     */   }
/*     */   
/*     */   boolean isExtSplitCharacter(int start, int current, int end, char[] cc, PdfChunk[] ck) {
/* 916 */     return this.splitCharacter.isSplitCharacter(start, current, end, cc, ck);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String trim(String string)
/*     */   {
/* 926 */     BaseFont ft = this.font.getFont();
/* 927 */     if ((ft.getFontType() == 2) && (ft.getUnicodeEquivalent(32) != 32)) {}
/* 928 */     while (string.endsWith("\001")) {
/* 929 */       string = string.substring(0, string.length() - 1); continue;
/*     */       
/*     */ 
/*     */ 
/* 933 */       while ((string.endsWith(" ")) || (string.endsWith("\t"))) {
/* 934 */         string = string.substring(0, string.length() - 1);
/*     */       }
/*     */     }
/* 937 */     return string;
/*     */   }
/*     */   
/*     */   public boolean changeLeading() {
/* 941 */     return this.changeLeading;
/*     */   }
/*     */   
/*     */   public float getLeading() {
/* 945 */     return this.leading;
/*     */   }
/*     */   
/*     */   float getCharWidth(int c) {
/* 949 */     if (noPrint(c))
/* 950 */       return 0.0F;
/* 951 */     if (isAttribute("CHAR_SPACING")) {
/* 952 */       Float cs = (Float)getAttribute("CHAR_SPACING");
/* 953 */       return this.font.width(c) + cs.floatValue() * this.font.getHorizontalScaling();
/*     */     }
/* 955 */     if (isImage()) {
/* 956 */       return getImageWidth();
/*     */     }
/* 958 */     return this.font.width(c);
/*     */   }
/*     */   
/*     */   public static boolean noPrint(int c) {
/* 962 */     return ((c >= 8203) && (c <= 8207)) || ((c >= 8234) && (c <= 8238));
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfChunk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */