package com.itextpdf.text.pdf;

public abstract interface PdfPTableEvent
{
  public abstract void tableLayout(PdfPTable paramPdfPTable, float[][] paramArrayOfFloat, float[] paramArrayOfFloat1, int paramInt1, int paramInt2, PdfContentByte[] paramArrayOfPdfContentByte);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfPTableEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */