/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Utilities;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.pdf.fonts.otf.GlyphSubstitutionTableReader;
/*     */ import com.itextpdf.text.pdf.fonts.otf.Language;
/*     */ import com.itextpdf.text.pdf.languages.ArabicLigaturizer;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TrueTypeFontUnicode
/*     */   extends TrueTypeFont
/*     */   implements Comparator<int[]>
/*     */ {
/*  69 */   private static final List<Language> SUPPORTED_LANGUAGES_FOR_OTF = Arrays.asList(new Language[] { Language.BENGALI });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, Glyph> glyphSubstitutionMap;
/*     */   
/*     */ 
/*     */ 
/*     */   private Language supportedLanguage;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   TrueTypeFontUnicode(String ttFile, String enc, boolean emb, byte[] ttfAfm, boolean forceRead)
/*     */     throws DocumentException, IOException
/*     */   {
/*  86 */     String nameBase = getBaseName(ttFile);
/*  87 */     String ttcName = getTTCName(nameBase);
/*  88 */     if (nameBase.length() < ttFile.length()) {
/*  89 */       this.style = ttFile.substring(nameBase.length());
/*     */     }
/*  91 */     this.encoding = enc;
/*  92 */     this.embedded = emb;
/*  93 */     this.fileName = ttcName;
/*  94 */     this.ttcIndex = "";
/*  95 */     if (ttcName.length() < nameBase.length())
/*  96 */       this.ttcIndex = nameBase.substring(ttcName.length() + 1);
/*  97 */     this.fontType = 3;
/*  98 */     if (((this.fileName.toLowerCase().endsWith(".ttf")) || (this.fileName.toLowerCase().endsWith(".otf")) || (this.fileName.toLowerCase().endsWith(".ttc"))) && ((enc.equals("Identity-H")) || (enc.equals("Identity-V"))) && (emb)) {
/*  99 */       process(ttfAfm, forceRead);
/* 100 */       if (this.os_2.fsType == 2) {
/* 101 */         throw new DocumentException(MessageLocalization.getComposedMessage("1.cannot.be.embedded.due.to.licensing.restrictions", new Object[] { this.fileName + this.style }));
/*     */       }
/* 103 */       if (((this.cmap31 == null) && (!this.fontSpecific)) || ((this.cmap10 == null) && (this.fontSpecific))) {
/* 104 */         this.directTextToByte = true;
/*     */       }
/* 106 */       if (this.fontSpecific) {
/* 107 */         this.fontSpecific = false;
/* 108 */         String tempEncoding = this.encoding;
/* 109 */         this.encoding = "";
/* 110 */         createEncoding();
/* 111 */         this.encoding = tempEncoding;
/* 112 */         this.fontSpecific = true;
/*     */       }
/*     */     }
/*     */     else {
/* 116 */       throw new DocumentException(MessageLocalization.getComposedMessage("1.2.is.not.a.ttf.font.file", new Object[] { this.fileName, this.style })); }
/* 117 */     this.vertical = enc.endsWith("V");
/*     */   }
/*     */   
/*     */   void process(byte[] ttfAfm, boolean preload) throws DocumentException, IOException
/*     */   {
/* 122 */     super.process(ttfAfm, preload);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth(int char1)
/*     */   {
/* 133 */     if (this.vertical)
/* 134 */       return 1000;
/* 135 */     if (this.fontSpecific) {
/* 136 */       if (((char1 & 0xFF00) == 0) || ((char1 & 0xFF00) == 61440)) {
/* 137 */         return getRawWidth(char1 & 0xFF, null);
/*     */       }
/* 139 */       return 0;
/*     */     }
/*     */     
/* 142 */     return getRawWidth(char1, this.encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth(String text)
/*     */   {
/* 153 */     if (this.vertical)
/* 154 */       return text.length() * 1000;
/* 155 */     int total = 0;
/* 156 */     if (this.fontSpecific) {
/* 157 */       char[] cc = text.toCharArray();
/* 158 */       int len = cc.length;
/* 159 */       for (int k = 0; k < len; k++) {
/* 160 */         char c = cc[k];
/* 161 */         if (((c & 0xFF00) == 0) || ((c & 0xFF00) == 61440)) {
/* 162 */           total += getRawWidth(c & 0xFF, null);
/*     */         }
/*     */       }
/*     */     } else {
/* 166 */       int len = text.length();
/* 167 */       for (int k = 0; k < len; k++)
/* 168 */         if (Utilities.isSurrogatePair(text, k)) {
/* 169 */           total += getRawWidth(Utilities.convertToUtf32(text, k), this.encoding);
/* 170 */           k++;
/*     */         }
/*     */         else {
/* 173 */           total += getRawWidth(text.charAt(k), this.encoding);
/*     */         }
/*     */     }
/* 176 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStream getToUnicode(Object[] metrics)
/*     */   {
/* 185 */     if (metrics.length == 0)
/* 186 */       return null;
/* 187 */     StringBuffer buf = new StringBuffer("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo\n<< /Registry (TTX+0)\n/Ordering (T42UV)\n/Supplement 0\n>> def\n/CMapName /TTX+0 def\n/CMapType 2 def\n1 begincodespacerange\n<0000><FFFF>\nendcodespacerange\n");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */     int size = 0;
/* 202 */     for (int k = 0; k < metrics.length; k++) {
/* 203 */       if (size == 0) {
/* 204 */         if (k != 0) {
/* 205 */           buf.append("endbfrange\n");
/*     */         }
/* 207 */         size = Math.min(100, metrics.length - k);
/* 208 */         buf.append(size).append(" beginbfrange\n");
/*     */       }
/* 210 */       size--;
/* 211 */       int[] metric = (int[])metrics[k];
/* 212 */       String fromTo = toHex(metric[0]);
/* 213 */       buf.append(fromTo).append(fromTo).append(toHex(metric[2])).append('\n');
/*     */     }
/* 215 */     buf.append("endbfrange\nendcmap\nCMapName currentdict /CMap defineresource pop\nend end\n");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 220 */     String s = buf.toString();
/* 221 */     PdfStream stream = new PdfStream(PdfEncodings.convertToBytes(s, null));
/* 222 */     stream.flateCompress(this.compressionLevel);
/* 223 */     return stream;
/*     */   }
/*     */   
/*     */   private static String toHex4(int n) {
/* 227 */     String s = "0000" + Integer.toHexString(n);
/* 228 */     return s.substring(s.length() - 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static String toHex(int n)
/*     */   {
/* 236 */     if (n < 65536)
/* 237 */       return "<" + toHex4(n) + ">";
/* 238 */     n -= 65536;
/* 239 */     int high = n / 1024 + 55296;
/* 240 */     int low = n % 1024 + 56320;
/* 241 */     return "[<" + toHex4(high) + toHex4(low) + ">]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDictionary getCIDFontType2(PdfIndirectReference fontDescriptor, String subsetPrefix, Object[] metrics)
/*     */   {
/* 251 */     PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/*     */     
/* 253 */     if (this.cff) {
/* 254 */       dic.put(PdfName.SUBTYPE, PdfName.CIDFONTTYPE0);
/* 255 */       dic.put(PdfName.BASEFONT, new PdfName(subsetPrefix + this.fontName + "-" + this.encoding));
/*     */     }
/*     */     else {
/* 258 */       dic.put(PdfName.SUBTYPE, PdfName.CIDFONTTYPE2);
/* 259 */       dic.put(PdfName.BASEFONT, new PdfName(subsetPrefix + this.fontName));
/*     */     }
/* 261 */     dic.put(PdfName.FONTDESCRIPTOR, fontDescriptor);
/* 262 */     if (!this.cff)
/* 263 */       dic.put(PdfName.CIDTOGIDMAP, PdfName.IDENTITY);
/* 264 */     PdfDictionary cdic = new PdfDictionary();
/* 265 */     cdic.put(PdfName.REGISTRY, new PdfString("Adobe"));
/* 266 */     cdic.put(PdfName.ORDERING, new PdfString("Identity"));
/* 267 */     cdic.put(PdfName.SUPPLEMENT, new PdfNumber(0));
/* 268 */     dic.put(PdfName.CIDSYSTEMINFO, cdic);
/* 269 */     if (!this.vertical) {
/* 270 */       dic.put(PdfName.DW, new PdfNumber(1000));
/* 271 */       StringBuffer buf = new StringBuffer("[");
/* 272 */       int lastNumber = -10;
/* 273 */       boolean firstTime = true;
/* 274 */       for (int k = 0; k < metrics.length; k++) {
/* 275 */         int[] metric = (int[])metrics[k];
/* 276 */         if (metric[1] != 1000)
/*     */         {
/* 278 */           int m = metric[0];
/* 279 */           if (m == lastNumber + 1) {
/* 280 */             buf.append(' ').append(metric[1]);
/*     */           }
/*     */           else {
/* 283 */             if (!firstTime) {
/* 284 */               buf.append(']');
/*     */             }
/* 286 */             firstTime = false;
/* 287 */             buf.append(m).append('[').append(metric[1]);
/*     */           }
/* 289 */           lastNumber = m;
/*     */         } }
/* 291 */       if (buf.length() > 1) {
/* 292 */         buf.append("]]");
/* 293 */         dic.put(PdfName.W, new PdfLiteral(buf.toString()));
/*     */       }
/*     */     }
/* 296 */     return dic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDictionary getFontBaseType(PdfIndirectReference descendant, String subsetPrefix, PdfIndirectReference toUnicode)
/*     */   {
/* 306 */     PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/*     */     
/* 308 */     dic.put(PdfName.SUBTYPE, PdfName.TYPE0);
/*     */     
/* 310 */     if (this.cff) {
/* 311 */       dic.put(PdfName.BASEFONT, new PdfName(subsetPrefix + this.fontName + "-" + this.encoding));
/*     */     }
/*     */     else {
/* 314 */       dic.put(PdfName.BASEFONT, new PdfName(subsetPrefix + this.fontName));
/*     */     }
/* 316 */     dic.put(PdfName.ENCODING, new PdfName(this.encoding));
/* 317 */     dic.put(PdfName.DESCENDANTFONTS, new PdfArray(descendant));
/* 318 */     if (toUnicode != null)
/* 319 */       dic.put(PdfName.TOUNICODE, toUnicode);
/* 320 */     return dic;
/*     */   }
/*     */   
/*     */   public int GetCharFromGlyphId(int gid) {
/* 324 */     if (this.glyphIdToChar == null) {
/* 325 */       int[] g2 = new int[this.maxGlyphId];
/* 326 */       HashMap<Integer, int[]> map = null;
/* 327 */       if (this.cmapExt != null) {
/* 328 */         map = this.cmapExt;
/*     */       }
/* 330 */       else if (this.cmap31 != null) {
/* 331 */         map = this.cmap31;
/*     */       }
/* 333 */       if (map != null) {
/* 334 */         for (Map.Entry<Integer, int[]> entry : map.entrySet()) {
/* 335 */           g2[((int[])entry.getValue())[0]] = ((Integer)entry.getKey()).intValue();
/*     */         }
/*     */       }
/* 338 */       this.glyphIdToChar = g2;
/*     */     }
/* 340 */     return this.glyphIdToChar[gid];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compare(int[] o1, int[] o2)
/*     */   {
/* 349 */     int m1 = o1[0];
/* 350 */     int m2 = o2[0];
/* 351 */     if (m1 < m2)
/* 352 */       return -1;
/* 353 */     if (m1 == m2)
/* 354 */       return 0;
/* 355 */     return 1;
/*     */   }
/*     */   
/* 358 */   private static final byte[] rotbits = { Byte.MIN_VALUE, 64, 32, 16, 8, 4, 2, 1 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void writeFont(PdfWriter writer, PdfIndirectReference ref, Object[] params)
/*     */     throws DocumentException, IOException
/*     */   {
/* 369 */     writer.getTtfUnicodeWriter().writeFont(this, ref, params, rotbits);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStream getFullFontStream()
/*     */     throws IOException, DocumentException
/*     */   {
/* 379 */     if (this.cff) {
/* 380 */       return new BaseFont.StreamFont(readCffFont(), "CIDFontType0C", this.compressionLevel);
/*     */     }
/* 382 */     return super.getFullFontStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] convertToBytes(String text)
/*     */   {
/* 391 */     return null;
/*     */   }
/*     */   
/*     */   byte[] convertToBytes(int char1)
/*     */   {
/* 396 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getMetricsTT(int c)
/*     */   {
/* 405 */     if (this.cmapExt != null)
/* 406 */       return (int[])this.cmapExt.get(Integer.valueOf(c));
/* 407 */     HashMap<Integer, int[]> map = null;
/* 408 */     if (this.fontSpecific) {
/* 409 */       map = this.cmap10;
/*     */     } else
/* 411 */       map = this.cmap31;
/* 412 */     if (map == null)
/* 413 */       return null;
/* 414 */     if (this.fontSpecific) {
/* 415 */       if (((c & 0xFF00) == 0) || ((c & 0xFF00) == 61440)) {
/* 416 */         return (int[])map.get(Integer.valueOf(c & 0xFF));
/*     */       }
/* 418 */       return null;
/*     */     }
/*     */     
/* 421 */     int[] result = (int[])map.get(Integer.valueOf(c));
/* 422 */     if (result == null) {
/* 423 */       Character ch = ArabicLigaturizer.getReverseMapping((char)c);
/* 424 */       if (ch != null)
/* 425 */         result = (int[])map.get(Integer.valueOf(ch.charValue()));
/*     */     }
/* 427 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean charExists(int c)
/*     */   {
/* 439 */     return getMetricsTT(c) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setCharAdvance(int c, int advance)
/*     */   {
/* 451 */     int[] m = getMetricsTT(c);
/* 452 */     if (m == null)
/* 453 */       return false;
/* 454 */     m[1] = advance;
/* 455 */     return true;
/*     */   }
/*     */   
/*     */   public int[] getCharBBox(int c)
/*     */   {
/* 460 */     if (this.bboxes == null)
/* 461 */       return null;
/* 462 */     int[] m = getMetricsTT(c);
/* 463 */     if (m == null)
/* 464 */       return null;
/* 465 */     return this.bboxes[m[0]];
/*     */   }
/*     */   
/*     */   protected Map<String, Glyph> getGlyphSubstitutionMap() {
/* 469 */     return this.glyphSubstitutionMap;
/*     */   }
/*     */   
/*     */   Language getSupportedLanguage() {
/* 473 */     return this.supportedLanguage;
/*     */   }
/*     */   
/*     */   private void readGsubTable() throws IOException {
/* 477 */     if (this.tables.get("GSUB") != null)
/*     */     {
/* 479 */       Map<Integer, Character> glyphToCharacterMap = new HashMap(this.cmap31.size());
/*     */       
/* 481 */       for (Integer charCode : this.cmap31.keySet()) {
/* 482 */         char c = (char)charCode.intValue();
/* 483 */         int glyphCode = ((int[])this.cmap31.get(charCode))[0];
/* 484 */         glyphToCharacterMap.put(Integer.valueOf(glyphCode), Character.valueOf(c));
/*     */       }
/*     */       
/*     */ 
/* 488 */       GlyphSubstitutionTableReader gsubReader = new GlyphSubstitutionTableReader(this.rf, ((int[])this.tables.get("GSUB"))[0], glyphToCharacterMap, this.glyphWidthsByIndex);
/*     */       try
/*     */       {
/* 491 */         gsubReader.read();
/* 492 */         this.supportedLanguage = gsubReader.getSupportedLanguage();
/*     */         
/* 494 */         if (SUPPORTED_LANGUAGES_FOR_OTF.contains(this.supportedLanguage)) {
/* 495 */           this.glyphSubstitutionMap = gsubReader.getGlyphSubstitutionMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 517 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/TrueTypeFontUnicode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */