/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TtfUnicodeWriter
/*     */ {
/*  57 */   protected PdfWriter writer = null;
/*     */   
/*     */   public TtfUnicodeWriter(PdfWriter writer) {
/*  60 */     this.writer = writer;
/*     */   }
/*     */   
/*     */   public void writeFont(TrueTypeFontUnicode font, PdfIndirectReference ref, Object[] params, byte[] rotbits) throws DocumentException, IOException {
/*  64 */     HashMap<Integer, int[]> longTag = (HashMap)params[0];
/*  65 */     font.addRangeUni(longTag, true, font.subset);
/*  66 */     int[][] metrics = (int[][])longTag.values().toArray(new int[0][]);
/*  67 */     Arrays.sort(metrics, font);
/*     */     
/*     */ 
/*     */     PdfIndirectReference ind_font;
/*     */     
/*  72 */     if (font.cff) {
/*  73 */       byte[] b = font.readCffFont();
/*  74 */       if ((font.subset) || (font.subsetRanges != null)) {
/*  75 */         CFFFontSubset cff = new CFFFontSubset(new RandomAccessFileOrArray(b), longTag);
/*     */         try {
/*  77 */           b = cff.Process(cff.getNames()[0]);
/*     */         }
/*     */         catch (Exception e) {
/*  80 */           LoggerFactory.getLogger(TtfUnicodeWriter.class).error("Issue in CFF font subsetting.Subsetting was disabled", e);
/*     */           
/*  82 */           font.setSubset(false);
/*  83 */           font.addRangeUni(longTag, true, font.subset);
/*  84 */           metrics = (int[][])longTag.values().toArray(new int[0][]);
/*  85 */           Arrays.sort(metrics, font);
/*     */         }
/*     */       }
/*  88 */       PdfObject pobj = new BaseFont.StreamFont(b, "CIDFontType0C", font.compressionLevel);
/*  89 */       PdfIndirectObject obj = this.writer.addToBody(pobj);
/*  90 */       ind_font = obj.getIndirectReference();
/*     */     } else { byte[] b;
/*     */       byte[] b;
/*  93 */       if ((font.subset) || (font.directoryOffset != 0)) { byte[] b;
/*  94 */         synchronized (font.rf) {
/*  95 */           TrueTypeFontSubSet sb = new TrueTypeFontSubSet(font.fileName, new RandomAccessFileOrArray(font.rf), new HashSet(longTag.keySet()), font.directoryOffset, true, false);
/*  96 */           b = sb.process();
/*     */         }
/*     */       }
/*     */       else {
/* 100 */         b = font.getFullFont();
/*     */       }
/* 102 */       int[] lengths = { b.length };
/* 103 */       pobj = new BaseFont.StreamFont(b, lengths, font.compressionLevel);
/* 104 */       obj = this.writer.addToBody(pobj);
/* 105 */       ind_font = obj.getIndirectReference();
/*     */     }
/* 107 */     String subsetPrefix = "";
/* 108 */     if (font.subset)
/* 109 */       subsetPrefix = TrueTypeFontUnicode.createSubsetPrefix();
/* 110 */     PdfDictionary dic = font.getFontDescriptor(ind_font, subsetPrefix, null);
/* 111 */     PdfIndirectObject obj = this.writer.addToBody(dic);
/* 112 */     PdfIndirectReference ind_font = obj.getIndirectReference();
/*     */     
/* 114 */     PdfObject pobj = font.getCIDFontType2(ind_font, subsetPrefix, metrics);
/* 115 */     obj = this.writer.addToBody(pobj);
/* 116 */     ind_font = obj.getIndirectReference();
/*     */     
/* 118 */     pobj = font.getToUnicode(metrics);
/* 119 */     PdfIndirectReference toUnicodeRef = null;
/*     */     
/* 121 */     if (pobj != null) {
/* 122 */       obj = this.writer.addToBody(pobj);
/* 123 */       toUnicodeRef = obj.getIndirectReference();
/*     */     }
/*     */     
/* 126 */     pobj = font.getFontBaseType(ind_font, subsetPrefix, toUnicodeRef);
/* 127 */     this.writer.addToBody(pobj, ref);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/TtfUnicodeWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */