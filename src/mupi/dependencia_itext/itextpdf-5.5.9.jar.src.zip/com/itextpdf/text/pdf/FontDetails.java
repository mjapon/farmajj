/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Utilities;
/*     */ import com.itextpdf.text.pdf.fonts.otf.Language;
/*     */ import com.itextpdf.text.pdf.languages.BanglaGlyphRepositioner;
/*     */ import com.itextpdf.text.pdf.languages.GlyphRepositioner;
/*     */ import com.itextpdf.text.pdf.languages.IndicCompositeCharacterComparator;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontDetails
/*     */ {
/*     */   PdfIndirectReference indirectReference;
/*     */   PdfName fontName;
/*     */   BaseFont baseFont;
/*     */   TrueTypeFontUnicode ttu;
/*     */   CJKFont cjkFont;
/*     */   byte[] shortTag;
/*     */   HashMap<Integer, int[]> longTag;
/*     */   IntHashtable cjkTag;
/*     */   int fontType;
/*     */   boolean symbolic;
/* 110 */   protected boolean subset = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FontDetails(PdfName fontName, PdfIndirectReference indirectReference, BaseFont baseFont)
/*     */   {
/* 121 */     this.fontName = fontName;
/* 122 */     this.indirectReference = indirectReference;
/* 123 */     this.baseFont = baseFont;
/* 124 */     this.fontType = baseFont.getFontType();
/* 125 */     switch (this.fontType) {
/*     */     case 0: 
/*     */     case 1: 
/* 128 */       this.shortTag = new byte['Ā'];
/* 129 */       break;
/*     */     case 2: 
/* 131 */       this.cjkTag = new IntHashtable();
/* 132 */       this.cjkFont = ((CJKFont)baseFont);
/* 133 */       break;
/*     */     case 3: 
/* 135 */       this.longTag = new HashMap();
/* 136 */       this.ttu = ((TrueTypeFontUnicode)baseFont);
/* 137 */       this.symbolic = baseFont.isFontSpecific();
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfIndirectReference getIndirectReference()
/*     */   {
/* 147 */     return this.indirectReference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfName getFontName()
/*     */   {
/* 155 */     return this.fontName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   BaseFont getBaseFont()
/*     */   {
/* 163 */     return this.baseFont;
/*     */   }
/*     */   
/*     */   Object[] convertToBytesGid(String gids) {
/* 167 */     if (this.fontType != 3)
/* 168 */       throw new IllegalArgumentException("GID require TT Unicode");
/*     */     try {
/* 170 */       StringBuilder sb = new StringBuilder();
/* 171 */       int totalWidth = 0;
/* 172 */       for (char gid : gids.toCharArray()) {
/* 173 */         int width = this.ttu.getGlyphWidth(gid);
/* 174 */         totalWidth += width;
/* 175 */         int vchar = this.ttu.GetCharFromGlyphId(gid);
/* 176 */         if (vchar != 0) {
/* 177 */           sb.append(Utilities.convertFromUtf32(vchar));
/*     */         }
/* 179 */         Integer gl = Integer.valueOf(gid);
/* 180 */         if (!this.longTag.containsKey(gl))
/* 181 */           this.longTag.put(gl, new int[] { gid, width, vchar });
/*     */       }
/* 183 */       return new Object[] { gids.getBytes("UnicodeBigUnmarked"), sb.toString(), Integer.valueOf(totalWidth) };
/*     */     }
/*     */     catch (Exception e) {
/* 186 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] convertToBytes(String text)
/*     */   {
/* 198 */     byte[] b = null;
/* 199 */     switch (this.fontType) {
/*     */     case 5: 
/* 201 */       return this.baseFont.convertToBytes(text);
/*     */     case 0: 
/*     */     case 1: 
/* 204 */       b = this.baseFont.convertToBytes(text);
/* 205 */       int len = b.length;
/* 206 */       for (int k = 0; k < len; k++)
/* 207 */         this.shortTag[(b[k] & 0xFF)] = 1;
/* 208 */       break;
/*     */     
/*     */     case 2: 
/* 211 */       int len = text.length();
/* 212 */       if (this.cjkFont.isIdentity()) {
/* 213 */         for (int k = 0; k < len; k++) {
/* 214 */           this.cjkTag.put(text.charAt(k), 0);
/*     */         }
/*     */         
/*     */       } else {
/* 218 */         for (int k = 0; k < len; k++) {
/*     */           int val;
/* 220 */           if (Utilities.isSurrogatePair(text, k)) {
/* 221 */             int val = Utilities.convertToUtf32(text, k);
/* 222 */             k++;
/*     */           }
/*     */           else {
/* 225 */             val = text.charAt(k);
/*     */           }
/* 227 */           this.cjkTag.put(this.cjkFont.getCidCode(val), 0);
/*     */         }
/*     */       }
/* 230 */       b = this.cjkFont.convertToBytes(text);
/* 231 */       break;
/*     */     
/*     */     case 4: 
/* 234 */       b = this.baseFont.convertToBytes(text);
/* 235 */       break;
/*     */     case 3: 
/*     */       try
/*     */       {
/* 239 */         int len = text.length();
/* 240 */         int[] metrics = null;
/* 241 */         char[] glyph = new char[len];
/* 242 */         int i = 0;
/* 243 */         if (this.symbolic) {
/* 244 */           b = PdfEncodings.convertToBytes(text, "symboltt");
/* 245 */           len = b.length;
/* 246 */           for (int k = 0; k < len; k++) {
/* 247 */             metrics = this.ttu.getMetricsTT(b[k] & 0xFF);
/* 248 */             if (metrics != null)
/*     */             {
/* 250 */               this.longTag.put(Integer.valueOf(metrics[0]), new int[] { metrics[0], metrics[1], this.ttu.getUnicodeDifferences(b[k] & 0xFF) });
/* 251 */               glyph[(i++)] = ((char)metrics[0]);
/*     */             }
/* 253 */           } } else { if (canApplyGlyphSubstitution()) {
/* 254 */             return convertToBytesAfterGlyphSubstitution(text);
/*     */           }
/* 256 */           for (int k = 0; k < len; k++) {
/*     */             int val;
/* 258 */             if (Utilities.isSurrogatePair(text, k)) {
/* 259 */               int val = Utilities.convertToUtf32(text, k);
/* 260 */               k++;
/*     */             }
/*     */             else {
/* 263 */               val = text.charAt(k);
/*     */             }
/* 265 */             metrics = this.ttu.getMetricsTT(val);
/* 266 */             if (metrics != null)
/*     */             {
/* 268 */               int m0 = metrics[0];
/* 269 */               Integer gl = Integer.valueOf(m0);
/* 270 */               if (!this.longTag.containsKey(gl))
/* 271 */                 this.longTag.put(gl, new int[] { m0, metrics[1], val });
/* 272 */               glyph[(i++)] = ((char)m0);
/*     */             }
/*     */           } }
/* 275 */         glyph = Utilities.copyOfRange(glyph, 0, i);
/* 276 */         b = StringUtils.convertCharsToBytes(glyph);
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 279 */         throw new ExceptionConverter(e);
/*     */       }
/*     */     }
/*     */     
/*     */     
/* 284 */     return b;
/*     */   }
/*     */   
/*     */   private boolean canApplyGlyphSubstitution() {
/* 288 */     return (this.fontType == 3) && (this.ttu.getGlyphSubstitutionMap() != null);
/*     */   }
/*     */   
/*     */   private byte[] convertToBytesAfterGlyphSubstitution(String text) throws UnsupportedEncodingException
/*     */   {
/* 293 */     if (!canApplyGlyphSubstitution()) {
/* 294 */       throw new IllegalArgumentException("Make sure the font type if TTF Unicode and a valid GlyphSubstitutionTable exists!");
/*     */     }
/*     */     
/* 297 */     Map<String, Glyph> glyphSubstitutionMap = this.ttu.getGlyphSubstitutionMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 302 */     Set<String> compositeCharacters = new TreeSet(new IndicCompositeCharacterComparator());
/* 303 */     compositeCharacters.addAll(glyphSubstitutionMap.keySet());
/*     */     
/*     */ 
/* 306 */     ArrayBasedStringTokenizer tokenizer = new ArrayBasedStringTokenizer((String[])compositeCharacters.toArray(new String[0]));
/* 307 */     String[] tokens = tokenizer.tokenize(text);
/*     */     
/* 309 */     List<Glyph> glyphList = new ArrayList(50);
/*     */     
/* 311 */     for (String token : tokens)
/*     */     {
/*     */ 
/* 314 */       Glyph subsGlyph = (Glyph)glyphSubstitutionMap.get(token);
/*     */       
/* 316 */       if (subsGlyph != null) {
/* 317 */         glyphList.add(subsGlyph);
/*     */       }
/*     */       else {
/* 320 */         for (char c : token.toCharArray()) {
/* 321 */           int[] metrics = this.ttu.getMetricsTT(c);
/* 322 */           int glyphCode = metrics[0];
/* 323 */           int glyphWidth = metrics[1];
/* 324 */           glyphList.add(new Glyph(glyphCode, glyphWidth, String.valueOf(c)));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 330 */     GlyphRepositioner glyphRepositioner = getGlyphRepositioner();
/*     */     
/* 332 */     if (glyphRepositioner != null) {
/* 333 */       glyphRepositioner.repositionGlyphs(glyphList);
/*     */     }
/*     */     
/* 336 */     char[] charEncodedGlyphCodes = new char[glyphList.size()];
/*     */     
/*     */ 
/* 339 */     for (int i = 0; i < glyphList.size(); i++) {
/* 340 */       Glyph glyph = (Glyph)glyphList.get(i);
/* 341 */       charEncodedGlyphCodes[i] = ((char)glyph.code);
/* 342 */       Integer glyphCode = Integer.valueOf(glyph.code);
/*     */       
/* 344 */       if (!this.longTag.containsKey(glyphCode))
/*     */       {
/* 346 */         this.longTag.put(glyphCode, new int[] { glyph.code, glyph.width, glyph.chars.charAt(0) });
/*     */       }
/*     */     }
/*     */     
/* 350 */     return new String(charEncodedGlyphCodes).getBytes("UnicodeBigUnmarked");
/*     */   }
/*     */   
/*     */   private GlyphRepositioner getGlyphRepositioner() {
/* 354 */     Language language = this.ttu.getSupportedLanguage();
/*     */     
/* 356 */     if (language == null) {
/* 357 */       throw new IllegalArgumentException("The supported language field cannot be null in " + this.ttu.getClass().getName());
/*     */     }
/*     */     
/* 360 */     switch (language) {
/*     */     case BENGALI: 
/* 362 */       return new BanglaGlyphRepositioner(Collections.unmodifiableMap(this.ttu.cmap31), this.ttu.getGlyphSubstitutionMap());
/*     */     }
/* 364 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeFont(PdfWriter writer)
/*     */   {
/*     */     try
/*     */     {
/* 374 */       switch (this.fontType) {
/*     */       case 5: 
/* 376 */         this.baseFont.writeFont(writer, this.indirectReference, null);
/* 377 */         break;
/*     */       
/*     */ 
/*     */       case 0: 
/*     */       case 1: 
/* 382 */         for (int firstChar = 0; firstChar < 256; firstChar++) {
/* 383 */           if (this.shortTag[firstChar] != 0)
/*     */             break;
/*     */         }
/* 386 */         for (int lastChar = 255; lastChar >= firstChar; lastChar--) {
/* 387 */           if (this.shortTag[lastChar] != 0)
/*     */             break;
/*     */         }
/* 390 */         if (firstChar > 255) {
/* 391 */           firstChar = 255;
/* 392 */           lastChar = 255;
/*     */         }
/* 394 */         this.baseFont.writeFont(writer, this.indirectReference, new Object[] { Integer.valueOf(firstChar), Integer.valueOf(lastChar), this.shortTag, Boolean.valueOf(this.subset) });
/* 395 */         break;
/*     */       
/*     */       case 2: 
/* 398 */         this.baseFont.writeFont(writer, this.indirectReference, new Object[] { this.cjkTag });
/* 399 */         break;
/*     */       case 3: 
/* 401 */         this.baseFont.writeFont(writer, this.indirectReference, new Object[] { this.longTag, Boolean.valueOf(this.subset) });
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 406 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSubset()
/*     */   {
/* 416 */     return this.subset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubset(boolean subset)
/*     */   {
/* 426 */     this.subset = subset;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/FontDetails.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */