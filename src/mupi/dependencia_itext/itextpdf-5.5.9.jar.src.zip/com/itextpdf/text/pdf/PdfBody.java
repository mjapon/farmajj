/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import com.itextpdf.text.Chunk;
/*    */ import com.itextpdf.text.Element;
/*    */ import com.itextpdf.text.ElementListener;
/*    */ import com.itextpdf.text.Rectangle;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfBody
/*    */   extends Rectangle
/*    */   implements Element
/*    */ {
/*    */   public PdfBody(Rectangle rectangle)
/*    */   {
/* 57 */     super(rectangle);
/*    */   }
/*    */   
/*    */   public boolean process(ElementListener listener) {
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   public int type() {
/* 65 */     return 38;
/*    */   }
/*    */   
/*    */   public boolean isContent() {
/* 69 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isNestable() {
/* 73 */     return false;
/*    */   }
/*    */   
/*    */   public List<Chunk> getChunks() {
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfBody.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */