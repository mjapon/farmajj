/*    */ package com.itextpdf.text.pdf.parser.clipper;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolyTree
/*    */   extends PolyNode
/*    */ {
/* 51 */   private final List<PolyNode> allPolys = new ArrayList();
/*    */   
/*    */   public void Clear() {
/* 54 */     this.allPolys.clear();
/* 55 */     this.childs.clear();
/*    */   }
/*    */   
/*    */   public List<PolyNode> getAllPolys() {
/* 59 */     return this.allPolys;
/*    */   }
/*    */   
/*    */   public PolyNode getFirst() {
/* 63 */     if (!this.childs.isEmpty()) {
/* 64 */       return (PolyNode)this.childs.get(0);
/*    */     }
/*    */     
/* 67 */     return null;
/*    */   }
/*    */   
/*    */   public int getTotalSize()
/*    */   {
/* 72 */     int result = this.allPolys.size();
/*    */     
/* 74 */     if ((result > 0) && (this.childs.get(0) != this.allPolys.get(0))) {
/* 75 */       result--;
/*    */     }
/* 77 */     return result;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/PolyTree.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */