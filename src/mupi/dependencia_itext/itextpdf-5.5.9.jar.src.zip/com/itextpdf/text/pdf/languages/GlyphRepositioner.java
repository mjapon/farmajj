package com.itextpdf.text.pdf.languages;

import com.itextpdf.text.pdf.Glyph;
import java.util.List;

public abstract interface GlyphRepositioner
{
  public abstract void repositionGlyphs(List<Glyph> paramList);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/languages/GlyphRepositioner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */