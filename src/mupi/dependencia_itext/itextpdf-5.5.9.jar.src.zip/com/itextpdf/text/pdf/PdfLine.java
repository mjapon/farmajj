/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.Chunk;
/*     */ import com.itextpdf.text.Image;
/*     */ import com.itextpdf.text.ListItem;
/*     */ import com.itextpdf.text.TabStop;
/*     */ import com.itextpdf.text.TabStop.Alignment;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfLine
/*     */ {
/*     */   protected ArrayList<PdfChunk> line;
/*     */   protected float left;
/*     */   protected float width;
/*     */   protected int alignment;
/*     */   protected float height;
/*  83 */   protected boolean newlineSplit = false;
/*     */   
/*     */ 
/*     */   protected float originalWidth;
/*     */   
/*  88 */   protected boolean isRTL = false;
/*     */   
/*  90 */   protected ListItem listItem = null;
/*     */   
/*  92 */   protected TabStop tabStop = null;
/*     */   
/*  94 */   protected float tabStopAnchorPosition = NaN.0F;
/*     */   
/*  96 */   protected float tabPosition = NaN.0F;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfLine(float left, float right, int alignment, float height)
/*     */   {
/* 110 */     this.left = left;
/* 111 */     this.width = (right - left);
/* 112 */     this.originalWidth = this.width;
/* 113 */     this.alignment = alignment;
/* 114 */     this.height = height;
/* 115 */     this.line = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfLine(float left, float originalWidth, float remainingWidth, int alignment, boolean newlineSplit, ArrayList<PdfChunk> line, boolean isRTL)
/*     */   {
/* 129 */     this.left = left;
/* 130 */     this.originalWidth = originalWidth;
/* 131 */     this.width = remainingWidth;
/* 132 */     this.alignment = alignment;
/* 133 */     this.line = line;
/* 134 */     this.newlineSplit = newlineSplit;
/* 135 */     this.isRTL = isRTL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfChunk add(PdfChunk chunk, float currentLeading)
/*     */   {
/* 152 */     if ((chunk != null) && (!chunk.toString().equals("")))
/*     */     {
/* 154 */       if ((!chunk.toString().equals(" ")) && (
/* 155 */         (this.height < currentLeading) || (this.line.isEmpty()))) {
/* 156 */         this.height = currentLeading;
/*     */       }
/*     */     }
/* 159 */     return add(chunk);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfChunk add(PdfChunk chunk)
/*     */   {
/* 173 */     if ((chunk == null) || (chunk.toString().equals(""))) {
/* 174 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 178 */     PdfChunk overflow = chunk.split(this.width);
/* 179 */     this.newlineSplit = ((chunk.isNewlineSplit()) || (overflow == null));
/* 180 */     if (chunk.isTab()) {
/* 181 */       Object[] tab = (Object[])chunk.getAttribute("TAB");
/* 182 */       if (chunk.isAttribute("TABSETTINGS")) {
/* 183 */         boolean isWhiteSpace = ((Boolean)tab[1]).booleanValue();
/* 184 */         if ((!isWhiteSpace) || (!this.line.isEmpty())) {
/* 185 */           flush();
/* 186 */           this.tabStopAnchorPosition = NaN.0F;
/* 187 */           this.tabStop = PdfChunk.getTabStop(chunk, this.originalWidth - this.width);
/* 188 */           if (this.tabStop.getPosition() > this.originalWidth) {
/* 189 */             if (isWhiteSpace) {
/* 190 */               overflow = null;
/* 191 */             } else if (Math.abs(this.originalWidth - this.width) < 0.001D) {
/* 192 */               addToLine(chunk);
/* 193 */               overflow = null;
/*     */             } else {
/* 195 */               overflow = chunk;
/*     */             }
/* 197 */             this.width = 0.0F;
/*     */           } else {
/* 199 */             chunk.setTabStop(this.tabStop);
/* 200 */             if ((!this.isRTL) && (this.tabStop.getAlignment() == TabStop.Alignment.LEFT)) {
/* 201 */               this.width = (this.originalWidth - this.tabStop.getPosition());
/* 202 */               this.tabStop = null;
/* 203 */               this.tabPosition = NaN.0F;
/*     */             } else {
/* 205 */               this.tabPosition = (this.originalWidth - this.width); }
/* 206 */             addToLine(chunk);
/*     */           }
/*     */         } else {
/* 209 */           return null;
/*     */         }
/*     */       } else {
/* 212 */         Float tabStopPosition = Float.valueOf(((Float)tab[1]).floatValue());
/* 213 */         boolean newline = ((Boolean)tab[2]).booleanValue();
/* 214 */         if ((newline) && (tabStopPosition.floatValue() < this.originalWidth - this.width)) {
/* 215 */           return chunk;
/*     */         }
/* 217 */         chunk.adjustLeft(this.left);
/* 218 */         this.width = (this.originalWidth - tabStopPosition.floatValue());
/* 219 */         addToLine(chunk);
/*     */       }
/*     */       
/*     */     }
/* 223 */     else if ((chunk.length() > 0) || (chunk.isImage())) {
/* 224 */       if (overflow != null)
/* 225 */         chunk.trimLastSpace();
/* 226 */       this.width -= chunk.width();
/* 227 */       addToLine(chunk);
/*     */     }
/*     */     else
/*     */     {
/* 231 */       if (this.line.size() < 1) {
/* 232 */         chunk = overflow;
/* 233 */         overflow = chunk.truncate(this.width);
/* 234 */         this.width -= chunk.width();
/* 235 */         if (chunk.length() > 0) {
/* 236 */           addToLine(chunk);
/* 237 */           return overflow;
/*     */         }
/*     */         
/*     */ 
/* 241 */         if (overflow != null)
/* 242 */           addToLine(overflow);
/* 243 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 247 */       this.width += ((PdfChunk)this.line.get(this.line.size() - 1)).trimLastSpace();
/*     */     }
/* 249 */     return overflow;
/*     */   }
/*     */   
/*     */   private void addToLine(PdfChunk chunk) {
/* 253 */     if (chunk.changeLeading) { float f;
/*     */       float f;
/* 255 */       if (chunk.isImage()) {
/* 256 */         Image img = chunk.getImage();
/*     */         
/* 258 */         f = chunk.getImageHeight() + chunk.getImageOffsetY() + img.getBorderWidthTop() + img.getSpacingBefore();
/*     */       }
/*     */       else {
/* 261 */         f = chunk.getLeading();
/*     */       }
/* 263 */       if (f > this.height) this.height = f;
/*     */     }
/* 265 */     if ((this.tabStop != null) && (this.tabStop.getAlignment() == TabStop.Alignment.ANCHOR) && (Float.isNaN(this.tabStopAnchorPosition))) {
/* 266 */       String value = chunk.toString();
/* 267 */       int anchorIndex = value.indexOf(this.tabStop.getAnchorChar());
/* 268 */       if (anchorIndex != -1) {
/* 269 */         float subWidth = chunk.width(value.substring(anchorIndex, value.length()));
/* 270 */         this.tabStopAnchorPosition = (this.originalWidth - this.width - subWidth);
/*     */       }
/*     */     }
/* 273 */     this.line.add(chunk);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 285 */     return this.line.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<PdfChunk> iterator()
/*     */   {
/* 295 */     return this.line.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float height()
/*     */   {
/* 305 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float indentLeft()
/*     */   {
/* 315 */     if (this.isRTL) {
/* 316 */       switch (this.alignment) {
/*     */       case 1: 
/* 318 */         return this.left + this.width / 2.0F;
/*     */       case 2: 
/* 320 */         return this.left;
/*     */       case 3: 
/* 322 */         return this.left + (hasToBeJustified() ? 0.0F : this.width);
/*     */       }
/*     */       
/* 325 */       return this.left + this.width;
/*     */     }
/* 327 */     if (getSeparatorCount() <= 0) {
/* 328 */       switch (this.alignment) {
/*     */       case 2: 
/* 330 */         return this.left + this.width;
/*     */       case 1: 
/* 332 */         return this.left + this.width / 2.0F;
/*     */       }
/*     */     }
/* 335 */     return this.left;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasToBeJustified()
/*     */   {
/* 345 */     return ((this.alignment == 3) && (!this.newlineSplit)) || ((this.alignment == 8) && (this.width != 0.0F));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetAlignment()
/*     */   {
/* 356 */     if (this.alignment == 3) {
/* 357 */       this.alignment = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   void setExtraIndent(float extra)
/*     */   {
/* 363 */     this.left += extra;
/* 364 */     this.width -= extra;
/* 365 */     this.originalWidth -= extra;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float widthLeft()
/*     */   {
/* 375 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int numberOfSpaces()
/*     */   {
/* 385 */     int numberOfSpaces = 0;
/* 386 */     for (PdfChunk pdfChunk : this.line) {
/* 387 */       String tmp = pdfChunk.toString();
/* 388 */       int length = tmp.length();
/* 389 */       for (int i = 0; i < length; i++) {
/* 390 */         if (tmp.charAt(i) == ' ') {
/* 391 */           numberOfSpaces++;
/*     */         }
/*     */       }
/*     */     }
/* 395 */     return numberOfSpaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setListItem(ListItem listItem)
/*     */   {
/* 407 */     this.listItem = listItem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Chunk listSymbol()
/*     */   {
/* 419 */     return this.listItem != null ? this.listItem.getListSymbol() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float listIndent()
/*     */   {
/* 429 */     return this.listItem != null ? this.listItem.getIndentationLeft() : 0.0F;
/*     */   }
/*     */   
/*     */   public ListItem listItem() {
/* 433 */     return this.listItem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 444 */     StringBuffer tmp = new StringBuffer();
/* 445 */     for (PdfChunk pdfChunk : this.line) {
/* 446 */       tmp.append(pdfChunk.toString());
/*     */     }
/* 448 */     return tmp.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineLengthUtf32()
/*     */   {
/* 457 */     int total = 0;
/* 458 */     for (Object element : this.line) {
/* 459 */       total += ((PdfChunk)element).lengthUtf32();
/*     */     }
/* 461 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNewlineSplit()
/*     */   {
/* 469 */     return (this.newlineSplit) && (this.alignment != 8);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastStrokeChunk()
/*     */   {
/* 477 */     for (int lastIdx = this.line.size() - 1; 
/* 478 */         lastIdx >= 0; lastIdx--) {
/* 479 */       PdfChunk chunk = (PdfChunk)this.line.get(lastIdx);
/* 480 */       if (chunk.isStroked())
/*     */         break;
/*     */     }
/* 483 */     return lastIdx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfChunk getChunk(int idx)
/*     */   {
/* 492 */     if ((idx < 0) || (idx >= this.line.size()))
/* 493 */       return null;
/* 494 */     return (PdfChunk)this.line.get(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getOriginalWidth()
/*     */   {
/* 502 */     return this.originalWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   float[] getMaxSize(float fixedLeading, float multipliedLeading)
/*     */   {
/* 532 */     float normal_leading = 0.0F;
/* 533 */     float image_leading = -10000.0F;
/*     */     
/* 535 */     for (int k = 0; k < this.line.size(); k++) {
/* 536 */       PdfChunk chunk = (PdfChunk)this.line.get(k);
/* 537 */       if (chunk.isImage()) {
/* 538 */         Image img = chunk.getImage();
/* 539 */         if (chunk.changeLeading()) {
/* 540 */           float height = chunk.getImageHeight() + chunk.getImageOffsetY() + img.getSpacingBefore();
/* 541 */           image_leading = Math.max(height, image_leading);
/*     */         }
/*     */       }
/* 544 */       else if (chunk.changeLeading()) {
/* 545 */         normal_leading = Math.max(chunk.getLeading(), normal_leading);
/*     */       } else {
/* 547 */         normal_leading = Math.max(fixedLeading + multipliedLeading * chunk.font().size(), normal_leading);
/*     */       }
/*     */     }
/* 550 */     return new float[] { normal_leading > 0.0F ? normal_leading : fixedLeading, image_leading };
/*     */   }
/*     */   
/*     */   boolean isRTL() {
/* 554 */     return this.isRTL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getSeparatorCount()
/*     */   {
/* 564 */     int s = 0;
/*     */     
/* 566 */     for (Object element : this.line) {
/* 567 */       PdfChunk ck = (PdfChunk)element;
/* 568 */       if (ck.isTab()) {
/* 569 */         if (!ck.isAttribute("TABSETTINGS"))
/*     */         {
/*     */ 
/* 572 */           return -1;
/*     */         }
/* 574 */       } else if (ck.isHorizontalSeparator()) {
/* 575 */         s++;
/*     */       }
/*     */     }
/* 578 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getWidthCorrected(float charSpacing, float wordSpacing)
/*     */   {
/* 588 */     float total = 0.0F;
/* 589 */     for (int k = 0; k < this.line.size(); k++) {
/* 590 */       PdfChunk ck = (PdfChunk)this.line.get(k);
/* 591 */       total += ck.getWidthCorrected(charSpacing, wordSpacing);
/*     */     }
/* 593 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getAscender()
/*     */   {
/* 602 */     float ascender = 0.0F;
/* 603 */     for (int k = 0; k < this.line.size(); k++) {
/* 604 */       PdfChunk ck = (PdfChunk)this.line.get(k);
/* 605 */       if (ck.isImage()) {
/* 606 */         ascender = Math.max(ascender, ck.getImageHeight() + ck.getImageOffsetY());
/*     */       } else {
/* 608 */         PdfFont font = ck.font();
/* 609 */         float textRise = ck.getTextRise();
/* 610 */         ascender = Math.max(ascender, (textRise > 0.0F ? textRise : 0.0F) + font.getFont().getFontDescriptor(1, font.size()));
/*     */       }
/*     */     }
/* 613 */     return ascender;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getDescender()
/*     */   {
/* 622 */     float descender = 0.0F;
/* 623 */     for (int k = 0; k < this.line.size(); k++) {
/* 624 */       PdfChunk ck = (PdfChunk)this.line.get(k);
/* 625 */       if (ck.isImage()) {
/* 626 */         descender = Math.min(descender, ck.getImageOffsetY());
/*     */       } else {
/* 628 */         PdfFont font = ck.font();
/* 629 */         float textRise = ck.getTextRise();
/* 630 */         descender = Math.min(descender, (textRise < 0.0F ? textRise : 0.0F) + font.getFont().getFontDescriptor(3, font.size()));
/*     */       }
/*     */     }
/* 633 */     return descender;
/*     */   }
/*     */   
/*     */   public void flush() {
/* 637 */     if (this.tabStop != null) {
/* 638 */       float textWidth = this.originalWidth - this.width - this.tabPosition;
/* 639 */       float tabStopPosition = this.tabStop.getPosition(this.tabPosition, this.originalWidth - this.width, this.tabStopAnchorPosition);
/* 640 */       this.width = (this.originalWidth - tabStopPosition - textWidth);
/* 641 */       if (this.width < 0.0F)
/* 642 */         tabStopPosition += this.width;
/* 643 */       if (!this.isRTL) {
/* 644 */         this.tabStop.setPosition(tabStopPosition);
/*     */       } else
/* 646 */         this.tabStop.setPosition(this.originalWidth - this.width - this.tabPosition);
/* 647 */       this.tabStop = null;
/* 648 */       this.tabPosition = NaN.0F;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */