/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CFFFontSubset
/*      */   extends CFFFont
/*      */ {
/*   69 */   static final String[] SubrsFunctions = { "RESERVED_0", "hstem", "RESERVED_2", "vstem", "vmoveto", "rlineto", "hlineto", "vlineto", "rrcurveto", "RESERVED_9", "callsubr", "return", "escape", "RESERVED_13", "endchar", "RESERVED_15", "RESERVED_16", "RESERVED_17", "hstemhm", "hintmask", "cntrmask", "rmoveto", "hmoveto", "vstemhm", "rcurveline", "rlinecurve", "vvcurveto", "hhcurveto", "shortint", "callgsubr", "vhcurveto", "hvcurveto" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   79 */   static final String[] SubrsEscapeFuncs = { "RESERVED_0", "RESERVED_1", "RESERVED_2", "and", "or", "not", "RESERVED_6", "RESERVED_7", "RESERVED_8", "abs", "add", "sub", "div", "RESERVED_13", "neg", "eq", "RESERVED_16", "RESERVED_17", "drop", "RESERVED_19", "put", "get", "ifelse", "random", "mul", "RESERVED_25", "sqrt", "dup", "exch", "index", "roll", "RESERVED_31", "RESERVED_32", "RESERVED_33", "hflex", "flex", "hflex1", "flex1", "RESERVED_REST" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte ENDCHAR_OP = 14;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte RETURN_OP = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap<Integer, int[]> GlyphsUsed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   ArrayList<Integer> glyphsInList;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  105 */   HashSet<Integer> FDArrayUsed = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */   HashMap<Integer, int[]>[] hSubrsUsed;
/*      */   
/*      */ 
/*      */ 
/*      */   ArrayList<Integer>[] lSubrsUsed;
/*      */   
/*      */ 
/*      */ 
/*  117 */   HashMap<Integer, int[]> hGSubrsUsed = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*  121 */   ArrayList<Integer> lGSubrsUsed = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*  125 */   HashMap<Integer, int[]> hSubrsUsedNonCID = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*  129 */   ArrayList<Integer> lSubrsUsedNonCID = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[][] NewLSubrsIndex;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] NewSubrsIndexNonCID;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] NewGSubrsIndex;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] NewCharStringsIndex;
/*      */   
/*      */ 
/*      */ 
/*  150 */   int GBias = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   LinkedList<CFFFont.Item> OutputList;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  160 */   int NumOfHints = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CFFFontSubset(RandomAccessFileOrArray rf, HashMap<Integer, int[]> GlyphsUsed)
/*      */   {
/*  170 */     super(rf);
/*  171 */     this.GlyphsUsed = GlyphsUsed;
/*      */     
/*  173 */     this.glyphsInList = new ArrayList(GlyphsUsed.keySet());
/*      */     
/*      */ 
/*  176 */     for (int i = 0; i < this.fonts.length; i++)
/*      */     {
/*      */ 
/*  179 */       seek(this.fonts[i].charstringsOffset);
/*  180 */       this.fonts[i].nglyphs = getCard16();
/*      */       
/*      */ 
/*  183 */       seek(this.stringIndexOffset);
/*  184 */       this.fonts[i].nstrings = (getCard16() + standardStrings.length);
/*      */       
/*      */ 
/*  187 */       this.fonts[i].charstringsOffsets = getIndex(this.fonts[i].charstringsOffset);
/*      */       
/*      */ 
/*  190 */       if (this.fonts[i].fdselectOffset >= 0)
/*      */       {
/*      */ 
/*  193 */         readFDSelect(i);
/*      */         
/*  195 */         BuildFDArrayUsed(i);
/*      */       }
/*  197 */       if (this.fonts[i].isCID)
/*      */       {
/*  199 */         ReadFDArray(i);
/*      */       }
/*  201 */       this.fonts[i].CharsetLength = CountCharset(this.fonts[i].charsetOffset, this.fonts[i].nglyphs);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int CountCharset(int Offset, int NumofGlyphs)
/*      */   {
/*  213 */     int Length = 0;
/*  214 */     seek(Offset);
/*      */     
/*  216 */     int format = getCard8();
/*      */     
/*  218 */     switch (format) {
/*      */     case 0: 
/*  220 */       Length = 1 + 2 * NumofGlyphs;
/*  221 */       break;
/*      */     case 1: 
/*  223 */       Length = 1 + 3 * CountRange(NumofGlyphs, 1);
/*  224 */       break;
/*      */     case 2: 
/*  226 */       Length = 1 + 4 * CountRange(NumofGlyphs, 2);
/*  227 */       break;
/*      */     }
/*      */     
/*      */     
/*  231 */     return Length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int CountRange(int NumofGlyphs, int Type)
/*      */   {
/*  241 */     int num = 0;
/*      */     
/*  243 */     int i = 1;
/*  244 */     while (i < NumofGlyphs) {
/*  245 */       num++;
/*  246 */       char Sid = getCard16();
/*  247 */       int nLeft; int nLeft; if (Type == 1) {
/*  248 */         nLeft = getCard8();
/*      */       } else
/*  250 */         nLeft = getCard16();
/*  251 */       i += nLeft + 1;
/*      */     }
/*  253 */     return num;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readFDSelect(int Font)
/*      */   {
/*  264 */     int NumOfGlyphs = this.fonts[Font].nglyphs;
/*  265 */     int[] FDSelect = new int[NumOfGlyphs];
/*      */     
/*  267 */     seek(this.fonts[Font].fdselectOffset);
/*      */     
/*  269 */     this.fonts[Font].FDSelectFormat = getCard8();
/*      */     
/*  271 */     switch (this.fonts[Font].FDSelectFormat)
/*      */     {
/*      */ 
/*      */     case 0: 
/*  275 */       for (int i = 0; i < NumOfGlyphs; i++)
/*      */       {
/*  277 */         FDSelect[i] = getCard8();
/*      */       }
/*      */       
/*      */ 
/*  281 */       this.fonts[Font].FDSelectLength = (this.fonts[Font].nglyphs + 1);
/*  282 */       break;
/*      */     
/*      */ 
/*      */     case 3: 
/*  286 */       int nRanges = getCard16();
/*  287 */       int l = 0;
/*      */       
/*  289 */       int first = getCard16();
/*  290 */       for (int i = 0; i < nRanges; i++)
/*      */       {
/*      */ 
/*  293 */         int fd = getCard8();
/*      */         
/*  295 */         int last = getCard16();
/*      */         
/*  297 */         int steps = last - first;
/*  298 */         for (int k = 0; k < steps; k++)
/*      */         {
/*  300 */           FDSelect[l] = fd;
/*  301 */           l++;
/*      */         }
/*      */         
/*  304 */         first = last;
/*      */       }
/*      */       
/*  307 */       this.fonts[Font].FDSelectLength = (3 + nRanges * 3 + 2);
/*  308 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  313 */     this.fonts[Font].FDSelect = FDSelect;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildFDArrayUsed(int Font)
/*      */   {
/*  322 */     int[] FDSelect = this.fonts[Font].FDSelect;
/*      */     
/*  324 */     for (int i = 0; i < this.glyphsInList.size(); i++)
/*      */     {
/*      */ 
/*  327 */       int glyph = ((Integer)this.glyphsInList.get(i)).intValue();
/*      */       
/*  329 */       int FD = FDSelect[glyph];
/*      */       
/*  331 */       this.FDArrayUsed.add(Integer.valueOf(FD));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void ReadFDArray(int Font)
/*      */   {
/*  341 */     seek(this.fonts[Font].fdarrayOffset);
/*  342 */     this.fonts[Font].FDArrayCount = getCard16();
/*  343 */     this.fonts[Font].FDArrayOffsize = getCard8();
/*      */     
/*      */ 
/*  346 */     if (this.fonts[Font].FDArrayOffsize < 4)
/*  347 */       this.fonts[Font].FDArrayOffsize += 1;
/*  348 */     this.fonts[Font].FDArrayOffsets = getIndex(this.fonts[Font].fdarrayOffset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] Process(String fontName)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  363 */       this.buf.reOpen();
/*      */       
/*      */ 
/*  366 */       for (int j = 0; j < this.fonts.length; j++)
/*  367 */         if (fontName.equals(this.fonts[j].name)) break;
/*  368 */       if (j == this.fonts.length) { return null;
/*      */       }
/*      */       
/*  371 */       if (this.gsubrIndexOffset >= 0) {
/*  372 */         this.GBias = CalcBias(this.gsubrIndexOffset, j);
/*      */       }
/*      */       
/*  375 */       BuildNewCharString(j);
/*      */       
/*  377 */       BuildNewLGSubrs(j);
/*      */       
/*  379 */       byte[] Ret = BuildNewFile(j);
/*  380 */       return Ret;
/*      */     }
/*      */     finally {
/*      */       try {
/*  384 */         this.buf.close();
/*      */       }
/*      */       catch (Exception localException2) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int CalcBias(int Offset, int Font)
/*      */   {
/*  401 */     seek(Offset);
/*  402 */     int nSubrs = getCard16();
/*      */     
/*  404 */     if (this.fonts[Font].CharstringType == 1) {
/*  405 */       return 0;
/*      */     }
/*  407 */     if (nSubrs < 1240)
/*  408 */       return 107;
/*  409 */     if (nSubrs < 33900) {
/*  410 */       return 1131;
/*      */     }
/*  412 */     return 32768;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildNewCharString(int FontIndex)
/*      */     throws IOException
/*      */   {
/*  422 */     this.NewCharStringsIndex = BuildNewIndex(this.fonts[FontIndex].charstringsOffsets, this.GlyphsUsed, (byte)14);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildNewLGSubrs(int Font)
/*      */     throws IOException
/*      */   {
/*  436 */     if (this.fonts[Font].isCID)
/*      */     {
/*      */ 
/*      */ 
/*  440 */       this.hSubrsUsed = new HashMap[this.fonts[Font].fdprivateOffsets.length];
/*  441 */       this.lSubrsUsed = new ArrayList[this.fonts[Font].fdprivateOffsets.length];
/*      */       
/*  443 */       this.NewLSubrsIndex = new byte[this.fonts[Font].fdprivateOffsets.length][];
/*      */       
/*  445 */       this.fonts[Font].PrivateSubrsOffset = new int[this.fonts[Font].fdprivateOffsets.length];
/*      */       
/*  447 */       this.fonts[Font].PrivateSubrsOffsetsArray = new int[this.fonts[Font].fdprivateOffsets.length][];
/*      */       
/*      */ 
/*  450 */       ArrayList<Integer> FDInList = new ArrayList(this.FDArrayUsed);
/*      */       
/*  452 */       for (int j = 0; j < FDInList.size(); j++)
/*      */       {
/*      */ 
/*  455 */         int FD = ((Integer)FDInList.get(j)).intValue();
/*  456 */         this.hSubrsUsed[FD] = new HashMap();
/*  457 */         this.lSubrsUsed[FD] = new ArrayList();
/*      */         
/*      */ 
/*  460 */         BuildFDSubrsOffsets(Font, FD);
/*      */         
/*  462 */         if (this.fonts[Font].PrivateSubrsOffset[FD] >= 0)
/*      */         {
/*      */ 
/*      */ 
/*  466 */           BuildSubrUsed(Font, FD, this.fonts[Font].PrivateSubrsOffset[FD], this.fonts[Font].PrivateSubrsOffsetsArray[FD], this.hSubrsUsed[FD], this.lSubrsUsed[FD]);
/*      */           
/*  468 */           this.NewLSubrsIndex[FD] = BuildNewIndex(this.fonts[Font].PrivateSubrsOffsetsArray[FD], this.hSubrsUsed[FD], 11);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*  473 */     else if (this.fonts[Font].privateSubrs >= 0)
/*      */     {
/*      */ 
/*  476 */       this.fonts[Font].SubrsOffsets = getIndex(this.fonts[Font].privateSubrs);
/*      */       
/*      */ 
/*  479 */       BuildSubrUsed(Font, -1, this.fonts[Font].privateSubrs, this.fonts[Font].SubrsOffsets, this.hSubrsUsedNonCID, this.lSubrsUsedNonCID);
/*      */     }
/*      */     
/*      */ 
/*  483 */     BuildGSubrsUsed(Font);
/*  484 */     if (this.fonts[Font].privateSubrs >= 0)
/*      */     {
/*  486 */       this.NewSubrsIndexNonCID = BuildNewIndex(this.fonts[Font].SubrsOffsets, this.hSubrsUsedNonCID, (byte)11);
/*      */     }
/*  488 */     this.NewGSubrsIndex = BuildNewIndex(this.gsubrOffsets, this.hGSubrsUsed, (byte)11);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildFDSubrsOffsets(int Font, int FD)
/*      */   {
/*  500 */     this.fonts[Font].PrivateSubrsOffset[FD] = -1;
/*      */     
/*  502 */     seek(this.fonts[Font].fdprivateOffsets[FD]);
/*      */     
/*  504 */     while (getPosition() < this.fonts[Font].fdprivateOffsets[FD] + this.fonts[Font].fdprivateLengths[FD])
/*      */     {
/*  506 */       getDictItem();
/*      */       
/*  508 */       if (this.key == "Subrs") {
/*  509 */         this.fonts[Font].PrivateSubrsOffset[FD] = (((Integer)this.args[0]).intValue() + this.fonts[Font].fdprivateOffsets[FD]);
/*      */       }
/*      */     }
/*  512 */     if (this.fonts[Font].PrivateSubrsOffset[FD] >= 0) {
/*  513 */       this.fonts[Font].PrivateSubrsOffsetsArray[FD] = getIndex(this.fonts[Font].PrivateSubrsOffset[FD]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildSubrUsed(int Font, int FD, int SubrOffset, int[] SubrsOffsets, HashMap<Integer, int[]> hSubr, ArrayList<Integer> lSubr)
/*      */   {
/*  531 */     int LBias = CalcBias(SubrOffset, Font);
/*      */     
/*      */ 
/*  534 */     for (int i = 0; i < this.glyphsInList.size(); i++)
/*      */     {
/*  536 */       int glyph = ((Integer)this.glyphsInList.get(i)).intValue();
/*  537 */       int Start = this.fonts[Font].charstringsOffsets[glyph];
/*  538 */       int End = this.fonts[Font].charstringsOffsets[(glyph + 1)];
/*      */       
/*      */ 
/*  541 */       if (FD >= 0)
/*      */       {
/*  543 */         EmptyStack();
/*  544 */         this.NumOfHints = 0;
/*      */         
/*  546 */         int GlyphFD = this.fonts[Font].FDSelect[glyph];
/*      */         
/*  548 */         if (GlyphFD == FD)
/*      */         {
/*  550 */           ReadASubr(Start, End, this.GBias, LBias, hSubr, lSubr, SubrsOffsets);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  555 */         ReadASubr(Start, End, this.GBias, LBias, hSubr, lSubr, SubrsOffsets);
/*      */       }
/*      */     }
/*  558 */     for (int i = 0; i < lSubr.size(); i++)
/*      */     {
/*      */ 
/*  561 */       int Subr = ((Integer)lSubr.get(i)).intValue();
/*      */       
/*  563 */       if ((Subr < SubrsOffsets.length - 1) && (Subr >= 0))
/*      */       {
/*      */ 
/*  566 */         int Start = SubrsOffsets[Subr];
/*  567 */         int End = SubrsOffsets[(Subr + 1)];
/*  568 */         ReadASubr(Start, End, this.GBias, LBias, hSubr, lSubr, SubrsOffsets);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildGSubrsUsed(int Font)
/*      */   {
/*  580 */     int LBias = 0;
/*  581 */     int SizeOfNonCIDSubrsUsed = 0;
/*  582 */     if (this.fonts[Font].privateSubrs >= 0)
/*      */     {
/*  584 */       LBias = CalcBias(this.fonts[Font].privateSubrs, Font);
/*  585 */       SizeOfNonCIDSubrsUsed = this.lSubrsUsedNonCID.size();
/*      */     }
/*      */     
/*      */ 
/*  589 */     for (int i = 0; i < this.lGSubrsUsed.size(); i++)
/*      */     {
/*      */ 
/*  592 */       int Subr = ((Integer)this.lGSubrsUsed.get(i)).intValue();
/*  593 */       if ((Subr < this.gsubrOffsets.length - 1) && (Subr >= 0))
/*      */       {
/*      */ 
/*  596 */         int Start = this.gsubrOffsets[Subr];
/*  597 */         int End = this.gsubrOffsets[(Subr + 1)];
/*      */         
/*  599 */         if (this.fonts[Font].isCID) {
/*  600 */           ReadASubr(Start, End, this.GBias, 0, this.hGSubrsUsed, this.lGSubrsUsed, null);
/*      */         }
/*      */         else {
/*  603 */           ReadASubr(Start, End, this.GBias, LBias, this.hSubrsUsedNonCID, this.lSubrsUsedNonCID, this.fonts[Font].SubrsOffsets);
/*  604 */           if (SizeOfNonCIDSubrsUsed < this.lSubrsUsedNonCID.size())
/*      */           {
/*  606 */             for (int j = SizeOfNonCIDSubrsUsed; j < this.lSubrsUsedNonCID.size(); j++)
/*      */             {
/*      */ 
/*  609 */               int LSubr = ((Integer)this.lSubrsUsedNonCID.get(j)).intValue();
/*  610 */               if ((LSubr < this.fonts[Font].SubrsOffsets.length - 1) && (LSubr >= 0))
/*      */               {
/*      */ 
/*  613 */                 int LStart = this.fonts[Font].SubrsOffsets[LSubr];
/*  614 */                 int LEnd = this.fonts[Font].SubrsOffsets[(LSubr + 1)];
/*  615 */                 ReadASubr(LStart, LEnd, this.GBias, LBias, this.hSubrsUsedNonCID, this.lSubrsUsedNonCID, this.fonts[Font].SubrsOffsets);
/*      */               }
/*      */             }
/*  618 */             SizeOfNonCIDSubrsUsed = this.lSubrsUsedNonCID.size();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void ReadASubr(int begin, int end, int GBias, int LBias, HashMap<Integer, int[]> hSubr, ArrayList<Integer> lSubr, int[] LSubrsOffsets)
/*      */   {
/*  639 */     EmptyStack();
/*  640 */     this.NumOfHints = 0;
/*      */     
/*  642 */     seek(begin);
/*  643 */     while (getPosition() < end)
/*      */     {
/*      */ 
/*  646 */       ReadCommand();
/*  647 */       int pos = getPosition();
/*  648 */       Object TopElement = null;
/*  649 */       if (this.arg_count > 0)
/*  650 */         TopElement = this.args[(this.arg_count - 1)];
/*  651 */       int NumOfArgs = this.arg_count;
/*      */       
/*  653 */       HandelStack();
/*      */       
/*  655 */       if (this.key == "callsubr")
/*      */       {
/*      */ 
/*  658 */         if (NumOfArgs > 0)
/*      */         {
/*      */ 
/*  661 */           int Subr = ((Integer)TopElement).intValue() + LBias;
/*      */           
/*  663 */           if (!hSubr.containsKey(Integer.valueOf(Subr)))
/*      */           {
/*  665 */             hSubr.put(Integer.valueOf(Subr), null);
/*  666 */             lSubr.add(Integer.valueOf(Subr));
/*      */           }
/*  668 */           CalcHints(LSubrsOffsets[Subr], LSubrsOffsets[(Subr + 1)], LBias, GBias, LSubrsOffsets);
/*  669 */           seek(pos);
/*      */         }
/*      */         
/*      */       }
/*  673 */       else if (this.key == "callgsubr")
/*      */       {
/*      */ 
/*  676 */         if (NumOfArgs > 0)
/*      */         {
/*      */ 
/*  679 */           int Subr = ((Integer)TopElement).intValue() + GBias;
/*      */           
/*  681 */           if (!this.hGSubrsUsed.containsKey(Integer.valueOf(Subr)))
/*      */           {
/*  683 */             this.hGSubrsUsed.put(Integer.valueOf(Subr), null);
/*  684 */             this.lGSubrsUsed.add(Integer.valueOf(Subr));
/*      */           }
/*  686 */           CalcHints(this.gsubrOffsets[Subr], this.gsubrOffsets[(Subr + 1)], LBias, GBias, LSubrsOffsets);
/*  687 */           seek(pos);
/*      */         }
/*      */         
/*      */       }
/*  691 */       else if ((this.key == "hstem") || (this.key == "vstem") || (this.key == "hstemhm") || (this.key == "vstemhm"))
/*      */       {
/*  693 */         this.NumOfHints += NumOfArgs / 2;
/*      */ 
/*      */       }
/*  696 */       else if ((this.key == "hintmask") || (this.key == "cntrmask"))
/*      */       {
/*      */ 
/*      */ 
/*  700 */         this.NumOfHints += NumOfArgs / 2;
/*      */         
/*  702 */         int SizeOfMask = this.NumOfHints / 8;
/*  703 */         if ((this.NumOfHints % 8 != 0) || (SizeOfMask == 0)) {
/*  704 */           SizeOfMask++;
/*      */         }
/*  706 */         for (int i = 0; i < SizeOfMask; i++) {
/*  707 */           getCard8();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void HandelStack()
/*      */   {
/*  719 */     int StackHandel = StackOpp();
/*  720 */     if (StackHandel < 2)
/*      */     {
/*      */ 
/*  723 */       if (StackHandel == 1) {
/*  724 */         PushStack();
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  729 */         StackHandel *= -1;
/*  730 */         for (int i = 0; i < StackHandel; i++) {
/*  731 */           PopStack();
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     else {
/*  737 */       EmptyStack();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int StackOpp()
/*      */   {
/*  746 */     if (this.key == "ifelse")
/*  747 */       return -3;
/*  748 */     if ((this.key == "roll") || (this.key == "put"))
/*  749 */       return -2;
/*  750 */     if ((this.key == "callsubr") || (this.key == "callgsubr") || (this.key == "add") || (this.key == "sub") || (this.key == "div") || (this.key == "mul") || (this.key == "drop") || (this.key == "and") || (this.key == "or") || (this.key == "eq"))
/*      */     {
/*      */ 
/*  753 */       return -1; }
/*  754 */     if ((this.key == "abs") || (this.key == "neg") || (this.key == "sqrt") || (this.key == "exch") || (this.key == "index") || (this.key == "get") || (this.key == "not") || (this.key == "return"))
/*      */     {
/*  756 */       return 0; }
/*  757 */     if ((this.key == "random") || (this.key == "dup"))
/*  758 */       return 1;
/*  759 */     return 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void EmptyStack()
/*      */   {
/*  769 */     for (int i = 0; i < this.arg_count; i++) this.args[i] = null;
/*  770 */     this.arg_count = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void PopStack()
/*      */   {
/*  779 */     if (this.arg_count > 0)
/*      */     {
/*  781 */       this.args[(this.arg_count - 1)] = null;
/*  782 */       this.arg_count -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void PushStack()
/*      */   {
/*  792 */     this.arg_count += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void ReadCommand()
/*      */   {
/*  800 */     this.key = null;
/*  801 */     boolean gotKey = false;
/*      */     
/*  803 */     while (!gotKey)
/*      */     {
/*  805 */       char b0 = getCard8();
/*      */       
/*  807 */       if (b0 == '\034')
/*      */       {
/*  809 */         int first = getCard8();
/*  810 */         int second = getCard8();
/*  811 */         this.args[this.arg_count] = Integer.valueOf(first << 8 | second);
/*  812 */         this.arg_count += 1;
/*      */ 
/*      */       }
/*  815 */       else if ((b0 >= ' ') && (b0 <= 'ö'))
/*      */       {
/*  817 */         this.args[this.arg_count] = Integer.valueOf(b0 - '');
/*  818 */         this.arg_count += 1;
/*      */ 
/*      */       }
/*  821 */       else if ((b0 >= '÷') && (b0 <= 'ú'))
/*      */       {
/*  823 */         int w = getCard8();
/*  824 */         this.args[this.arg_count] = Integer.valueOf((b0 - '÷') * 256 + w + 108);
/*  825 */         this.arg_count += 1;
/*      */ 
/*      */       }
/*  828 */       else if ((b0 >= 'û') && (b0 <= 'þ'))
/*      */       {
/*  830 */         int w = getCard8();
/*  831 */         this.args[this.arg_count] = Integer.valueOf(-(b0 - 'û') * 256 - w - 108);
/*  832 */         this.arg_count += 1;
/*      */ 
/*      */       }
/*  835 */       else if (b0 == 'ÿ')
/*      */       {
/*  837 */         int first = getCard8();
/*  838 */         int second = getCard8();
/*  839 */         int third = getCard8();
/*  840 */         int fourth = getCard8();
/*  841 */         this.args[this.arg_count] = Integer.valueOf(first << 24 | second << 16 | third << 8 | fourth);
/*  842 */         this.arg_count += 1;
/*      */ 
/*      */       }
/*  845 */       else if ((b0 <= '\037') && (b0 != '\034'))
/*      */       {
/*  847 */         gotKey = true;
/*      */         
/*      */ 
/*  850 */         if (b0 == '\f')
/*      */         {
/*  852 */           int b1 = getCard8();
/*  853 */           if (b1 > SubrsEscapeFuncs.length - 1)
/*  854 */             b1 = SubrsEscapeFuncs.length - 1;
/*  855 */           this.key = SubrsEscapeFuncs[b1];
/*      */         }
/*      */         else {
/*  858 */           this.key = SubrsFunctions[b0];
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int CalcHints(int begin, int end, int LBias, int GBias, int[] LSubrsOffsets)
/*      */   {
/*  877 */     seek(begin);
/*  878 */     while (getPosition() < end)
/*      */     {
/*      */ 
/*  881 */       ReadCommand();
/*  882 */       int pos = getPosition();
/*  883 */       Object TopElement = null;
/*  884 */       if (this.arg_count > 0)
/*  885 */         TopElement = this.args[(this.arg_count - 1)];
/*  886 */       int NumOfArgs = this.arg_count;
/*      */       
/*  888 */       HandelStack();
/*      */       
/*  890 */       if (this.key == "callsubr")
/*      */       {
/*  892 */         if (NumOfArgs > 0)
/*      */         {
/*  894 */           int Subr = ((Integer)TopElement).intValue() + LBias;
/*  895 */           CalcHints(LSubrsOffsets[Subr], LSubrsOffsets[(Subr + 1)], LBias, GBias, LSubrsOffsets);
/*  896 */           seek(pos);
/*      */         }
/*      */         
/*      */       }
/*  900 */       else if (this.key == "callgsubr")
/*      */       {
/*  902 */         if (NumOfArgs > 0)
/*      */         {
/*  904 */           int Subr = ((Integer)TopElement).intValue() + GBias;
/*  905 */           CalcHints(this.gsubrOffsets[Subr], this.gsubrOffsets[(Subr + 1)], LBias, GBias, LSubrsOffsets);
/*  906 */           seek(pos);
/*      */         }
/*      */         
/*      */       }
/*  910 */       else if ((this.key == "hstem") || (this.key == "vstem") || (this.key == "hstemhm") || (this.key == "vstemhm"))
/*      */       {
/*  912 */         this.NumOfHints += NumOfArgs / 2;
/*      */       }
/*  914 */       else if ((this.key == "hintmask") || (this.key == "cntrmask"))
/*      */       {
/*      */ 
/*  917 */         int SizeOfMask = this.NumOfHints / 8;
/*  918 */         if ((this.NumOfHints % 8 != 0) || (SizeOfMask == 0)) {
/*  919 */           SizeOfMask++;
/*      */         }
/*  921 */         for (int i = 0; i < SizeOfMask; i++)
/*  922 */           getCard8();
/*      */       }
/*      */     }
/*  925 */     return this.NumOfHints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] BuildNewIndex(int[] Offsets, HashMap<Integer, int[]> Used, byte OperatorForUnusedEntries)
/*      */     throws IOException
/*      */   {
/*  940 */     int unusedCount = 0;
/*  941 */     int Offset = 0;
/*  942 */     int[] NewOffsets = new int[Offsets.length];
/*      */     
/*  944 */     for (int i = 0; i < Offsets.length; i++)
/*      */     {
/*  946 */       NewOffsets[i] = Offset;
/*      */       
/*      */ 
/*  949 */       if (Used.containsKey(Integer.valueOf(i))) {
/*  950 */         Offset += Offsets[(i + 1)] - Offsets[i];
/*      */       }
/*      */       else {
/*  953 */         unusedCount++;
/*      */       }
/*      */     }
/*      */     
/*  957 */     byte[] NewObjects = new byte[Offset + unusedCount];
/*      */     
/*  959 */     int unusedOffset = 0;
/*  960 */     for (int i = 0; i < Offsets.length - 1; i++)
/*      */     {
/*  962 */       int start = NewOffsets[i];
/*  963 */       int end = NewOffsets[(i + 1)];
/*  964 */       NewOffsets[i] = (start + unusedOffset);
/*      */       
/*      */ 
/*  967 */       if (start != end)
/*      */       {
/*      */ 
/*      */ 
/*  971 */         this.buf.seek(Offsets[i]);
/*      */         
/*  973 */         this.buf.readFully(NewObjects, start + unusedOffset, end - start);
/*      */       } else {
/*  975 */         NewObjects[(start + unusedOffset)] = OperatorForUnusedEntries;
/*  976 */         unusedOffset++;
/*      */       }
/*      */     }
/*  979 */     NewOffsets[(Offsets.length - 1)] += unusedOffset;
/*      */     
/*  981 */     return AssembleIndex(NewOffsets, NewObjects);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] AssembleIndex(int[] NewOffsets, byte[] NewObjects)
/*      */   {
/*  994 */     char Count = (char)(NewOffsets.length - 1);
/*      */     
/*  996 */     int Size = NewOffsets[(NewOffsets.length - 1)];
/*      */     byte Offsize;
/*      */     byte Offsize;
/*  999 */     if (Size <= 255) { Offsize = 1; } else { byte Offsize;
/* 1000 */       if (Size <= 65535) { Offsize = 2; } else { byte Offsize;
/* 1001 */         if (Size <= 16777215) Offsize = 3; else
/* 1002 */           Offsize = 4;
/*      */       }
/*      */     }
/* 1005 */     byte[] NewIndex = new byte[3 + Offsize * (Count + '\001') + NewObjects.length];
/*      */     
/* 1007 */     int Place = 0;
/*      */     
/* 1009 */     NewIndex[(Place++)] = ((byte)(Count >>> '\b' & 0xFF));
/* 1010 */     NewIndex[(Place++)] = ((byte)(Count >>> '\000' & 0xFF));
/*      */     
/* 1012 */     NewIndex[(Place++)] = Offsize;
/*      */     
/* 1014 */     for (int newOffset : NewOffsets)
/*      */     {
/* 1016 */       int Num = newOffset - NewOffsets[0] + 1;
/*      */       
/* 1018 */       switch (Offsize) {
/*      */       case 4: 
/* 1020 */         NewIndex[(Place++)] = ((byte)(Num >>> 24 & 0xFF));
/*      */       case 3: 
/* 1022 */         NewIndex[(Place++)] = ((byte)(Num >>> 16 & 0xFF));
/*      */       case 2: 
/* 1024 */         NewIndex[(Place++)] = ((byte)(Num >>> 8 & 0xFF));
/*      */       case 1: 
/* 1026 */         NewIndex[(Place++)] = ((byte)(Num >>> 0 & 0xFF));
/*      */       }
/*      */       
/*      */     }
/* 1030 */     for (byte newObject : NewObjects) {
/* 1031 */       NewIndex[(Place++)] = newObject;
/*      */     }
/*      */     
/* 1034 */     return NewIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] BuildNewFile(int Font)
/*      */   {
/* 1045 */     this.OutputList = new LinkedList();
/*      */     
/*      */ 
/* 1048 */     CopyHeader();
/*      */     
/*      */ 
/* 1051 */     BuildIndexHeader(1, 1, 1);
/* 1052 */     this.OutputList.addLast(new CFFFont.UInt8Item((char)(1 + this.fonts[Font].name.length())));
/* 1053 */     this.OutputList.addLast(new CFFFont.StringItem(this.fonts[Font].name));
/*      */     
/*      */ 
/* 1056 */     BuildIndexHeader(1, 2, 1);
/* 1057 */     CFFFont.OffsetItem topdictIndex1Ref = new CFFFont.IndexOffsetItem(2);
/* 1058 */     this.OutputList.addLast(topdictIndex1Ref);
/* 1059 */     CFFFont.IndexBaseItem topdictBase = new CFFFont.IndexBaseItem();
/* 1060 */     this.OutputList.addLast(topdictBase);
/*      */     
/*      */ 
/* 1063 */     CFFFont.OffsetItem charsetRef = new CFFFont.DictOffsetItem();
/* 1064 */     CFFFont.OffsetItem charstringsRef = new CFFFont.DictOffsetItem();
/* 1065 */     CFFFont.OffsetItem fdarrayRef = new CFFFont.DictOffsetItem();
/* 1066 */     CFFFont.OffsetItem fdselectRef = new CFFFont.DictOffsetItem();
/* 1067 */     CFFFont.OffsetItem privateRef = new CFFFont.DictOffsetItem();
/*      */     
/*      */ 
/* 1070 */     if (!this.fonts[Font].isCID)
/*      */     {
/* 1072 */       this.OutputList.addLast(new CFFFont.DictNumberItem(this.fonts[Font].nstrings));
/* 1073 */       this.OutputList.addLast(new CFFFont.DictNumberItem(this.fonts[Font].nstrings + 1));
/* 1074 */       this.OutputList.addLast(new CFFFont.DictNumberItem(0));
/* 1075 */       this.OutputList.addLast(new CFFFont.UInt8Item('\f'));
/* 1076 */       this.OutputList.addLast(new CFFFont.UInt8Item('\036'));
/*      */       
/* 1078 */       this.OutputList.addLast(new CFFFont.DictNumberItem(this.fonts[Font].nglyphs));
/* 1079 */       this.OutputList.addLast(new CFFFont.UInt8Item('\f'));
/* 1080 */       this.OutputList.addLast(new CFFFont.UInt8Item('"'));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1086 */     seek(this.topdictOffsets[Font]);
/*      */     
/* 1088 */     while (getPosition() < this.topdictOffsets[(Font + 1)]) {
/* 1089 */       int p1 = getPosition();
/* 1090 */       getDictItem();
/* 1091 */       int p2 = getPosition();
/*      */       
/* 1093 */       if ((this.key != "Encoding") && (this.key != "Private") && (this.key != "FDSelect") && (this.key != "FDArray") && (this.key != "charset") && (this.key != "CharStrings"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1103 */         this.OutputList.add(new CFFFont.RangeItem(this.buf, p1, p2 - p1));
/*      */       }
/*      */     }
/*      */     
/* 1107 */     CreateKeys(fdarrayRef, fdselectRef, charsetRef, charstringsRef);
/*      */     
/*      */ 
/* 1110 */     this.OutputList.addLast(new CFFFont.IndexMarkerItem(topdictIndex1Ref, topdictBase));
/*      */     
/*      */ 
/*      */ 
/* 1114 */     if (this.fonts[Font].isCID) {
/* 1115 */       this.OutputList.addLast(getEntireIndexRange(this.stringIndexOffset));
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1120 */       CreateNewStringIndex(Font);
/*      */     }
/*      */     
/* 1123 */     this.OutputList.addLast(new CFFFont.RangeItem(new RandomAccessFileOrArray(this.NewGSubrsIndex), 0, this.NewGSubrsIndex.length));
/*      */     
/*      */ 
/*      */ 
/* 1127 */     if (this.fonts[Font].isCID)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1132 */       this.OutputList.addLast(new CFFFont.MarkerItem(fdselectRef));
/*      */       
/* 1134 */       if (this.fonts[Font].fdselectOffset >= 0) {
/* 1135 */         this.OutputList.addLast(new CFFFont.RangeItem(this.buf, this.fonts[Font].fdselectOffset, this.fonts[Font].FDSelectLength));
/*      */       }
/*      */       else {
/* 1138 */         CreateFDSelect(fdselectRef, this.fonts[Font].nglyphs);
/*      */       }
/*      */       
/*      */ 
/* 1142 */       this.OutputList.addLast(new CFFFont.MarkerItem(charsetRef));
/* 1143 */       this.OutputList.addLast(new CFFFont.RangeItem(this.buf, this.fonts[Font].charsetOffset, this.fonts[Font].CharsetLength));
/*      */       
/*      */ 
/*      */ 
/* 1147 */       if (this.fonts[Font].fdarrayOffset >= 0)
/*      */       {
/*      */ 
/* 1150 */         this.OutputList.addLast(new CFFFont.MarkerItem(fdarrayRef));
/*      */         
/* 1152 */         Reconstruct(Font);
/*      */       }
/*      */       else
/*      */       {
/* 1156 */         CreateFDArray(fdarrayRef, privateRef, Font);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1163 */       CreateFDSelect(fdselectRef, this.fonts[Font].nglyphs);
/*      */       
/* 1165 */       CreateCharset(charsetRef, this.fonts[Font].nglyphs);
/*      */       
/* 1167 */       CreateFDArray(fdarrayRef, privateRef, Font);
/*      */     }
/*      */     
/*      */ 
/* 1171 */     if (this.fonts[Font].privateOffset >= 0)
/*      */     {
/*      */ 
/* 1174 */       CFFFont.IndexBaseItem PrivateBase = new CFFFont.IndexBaseItem();
/* 1175 */       this.OutputList.addLast(PrivateBase);
/* 1176 */       this.OutputList.addLast(new CFFFont.MarkerItem(privateRef));
/*      */       
/* 1178 */       CFFFont.OffsetItem Subr = new CFFFont.DictOffsetItem();
/*      */       
/* 1180 */       CreateNonCIDPrivate(Font, Subr);
/*      */       
/* 1182 */       CreateNonCIDSubrs(Font, PrivateBase, Subr);
/*      */     }
/*      */     
/*      */ 
/* 1186 */     this.OutputList.addLast(new CFFFont.MarkerItem(charstringsRef));
/*      */     
/*      */ 
/* 1189 */     this.OutputList.addLast(new CFFFont.RangeItem(new RandomAccessFileOrArray(this.NewCharStringsIndex), 0, this.NewCharStringsIndex.length));
/*      */     
/*      */ 
/* 1192 */     int[] currentOffset = new int[1];
/* 1193 */     currentOffset[0] = 0;
/*      */     
/* 1195 */     Iterator<CFFFont.Item> listIter = this.OutputList.iterator();
/* 1196 */     while (listIter.hasNext()) {
/* 1197 */       CFFFont.Item item = (CFFFont.Item)listIter.next();
/* 1198 */       item.increment(currentOffset);
/*      */     }
/*      */     
/* 1201 */     listIter = this.OutputList.iterator();
/* 1202 */     while (listIter.hasNext()) {
/* 1203 */       CFFFont.Item item = (CFFFont.Item)listIter.next();
/* 1204 */       item.xref();
/*      */     }
/*      */     
/* 1207 */     int size = currentOffset[0];
/* 1208 */     byte[] b = new byte[size];
/*      */     
/*      */ 
/* 1211 */     listIter = this.OutputList.iterator();
/* 1212 */     while (listIter.hasNext()) {
/* 1213 */       CFFFont.Item item = (CFFFont.Item)listIter.next();
/* 1214 */       item.emit(b);
/*      */     }
/*      */     
/* 1217 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void CopyHeader()
/*      */   {
/* 1225 */     seek(0);
/* 1226 */     int major = getCard8();
/* 1227 */     int minor = getCard8();
/* 1228 */     int hdrSize = getCard8();
/* 1229 */     int offSize = getCard8();
/* 1230 */     this.nextIndexOffset = hdrSize;
/* 1231 */     this.OutputList.addLast(new CFFFont.RangeItem(this.buf, 0, hdrSize));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void BuildIndexHeader(int Count, int Offsize, int First)
/*      */   {
/* 1243 */     this.OutputList.addLast(new CFFFont.UInt16Item((char)Count));
/*      */     
/* 1245 */     this.OutputList.addLast(new CFFFont.UInt8Item((char)Offsize));
/*      */     
/* 1247 */     switch (Offsize) {
/*      */     case 1: 
/* 1249 */       this.OutputList.addLast(new CFFFont.UInt8Item((char)First));
/* 1250 */       break;
/*      */     case 2: 
/* 1252 */       this.OutputList.addLast(new CFFFont.UInt16Item((char)First));
/* 1253 */       break;
/*      */     case 3: 
/* 1255 */       this.OutputList.addLast(new CFFFont.UInt24Item((char)First));
/* 1256 */       break;
/*      */     case 4: 
/* 1258 */       this.OutputList.addLast(new CFFFont.UInt32Item((char)First));
/* 1259 */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void CreateKeys(CFFFont.OffsetItem fdarrayRef, CFFFont.OffsetItem fdselectRef, CFFFont.OffsetItem charsetRef, CFFFont.OffsetItem charstringsRef)
/*      */   {
/* 1275 */     this.OutputList.addLast(fdarrayRef);
/* 1276 */     this.OutputList.addLast(new CFFFont.UInt8Item('\f'));
/* 1277 */     this.OutputList.addLast(new CFFFont.UInt8Item('$'));
/*      */     
/* 1279 */     this.OutputList.addLast(fdselectRef);
/* 1280 */     this.OutputList.addLast(new CFFFont.UInt8Item('\f'));
/* 1281 */     this.OutputList.addLast(new CFFFont.UInt8Item('%'));
/*      */     
/* 1283 */     this.OutputList.addLast(charsetRef);
/* 1284 */     this.OutputList.addLast(new CFFFont.UInt8Item('\017'));
/*      */     
/* 1286 */     this.OutputList.addLast(charstringsRef);
/* 1287 */     this.OutputList.addLast(new CFFFont.UInt8Item('\021'));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void CreateNewStringIndex(int Font)
/*      */   {
/* 1297 */     String fdFontName = this.fonts[Font].name + "-OneRange";
/* 1298 */     if (fdFontName.length() > 127)
/* 1299 */       fdFontName = fdFontName.substring(0, 127);
/* 1300 */     String extraStrings = "AdobeIdentity" + fdFontName;
/*      */     
/* 1302 */     int origStringsLen = this.stringOffsets[(this.stringOffsets.length - 1)] - this.stringOffsets[0];
/*      */     
/* 1304 */     int stringsBaseOffset = this.stringOffsets[0] - 1;
/*      */     byte stringsIndexOffSize;
/*      */     byte stringsIndexOffSize;
/* 1307 */     if (origStringsLen + extraStrings.length() <= 255) { stringsIndexOffSize = 1; } else { byte stringsIndexOffSize;
/* 1308 */       if (origStringsLen + extraStrings.length() <= 65535) { stringsIndexOffSize = 2; } else { byte stringsIndexOffSize;
/* 1309 */         if (origStringsLen + extraStrings.length() <= 16777215) stringsIndexOffSize = 3; else
/* 1310 */           stringsIndexOffSize = 4;
/*      */       } }
/* 1312 */     this.OutputList.addLast(new CFFFont.UInt16Item((char)(this.stringOffsets.length - 1 + 3)));
/* 1313 */     this.OutputList.addLast(new CFFFont.UInt8Item((char)stringsIndexOffSize));
/* 1314 */     for (int stringOffset : this.stringOffsets) {
/* 1315 */       this.OutputList.addLast(new CFFFont.IndexOffsetItem(stringsIndexOffSize, stringOffset - stringsBaseOffset));
/*      */     }
/* 1317 */     int currentStringsOffset = this.stringOffsets[(this.stringOffsets.length - 1)] - stringsBaseOffset;
/*      */     
/*      */ 
/* 1320 */     currentStringsOffset += "Adobe".length();
/* 1321 */     this.OutputList.addLast(new CFFFont.IndexOffsetItem(stringsIndexOffSize, currentStringsOffset));
/* 1322 */     currentStringsOffset += "Identity".length();
/* 1323 */     this.OutputList.addLast(new CFFFont.IndexOffsetItem(stringsIndexOffSize, currentStringsOffset));
/* 1324 */     currentStringsOffset += fdFontName.length();
/* 1325 */     this.OutputList.addLast(new CFFFont.IndexOffsetItem(stringsIndexOffSize, currentStringsOffset));
/*      */     
/* 1327 */     this.OutputList.addLast(new CFFFont.RangeItem(this.buf, this.stringOffsets[0], origStringsLen));
/* 1328 */     this.OutputList.addLast(new CFFFont.StringItem(extraStrings));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void CreateFDSelect(CFFFont.OffsetItem fdselectRef, int nglyphs)
/*      */   {
/* 1339 */     this.OutputList.addLast(new CFFFont.MarkerItem(fdselectRef));
/* 1340 */     this.OutputList.addLast(new CFFFont.UInt8Item('\003'));
/* 1341 */     this.OutputList.addLast(new CFFFont.UInt16Item('\001'));
/*      */     
/* 1343 */     this.OutputList.addLast(new CFFFont.UInt16Item('\000'));
/* 1344 */     this.OutputList.addLast(new CFFFont.UInt8Item('\000'));
/*      */     
/* 1346 */     this.OutputList.addLast(new CFFFont.UInt16Item((char)nglyphs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void CreateCharset(CFFFont.OffsetItem charsetRef, int nglyphs)
/*      */   {
/* 1357 */     this.OutputList.addLast(new CFFFont.MarkerItem(charsetRef));
/* 1358 */     this.OutputList.addLast(new CFFFont.UInt8Item('\002'));
/* 1359 */     this.OutputList.addLast(new CFFFont.UInt16Item('\001'));
/* 1360 */     this.OutputList.addLast(new CFFFont.UInt16Item((char)(nglyphs - 1)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void CreateFDArray(CFFFont.OffsetItem fdarrayRef, CFFFont.OffsetItem privateRef, int Font)
/*      */   {
/* 1373 */     this.OutputList.addLast(new CFFFont.MarkerItem(fdarrayRef));
/*      */     
/* 1375 */     BuildIndexHeader(1, 1, 1);
/*      */     
/*      */ 
/* 1378 */     CFFFont.OffsetItem privateIndex1Ref = new CFFFont.IndexOffsetItem(1);
/* 1379 */     this.OutputList.addLast(privateIndex1Ref);
/* 1380 */     CFFFont.IndexBaseItem privateBase = new CFFFont.IndexBaseItem();
/*      */     
/* 1382 */     this.OutputList.addLast(privateBase);
/*      */     
/*      */ 
/* 1385 */     int NewSize = this.fonts[Font].privateLength;
/*      */     
/* 1387 */     int OrgSubrsOffsetSize = CalcSubrOffsetSize(this.fonts[Font].privateOffset, this.fonts[Font].privateLength);
/*      */     
/* 1389 */     if (OrgSubrsOffsetSize != 0)
/* 1390 */       NewSize += 5 - OrgSubrsOffsetSize;
/* 1391 */     this.OutputList.addLast(new CFFFont.DictNumberItem(NewSize));
/* 1392 */     this.OutputList.addLast(privateRef);
/* 1393 */     this.OutputList.addLast(new CFFFont.UInt8Item('\022'));
/*      */     
/* 1395 */     this.OutputList.addLast(new CFFFont.IndexMarkerItem(privateIndex1Ref, privateBase));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void Reconstruct(int Font)
/*      */   {
/* 1405 */     CFFFont.OffsetItem[] fdPrivate = new CFFFont.DictOffsetItem[this.fonts[Font].FDArrayOffsets.length - 1];
/* 1406 */     CFFFont.IndexBaseItem[] fdPrivateBase = new CFFFont.IndexBaseItem[this.fonts[Font].fdprivateOffsets.length];
/* 1407 */     CFFFont.OffsetItem[] fdSubrs = new CFFFont.DictOffsetItem[this.fonts[Font].fdprivateOffsets.length];
/*      */     
/* 1409 */     ReconstructFDArray(Font, fdPrivate);
/* 1410 */     ReconstructPrivateDict(Font, fdPrivate, fdPrivateBase, fdSubrs);
/* 1411 */     ReconstructPrivateSubrs(Font, fdPrivateBase, fdSubrs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void ReconstructFDArray(int Font, CFFFont.OffsetItem[] fdPrivate)
/*      */   {
/* 1422 */     BuildIndexHeader(this.fonts[Font].FDArrayCount, this.fonts[Font].FDArrayOffsize, 1);
/*      */     
/*      */ 
/* 1425 */     CFFFont.OffsetItem[] fdOffsets = new CFFFont.IndexOffsetItem[this.fonts[Font].FDArrayOffsets.length - 1];
/* 1426 */     for (int i = 0; i < this.fonts[Font].FDArrayOffsets.length - 1; i++)
/*      */     {
/* 1428 */       fdOffsets[i] = new CFFFont.IndexOffsetItem(this.fonts[Font].FDArrayOffsize);
/* 1429 */       this.OutputList.addLast(fdOffsets[i]);
/*      */     }
/*      */     
/*      */ 
/* 1433 */     CFFFont.IndexBaseItem fdArrayBase = new CFFFont.IndexBaseItem();
/* 1434 */     this.OutputList.addLast(fdArrayBase);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1440 */     for (int k = 0; k < this.fonts[Font].FDArrayOffsets.length - 1; k++)
/*      */     {
/*      */ 
/*      */ 
/* 1444 */       seek(this.fonts[Font].FDArrayOffsets[k]);
/* 1445 */       while (getPosition() < this.fonts[Font].FDArrayOffsets[(k + 1)])
/*      */       {
/* 1447 */         int p1 = getPosition();
/* 1448 */         getDictItem();
/* 1449 */         int p2 = getPosition();
/*      */         
/*      */ 
/* 1452 */         if (this.key == "Private")
/*      */         {
/* 1454 */           int NewSize = ((Integer)this.args[0]).intValue();
/*      */           
/* 1456 */           int OrgSubrsOffsetSize = CalcSubrOffsetSize(this.fonts[Font].fdprivateOffsets[k], this.fonts[Font].fdprivateLengths[k]);
/*      */           
/* 1458 */           if (OrgSubrsOffsetSize != 0) {
/* 1459 */             NewSize += 5 - OrgSubrsOffsetSize;
/*      */           }
/* 1461 */           this.OutputList.addLast(new CFFFont.DictNumberItem(NewSize));
/* 1462 */           fdPrivate[k] = new CFFFont.DictOffsetItem();
/* 1463 */           this.OutputList.addLast(fdPrivate[k]);
/* 1464 */           this.OutputList.addLast(new CFFFont.UInt8Item('\022'));
/*      */           
/* 1466 */           seek(p2);
/*      */         }
/*      */         else
/*      */         {
/* 1470 */           this.OutputList.addLast(new CFFFont.RangeItem(this.buf, p1, p2 - p1));
/*      */         }
/*      */       }
/*      */       
/* 1474 */       this.OutputList.addLast(new CFFFont.IndexMarkerItem(fdOffsets[k], fdArrayBase));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void ReconstructPrivateDict(int Font, CFFFont.OffsetItem[] fdPrivate, CFFFont.IndexBaseItem[] fdPrivateBase, CFFFont.OffsetItem[] fdSubrs)
/*      */   {
/* 1491 */     for (int i = 0; i < this.fonts[Font].fdprivateOffsets.length; i++)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1496 */       this.OutputList.addLast(new CFFFont.MarkerItem(fdPrivate[i]));
/* 1497 */       fdPrivateBase[i] = new CFFFont.IndexBaseItem();
/* 1498 */       this.OutputList.addLast(fdPrivateBase[i]);
/*      */       
/* 1500 */       seek(this.fonts[Font].fdprivateOffsets[i]);
/* 1501 */       while (getPosition() < this.fonts[Font].fdprivateOffsets[i] + this.fonts[Font].fdprivateLengths[i])
/*      */       {
/* 1503 */         int p1 = getPosition();
/* 1504 */         getDictItem();
/* 1505 */         int p2 = getPosition();
/*      */         
/*      */ 
/* 1508 */         if (this.key == "Subrs") {
/* 1509 */           fdSubrs[i] = new CFFFont.DictOffsetItem();
/* 1510 */           this.OutputList.addLast(fdSubrs[i]);
/* 1511 */           this.OutputList.addLast(new CFFFont.UInt8Item('\023'));
/*      */         }
/*      */         else
/*      */         {
/* 1515 */           this.OutputList.addLast(new CFFFont.RangeItem(this.buf, p1, p2 - p1));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void ReconstructPrivateSubrs(int Font, CFFFont.IndexBaseItem[] fdPrivateBase, CFFFont.OffsetItem[] fdSubrs)
/*      */   {
/* 1532 */     for (int i = 0; i < this.fonts[Font].fdprivateLengths.length; i++)
/*      */     {
/*      */ 
/*      */ 
/* 1536 */       if ((fdSubrs[i] != null) && (this.fonts[Font].PrivateSubrsOffset[i] >= 0))
/*      */       {
/* 1538 */         this.OutputList.addLast(new CFFFont.SubrMarkerItem(fdSubrs[i], fdPrivateBase[i]));
/* 1539 */         if (this.NewLSubrsIndex[i] != null) {
/* 1540 */           this.OutputList.addLast(new CFFFont.RangeItem(new RandomAccessFileOrArray(this.NewLSubrsIndex[i]), 0, this.NewLSubrsIndex[i].length));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int CalcSubrOffsetSize(int Offset, int Size)
/*      */   {
/* 1555 */     int OffsetSize = 0;
/*      */     
/* 1557 */     seek(Offset);
/*      */     
/* 1559 */     while (getPosition() < Offset + Size)
/*      */     {
/* 1561 */       int p1 = getPosition();
/* 1562 */       getDictItem();
/* 1563 */       int p2 = getPosition();
/*      */       
/* 1565 */       if (this.key == "Subrs")
/*      */       {
/* 1567 */         OffsetSize = p2 - p1 - 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1572 */     return OffsetSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int countEntireIndexRange(int indexOffset)
/*      */   {
/* 1583 */     seek(indexOffset);
/*      */     
/* 1585 */     int count = getCard16();
/*      */     
/* 1587 */     if (count == 0) {
/* 1588 */       return 2;
/*      */     }
/*      */     
/*      */ 
/* 1592 */     int indexOffSize = getCard8();
/*      */     
/* 1594 */     seek(indexOffset + 2 + 1 + count * indexOffSize);
/*      */     
/* 1596 */     int size = getOffset(indexOffSize) - 1;
/*      */     
/* 1598 */     return 3 + (count + 1) * indexOffSize + size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void CreateNonCIDPrivate(int Font, CFFFont.OffsetItem Subr)
/*      */   {
/* 1611 */     seek(this.fonts[Font].privateOffset);
/* 1612 */     while (getPosition() < this.fonts[Font].privateOffset + this.fonts[Font].privateLength)
/*      */     {
/* 1614 */       int p1 = getPosition();
/* 1615 */       getDictItem();
/* 1616 */       int p2 = getPosition();
/*      */       
/*      */ 
/* 1619 */       if (this.key == "Subrs") {
/* 1620 */         this.OutputList.addLast(Subr);
/* 1621 */         this.OutputList.addLast(new CFFFont.UInt8Item('\023'));
/*      */       }
/*      */       else
/*      */       {
/* 1625 */         this.OutputList.addLast(new CFFFont.RangeItem(this.buf, p1, p2 - p1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void CreateNonCIDSubrs(int Font, CFFFont.IndexBaseItem PrivateBase, CFFFont.OffsetItem Subrs)
/*      */   {
/* 1639 */     this.OutputList.addLast(new CFFFont.SubrMarkerItem(Subrs, PrivateBase));
/*      */     
/* 1641 */     if (this.NewSubrsIndexNonCID != null) {
/* 1642 */       this.OutputList.addLast(new CFFFont.RangeItem(new RandomAccessFileOrArray(this.NewSubrsIndexNonCID), 0, this.NewSubrsIndexNonCID.length));
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/CFFFontSubset.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */