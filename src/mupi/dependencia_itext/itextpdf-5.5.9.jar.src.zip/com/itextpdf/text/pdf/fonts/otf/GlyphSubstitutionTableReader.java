/*     */ package com.itextpdf.text.pdf.fonts.otf;
/*     */ 
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.pdf.Glyph;
/*     */ import com.itextpdf.text.pdf.RandomAccessFileOrArray;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlyphSubstitutionTableReader
/*     */   extends OpenTypeFontTableReader
/*     */ {
/*     */   private final int[] glyphWidthsByIndex;
/*     */   private final Map<Integer, Character> glyphToCharacterMap;
/*     */   private Map<Integer, List<Integer>> rawLigatureSubstitutionMap;
/*     */   
/*     */   public GlyphSubstitutionTableReader(RandomAccessFileOrArray rf, int gsubTableLocation, Map<Integer, Character> glyphToCharacterMap, int[] glyphWidthsByIndex)
/*     */     throws IOException
/*     */   {
/*  77 */     super(rf, gsubTableLocation);
/*  78 */     this.glyphWidthsByIndex = glyphWidthsByIndex;
/*  79 */     this.glyphToCharacterMap = glyphToCharacterMap;
/*     */   }
/*     */   
/*     */   public void read() throws FontReadingException {
/*  83 */     this.rawLigatureSubstitutionMap = new LinkedHashMap();
/*  84 */     startReadingTable();
/*     */   }
/*     */   
/*     */   public Map<String, Glyph> getGlyphSubstitutionMap() throws FontReadingException {
/*  88 */     Map<String, Glyph> glyphSubstitutionMap = new LinkedHashMap();
/*     */     
/*  90 */     for (Integer glyphIdToReplace : this.rawLigatureSubstitutionMap.keySet()) {
/*  91 */       List<Integer> constituentGlyphs = (List)this.rawLigatureSubstitutionMap.get(glyphIdToReplace);
/*  92 */       StringBuilder chars = new StringBuilder(constituentGlyphs.size());
/*     */       
/*  94 */       for (Integer constituentGlyphId : constituentGlyphs) {
/*  95 */         chars.append(getTextFromGlyph(constituentGlyphId.intValue(), this.glyphToCharacterMap));
/*     */       }
/*     */       
/*  98 */       Glyph glyph = new Glyph(glyphIdToReplace.intValue(), this.glyphWidthsByIndex[glyphIdToReplace.intValue()], chars.toString());
/*     */       
/* 100 */       glyphSubstitutionMap.put(glyph.chars, glyph);
/*     */     }
/*     */     
/* 103 */     return Collections.unmodifiableMap(glyphSubstitutionMap);
/*     */   }
/*     */   
/*     */   private String getTextFromGlyph(int glyphId, Map<Integer, Character> glyphToCharacterMap) throws FontReadingException
/*     */   {
/* 108 */     StringBuilder chars = new StringBuilder(1);
/*     */     
/* 110 */     Character c = (Character)glyphToCharacterMap.get(Integer.valueOf(glyphId));
/*     */     Iterator localIterator;
/* 112 */     if (c == null)
/*     */     {
/* 114 */       List<Integer> constituentGlyphs = (List)this.rawLigatureSubstitutionMap.get(Integer.valueOf(glyphId));
/*     */       
/* 116 */       if ((constituentGlyphs == null) || (constituentGlyphs.isEmpty())) {
/* 117 */         throw new FontReadingException("No corresponding character or simple glyphs found for GlyphID=" + glyphId);
/*     */       }
/*     */       
/* 120 */       for (localIterator = constituentGlyphs.iterator(); localIterator.hasNext();) { int constituentGlyphId = ((Integer)localIterator.next()).intValue();
/* 121 */         chars.append(getTextFromGlyph(constituentGlyphId, glyphToCharacterMap));
/*     */       }
/*     */     }
/*     */     else {
/* 125 */       chars.append(c.charValue());
/*     */     }
/*     */     
/* 128 */     return chars.toString();
/*     */   }
/*     */   
/*     */   protected void readSubTable(int lookupType, int subTableLocation)
/*     */     throws IOException
/*     */   {
/* 134 */     if (lookupType == 1) {
/* 135 */       readSingleSubstitutionSubtable(subTableLocation);
/* 136 */     } else if (lookupType == 4) {
/* 137 */       readLigatureSubstitutionSubtable(subTableLocation);
/*     */     } else {
/* 139 */       System.err.println("LookupType " + lookupType + " is not yet handled for " + GlyphSubstitutionTableReader.class.getSimpleName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readSingleSubstitutionSubtable(int subTableLocation)
/*     */     throws IOException
/*     */   {
/* 148 */     this.rf.seek(subTableLocation);
/*     */     
/* 150 */     int substFormat = this.rf.readShort();
/* 151 */     LOG.debug("substFormat=" + substFormat);
/*     */     int deltaGlyphID;
/* 153 */     Iterator localIterator; if (substFormat == 1) {
/* 154 */       int coverage = this.rf.readShort();
/* 155 */       LOG.debug("coverage=" + coverage);
/*     */       
/* 157 */       deltaGlyphID = this.rf.readShort();
/* 158 */       LOG.debug("deltaGlyphID=" + deltaGlyphID);
/*     */       
/* 160 */       List<Integer> coverageGlyphIds = readCoverageFormat(subTableLocation + coverage);
/*     */       
/* 162 */       for (localIterator = coverageGlyphIds.iterator(); localIterator.hasNext();) { int coverageGlyphId = ((Integer)localIterator.next()).intValue();
/* 163 */         int substituteGlyphId = coverageGlyphId + deltaGlyphID;
/* 164 */         this.rawLigatureSubstitutionMap.put(Integer.valueOf(substituteGlyphId), Arrays.asList(new Integer[] { Integer.valueOf(coverageGlyphId) }));
/*     */       }
/* 166 */     } else if (substFormat == 2) {
/* 167 */       int coverage = this.rf.readShort();
/* 168 */       LOG.debug("coverage=" + coverage);
/* 169 */       int glyphCount = this.rf.readUnsignedShort();
/* 170 */       int[] substitute = new int[glyphCount];
/* 171 */       for (int k = 0; k < glyphCount; k++) {
/* 172 */         substitute[k] = this.rf.readUnsignedShort();
/*     */       }
/* 174 */       Object coverageGlyphIds = readCoverageFormat(subTableLocation + coverage);
/* 175 */       for (int k = 0; k < glyphCount; k++) {
/* 176 */         this.rawLigatureSubstitutionMap.put(Integer.valueOf(substitute[k]), Arrays.asList(new Integer[] { (Integer)((List)coverageGlyphIds).get(k) }));
/*     */       }
/*     */     }
/*     */     else {
/* 180 */       throw new IllegalArgumentException("Bad substFormat: " + substFormat);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void readLigatureSubstitutionSubtable(int ligatureSubstitutionSubtableLocation)
/*     */     throws IOException
/*     */   {
/* 188 */     this.rf.seek(ligatureSubstitutionSubtableLocation);
/* 189 */     int substFormat = this.rf.readShort();
/* 190 */     LOG.debug("substFormat=" + substFormat);
/*     */     
/* 192 */     if (substFormat != 1) {
/* 193 */       throw new IllegalArgumentException("The expected SubstFormat is 1");
/*     */     }
/*     */     
/* 196 */     int coverage = this.rf.readShort();
/* 197 */     LOG.debug("coverage=" + coverage);
/*     */     
/* 199 */     int ligSetCount = this.rf.readShort();
/*     */     
/* 201 */     List<Integer> ligatureOffsets = new ArrayList(ligSetCount);
/*     */     
/* 203 */     for (int i = 0; i < ligSetCount; i++) {
/* 204 */       int ligatureOffset = this.rf.readShort();
/* 205 */       ligatureOffsets.add(Integer.valueOf(ligatureOffset));
/*     */     }
/*     */     
/* 208 */     List<Integer> coverageGlyphIds = readCoverageFormat(ligatureSubstitutionSubtableLocation + coverage);
/*     */     
/* 210 */     if (ligSetCount != coverageGlyphIds.size()) {
/* 211 */       throw new IllegalArgumentException("According to the OpenTypeFont specifications, the coverage count should be equal to the no. of LigatureSetTables");
/*     */     }
/*     */     
/* 214 */     for (int i = 0; i < ligSetCount; i++)
/*     */     {
/* 216 */       int coverageGlyphId = ((Integer)coverageGlyphIds.get(i)).intValue();
/* 217 */       int ligatureOffset = ((Integer)ligatureOffsets.get(i)).intValue();
/* 218 */       LOG.debug("ligatureOffset=" + ligatureOffset);
/* 219 */       readLigatureSetTable(ligatureSubstitutionSubtableLocation + ligatureOffset, coverageGlyphId);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readLigatureSetTable(int ligatureSetTableLocation, int coverageGlyphId) throws IOException
/*     */   {
/* 225 */     this.rf.seek(ligatureSetTableLocation);
/* 226 */     int ligatureCount = this.rf.readShort();
/* 227 */     LOG.debug("ligatureCount=" + ligatureCount);
/*     */     
/* 229 */     List<Integer> ligatureOffsets = new ArrayList(ligatureCount);
/*     */     
/* 231 */     for (int i = 0; i < ligatureCount; i++) {
/* 232 */       int ligatureOffset = this.rf.readShort();
/* 233 */       ligatureOffsets.add(Integer.valueOf(ligatureOffset));
/*     */     }
/*     */     
/* 236 */     for (i = ligatureOffsets.iterator(); i.hasNext();) { int ligatureOffset = ((Integer)i.next()).intValue();
/* 237 */       readLigatureTable(ligatureSetTableLocation + ligatureOffset, coverageGlyphId);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readLigatureTable(int ligatureTableLocation, int coverageGlyphId) throws IOException {
/* 242 */     this.rf.seek(ligatureTableLocation);
/* 243 */     int ligGlyph = this.rf.readShort();
/* 244 */     LOG.debug("ligGlyph=" + ligGlyph);
/*     */     
/* 246 */     int compCount = this.rf.readShort();
/*     */     
/* 248 */     List<Integer> glyphIdList = new ArrayList();
/*     */     
/* 250 */     glyphIdList.add(Integer.valueOf(coverageGlyphId));
/*     */     
/* 252 */     for (int i = 0; i < compCount - 1; i++) {
/* 253 */       int glyphId = this.rf.readShort();
/* 254 */       glyphIdList.add(Integer.valueOf(glyphId));
/*     */     }
/*     */     
/* 257 */     LOG.debug("glyphIdList=" + glyphIdList);
/*     */     
/* 259 */     List<Integer> previousValue = (List)this.rawLigatureSubstitutionMap.put(Integer.valueOf(ligGlyph), glyphIdList);
/*     */     
/* 261 */     if (previousValue != null) {
/* 262 */       LOG.warn("!!!!!!!!!!glyphId=" + ligGlyph + ",\npreviousValue=" + previousValue + ",\ncurrentVal=" + glyphIdList);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/otf/GlyphSubstitutionTableReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */