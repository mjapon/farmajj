package com.itextpdf.text.pdf;

public abstract interface ExtraEncoding
{
  public abstract byte[] charToByte(String paramString1, String paramString2);
  
  public abstract byte[] charToByte(char paramChar, String paramString);
  
  public abstract String byteToChar(byte[] paramArrayOfByte, String paramString);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/ExtraEncoding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */