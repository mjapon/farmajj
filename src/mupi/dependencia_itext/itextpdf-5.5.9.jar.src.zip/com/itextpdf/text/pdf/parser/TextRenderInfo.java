/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.pdf.CMapAwareDocumentFont;
/*     */ import com.itextpdf.text.pdf.DocumentFont;
/*     */ import com.itextpdf.text.pdf.PdfString;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextRenderInfo
/*     */ {
/*     */   private final PdfString string;
/*  68 */   private String text = null;
/*     */   private final Matrix textToUserSpaceTransformMatrix;
/*     */   private final GraphicsState gs;
/*  71 */   private Float unscaledWidth = null;
/*  72 */   private double[] fontMatrix = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Collection<MarkedContentInfo> markedContentInfos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TextRenderInfo(PdfString string, GraphicsState gs, Matrix textMatrix, Collection<MarkedContentInfo> markedContentInfo)
/*     */   {
/*  87 */     this.string = string;
/*  88 */     this.textToUserSpaceTransformMatrix = textMatrix.multiply(gs.ctm);
/*  89 */     this.gs = gs;
/*  90 */     this.markedContentInfos = new ArrayList(markedContentInfo);
/*  91 */     this.fontMatrix = gs.font.getFontMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TextRenderInfo(TextRenderInfo parent, PdfString string, float horizontalOffset)
/*     */   {
/* 102 */     this.string = string;
/* 103 */     this.textToUserSpaceTransformMatrix = new Matrix(horizontalOffset, 0.0F).multiply(parent.textToUserSpaceTransformMatrix);
/* 104 */     this.gs = parent.gs;
/* 105 */     this.markedContentInfos = parent.markedContentInfos;
/* 106 */     this.fontMatrix = this.gs.font.getFontMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 113 */     if (this.text == null)
/* 114 */       this.text = decode(this.string);
/* 115 */     return this.text;
/*     */   }
/*     */   
/*     */ 
/*     */   public PdfString getPdfString()
/*     */   {
/* 121 */     return this.string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasMcid(int mcid)
/*     */   {
/* 131 */     return hasMcid(mcid, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasMcid(int mcid, boolean checkTheTopmostLevelOnly)
/*     */   {
/*     */     Integer infoMcid;
/*     */     
/*     */ 
/*     */ 
/* 143 */     if (checkTheTopmostLevelOnly) {
/* 144 */       if ((this.markedContentInfos instanceof ArrayList)) {
/* 145 */         infoMcid = getMcid();
/* 146 */         return infoMcid.intValue() == mcid;
/*     */       }
/*     */     } else {
/* 149 */       for (MarkedContentInfo info : this.markedContentInfos) {
/* 150 */         if ((info.hasMcid()) && 
/* 151 */           (info.getMcid() == mcid))
/* 152 */           return true;
/*     */       }
/*     */     }
/* 155 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Integer getMcid()
/*     */   {
/* 162 */     if ((this.markedContentInfos instanceof ArrayList)) {
/* 163 */       ArrayList<MarkedContentInfo> mci = (ArrayList)this.markedContentInfos;
/* 164 */       MarkedContentInfo info = mci.size() > 0 ? (MarkedContentInfo)mci.get(mci.size() - 1) : null;
/* 165 */       return (info != null) && (info.hasMcid()) ? Integer.valueOf(info.getMcid()) : null;
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   float getUnscaledWidth()
/*     */   {
/* 174 */     if (this.unscaledWidth == null)
/* 175 */       this.unscaledWidth = Float.valueOf(getPdfStringWidth(this.string, false));
/* 176 */     return this.unscaledWidth.floatValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineSegment getBaseline()
/*     */   {
/* 186 */     return getUnscaledBaselineWithOffset(0.0F + this.gs.rise).transformBy(this.textToUserSpaceTransformMatrix);
/*     */   }
/*     */   
/*     */   public LineSegment getUnscaledBaseline() {
/* 190 */     return getUnscaledBaselineWithOffset(0.0F + this.gs.rise);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineSegment getAscentLine()
/*     */   {
/* 200 */     float ascent = this.gs.getFont().getFontDescriptor(1, this.gs.getFontSize());
/* 201 */     return getUnscaledBaselineWithOffset(ascent + this.gs.rise).transformBy(this.textToUserSpaceTransformMatrix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineSegment getDescentLine()
/*     */   {
/* 212 */     float descent = this.gs.getFont().getFontDescriptor(3, this.gs.getFontSize());
/* 213 */     return getUnscaledBaselineWithOffset(descent + this.gs.rise).transformBy(this.textToUserSpaceTransformMatrix);
/*     */   }
/*     */   
/*     */ 
/*     */   private LineSegment getUnscaledBaselineWithOffset(float yOffset)
/*     */   {
/* 219 */     String unicodeStr = this.string.toUnicodeString();
/*     */     
/*     */ 
/* 222 */     float correctedUnscaledWidth = getUnscaledWidth() - (this.gs.characterSpacing + ((unicodeStr.length() > 0) && (unicodeStr.charAt(unicodeStr.length() - 1) == ' ') ? this.gs.wordSpacing : 0.0F)) * this.gs.horizontalScaling;
/*     */     
/* 224 */     return new LineSegment(new Vector(0.0F, yOffset, 1.0F), new Vector(correctedUnscaledWidth, yOffset, 1.0F));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentFont getFont()
/*     */   {
/* 233 */     return this.gs.getFont();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getRise()
/*     */   {
/* 260 */     if (this.gs.rise == 0.0F) { return 0.0F;
/*     */     }
/* 262 */     return convertHeightFromTextSpaceToUserSpace(this.gs.rise);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float convertWidthFromTextSpaceToUserSpace(float width)
/*     */   {
/* 272 */     LineSegment textSpace = new LineSegment(new Vector(0.0F, 0.0F, 1.0F), new Vector(width, 0.0F, 1.0F));
/* 273 */     LineSegment userSpace = textSpace.transformBy(this.textToUserSpaceTransformMatrix);
/* 274 */     return userSpace.getLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float convertHeightFromTextSpaceToUserSpace(float height)
/*     */   {
/* 284 */     LineSegment textSpace = new LineSegment(new Vector(0.0F, 0.0F, 1.0F), new Vector(0.0F, height, 1.0F));
/* 285 */     LineSegment userSpace = textSpace.transformBy(this.textToUserSpaceTransformMatrix);
/* 286 */     return userSpace.getLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public float getSingleSpaceWidth()
/*     */   {
/* 293 */     return convertWidthFromTextSpaceToUserSpace(getUnscaledFontSpaceWidth());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTextRenderMode()
/*     */   {
/* 312 */     return this.gs.renderMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BaseColor getFillColor()
/*     */   {
/* 319 */     return this.gs.fillColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseColor getStrokeColor()
/*     */   {
/* 327 */     return this.gs.strokeColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float getUnscaledFontSpaceWidth()
/*     */   {
/* 337 */     char charToUse = ' ';
/* 338 */     if (this.gs.font.getWidth(charToUse) == 0)
/* 339 */       charToUse = ' ';
/* 340 */     return getStringWidth(String.valueOf(charToUse));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float getStringWidth(String string)
/*     */   {
/* 349 */     float totalWidth = 0.0F;
/* 350 */     for (int i = 0; i < string.length(); i++) {
/* 351 */       char c = string.charAt(i);
/* 352 */       float w = this.gs.font.getWidth(c) / 1000.0F;
/* 353 */       float wordSpacing = c == ' ' ? this.gs.wordSpacing : 0.0F;
/* 354 */       totalWidth += (w * this.gs.fontSize + this.gs.characterSpacing + wordSpacing) * this.gs.horizontalScaling;
/*     */     }
/* 356 */     return totalWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float getPdfStringWidth(PdfString string, boolean singleCharString)
/*     */   {
/* 365 */     if (singleCharString) {
/* 366 */       float[] widthAndWordSpacing = getWidthAndWordSpacing(string, singleCharString);
/* 367 */       return (widthAndWordSpacing[0] * this.gs.fontSize + this.gs.characterSpacing + widthAndWordSpacing[1]) * this.gs.horizontalScaling;
/*     */     }
/* 369 */     float totalWidth = 0.0F;
/* 370 */     for (PdfString str : splitString(string)) {
/* 371 */       totalWidth += getPdfStringWidth(str, true);
/*     */     }
/* 373 */     return totalWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TextRenderInfo> getCharacterRenderInfos()
/*     */   {
/* 383 */     List<TextRenderInfo> rslt = new ArrayList(this.string.length());
/* 384 */     PdfString[] strings = splitString(this.string);
/* 385 */     float totalWidth = 0.0F;
/* 386 */     for (int i = 0; i < strings.length; i++) {
/* 387 */       float[] widthAndWordSpacing = getWidthAndWordSpacing(strings[i], true);
/* 388 */       TextRenderInfo subInfo = new TextRenderInfo(this, strings[i], totalWidth);
/* 389 */       rslt.add(subInfo);
/* 390 */       totalWidth += (widthAndWordSpacing[0] * this.gs.fontSize + this.gs.characterSpacing + widthAndWordSpacing[1]) * this.gs.horizontalScaling;
/*     */     }
/* 392 */     for (TextRenderInfo tri : rslt)
/* 393 */       tri.getUnscaledWidth();
/* 394 */     return rslt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float[] getWidthAndWordSpacing(PdfString string, boolean singleCharString)
/*     */   {
/* 404 */     if (!singleCharString)
/* 405 */       throw new UnsupportedOperationException();
/* 406 */     float[] result = new float[2];
/* 407 */     String decoded = decode(string);
/* 408 */     result[0] = ((float)(this.gs.font.getWidth(getCharCode(decoded)) * this.fontMatrix[0]));
/* 409 */     result[1] = (decoded.equals(" ") ? this.gs.wordSpacing : 0.0F);
/* 410 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String decode(PdfString in)
/*     */   {
/* 420 */     byte[] bytes = in.getBytes();
/* 421 */     return this.gs.font.decode(bytes, 0, bytes.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getCharCode(String string)
/*     */   {
/*     */     try
/*     */     {
/* 432 */       byte[] b = string.getBytes("UTF-16BE");
/* 433 */       int value = 0;
/* 434 */       for (int i = 0; i < b.length - 1; i++) {
/* 435 */         value += (b[i] & 0xFF);
/* 436 */         value <<= 8;
/*     */       }
/* 438 */       if (b.length > 0) {}
/* 439 */       return value + (b[(b.length - 1)] & 0xFF);
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*     */     
/*     */ 
/* 444 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PdfString[] splitString(PdfString string)
/*     */   {
/* 453 */     List<PdfString> strings = new ArrayList();
/* 454 */     String stringValue = string.toString();
/* 455 */     for (int i = 0; i < stringValue.length(); i++) {
/* 456 */       PdfString newString = new PdfString(stringValue.substring(i, i + 1), string.getEncoding());
/* 457 */       String text = decode(newString);
/* 458 */       if ((text.length() == 0) && (i < stringValue.length() - 1)) {
/* 459 */         newString = new PdfString(stringValue.substring(i, i + 2), string.getEncoding());
/* 460 */         i++;
/*     */       }
/* 462 */       strings.add(newString);
/*     */     }
/* 464 */     return (PdfString[])strings.toArray(new PdfString[strings.size()]);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/TextRenderInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */