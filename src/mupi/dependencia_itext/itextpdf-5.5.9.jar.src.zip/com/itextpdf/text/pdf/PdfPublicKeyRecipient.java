/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import java.security.cert.Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfPublicKeyRecipient
/*    */ {
/* 51 */   private Certificate certificate = null;
/*    */   
/* 53 */   private int permission = 0;
/*    */   
/* 55 */   protected byte[] cms = null;
/*    */   
/*    */   public PdfPublicKeyRecipient(Certificate certificate, int permission)
/*    */   {
/* 59 */     this.certificate = certificate;
/* 60 */     this.permission = permission;
/*    */   }
/*    */   
/*    */   public Certificate getCertificate() {
/* 64 */     return this.certificate;
/*    */   }
/*    */   
/*    */   public int getPermission() {
/* 68 */     return this.permission;
/*    */   }
/*    */   
/*    */   protected void setCms(byte[] cms) {
/* 72 */     this.cms = cms;
/*    */   }
/*    */   
/*    */   protected byte[] getCms() {
/* 76 */     return this.cms;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfPublicKeyRecipient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */