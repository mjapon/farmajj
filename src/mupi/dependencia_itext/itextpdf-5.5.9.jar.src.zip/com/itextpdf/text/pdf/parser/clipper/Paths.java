/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Paths
/*     */   extends ArrayList<Path>
/*     */ {
/*     */   private static final long serialVersionUID = 1910552127810480852L;
/*     */   
/*     */   public static Paths closedPathsFromPolyTree(PolyTree polytree)
/*     */   {
/*  89 */     Paths result = new Paths();
/*     */     
/*  91 */     result.addPolyNode(polytree, PolyNode.NodeType.CLOSED);
/*  92 */     return result;
/*     */   }
/*     */   
/*     */   public static Paths makePolyTreeToPaths(PolyTree polytree)
/*     */   {
/*  97 */     Paths result = new Paths();
/*     */     
/*  99 */     result.addPolyNode(polytree, PolyNode.NodeType.ANY);
/* 100 */     return result;
/*     */   }
/*     */   
/*     */   public static Paths openPathsFromPolyTree(PolyTree polytree) {
/* 104 */     Paths result = new Paths();
/*     */     
/* 106 */     for (PolyNode c : polytree.getChilds()) {
/* 107 */       if (c.isOpen()) {
/* 108 */         result.add(c.getPolygon());
/*     */       }
/*     */     }
/* 111 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Paths() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Paths(int initialCapacity)
/*     */   {
/* 124 */     super(initialCapacity);
/*     */   }
/*     */   
/*     */   public void addPolyNode(PolyNode polynode, PolyNode.NodeType nt) {
/* 128 */     boolean match = true;
/* 129 */     switch (nt) {
/*     */     case OPEN: 
/* 131 */       return;
/*     */     case CLOSED: 
/* 133 */       match = !polynode.isOpen();
/* 134 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 139 */     if ((polynode.getPolygon().size() > 0) && (match)) {
/* 140 */       add(polynode.getPolygon());
/*     */     }
/* 142 */     for (PolyNode pn : polynode.getChilds()) {
/* 143 */       addPolyNode(pn, nt);
/*     */     }
/*     */   }
/*     */   
/*     */   public Paths cleanPolygons() {
/* 148 */     return cleanPolygons(1.415D);
/*     */   }
/*     */   
/*     */   public Paths cleanPolygons(double distance) {
/* 152 */     Paths result = new Paths(size());
/* 153 */     for (int i = 0; i < size(); i++) {
/* 154 */       result.add(((Path)get(i)).cleanPolygon(distance));
/*     */     }
/* 156 */     return result;
/*     */   }
/*     */   
/*     */   public LongRect getBounds()
/*     */   {
/* 161 */     int i = 0;
/* 162 */     int cnt = size();
/* 163 */     LongRect result = new LongRect();
/* 164 */     while ((i < cnt) && (((Path)get(i)).isEmpty())) {
/* 165 */       i++;
/*     */     }
/* 167 */     if (i == cnt) {
/* 168 */       return result;
/*     */     }
/*     */     
/* 171 */     result.left = ((Point.LongPoint)((Path)get(i)).get(0)).getX();
/* 172 */     result.right = result.left;
/* 173 */     result.top = ((Point.LongPoint)((Path)get(i)).get(0)).getY();
/* 174 */     result.bottom = result.top;
/* 175 */     for (; i < cnt; i++) {
/* 176 */       for (int j = 0; j < ((Path)get(i)).size(); j++) {
/* 177 */         if (((Point.LongPoint)((Path)get(i)).get(j)).getX() < result.left) {
/* 178 */           result.left = ((Point.LongPoint)((Path)get(i)).get(j)).getX();
/*     */         }
/* 180 */         else if (((Point.LongPoint)((Path)get(i)).get(j)).getX() > result.right) {
/* 181 */           result.right = ((Point.LongPoint)((Path)get(i)).get(j)).getX();
/*     */         }
/* 183 */         if (((Point.LongPoint)((Path)get(i)).get(j)).getY() < result.top) {
/* 184 */           result.top = ((Point.LongPoint)((Path)get(i)).get(j)).getY();
/*     */         }
/* 186 */         else if (((Point.LongPoint)((Path)get(i)).get(j)).getY() > result.bottom) {
/* 187 */           result.bottom = ((Point.LongPoint)((Path)get(i)).get(j)).getY();
/*     */         }
/*     */       }
/*     */     }
/* 191 */     return result;
/*     */   }
/*     */   
/*     */   public void reversePaths() {
/* 195 */     for (Path poly : this) {
/* 196 */       poly.reverse();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/Paths.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */