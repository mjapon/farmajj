/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.Document;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.exceptions.BadPasswordException;
/*      */ import com.itextpdf.text.log.Counter;
/*      */ import com.itextpdf.text.log.CounterFactory;
/*      */ import com.itextpdf.text.log.Logger;
/*      */ import com.itextpdf.text.log.LoggerFactory;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfCopy
/*      */   extends PdfWriter
/*      */ {
/*   77 */   private static final Logger LOGGER = LoggerFactory.getLogger(PdfCopy.class);
/*      */   
/*      */ 
/*      */   static class IndirectReferences
/*      */   {
/*      */     PdfIndirectReference theRef;
/*      */     boolean hasCopied;
/*      */     
/*      */     IndirectReferences(PdfIndirectReference ref)
/*      */     {
/*   87 */       this.theRef = ref;
/*   88 */       this.hasCopied = false; }
/*      */     
/*   90 */     void setCopied() { this.hasCopied = true; }
/*   91 */     void setNotCopied() { this.hasCopied = false; }
/*   92 */     boolean getCopied() { return this.hasCopied; }
/*   93 */     PdfIndirectReference getRef() { return this.theRef; }
/*      */     
/*      */     public String toString()
/*      */     {
/*   97 */       String ext = "";
/*   98 */       if (this.hasCopied) ext = ext + " Copied";
/*   99 */       return getRef() + ext;
/*      */     }
/*      */   }
/*      */   
/*  103 */   protected static Counter COUNTER = CounterFactory.getCounter(PdfCopy.class);
/*      */   
/*  105 */   protected Counter getCounter() { return COUNTER; }
/*      */   
/*      */   protected HashMap<RefKey, IndirectReferences> indirects;
/*      */   protected HashMap<PdfReader, HashMap<RefKey, IndirectReferences>> indirectMap;
/*      */   protected HashMap<PdfObject, PdfObject> parentObjects;
/*      */   protected HashSet<PdfObject> disableIndirects;
/*      */   protected PdfReader reader;
/*  112 */   protected int[] namePtr = { 0 };
/*      */   
/*  114 */   private boolean rotateContents = true;
/*      */   protected PdfArray fieldArray;
/*      */   protected HashSet<PdfTemplate> fieldTemplates;
/*  117 */   private PdfStructTreeController structTreeController = null;
/*  118 */   private int currentStructArrayNumber = 0;
/*      */   
/*      */   protected PRIndirectReference structTreeRootReference;
/*      */   
/*      */   protected LinkedHashMap<RefKey, PdfIndirectObject> indirectObjects;
/*      */   
/*      */   protected ArrayList<PdfIndirectObject> savedObjects;
/*      */   
/*      */   protected ArrayList<ImportedPage> importedPages;
/*      */   
/*  128 */   protected boolean updateRootKids = false;
/*      */   
/*  130 */   private static final PdfName annotId = new PdfName("iTextAnnotId");
/*  131 */   private static int annotIdCnt = 0;
/*      */   
/*  133 */   protected boolean mergeFields = false;
/*  134 */   private boolean needAppearances = false;
/*      */   private boolean hasSignature;
/*      */   private PdfIndirectReference acroForm;
/*      */   private HashMap<PdfArray, ArrayList<Integer>> tabOrder;
/*      */   private ArrayList<Object> calculationOrderRefs;
/*      */   private PdfDictionary resources;
/*      */   protected ArrayList<AcroFields> fields;
/*      */   private ArrayList<String> calculationOrder;
/*      */   private HashMap<String, Object> fieldTree;
/*      */   private HashMap<Integer, PdfIndirectObject> unmergedMap;
/*      */   private HashMap<RefKey, PdfIndirectObject> unmergedIndirectRefsMap;
/*      */   private HashMap<Integer, PdfIndirectObject> mergedMap;
/*      */   private HashSet<PdfIndirectObject> mergedSet;
/*  147 */   private boolean mergeFieldsInternalCall = false;
/*  148 */   private static final PdfName iTextTag = new PdfName("_iTextTag_");
/*  149 */   private static final Integer zero = Integer.valueOf(0);
/*  150 */   private HashSet<Object> mergedRadioButtons = new HashSet();
/*  151 */   private HashMap<Object, PdfString> mergedTextFields = new HashMap();
/*      */   
/*  153 */   private HashSet<PdfReader> readersWithImportedStructureTreeRootKids = new HashSet();
/*      */   
/*      */   protected static class ImportedPage {
/*      */     int pageNumber;
/*      */     PdfReader reader;
/*      */     PdfArray mergedFields;
/*      */     PdfIndirectReference annotsIndirectReference;
/*      */     
/*      */     ImportedPage(PdfReader reader, int pageNumber, boolean keepFields) {
/*  162 */       this.pageNumber = pageNumber;
/*  163 */       this.reader = reader;
/*  164 */       if (keepFields) {
/*  165 */         this.mergedFields = new PdfArray();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean equals(Object o)
/*      */     {
/*  171 */       if (!(o instanceof ImportedPage)) return false;
/*  172 */       ImportedPage other = (ImportedPage)o;
/*  173 */       return (this.pageNumber == other.pageNumber) && (this.reader.equals(other.reader));
/*      */     }
/*      */     
/*      */     public String toString() {
/*  177 */       return Integer.toString(this.pageNumber);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfCopy(Document document, OutputStream os)
/*      */     throws DocumentException
/*      */   {
/*  187 */     super(new PdfDocument(), os);
/*  188 */     document.addDocListener(this.pdf);
/*  189 */     this.pdf.addWriter(this);
/*  190 */     this.indirectMap = new HashMap();
/*  191 */     this.parentObjects = new HashMap();
/*  192 */     this.disableIndirects = new HashSet();
/*      */     
/*  194 */     this.indirectObjects = new LinkedHashMap();
/*  195 */     this.savedObjects = new ArrayList();
/*  196 */     this.importedPages = new ArrayList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageEvent(PdfPageEvent event)
/*      */   {
/*  206 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRotateContents()
/*      */   {
/*  214 */     return this.rotateContents;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRotateContents(boolean rotateContents)
/*      */   {
/*  222 */     this.rotateContents = rotateContents;
/*      */   }
/*      */   
/*      */   public void setMergeFields() {
/*  226 */     this.mergeFields = true;
/*  227 */     this.resources = new PdfDictionary();
/*  228 */     this.fields = new ArrayList();
/*  229 */     this.calculationOrder = new ArrayList();
/*  230 */     this.fieldTree = new LinkedHashMap();
/*  231 */     this.unmergedMap = new HashMap();
/*  232 */     this.unmergedIndirectRefsMap = new HashMap();
/*  233 */     this.mergedMap = new HashMap();
/*  234 */     this.mergedSet = new HashSet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfImportedPage getImportedPage(PdfReader reader, int pageNumber)
/*      */   {
/*  245 */     if ((this.mergeFields) && (!this.mergeFieldsInternalCall)) {
/*  246 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("1.method.cannot.be.used.in.mergeFields.mode.please.use.addDocument", new Object[] { "getImportedPage" }));
/*      */     }
/*  248 */     if (this.mergeFields) {
/*  249 */       ImportedPage newPage = new ImportedPage(reader, pageNumber, this.mergeFields);
/*  250 */       this.importedPages.add(newPage);
/*      */     }
/*  252 */     if (this.structTreeController != null)
/*  253 */       this.structTreeController.reader = null;
/*  254 */     this.disableIndirects.clear();
/*  255 */     this.parentObjects.clear();
/*  256 */     return getImportedPageImpl(reader, pageNumber);
/*      */   }
/*      */   
/*      */   public PdfImportedPage getImportedPage(PdfReader reader, int pageNumber, boolean keepTaggedPdfStructure) throws BadPdfFormatException {
/*  260 */     if ((this.mergeFields) && (!this.mergeFieldsInternalCall)) {
/*  261 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("1.method.cannot.be.used.in.mergeFields.mode.please.use.addDocument", new Object[] { "getImportedPage" }));
/*      */     }
/*  263 */     this.updateRootKids = false;
/*  264 */     if (!keepTaggedPdfStructure) {
/*  265 */       if (this.mergeFields) {
/*  266 */         ImportedPage newPage = new ImportedPage(reader, pageNumber, this.mergeFields);
/*  267 */         this.importedPages.add(newPage);
/*      */       }
/*  269 */       return getImportedPageImpl(reader, pageNumber);
/*      */     }
/*  271 */     if (this.structTreeController != null) {
/*  272 */       if (reader != this.structTreeController.reader)
/*  273 */         this.structTreeController.setReader(reader);
/*      */     } else {
/*  275 */       this.structTreeController = new PdfStructTreeController(reader, this);
/*      */     }
/*  277 */     ImportedPage newPage = new ImportedPage(reader, pageNumber, this.mergeFields);
/*  278 */     switch (checkStructureTreeRootKids(newPage)) {
/*      */     case -1: 
/*  280 */       clearIndirects(reader);
/*  281 */       this.updateRootKids = true;
/*  282 */       break;
/*      */     case 0: 
/*  284 */       this.updateRootKids = false;
/*  285 */       break;
/*      */     case 1: 
/*  287 */       this.updateRootKids = true;
/*      */     }
/*      */     
/*  290 */     this.importedPages.add(newPage);
/*      */     
/*  292 */     this.disableIndirects.clear();
/*  293 */     this.parentObjects.clear();
/*  294 */     return getImportedPageImpl(reader, pageNumber);
/*      */   }
/*      */   
/*      */   private void clearIndirects(PdfReader reader) {
/*  298 */     HashMap<RefKey, IndirectReferences> currIndirects = (HashMap)this.indirectMap.get(reader);
/*  299 */     ArrayList<RefKey> forDelete = new ArrayList();
/*  300 */     for (Map.Entry<RefKey, IndirectReferences> entry : currIndirects.entrySet()) {
/*  301 */       PdfIndirectReference iRef = ((IndirectReferences)entry.getValue()).theRef;
/*  302 */       RefKey key = new RefKey(iRef);
/*  303 */       PdfIndirectObject iobj = (PdfIndirectObject)this.indirectObjects.get(key);
/*  304 */       if (iobj == null) {
/*  305 */         forDelete.add(entry.getKey());
/*      */       }
/*  307 */       else if ((iobj.object.isArray()) || (iobj.object.isDictionary()) || (iobj.object.isStream())) {
/*  308 */         forDelete.add(entry.getKey());
/*      */       }
/*      */     }
/*      */     
/*  312 */     for (RefKey key : forDelete) {
/*  313 */       currIndirects.remove(key);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int checkStructureTreeRootKids(ImportedPage newPage)
/*      */   {
/*  321 */     if (this.importedPages.size() == 0) return 1;
/*  322 */     boolean readerExist = false;
/*  323 */     for (ImportedPage page : this.importedPages) {
/*  324 */       if (page.reader.equals(newPage.reader)) {
/*  325 */         readerExist = true;
/*  326 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  331 */     if (!readerExist) { return 1;
/*      */     }
/*  333 */     ImportedPage lastPage = (ImportedPage)this.importedPages.get(this.importedPages.size() - 1);
/*  334 */     boolean equalReader = lastPage.reader.equals(newPage.reader);
/*      */     
/*  336 */     if ((equalReader) && (newPage.pageNumber > lastPage.pageNumber)) {
/*  337 */       if (this.readersWithImportedStructureTreeRootKids.contains(newPage.reader)) {
/*  338 */         return 0;
/*      */       }
/*  340 */       return 1;
/*      */     }
/*      */     
/*  343 */     return -1;
/*      */   }
/*      */   
/*      */   protected void structureTreeRootKidsForReaderImported(PdfReader reader) {
/*  347 */     this.readersWithImportedStructureTreeRootKids.add(reader);
/*      */   }
/*      */   
/*      */   protected void fixStructureTreeRoot(HashSet<RefKey> activeKeys, HashSet<PdfName> activeClassMaps) {
/*  351 */     HashMap<PdfName, PdfObject> newClassMap = new HashMap(activeClassMaps.size());
/*  352 */     for (PdfName key : activeClassMaps) {
/*  353 */       PdfObject cm = (PdfObject)this.structureTreeRoot.classes.get(key);
/*  354 */       if (cm != null) { newClassMap.put(key, cm);
/*      */       }
/*      */     }
/*  357 */     this.structureTreeRoot.classes = newClassMap;
/*      */     
/*  359 */     PdfArray kids = this.structureTreeRoot.getAsArray(PdfName.K);
/*  360 */     if (kids != null) {
/*  361 */       for (int i = 0; i < kids.size(); i++) {
/*  362 */         PdfIndirectReference iref = (PdfIndirectReference)kids.getPdfObject(i);
/*  363 */         RefKey key = new RefKey(iref);
/*  364 */         if (!activeKeys.contains(key)) kids.remove(i--);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected PdfImportedPage getImportedPageImpl(PdfReader reader, int pageNumber) {
/*  370 */     if (this.currentPdfReaderInstance != null) {
/*  371 */       if (this.currentPdfReaderInstance.getReader() != reader)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  381 */         this.currentPdfReaderInstance = super.getPdfReaderInstance(reader);
/*      */       }
/*      */     }
/*      */     else {
/*  385 */       this.currentPdfReaderInstance = super.getPdfReaderInstance(reader);
/*      */     }
/*      */     
/*      */ 
/*  389 */     return this.currentPdfReaderInstance.getImportedPage(pageNumber);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfIndirectReference copyIndirect(PRIndirectReference in, boolean keepStructure, boolean directRootKids)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  403 */     RefKey key = new RefKey(in);
/*  404 */     IndirectReferences iRef = (IndirectReferences)this.indirects.get(key);
/*  405 */     PdfObject obj = PdfReader.getPdfObjectRelease(in);
/*  406 */     if ((keepStructure) && (directRootKids) && 
/*  407 */       ((obj instanceof PdfDictionary))) {
/*  408 */       PdfDictionary dict = (PdfDictionary)obj;
/*  409 */       if (dict.contains(PdfName.PG))
/*  410 */         return null;
/*      */     }
/*      */     PdfIndirectReference theRef;
/*  413 */     if (iRef != null) {
/*  414 */       PdfIndirectReference theRef = iRef.getRef();
/*  415 */       if (iRef.getCopied()) {
/*  416 */         return theRef;
/*      */       }
/*      */     }
/*      */     else {
/*  420 */       theRef = this.body.getPdfIndirectReference();
/*  421 */       iRef = new IndirectReferences(theRef);
/*  422 */       this.indirects.put(key, iRef);
/*      */     }
/*      */     
/*  425 */     if ((obj != null) && (obj.isDictionary())) {
/*  426 */       PdfObject type = PdfReader.getPdfObjectRelease(((PdfDictionary)obj).get(PdfName.TYPE));
/*  427 */       if (type != null) {
/*  428 */         if (PdfName.PAGE.equals(type)) {
/*  429 */           return theRef;
/*      */         }
/*  431 */         if (PdfName.CATALOG.equals(type)) {
/*  432 */           LOGGER.warn(MessageLocalization.getComposedMessage("make.copy.of.catalog.dictionary.is.forbidden", new Object[0]));
/*  433 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*  437 */     iRef.setCopied();
/*  438 */     if (obj != null) this.parentObjects.put(obj, in);
/*  439 */     PdfObject res = copyObject(obj, keepStructure, directRootKids);
/*  440 */     if (this.disableIndirects.contains(obj))
/*  441 */       iRef.setNotCopied();
/*  442 */     if (res != null)
/*      */     {
/*  444 */       addToBody(res, theRef);
/*  445 */       return theRef;
/*      */     }
/*      */     
/*  448 */     this.indirects.remove(key);
/*  449 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfIndirectReference copyIndirect(PRIndirectReference in)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  464 */     return copyIndirect(in, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary copyDictionary(PdfDictionary in, boolean keepStruct, boolean directRootKids)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  473 */     PdfDictionary out = new PdfDictionary(in.size());
/*  474 */     PdfObject type = PdfReader.getPdfObjectRelease(in.get(PdfName.TYPE));
/*      */     
/*  476 */     if (keepStruct)
/*      */     {
/*  478 */       if ((directRootKids) && (in.contains(PdfName.PG)))
/*      */       {
/*  480 */         PdfObject curr = in;
/*  481 */         this.disableIndirects.add(curr);
/*  482 */         while ((this.parentObjects.containsKey(curr)) && (!this.disableIndirects.contains(curr))) {
/*  483 */           curr = (PdfObject)this.parentObjects.get(curr);
/*  484 */           this.disableIndirects.add(curr);
/*      */         }
/*  486 */         return null;
/*      */       }
/*      */       
/*  489 */       PdfName structType = in.getAsName(PdfName.S);
/*  490 */       this.structTreeController.addRole(structType);
/*  491 */       this.structTreeController.addClass(in); }
/*      */     PdfName key;
/*  493 */     if ((this.structTreeController != null) && (this.structTreeController.reader != null) && ((in.contains(PdfName.STRUCTPARENTS)) || (in.contains(PdfName.STRUCTPARENT)))) {
/*  494 */       key = PdfName.STRUCTPARENT;
/*  495 */       if (in.contains(PdfName.STRUCTPARENTS)) {
/*  496 */         key = PdfName.STRUCTPARENTS;
/*      */       }
/*  498 */       PdfObject value = in.get(key);
/*  499 */       out.put(key, new PdfNumber(this.currentStructArrayNumber));
/*  500 */       this.structTreeController.copyStructTreeForPage((PdfNumber)value, this.currentStructArrayNumber++);
/*      */     }
/*  502 */     for (Object element : in.getKeys()) {
/*  503 */       PdfName key = (PdfName)element;
/*  504 */       PdfObject value = in.get(key);
/*  505 */       if ((this.structTreeController == null) || (this.structTreeController.reader == null) || ((!key.equals(PdfName.STRUCTPARENTS)) && (!key.equals(PdfName.STRUCTPARENT))))
/*      */       {
/*      */ 
/*  508 */         if (PdfName.PAGE.equals(type)) {
/*  509 */           if ((!key.equals(PdfName.B)) && (!key.equals(PdfName.PARENT))) {
/*  510 */             this.parentObjects.put(value, in);
/*  511 */             PdfObject res = copyObject(value, keepStruct, directRootKids);
/*  512 */             if (res != null)
/*  513 */               out.put(key, res);
/*      */           }
/*      */         } else {
/*      */           PdfObject res;
/*      */           PdfObject res;
/*  518 */           if ((this.tagged) && (value.isIndirect()) && (isStructTreeRootReference((PRIndirectReference)value))) {
/*  519 */             res = this.structureTreeRoot.getReference();
/*      */           } else {
/*  521 */             res = copyObject(value, keepStruct, directRootKids);
/*      */           }
/*  523 */           if (res != null)
/*  524 */             out.put(key, res);
/*      */         }
/*      */       }
/*      */     }
/*  528 */     return out;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary copyDictionary(PdfDictionary in)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  537 */     return copyDictionary(in, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */   protected PdfStream copyStream(PRStream in)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  544 */     PRStream out = new PRStream(in, null);
/*      */     
/*  546 */     for (Object element : in.getKeys()) {
/*  547 */       PdfName key = (PdfName)element;
/*  548 */       PdfObject value = in.get(key);
/*  549 */       this.parentObjects.put(value, in);
/*  550 */       PdfObject res = copyObject(value);
/*  551 */       if (res != null) {
/*  552 */         out.put(key, res);
/*      */       }
/*      */     }
/*  555 */     return out;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfArray copyArray(PdfArray in, boolean keepStruct, boolean directRootKids)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  563 */     PdfArray out = new PdfArray(in.size());
/*      */     
/*  565 */     for (Iterator<PdfObject> i = in.listIterator(); i.hasNext();) {
/*  566 */       PdfObject value = (PdfObject)i.next();
/*  567 */       this.parentObjects.put(value, in);
/*  568 */       PdfObject res = copyObject(value, keepStruct, directRootKids);
/*  569 */       if (res != null)
/*  570 */         out.add(res);
/*      */     }
/*  572 */     return out;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfArray copyArray(PdfArray in)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  580 */     return copyArray(in, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */   protected PdfObject copyObject(PdfObject in, boolean keepStruct, boolean directRootKids)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  587 */     if (in == null)
/*  588 */       return PdfNull.PDFNULL;
/*  589 */     switch (in.type) {
/*      */     case 6: 
/*  591 */       return copyDictionary((PdfDictionary)in, keepStruct, directRootKids);
/*      */     case 10: 
/*  593 */       if ((!keepStruct) && (!directRootKids))
/*      */       {
/*  595 */         return copyIndirect((PRIndirectReference)in);
/*      */       }
/*  597 */       return copyIndirect((PRIndirectReference)in, keepStruct, directRootKids);
/*      */     case 5: 
/*  599 */       return copyArray((PdfArray)in, keepStruct, directRootKids);
/*      */     case 0: 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 8: 
/*  606 */       return in;
/*      */     case 7: 
/*  608 */       return copyStream((PRStream)in);
/*      */     }
/*      */     
/*  611 */     if (in.type < 0) {
/*  612 */       String lit = ((PdfLiteral)in).toString();
/*  613 */       if ((lit.equals("true")) || (lit.equals("false"))) {
/*  614 */         return new PdfBoolean(lit);
/*      */       }
/*  616 */       return new PdfLiteral(lit);
/*      */     }
/*  618 */     System.out.println("CANNOT COPY type " + in.type);
/*  619 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfObject copyObject(PdfObject in)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  627 */     return copyObject(in, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected int setFromIPage(PdfImportedPage iPage)
/*      */   {
/*  634 */     int pageNum = iPage.getPageNumber();
/*  635 */     PdfReaderInstance inst = this.currentPdfReaderInstance = iPage.getPdfReaderInstance();
/*  636 */     this.reader = inst.getReader();
/*  637 */     setFromReader(this.reader);
/*  638 */     return pageNum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void setFromReader(PdfReader reader)
/*      */   {
/*  645 */     this.reader = reader;
/*  646 */     this.indirects = ((HashMap)this.indirectMap.get(reader));
/*  647 */     if (this.indirects == null) {
/*  648 */       this.indirects = new HashMap();
/*  649 */       this.indirectMap.put(reader, this.indirects);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addPage(PdfImportedPage iPage)
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  658 */     if ((this.mergeFields) && (!this.mergeFieldsInternalCall)) {
/*  659 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("1.method.cannot.be.used.in.mergeFields.mode.please.use.addDocument", new Object[] { "addPage" }));
/*      */     }
/*      */     
/*  662 */     int pageNum = setFromIPage(iPage);
/*  663 */     PdfDictionary thePage = this.reader.getPageN(pageNum);
/*  664 */     PRIndirectReference origRef = this.reader.getPageOrigRef(pageNum);
/*  665 */     this.reader.releasePage(pageNum);
/*  666 */     RefKey key = new RefKey(origRef);
/*      */     
/*  668 */     IndirectReferences iRef = (IndirectReferences)this.indirects.get(key);
/*  669 */     if ((iRef != null) && (!iRef.getCopied())) {
/*  670 */       this.pageReferences.add(iRef.getRef());
/*  671 */       iRef.setCopied();
/*      */     }
/*  673 */     PdfIndirectReference pageRef = getCurrentPage();
/*  674 */     if (iRef == null) {
/*  675 */       iRef = new IndirectReferences(pageRef);
/*  676 */       this.indirects.put(key, iRef);
/*      */     }
/*  678 */     iRef.setCopied();
/*  679 */     if (this.tagged)
/*  680 */       this.structTreeRootReference = ((PRIndirectReference)this.reader.getCatalog().get(PdfName.STRUCTTREEROOT));
/*  681 */     PdfDictionary newPage = copyDictionary(thePage);
/*  682 */     if (this.mergeFields) {
/*  683 */       ImportedPage importedPage = (ImportedPage)this.importedPages.get(this.importedPages.size() - 1);
/*  684 */       importedPage.annotsIndirectReference = this.body.getPdfIndirectReference();
/*  685 */       newPage.put(PdfName.ANNOTS, importedPage.annotsIndirectReference);
/*      */     }
/*  687 */     this.root.addPage(newPage);
/*  688 */     iPage.setCopied();
/*  689 */     this.currentPageNumber += 1;
/*  690 */     this.pdf.setPageCount(this.currentPageNumber);
/*  691 */     this.structTreeRootReference = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPage(Rectangle rect, int rotation)
/*      */     throws DocumentException
/*      */   {
/*  702 */     if ((this.mergeFields) && (!this.mergeFieldsInternalCall)) {
/*  703 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("1.method.cannot.be.used.in.mergeFields.mode.please.use.addDocument", new Object[] { "addPage" }));
/*      */     }
/*  705 */     PdfRectangle mediabox = new PdfRectangle(rect, rotation);
/*  706 */     PageResources resources = new PageResources();
/*  707 */     PdfPage page = new PdfPage(mediabox, new HashMap(), resources.getResources(), 0);
/*  708 */     page.put(PdfName.TABS, getTabs());
/*  709 */     this.root.addPage(page);
/*  710 */     this.currentPageNumber += 1;
/*  711 */     this.pdf.setPageCount(this.currentPageNumber);
/*      */   }
/*      */   
/*      */   public void addDocument(PdfReader reader, List<Integer> pagesToKeep) throws DocumentException, IOException {
/*  715 */     if (this.indirectMap.containsKey(reader)) {
/*  716 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("document.1.has.already.been.added", new Object[] { reader.toString() }));
/*      */     }
/*  718 */     reader.selectPages(pagesToKeep, false);
/*  719 */     addDocument(reader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyDocumentFields(PdfReader reader)
/*      */     throws DocumentException, IOException
/*      */   {
/*  729 */     if (!this.document.isOpen()) {
/*  730 */       throw new DocumentException(MessageLocalization.getComposedMessage("the.document.is.not.open.yet.you.can.only.add.meta.information", new Object[0]));
/*      */     }
/*      */     
/*  733 */     if (this.indirectMap.containsKey(reader)) {
/*  734 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("document.1.has.already.been.added", new Object[] { reader.toString() }));
/*      */     }
/*      */     
/*  737 */     if (!reader.isOpenedWithFullPermissions()) {
/*  738 */       throw new BadPasswordException(MessageLocalization.getComposedMessage("pdfreader.not.opened.with.owner.password", new Object[0]));
/*      */     }
/*  740 */     if (!this.mergeFields) {
/*  741 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("1.method.can.be.only.used.in.mergeFields.mode.please.use.addDocument", new Object[] { "copyDocumentFields" }));
/*      */     }
/*  743 */     this.indirects = new HashMap();
/*  744 */     this.indirectMap.put(reader, this.indirects);
/*      */     
/*  746 */     reader.consolidateNamedDestinations();
/*  747 */     reader.shuffleSubsetNames();
/*  748 */     if ((this.tagged) && (PdfStructTreeController.checkTagged(reader))) {
/*  749 */       this.structTreeRootReference = ((PRIndirectReference)reader.getCatalog().get(PdfName.STRUCTTREEROOT));
/*  750 */       if (this.structTreeController != null) {
/*  751 */         if (reader != this.structTreeController.reader)
/*  752 */           this.structTreeController.setReader(reader);
/*      */       } else {
/*  754 */         this.structTreeController = new PdfStructTreeController(reader, this);
/*      */       }
/*      */     }
/*      */     
/*  758 */     List<PdfObject> annotationsToBeCopied = new ArrayList();
/*      */     
/*  760 */     for (int i = 1; i <= reader.getNumberOfPages(); i++) {
/*  761 */       PdfDictionary page = reader.getPageNRelease(i);
/*  762 */       if ((page != null) && (page.contains(PdfName.ANNOTS))) {
/*  763 */         PdfArray annots = page.getAsArray(PdfName.ANNOTS);
/*  764 */         if ((annots != null) && (annots.size() > 0)) {
/*  765 */           if (this.importedPages.size() < i)
/*  766 */             throw new DocumentException(MessageLocalization.getComposedMessage("there.are.not.enough.imported.pages.for.copied.fields", new Object[0]));
/*  767 */           ((HashMap)this.indirectMap.get(reader)).put(new RefKey(reader.pageRefs.getPageOrigRef(i)), new IndirectReferences((PdfIndirectReference)this.pageReferences.get(i - 1)));
/*  768 */           for (int j = 0; j < annots.size(); j++) {
/*  769 */             PdfDictionary annot = annots.getAsDict(j);
/*  770 */             if (annot != null) {
/*  771 */               annot.put(annotId, new PdfNumber(++annotIdCnt));
/*  772 */               annotationsToBeCopied.add(annots.getPdfObject(j));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  779 */     for (PdfObject annot : annotationsToBeCopied) {
/*  780 */       copyObject(annot);
/*      */     }
/*      */     
/*  783 */     if ((this.tagged) && (this.structTreeController != null)) {
/*  784 */       this.structTreeController.attachStructTreeRootKids(null);
/*      */     }
/*  786 */     AcroFields acro = reader.getAcroFields();
/*  787 */     boolean needapp = !acro.isGenerateAppearances();
/*  788 */     if (needapp)
/*  789 */       this.needAppearances = true;
/*  790 */     this.fields.add(acro);
/*  791 */     updateCalculationOrder(reader);
/*  792 */     this.structTreeRootReference = null;
/*      */   }
/*      */   
/*      */   public void addDocument(PdfReader reader) throws DocumentException, IOException {
/*  796 */     if (!this.document.isOpen()) {
/*  797 */       throw new DocumentException(MessageLocalization.getComposedMessage("the.document.is.not.open.yet.you.can.only.add.meta.information", new Object[0]));
/*      */     }
/*  799 */     if (this.indirectMap.containsKey(reader)) {
/*  800 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("document.1.has.already.been.added", new Object[] { reader.toString() }));
/*      */     }
/*  802 */     if (!reader.isOpenedWithFullPermissions())
/*  803 */       throw new BadPasswordException(MessageLocalization.getComposedMessage("pdfreader.not.opened.with.owner.password", new Object[0]));
/*  804 */     if (this.mergeFields) {
/*  805 */       reader.consolidateNamedDestinations();
/*  806 */       reader.shuffleSubsetNames();
/*  807 */       for (int i = 1; i <= reader.getNumberOfPages(); i++) {
/*  808 */         PdfDictionary page = reader.getPageNRelease(i);
/*  809 */         if ((page != null) && (page.contains(PdfName.ANNOTS))) {
/*  810 */           PdfArray annots = page.getAsArray(PdfName.ANNOTS);
/*  811 */           if (annots != null) {
/*  812 */             for (int j = 0; j < annots.size(); j++) {
/*  813 */               PdfDictionary annot = annots.getAsDict(j);
/*  814 */               if (annot != null)
/*  815 */                 annot.put(annotId, new PdfNumber(++annotIdCnt));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  820 */       AcroFields acro = reader.getAcroFields();
/*      */       
/*      */ 
/*  823 */       boolean needapp = !acro.isGenerateAppearances();
/*  824 */       if (needapp)
/*  825 */         this.needAppearances = true;
/*  826 */       this.fields.add(acro);
/*  827 */       updateCalculationOrder(reader);
/*      */     }
/*  829 */     boolean tagged = (this.tagged) && (PdfStructTreeController.checkTagged(reader));
/*  830 */     this.mergeFieldsInternalCall = true;
/*  831 */     for (int i = 1; i <= reader.getNumberOfPages(); i++) {
/*  832 */       addPage(getImportedPage(reader, i, tagged));
/*      */     }
/*  834 */     this.mergeFieldsInternalCall = false;
/*      */   }
/*      */   
/*      */   public PdfIndirectObject addToBody(PdfObject object, PdfIndirectReference ref) throws IOException
/*      */   {
/*  839 */     return addToBody(object, ref, false);
/*      */   }
/*      */   
/*      */   public PdfIndirectObject addToBody(PdfObject object, PdfIndirectReference ref, boolean formBranching) throws IOException
/*      */   {
/*  844 */     if (formBranching)
/*  845 */       updateReferences(object);
/*      */     PdfIndirectObject iobj;
/*      */     PdfIndirectObject iobj;
/*  848 */     if (((this.tagged) || (this.mergeFields)) && (this.indirectObjects != null) && ((object.isArray()) || (object.isDictionary()) || (object.isStream()) || (object.isNull()))) {
/*  849 */       RefKey key = new RefKey(ref);
/*  850 */       PdfIndirectObject obj = (PdfIndirectObject)this.indirectObjects.get(key);
/*  851 */       if (obj == null) {
/*  852 */         obj = new PdfIndirectObject(ref, object, this);
/*  853 */         this.indirectObjects.put(key, obj);
/*      */       }
/*  855 */       iobj = obj;
/*      */     } else {
/*  857 */       iobj = super.addToBody(object, ref);
/*      */     }
/*  859 */     if ((this.mergeFields) && (object.isDictionary())) {
/*  860 */       PdfNumber annotId = ((PdfDictionary)object).getAsNumber(annotId);
/*  861 */       if (annotId != null) {
/*  862 */         if (formBranching) {
/*  863 */           this.mergedMap.put(Integer.valueOf(annotId.intValue()), iobj);
/*  864 */           this.mergedSet.add(iobj);
/*      */         } else {
/*  866 */           this.unmergedMap.put(Integer.valueOf(annotId.intValue()), iobj);
/*  867 */           this.unmergedIndirectRefsMap.put(new RefKey(iobj.number, iobj.generation), iobj);
/*      */         }
/*      */       }
/*      */     }
/*  871 */     return iobj;
/*      */   }
/*      */   
/*      */   protected void cacheObject(PdfIndirectObject iobj)
/*      */   {
/*  876 */     if (((this.tagged) || (this.mergeFields)) && (this.indirectObjects != null)) {
/*  877 */       this.savedObjects.add(iobj);
/*  878 */       RefKey key = new RefKey(iobj.number, iobj.generation);
/*  879 */       if (!this.indirectObjects.containsKey(key)) { this.indirectObjects.put(key, iobj);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void flushAcroFields()
/*      */     throws IOException, BadPdfFormatException
/*      */   {
/*  893 */     if (this.mergeFields) {
/*      */       try
/*      */       {
/*  896 */         for (Iterator localIterator1 = this.importedPages.iterator(); localIterator1.hasNext();) { page = (ImportedPage)localIterator1.next();
/*  897 */           PdfDictionary pageDict = page.reader.getPageN(page.pageNumber);
/*  898 */           if (pageDict != null) {
/*  899 */             PdfArray pageFields = pageDict.getAsArray(PdfName.ANNOTS);
/*  900 */             if ((pageFields != null) && (pageFields.size() != 0))
/*      */             {
/*  902 */               for (AcroFields.Item items : page.reader.getAcroFields().getFields().values()) {
/*  903 */                 for (PdfIndirectReference ref : items.widget_refs) {
/*  904 */                   pageFields.arrayList.remove(ref);
/*      */                 }
/*      */               }
/*  907 */               this.indirects = ((HashMap)this.indirectMap.get(page.reader));
/*  908 */               for (PdfObject ref : pageFields.arrayList)
/*  909 */                 page.mergedFields.add(copyObject(ref));
/*      */             }
/*      */           } }
/*      */         ImportedPage page;
/*  913 */         for (PdfReader reader : this.indirectMap.keySet()) {
/*  914 */           reader.removeFields();
/*      */         }
/*  916 */         mergeFields();
/*  917 */         createAcroForms();
/*      */       }
/*      */       catch (ClassCastException localClassCastException1) {}finally
/*      */       {
/*  921 */         if (!this.tagged) {
/*  922 */           flushIndirectObjects();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void fixTaggedStructure() throws IOException {
/*  929 */     HashMap<Integer, PdfIndirectReference> numTree = this.structureTreeRoot.getNumTree();
/*  930 */     HashSet<RefKey> activeKeys = new HashSet();
/*  931 */     ArrayList<PdfIndirectReference> actives = new ArrayList();
/*  932 */     int pageRefIndex = 0;
/*      */     
/*  934 */     if ((this.mergeFields) && (this.acroForm != null)) {
/*  935 */       actives.add(this.acroForm);
/*  936 */       activeKeys.add(new RefKey(this.acroForm));
/*      */     }
/*  938 */     for (PdfIndirectReference page : this.pageReferences) {
/*  939 */       actives.add(page);
/*  940 */       activeKeys.add(new RefKey(page));
/*      */     }
/*      */     
/*      */     RefKey numKey;
/*  944 */     for (int i = numTree.size() - 1; i >= 0; i--) {
/*  945 */       PdfIndirectReference currNum = (PdfIndirectReference)numTree.get(Integer.valueOf(i));
/*  946 */       if (currNum != null)
/*      */       {
/*      */ 
/*  949 */         numKey = new RefKey(currNum);
/*  950 */         PdfObject obj = ((PdfIndirectObject)this.indirectObjects.get(numKey)).object;
/*  951 */         if (obj.isDictionary()) {
/*  952 */           boolean addActiveKeys = false;
/*  953 */           if (this.pageReferences.contains(((PdfDictionary)obj).get(PdfName.PG))) {
/*  954 */             addActiveKeys = true;
/*      */           } else {
/*  956 */             PdfDictionary k = PdfStructTreeController.getKDict((PdfDictionary)obj);
/*  957 */             if ((k != null) && (this.pageReferences.contains(k.get(PdfName.PG)))) {
/*  958 */               addActiveKeys = true;
/*      */             }
/*      */           }
/*  961 */           if (addActiveKeys) {
/*  962 */             activeKeys.add(numKey);
/*  963 */             actives.add(currNum);
/*      */           } else {
/*  965 */             numTree.remove(Integer.valueOf(i));
/*      */           }
/*  967 */         } else if (obj.isArray()) {
/*  968 */           activeKeys.add(numKey);
/*  969 */           actives.add(currNum);
/*  970 */           PdfArray currNums = (PdfArray)obj;
/*  971 */           PdfIndirectReference currPage = (PdfIndirectReference)this.pageReferences.get(pageRefIndex++);
/*  972 */           actives.add(currPage);
/*  973 */           activeKeys.add(new RefKey(currPage));
/*  974 */           PdfIndirectReference prevKid = null;
/*  975 */           for (int j = 0; j < currNums.size(); j++) {
/*  976 */             PdfIndirectReference currKid = (PdfIndirectReference)currNums.getDirectObject(j);
/*  977 */             if (!currKid.equals(prevKid)) {
/*  978 */               RefKey kidKey = new RefKey(currKid);
/*  979 */               activeKeys.add(kidKey);
/*  980 */               actives.add(currKid);
/*      */               
/*  982 */               PdfIndirectObject iobj = (PdfIndirectObject)this.indirectObjects.get(kidKey);
/*  983 */               if (iobj.object.isDictionary()) {
/*  984 */                 PdfDictionary dict = (PdfDictionary)iobj.object;
/*  985 */                 PdfIndirectReference pg = (PdfIndirectReference)dict.get(PdfName.PG);
/*      */                 
/*  987 */                 if ((pg != null) && (!this.pageReferences.contains(pg)) && (!pg.equals(currPage))) {
/*  988 */                   dict.put(PdfName.PG, currPage);
/*  989 */                   PdfArray kids = dict.getAsArray(PdfName.K);
/*  990 */                   if (kids != null) {
/*  991 */                     PdfObject firstKid = kids.getDirectObject(0);
/*  992 */                     if (firstKid.isNumber()) kids.remove(0);
/*      */                   }
/*      */                 }
/*      */               }
/*  996 */               prevKid = currKid;
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/* 1001 */     Object activeClassMaps = new HashSet();
/*      */     
/* 1003 */     findActives(actives, activeKeys, (HashSet)activeClassMaps);
/*      */     
/* 1005 */     ArrayList<PdfIndirectReference> newRefs = findActiveParents(activeKeys);
/*      */     
/* 1007 */     fixPgKey(newRefs, activeKeys);
/*      */     
/* 1009 */     fixStructureTreeRoot(activeKeys, (HashSet)activeClassMaps);
/*      */     
/* 1011 */     for (Map.Entry<RefKey, PdfIndirectObject> entry : this.indirectObjects.entrySet()) {
/* 1012 */       if (!activeKeys.contains(entry.getKey())) {
/* 1013 */         entry.setValue(null);
/*      */ 
/*      */       }
/* 1016 */       else if (((PdfIndirectObject)entry.getValue()).object.isArray()) {
/* 1017 */         removeInactiveReferences((PdfArray)((PdfIndirectObject)entry.getValue()).object, activeKeys);
/* 1018 */       } else if (((PdfIndirectObject)entry.getValue()).object.isDictionary()) {
/* 1019 */         PdfObject kids = ((PdfDictionary)((PdfIndirectObject)entry.getValue()).object).get(PdfName.K);
/* 1020 */         if ((kids != null) && (kids.isArray())) {
/* 1021 */           removeInactiveReferences((PdfArray)kids, activeKeys);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void removeInactiveReferences(PdfArray array, HashSet<RefKey> activeKeys) {
/* 1028 */     for (int i = 0; i < array.size(); i++) {
/* 1029 */       PdfObject obj = array.getPdfObject(i);
/* 1030 */       if (((obj.type() == 0) && (!activeKeys.contains(new RefKey((PdfIndirectReference)obj)))) || (
/* 1031 */         (obj.isDictionary()) && (containsInactivePg((PdfDictionary)obj, activeKeys))))
/* 1032 */         array.remove(i--);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean containsInactivePg(PdfDictionary dict, HashSet<RefKey> activeKeys) {
/* 1037 */     PdfObject pg = dict.get(PdfName.PG);
/* 1038 */     if ((pg != null) && (!activeKeys.contains(new RefKey((PdfIndirectReference)pg))))
/* 1039 */       return true;
/* 1040 */     return false;
/*      */   }
/*      */   
/*      */   private ArrayList<PdfIndirectReference> findActiveParents(HashSet<RefKey> activeKeys)
/*      */   {
/* 1045 */     ArrayList<PdfIndirectReference> newRefs = new ArrayList();
/* 1046 */     ArrayList<RefKey> tmpActiveKeys = new ArrayList(activeKeys);
/* 1047 */     for (int i = 0; i < tmpActiveKeys.size(); i++) {
/* 1048 */       PdfIndirectObject iobj = (PdfIndirectObject)this.indirectObjects.get(tmpActiveKeys.get(i));
/* 1049 */       if ((iobj != null) && (iobj.object.isDictionary())) {
/* 1050 */         PdfObject parent = ((PdfDictionary)iobj.object).get(PdfName.P);
/* 1051 */         if ((parent != null) && (parent.type() == 0)) {
/* 1052 */           RefKey key = new RefKey((PdfIndirectReference)parent);
/* 1053 */           if (!activeKeys.contains(key)) {
/* 1054 */             activeKeys.add(key);
/* 1055 */             tmpActiveKeys.add(key);
/* 1056 */             newRefs.add((PdfIndirectReference)parent);
/*      */           }
/*      */         }
/*      */       } }
/* 1060 */     return newRefs;
/*      */   }
/*      */   
/*      */   private void fixPgKey(ArrayList<PdfIndirectReference> newRefs, HashSet<RefKey> activeKeys) {
/* 1064 */     for (PdfIndirectReference iref : newRefs) {
/* 1065 */       PdfIndirectObject iobj = (PdfIndirectObject)this.indirectObjects.get(new RefKey(iref));
/* 1066 */       if ((iobj != null) && (iobj.object.isDictionary())) {
/* 1067 */         PdfDictionary dict = (PdfDictionary)iobj.object;
/* 1068 */         PdfObject pg = dict.get(PdfName.PG);
/* 1069 */         if ((pg != null) && (!activeKeys.contains(new RefKey((PdfIndirectReference)pg)))) {
/* 1070 */           PdfArray kids = dict.getAsArray(PdfName.K);
/* 1071 */           if (kids != null)
/* 1072 */             for (int i = 0; i < kids.size(); i++) {
/* 1073 */               PdfObject obj = kids.getPdfObject(i);
/* 1074 */               if (obj.type() != 0) {
/* 1075 */                 kids.remove(i--);
/*      */               } else {
/* 1077 */                 PdfIndirectObject kid = (PdfIndirectObject)this.indirectObjects.get(new RefKey((PdfIndirectReference)obj));
/* 1078 */                 if ((kid != null) && (kid.object.isDictionary())) {
/* 1079 */                   PdfObject kidPg = ((PdfDictionary)kid.object).get(PdfName.PG);
/* 1080 */                   if ((kidPg != null) && (activeKeys.contains(new RefKey((PdfIndirectReference)kidPg)))) {
/* 1081 */                     dict.put(PdfName.PG, kidPg);
/* 1082 */                     break;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/* 1092 */   private void findActives(ArrayList<PdfIndirectReference> actives, HashSet<RefKey> activeKeys, HashSet<PdfName> activeClassMaps) { for (int i = 0; i < actives.size(); i++) {
/* 1093 */       RefKey key = new RefKey((PdfIndirectReference)actives.get(i));
/* 1094 */       PdfIndirectObject iobj = (PdfIndirectObject)this.indirectObjects.get(key);
/* 1095 */       if ((iobj != null) && (iobj.object != null)) {
/* 1096 */         switch (iobj.object.type()) {
/*      */         case 0: 
/* 1098 */           findActivesFromReference((PdfIndirectReference)iobj.object, actives, activeKeys);
/* 1099 */           break;
/*      */         case 5: 
/* 1101 */           findActivesFromArray((PdfArray)iobj.object, actives, activeKeys, activeClassMaps);
/* 1102 */           break;
/*      */         case 6: 
/*      */         case 7: 
/* 1105 */           findActivesFromDict((PdfDictionary)iobj.object, actives, activeKeys, activeClassMaps);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void findActivesFromReference(PdfIndirectReference iref, ArrayList<PdfIndirectReference> actives, HashSet<RefKey> activeKeys) {
/* 1112 */     RefKey key = new RefKey(iref);
/* 1113 */     PdfIndirectObject iobj = (PdfIndirectObject)this.indirectObjects.get(key);
/* 1114 */     if ((iobj != null) && (iobj.object.isDictionary()) && (containsInactivePg((PdfDictionary)iobj.object, activeKeys))) { return;
/*      */     }
/* 1116 */     if (!activeKeys.contains(key)) {
/* 1117 */       activeKeys.add(key);
/* 1118 */       actives.add(iref);
/*      */     }
/*      */   }
/*      */   
/*      */   private void findActivesFromArray(PdfArray array, ArrayList<PdfIndirectReference> actives, HashSet<RefKey> activeKeys, HashSet<PdfName> activeClassMaps) {
/* 1123 */     for (PdfObject obj : array) {
/* 1124 */       switch (obj.type()) {
/*      */       case 0: 
/* 1126 */         findActivesFromReference((PdfIndirectReference)obj, actives, activeKeys);
/* 1127 */         break;
/*      */       case 5: 
/* 1129 */         findActivesFromArray((PdfArray)obj, actives, activeKeys, activeClassMaps);
/* 1130 */         break;
/*      */       case 6: 
/*      */       case 7: 
/* 1133 */         findActivesFromDict((PdfDictionary)obj, actives, activeKeys, activeClassMaps);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void findActivesFromDict(PdfDictionary dict, ArrayList<PdfIndirectReference> actives, HashSet<RefKey> activeKeys, HashSet<PdfName> activeClassMaps)
/*      */   {
/* 1140 */     if (containsInactivePg(dict, activeKeys)) return;
/* 1141 */     for (PdfName key : dict.getKeys()) {
/* 1142 */       PdfObject obj = dict.get(key);
/* 1143 */       if (!key.equals(PdfName.P)) {
/* 1144 */         if (key.equals(PdfName.C)) {
/* 1145 */           if (obj.isArray()) {
/* 1146 */             for (PdfObject cm : (PdfArray)obj) {
/* 1147 */               if (cm.isName()) { activeClassMaps.add((PdfName)cm);
/*      */               }
/*      */             }
/* 1150 */           } else if (obj.isName()) activeClassMaps.add((PdfName)obj);
/*      */         }
/*      */         else
/* 1153 */           switch (obj.type()) {
/*      */           case 0: 
/* 1155 */             findActivesFromReference((PdfIndirectReference)obj, actives, activeKeys);
/* 1156 */             break;
/*      */           case 5: 
/* 1158 */             findActivesFromArray((PdfArray)obj, actives, activeKeys, activeClassMaps);
/* 1159 */             break;
/*      */           case 6: 
/*      */           case 7: 
/* 1162 */             findActivesFromDict((PdfDictionary)obj, actives, activeKeys, activeClassMaps);
/*      */           }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void flushIndirectObjects() throws IOException {
/* 1169 */     for (Iterator localIterator = this.savedObjects.iterator(); localIterator.hasNext();) { iobj = (PdfIndirectObject)localIterator.next();
/* 1170 */       this.indirectObjects.remove(new RefKey(iobj.number, iobj.generation)); }
/* 1171 */     Object inactives = new HashSet();
/* 1172 */     for (PdfIndirectObject iobj = this.indirectObjects.entrySet().iterator(); iobj.hasNext();) { entry = (Map.Entry)iobj.next();
/* 1173 */       if (entry.getValue() != null) {
/* 1174 */         writeObjectToBody((PdfIndirectObject)entry.getValue());
/*      */       } else
/* 1176 */         ((HashSet)inactives).add(entry.getKey()); }
/*      */     Map.Entry<RefKey, PdfIndirectObject> entry;
/* 1178 */     ArrayList<PdfWriter.PdfBody.PdfCrossReference> pdfCrossReferences = new ArrayList(this.body.xrefs);
/* 1179 */     for (PdfWriter.PdfBody.PdfCrossReference cr : pdfCrossReferences) {
/* 1180 */       RefKey key = new RefKey(cr.getRefnum(), 0);
/* 1181 */       if (((HashSet)inactives).contains(key))
/* 1182 */         this.body.xrefs.remove(cr);
/*      */     }
/* 1184 */     this.indirectObjects = null;
/*      */   }
/*      */   
/*      */   private void writeObjectToBody(PdfIndirectObject object) throws IOException {
/* 1188 */     boolean skipWriting = false;
/* 1189 */     if (this.mergeFields) {
/* 1190 */       updateAnnotationReferences(object.object);
/* 1191 */       if ((object.object.isDictionary()) || (object.object.isStream())) {
/* 1192 */         PdfDictionary dictionary = (PdfDictionary)object.object;
/* 1193 */         if (this.unmergedIndirectRefsMap.containsKey(new RefKey(object.number, object.generation))) {
/* 1194 */           PdfNumber annotId = dictionary.getAsNumber(annotId);
/* 1195 */           if ((annotId != null) && (this.mergedMap.containsKey(Integer.valueOf(annotId.intValue()))))
/* 1196 */             skipWriting = true;
/*      */         }
/* 1198 */         if (this.mergedSet.contains(object)) {
/* 1199 */           PdfNumber annotId = dictionary.getAsNumber(annotId);
/* 1200 */           if (annotId != null) {
/* 1201 */             PdfIndirectObject unmerged = (PdfIndirectObject)this.unmergedMap.get(Integer.valueOf(annotId.intValue()));
/* 1202 */             if ((unmerged != null) && (unmerged.object.isDictionary())) {
/* 1203 */               PdfNumber structParent = ((PdfDictionary)unmerged.object).getAsNumber(PdfName.STRUCTPARENT);
/* 1204 */               if (structParent != null) {
/* 1205 */                 dictionary.put(PdfName.STRUCTPARENT, structParent);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1212 */     if (!skipWriting) {
/* 1213 */       PdfDictionary dictionary = null;
/* 1214 */       PdfNumber annotId = null;
/* 1215 */       if ((this.mergeFields) && (object.object.isDictionary())) {
/* 1216 */         dictionary = (PdfDictionary)object.object;
/* 1217 */         annotId = dictionary.getAsNumber(annotId);
/* 1218 */         if (annotId != null)
/* 1219 */           dictionary.remove(annotId);
/*      */       }
/* 1221 */       this.body.add(object.object, object.number, object.generation, true);
/* 1222 */       if (annotId != null)
/* 1223 */         dictionary.put(annotId, annotId);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateAnnotationReferences(PdfObject obj) { int i;
/*      */     PdfDictionary dictionary;
/* 1229 */     if (obj.isArray()) {
/* 1230 */       PdfArray array = (PdfArray)obj;
/* 1231 */       for (i = 0; i < array.size(); i++) {
/* 1232 */         PdfObject o = array.getPdfObject(i);
/* 1233 */         if ((o != null) && (o.type() == 0)) {
/* 1234 */           PdfIndirectObject entry = (PdfIndirectObject)this.unmergedIndirectRefsMap.get(new RefKey((PdfIndirectReference)o));
/* 1235 */           if ((entry != null) && 
/* 1236 */             (entry.object.isDictionary())) {
/* 1237 */             PdfNumber annotId = ((PdfDictionary)entry.object).getAsNumber(annotId);
/* 1238 */             if (annotId != null) {
/* 1239 */               PdfIndirectObject merged = (PdfIndirectObject)this.mergedMap.get(Integer.valueOf(annotId.intValue()));
/* 1240 */               if (merged != null) {
/* 1241 */                 array.set(i, merged.getIndirectReference());
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/* 1247 */           updateAnnotationReferences(o);
/*      */         }
/*      */       }
/* 1250 */     } else if ((obj.isDictionary()) || (obj.isStream())) {
/* 1251 */       dictionary = (PdfDictionary)obj;
/* 1252 */       for (PdfName key : dictionary.getKeys()) {
/* 1253 */         PdfObject o = dictionary.get(key);
/* 1254 */         if ((o != null) && (o.type() == 0)) {
/* 1255 */           PdfIndirectObject entry = (PdfIndirectObject)this.unmergedIndirectRefsMap.get(new RefKey((PdfIndirectReference)o));
/* 1256 */           if ((entry != null) && 
/* 1257 */             (entry.object.isDictionary())) {
/* 1258 */             PdfNumber annotId = ((PdfDictionary)entry.object).getAsNumber(annotId);
/* 1259 */             if (annotId != null) {
/* 1260 */               PdfIndirectObject merged = (PdfIndirectObject)this.mergedMap.get(Integer.valueOf(annotId.intValue()));
/* 1261 */               if (merged != null) {
/* 1262 */                 dictionary.put(key, merged.getIndirectReference());
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/* 1268 */           updateAnnotationReferences(o);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateCalculationOrder(PdfReader reader) {
/* 1275 */     PdfDictionary catalog = reader.getCatalog();
/* 1276 */     PdfDictionary acro = catalog.getAsDict(PdfName.ACROFORM);
/* 1277 */     if (acro == null)
/* 1278 */       return;
/* 1279 */     PdfArray co = acro.getAsArray(PdfName.CO);
/* 1280 */     if ((co == null) || (co.size() == 0))
/* 1281 */       return;
/* 1282 */     AcroFields af = reader.getAcroFields();
/* 1283 */     for (int k = 0; k < co.size(); k++) {
/* 1284 */       PdfObject obj = co.getPdfObject(k);
/* 1285 */       if ((obj != null) && (obj.isIndirect()))
/*      */       {
/* 1287 */         String name = getCOName(reader, (PRIndirectReference)obj);
/* 1288 */         if (af.getFieldItem(name) != null)
/*      */         {
/* 1290 */           name = "." + name;
/* 1291 */           if (!this.calculationOrder.contains(name))
/*      */           {
/* 1293 */             this.calculationOrder.add(name); }
/*      */         }
/*      */       }
/*      */     } }
/*      */   
/* 1298 */   private static String getCOName(PdfReader reader, PRIndirectReference ref) { String name = "";
/* 1299 */     while (ref != null) {
/* 1300 */       PdfObject obj = PdfReader.getPdfObject(ref);
/* 1301 */       if ((obj == null) || (obj.type() != 6))
/*      */         break;
/* 1303 */       PdfDictionary dic = (PdfDictionary)obj;
/* 1304 */       PdfString t = dic.getAsString(PdfName.T);
/* 1305 */       if (t != null) {
/* 1306 */         name = t.toUnicodeString() + "." + name;
/*      */       }
/* 1308 */       ref = (PRIndirectReference)dic.get(PdfName.PARENT);
/*      */     }
/* 1310 */     if (name.endsWith("."))
/* 1311 */       name = name.substring(0, name.length() - 2);
/* 1312 */     return name;
/*      */   }
/*      */   
/*      */   private void mergeFields() {
/* 1316 */     int pageOffset = 0;
/* 1317 */     for (int k = 0; k < this.fields.size(); k++) {
/* 1318 */       AcroFields af = (AcroFields)this.fields.get(k);
/* 1319 */       Map<String, AcroFields.Item> fd = af.getFields();
/* 1320 */       if ((pageOffset < this.importedPages.size()) && (((ImportedPage)this.importedPages.get(pageOffset)).reader == af.reader)) {
/* 1321 */         addPageOffsetToField(fd, pageOffset);
/* 1322 */         pageOffset += af.reader.getNumberOfPages();
/*      */       }
/* 1324 */       mergeWithMaster(fd);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addPageOffsetToField(Map<String, AcroFields.Item> fd, int pageOffset) {
/* 1329 */     if (pageOffset == 0)
/* 1330 */       return;
/* 1331 */     for (AcroFields.Item item : fd.values()) {
/* 1332 */       for (int k = 0; k < item.size(); k++) {
/* 1333 */         int p = item.getPage(k).intValue();
/* 1334 */         item.forcePage(k, p + pageOffset);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void mergeWithMaster(Map<String, AcroFields.Item> fd) {
/* 1340 */     for (Map.Entry<String, AcroFields.Item> entry : fd.entrySet()) {
/* 1341 */       String name = (String)entry.getKey();
/* 1342 */       mergeField(name, (AcroFields.Item)entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   private void mergeField(String name, AcroFields.Item item)
/*      */   {
/* 1348 */     HashMap<String, Object> map = this.fieldTree;
/* 1349 */     StringTokenizer tk = new StringTokenizer(name, ".");
/* 1350 */     if (!tk.hasMoreTokens())
/* 1351 */       return;
/*      */     for (;;) {
/* 1353 */       String s = tk.nextToken();
/* 1354 */       Object obj = map.get(s);
/* 1355 */       if (tk.hasMoreTokens()) {
/* 1356 */         if (obj == null) {
/* 1357 */           obj = new LinkedHashMap();
/* 1358 */           map.put(s, obj);
/* 1359 */           map = (HashMap)obj;
/*      */ 
/*      */         }
/* 1362 */         else if ((obj instanceof HashMap)) {
/* 1363 */           map = (HashMap)obj;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1368 */         if ((obj instanceof HashMap))
/* 1369 */           return;
/* 1370 */         PdfDictionary merged = item.getMerged(0);
/* 1371 */         if (obj == null) {
/* 1372 */           PdfDictionary field = new PdfDictionary();
/* 1373 */           if (PdfName.SIG.equals(merged.get(PdfName.FT)))
/* 1374 */             this.hasSignature = true;
/* 1375 */           for (Object element : merged.getKeys()) {
/* 1376 */             PdfName key = (PdfName)element;
/* 1377 */             if (fieldKeys.contains(key))
/* 1378 */               field.put(key, merged.get(key));
/*      */           }
/* 1380 */           Object list = new ArrayList();
/* 1381 */           ((ArrayList)list).add(field);
/* 1382 */           createWidgets((ArrayList)list, item);
/* 1383 */           map.put(s, list);
/*      */         }
/*      */         else {
/* 1386 */           ArrayList<Object> list = (ArrayList)obj;
/* 1387 */           PdfDictionary field = (PdfDictionary)list.get(0);
/* 1388 */           PdfName type1 = (PdfName)field.get(PdfName.FT);
/* 1389 */           PdfName type2 = (PdfName)merged.get(PdfName.FT);
/* 1390 */           if ((type1 == null) || (!type1.equals(type2)))
/* 1391 */             return;
/* 1392 */           int flag1 = 0;
/* 1393 */           PdfObject f1 = field.get(PdfName.FF);
/* 1394 */           if ((f1 != null) && (f1.isNumber()))
/* 1395 */             flag1 = ((PdfNumber)f1).intValue();
/* 1396 */           int flag2 = 0;
/* 1397 */           PdfObject f2 = merged.get(PdfName.FF);
/* 1398 */           if ((f2 != null) && (f2.isNumber()))
/* 1399 */             flag2 = ((PdfNumber)f2).intValue();
/* 1400 */           if (type1.equals(PdfName.BTN)) {
/* 1401 */             if (((flag1 ^ flag2) & 0x10000) != 0)
/* 1402 */               return;
/* 1403 */             if (((flag1 & 0x10000) != 0) || (((flag1 ^ flag2) & 0x8000) == 0)) {}
/*      */ 
/*      */           }
/* 1406 */           else if ((type1.equals(PdfName.CH)) && 
/* 1407 */             (((flag1 ^ flag2) & 0x20000) != 0)) {
/* 1408 */             return;
/*      */           }
/* 1410 */           createWidgets(list, item);
/*      */         }
/* 1412 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void createWidgets(ArrayList<Object> list, AcroFields.Item item) {
/* 1418 */     for (int k = 0; k < item.size(); k++) {
/* 1419 */       list.add(item.getPage(k));
/* 1420 */       PdfDictionary merged = item.getMerged(k);
/* 1421 */       PdfObject dr = merged.get(PdfName.DR);
/* 1422 */       if (dr != null)
/* 1423 */         PdfFormField.mergeResources(this.resources, (PdfDictionary)PdfReader.getPdfObject(dr));
/* 1424 */       PdfDictionary widget = new PdfDictionary();
/* 1425 */       for (Object element : merged.getKeys()) {
/* 1426 */         PdfName key = (PdfName)element;
/* 1427 */         if (widgetKeys.contains(key))
/* 1428 */           widget.put(key, merged.get(key));
/*      */       }
/* 1430 */       widget.put(iTextTag, new PdfNumber(item.getTabOrder(k).intValue() + 1));
/* 1431 */       list.add(widget);
/*      */     }
/*      */   }
/*      */   
/*      */   private PdfObject propagate(PdfObject obj) throws IOException {
/* 1436 */     if (obj == null)
/* 1437 */       return new PdfNull();
/* 1438 */     int i; if (obj.isArray()) {
/* 1439 */       PdfArray a = (PdfArray)obj;
/* 1440 */       for (i = 0; i < a.size(); i++) {
/* 1441 */         a.set(i, propagate(a.getPdfObject(i)));
/*      */       }
/* 1443 */       return a; }
/* 1444 */     if ((obj.isDictionary()) || (obj.isStream())) {
/* 1445 */       PdfDictionary d = (PdfDictionary)obj;
/* 1446 */       for (PdfName key : d.getKeys()) {
/* 1447 */         d.put(key, propagate(d.get(key)));
/*      */       }
/* 1449 */       return d; }
/* 1450 */     if (obj.isIndirect()) {
/* 1451 */       obj = PdfReader.getPdfObject(obj);
/* 1452 */       return addToBody(propagate(obj)).getIndirectReference();
/*      */     }
/* 1454 */     return obj;
/*      */   }
/*      */   
/*      */   private void createAcroForms() throws IOException, BadPdfFormatException {
/* 1458 */     if (this.fieldTree.isEmpty())
/*      */     {
/* 1460 */       for (ImportedPage importedPage : this.importedPages) {
/* 1461 */         if (importedPage.mergedFields.size() > 0)
/* 1462 */           addToBody(importedPage.mergedFields, importedPage.annotsIndirectReference);
/*      */       }
/* 1464 */       return;
/*      */     }
/* 1466 */     PdfDictionary form = new PdfDictionary();
/* 1467 */     form.put(PdfName.DR, propagate(this.resources));
/*      */     
/* 1469 */     if (this.needAppearances) {
/* 1470 */       form.put(PdfName.NEEDAPPEARANCES, PdfBoolean.PDFTRUE);
/*      */     }
/* 1472 */     form.put(PdfName.DA, new PdfString("/Helv 0 Tf 0 g "));
/* 1473 */     this.tabOrder = new HashMap();
/* 1474 */     this.calculationOrderRefs = new ArrayList(this.calculationOrder);
/* 1475 */     form.put(PdfName.FIELDS, branchForm(this.fieldTree, null, ""));
/* 1476 */     if (this.hasSignature)
/* 1477 */       form.put(PdfName.SIGFLAGS, new PdfNumber(3));
/* 1478 */     PdfArray co = new PdfArray();
/* 1479 */     for (int k = 0; k < this.calculationOrderRefs.size(); k++) {
/* 1480 */       Object obj = this.calculationOrderRefs.get(k);
/* 1481 */       if ((obj instanceof PdfIndirectReference))
/* 1482 */         co.add((PdfIndirectReference)obj);
/*      */     }
/* 1484 */     if (co.size() > 0)
/* 1485 */       form.put(PdfName.CO, co);
/* 1486 */     this.acroForm = addToBody(form).getIndirectReference();
/* 1487 */     for (ImportedPage importedPage : this.importedPages)
/* 1488 */       addToBody(importedPage.mergedFields, importedPage.annotsIndirectReference);
/*      */   }
/*      */   
/*      */   private void updateReferences(PdfObject obj) {
/*      */     PdfDictionary dictionary;
/* 1493 */     if ((obj.isDictionary()) || (obj.isStream())) {
/* 1494 */       dictionary = (PdfDictionary)obj;
/* 1495 */       for (PdfName key : dictionary.getKeys()) {
/* 1496 */         PdfObject o = dictionary.get(key);
/* 1497 */         if (o.isIndirect()) {
/* 1498 */           PdfReader reader = ((PRIndirectReference)o).getReader();
/* 1499 */           HashMap<RefKey, IndirectReferences> indirects = (HashMap)this.indirectMap.get(reader);
/* 1500 */           IndirectReferences indRef = (IndirectReferences)indirects.get(new RefKey((PRIndirectReference)o));
/* 1501 */           if (indRef != null) {
/* 1502 */             dictionary.put(key, indRef.getRef());
/*      */           }
/*      */         } else {
/* 1505 */           updateReferences(o);
/*      */         }
/*      */       }
/* 1508 */     } else if (obj.isArray()) {
/* 1509 */       PdfArray array = (PdfArray)obj;
/* 1510 */       for (int i = 0; i < array.size(); i++) {
/* 1511 */         PdfObject o = array.getPdfObject(i);
/* 1512 */         if (o.isIndirect()) {
/* 1513 */           PdfReader reader = ((PRIndirectReference)o).getReader();
/* 1514 */           HashMap<RefKey, IndirectReferences> indirects = (HashMap)this.indirectMap.get(reader);
/* 1515 */           IndirectReferences indRef = (IndirectReferences)indirects.get(new RefKey((PRIndirectReference)o));
/* 1516 */           if (indRef != null) {
/* 1517 */             array.set(i, indRef.getRef());
/*      */           }
/*      */         } else {
/* 1520 */           updateReferences(o);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private PdfArray branchForm(HashMap<String, Object> level, PdfIndirectReference parent, String fname) throws IOException, BadPdfFormatException
/*      */   {
/* 1528 */     PdfArray arr = new PdfArray();
/* 1529 */     for (Map.Entry<String, Object> entry : level.entrySet()) {
/* 1530 */       String name = (String)entry.getKey();
/* 1531 */       Object obj = entry.getValue();
/* 1532 */       PdfIndirectReference ind = getPdfIndirectReference();
/* 1533 */       PdfDictionary dic = new PdfDictionary();
/* 1534 */       if (parent != null)
/* 1535 */         dic.put(PdfName.PARENT, parent);
/* 1536 */       dic.put(PdfName.T, new PdfString(name, "UnicodeBig"));
/* 1537 */       String fname2 = fname + "." + name;
/* 1538 */       int coidx = this.calculationOrder.indexOf(fname2);
/* 1539 */       if (coidx >= 0)
/* 1540 */         this.calculationOrderRefs.set(coidx, ind);
/* 1541 */       if ((obj instanceof HashMap)) {
/* 1542 */         dic.put(PdfName.KIDS, branchForm((HashMap)obj, ind, fname2));
/* 1543 */         arr.add(ind);
/* 1544 */         addToBody(dic, ind, true);
/*      */       }
/*      */       else {
/* 1547 */         ArrayList<Object> list = (ArrayList)obj;
/* 1548 */         dic.mergeDifferent((PdfDictionary)list.get(0));
/* 1549 */         if (list.size() == 3) {
/* 1550 */           dic.mergeDifferent((PdfDictionary)list.get(2));
/* 1551 */           int page = ((Integer)list.get(1)).intValue();
/* 1552 */           PdfArray annots = ((ImportedPage)this.importedPages.get(page - 1)).mergedFields;
/* 1553 */           PdfNumber nn = (PdfNumber)dic.get(iTextTag);
/* 1554 */           dic.remove(iTextTag);
/* 1555 */           dic.put(PdfName.TYPE, PdfName.ANNOT);
/* 1556 */           adjustTabOrder(annots, ind, nn);
/*      */         } else {
/* 1558 */           PdfDictionary field = (PdfDictionary)list.get(0);
/* 1559 */           PdfArray kids = new PdfArray();
/* 1560 */           for (int k = 1; k < list.size(); k += 2) {
/* 1561 */             int page = ((Integer)list.get(k)).intValue();
/* 1562 */             PdfArray annots = ((ImportedPage)this.importedPages.get(page - 1)).mergedFields;
/* 1563 */             PdfDictionary widget = new PdfDictionary();
/* 1564 */             widget.merge((PdfDictionary)list.get(k + 1));
/* 1565 */             widget.put(PdfName.PARENT, ind);
/* 1566 */             PdfNumber nn = (PdfNumber)widget.get(iTextTag);
/* 1567 */             widget.remove(iTextTag);
/* 1568 */             if (isTextField(field)) {
/* 1569 */               PdfString v = field.getAsString(PdfName.V);
/* 1570 */               PdfObject ap = widget.getDirectObject(PdfName.AP);
/* 1571 */               if ((v != null) && (ap != null)) {
/* 1572 */                 if (!this.mergedTextFields.containsKey(list)) {
/* 1573 */                   this.mergedTextFields.put(list, v);
/*      */                 } else {
/*      */                   try {
/* 1576 */                     TextField tx = new TextField(this, null, null);
/* 1577 */                     ((AcroFields)this.fields.get(0)).decodeGenericDictionary(widget, tx);
/* 1578 */                     Rectangle box = PdfReader.getNormalizedRectangle(widget.getAsArray(PdfName.RECT));
/* 1579 */                     if ((tx.getRotation() == 90) || (tx.getRotation() == 270))
/* 1580 */                       box = box.rotate();
/* 1581 */                     tx.setBox(box);
/* 1582 */                     tx.setText(((PdfString)this.mergedTextFields.get(list)).toUnicodeString());
/* 1583 */                     PdfAppearance app = tx.getAppearance();
/* 1584 */                     ((PdfDictionary)ap).put(PdfName.N, app.getIndirectReference());
/*      */                   }
/*      */                   catch (DocumentException localDocumentException) {}
/*      */                 }
/*      */               }
/*      */             }
/* 1590 */             else if (isCheckButton(field)) {
/* 1591 */               PdfName v = field.getAsName(PdfName.V);
/* 1592 */               PdfName as = widget.getAsName(PdfName.AS);
/* 1593 */               if ((v != null) && (as != null))
/* 1594 */                 widget.put(PdfName.AS, v);
/* 1595 */             } else if (isRadioButton(field)) {
/* 1596 */               PdfName v = field.getAsName(PdfName.V);
/* 1597 */               PdfName as = widget.getAsName(PdfName.AS);
/* 1598 */               if ((v != null) && (as != null) && (!as.equals(getOffStateName(widget)))) {
/* 1599 */                 if (!this.mergedRadioButtons.contains(list)) {
/* 1600 */                   this.mergedRadioButtons.add(list);
/* 1601 */                   widget.put(PdfName.AS, v);
/*      */                 } else {
/* 1603 */                   widget.put(PdfName.AS, getOffStateName(widget));
/*      */                 }
/*      */               }
/*      */             }
/* 1607 */             widget.put(PdfName.TYPE, PdfName.ANNOT);
/* 1608 */             PdfIndirectReference wref = addToBody(widget, getPdfIndirectReference(), true).getIndirectReference();
/* 1609 */             adjustTabOrder(annots, wref, nn);
/* 1610 */             kids.add(wref);
/*      */           }
/* 1612 */           dic.put(PdfName.KIDS, kids);
/*      */         }
/* 1614 */         arr.add(ind);
/* 1615 */         addToBody(dic, ind, true);
/*      */       }
/*      */     }
/* 1618 */     return arr;
/*      */   }
/*      */   
/*      */   private void adjustTabOrder(PdfArray annots, PdfIndirectReference ind, PdfNumber nn) {
/* 1622 */     int v = nn.intValue();
/* 1623 */     ArrayList<Integer> t = (ArrayList)this.tabOrder.get(annots);
/* 1624 */     if (t == null) {
/* 1625 */       t = new ArrayList();
/* 1626 */       int size = annots.size() - 1;
/* 1627 */       for (int k = 0; k < size; k++) {
/* 1628 */         t.add(zero);
/*      */       }
/* 1630 */       t.add(Integer.valueOf(v));
/* 1631 */       this.tabOrder.put(annots, t);
/* 1632 */       annots.add(ind);
/*      */     }
/*      */     else {
/* 1635 */       int size = t.size() - 1;
/* 1636 */       for (int k = size; k >= 0; k--) {
/* 1637 */         if (((Integer)t.get(k)).intValue() <= v) {
/* 1638 */           t.add(k + 1, Integer.valueOf(v));
/* 1639 */           annots.add(k + 1, ind);
/* 1640 */           size = -2;
/* 1641 */           break;
/*      */         }
/*      */       }
/* 1644 */       if (size != -2) {
/* 1645 */         t.add(0, Integer.valueOf(v));
/* 1646 */         annots.add(0, ind);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary getCatalog(PdfIndirectReference rootObj)
/*      */   {
/*      */     try
/*      */     {
/* 1658 */       PdfDictionary theCat = this.pdf.getCatalog(rootObj);
/* 1659 */       buildStructTreeRootForTagged(theCat);
/* 1660 */       if (this.fieldArray != null) {
/* 1661 */         addFieldResources(theCat);
/* 1662 */       } else if ((this.mergeFields) && (this.acroForm != null)) {
/* 1663 */         theCat.put(PdfName.ACROFORM, this.acroForm);
/*      */       }
/* 1665 */       return theCat;
/*      */     }
/*      */     catch (IOException e) {
/* 1668 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean isStructTreeRootReference(PdfIndirectReference prRef) {
/* 1673 */     if ((prRef == null) || (this.structTreeRootReference == null))
/* 1674 */       return false;
/* 1675 */     return (prRef.number == this.structTreeRootReference.number) && (prRef.generation == this.structTreeRootReference.generation);
/*      */   }
/*      */   
/*      */   private void addFieldResources(PdfDictionary catalog) throws IOException {
/* 1679 */     if (this.fieldArray == null)
/* 1680 */       return;
/* 1681 */     PdfDictionary acroForm = new PdfDictionary();
/* 1682 */     catalog.put(PdfName.ACROFORM, acroForm);
/* 1683 */     acroForm.put(PdfName.FIELDS, this.fieldArray);
/* 1684 */     acroForm.put(PdfName.DA, new PdfString("/Helv 0 Tf 0 g "));
/* 1685 */     if (this.fieldTemplates.isEmpty())
/* 1686 */       return;
/* 1687 */     PdfDictionary dr = new PdfDictionary();
/* 1688 */     acroForm.put(PdfName.DR, dr);
/* 1689 */     for (PdfTemplate template : this.fieldTemplates) {
/* 1690 */       PdfFormField.mergeResources(dr, (PdfDictionary)template.getResources());
/*      */     }
/*      */     
/* 1693 */     PdfDictionary fonts = dr.getAsDict(PdfName.FONT);
/* 1694 */     if (fonts == null) {
/* 1695 */       fonts = new PdfDictionary();
/* 1696 */       dr.put(PdfName.FONT, fonts);
/*      */     }
/* 1698 */     if (!fonts.contains(PdfName.HELV)) {
/* 1699 */       PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 1700 */       dic.put(PdfName.BASEFONT, PdfName.HELVETICA);
/* 1701 */       dic.put(PdfName.ENCODING, PdfName.WIN_ANSI_ENCODING);
/* 1702 */       dic.put(PdfName.NAME, PdfName.HELV);
/* 1703 */       dic.put(PdfName.SUBTYPE, PdfName.TYPE1);
/* 1704 */       fonts.put(PdfName.HELV, addToBody(dic).getIndirectReference());
/*      */     }
/* 1706 */     if (!fonts.contains(PdfName.ZADB)) {
/* 1707 */       PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 1708 */       dic.put(PdfName.BASEFONT, PdfName.ZAPFDINGBATS);
/* 1709 */       dic.put(PdfName.NAME, PdfName.ZADB);
/* 1710 */       dic.put(PdfName.SUBTYPE, PdfName.TYPE1);
/* 1711 */       fonts.put(PdfName.ZADB, addToBody(dic).getIndirectReference());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/* 1727 */     if (this.open) {
/* 1728 */       this.pdf.close();
/* 1729 */       super.close();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectReference add(PdfOutline outline)
/*      */   {
/* 1743 */     return null;
/*      */   }
/*      */   
/*      */   PdfIndirectReference add(PdfPage page, PdfContents contents)
/*      */     throws PdfException
/*      */   {
/* 1749 */     return null;
/*      */   }
/*      */   
/*      */   public void freeReader(PdfReader reader) throws IOException {
/* 1753 */     if (this.mergeFields)
/* 1754 */       throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("it.is.not.possible.to.free.reader.in.merge.fields.mode", new Object[0]));
/* 1755 */     PdfArray array = reader.trailer.getAsArray(PdfName.ID);
/* 1756 */     if (array != null)
/* 1757 */       this.originalFileID = array.getAsString(0).getBytes();
/* 1758 */     this.indirectMap.remove(reader);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1769 */     this.currentPdfReaderInstance = null;
/*      */     
/*      */ 
/* 1772 */     super.freeReader(reader);
/*      */   }
/*      */   
/*      */   protected PdfName getOffStateName(PdfDictionary widget) {
/* 1776 */     return PdfName.Off;
/*      */   }
/*      */   
/* 1779 */   protected static final HashSet<PdfName> widgetKeys = new HashSet();
/* 1780 */   protected static final HashSet<PdfName> fieldKeys = new HashSet();
/*      */   
/* 1782 */   static { widgetKeys.add(PdfName.SUBTYPE);
/* 1783 */     widgetKeys.add(PdfName.CONTENTS);
/* 1784 */     widgetKeys.add(PdfName.RECT);
/* 1785 */     widgetKeys.add(PdfName.NM);
/* 1786 */     widgetKeys.add(PdfName.M);
/* 1787 */     widgetKeys.add(PdfName.F);
/* 1788 */     widgetKeys.add(PdfName.BS);
/* 1789 */     widgetKeys.add(PdfName.BORDER);
/* 1790 */     widgetKeys.add(PdfName.AP);
/* 1791 */     widgetKeys.add(PdfName.AS);
/* 1792 */     widgetKeys.add(PdfName.C);
/* 1793 */     widgetKeys.add(PdfName.A);
/* 1794 */     widgetKeys.add(PdfName.STRUCTPARENT);
/* 1795 */     widgetKeys.add(PdfName.OC);
/* 1796 */     widgetKeys.add(PdfName.H);
/* 1797 */     widgetKeys.add(PdfName.MK);
/* 1798 */     widgetKeys.add(PdfName.DA);
/* 1799 */     widgetKeys.add(PdfName.Q);
/* 1800 */     widgetKeys.add(PdfName.P);
/* 1801 */     widgetKeys.add(PdfName.TYPE);
/* 1802 */     widgetKeys.add(annotId);
/* 1803 */     fieldKeys.add(PdfName.AA);
/* 1804 */     fieldKeys.add(PdfName.FT);
/* 1805 */     fieldKeys.add(PdfName.TU);
/* 1806 */     fieldKeys.add(PdfName.TM);
/* 1807 */     fieldKeys.add(PdfName.FF);
/* 1808 */     fieldKeys.add(PdfName.V);
/* 1809 */     fieldKeys.add(PdfName.DV);
/* 1810 */     fieldKeys.add(PdfName.DS);
/* 1811 */     fieldKeys.add(PdfName.RV);
/* 1812 */     fieldKeys.add(PdfName.OPT);
/* 1813 */     fieldKeys.add(PdfName.MAXLEN);
/* 1814 */     fieldKeys.add(PdfName.TI);
/* 1815 */     fieldKeys.add(PdfName.I);
/* 1816 */     fieldKeys.add(PdfName.LOCK);
/* 1817 */     fieldKeys.add(PdfName.SV);
/*      */   }
/*      */   
/*      */   static Integer getFlags(PdfDictionary field) {
/* 1821 */     PdfName type = field.getAsName(PdfName.FT);
/* 1822 */     if (!PdfName.BTN.equals(type))
/* 1823 */       return null;
/* 1824 */     PdfNumber flags = field.getAsNumber(PdfName.FF);
/* 1825 */     if (flags == null)
/* 1826 */       return null;
/* 1827 */     return Integer.valueOf(flags.intValue());
/*      */   }
/*      */   
/*      */   static boolean isCheckButton(PdfDictionary field) {
/* 1831 */     Integer flags = getFlags(field);
/* 1832 */     return (flags == null) || (((flags.intValue() & 0x10000) == 0) && ((flags.intValue() & 0x8000) == 0));
/*      */   }
/*      */   
/*      */   static boolean isRadioButton(PdfDictionary field) {
/* 1836 */     Integer flags = getFlags(field);
/* 1837 */     return (flags != null) && ((flags.intValue() & 0x10000) == 0) && ((flags.intValue() & 0x8000) != 0);
/*      */   }
/*      */   
/*      */   static boolean isTextField(PdfDictionary field) {
/* 1841 */     PdfName type = field.getAsName(PdfName.FT);
/* 1842 */     return PdfName.TX.equals(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PageStamp createPageStamp(PdfImportedPage iPage)
/*      */   {
/* 1869 */     int pageNum = iPage.getPageNumber();
/* 1870 */     PdfReader reader = iPage.getPdfReaderInstance().getReader();
/* 1871 */     if (isTagged())
/* 1872 */       throw new RuntimeException(MessageLocalization.getComposedMessage("creating.page.stamp.not.allowed.for.tagged.reader", new Object[0]));
/* 1873 */     PdfDictionary pageN = reader.getPageN(pageNum);
/* 1874 */     return new PageStamp(reader, pageN, this);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected void flushTaggedObjects()
/*      */     throws IOException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 264	com/itextpdf/text/pdf/PdfCopy:fixTaggedStructure	()V
/*      */     //   4: aload_0
/*      */     //   5: invokevirtual 265	com/itextpdf/text/pdf/PdfCopy:flushIndirectObjects	()V
/*      */     //   8: goto +18 -> 26
/*      */     //   11: astore_1
/*      */     //   12: aload_0
/*      */     //   13: invokevirtual 265	com/itextpdf/text/pdf/PdfCopy:flushIndirectObjects	()V
/*      */     //   16: goto +10 -> 26
/*      */     //   19: astore_2
/*      */     //   20: aload_0
/*      */     //   21: invokevirtual 265	com/itextpdf/text/pdf/PdfCopy:flushIndirectObjects	()V
/*      */     //   24: aload_2
/*      */     //   25: athrow
/*      */     //   26: return
/*      */     // Line number table:
/*      */     //   Java source line #886	-> byte code offset #0
/*      */     //   Java source line #888	-> byte code offset #4
/*      */     //   Java source line #887	-> byte code offset #11
/*      */     //   Java source line #888	-> byte code offset #12
/*      */     //   Java source line #889	-> byte code offset #26
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	27	0	this	PdfCopy
/*      */     //   11	1	1	localClassCastException	ClassCastException
/*      */     //   19	6	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	4	11	java/lang/ClassCastException
/*      */     //   0	4	19	finally
/*      */   }
/*      */   
/*      */   public void addAnnotation(PdfAnnotation annot) {}
/*      */   
/*      */   public static class PageStamp
/*      */   {
/*      */     PdfDictionary pageN;
/*      */     PdfCopy.StampContent under;
/*      */     PdfCopy.StampContent over;
/*      */     PageResources pageResources;
/*      */     PdfReader reader;
/*      */     PdfCopy cstp;
/*      */     
/*      */     PageStamp(PdfReader reader, PdfDictionary pageN, PdfCopy cstp)
/*      */     {
/* 1887 */       this.pageN = pageN;
/* 1888 */       this.reader = reader;
/* 1889 */       this.cstp = cstp;
/*      */     }
/*      */     
/*      */     public PdfContentByte getUnderContent() {
/* 1893 */       if (this.under == null) {
/* 1894 */         if (this.pageResources == null) {
/* 1895 */           this.pageResources = new PageResources();
/* 1896 */           PdfDictionary resources = this.pageN.getAsDict(PdfName.RESOURCES);
/* 1897 */           this.pageResources.setOriginalResources(resources, this.cstp.namePtr);
/*      */         }
/* 1899 */         this.under = new PdfCopy.StampContent(this.cstp, this.pageResources);
/*      */       }
/* 1901 */       return this.under;
/*      */     }
/*      */     
/*      */     public PdfContentByte getOverContent() {
/* 1905 */       if (this.over == null) {
/* 1906 */         if (this.pageResources == null) {
/* 1907 */           this.pageResources = new PageResources();
/* 1908 */           PdfDictionary resources = this.pageN.getAsDict(PdfName.RESOURCES);
/* 1909 */           this.pageResources.setOriginalResources(resources, this.cstp.namePtr);
/*      */         }
/* 1911 */         this.over = new PdfCopy.StampContent(this.cstp, this.pageResources);
/*      */       }
/* 1913 */       return this.over;
/*      */     }
/*      */     
/*      */     public void alterContents() throws IOException {
/* 1917 */       if ((this.over == null) && (this.under == null))
/* 1918 */         return;
/* 1919 */       PdfArray ar = null;
/* 1920 */       PdfObject content = PdfReader.getPdfObject(this.pageN.get(PdfName.CONTENTS), this.pageN);
/* 1921 */       if (content == null) {
/* 1922 */         ar = new PdfArray();
/* 1923 */         this.pageN.put(PdfName.CONTENTS, ar);
/* 1924 */       } else if (content.isArray()) {
/* 1925 */         ar = (PdfArray)content;
/* 1926 */       } else if (content.isStream()) {
/* 1927 */         ar = new PdfArray();
/* 1928 */         ar.add(this.pageN.get(PdfName.CONTENTS));
/* 1929 */         this.pageN.put(PdfName.CONTENTS, ar);
/*      */       } else {
/* 1931 */         ar = new PdfArray();
/* 1932 */         this.pageN.put(PdfName.CONTENTS, ar);
/*      */       }
/* 1934 */       ByteBuffer out = new ByteBuffer();
/* 1935 */       if (this.under != null) {
/* 1936 */         out.append(PdfContents.SAVESTATE);
/* 1937 */         applyRotation(this.pageN, out);
/* 1938 */         out.append(this.under.getInternalBuffer());
/* 1939 */         out.append(PdfContents.RESTORESTATE);
/*      */       }
/* 1941 */       if (this.over != null)
/* 1942 */         out.append(PdfContents.SAVESTATE);
/* 1943 */       PdfStream stream = new PdfStream(out.toByteArray());
/* 1944 */       stream.flateCompress(this.cstp.getCompressionLevel());
/* 1945 */       PdfIndirectReference ref1 = this.cstp.addToBody(stream).getIndirectReference();
/* 1946 */       ar.addFirst(ref1);
/* 1947 */       out.reset();
/* 1948 */       if (this.over != null) {
/* 1949 */         out.append(' ');
/* 1950 */         out.append(PdfContents.RESTORESTATE);
/* 1951 */         out.append(PdfContents.SAVESTATE);
/* 1952 */         applyRotation(this.pageN, out);
/* 1953 */         out.append(this.over.getInternalBuffer());
/* 1954 */         out.append(PdfContents.RESTORESTATE);
/* 1955 */         stream = new PdfStream(out.toByteArray());
/* 1956 */         stream.flateCompress(this.cstp.getCompressionLevel());
/* 1957 */         ar.add(this.cstp.addToBody(stream).getIndirectReference());
/*      */       }
/* 1959 */       this.pageN.put(PdfName.RESOURCES, this.pageResources.getResources());
/*      */     }
/*      */     
/*      */     void applyRotation(PdfDictionary pageN, ByteBuffer out) {
/* 1963 */       if (!this.cstp.rotateContents)
/* 1964 */         return;
/* 1965 */       Rectangle page = this.reader.getPageSizeWithRotation(pageN);
/* 1966 */       int rotation = page.getRotation();
/* 1967 */       switch (rotation) {
/*      */       case 90: 
/* 1969 */         out.append(PdfContents.ROTATE90);
/* 1970 */         out.append(page.getTop());
/* 1971 */         out.append(' ').append('0').append(PdfContents.ROTATEFINAL);
/* 1972 */         break;
/*      */       case 180: 
/* 1974 */         out.append(PdfContents.ROTATE180);
/* 1975 */         out.append(page.getRight());
/* 1976 */         out.append(' ');
/* 1977 */         out.append(page.getTop());
/* 1978 */         out.append(PdfContents.ROTATEFINAL);
/* 1979 */         break;
/*      */       case 270: 
/* 1981 */         out.append(PdfContents.ROTATE270);
/* 1982 */         out.append('0').append(' ');
/* 1983 */         out.append(page.getRight());
/* 1984 */         out.append(PdfContents.ROTATEFINAL);
/*      */       }
/*      */     }
/*      */     
/*      */     private void addDocumentField(PdfIndirectReference ref)
/*      */     {
/* 1990 */       if (this.cstp.fieldArray == null)
/* 1991 */         this.cstp.fieldArray = new PdfArray();
/* 1992 */       this.cstp.fieldArray.add(ref);
/*      */     }
/*      */     
/*      */     private void expandFields(PdfFormField field, ArrayList<PdfAnnotation> allAnnots) {
/* 1996 */       allAnnots.add(field);
/* 1997 */       ArrayList<PdfFormField> kids = field.getKids();
/* 1998 */       if (kids != null) {
/* 1999 */         for (PdfFormField f : kids)
/* 2000 */           expandFields(f, allAnnots);
/*      */       }
/*      */     }
/*      */     
/*      */     public void addAnnotation(PdfAnnotation annot) {
/*      */       try {
/* 2006 */         ArrayList<PdfAnnotation> allAnnots = new ArrayList();
/* 2007 */         if (annot.isForm()) {
/* 2008 */           PdfFormField field = (PdfFormField)annot;
/* 2009 */           if (field.getParent() != null)
/* 2010 */             return;
/* 2011 */           expandFields(field, allAnnots);
/* 2012 */           if (this.cstp.fieldTemplates == null) {
/* 2013 */             this.cstp.fieldTemplates = new HashSet();
/*      */           }
/*      */         } else {
/* 2016 */           allAnnots.add(annot); }
/* 2017 */         for (int k = 0; k < allAnnots.size(); k++) {
/* 2018 */           annot = (PdfAnnotation)allAnnots.get(k);
/* 2019 */           if (annot.isForm()) {
/* 2020 */             if (!annot.isUsed()) {
/* 2021 */               HashSet<PdfTemplate> templates = annot.getTemplates();
/* 2022 */               if (templates != null)
/* 2023 */                 this.cstp.fieldTemplates.addAll(templates);
/*      */             }
/* 2025 */             PdfFormField field = (PdfFormField)annot;
/* 2026 */             if (field.getParent() == null)
/* 2027 */               addDocumentField(field.getIndirectReference());
/*      */           }
/* 2029 */           if (annot.isAnnotation()) {
/* 2030 */             PdfObject pdfobj = PdfReader.getPdfObject(this.pageN.get(PdfName.ANNOTS), this.pageN);
/* 2031 */             PdfArray annots = null;
/* 2032 */             if ((pdfobj == null) || (!pdfobj.isArray())) {
/* 2033 */               annots = new PdfArray();
/* 2034 */               this.pageN.put(PdfName.ANNOTS, annots);
/*      */             }
/*      */             else {
/* 2037 */               annots = (PdfArray)pdfobj; }
/* 2038 */             annots.add(annot.getIndirectReference());
/* 2039 */             if (!annot.isUsed()) {
/* 2040 */               PdfRectangle rect = (PdfRectangle)annot.get(PdfName.RECT);
/* 2041 */               if ((rect != null) && ((rect.left() != 0.0F) || (rect.right() != 0.0F) || (rect.top() != 0.0F) || (rect.bottom() != 0.0F))) {
/* 2042 */                 int rotation = this.reader.getPageRotation(this.pageN);
/* 2043 */                 Rectangle pageSize = this.reader.getPageSizeWithRotation(this.pageN);
/* 2044 */                 switch (rotation) {
/*      */                 case 90: 
/* 2046 */                   annot.put(PdfName.RECT, new PdfRectangle(pageSize
/* 2047 */                     .getTop() - rect.bottom(), rect
/* 2048 */                     .left(), pageSize
/* 2049 */                     .getTop() - rect.top(), rect
/* 2050 */                     .right()));
/* 2051 */                   break;
/*      */                 case 180: 
/* 2053 */                   annot.put(PdfName.RECT, new PdfRectangle(pageSize
/* 2054 */                     .getRight() - rect.left(), pageSize
/* 2055 */                     .getTop() - rect.bottom(), pageSize
/* 2056 */                     .getRight() - rect.right(), pageSize
/* 2057 */                     .getTop() - rect.top()));
/* 2058 */                   break;
/*      */                 case 270: 
/* 2060 */                   annot.put(PdfName.RECT, new PdfRectangle(rect
/* 2061 */                     .bottom(), pageSize
/* 2062 */                     .getRight() - rect.left(), rect
/* 2063 */                     .top(), pageSize
/* 2064 */                     .getRight() - rect.right()));
/*      */                 }
/*      */                 
/*      */               }
/*      */             }
/*      */           }
/* 2070 */           if (!annot.isUsed()) {
/* 2071 */             annot.setUsed();
/* 2072 */             this.cstp.addToBody(annot, annot.getIndirectReference());
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException e) {
/* 2077 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class StampContent extends PdfContentByte
/*      */   {
/*      */     PageResources pageResources;
/*      */     
/*      */     StampContent(PdfWriter writer, PageResources pageResources) {
/* 2087 */       super();
/* 2088 */       this.pageResources = pageResources;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfContentByte getDuplicate()
/*      */     {
/* 2099 */       return new StampContent(this.writer, this.pageResources);
/*      */     }
/*      */     
/*      */     PageResources getPageResources()
/*      */     {
/* 2104 */       return this.pageResources;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfCopy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */