/*    */ package com.itextpdf.text.pdf.parser;
/*    */ 
/*    */ import com.itextpdf.text.pdf.PdfDictionary;
/*    */ import com.itextpdf.text.pdf.PdfName;
/*    */ import com.itextpdf.text.pdf.PdfNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkedContentInfo
/*    */ {
/*    */   private final PdfName tag;
/*    */   private final PdfDictionary dictionary;
/*    */   
/*    */   public MarkedContentInfo(PdfName tag, PdfDictionary dictionary)
/*    */   {
/* 60 */     this.tag = tag;
/* 61 */     this.dictionary = (dictionary != null ? dictionary : new PdfDictionary());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PdfName getTag()
/*    */   {
/* 69 */     return this.tag;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasMcid()
/*    */   {
/* 77 */     return this.dictionary.contains(PdfName.MCID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getMcid()
/*    */   {
/* 87 */     PdfNumber id = this.dictionary.getAsNumber(PdfName.MCID);
/* 88 */     if (id == null) {
/* 89 */       throw new IllegalStateException("MarkedContentInfo does not contain MCID");
/*    */     }
/* 91 */     return id.intValue();
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/MarkedContentInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */