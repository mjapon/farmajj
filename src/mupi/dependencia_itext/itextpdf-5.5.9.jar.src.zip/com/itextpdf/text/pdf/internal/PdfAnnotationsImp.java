/*     */ package com.itextpdf.text.pdf.internal;
/*     */ 
/*     */ import com.itextpdf.text.Annotation;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.pdf.PdfAcroForm;
/*     */ import com.itextpdf.text.pdf.PdfAction;
/*     */ import com.itextpdf.text.pdf.PdfAnnotation;
/*     */ import com.itextpdf.text.pdf.PdfArray;
/*     */ import com.itextpdf.text.pdf.PdfFileSpecification;
/*     */ import com.itextpdf.text.pdf.PdfFormField;
/*     */ import com.itextpdf.text.pdf.PdfName;
/*     */ import com.itextpdf.text.pdf.PdfNumber;
/*     */ import com.itextpdf.text.pdf.PdfRectangle;
/*     */ import com.itextpdf.text.pdf.PdfString;
/*     */ import com.itextpdf.text.pdf.PdfTemplate;
/*     */ import com.itextpdf.text.pdf.PdfWriter;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfAnnotationsImp
/*     */ {
/*     */   protected PdfAcroForm acroForm;
/*  79 */   protected ArrayList<PdfAnnotation> annotations = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected ArrayList<PdfAnnotation> delayedAnnotations = new ArrayList();
/*     */   
/*     */   public PdfAnnotationsImp(PdfWriter writer)
/*     */   {
/*  89 */     this.acroForm = new PdfAcroForm(writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasValidAcroForm()
/*     */   {
/*  96 */     return this.acroForm.isValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfAcroForm getAcroForm()
/*     */   {
/* 104 */     return this.acroForm;
/*     */   }
/*     */   
/*     */   public void setSigFlags(int f) {
/* 108 */     this.acroForm.setSigFlags(f);
/*     */   }
/*     */   
/*     */   public void addCalculationOrder(PdfFormField formField) {
/* 112 */     this.acroForm.addCalculationOrder(formField);
/*     */   }
/*     */   
/*     */   public void addAnnotation(PdfAnnotation annot) {
/* 116 */     if (annot.isForm()) {
/* 117 */       PdfFormField field = (PdfFormField)annot;
/* 118 */       if (field.getParent() == null) {
/* 119 */         addFormFieldRaw(field);
/*     */       }
/*     */     } else {
/* 122 */       this.annotations.add(annot);
/*     */     }
/*     */   }
/*     */   
/* 126 */   public void addPlainAnnotation(PdfAnnotation annot) { this.annotations.add(annot); }
/*     */   
/*     */   void addFormFieldRaw(PdfFormField field)
/*     */   {
/* 130 */     this.annotations.add(field);
/* 131 */     ArrayList<PdfFormField> kids = field.getKids();
/* 132 */     if (kids != null) {
/* 133 */       for (int k = 0; k < kids.size(); k++) {
/* 134 */         PdfFormField kid = (PdfFormField)kids.get(k);
/* 135 */         if (!kid.isUsed())
/* 136 */           addFormFieldRaw(kid);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasUnusedAnnotations() {
/* 142 */     return !this.annotations.isEmpty();
/*     */   }
/*     */   
/*     */   public void resetAnnotations() {
/* 146 */     this.annotations = this.delayedAnnotations;
/* 147 */     this.delayedAnnotations = new ArrayList();
/*     */   }
/*     */   
/*     */   public PdfArray rotateAnnotations(PdfWriter writer, Rectangle pageSize) {
/* 151 */     PdfArray array = new PdfArray();
/* 152 */     int rotation = pageSize.getRotation() % 360;
/* 153 */     int currentPage = writer.getCurrentPageNumber();
/* 154 */     for (int k = 0; k < this.annotations.size(); k++) {
/* 155 */       PdfAnnotation dic = (PdfAnnotation)this.annotations.get(k);
/* 156 */       int page = dic.getPlaceInPage();
/* 157 */       if (page > currentPage) {
/* 158 */         this.delayedAnnotations.add(dic);
/*     */       }
/*     */       else {
/* 161 */         if (dic.isForm()) {
/* 162 */           if (!dic.isUsed()) {
/* 163 */             HashSet<PdfTemplate> templates = dic.getTemplates();
/* 164 */             if (templates != null)
/* 165 */               this.acroForm.addFieldTemplates(templates);
/*     */           }
/* 167 */           PdfFormField field = (PdfFormField)dic;
/* 168 */           if (field.getParent() == null)
/* 169 */             this.acroForm.addDocumentField(field.getIndirectReference());
/*     */         }
/* 171 */         if (dic.isAnnotation()) {
/* 172 */           array.add(dic.getIndirectReference());
/* 173 */           if (!dic.isUsed()) {
/* 174 */             PdfArray tmp = dic.getAsArray(PdfName.RECT);
/*     */             PdfRectangle rect;
/* 176 */             PdfRectangle rect; if (tmp.size() == 4) {
/* 177 */               rect = new PdfRectangle(tmp.getAsNumber(0).floatValue(), tmp.getAsNumber(1).floatValue(), tmp.getAsNumber(2).floatValue(), tmp.getAsNumber(3).floatValue());
/*     */             }
/*     */             else {
/* 180 */               rect = new PdfRectangle(tmp.getAsNumber(0).floatValue(), tmp.getAsNumber(1).floatValue());
/*     */             }
/* 182 */             switch (rotation) {
/*     */             case 90: 
/* 184 */               dic.put(PdfName.RECT, new PdfRectangle(pageSize
/* 185 */                 .getTop() - rect.bottom(), rect
/* 186 */                 .left(), pageSize
/* 187 */                 .getTop() - rect.top(), rect
/* 188 */                 .right()));
/* 189 */               break;
/*     */             case 180: 
/* 191 */               dic.put(PdfName.RECT, new PdfRectangle(pageSize
/* 192 */                 .getRight() - rect.left(), pageSize
/* 193 */                 .getTop() - rect.bottom(), pageSize
/* 194 */                 .getRight() - rect.right(), pageSize
/* 195 */                 .getTop() - rect.top()));
/* 196 */               break;
/*     */             case 270: 
/* 198 */               dic.put(PdfName.RECT, new PdfRectangle(rect
/* 199 */                 .bottom(), pageSize
/* 200 */                 .getRight() - rect.left(), rect
/* 201 */                 .top(), pageSize
/* 202 */                 .getRight() - rect.right()));
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 207 */         if (!dic.isUsed()) {
/* 208 */           dic.setUsed();
/*     */           try {
/* 210 */             writer.addToBody(dic, dic.getIndirectReference());
/*     */           }
/*     */           catch (IOException e) {
/* 213 */             throw new ExceptionConverter(e);
/*     */           }
/*     */         }
/*     */       } }
/* 217 */     return array;
/*     */   }
/*     */   
/*     */   public static PdfAnnotation convertAnnotation(PdfWriter writer, Annotation annot, Rectangle defaultRect) throws IOException {
/* 221 */     switch (annot.annotationType()) {
/*     */     case 1: 
/* 223 */       return writer.createAnnotation(annot.llx(), annot.lly(), annot.urx(), annot.ury(), new PdfAction((URL)annot.attributes().get("url")), null);
/*     */     case 2: 
/* 225 */       return writer.createAnnotation(annot.llx(), annot.lly(), annot.urx(), annot.ury(), new PdfAction((String)annot.attributes().get("file")), null);
/*     */     case 3: 
/* 227 */       return writer.createAnnotation(annot.llx(), annot.lly(), annot.urx(), annot.ury(), new PdfAction((String)annot.attributes().get("file"), (String)annot.attributes().get("destination")), null);
/*     */     case 7: 
/* 229 */       boolean[] sparams = (boolean[])annot.attributes().get("parameters");
/* 230 */       String fname = (String)annot.attributes().get("file");
/* 231 */       String mimetype = (String)annot.attributes().get("mime");
/*     */       PdfFileSpecification fs;
/* 233 */       PdfFileSpecification fs; if (sparams[0] != 0) {
/* 234 */         fs = PdfFileSpecification.fileEmbedded(writer, fname, fname, null);
/*     */       } else
/* 236 */         fs = PdfFileSpecification.fileExtern(writer, fname);
/* 237 */       PdfAnnotation ann = PdfAnnotation.createScreen(writer, new Rectangle(annot.llx(), annot.lly(), annot.urx(), annot.ury()), fname, fs, mimetype, sparams[1]);
/*     */       
/* 239 */       return ann;
/*     */     case 4: 
/* 241 */       return writer.createAnnotation(annot.llx(), annot.lly(), annot.urx(), annot.ury(), new PdfAction((String)annot.attributes().get("file"), ((Integer)annot.attributes().get("page")).intValue()), null);
/*     */     case 5: 
/* 243 */       return writer.createAnnotation(annot.llx(), annot.lly(), annot.urx(), annot.ury(), new PdfAction(((Integer)annot.attributes().get("named")).intValue()), null);
/*     */     case 6: 
/* 245 */       return writer.createAnnotation(annot.llx(), annot.lly(), annot.urx(), annot.ury(), new PdfAction((String)annot.attributes().get("application"), (String)annot.attributes().get("parameters"), (String)annot.attributes().get("operation"), (String)annot.attributes().get("defaultdir")), null);
/*     */     }
/* 247 */     return writer.createAnnotation(defaultRect.getLeft(), defaultRect.getBottom(), defaultRect.getRight(), defaultRect.getTop(), new PdfString(annot.title(), "UnicodeBig"), new PdfString(annot.content(), "UnicodeBig"), null);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/internal/PdfAnnotationsImp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */