/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Path
/*     */   extends ArrayList<Point.LongPoint>
/*     */ {
/*     */   private static final long serialVersionUID = -7120161578077546673L;
/*     */   
/*     */   static class Join
/*     */   {
/*     */     Path.OutPt outPt1;
/*     */     Path.OutPt outPt2;
/*     */     private Point.LongPoint offPt;
/*     */     
/*     */     public Point.LongPoint getOffPt()
/*     */     {
/*  97 */       return this.offPt;
/*     */     }
/*     */     
/*     */ 
/* 101 */     public void setOffPt(Point.LongPoint offPt) { this.offPt = offPt; }
/*     */   }
/*     */   
/*     */   static class OutPt { int idx;
/*     */     protected Point.LongPoint pt;
/*     */     OutPt next;
/*     */     OutPt prev;
/*     */     
/* 109 */     public static Path.OutRec getLowerMostRec(Path.OutRec outRec1, Path.OutRec outRec2) { if (outRec1.bottomPt == null) {
/* 110 */         outRec1.bottomPt = outRec1.pts.getBottomPt();
/*     */       }
/* 112 */       if (outRec2.bottomPt == null) {
/* 113 */         outRec2.bottomPt = outRec2.pts.getBottomPt();
/*     */       }
/* 115 */       OutPt bPt1 = outRec1.bottomPt;
/* 116 */       OutPt bPt2 = outRec2.bottomPt;
/* 117 */       if (bPt1.getPt().getY() > bPt2.getPt().getY()) {
/* 118 */         return outRec1;
/*     */       }
/* 120 */       if (bPt1.getPt().getY() < bPt2.getPt().getY()) {
/* 121 */         return outRec2;
/*     */       }
/* 123 */       if (bPt1.getPt().getX() < bPt2.getPt().getX()) {
/* 124 */         return outRec1;
/*     */       }
/* 126 */       if (bPt1.getPt().getX() > bPt2.getPt().getX()) {
/* 127 */         return outRec2;
/*     */       }
/* 129 */       if (bPt1.next == bPt1) {
/* 130 */         return outRec2;
/*     */       }
/* 132 */       if (bPt2.next == bPt2) {
/* 133 */         return outRec1;
/*     */       }
/* 135 */       if (isFirstBottomPt(bPt1, bPt2)) {
/* 136 */         return outRec1;
/*     */       }
/*     */       
/* 139 */       return outRec2;
/*     */     }
/*     */     
/*     */     private static boolean isFirstBottomPt(OutPt btmPt1, OutPt btmPt2)
/*     */     {
/* 144 */       OutPt p = btmPt1.prev;
/* 145 */       while ((p.getPt().equals(btmPt1.getPt())) && (!p.equals(btmPt1))) {
/* 146 */         p = p.prev;
/*     */       }
/* 148 */       double dx1p = Math.abs(Point.LongPoint.getDeltaX(btmPt1.getPt(), p.getPt()));
/* 149 */       p = btmPt1.next;
/* 150 */       while ((p.getPt().equals(btmPt1.getPt())) && (!p.equals(btmPt1))) {
/* 151 */         p = p.next;
/*     */       }
/* 153 */       double dx1n = Math.abs(Point.LongPoint.getDeltaX(btmPt1.getPt(), p.getPt()));
/*     */       
/* 155 */       p = btmPt2.prev;
/* 156 */       while ((p.getPt().equals(btmPt2.getPt())) && (!p.equals(btmPt2))) {
/* 157 */         p = p.prev;
/*     */       }
/* 159 */       double dx2p = Math.abs(Point.LongPoint.getDeltaX(btmPt2.getPt(), p.getPt()));
/* 160 */       p = btmPt2.next;
/* 161 */       while ((p.getPt().equals(btmPt2.getPt())) && (p.equals(btmPt2))) {
/* 162 */         p = p.next;
/*     */       }
/* 164 */       double dx2n = Math.abs(Point.LongPoint.getDeltaX(btmPt2.getPt(), p.getPt()));
/* 165 */       return ((dx1p >= dx2p) && (dx1p >= dx2n)) || ((dx1n >= dx2p) && (dx1n >= dx2n));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public OutPt duplicate(boolean InsertAfter)
/*     */     {
/* 175 */       OutPt result = new OutPt();
/* 176 */       result.setPt(new Point.LongPoint(getPt()));
/* 177 */       result.idx = this.idx;
/* 178 */       if (InsertAfter) {
/* 179 */         result.next = this.next;
/* 180 */         result.prev = this;
/* 181 */         this.next.prev = result;
/* 182 */         this.next = result;
/*     */       }
/*     */       else {
/* 185 */         result.prev = this.prev;
/* 186 */         result.next = this;
/* 187 */         this.prev.next = result;
/* 188 */         this.prev = result;
/*     */       }
/* 190 */       return result;
/*     */     }
/*     */     
/*     */     OutPt getBottomPt() {
/* 194 */       OutPt dups = null;
/* 195 */       OutPt p = this.next;
/* 196 */       OutPt pp = this;
/* 197 */       while (p != pp) {
/* 198 */         if (p.getPt().getY() > pp.getPt().getY()) {
/* 199 */           pp = p;
/* 200 */           dups = null;
/*     */         }
/* 202 */         else if ((p.getPt().getY() == pp.getPt().getY()) && (p.getPt().getX() <= pp.getPt().getX())) {
/* 203 */           if (p.getPt().getX() < pp.getPt().getX()) {
/* 204 */             dups = null;
/* 205 */             pp = p;
/*     */ 
/*     */           }
/* 208 */           else if ((p.next != pp) && (p.prev != pp)) {
/* 209 */             dups = p;
/*     */           }
/*     */         }
/*     */         
/* 213 */         p = p.next;
/*     */       }
/* 215 */       if (dups != null)
/*     */       {
/* 217 */         while (dups != p) {
/* 218 */           if (!isFirstBottomPt(p, dups)) {
/* 219 */             pp = dups;
/*     */           }
/* 221 */           dups = dups.next;
/* 222 */           while (!dups.getPt().equals(pp.getPt())) {
/* 223 */             dups = dups.next;
/*     */           }
/*     */         }
/*     */       }
/* 227 */       return pp;
/*     */     }
/*     */     
/*     */     public int getPointCount()
/*     */     {
/* 232 */       int result = 0;
/* 233 */       OutPt p = this;
/*     */       do {
/* 235 */         result++;
/* 236 */         p = p.next;
/*     */       }
/* 238 */       while ((p != this) && (p != null));
/* 239 */       return result;
/*     */     }
/*     */     
/*     */     public Point.LongPoint getPt() {
/* 243 */       return this.pt;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void reversePolyPtLinks()
/*     */     {
/* 250 */       OutPt pp1 = this;
/*     */       do {
/* 252 */         OutPt pp2 = pp1.next;
/* 253 */         pp1.next = pp1.prev;
/* 254 */         pp1.prev = pp2;
/* 255 */         pp1 = pp2;
/*     */       }
/* 257 */       while (pp1 != this);
/*     */     }
/*     */     
/*     */     public void setPt(Point.LongPoint pt) {
/* 261 */       this.pt = pt;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static class Maxima
/*     */   {
/*     */     protected long X;
/*     */     protected Maxima Next;
/*     */     protected Maxima Prev;
/*     */   }
/*     */   
/*     */   static class OutRec
/*     */   {
/*     */     int Idx;
/*     */     boolean isHole;
/*     */     boolean isOpen;
/*     */     OutRec firstLeft;
/*     */     protected Path.OutPt pts;
/*     */     Path.OutPt bottomPt;
/*     */     PolyNode polyNode;
/*     */     
/*     */     public double area()
/*     */     {
/* 284 */       Path.OutPt op = this.pts;
/* 285 */       if (op == null) {
/* 286 */         return 0.0D;
/*     */       }
/* 288 */       double a = 0.0D;
/*     */       do {
/* 290 */         a += (op.prev.getPt().getX() + op.getPt().getX()) * (op.prev.getPt().getY() - op.getPt().getY());
/* 291 */         op = op.next;
/*     */       }
/* 293 */       while (op != this.pts);
/* 294 */       return a * 0.5D;
/*     */     }
/*     */     
/*     */ 
/*     */     public void fixHoleLinkage()
/*     */     {
/* 300 */       if ((this.firstLeft == null) || ((this.isHole != this.firstLeft.isHole) && (this.firstLeft.pts != null))) {
/* 301 */         return;
/*     */       }
/*     */       
/* 304 */       OutRec orfl = this.firstLeft;
/* 305 */       while ((orfl != null) && ((orfl.isHole == this.isHole) || (orfl.pts == null))) {
/* 306 */         orfl = orfl.firstLeft;
/*     */       }
/* 308 */       this.firstLeft = orfl;
/*     */     }
/*     */     
/*     */     public Path.OutPt getPoints() {
/* 312 */       return this.pts;
/*     */     }
/*     */     
/*     */     public void setPoints(Path.OutPt pts) {
/* 316 */       this.pts = pts;
/*     */     }
/*     */   }
/*     */   
/*     */   private static OutPt excludeOp(OutPt op) {
/* 321 */     OutPt result = op.prev;
/* 322 */     result.next = op.next;
/* 323 */     op.next.prev = result;
/* 324 */     result.idx = 0;
/* 325 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Path() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Path(Point.LongPoint[] points)
/*     */   {
/* 338 */     this();
/* 339 */     for (Point.LongPoint point : points) {
/* 340 */       add(point);
/*     */     }
/*     */   }
/*     */   
/*     */   public Path(int cnt) {
/* 345 */     super(cnt);
/*     */   }
/*     */   
/*     */   public Path(Collection<? extends Point.LongPoint> c) {
/* 349 */     super(c);
/*     */   }
/*     */   
/*     */   public double area() {
/* 353 */     int cnt = size();
/* 354 */     if (cnt < 3) {
/* 355 */       return 0.0D;
/*     */     }
/* 357 */     double a = 0.0D;
/* 358 */     int i = 0; for (int j = cnt - 1; i < cnt; i++) {
/* 359 */       a += (((Point.LongPoint)get(j)).getX() + ((Point.LongPoint)get(i)).getX()) * (((Point.LongPoint)get(j)).getY() - ((Point.LongPoint)get(i)).getY());
/* 360 */       j = i;
/*     */     }
/* 362 */     return -a * 0.5D;
/*     */   }
/*     */   
/*     */   public Path cleanPolygon() {
/* 366 */     return cleanPolygon(1.415D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Path cleanPolygon(double distance)
/*     */   {
/* 374 */     int cnt = size();
/*     */     
/* 376 */     if (cnt == 0) {
/* 377 */       return new Path();
/*     */     }
/*     */     
/* 380 */     OutPt[] outPts = new OutPt[cnt];
/* 381 */     for (int i = 0; i < cnt; i++) {
/* 382 */       outPts[i] = new OutPt();
/*     */     }
/*     */     
/* 385 */     for (int i = 0; i < cnt; i++) {
/* 386 */       outPts[i].pt = ((Point.LongPoint)get(i));
/* 387 */       outPts[i].next = outPts[((i + 1) % cnt)];
/* 388 */       outPts[i].next.prev = outPts[i];
/* 389 */       outPts[i].idx = 0;
/*     */     }
/*     */     
/* 392 */     double distSqrd = distance * distance;
/* 393 */     OutPt op = outPts[0];
/* 394 */     while ((op.idx == 0) && (op.next != op.prev)) {
/* 395 */       if (Point.arePointsClose(op.pt, op.prev.pt, distSqrd)) {
/* 396 */         op = excludeOp(op);
/* 397 */         cnt--;
/*     */       }
/* 399 */       else if (Point.arePointsClose(op.prev.pt, op.next.pt, distSqrd)) {
/* 400 */         excludeOp(op.next);
/* 401 */         op = excludeOp(op);
/* 402 */         cnt -= 2;
/*     */       }
/* 404 */       else if (Point.slopesNearCollinear(op.prev.pt, op.pt, op.next.pt, distSqrd)) {
/* 405 */         op = excludeOp(op);
/* 406 */         cnt--;
/*     */       }
/*     */       else {
/* 409 */         op.idx = 1;
/* 410 */         op = op.next;
/*     */       }
/*     */     }
/*     */     
/* 414 */     if (cnt < 3) {
/* 415 */       cnt = 0;
/*     */     }
/* 417 */     Path result = new Path(cnt);
/* 418 */     for (int i = 0; i < cnt; i++) {
/* 419 */       result.add(op.pt);
/* 420 */       op = op.next;
/*     */     }
/* 422 */     outPts = null;
/* 423 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int isPointInPolygon(Point.LongPoint pt)
/*     */   {
/* 430 */     int result = 0;
/* 431 */     int cnt = size();
/* 432 */     if (cnt < 3) {
/* 433 */       return 0;
/*     */     }
/* 435 */     Point.LongPoint ip = (Point.LongPoint)get(0);
/* 436 */     for (int i = 1; i <= cnt; i++) {
/* 437 */       Point.LongPoint ipNext = i == cnt ? (Point.LongPoint)get(0) : (Point.LongPoint)get(i);
/* 438 */       if (ipNext.getY() == pt.getY()) {
/* 439 */         if (ipNext.getX() != pt.getX()) { if (ip.getY() == pt.getY()) if ((ipNext.getX() > pt.getX() ? 1 : 0) != (ip.getX() < pt.getX() ? 1 : 0)) {}
/* 440 */         } else { return -1;
/*     */         }
/*     */       }
/* 443 */       if ((ip.getY() < pt.getY() ? 1 : 0) != (ipNext.getY() < pt.getY() ? 1 : 0)) {
/* 444 */         if (ip.getX() >= pt.getX()) {
/* 445 */           if (ipNext.getX() > pt.getX()) {
/* 446 */             result = 1 - result;
/*     */           }
/*     */           else
/*     */           {
/* 450 */             double d = (ip.getX() - pt.getX()) * (ipNext.getY() - pt.getY()) - (ipNext.getX() - pt.getX()) * (ip.getY() - pt.getY());
/* 451 */             if (d == 0.0D) {
/* 452 */               return -1;
/*     */             }
/* 454 */             if ((d > 0.0D ? 1 : 0) == (ipNext.getY() > ip.getY() ? 1 : 0)) {
/* 455 */               result = 1 - result;
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 460 */         else if (ipNext.getX() > pt.getX())
/*     */         {
/* 462 */           double d = (ip.getX() - pt.getX()) * (ipNext.getY() - pt.getY()) - (ipNext.getX() - pt.getX()) * (ip.getY() - pt.getY());
/* 463 */           if (d == 0.0D) {
/* 464 */             return -1;
/*     */           }
/* 466 */           if ((d > 0.0D ? 1 : 0) == (ipNext.getY() > ip.getY() ? 1 : 0)) {
/* 467 */             result = 1 - result;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 472 */       ip = ipNext;
/*     */     }
/* 474 */     return result;
/*     */   }
/*     */   
/*     */   public boolean orientation() {
/* 478 */     return area() >= 0.0D;
/*     */   }
/*     */   
/*     */   public void reverse() {
/* 482 */     Collections.reverse(this);
/*     */   }
/*     */   
/*     */   public Path TranslatePath(Point.LongPoint delta) {
/* 486 */     Path outPath = new Path(size());
/* 487 */     for (int i = 0; i < size(); i++) {
/* 488 */       outPath.add(new Point.LongPoint(((Point.LongPoint)get(i)).getX() + delta.getX(), ((Point.LongPoint)get(i)).getY() + delta.getY()));
/*     */     }
/* 490 */     return outPath;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/Path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */