/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.text.exceptions.UnsupportedPdfException;
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import com.itextpdf.text.pdf.FilterHandlers;
/*     */ import com.itextpdf.text.pdf.PRTokeniser;
/*     */ import com.itextpdf.text.pdf.PdfArray;
/*     */ import com.itextpdf.text.pdf.PdfContentParser;
/*     */ import com.itextpdf.text.pdf.PdfDictionary;
/*     */ import com.itextpdf.text.pdf.PdfName;
/*     */ import com.itextpdf.text.pdf.PdfNumber;
/*     */ import com.itextpdf.text.pdf.PdfObject;
/*     */ import com.itextpdf.text.pdf.PdfReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InlineImageUtils
/*     */ {
/*  70 */   private static final Logger LOGGER = LoggerFactory.getLogger(InlineImageUtils.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   public static class InlineImageParseException
/*     */     extends IOException
/*     */   {
/*     */     private static final long serialVersionUID = 233760879000268548L;
/*     */     
/*     */ 
/*     */ 
/*     */     public InlineImageParseException(String message)
/*     */     {
/*  83 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   private static final Map<PdfName, PdfName> inlineImageEntryAbbreviationMap = new HashMap();
/*     */   private static final Map<PdfName, PdfName> inlineImageColorSpaceAbbreviationMap;
/*     */   
/*  97 */   static { inlineImageEntryAbbreviationMap.put(PdfName.BITSPERCOMPONENT, PdfName.BITSPERCOMPONENT);
/*  98 */     inlineImageEntryAbbreviationMap.put(PdfName.COLORSPACE, PdfName.COLORSPACE);
/*  99 */     inlineImageEntryAbbreviationMap.put(PdfName.DECODE, PdfName.DECODE);
/* 100 */     inlineImageEntryAbbreviationMap.put(PdfName.DECODEPARMS, PdfName.DECODEPARMS);
/* 101 */     inlineImageEntryAbbreviationMap.put(PdfName.FILTER, PdfName.FILTER);
/* 102 */     inlineImageEntryAbbreviationMap.put(PdfName.HEIGHT, PdfName.HEIGHT);
/* 103 */     inlineImageEntryAbbreviationMap.put(PdfName.IMAGEMASK, PdfName.IMAGEMASK);
/* 104 */     inlineImageEntryAbbreviationMap.put(PdfName.INTENT, PdfName.INTENT);
/* 105 */     inlineImageEntryAbbreviationMap.put(PdfName.INTERPOLATE, PdfName.INTERPOLATE);
/* 106 */     inlineImageEntryAbbreviationMap.put(PdfName.WIDTH, PdfName.WIDTH);
/*     */     
/*     */ 
/* 109 */     inlineImageEntryAbbreviationMap.put(new PdfName("BPC"), PdfName.BITSPERCOMPONENT);
/* 110 */     inlineImageEntryAbbreviationMap.put(new PdfName("CS"), PdfName.COLORSPACE);
/* 111 */     inlineImageEntryAbbreviationMap.put(new PdfName("D"), PdfName.DECODE);
/* 112 */     inlineImageEntryAbbreviationMap.put(new PdfName("DP"), PdfName.DECODEPARMS);
/* 113 */     inlineImageEntryAbbreviationMap.put(new PdfName("F"), PdfName.FILTER);
/* 114 */     inlineImageEntryAbbreviationMap.put(new PdfName("H"), PdfName.HEIGHT);
/* 115 */     inlineImageEntryAbbreviationMap.put(new PdfName("IM"), PdfName.IMAGEMASK);
/* 116 */     inlineImageEntryAbbreviationMap.put(new PdfName("I"), PdfName.INTERPOLATE);
/* 117 */     inlineImageEntryAbbreviationMap.put(new PdfName("W"), PdfName.WIDTH);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     inlineImageColorSpaceAbbreviationMap = new HashMap();
/*     */     
/* 127 */     inlineImageColorSpaceAbbreviationMap.put(new PdfName("G"), PdfName.DEVICEGRAY);
/* 128 */     inlineImageColorSpaceAbbreviationMap.put(new PdfName("RGB"), PdfName.DEVICERGB);
/* 129 */     inlineImageColorSpaceAbbreviationMap.put(new PdfName("CMYK"), PdfName.DEVICECMYK);
/* 130 */     inlineImageColorSpaceAbbreviationMap.put(new PdfName("I"), PdfName.INDEXED);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     inlineImageFilterAbbreviationMap = new HashMap();
/*     */     
/* 140 */     inlineImageFilterAbbreviationMap.put(new PdfName("AHx"), PdfName.ASCIIHEXDECODE);
/* 141 */     inlineImageFilterAbbreviationMap.put(new PdfName("A85"), PdfName.ASCII85DECODE);
/* 142 */     inlineImageFilterAbbreviationMap.put(new PdfName("LZW"), PdfName.LZWDECODE);
/* 143 */     inlineImageFilterAbbreviationMap.put(new PdfName("Fl"), PdfName.FLATEDECODE);
/* 144 */     inlineImageFilterAbbreviationMap.put(new PdfName("RL"), PdfName.RUNLENGTHDECODE);
/* 145 */     inlineImageFilterAbbreviationMap.put(new PdfName("CCF"), PdfName.CCITTFAXDECODE);
/* 146 */     inlineImageFilterAbbreviationMap.put(new PdfName("DCT"), PdfName.DCTDECODE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InlineImageInfo parseInlineImage(PdfContentParser ps, PdfDictionary colorSpaceDic)
/*     */     throws IOException
/*     */   {
/* 159 */     PdfDictionary inlineImageDictionary = parseInlineImageDictionary(ps);
/* 160 */     byte[] samples = parseInlineImageSamples(inlineImageDictionary, colorSpaceDic, ps);
/* 161 */     return new InlineImageInfo(samples, inlineImageDictionary);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PdfDictionary parseInlineImageDictionary(PdfContentParser ps)
/*     */     throws IOException
/*     */   {
/* 173 */     PdfDictionary dictionary = new PdfDictionary();
/*     */     
/* 175 */     for (PdfObject key = ps.readPRObject(); (key != null) && (!"ID".equals(key.toString())); key = ps.readPRObject()) {
/* 176 */       PdfObject value = ps.readPRObject();
/*     */       
/* 178 */       PdfName resolvedKey = (PdfName)inlineImageEntryAbbreviationMap.get(key);
/* 179 */       if (resolvedKey == null) {
/* 180 */         resolvedKey = (PdfName)key;
/*     */       }
/* 182 */       dictionary.put(resolvedKey, getAlternateValue(resolvedKey, value));
/*     */     }
/*     */     
/* 185 */     int ch = ps.getTokeniser().read();
/* 186 */     if (!PRTokeniser.isWhitespace(ch)) {
/* 187 */       throw new IOException("Unexpected character " + ch + " found after ID in inline image");
/*     */     }
/* 189 */     return dictionary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PdfObject getAlternateValue(PdfName key, PdfObject value)
/*     */   {
/* 199 */     if (key == PdfName.FILTER) {
/* 200 */       if ((value instanceof PdfName)) {
/* 201 */         PdfName altValue = (PdfName)inlineImageFilterAbbreviationMap.get(value);
/* 202 */         if (altValue != null)
/* 203 */           return altValue;
/* 204 */       } else if ((value instanceof PdfArray)) {
/* 205 */         PdfArray array = (PdfArray)value;
/* 206 */         PdfArray altArray = new PdfArray();
/* 207 */         int count = array.size();
/* 208 */         for (int i = 0; i < count; i++) {
/* 209 */           altArray.add(getAlternateValue(key, array.getPdfObject(i)));
/*     */         }
/* 211 */         return altArray;
/*     */       }
/* 213 */     } else if (key == PdfName.COLORSPACE) {
/* 214 */       PdfName altValue = (PdfName)inlineImageColorSpaceAbbreviationMap.get(value);
/* 215 */       if (altValue != null) {
/* 216 */         return altValue;
/*     */       }
/*     */     }
/* 219 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getComponentsPerPixel(PdfName colorSpaceName, PdfDictionary colorSpaceDic)
/*     */   {
/* 227 */     if (colorSpaceName == null)
/* 228 */       return 1;
/* 229 */     if (colorSpaceName.equals(PdfName.DEVICEGRAY))
/* 230 */       return 1;
/* 231 */     if (colorSpaceName.equals(PdfName.DEVICERGB))
/* 232 */       return 3;
/* 233 */     if (colorSpaceName.equals(PdfName.DEVICECMYK)) {
/* 234 */       return 4;
/*     */     }
/* 236 */     if (colorSpaceDic != null) {
/* 237 */       PdfArray colorSpace = colorSpaceDic.getAsArray(colorSpaceName);
/* 238 */       if (colorSpace != null) {
/* 239 */         if (PdfName.INDEXED.equals(colorSpace.getAsName(0))) {
/* 240 */           return 1;
/*     */         }
/*     */       }
/*     */       else {
/* 244 */         PdfName tempName = colorSpaceDic.getAsName(colorSpaceName);
/* 245 */         if (tempName != null) {
/* 246 */           return getComponentsPerPixel(tempName, colorSpaceDic);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 251 */     throw new IllegalArgumentException("Unexpected color space " + colorSpaceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int computeBytesPerRow(PdfDictionary imageDictionary, PdfDictionary colorSpaceDic)
/*     */   {
/* 262 */     PdfNumber wObj = imageDictionary.getAsNumber(PdfName.WIDTH);
/* 263 */     PdfNumber bpcObj = imageDictionary.getAsNumber(PdfName.BITSPERCOMPONENT);
/* 264 */     int cpp = getComponentsPerPixel(imageDictionary.getAsName(PdfName.COLORSPACE), colorSpaceDic);
/*     */     
/* 266 */     int w = wObj.intValue();
/* 267 */     int bpc = bpcObj != null ? bpcObj.intValue() : 1;
/*     */     
/*     */ 
/* 270 */     int bytesPerRow = (w * bpc * cpp + 7) / 8;
/*     */     
/* 272 */     return bytesPerRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final Map<PdfName, PdfName> inlineImageFilterAbbreviationMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] parseUnfilteredSamples(PdfDictionary imageDictionary, PdfDictionary colorSpaceDic, PdfContentParser ps)
/*     */     throws IOException
/*     */   {
/* 288 */     if (imageDictionary.contains(PdfName.FILTER)) {
/* 289 */       throw new IllegalArgumentException("Dictionary contains filters");
/*     */     }
/* 291 */     PdfNumber h = imageDictionary.getAsNumber(PdfName.HEIGHT);
/*     */     
/* 293 */     int bytesToRead = computeBytesPerRow(imageDictionary, colorSpaceDic) * h.intValue();
/* 294 */     byte[] bytes = new byte[bytesToRead];
/* 295 */     PRTokeniser tokeniser = ps.getTokeniser();
/*     */     
/* 297 */     int shouldBeWhiteSpace = tokeniser.read();
/*     */     
/*     */ 
/* 300 */     int startIndex = 0;
/* 301 */     if ((!PRTokeniser.isWhitespace(shouldBeWhiteSpace)) || (shouldBeWhiteSpace == 0)) {
/* 302 */       bytes[0] = ((byte)shouldBeWhiteSpace);
/* 303 */       startIndex++;
/*     */     }
/* 305 */     for (int i = startIndex; i < bytesToRead; i++) {
/* 306 */       int ch = tokeniser.read();
/* 307 */       if (ch == -1) {
/* 308 */         throw new InlineImageParseException("End of content stream reached before end of image data");
/*     */       }
/* 310 */       bytes[i] = ((byte)ch);
/*     */     }
/* 312 */     PdfObject ei = ps.readPRObject();
/* 313 */     if (!ei.toString().equals("EI"))
/*     */     {
/*     */ 
/* 316 */       PdfObject ei2 = ps.readPRObject();
/* 317 */       if (!ei2.toString().equals("EI"))
/* 318 */         throw new InlineImageParseException("EI not found after end of image data");
/*     */     }
/* 320 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] parseInlineImageSamples(PdfDictionary imageDictionary, PdfDictionary colorSpaceDic, PdfContentParser ps)
/*     */     throws IOException
/*     */   {
/* 336 */     if (!imageDictionary.contains(PdfName.FILTER)) {
/* 337 */       return parseUnfilteredSamples(imageDictionary, colorSpaceDic, ps);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 347 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 348 */     ByteArrayOutputStream accumulated = new ByteArrayOutputStream();
/*     */     
/* 350 */     int found = 0;
/* 351 */     PRTokeniser tokeniser = ps.getTokeniser();
/*     */     int ch;
/* 353 */     while ((ch = tokeniser.read()) != -1) {
/* 354 */       if ((found == 0) && (PRTokeniser.isWhitespace(ch))) {
/* 355 */         found++;
/* 356 */         accumulated.write(ch);
/* 357 */       } else if ((found == 1) && (ch == 69)) {
/* 358 */         found++;
/* 359 */         accumulated.write(ch);
/* 360 */       } else if ((found == 1) && (PRTokeniser.isWhitespace(ch)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 365 */         baos.write(accumulated.toByteArray());
/* 366 */         accumulated.reset();
/* 367 */         accumulated.write(ch);
/* 368 */       } else if ((found == 2) && (ch == 73)) {
/* 369 */         found++;
/* 370 */         accumulated.write(ch);
/* 371 */       } else if ((found == 3) && (PRTokeniser.isWhitespace(ch))) {
/* 372 */         byte[] tmp = baos.toByteArray();
/* 373 */         if (inlineImageStreamBytesAreComplete(tmp, imageDictionary)) {
/* 374 */           return tmp;
/*     */         }
/* 376 */         baos.write(accumulated.toByteArray());
/* 377 */         accumulated.reset();
/*     */         
/* 379 */         baos.write(ch);
/* 380 */         found = 0;
/*     */       }
/*     */       else {
/* 383 */         baos.write(accumulated.toByteArray());
/* 384 */         accumulated.reset();
/*     */         
/* 386 */         baos.write(ch);
/* 387 */         found = 0;
/*     */       }
/*     */     }
/* 390 */     throw new InlineImageParseException("Could not find image data or EI");
/*     */   }
/*     */   
/*     */   private static boolean inlineImageStreamBytesAreComplete(byte[] samples, PdfDictionary imageDictionary) {
/*     */     try {
/* 395 */       PdfReader.decodeBytes(samples, imageDictionary, FilterHandlers.getDefaultFilterHandlers());
/* 396 */       return true;
/*     */     }
/*     */     catch (UnsupportedPdfException e) {
/* 399 */       LOGGER.warn(e.getMessage());
/* 400 */       return true;
/*     */     }
/*     */     catch (IOException e) {}
/* 403 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/InlineImageUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */