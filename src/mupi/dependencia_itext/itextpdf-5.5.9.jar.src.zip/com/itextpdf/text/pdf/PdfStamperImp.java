/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.awt.geom.Point;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.Version;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.exceptions.BadPasswordException;
/*      */ import com.itextpdf.text.log.Counter;
/*      */ import com.itextpdf.text.log.CounterFactory;
/*      */ import com.itextpdf.text.pdf.collection.PdfCollection;
/*      */ import com.itextpdf.text.pdf.internal.PdfVersionImp;
/*      */ import com.itextpdf.text.pdf.internal.PdfViewerPreferencesImp;
/*      */ import com.itextpdf.text.xml.xmp.PdfProperties;
/*      */ import com.itextpdf.text.xml.xmp.XmpBasicProperties;
/*      */ import com.itextpdf.text.xml.xmp.XmpWriter;
/*      */ import com.itextpdf.xmp.XMPException;
/*      */ import com.itextpdf.xmp.XMPMeta;
/*      */ import com.itextpdf.xmp.XMPMetaFactory;
/*      */ import com.itextpdf.xmp.options.SerializeOptions;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class PdfStamperImp
/*      */   extends PdfWriter
/*      */ {
/*   83 */   HashMap<PdfReader, IntHashtable> readers2intrefs = new HashMap();
/*   84 */   HashMap<PdfReader, RandomAccessFileOrArray> readers2file = new HashMap();
/*      */   protected RandomAccessFileOrArray file;
/*      */   PdfReader reader;
/*   87 */   IntHashtable myXref = new IntHashtable();
/*      */   
/*      */ 
/*      */ 
/*   91 */   HashMap<PdfDictionary, PageStamp> pagesToContent = new HashMap();
/*   92 */   protected boolean closed = false;
/*      */   
/*      */ 
/*      */ 
/*   96 */   private boolean rotateContents = true;
/*      */   protected AcroFields acroFields;
/*   98 */   protected boolean flat = false;
/*   99 */   protected boolean flatFreeText = false;
/*  100 */   protected boolean flatannotations = false;
/*  101 */   protected int[] namePtr = { 0 };
/*  102 */   protected HashSet<String> partialFlattening = new HashSet();
/*  103 */   protected boolean useVp = false;
/*  104 */   protected PdfViewerPreferencesImp viewerPreferences = new PdfViewerPreferencesImp();
/*  105 */   protected HashSet<PdfTemplate> fieldTemplates = new HashSet();
/*  106 */   protected boolean fieldsAdded = false;
/*  107 */   protected int sigFlags = 0;
/*      */   protected boolean append;
/*      */   protected IntHashtable marked;
/*      */   protected int initialXrefSize;
/*      */   protected PdfAction openAction;
/*  112 */   protected HashMap<Object, PdfObject> namedDestinations = new HashMap();
/*      */   
/*  114 */   protected Counter COUNTER = CounterFactory.getCounter(PdfStamper.class);
/*      */   
/*      */   protected Counter getCounter() {
/*  117 */     return this.COUNTER;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  123 */   private boolean originalLayersAreRead = false;
/*      */   
/*  125 */   private double[] DEFAULT_MATRIX = { 1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfStamperImp(PdfReader reader, OutputStream os, char pdfVersion, boolean append)
/*      */     throws DocumentException, IOException
/*      */   {
/*  139 */     super(new PdfDocument(), os);
/*  140 */     if (!reader.isOpenedWithFullPermissions())
/*  141 */       throw new BadPasswordException(MessageLocalization.getComposedMessage("pdfreader.not.opened.with.owner.password", new Object[0]));
/*  142 */     if (reader.isTampered())
/*  143 */       throw new DocumentException(MessageLocalization.getComposedMessage("the.original.document.was.reused.read.it.again.from.file", new Object[0]));
/*  144 */     reader.setTampered(true);
/*  145 */     this.reader = reader;
/*  146 */     this.file = reader.getSafeFile();
/*  147 */     this.append = append;
/*  148 */     if ((reader.isEncrypted()) && ((append) || (PdfReader.unethicalreading))) {
/*  149 */       this.crypto = new PdfEncryption(reader.getDecrypt());
/*      */     }
/*  151 */     if (append) {
/*  152 */       if (reader.isRebuilt())
/*  153 */         throw new DocumentException(MessageLocalization.getComposedMessage("append.mode.requires.a.document.without.errors.even.if.recovery.was.possible", new Object[0]));
/*  154 */       this.pdf_version.setAppendmode(true);
/*  155 */       if (pdfVersion == 0) {
/*  156 */         this.pdf_version.setPdfVersion(reader.getPdfVersion());
/*      */       } else {
/*  158 */         this.pdf_version.setPdfVersion(pdfVersion);
/*      */       }
/*  160 */       byte[] buf = new byte[' '];
/*      */       int n;
/*  162 */       while ((n = this.file.read(buf)) > 0)
/*  163 */         this.os.write(buf, 0, n);
/*  164 */       this.prevxref = reader.getLastXref();
/*  165 */       reader.setAppendable(true);
/*      */     }
/*  167 */     else if (pdfVersion == 0) {
/*  168 */       super.setPdfVersion(reader.getPdfVersion());
/*      */     } else {
/*  170 */       super.setPdfVersion(pdfVersion);
/*      */     }
/*      */     
/*  173 */     if (reader.isTagged()) {
/*  174 */       setTagged();
/*      */     }
/*      */     
/*  177 */     super.open();
/*  178 */     this.pdf.addWriter(this);
/*  179 */     if (append) {
/*  180 */       this.body.setRefnum(reader.getXrefSize());
/*  181 */       this.marked = new IntHashtable();
/*  182 */       if (reader.isNewXrefType())
/*  183 */         this.fullCompression = true;
/*  184 */       if (reader.isHybridXref())
/*  185 */         this.fullCompression = false;
/*      */     }
/*  187 */     this.initialXrefSize = reader.getXrefSize();
/*  188 */     readColorProfile();
/*      */   }
/*      */   
/*      */   protected void readColorProfile() {
/*  192 */     PdfObject outputIntents = this.reader.getCatalog().getAsArray(PdfName.OUTPUTINTENTS);
/*  193 */     if ((outputIntents != null) && (((PdfArray)outputIntents).size() > 0)) {
/*  194 */       PdfStream iccProfileStream = null;
/*  195 */       for (int i = 0; i < ((PdfArray)outputIntents).size(); i++) {
/*  196 */         PdfDictionary outputIntentDictionary = ((PdfArray)outputIntents).getAsDict(i);
/*  197 */         if (outputIntentDictionary != null) {
/*  198 */           iccProfileStream = outputIntentDictionary.getAsStream(PdfName.DESTOUTPUTPROFILE);
/*  199 */           if (iccProfileStream != null) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*  204 */       if ((iccProfileStream instanceof PRStream)) {
/*      */         try {
/*  206 */           this.colorProfile = ICC_Profile.getInstance(PdfReader.getStreamBytes((PRStream)iccProfileStream));
/*      */         } catch (IOException exc) {
/*  208 */           throw new ExceptionConverter(exc);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setViewerPreferences() {
/*  215 */     this.reader.setViewerPreferences(this.viewerPreferences);
/*  216 */     markUsed(this.reader.getTrailer().get(PdfName.ROOT));
/*      */   }
/*      */   
/*      */   protected void close(Map<String, String> moreInfo) throws IOException {
/*  220 */     if (this.closed) {
/*  221 */       return;
/*      */     }
/*  223 */     if (this.useVp) {
/*  224 */       setViewerPreferences();
/*      */     }
/*  226 */     if (this.flat) {
/*  227 */       flatFields();
/*      */     }
/*  229 */     if (this.flatFreeText) {
/*  230 */       flatFreeTextFields();
/*      */     }
/*  232 */     if (this.flatannotations) {
/*  233 */       flattenAnnotations();
/*      */     }
/*  235 */     addFieldResources();
/*  236 */     PdfDictionary catalog = this.reader.getCatalog();
/*  237 */     getPdfVersion().addToCatalog(catalog);
/*  238 */     PdfDictionary acroForm = (PdfDictionary)PdfReader.getPdfObject(catalog.get(PdfName.ACROFORM), this.reader.getCatalog());
/*  239 */     if ((this.acroFields != null) && (this.acroFields.getXfa().isChanged())) {
/*  240 */       markUsed(acroForm);
/*  241 */       if (!this.flat) {
/*  242 */         this.acroFields.getXfa().setXfa(this);
/*      */       }
/*      */     }
/*  245 */     if ((this.sigFlags != 0) && 
/*  246 */       (acroForm != null)) {
/*  247 */       acroForm.put(PdfName.SIGFLAGS, new PdfNumber(this.sigFlags));
/*  248 */       markUsed(acroForm);
/*  249 */       markUsed(catalog);
/*      */     }
/*      */     
/*  252 */     this.closed = true;
/*  253 */     addSharedObjectsToBody();
/*  254 */     setOutlines();
/*  255 */     setJavaScript();
/*  256 */     addFileAttachments();
/*      */     
/*  258 */     if (this.extraCatalog != null) {
/*  259 */       catalog.mergeDifferent(this.extraCatalog);
/*      */     }
/*  261 */     if (this.openAction != null) {
/*  262 */       catalog.put(PdfName.OPENACTION, this.openAction);
/*      */     }
/*  264 */     if (this.pdf.pageLabels != null) {
/*  265 */       catalog.put(PdfName.PAGELABELS, this.pdf.pageLabels.getDictionary(this));
/*      */     }
/*      */     
/*  268 */     if (!this.documentOCG.isEmpty()) {
/*  269 */       fillOCProperties(false);
/*  270 */       PdfDictionary ocdict = catalog.getAsDict(PdfName.OCPROPERTIES);
/*  271 */       if (ocdict == null) {
/*  272 */         this.reader.getCatalog().put(PdfName.OCPROPERTIES, this.OCProperties);
/*      */       } else {
/*  274 */         ocdict.put(PdfName.OCGS, this.OCProperties.get(PdfName.OCGS));
/*  275 */         PdfDictionary ddict = ocdict.getAsDict(PdfName.D);
/*  276 */         if (ddict == null) {
/*  277 */           ddict = new PdfDictionary();
/*  278 */           ocdict.put(PdfName.D, ddict);
/*      */         }
/*  280 */         ddict.put(PdfName.ORDER, this.OCProperties.getAsDict(PdfName.D).get(PdfName.ORDER));
/*  281 */         ddict.put(PdfName.RBGROUPS, this.OCProperties.getAsDict(PdfName.D).get(PdfName.RBGROUPS));
/*  282 */         ddict.put(PdfName.OFF, this.OCProperties.getAsDict(PdfName.D).get(PdfName.OFF));
/*  283 */         ddict.put(PdfName.AS, this.OCProperties.getAsDict(PdfName.D).get(PdfName.AS));
/*      */       }
/*  285 */       PdfWriter.checkPdfIsoConformance(this, 7, this.OCProperties);
/*      */     }
/*      */     
/*  288 */     int skipInfo = -1;
/*  289 */     PdfIndirectReference iInfo = this.reader.getTrailer().getAsIndirectObject(PdfName.INFO);
/*  290 */     if (iInfo != null) {
/*  291 */       skipInfo = iInfo.getNumber();
/*      */     }
/*  293 */     PdfDictionary oldInfo = this.reader.getTrailer().getAsDict(PdfName.INFO);
/*  294 */     String producer = null;
/*  295 */     if ((oldInfo != null) && (oldInfo.get(PdfName.PRODUCER) != null)) {
/*  296 */       producer = oldInfo.getAsString(PdfName.PRODUCER).toUnicodeString();
/*      */     }
/*  298 */     Version version = Version.getInstance();
/*  299 */     if ((producer == null) || (version.getVersion().indexOf(version.getProduct()) == -1)) {
/*  300 */       producer = version.getVersion();
/*      */     } else {
/*  302 */       int idx = producer.indexOf("; modified using");
/*      */       StringBuffer buf;
/*  304 */       StringBuffer buf; if (idx == -1) {
/*  305 */         buf = new StringBuffer(producer);
/*      */       } else
/*  307 */         buf = new StringBuffer(producer.substring(0, idx));
/*  308 */       buf.append("; modified using ");
/*  309 */       buf.append(version.getVersion());
/*  310 */       producer = buf.toString();
/*      */     }
/*  312 */     PdfIndirectReference info = null;
/*  313 */     PdfDictionary newInfo = new PdfDictionary();
/*  314 */     if (oldInfo != null) {
/*  315 */       for (Object element : oldInfo.getKeys()) {
/*  316 */         PdfName key = (PdfName)element;
/*  317 */         PdfObject value = PdfReader.getPdfObject(oldInfo.get(key));
/*  318 */         newInfo.put(key, value);
/*      */       }
/*      */     }
/*  321 */     if (moreInfo != null) {
/*  322 */       for (Map.Entry<String, String> entry : moreInfo.entrySet()) {
/*  323 */         String key = (String)entry.getKey();
/*  324 */         PdfName keyName = new PdfName(key);
/*  325 */         String value = (String)entry.getValue();
/*  326 */         if (value == null) {
/*  327 */           newInfo.remove(keyName);
/*      */         } else
/*  329 */           newInfo.put(keyName, new PdfString(value, "UnicodeBig"));
/*      */       }
/*      */     }
/*  332 */     PdfDate date = new PdfDate();
/*  333 */     newInfo.put(PdfName.MODDATE, date);
/*  334 */     newInfo.put(PdfName.PRODUCER, new PdfString(producer, "UnicodeBig"));
/*  335 */     if (this.append) {
/*  336 */       if (iInfo == null) {
/*  337 */         info = addToBody(newInfo, false).getIndirectReference();
/*      */       } else {
/*  339 */         info = addToBody(newInfo, iInfo.getNumber(), false).getIndirectReference();
/*      */       }
/*      */     } else {
/*  342 */       info = addToBody(newInfo, false).getIndirectReference();
/*      */     }
/*      */     
/*  345 */     byte[] altMetadata = null;
/*  346 */     PdfObject xmpo = PdfReader.getPdfObject(catalog.get(PdfName.METADATA));
/*  347 */     if ((xmpo != null) && (xmpo.isStream())) {
/*  348 */       altMetadata = PdfReader.getStreamBytesRaw((PRStream)xmpo);
/*  349 */       PdfReader.killIndirect(catalog.get(PdfName.METADATA));
/*      */     }
/*  351 */     PdfStream xmp = null;
/*  352 */     if (this.xmpMetadata != null) {
/*  353 */       altMetadata = this.xmpMetadata;
/*  354 */     } else if (this.xmpWriter != null) {
/*      */       try {
/*  356 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  357 */         PdfProperties.setProducer(this.xmpWriter.getXmpMeta(), producer);
/*  358 */         XmpBasicProperties.setModDate(this.xmpWriter.getXmpMeta(), date.getW3CDate());
/*  359 */         XmpBasicProperties.setMetaDataDate(this.xmpWriter.getXmpMeta(), date.getW3CDate());
/*  360 */         this.xmpWriter.serialize(baos);
/*  361 */         this.xmpWriter.close();
/*  362 */         xmp = new PdfStream(baos.toByteArray());
/*      */       } catch (XMPException exc) {
/*  364 */         this.xmpWriter = null;
/*      */       }
/*      */     }
/*  367 */     if ((xmp == null) && (altMetadata != null)) {
/*      */       try {
/*  369 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  370 */         if ((moreInfo == null) || (this.xmpMetadata != null)) {
/*  371 */           XMPMeta xmpMeta = XMPMetaFactory.parseFromBuffer(altMetadata);
/*      */           
/*  373 */           PdfProperties.setProducer(xmpMeta, producer);
/*  374 */           XmpBasicProperties.setModDate(xmpMeta, date.getW3CDate());
/*  375 */           XmpBasicProperties.setMetaDataDate(xmpMeta, date.getW3CDate());
/*      */           
/*  377 */           SerializeOptions serializeOptions = new SerializeOptions();
/*  378 */           serializeOptions.setPadding(2000);
/*  379 */           XMPMetaFactory.serialize(xmpMeta, baos, serializeOptions);
/*      */         } else {
/*  381 */           XmpWriter xmpw = createXmpWriter(baos, newInfo);
/*  382 */           xmpw.close();
/*      */         }
/*  384 */         xmp = new PdfStream(baos.toByteArray());
/*      */       } catch (XMPException e) {
/*  386 */         xmp = new PdfStream(altMetadata);
/*      */       } catch (IOException e) {
/*  388 */         xmp = new PdfStream(altMetadata);
/*      */       }
/*      */     }
/*  391 */     if (xmp != null) {
/*  392 */       xmp.put(PdfName.TYPE, PdfName.METADATA);
/*  393 */       xmp.put(PdfName.SUBTYPE, PdfName.XML);
/*  394 */       if ((this.crypto != null) && (!this.crypto.isMetadataEncrypted())) {
/*  395 */         PdfArray ar = new PdfArray();
/*  396 */         ar.add(PdfName.CRYPT);
/*  397 */         xmp.put(PdfName.FILTER, ar);
/*      */       }
/*  399 */       if ((this.append) && (xmpo != null)) {
/*  400 */         this.body.add(xmp, xmpo.getIndRef());
/*      */       } else {
/*  402 */         catalog.put(PdfName.METADATA, this.body.add(xmp).getIndirectReference());
/*  403 */         markUsed(catalog);
/*      */       }
/*      */     }
/*      */     
/*  407 */     if (!this.namedDestinations.isEmpty())
/*  408 */       updateNamedDestinations();
/*  409 */     close(info, skipInfo);
/*      */   }
/*      */   
/*      */   protected void close(PdfIndirectReference info, int skipInfo) throws IOException {
/*  413 */     alterContents();
/*  414 */     int rootN = ((PRIndirectReference)this.reader.trailer.get(PdfName.ROOT)).getNumber();
/*  415 */     if (this.append) {
/*  416 */       int[] keys = this.marked.getKeys();
/*  417 */       for (int k = 0; k < keys.length; k++) {
/*  418 */         int j = keys[k];
/*  419 */         PdfObject obj = this.reader.getPdfObjectRelease(j);
/*  420 */         if ((obj != null) && (skipInfo != j) && (j < this.initialXrefSize)) {
/*  421 */           addToBody(obj, obj.getIndRef(), j != rootN);
/*      */         }
/*      */       }
/*  424 */       for (int k = this.initialXrefSize; k < this.reader.getXrefSize(); k++) {
/*  425 */         PdfObject obj = this.reader.getPdfObject(k);
/*  426 */         if (obj != null) {
/*  427 */           addToBody(obj, getNewObjectNumber(this.reader, k, 0));
/*      */         }
/*      */       }
/*      */     } else {
/*  431 */       for (int k = 1; k < this.reader.getXrefSize(); k++) {
/*  432 */         PdfObject obj = this.reader.getPdfObjectRelease(k);
/*  433 */         if ((obj != null) && (skipInfo != k)) {
/*  434 */           addToBody(obj, getNewObjectNumber(this.reader, k, 0), k != rootN);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  439 */     PdfIndirectReference encryption = null;
/*  440 */     PdfObject fileID = null;
/*  441 */     if (this.crypto != null) {
/*  442 */       if (this.append) {
/*  443 */         encryption = this.reader.getCryptoRef();
/*      */       } else {
/*  445 */         PdfIndirectObject encryptionObject = addToBody(this.crypto.getEncryptionDictionary(), false);
/*  446 */         encryption = encryptionObject.getIndirectReference();
/*      */       }
/*  448 */       fileID = this.crypto.getFileID(true);
/*      */     } else {
/*  450 */       PdfArray IDs = this.reader.trailer.getAsArray(PdfName.ID);
/*  451 */       if ((IDs != null) && (IDs.getAsString(0) != null)) {
/*  452 */         fileID = PdfEncryption.createInfoId(IDs.getAsString(0).getBytes(), true);
/*      */       } else {
/*  454 */         fileID = PdfEncryption.createInfoId(PdfEncryption.createDocumentId(), true);
/*      */       }
/*      */     }
/*  457 */     PRIndirectReference iRoot = (PRIndirectReference)this.reader.trailer.get(PdfName.ROOT);
/*  458 */     PdfIndirectReference root = new PdfIndirectReference(0, getNewObjectNumber(this.reader, iRoot.getNumber(), 0));
/*      */     
/*  460 */     this.body.writeCrossReferenceTable(this.os, root, info, encryption, fileID, this.prevxref);
/*  461 */     if (this.fullCompression) {
/*  462 */       writeKeyInfo(this.os);
/*  463 */       this.os.write(getISOBytes("startxref\n"));
/*  464 */       this.os.write(getISOBytes(String.valueOf(this.body.offset())));
/*  465 */       this.os.write(getISOBytes("\n%%EOF\n"));
/*      */     }
/*      */     else {
/*  468 */       PdfWriter.PdfTrailer trailer = new PdfWriter.PdfTrailer(this.body.size(), this.body.offset(), root, info, encryption, fileID, this.prevxref);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  473 */       trailer.toPdf(this, this.os);
/*      */     }
/*  475 */     this.os.flush();
/*  476 */     if (isCloseStream())
/*  477 */       this.os.close();
/*  478 */     getCounter().written(this.os.getCounter());
/*      */   }
/*      */   
/*      */   void applyRotation(PdfDictionary pageN, ByteBuffer out) {
/*  482 */     if (!this.rotateContents)
/*  483 */       return;
/*  484 */     Rectangle page = this.reader.getPageSizeWithRotation(pageN);
/*  485 */     int rotation = page.getRotation();
/*  486 */     switch (rotation) {
/*      */     case 90: 
/*  488 */       out.append(PdfContents.ROTATE90);
/*  489 */       out.append(page.getTop());
/*  490 */       out.append(' ').append('0').append(PdfContents.ROTATEFINAL);
/*  491 */       break;
/*      */     case 180: 
/*  493 */       out.append(PdfContents.ROTATE180);
/*  494 */       out.append(page.getRight());
/*  495 */       out.append(' ');
/*  496 */       out.append(page.getTop());
/*  497 */       out.append(PdfContents.ROTATEFINAL);
/*  498 */       break;
/*      */     case 270: 
/*  500 */       out.append(PdfContents.ROTATE270);
/*  501 */       out.append('0').append(' ');
/*  502 */       out.append(page.getRight());
/*  503 */       out.append(PdfContents.ROTATEFINAL);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void alterContents() throws IOException
/*      */   {
/*  509 */     for (Object element : this.pagesToContent.values()) {
/*  510 */       PageStamp ps = (PageStamp)element;
/*  511 */       PdfDictionary pageN = ps.pageN;
/*  512 */       markUsed(pageN);
/*  513 */       PdfArray ar = null;
/*  514 */       PdfObject content = PdfReader.getPdfObject(pageN.get(PdfName.CONTENTS), pageN);
/*  515 */       if (content == null) {
/*  516 */         ar = new PdfArray();
/*  517 */         pageN.put(PdfName.CONTENTS, ar);
/*  518 */       } else if (content.isArray()) {
/*  519 */         ar = new PdfArray((PdfArray)content);
/*  520 */         pageN.put(PdfName.CONTENTS, ar);
/*  521 */       } else if (content.isStream()) {
/*  522 */         ar = new PdfArray();
/*  523 */         ar.add(pageN.get(PdfName.CONTENTS));
/*  524 */         pageN.put(PdfName.CONTENTS, ar);
/*      */       } else {
/*  526 */         ar = new PdfArray();
/*  527 */         pageN.put(PdfName.CONTENTS, ar);
/*      */       }
/*  529 */       ByteBuffer out = new ByteBuffer();
/*  530 */       if (ps.under != null) {
/*  531 */         out.append(PdfContents.SAVESTATE);
/*  532 */         applyRotation(pageN, out);
/*  533 */         out.append(ps.under.getInternalBuffer());
/*  534 */         out.append(PdfContents.RESTORESTATE);
/*      */       }
/*  536 */       if (ps.over != null)
/*  537 */         out.append(PdfContents.SAVESTATE);
/*  538 */       PdfStream stream = new PdfStream(out.toByteArray());
/*  539 */       stream.flateCompress(this.compressionLevel);
/*  540 */       ar.addFirst(addToBody(stream).getIndirectReference());
/*  541 */       out.reset();
/*  542 */       if (ps.over != null) {
/*  543 */         out.append(' ');
/*  544 */         out.append(PdfContents.RESTORESTATE);
/*  545 */         ByteBuffer buf = ps.over.getInternalBuffer();
/*  546 */         out.append(buf.getBuffer(), 0, ps.replacePoint);
/*  547 */         out.append(PdfContents.SAVESTATE);
/*  548 */         applyRotation(pageN, out);
/*  549 */         out.append(buf.getBuffer(), ps.replacePoint, buf.size() - ps.replacePoint);
/*  550 */         out.append(PdfContents.RESTORESTATE);
/*  551 */         stream = new PdfStream(out.toByteArray());
/*  552 */         stream.flateCompress(this.compressionLevel);
/*  553 */         ar.add(addToBody(stream).getIndirectReference());
/*      */       }
/*  555 */       alterResources(ps);
/*      */     }
/*      */   }
/*      */   
/*      */   void alterResources(PageStamp ps) {
/*  560 */     ps.pageN.put(PdfName.RESOURCES, ps.pageResources.getResources());
/*      */   }
/*      */   
/*      */   protected int getNewObjectNumber(PdfReader reader, int number, int generation)
/*      */   {
/*  565 */     IntHashtable ref = (IntHashtable)this.readers2intrefs.get(reader);
/*  566 */     if (ref != null) {
/*  567 */       int n = ref.get(number);
/*  568 */       if (n == 0) {
/*  569 */         n = getIndirectReferenceNumber();
/*  570 */         ref.put(number, n);
/*      */       }
/*  572 */       return n;
/*      */     }
/*  574 */     if (this.currentPdfReaderInstance == null) {
/*  575 */       if ((this.append) && (number < this.initialXrefSize))
/*  576 */         return number;
/*  577 */       int n = this.myXref.get(number);
/*  578 */       if (n == 0) {
/*  579 */         n = getIndirectReferenceNumber();
/*  580 */         this.myXref.put(number, n);
/*      */       }
/*  582 */       return n;
/*      */     }
/*  584 */     return this.currentPdfReaderInstance.getNewObjectNumber(number, generation);
/*      */   }
/*      */   
/*      */   RandomAccessFileOrArray getReaderFile(PdfReader reader)
/*      */   {
/*  589 */     if (this.readers2intrefs.containsKey(reader)) {
/*  590 */       RandomAccessFileOrArray raf = (RandomAccessFileOrArray)this.readers2file.get(reader);
/*  591 */       if (raf != null)
/*  592 */         return raf;
/*  593 */       return reader.getSafeFile();
/*      */     }
/*  595 */     if (this.currentPdfReaderInstance == null) {
/*  596 */       return this.file;
/*      */     }
/*  598 */     return this.currentPdfReaderInstance.getReaderFile();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerReader(PdfReader reader, boolean openFile)
/*      */     throws IOException
/*      */   {
/*  607 */     if (this.readers2intrefs.containsKey(reader))
/*  608 */       return;
/*  609 */     this.readers2intrefs.put(reader, new IntHashtable());
/*  610 */     if (openFile) {
/*  611 */       RandomAccessFileOrArray raf = reader.getSafeFile();
/*  612 */       this.readers2file.put(reader, raf);
/*  613 */       raf.reOpen();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void unRegisterReader(PdfReader reader)
/*      */   {
/*  621 */     if (!this.readers2intrefs.containsKey(reader))
/*  622 */       return;
/*  623 */     this.readers2intrefs.remove(reader);
/*  624 */     RandomAccessFileOrArray raf = (RandomAccessFileOrArray)this.readers2file.get(reader);
/*  625 */     if (raf == null)
/*  626 */       return;
/*  627 */     this.readers2file.remove(reader);
/*      */     try {
/*  629 */       raf.close();
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */   static void findAllObjects(PdfReader reader, PdfObject obj, IntHashtable hits) {
/*  635 */     if (obj == null)
/*  636 */       return;
/*  637 */     switch (obj.type()) {
/*      */     case 10: 
/*  639 */       PRIndirectReference iref = (PRIndirectReference)obj;
/*  640 */       if (reader != iref.getReader())
/*  641 */         return;
/*  642 */       if (hits.containsKey(iref.getNumber()))
/*  643 */         return;
/*  644 */       hits.put(iref.getNumber(), 1);
/*  645 */       findAllObjects(reader, PdfReader.getPdfObject(obj), hits);
/*  646 */       return;
/*      */     case 5: 
/*  648 */       PdfArray a = (PdfArray)obj;
/*  649 */       for (int k = 0; k < a.size(); k++) {
/*  650 */         findAllObjects(reader, a.getPdfObject(k), hits);
/*      */       }
/*  652 */       return;
/*      */     case 6: 
/*      */     case 7: 
/*  655 */       PdfDictionary dic = (PdfDictionary)obj;
/*  656 */       for (Object element : dic.getKeys()) {
/*  657 */         PdfName name = (PdfName)element;
/*  658 */         findAllObjects(reader, dic.get(name), hits);
/*      */       }
/*  660 */       return;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */   public void addComments(FdfReader fdf)
/*      */     throws IOException
/*      */   {
/*  669 */     if (this.readers2intrefs.containsKey(fdf))
/*  670 */       return;
/*  671 */     PdfDictionary catalog = fdf.getCatalog();
/*  672 */     catalog = catalog.getAsDict(PdfName.FDF);
/*  673 */     if (catalog == null)
/*  674 */       return;
/*  675 */     PdfArray annots = catalog.getAsArray(PdfName.ANNOTS);
/*  676 */     if ((annots == null) || (annots.size() == 0))
/*  677 */       return;
/*  678 */     registerReader(fdf, false);
/*  679 */     IntHashtable hits = new IntHashtable();
/*  680 */     HashMap<String, PdfObject> irt = new HashMap();
/*  681 */     ArrayList<PdfObject> an = new ArrayList();
/*  682 */     for (int k = 0; k < annots.size(); k++) {
/*  683 */       PdfObject obj = annots.getPdfObject(k);
/*  684 */       PdfDictionary annot = (PdfDictionary)PdfReader.getPdfObject(obj);
/*  685 */       PdfNumber page = annot.getAsNumber(PdfName.PAGE);
/*  686 */       if ((page != null) && (page.intValue() < this.reader.getNumberOfPages()))
/*      */       {
/*  688 */         findAllObjects(fdf, obj, hits);
/*  689 */         an.add(obj);
/*  690 */         if (obj.type() == 10) {
/*  691 */           PdfObject nm = PdfReader.getPdfObject(annot.get(PdfName.NM));
/*  692 */           if ((nm != null) && (nm.type() == 3))
/*  693 */             irt.put(nm.toString(), obj);
/*      */         }
/*      */       } }
/*  696 */     int[] arhits = hits.getKeys();
/*  697 */     for (int k = 0; k < arhits.length; k++) {
/*  698 */       int n = arhits[k];
/*  699 */       PdfObject obj = fdf.getPdfObject(n);
/*  700 */       if (obj.type() == 6) {
/*  701 */         PdfObject str = PdfReader.getPdfObject(((PdfDictionary)obj).get(PdfName.IRT));
/*  702 */         if ((str != null) && (str.type() == 3)) {
/*  703 */           PdfObject i = (PdfObject)irt.get(str.toString());
/*  704 */           if (i != null) {
/*  705 */             PdfDictionary dic2 = new PdfDictionary();
/*  706 */             dic2.merge((PdfDictionary)obj);
/*  707 */             dic2.put(PdfName.IRT, i);
/*  708 */             obj = dic2;
/*      */           }
/*      */         }
/*      */       }
/*  712 */       addToBody(obj, getNewObjectNumber(fdf, n, 0));
/*      */     }
/*  714 */     for (int k = 0; k < an.size(); k++) {
/*  715 */       PdfObject obj = (PdfObject)an.get(k);
/*  716 */       PdfDictionary annot = (PdfDictionary)PdfReader.getPdfObject(obj);
/*  717 */       PdfNumber page = annot.getAsNumber(PdfName.PAGE);
/*  718 */       PdfDictionary dic = this.reader.getPageN(page.intValue() + 1);
/*  719 */       PdfArray annotsp = (PdfArray)PdfReader.getPdfObject(dic.get(PdfName.ANNOTS), dic);
/*  720 */       if (annotsp == null) {
/*  721 */         annotsp = new PdfArray();
/*  722 */         dic.put(PdfName.ANNOTS, annotsp);
/*  723 */         markUsed(dic);
/*      */       }
/*  725 */       markUsed(annotsp);
/*  726 */       annotsp.add(obj);
/*      */     }
/*      */   }
/*      */   
/*      */   PageStamp getPageStamp(int pageNum) {
/*  731 */     PdfDictionary pageN = this.reader.getPageN(pageNum);
/*  732 */     PageStamp ps = (PageStamp)this.pagesToContent.get(pageN);
/*  733 */     if (ps == null) {
/*  734 */       ps = new PageStamp(this, this.reader, pageN);
/*  735 */       this.pagesToContent.put(pageN, ps);
/*      */     }
/*  737 */     return ps;
/*      */   }
/*      */   
/*      */   PdfContentByte getUnderContent(int pageNum) {
/*  741 */     if ((pageNum < 1) || (pageNum > this.reader.getNumberOfPages()))
/*  742 */       return null;
/*  743 */     PageStamp ps = getPageStamp(pageNum);
/*  744 */     if (ps.under == null)
/*  745 */       ps.under = new StampContent(this, ps);
/*  746 */     return ps.under;
/*      */   }
/*      */   
/*      */   PdfContentByte getOverContent(int pageNum) {
/*  750 */     if ((pageNum < 1) || (pageNum > this.reader.getNumberOfPages()))
/*  751 */       return null;
/*  752 */     PageStamp ps = getPageStamp(pageNum);
/*  753 */     if (ps.over == null)
/*  754 */       ps.over = new StampContent(this, ps);
/*  755 */     return ps.over;
/*      */   }
/*      */   
/*      */   void correctAcroFieldPages(int page) {
/*  759 */     if (this.acroFields == null)
/*  760 */       return;
/*  761 */     if (page > this.reader.getNumberOfPages())
/*  762 */       return;
/*  763 */     Map<String, AcroFields.Item> fields = this.acroFields.getFields();
/*  764 */     for (AcroFields.Item item : fields.values()) {
/*  765 */       for (int k = 0; k < item.size(); k++) {
/*  766 */         int p = item.getPage(k).intValue();
/*  767 */         if (p >= page)
/*  768 */           item.forcePage(k, p + 1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static void moveRectangle(PdfDictionary dic2, PdfReader r, int pageImported, PdfName key, String name) {
/*  774 */     Rectangle m = r.getBoxSize(pageImported, name);
/*  775 */     if (m == null) {
/*  776 */       dic2.remove(key);
/*      */     } else
/*  778 */       dic2.put(key, new PdfRectangle(m));
/*      */   }
/*      */   
/*      */   void replacePage(PdfReader r, int pageImported, int pageReplaced) {
/*  782 */     PdfDictionary pageN = this.reader.getPageN(pageReplaced);
/*  783 */     if (this.pagesToContent.containsKey(pageN))
/*  784 */       throw new IllegalStateException(MessageLocalization.getComposedMessage("this.page.cannot.be.replaced.new.content.was.already.added", new Object[0]));
/*  785 */     PdfImportedPage p = getImportedPage(r, pageImported);
/*  786 */     PdfDictionary dic2 = this.reader.getPageNRelease(pageReplaced);
/*  787 */     dic2.remove(PdfName.RESOURCES);
/*  788 */     dic2.remove(PdfName.CONTENTS);
/*  789 */     moveRectangle(dic2, r, pageImported, PdfName.MEDIABOX, "media");
/*  790 */     moveRectangle(dic2, r, pageImported, PdfName.CROPBOX, "crop");
/*  791 */     moveRectangle(dic2, r, pageImported, PdfName.TRIMBOX, "trim");
/*  792 */     moveRectangle(dic2, r, pageImported, PdfName.ARTBOX, "art");
/*  793 */     moveRectangle(dic2, r, pageImported, PdfName.BLEEDBOX, "bleed");
/*  794 */     dic2.put(PdfName.ROTATE, new PdfNumber(r.getPageRotation(pageImported)));
/*  795 */     PdfContentByte cb = getOverContent(pageReplaced);
/*  796 */     cb.addTemplate(p, 0.0F, 0.0F);
/*  797 */     PageStamp ps = (PageStamp)this.pagesToContent.get(pageN);
/*  798 */     ps.replacePoint = ps.over.getInternalBuffer().size();
/*      */   }
/*      */   
/*      */   void insertPage(int pageNumber, Rectangle mediabox) {
/*  802 */     Rectangle media = new Rectangle(mediabox);
/*  803 */     int rotation = media.getRotation() % 360;
/*  804 */     PdfDictionary page = new PdfDictionary(PdfName.PAGE);
/*  805 */     page.put(PdfName.RESOURCES, new PdfDictionary());
/*  806 */     page.put(PdfName.ROTATE, new PdfNumber(rotation));
/*  807 */     page.put(PdfName.MEDIABOX, new PdfRectangle(media, rotation));
/*  808 */     PRIndirectReference pref = this.reader.addPdfObject(page);
/*      */     PRIndirectReference parentRef;
/*      */     PdfDictionary parent;
/*  811 */     if (pageNumber > this.reader.getNumberOfPages()) {
/*  812 */       PdfDictionary lastPage = this.reader.getPageNRelease(this.reader.getNumberOfPages());
/*  813 */       PRIndirectReference parentRef = (PRIndirectReference)lastPage.get(PdfName.PARENT);
/*  814 */       parentRef = new PRIndirectReference(this.reader, parentRef.getNumber());
/*  815 */       PdfDictionary parent = (PdfDictionary)PdfReader.getPdfObject(parentRef);
/*  816 */       PdfArray kids = (PdfArray)PdfReader.getPdfObject(parent.get(PdfName.KIDS), parent);
/*  817 */       kids.add(pref);
/*  818 */       markUsed(kids);
/*  819 */       this.reader.pageRefs.insertPage(pageNumber, pref);
/*      */     } else {
/*  821 */       if (pageNumber < 1)
/*  822 */         pageNumber = 1;
/*  823 */       PdfDictionary firstPage = this.reader.getPageN(pageNumber);
/*  824 */       PRIndirectReference firstPageRef = this.reader.getPageOrigRef(pageNumber);
/*  825 */       this.reader.releasePage(pageNumber);
/*  826 */       parentRef = (PRIndirectReference)firstPage.get(PdfName.PARENT);
/*  827 */       parentRef = new PRIndirectReference(this.reader, parentRef.getNumber());
/*  828 */       parent = (PdfDictionary)PdfReader.getPdfObject(parentRef);
/*  829 */       PdfArray kids = (PdfArray)PdfReader.getPdfObject(parent.get(PdfName.KIDS), parent);
/*  830 */       int len = kids.size();
/*  831 */       int num = firstPageRef.getNumber();
/*  832 */       for (int k = 0; k < len; k++) {
/*  833 */         PRIndirectReference cur = (PRIndirectReference)kids.getPdfObject(k);
/*  834 */         if (num == cur.getNumber()) {
/*  835 */           kids.add(k, pref);
/*  836 */           break;
/*      */         }
/*      */       }
/*  839 */       if (len == kids.size())
/*  840 */         throw new RuntimeException(MessageLocalization.getComposedMessage("internal.inconsistence", new Object[0]));
/*  841 */       markUsed(kids);
/*  842 */       this.reader.pageRefs.insertPage(pageNumber, pref);
/*  843 */       correctAcroFieldPages(pageNumber);
/*      */     }
/*  845 */     page.put(PdfName.PARENT, parentRef);
/*  846 */     while (parent != null) {
/*  847 */       markUsed(parent);
/*  848 */       PdfNumber count = (PdfNumber)PdfReader.getPdfObjectRelease(parent.get(PdfName.COUNT));
/*  849 */       parent.put(PdfName.COUNT, new PdfNumber(count.intValue() + 1));
/*  850 */       parent = parent.getAsDict(PdfName.PARENT);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isRotateContents()
/*      */   {
/*  860 */     return this.rotateContents;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setRotateContents(boolean rotateContents)
/*      */   {
/*  869 */     this.rotateContents = rotateContents;
/*      */   }
/*      */   
/*      */   boolean isContentWritten() {
/*  873 */     return this.body.size() > 1;
/*      */   }
/*      */   
/*      */   AcroFields getAcroFields() {
/*  877 */     if (this.acroFields == null) {
/*  878 */       this.acroFields = new AcroFields(this.reader, this);
/*      */     }
/*  880 */     return this.acroFields;
/*      */   }
/*      */   
/*      */   void setFormFlattening(boolean flat) {
/*  884 */     this.flat = flat;
/*      */   }
/*      */   
/*      */   void setFreeTextFlattening(boolean flat) {
/*  888 */     this.flatFreeText = flat;
/*      */   }
/*      */   
/*      */   boolean partialFormFlattening(String name) {
/*  892 */     getAcroFields();
/*  893 */     if (this.acroFields.getXfa().isXfaPresent())
/*  894 */       throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("partial.form.flattening.is.not.supported.with.xfa.forms", new Object[0]));
/*  895 */     if (!this.acroFields.getFields().containsKey(name))
/*  896 */       return false;
/*  897 */     this.partialFlattening.add(name);
/*  898 */     return true;
/*      */   }
/*      */   
/*      */   protected void flatFields() {
/*  902 */     if (this.append)
/*  903 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("field.flattening.is.not.supported.in.append.mode", new Object[0]));
/*  904 */     getAcroFields();
/*  905 */     Map<String, AcroFields.Item> fields = this.acroFields.getFields();
/*  906 */     if ((this.fieldsAdded) && (this.partialFlattening.isEmpty())) {
/*  907 */       for (String s : fields.keySet()) {
/*  908 */         this.partialFlattening.add(s);
/*      */       }
/*      */     }
/*  911 */     PdfDictionary acroForm = this.reader.getCatalog().getAsDict(PdfName.ACROFORM);
/*  912 */     PdfArray acroFds = null;
/*  913 */     if (acroForm != null) {
/*  914 */       acroFds = (PdfArray)PdfReader.getPdfObject(acroForm.get(PdfName.FIELDS), acroForm);
/*      */     }
/*  916 */     for (Map.Entry<String, AcroFields.Item> entry : fields.entrySet()) {
/*  917 */       String name = (String)entry.getKey();
/*  918 */       if ((this.partialFlattening.isEmpty()) || (this.partialFlattening.contains(name)))
/*      */       {
/*  920 */         AcroFields.Item item = (AcroFields.Item)entry.getValue();
/*  921 */         for (int k = 0; k < item.size(); k++) {
/*  922 */           PdfDictionary merged = item.getMerged(k);
/*  923 */           PdfNumber ff = merged.getAsNumber(PdfName.F);
/*  924 */           int flags = 0;
/*  925 */           if (ff != null)
/*  926 */             flags = ff.intValue();
/*  927 */           int page = item.getPage(k).intValue();
/*  928 */           if (page >= 1)
/*      */           {
/*  930 */             PdfDictionary appDic = merged.getAsDict(PdfName.AP);
/*  931 */             PdfObject as_n = null;
/*  932 */             if (appDic != null) {
/*  933 */               as_n = appDic.getAsStream(PdfName.N);
/*  934 */               if (as_n == null)
/*  935 */                 as_n = appDic.getAsDict(PdfName.N);
/*      */             }
/*  937 */             if (this.acroFields.isGenerateAppearances()) {
/*  938 */               if ((appDic == null) || (as_n == null)) {
/*      */                 try {
/*  940 */                   this.acroFields.regenerateField(name);
/*  941 */                   appDic = this.acroFields.getFieldItem(name).getMerged(k).getAsDict(PdfName.AP);
/*      */ 
/*      */                 }
/*      */                 catch (IOException localIOException) {}catch (DocumentException localDocumentException) {}
/*      */ 
/*      */               }
/*  947 */               else if (as_n.isStream()) {
/*  948 */                 PdfStream stream = (PdfStream)as_n;
/*  949 */                 PdfArray bbox = stream.getAsArray(PdfName.BBOX);
/*  950 */                 PdfArray rect = merged.getAsArray(PdfName.RECT);
/*  951 */                 if ((bbox != null) && (rect != null)) {
/*  952 */                   float rectWidth = rect.getAsNumber(2).floatValue() - rect.getAsNumber(0).floatValue();
/*  953 */                   float bboxWidth = bbox.getAsNumber(2).floatValue() - bbox.getAsNumber(0).floatValue();
/*  954 */                   float rectHeight = rect.getAsNumber(3).floatValue() - rect.getAsNumber(1).floatValue();
/*  955 */                   float bboxHeight = bbox.getAsNumber(3).floatValue() - bbox.getAsNumber(1).floatValue();
/*  956 */                   float widthCoef = Math.abs(bboxWidth != 0.0F ? rectWidth / bboxWidth : Float.MAX_VALUE);
/*  957 */                   float heightCoef = Math.abs(bboxHeight != 0.0F ? rectHeight / bboxHeight : Float.MAX_VALUE);
/*      */                   
/*  959 */                   if ((widthCoef != 1.0F) || (heightCoef != 1.0F)) {
/*  960 */                     NumberArray array = new NumberArray(new float[] { widthCoef, 0.0F, 0.0F, heightCoef, 0.0F, 0.0F });
/*  961 */                     stream.put(PdfName.MATRIX, array);
/*  962 */                     markUsed(stream);
/*      */                   }
/*      */                 }
/*      */               }
/*  966 */             } else if ((appDic != null) && (as_n != null)) {
/*  967 */               PdfArray bbox = ((PdfDictionary)as_n).getAsArray(PdfName.BBOX);
/*  968 */               PdfArray rect = merged.getAsArray(PdfName.RECT);
/*  969 */               if ((bbox != null) && (rect != null))
/*      */               {
/*  971 */                 float widthDiff = bbox.getAsNumber(2).floatValue() - bbox.getAsNumber(0).floatValue() - (rect.getAsNumber(2).floatValue() - rect.getAsNumber(0).floatValue());
/*      */                 
/*  973 */                 float heightDiff = bbox.getAsNumber(3).floatValue() - bbox.getAsNumber(1).floatValue() - (rect.getAsNumber(3).floatValue() - rect.getAsNumber(1).floatValue());
/*  974 */                 if ((Math.abs(widthDiff) > 1.0F) || (Math.abs(heightDiff) > 1.0F)) {
/*      */                   try
/*      */                   {
/*  977 */                     this.acroFields.setGenerateAppearances(true);
/*  978 */                     this.acroFields.regenerateField(name);
/*  979 */                     this.acroFields.setGenerateAppearances(false);
/*  980 */                     appDic = this.acroFields.getFieldItem(name).getMerged(k).getAsDict(PdfName.AP);
/*      */                   }
/*      */                   catch (IOException localIOException1) {}catch (DocumentException localDocumentException1) {}
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  990 */             if ((appDic != null) && ((flags & 0x4) != 0) && ((flags & 0x2) == 0)) {
/*  991 */               PdfObject obj = appDic.get(PdfName.N);
/*  992 */               PdfAppearance app = null;
/*  993 */               if (obj != null) {
/*  994 */                 PdfObject objReal = PdfReader.getPdfObject(obj);
/*  995 */                 if (((obj instanceof PdfIndirectReference)) && (!obj.isIndirect())) {
/*  996 */                   app = new PdfAppearance((PdfIndirectReference)obj);
/*  997 */                 } else if ((objReal instanceof PdfStream)) {
/*  998 */                   ((PdfDictionary)objReal).put(PdfName.SUBTYPE, PdfName.FORM);
/*  999 */                   app = new PdfAppearance((PdfIndirectReference)obj);
/*      */                 }
/* 1001 */                 else if ((objReal != null) && (objReal.isDictionary())) {
/* 1002 */                   PdfName as = merged.getAsName(PdfName.AS);
/* 1003 */                   if (as != null) {
/* 1004 */                     PdfIndirectReference iref = (PdfIndirectReference)((PdfDictionary)objReal).get(as);
/* 1005 */                     if (iref != null) {
/* 1006 */                       app = new PdfAppearance(iref);
/* 1007 */                       if (iref.isIndirect()) {
/* 1008 */                         objReal = PdfReader.getPdfObject(iref);
/* 1009 */                         ((PdfDictionary)objReal).put(PdfName.SUBTYPE, PdfName.FORM);
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */               
/* 1016 */               if (app != null) {
/* 1017 */                 Rectangle box = PdfReader.getNormalizedRectangle(merged.getAsArray(PdfName.RECT));
/* 1018 */                 PdfContentByte cb = getOverContent(page);
/* 1019 */                 cb.setLiteral("Q ");
/* 1020 */                 cb.addTemplate(app, box.getLeft(), box.getBottom());
/* 1021 */                 cb.setLiteral("q ");
/*      */               }
/*      */             }
/* 1024 */             if (!this.partialFlattening.isEmpty())
/*      */             {
/* 1026 */               PdfDictionary pageDic = this.reader.getPageN(page);
/* 1027 */               PdfArray annots = pageDic.getAsArray(PdfName.ANNOTS);
/* 1028 */               if (annots != null)
/*      */               {
/* 1030 */                 for (int idx = 0; idx < annots.size(); idx++) {
/* 1031 */                   PdfObject ran = annots.getPdfObject(idx);
/* 1032 */                   if (ran.isIndirect())
/*      */                   {
/* 1034 */                     PdfObject ran2 = item.getWidgetRef(k);
/* 1035 */                     if (ran2.isIndirect())
/*      */                     {
/* 1037 */                       if (((PRIndirectReference)ran).getNumber() == ((PRIndirectReference)ran2).getNumber()) {
/* 1038 */                         annots.remove(idx--);
/* 1039 */                         PRIndirectReference wdref = (PRIndirectReference)ran2;
/*      */                         for (;;) {
/* 1041 */                           PdfDictionary wd = (PdfDictionary)PdfReader.getPdfObject(wdref);
/* 1042 */                           PRIndirectReference parentRef = (PRIndirectReference)wd.get(PdfName.PARENT);
/* 1043 */                           PdfReader.killIndirect(wdref);
/* 1044 */                           if (parentRef == null) {
/* 1045 */                             for (int fr = 0; fr < acroFds.size(); fr++) {
/* 1046 */                               PdfObject h = acroFds.getPdfObject(fr);
/* 1047 */                               if ((h.isIndirect()) && (((PRIndirectReference)h).getNumber() == wdref.getNumber())) {
/* 1048 */                                 acroFds.remove(fr);
/* 1049 */                                 fr--;
/*      */                               }
/*      */                             }
/* 1052 */                             break;
/*      */                           }
/* 1054 */                           PdfDictionary parent = (PdfDictionary)PdfReader.getPdfObject(parentRef);
/* 1055 */                           PdfArray kids = parent.getAsArray(PdfName.KIDS);
/* 1056 */                           for (int fr = 0; fr < kids.size(); fr++) {
/* 1057 */                             PdfObject h = kids.getPdfObject(fr);
/* 1058 */                             if ((h.isIndirect()) && (((PRIndirectReference)h).getNumber() == wdref.getNumber())) {
/* 1059 */                               kids.remove(fr);
/* 1060 */                               fr--;
/*      */                             }
/*      */                           }
/* 1063 */                           if (!kids.isEmpty())
/*      */                             break;
/* 1065 */                           wdref = parentRef;
/*      */                         }
/*      */                       } }
/*      */                   } }
/* 1069 */                 if (annots.isEmpty()) {
/* 1070 */                   PdfReader.killIndirect(pageDic.get(PdfName.ANNOTS));
/* 1071 */                   pageDic.remove(PdfName.ANNOTS);
/*      */                 }
/*      */               }
/*      */             } } } } }
/* 1075 */     if ((!this.fieldsAdded) && (this.partialFlattening.isEmpty())) {
/* 1076 */       for (int page = 1; page <= this.reader.getNumberOfPages(); page++) {
/* 1077 */         PdfDictionary pageDic = this.reader.getPageN(page);
/* 1078 */         PdfArray annots = pageDic.getAsArray(PdfName.ANNOTS);
/* 1079 */         if (annots != null)
/*      */         {
/* 1081 */           for (int idx = 0; idx < annots.size(); idx++) {
/* 1082 */             PdfObject annoto = annots.getDirectObject(idx);
/* 1083 */             if ((!(annoto instanceof PdfIndirectReference)) || (annoto.isIndirect()))
/*      */             {
/* 1085 */               if ((!annoto.isDictionary()) || (PdfName.WIDGET.equals(((PdfDictionary)annoto).get(PdfName.SUBTYPE)))) {
/* 1086 */                 annots.remove(idx);
/* 1087 */                 idx--;
/*      */               } }
/*      */           }
/* 1090 */           if (annots.isEmpty()) {
/* 1091 */             PdfReader.killIndirect(pageDic.get(PdfName.ANNOTS));
/* 1092 */             pageDic.remove(PdfName.ANNOTS);
/*      */           }
/*      */         } }
/* 1095 */       eliminateAcroformObjects();
/*      */     }
/*      */   }
/*      */   
/*      */   void eliminateAcroformObjects() {
/* 1100 */     PdfObject acro = this.reader.getCatalog().get(PdfName.ACROFORM);
/* 1101 */     if (acro == null)
/* 1102 */       return;
/* 1103 */     PdfDictionary acrodic = (PdfDictionary)PdfReader.getPdfObject(acro);
/* 1104 */     this.reader.killXref(acrodic.get(PdfName.XFA));
/* 1105 */     acrodic.remove(PdfName.XFA);
/* 1106 */     PdfObject iFields = acrodic.get(PdfName.FIELDS);
/* 1107 */     if (iFields != null) {
/* 1108 */       PdfDictionary kids = new PdfDictionary();
/* 1109 */       kids.put(PdfName.KIDS, iFields);
/* 1110 */       sweepKids(kids);
/* 1111 */       PdfReader.killIndirect(iFields);
/* 1112 */       acrodic.put(PdfName.FIELDS, new PdfArray());
/*      */     }
/* 1114 */     acrodic.remove(PdfName.SIGFLAGS);
/* 1115 */     acrodic.remove(PdfName.NEEDAPPEARANCES);
/* 1116 */     acrodic.remove(PdfName.DR);
/*      */   }
/*      */   
/*      */ 
/*      */   void sweepKids(PdfObject obj)
/*      */   {
/* 1122 */     PdfObject oo = PdfReader.killIndirect(obj);
/* 1123 */     if ((oo == null) || (!oo.isDictionary()))
/* 1124 */       return;
/* 1125 */     PdfDictionary dic = (PdfDictionary)oo;
/* 1126 */     PdfArray kids = (PdfArray)PdfReader.killIndirect(dic.get(PdfName.KIDS));
/* 1127 */     if (kids == null)
/* 1128 */       return;
/* 1129 */     for (int k = 0; k < kids.size(); k++) {
/* 1130 */       sweepKids(kids.getPdfObject(k));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFlatAnnotations(boolean flatAnnotations)
/*      */   {
/* 1141 */     this.flatannotations = flatAnnotations;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void flattenAnnotations()
/*      */   {
/* 1150 */     flattenAnnotations(false);
/*      */   }
/*      */   
/*      */   private void flattenAnnotations(boolean flattenFreeTextAnnotations) {
/* 1154 */     if (this.append) {
/* 1155 */       if (flattenFreeTextAnnotations) {
/* 1156 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("freetext.flattening.is.not.supported.in.append.mode", new Object[0]));
/*      */       }
/* 1158 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("annotation.flattening.is.not.supported.in.append.mode", new Object[0]));
/*      */     }
/*      */     
/*      */ 
/* 1162 */     for (int page = 1; page <= this.reader.getNumberOfPages(); page++) {
/* 1163 */       PdfDictionary pageDic = this.reader.getPageN(page);
/* 1164 */       PdfArray annots = pageDic.getAsArray(PdfName.ANNOTS);
/*      */       
/* 1166 */       if (annots != null)
/*      */       {
/*      */ 
/*      */ 
/* 1170 */         for (int idx = 0; idx < annots.size(); idx++) {
/* 1171 */           PdfObject annoto = annots.getDirectObject(idx);
/* 1172 */           if ((!(annoto instanceof PdfIndirectReference)) || (annoto.isIndirect()))
/*      */           {
/* 1174 */             if ((annoto instanceof PdfDictionary))
/*      */             {
/* 1176 */               PdfDictionary annDic = (PdfDictionary)annoto;
/* 1177 */               if (flattenFreeTextAnnotations ? 
/* 1178 */                 annDic.get(PdfName.SUBTYPE).equals(PdfName.FREETEXT) : 
/*      */                 
/*      */ 
/*      */ 
/* 1182 */                 !annDic.get(PdfName.SUBTYPE).equals(PdfName.WIDGET))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1188 */                 PdfNumber ff = annDic.getAsNumber(PdfName.F);
/* 1189 */                 int flags = ff != null ? ff.intValue() : 0;
/*      */                 
/* 1191 */                 if (((flags & 0x4) != 0) && ((flags & 0x2) == 0)) {
/* 1192 */                   PdfObject obj1 = annDic.get(PdfName.AP);
/* 1193 */                   if (obj1 != null)
/*      */                   {
/*      */ 
/* 1196 */                     PdfDictionary appDic = (obj1 instanceof PdfIndirectReference) ? (PdfDictionary)PdfReader.getPdfObject(obj1) : (PdfDictionary)obj1;
/* 1197 */                     PdfObject obj = appDic.get(PdfName.N);
/* 1198 */                     PdfDictionary objDict = appDic.getAsStream(PdfName.N);
/* 1199 */                     PdfAppearance app = null;
/* 1200 */                     PdfObject objReal = PdfReader.getPdfObject(obj);
/*      */                     
/* 1202 */                     if (((obj instanceof PdfIndirectReference)) && (!obj.isIndirect())) {
/* 1203 */                       app = new PdfAppearance((PdfIndirectReference)obj);
/* 1204 */                     } else if ((objReal instanceof PdfStream)) {
/* 1205 */                       ((PdfDictionary)objReal).put(PdfName.SUBTYPE, PdfName.FORM);
/* 1206 */                       app = new PdfAppearance((PdfIndirectReference)obj);
/*      */                     }
/* 1208 */                     else if (objReal.isDictionary()) {
/* 1209 */                       PdfName as_p = appDic.getAsName(PdfName.AS);
/* 1210 */                       if (as_p != null) {
/* 1211 */                         PdfIndirectReference iref = (PdfIndirectReference)((PdfDictionary)objReal).get(as_p);
/* 1212 */                         if (iref != null) {
/* 1213 */                           app = new PdfAppearance(iref);
/* 1214 */                           if (iref.isIndirect()) {
/* 1215 */                             objReal = PdfReader.getPdfObject(iref);
/* 1216 */                             ((PdfDictionary)objReal).put(PdfName.SUBTYPE, PdfName.FORM);
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                     
/* 1222 */                     if (app != null) {
/* 1223 */                       Rectangle rect = PdfReader.getNormalizedRectangle(annDic.getAsArray(PdfName.RECT));
/* 1224 */                       Rectangle bBox = PdfReader.getNormalizedRectangle(objDict.getAsArray(PdfName.BBOX));
/* 1225 */                       PdfContentByte cb = getOverContent(page);
/* 1226 */                       cb.setLiteral("Q ");
/* 1227 */                       if ((objDict.getAsArray(PdfName.MATRIX) != null) && 
/* 1228 */                         (!Arrays.equals(this.DEFAULT_MATRIX, objDict.getAsArray(PdfName.MATRIX).asDoubleArray()))) {
/* 1229 */                         double[] matrix = objDict.getAsArray(PdfName.MATRIX).asDoubleArray();
/* 1230 */                         Rectangle transformBBox = transformBBoxByMatrix(bBox, matrix);
/* 1231 */                         cb.addTemplate(app, rect.getWidth() / transformBBox.getWidth(), 0.0F, 0.0F, rect.getHeight() / transformBBox.getHeight(), rect.getLeft(), rect.getBottom());
/*      */                       }
/*      */                       else
/*      */                       {
/* 1235 */                         cb.addTemplate(app, rect.getWidth() / bBox.getWidth(), 0.0F, 0.0F, rect.getHeight() / bBox.getHeight(), rect.getLeft(), rect.getBottom());
/*      */                       }
/* 1237 */                       cb.setLiteral("q ");
/*      */                       
/* 1239 */                       annots.remove(idx);
/* 1240 */                       idx--;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               } } } }
/* 1245 */         if (annots.isEmpty()) {
/* 1246 */           PdfReader.killIndirect(pageDic.get(PdfName.ANNOTS));
/* 1247 */           pageDic.remove(PdfName.ANNOTS);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Rectangle transformBBoxByMatrix(Rectangle bBox, double[] matrix)
/*      */   {
/* 1258 */     List xArr = new ArrayList();
/* 1259 */     List yArr = new ArrayList();
/* 1260 */     Point p1 = transformPoint(bBox.getLeft(), bBox.getBottom(), matrix);
/* 1261 */     xArr.add(Double.valueOf(p1.x));
/* 1262 */     yArr.add(Double.valueOf(p1.y));
/* 1263 */     Point p2 = transformPoint(bBox.getRight(), bBox.getTop(), matrix);
/* 1264 */     xArr.add(Double.valueOf(p2.x));
/* 1265 */     yArr.add(Double.valueOf(p2.y));
/* 1266 */     Point p3 = transformPoint(bBox.getLeft(), bBox.getTop(), matrix);
/* 1267 */     xArr.add(Double.valueOf(p3.x));
/* 1268 */     yArr.add(Double.valueOf(p3.y));
/* 1269 */     Point p4 = transformPoint(bBox.getRight(), bBox.getBottom(), matrix);
/* 1270 */     xArr.add(Double.valueOf(p4.x));
/* 1271 */     yArr.add(Double.valueOf(p4.y));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1276 */     return new Rectangle(((Double)Collections.min(xArr)).floatValue(), ((Double)Collections.min(yArr)).floatValue(), ((Double)Collections.max(xArr)).floatValue(), ((Double)Collections.max(yArr)).floatValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Point transformPoint(double x, double y, double[] matrix)
/*      */   {
/* 1286 */     Point point = new Point();
/* 1287 */     point.x = (matrix[0] * x + matrix[2] * y + matrix[4]);
/* 1288 */     point.y = (matrix[1] * x + matrix[3] * y + matrix[5]);
/* 1289 */     return point;
/*      */   }
/*      */   
/*      */   protected void flatFreeTextFields() {
/* 1293 */     flattenAnnotations(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectReference getPageReference(int page)
/*      */   {
/* 1301 */     PdfIndirectReference ref = this.reader.getPageOrigRef(page);
/* 1302 */     if (ref == null)
/* 1303 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("invalid.page.number.1", page));
/* 1304 */     return ref;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAnnotation(PdfAnnotation annot)
/*      */   {
/* 1312 */     throw new RuntimeException(MessageLocalization.getComposedMessage("unsupported.in.this.context.use.pdfstamper.addannotation", new Object[0]));
/*      */   }
/*      */   
/*      */   void addDocumentField(PdfIndirectReference ref) {
/* 1316 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1317 */     PdfDictionary acroForm = (PdfDictionary)PdfReader.getPdfObject(catalog.get(PdfName.ACROFORM), catalog);
/* 1318 */     if (acroForm == null) {
/* 1319 */       acroForm = new PdfDictionary();
/* 1320 */       catalog.put(PdfName.ACROFORM, acroForm);
/* 1321 */       markUsed(catalog);
/*      */     }
/* 1323 */     PdfArray fields = (PdfArray)PdfReader.getPdfObject(acroForm.get(PdfName.FIELDS), acroForm);
/* 1324 */     if (fields == null) {
/* 1325 */       fields = new PdfArray();
/* 1326 */       acroForm.put(PdfName.FIELDS, fields);
/* 1327 */       markUsed(acroForm);
/*      */     }
/* 1329 */     if (!acroForm.contains(PdfName.DA)) {
/* 1330 */       acroForm.put(PdfName.DA, new PdfString("/Helv 0 Tf 0 g "));
/* 1331 */       markUsed(acroForm);
/*      */     }
/* 1333 */     fields.add(ref);
/* 1334 */     markUsed(fields);
/*      */   }
/*      */   
/*      */   protected void addFieldResources() throws IOException {
/* 1338 */     if (this.fieldTemplates.isEmpty())
/* 1339 */       return;
/* 1340 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1341 */     PdfDictionary acroForm = (PdfDictionary)PdfReader.getPdfObject(catalog.get(PdfName.ACROFORM), catalog);
/* 1342 */     if (acroForm == null) {
/* 1343 */       acroForm = new PdfDictionary();
/* 1344 */       catalog.put(PdfName.ACROFORM, acroForm);
/* 1345 */       markUsed(catalog);
/*      */     }
/* 1347 */     PdfDictionary dr = (PdfDictionary)PdfReader.getPdfObject(acroForm.get(PdfName.DR), acroForm);
/* 1348 */     if (dr == null) {
/* 1349 */       dr = new PdfDictionary();
/* 1350 */       acroForm.put(PdfName.DR, dr);
/* 1351 */       markUsed(acroForm);
/*      */     }
/* 1353 */     markUsed(dr);
/* 1354 */     for (PdfTemplate template : this.fieldTemplates) {
/* 1355 */       PdfFormField.mergeResources(dr, (PdfDictionary)template.getResources(), this);
/*      */     }
/*      */     
/* 1358 */     PdfDictionary fonts = dr.getAsDict(PdfName.FONT);
/* 1359 */     if (fonts == null) {
/* 1360 */       fonts = new PdfDictionary();
/* 1361 */       dr.put(PdfName.FONT, fonts);
/*      */     }
/* 1363 */     if (!fonts.contains(PdfName.HELV)) {
/* 1364 */       PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 1365 */       dic.put(PdfName.BASEFONT, PdfName.HELVETICA);
/* 1366 */       dic.put(PdfName.ENCODING, PdfName.WIN_ANSI_ENCODING);
/* 1367 */       dic.put(PdfName.NAME, PdfName.HELV);
/* 1368 */       dic.put(PdfName.SUBTYPE, PdfName.TYPE1);
/* 1369 */       fonts.put(PdfName.HELV, addToBody(dic).getIndirectReference());
/*      */     }
/* 1371 */     if (!fonts.contains(PdfName.ZADB)) {
/* 1372 */       PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 1373 */       dic.put(PdfName.BASEFONT, PdfName.ZAPFDINGBATS);
/* 1374 */       dic.put(PdfName.NAME, PdfName.ZADB);
/* 1375 */       dic.put(PdfName.SUBTYPE, PdfName.TYPE1);
/* 1376 */       fonts.put(PdfName.ZADB, addToBody(dic).getIndirectReference());
/*      */     }
/* 1378 */     if (acroForm.get(PdfName.DA) == null) {
/* 1379 */       acroForm.put(PdfName.DA, new PdfString("/Helv 0 Tf 0 g "));
/* 1380 */       markUsed(acroForm);
/*      */     }
/*      */   }
/*      */   
/*      */   void expandFields(PdfFormField field, ArrayList<PdfAnnotation> allAnnots) {
/* 1385 */     allAnnots.add(field);
/* 1386 */     ArrayList<PdfFormField> kids = field.getKids();
/* 1387 */     if (kids != null) {
/* 1388 */       for (int k = 0; k < kids.size(); k++)
/* 1389 */         expandFields((PdfFormField)kids.get(k), allAnnots);
/*      */     }
/*      */   }
/*      */   
/*      */   void addAnnotation(PdfAnnotation annot, PdfDictionary pageN) {
/*      */     try {
/* 1395 */       ArrayList<PdfAnnotation> allAnnots = new ArrayList();
/* 1396 */       if (annot.isForm()) {
/* 1397 */         this.fieldsAdded = true;
/* 1398 */         getAcroFields();
/* 1399 */         PdfFormField field = (PdfFormField)annot;
/* 1400 */         if (field.getParent() != null)
/* 1401 */           return;
/* 1402 */         expandFields(field, allAnnots);
/*      */       } else {
/* 1404 */         allAnnots.add(annot); }
/* 1405 */       for (int k = 0; k < allAnnots.size(); k++) {
/* 1406 */         annot = (PdfAnnotation)allAnnots.get(k);
/* 1407 */         if (annot.getPlaceInPage() > 0)
/* 1408 */           pageN = this.reader.getPageN(annot.getPlaceInPage());
/* 1409 */         if (annot.isForm()) {
/* 1410 */           if (!annot.isUsed()) {
/* 1411 */             HashSet<PdfTemplate> templates = annot.getTemplates();
/* 1412 */             if (templates != null)
/* 1413 */               this.fieldTemplates.addAll(templates);
/*      */           }
/* 1415 */           PdfFormField field = (PdfFormField)annot;
/* 1416 */           if (field.getParent() == null)
/* 1417 */             addDocumentField(field.getIndirectReference());
/*      */         }
/* 1419 */         if (annot.isAnnotation()) {
/* 1420 */           PdfObject pdfobj = PdfReader.getPdfObject(pageN.get(PdfName.ANNOTS), pageN);
/* 1421 */           PdfArray annots = null;
/* 1422 */           if ((pdfobj == null) || (!pdfobj.isArray())) {
/* 1423 */             annots = new PdfArray();
/* 1424 */             pageN.put(PdfName.ANNOTS, annots);
/* 1425 */             markUsed(pageN);
/*      */           } else {
/* 1427 */             annots = (PdfArray)pdfobj; }
/* 1428 */           annots.add(annot.getIndirectReference());
/* 1429 */           markUsed(annots);
/* 1430 */           if (!annot.isUsed()) {
/* 1431 */             PdfRectangle rect = (PdfRectangle)annot.get(PdfName.RECT);
/* 1432 */             if ((rect != null) && ((rect.left() != 0.0F) || (rect.right() != 0.0F) || (rect.top() != 0.0F) || (rect.bottom() != 0.0F))) {
/* 1433 */               int rotation = this.reader.getPageRotation(pageN);
/* 1434 */               Rectangle pageSize = this.reader.getPageSizeWithRotation(pageN);
/* 1435 */               switch (rotation) {
/*      */               case 90: 
/* 1437 */                 annot.put(PdfName.RECT, new PdfRectangle(pageSize
/* 1438 */                   .getTop() - rect.top(), rect
/* 1439 */                   .right(), pageSize
/* 1440 */                   .getTop() - rect.bottom(), rect
/* 1441 */                   .left()));
/* 1442 */                 break;
/*      */               case 180: 
/* 1444 */                 annot.put(PdfName.RECT, new PdfRectangle(pageSize
/* 1445 */                   .getRight() - rect.left(), pageSize
/* 1446 */                   .getTop() - rect.bottom(), pageSize
/* 1447 */                   .getRight() - rect.right(), pageSize
/* 1448 */                   .getTop() - rect.top()));
/* 1449 */                 break;
/*      */               case 270: 
/* 1451 */                 annot.put(PdfName.RECT, new PdfRectangle(rect
/* 1452 */                   .bottom(), pageSize
/* 1453 */                   .getRight() - rect.left(), rect
/* 1454 */                   .top(), pageSize
/* 1455 */                   .getRight() - rect.right()));
/*      */               }
/*      */               
/*      */             }
/*      */           }
/*      */         }
/* 1461 */         if (!annot.isUsed()) {
/* 1462 */           annot.setUsed();
/* 1463 */           addToBody(annot, annot.getIndirectReference());
/*      */         }
/*      */       }
/*      */     } catch (IOException e) {
/* 1467 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */   void addAnnotation(PdfAnnotation annot, int page)
/*      */   {
/* 1473 */     if (annot.isAnnotation())
/* 1474 */       annot.setPage(page);
/* 1475 */     addAnnotation(annot, this.reader.getPageN(page));
/*      */   }
/*      */   
/*      */   private void outlineTravel(PRIndirectReference outline) {
/* 1479 */     while (outline != null) {
/* 1480 */       PdfDictionary outlineR = (PdfDictionary)PdfReader.getPdfObjectRelease(outline);
/* 1481 */       PRIndirectReference first = (PRIndirectReference)outlineR.get(PdfName.FIRST);
/* 1482 */       if (first != null) {
/* 1483 */         outlineTravel(first);
/*      */       }
/* 1485 */       PdfReader.killIndirect(outlineR.get(PdfName.DEST));
/* 1486 */       PdfReader.killIndirect(outlineR.get(PdfName.A));
/* 1487 */       PdfReader.killIndirect(outline);
/* 1488 */       outline = (PRIndirectReference)outlineR.get(PdfName.NEXT);
/*      */     }
/*      */   }
/*      */   
/*      */   void deleteOutlines() {
/* 1493 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1494 */     PdfObject obj = catalog.get(PdfName.OUTLINES);
/* 1495 */     if (obj == null)
/* 1496 */       return;
/* 1497 */     if ((obj instanceof PRIndirectReference)) {
/* 1498 */       PRIndirectReference outlines = (PRIndirectReference)obj;
/* 1499 */       outlineTravel(outlines);
/* 1500 */       PdfReader.killIndirect(outlines);
/*      */     }
/* 1502 */     catalog.remove(PdfName.OUTLINES);
/* 1503 */     markUsed(catalog);
/*      */   }
/*      */   
/*      */   protected void setJavaScript() throws IOException {
/* 1507 */     HashMap<String, PdfObject> djs = this.pdf.getDocumentLevelJS();
/* 1508 */     if (djs.isEmpty())
/* 1509 */       return;
/* 1510 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1511 */     PdfDictionary names = (PdfDictionary)PdfReader.getPdfObject(catalog.get(PdfName.NAMES), catalog);
/* 1512 */     if (names == null) {
/* 1513 */       names = new PdfDictionary();
/* 1514 */       catalog.put(PdfName.NAMES, names);
/* 1515 */       markUsed(catalog);
/*      */     }
/* 1517 */     markUsed(names);
/* 1518 */     PdfDictionary tree = PdfNameTree.writeTree(djs, this);
/* 1519 */     names.put(PdfName.JAVASCRIPT, addToBody(tree).getIndirectReference());
/*      */   }
/*      */   
/*      */   protected void addFileAttachments() throws IOException {
/* 1523 */     HashMap<String, PdfObject> fs = this.pdf.getDocumentFileAttachment();
/* 1524 */     if (fs.isEmpty())
/* 1525 */       return;
/* 1526 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1527 */     PdfDictionary names = (PdfDictionary)PdfReader.getPdfObject(catalog.get(PdfName.NAMES), catalog);
/* 1528 */     if (names == null) {
/* 1529 */       names = new PdfDictionary();
/* 1530 */       catalog.put(PdfName.NAMES, names);
/* 1531 */       markUsed(catalog);
/*      */     }
/* 1533 */     markUsed(names);
/* 1534 */     HashMap<String, PdfObject> old = PdfNameTree.readTree((PdfDictionary)PdfReader.getPdfObjectRelease(names.get(PdfName.EMBEDDEDFILES)));
/* 1535 */     for (Map.Entry<String, PdfObject> entry : fs.entrySet()) {
/* 1536 */       String name = (String)entry.getKey();
/* 1537 */       int k = 0;
/* 1538 */       StringBuilder nn = new StringBuilder(name);
/* 1539 */       while (old.containsKey(nn.toString())) {
/* 1540 */         k++;
/* 1541 */         nn.append(" ").append(k);
/*      */       }
/* 1543 */       old.put(nn.toString(), entry.getValue());
/*      */     }
/* 1545 */     PdfDictionary tree = PdfNameTree.writeTree(old, this);
/*      */     
/* 1547 */     PdfObject oldEmbeddedFiles = names.get(PdfName.EMBEDDEDFILES);
/* 1548 */     if (oldEmbeddedFiles != null) {
/* 1549 */       PdfReader.killIndirect(oldEmbeddedFiles);
/*      */     }
/*      */     
/*      */ 
/* 1553 */     names.put(PdfName.EMBEDDEDFILES, addToBody(tree).getIndirectReference());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void makePackage(PdfCollection collection)
/*      */   {
/* 1562 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1563 */     catalog.put(PdfName.COLLECTION, collection);
/*      */   }
/*      */   
/*      */   protected void setOutlines() throws IOException {
/* 1567 */     if (this.newBookmarks == null)
/* 1568 */       return;
/* 1569 */     deleteOutlines();
/* 1570 */     if (this.newBookmarks.isEmpty())
/* 1571 */       return;
/* 1572 */     PdfDictionary catalog = this.reader.getCatalog();
/* 1573 */     boolean namedAsNames = catalog.get(PdfName.DESTS) != null;
/* 1574 */     writeOutlines(catalog, namedAsNames);
/* 1575 */     markUsed(catalog);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setViewerPreferences(int preferences)
/*      */   {
/* 1586 */     this.useVp = true;
/* 1587 */     this.viewerPreferences.setViewerPreferences(preferences);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addViewerPreference(PdfName key, PdfObject value)
/*      */   {
/* 1599 */     this.useVp = true;
/* 1600 */     this.viewerPreferences.addViewerPreference(key, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSigFlags(int f)
/*      */   {
/* 1610 */     this.sigFlags |= f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageAction(PdfName actionType, PdfAction action)
/*      */     throws PdfException
/*      */   {
/* 1623 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("use.setpageaction.pdfname.actiontype.pdfaction.action.int.page", new Object[0]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setPageAction(PdfName actionType, PdfAction action, int page)
/*      */     throws PdfException
/*      */   {
/* 1636 */     if ((!actionType.equals(PAGE_OPEN)) && (!actionType.equals(PAGE_CLOSE)))
/* 1637 */       throw new PdfException(MessageLocalization.getComposedMessage("invalid.page.additional.action.type.1", new Object[] { actionType.toString() }));
/* 1638 */     PdfDictionary pg = this.reader.getPageN(page);
/* 1639 */     PdfDictionary aa = (PdfDictionary)PdfReader.getPdfObject(pg.get(PdfName.AA), pg);
/* 1640 */     if (aa == null) {
/* 1641 */       aa = new PdfDictionary();
/* 1642 */       pg.put(PdfName.AA, aa);
/* 1643 */       markUsed(pg);
/*      */     }
/* 1645 */     aa.put(actionType, action);
/* 1646 */     markUsed(aa);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDuration(int seconds)
/*      */   {
/* 1656 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("use.setpageaction.pdfname.actiontype.pdfaction.action.int.page", new Object[0]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransition(PdfTransition transition)
/*      */   {
/* 1666 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("use.setpageaction.pdfname.actiontype.pdfaction.action.int.page", new Object[0]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDuration(int seconds, int page)
/*      */   {
/* 1676 */     PdfDictionary pg = this.reader.getPageN(page);
/* 1677 */     if (seconds < 0) {
/* 1678 */       pg.remove(PdfName.DUR);
/*      */     } else
/* 1680 */       pg.put(PdfName.DUR, new PdfNumber(seconds));
/* 1681 */     markUsed(pg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setTransition(PdfTransition transition, int page)
/*      */   {
/* 1691 */     PdfDictionary pg = this.reader.getPageN(page);
/* 1692 */     if (transition == null) {
/* 1693 */       pg.remove(PdfName.TRANS);
/*      */     } else
/* 1695 */       pg.put(PdfName.TRANS, transition.getTransitionDictionary());
/* 1696 */     markUsed(pg);
/*      */   }
/*      */   
/*      */   protected void markUsed(PdfObject obj) {
/* 1700 */     if ((this.append) && (obj != null)) {
/* 1701 */       PRIndirectReference ref = null;
/* 1702 */       if (obj.type() == 10) {
/* 1703 */         ref = (PRIndirectReference)obj;
/*      */       } else
/* 1705 */         ref = obj.getIndRef();
/* 1706 */       if (ref != null)
/* 1707 */         this.marked.put(ref.getNumber(), 1);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void markUsed(int num) {
/* 1712 */     if (this.append) {
/* 1713 */       this.marked.put(num, 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isAppend()
/*      */   {
/* 1722 */     return this.append;
/*      */   }
/*      */   
/*      */   public PdfReader getPdfReader() {
/* 1726 */     return this.reader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdditionalAction(PdfName actionType, PdfAction action)
/*      */     throws PdfException
/*      */   {
/* 1742 */     if ((!actionType.equals(DOCUMENT_CLOSE)) && 
/* 1743 */       (!actionType.equals(WILL_SAVE)) && 
/* 1744 */       (!actionType.equals(DID_SAVE)) && 
/* 1745 */       (!actionType.equals(WILL_PRINT)) && 
/* 1746 */       (!actionType.equals(DID_PRINT))) {
/* 1747 */       throw new PdfException(MessageLocalization.getComposedMessage("invalid.additional.action.type.1", new Object[] { actionType.toString() }));
/*      */     }
/* 1749 */     PdfDictionary aa = this.reader.getCatalog().getAsDict(PdfName.AA);
/* 1750 */     if (aa == null) {
/* 1751 */       if (action == null)
/* 1752 */         return;
/* 1753 */       aa = new PdfDictionary();
/* 1754 */       this.reader.getCatalog().put(PdfName.AA, aa);
/*      */     }
/* 1756 */     markUsed(aa);
/* 1757 */     if (action == null) {
/* 1758 */       aa.remove(actionType);
/*      */     } else {
/* 1760 */       aa.put(actionType, action);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOpenAction(PdfAction action)
/*      */   {
/* 1768 */     this.openAction = action;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOpenAction(String name)
/*      */   {
/* 1776 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("open.actions.by.name.are.not.supported", new Object[0]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setThumbnail(Image image)
/*      */   {
/* 1784 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("use.pdfstamper.setthumbnail", new Object[0]));
/*      */   }
/*      */   
/*      */   void setThumbnail(Image image, int page) throws PdfException, DocumentException {
/* 1788 */     PdfIndirectReference thumb = getImageReference(addDirectImageSimple(image));
/* 1789 */     this.reader.resetReleasePage();
/* 1790 */     PdfDictionary dic = this.reader.getPageN(page);
/* 1791 */     dic.put(PdfName.THUMB, thumb);
/* 1792 */     this.reader.resetReleasePage();
/*      */   }
/*      */   
/*      */   public PdfContentByte getDirectContentUnder()
/*      */   {
/* 1797 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("use.pdfstamper.getundercontent.or.pdfstamper.getovercontent", new Object[0]));
/*      */   }
/*      */   
/*      */   public PdfContentByte getDirectContent()
/*      */   {
/* 1802 */     throw new UnsupportedOperationException(MessageLocalization.getComposedMessage("use.pdfstamper.getundercontent.or.pdfstamper.getovercontent", new Object[0]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readOCProperties()
/*      */   {
/* 1813 */     if (!this.documentOCG.isEmpty()) {
/* 1814 */       return;
/*      */     }
/* 1816 */     PdfDictionary dict = this.reader.getCatalog().getAsDict(PdfName.OCPROPERTIES);
/* 1817 */     if (dict == null) {
/* 1818 */       return;
/*      */     }
/* 1820 */     PdfArray ocgs = dict.getAsArray(PdfName.OCGS);
/*      */     
/*      */ 
/* 1823 */     HashMap<String, PdfLayer> ocgmap = new HashMap();
/* 1824 */     for (Iterator<PdfObject> i = ocgs.listIterator(); i.hasNext();) {
/* 1825 */       PdfIndirectReference ref = (PdfIndirectReference)i.next();
/* 1826 */       PdfLayer layer = new PdfLayer(null);
/* 1827 */       layer.setRef(ref);
/* 1828 */       layer.setOnPanel(false);
/* 1829 */       layer.merge((PdfDictionary)PdfReader.getPdfObject(ref));
/* 1830 */       ocgmap.put(ref.toString(), layer);
/*      */     }
/* 1832 */     PdfDictionary d = dict.getAsDict(PdfName.D);
/* 1833 */     PdfArray off = d.getAsArray(PdfName.OFF);
/* 1834 */     Iterator<PdfObject> i; if (off != null) {
/* 1835 */       for (i = off.listIterator(); i.hasNext();) {
/* 1836 */         PdfIndirectReference ref = (PdfIndirectReference)i.next();
/* 1837 */         PdfLayer layer = (PdfLayer)ocgmap.get(ref.toString());
/* 1838 */         layer.setOn(false);
/*      */       }
/*      */     }
/* 1841 */     PdfArray order = d.getAsArray(PdfName.ORDER);
/* 1842 */     if (order != null) {
/* 1843 */       addOrder(null, order, ocgmap);
/*      */     }
/* 1845 */     this.documentOCG.addAll(ocgmap.values());
/* 1846 */     this.OCGRadioGroup = d.getAsArray(PdfName.RBGROUPS);
/* 1847 */     if (this.OCGRadioGroup == null)
/* 1848 */       this.OCGRadioGroup = new PdfArray();
/* 1849 */     this.OCGLocked = d.getAsArray(PdfName.LOCKED);
/* 1850 */     if (this.OCGLocked == null) {
/* 1851 */       this.OCGLocked = new PdfArray();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addOrder(PdfLayer parent, PdfArray arr, Map<String, PdfLayer> ocgmap)
/*      */   {
/* 1865 */     for (int i = 0; i < arr.size(); i++) {
/* 1866 */       PdfObject obj = arr.getPdfObject(i);
/* 1867 */       if (obj.isIndirect()) {
/* 1868 */         PdfLayer layer = (PdfLayer)ocgmap.get(obj.toString());
/* 1869 */         if (layer != null) {
/* 1870 */           layer.setOnPanel(true);
/* 1871 */           registerLayer(layer);
/* 1872 */           if (parent != null) {
/* 1873 */             parent.addChild(layer);
/*      */           }
/* 1875 */           if ((arr.size() > i + 1) && (arr.getPdfObject(i + 1).isArray())) {
/* 1876 */             i++;
/* 1877 */             addOrder(layer, (PdfArray)arr.getPdfObject(i), ocgmap);
/*      */           }
/*      */         }
/* 1880 */       } else if (obj.isArray()) {
/* 1881 */         PdfArray sub = (PdfArray)obj;
/* 1882 */         if (sub.isEmpty()) return;
/* 1883 */         obj = sub.getPdfObject(0);
/* 1884 */         if (obj.isString()) {
/* 1885 */           PdfLayer layer = new PdfLayer(obj.toString());
/* 1886 */           layer.setOnPanel(true);
/* 1887 */           registerLayer(layer);
/* 1888 */           if (parent != null) {
/* 1889 */             parent.addChild(layer);
/*      */           }
/* 1891 */           PdfArray array = new PdfArray();
/* 1892 */           for (Iterator<PdfObject> j = sub.listIterator(); j.hasNext();) {
/* 1893 */             array.add((PdfObject)j.next());
/*      */           }
/* 1895 */           addOrder(layer, array, ocgmap);
/*      */         } else {
/* 1897 */           addOrder(parent, (PdfArray)obj, ocgmap);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, PdfLayer> getPdfLayers()
/*      */   {
/* 1911 */     if (!this.originalLayersAreRead) {
/* 1912 */       this.originalLayersAreRead = true;
/* 1913 */       readOCProperties();
/*      */     }
/* 1915 */     HashMap<String, PdfLayer> map = new HashMap();
/*      */     
/*      */ 
/* 1918 */     for (PdfOCG pdfOCG : this.documentOCG) {
/* 1919 */       PdfLayer layer = (PdfLayer)pdfOCG;
/* 1920 */       String key; String key; if (layer.getTitle() == null) {
/* 1921 */         key = layer.getAsString(PdfName.NAME).toString();
/*      */       } else {
/* 1923 */         key = layer.getTitle();
/*      */       }
/* 1925 */       if (map.containsKey(key)) {
/* 1926 */         int seq = 2;
/* 1927 */         String tmp = key + "(" + seq + ")";
/* 1928 */         while (map.containsKey(tmp)) {
/* 1929 */           seq++;
/* 1930 */           tmp = key + "(" + seq + ")";
/*      */         }
/* 1932 */         key = tmp;
/*      */       }
/* 1934 */       map.put(key, layer);
/*      */     }
/* 1936 */     return map;
/*      */   }
/*      */   
/*      */   void registerLayer(PdfOCG layer)
/*      */   {
/* 1941 */     if (!this.originalLayersAreRead) {
/* 1942 */       this.originalLayersAreRead = true;
/* 1943 */       readOCProperties();
/*      */     }
/* 1945 */     super.registerLayer(layer);
/*      */   }
/*      */   
/*      */   public void createXmpMetadata() {
/*      */     try {
/* 1950 */       this.xmpWriter = createXmpWriter(null, this.reader.getInfo());
/* 1951 */       this.xmpMetadata = null;
/*      */     } catch (IOException ioe) {
/* 1953 */       ioe.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   protected HashMap<Object, PdfObject> getNamedDestinations() {
/* 1958 */     return this.namedDestinations;
/*      */   }
/*      */   
/*      */   protected void updateNamedDestinations() throws IOException
/*      */   {
/* 1963 */     PdfDictionary dic = this.reader.getCatalog().getAsDict(PdfName.NAMES);
/* 1964 */     if (dic != null)
/* 1965 */       dic = dic.getAsDict(PdfName.DESTS);
/* 1966 */     if (dic == null) {
/* 1967 */       dic = this.reader.getCatalog().getAsDict(PdfName.DESTS);
/*      */     }
/* 1969 */     if (dic == null) {
/* 1970 */       dic = new PdfDictionary();
/* 1971 */       PdfDictionary dests = new PdfDictionary();
/* 1972 */       dic.put(PdfName.NAMES, new PdfArray());
/* 1973 */       dests.put(PdfName.DESTS, dic);
/* 1974 */       this.reader.getCatalog().put(PdfName.NAMES, dests);
/*      */     }
/*      */     
/* 1977 */     PdfArray names = getLastChildInNameTree(dic);
/*      */     
/* 1979 */     for (Object name : this.namedDestinations.keySet()) {
/* 1980 */       names.add(new PdfString(name.toString()));
/* 1981 */       names.add(addToBody((PdfObject)this.namedDestinations.get(name), getPdfIndirectReference()).getIndirectReference());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private PdfArray getLastChildInNameTree(PdfDictionary dic)
/*      */   {
/* 1989 */     PdfArray childNode = dic.getAsArray(PdfName.KIDS);
/* 1990 */     PdfArray names; PdfArray names; if (childNode != null) {
/* 1991 */       PdfDictionary lastKid = childNode.getAsDict(childNode.size() - 1);
/* 1992 */       names = getLastChildInNameTree(lastKid);
/*      */     } else {
/* 1994 */       names = dic.getAsArray(PdfName.NAMES);
/*      */     }
/*      */     
/* 1997 */     return names;
/*      */   }
/*      */   
/*      */   static class PageStamp
/*      */   {
/*      */     PdfDictionary pageN;
/*      */     StampContent under;
/*      */     StampContent over;
/*      */     PageResources pageResources;
/* 2006 */     int replacePoint = 0;
/*      */     
/*      */     PageStamp(PdfStamperImp stamper, PdfReader reader, PdfDictionary pageN) {
/* 2009 */       this.pageN = pageN;
/* 2010 */       this.pageResources = new PageResources();
/* 2011 */       PdfDictionary resources = pageN.getAsDict(PdfName.RESOURCES);
/* 2012 */       this.pageResources.setOriginalResources(resources, stamper.namePtr);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfStamperImp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */