/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import com.itextpdf.text.BaseColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PdfColor
/*    */   extends PdfArray
/*    */ {
/*    */   PdfColor(int red, int green, int blue)
/*    */   {
/* 68 */     super(new PdfNumber((red & 0xFF) / 255.0D));
/* 69 */     add(new PdfNumber((green & 0xFF) / 255.0D));
/* 70 */     add(new PdfNumber((blue & 0xFF) / 255.0D));
/*    */   }
/*    */   
/*    */   PdfColor(BaseColor color) {
/* 74 */     this(color.getRed(), color.getGreen(), color.getBlue());
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */