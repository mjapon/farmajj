/*    */ package com.itextpdf.text.pdf.parser;
/*    */ 
/*    */ import com.itextpdf.text.pdf.PdfDictionary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InlineImageInfo
/*    */ {
/*    */   private final byte[] samples;
/*    */   private final PdfDictionary imageDictionary;
/*    */   
/*    */   public InlineImageInfo(byte[] samples, PdfDictionary imageDictionary)
/*    */   {
/* 58 */     this.samples = samples;
/* 59 */     this.imageDictionary = imageDictionary;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PdfDictionary getImageDictionary()
/*    */   {
/* 66 */     return this.imageDictionary;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public byte[] getSamples()
/*    */   {
/* 73 */     return this.samples;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/InlineImageInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */