/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.AccessibleElementId;
/*      */ import com.itextpdf.text.Chunk;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ElementListener;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.LargeElement;
/*      */ import com.itextpdf.text.Phrase;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.api.Spaceable;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.log.Logger;
/*      */ import com.itextpdf.text.log.LoggerFactory;
/*      */ import com.itextpdf.text.pdf.events.PdfPTableEventForwarder;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfPTable
/*      */   implements LargeElement, Spaceable, IAccessibleElement
/*      */ {
/*   79 */   private final Logger LOGGER = LoggerFactory.getLogger(PdfPTable.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int BASECANVAS = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int BACKGROUNDCANVAS = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int LINECANVAS = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int TEXTCANVAS = 3;
/*      */   
/*      */ 
/*      */ 
/*  103 */   protected ArrayList<PdfPRow> rows = new ArrayList();
/*  104 */   protected float totalHeight = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfPCell[] currentRow;
/*      */   
/*      */ 
/*  111 */   protected int currentColIdx = 0;
/*  112 */   protected PdfPCell defaultCell = new PdfPCell((Phrase)null);
/*  113 */   protected float totalWidth = 0.0F;
/*      */   
/*      */ 
/*      */   protected float[] relativeWidths;
/*      */   
/*      */ 
/*      */   protected float[] absoluteWidths;
/*      */   
/*      */ 
/*      */   protected PdfPTableEvent tableEvent;
/*      */   
/*      */   protected int headerRows;
/*      */   
/*  126 */   protected float widthPercentage = 80.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  131 */   private int horizontalAlignment = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  136 */   private boolean skipFirstHeader = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  142 */   private boolean skipLastFooter = false;
/*      */   
/*  144 */   protected boolean isColspan = false;
/*      */   
/*  146 */   protected int runDirection = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  151 */   private boolean lockedWidth = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  156 */   private boolean splitRows = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float spacingBefore;
/*      */   
/*      */ 
/*      */ 
/*      */   protected float spacingAfter;
/*      */   
/*      */ 
/*      */ 
/*      */   protected float paddingTop;
/*      */   
/*      */ 
/*      */ 
/*  173 */   private boolean[] extendLastRow = { false, false };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean headersInEvent;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  183 */   private boolean splitLate = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean keepTogether;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   protected boolean complete = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int footerRows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */   protected boolean rowCompleted = true;
/*      */   
/*  209 */   protected boolean loopCheck = true;
/*  210 */   protected boolean rowsNotChecked = true;
/*      */   
/*  212 */   protected PdfName role = PdfName.TABLE;
/*  213 */   protected HashMap<PdfName, PdfObject> accessibleAttributes = null;
/*  214 */   protected AccessibleElementId id = new AccessibleElementId();
/*  215 */   private PdfPTableHeader header = null;
/*  216 */   private PdfPTableBody body = null;
/*  217 */   private PdfPTableFooter footer = null;
/*      */   
/*      */ 
/*      */   private int numberOfWrittenRows;
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfPTable() {}
/*      */   
/*      */ 
/*      */ 
/*      */   public PdfPTable(float[] relativeWidths)
/*      */   {
/*  230 */     if (relativeWidths == null) {
/*  231 */       throw new NullPointerException(MessageLocalization.getComposedMessage("the.widths.array.in.pdfptable.constructor.can.not.be.null", new Object[0]));
/*      */     }
/*  233 */     if (relativeWidths.length == 0) {
/*  234 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("the.widths.array.in.pdfptable.constructor.can.not.have.zero.length", new Object[0]));
/*      */     }
/*  236 */     this.relativeWidths = new float[relativeWidths.length];
/*  237 */     System.arraycopy(relativeWidths, 0, this.relativeWidths, 0, relativeWidths.length);
/*  238 */     this.absoluteWidths = new float[relativeWidths.length];
/*  239 */     calculateWidths();
/*  240 */     this.currentRow = new PdfPCell[this.absoluteWidths.length];
/*  241 */     this.keepTogether = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPTable(int numColumns)
/*      */   {
/*  250 */     if (numColumns <= 0) {
/*  251 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("the.number.of.columns.in.pdfptable.constructor.must.be.greater.than.zero", new Object[0]));
/*      */     }
/*  253 */     this.relativeWidths = new float[numColumns];
/*  254 */     for (int k = 0; k < numColumns; k++) {
/*  255 */       this.relativeWidths[k] = 1.0F;
/*      */     }
/*  257 */     this.absoluteWidths = new float[this.relativeWidths.length];
/*  258 */     calculateWidths();
/*  259 */     this.currentRow = new PdfPCell[this.absoluteWidths.length];
/*  260 */     this.keepTogether = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPTable(PdfPTable table)
/*      */   {
/*  269 */     copyFormat(table);
/*  270 */     for (int k = 0; k < this.currentRow.length; k++) {
/*  271 */       if (table.currentRow[k] == null) {
/*      */         break;
/*      */       }
/*  274 */       this.currentRow[k] = new PdfPCell(table.currentRow[k]);
/*      */     }
/*  276 */     for (int k = 0; k < table.rows.size(); k++) {
/*  277 */       PdfPRow row = (PdfPRow)table.rows.get(k);
/*  278 */       if (row != null) {
/*  279 */         row = new PdfPRow(row);
/*      */       }
/*  281 */       this.rows.add(row);
/*      */     }
/*      */   }
/*      */   
/*      */   public void init() {
/*  286 */     this.LOGGER.info("Initialize row and cell heights");
/*      */     
/*  288 */     for (PdfPRow row : getRows()) {
/*  289 */       if (row != null) {
/*  290 */         row.calculated = false;
/*  291 */         for (PdfPCell cell : row.getCells()) {
/*  292 */           if (cell != null) {
/*  293 */             cell.setCalculatedHeight(0.0F);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfPTable shallowCopy(PdfPTable table)
/*      */   {
/*  306 */     PdfPTable nt = new PdfPTable();
/*  307 */     nt.copyFormat(table);
/*  308 */     return nt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copyFormat(PdfPTable sourceTable)
/*      */   {
/*  318 */     this.rowsNotChecked = sourceTable.rowsNotChecked;
/*  319 */     this.relativeWidths = new float[sourceTable.getNumberOfColumns()];
/*  320 */     this.absoluteWidths = new float[sourceTable.getNumberOfColumns()];
/*  321 */     System.arraycopy(sourceTable.relativeWidths, 0, this.relativeWidths, 0, getNumberOfColumns());
/*  322 */     System.arraycopy(sourceTable.absoluteWidths, 0, this.absoluteWidths, 0, getNumberOfColumns());
/*  323 */     this.totalWidth = sourceTable.totalWidth;
/*  324 */     this.totalHeight = sourceTable.totalHeight;
/*  325 */     this.currentColIdx = 0;
/*  326 */     this.tableEvent = sourceTable.tableEvent;
/*  327 */     this.runDirection = sourceTable.runDirection;
/*  328 */     if ((sourceTable.defaultCell instanceof PdfPHeaderCell)) {
/*  329 */       this.defaultCell = new PdfPHeaderCell((PdfPHeaderCell)sourceTable.defaultCell);
/*      */     } else {
/*  331 */       this.defaultCell = new PdfPCell(sourceTable.defaultCell);
/*      */     }
/*  333 */     this.currentRow = new PdfPCell[sourceTable.currentRow.length];
/*  334 */     this.isColspan = sourceTable.isColspan;
/*  335 */     this.splitRows = sourceTable.splitRows;
/*  336 */     this.spacingAfter = sourceTable.spacingAfter;
/*  337 */     this.spacingBefore = sourceTable.spacingBefore;
/*  338 */     this.headerRows = sourceTable.headerRows;
/*  339 */     this.footerRows = sourceTable.footerRows;
/*  340 */     this.lockedWidth = sourceTable.lockedWidth;
/*  341 */     this.extendLastRow = sourceTable.extendLastRow;
/*  342 */     this.headersInEvent = sourceTable.headersInEvent;
/*  343 */     this.widthPercentage = sourceTable.widthPercentage;
/*  344 */     this.splitLate = sourceTable.splitLate;
/*  345 */     this.skipFirstHeader = sourceTable.skipFirstHeader;
/*  346 */     this.skipLastFooter = sourceTable.skipLastFooter;
/*  347 */     this.horizontalAlignment = sourceTable.horizontalAlignment;
/*  348 */     this.keepTogether = sourceTable.keepTogether;
/*  349 */     this.complete = sourceTable.complete;
/*  350 */     this.loopCheck = sourceTable.loopCheck;
/*  351 */     this.id = sourceTable.id;
/*  352 */     this.role = sourceTable.role;
/*  353 */     if (sourceTable.accessibleAttributes != null) {
/*  354 */       this.accessibleAttributes = new HashMap(sourceTable.accessibleAttributes);
/*      */     }
/*  356 */     this.header = sourceTable.getHeader();
/*  357 */     this.body = sourceTable.getBody();
/*  358 */     this.footer = sourceTable.getFooter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidths(float[] relativeWidths)
/*      */     throws DocumentException
/*      */   {
/*  369 */     if (relativeWidths.length != getNumberOfColumns()) {
/*  370 */       throw new DocumentException(MessageLocalization.getComposedMessage("wrong.number.of.columns", new Object[0]));
/*      */     }
/*  372 */     this.relativeWidths = new float[relativeWidths.length];
/*  373 */     System.arraycopy(relativeWidths, 0, this.relativeWidths, 0, relativeWidths.length);
/*  374 */     this.absoluteWidths = new float[relativeWidths.length];
/*  375 */     this.totalHeight = 0.0F;
/*  376 */     calculateWidths();
/*  377 */     calculateHeights();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidths(int[] relativeWidths)
/*      */     throws DocumentException
/*      */   {
/*  388 */     float[] tb = new float[relativeWidths.length];
/*  389 */     for (int k = 0; k < relativeWidths.length; k++) {
/*  390 */       tb[k] = relativeWidths[k];
/*      */     }
/*  392 */     setWidths(tb);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void calculateWidths()
/*      */   {
/*  399 */     if (this.totalWidth <= 0.0F) {
/*  400 */       return;
/*      */     }
/*  402 */     float total = 0.0F;
/*  403 */     int numCols = getNumberOfColumns();
/*  404 */     for (int k = 0; k < numCols; k++) {
/*  405 */       total += this.relativeWidths[k];
/*      */     }
/*  407 */     for (int k = 0; k < numCols; k++) {
/*  408 */       this.absoluteWidths[k] = (this.totalWidth * this.relativeWidths[k] / total);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTotalWidth(float totalWidth)
/*      */   {
/*  418 */     if (this.totalWidth == totalWidth) {
/*  419 */       return;
/*      */     }
/*  421 */     this.totalWidth = totalWidth;
/*  422 */     this.totalHeight = 0.0F;
/*  423 */     calculateWidths();
/*  424 */     calculateHeights();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTotalWidth(float[] columnWidth)
/*      */     throws DocumentException
/*      */   {
/*  435 */     if (columnWidth.length != getNumberOfColumns()) {
/*  436 */       throw new DocumentException(MessageLocalization.getComposedMessage("wrong.number.of.columns", new Object[0]));
/*      */     }
/*  438 */     this.totalWidth = 0.0F;
/*  439 */     for (int k = 0; k < columnWidth.length; k++) {
/*  440 */       this.totalWidth += columnWidth[k];
/*      */     }
/*  442 */     setWidths(columnWidth);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidthPercentage(float[] columnWidth, Rectangle pageSize)
/*      */     throws DocumentException
/*      */   {
/*  453 */     if (columnWidth.length != getNumberOfColumns()) {
/*  454 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("wrong.number.of.columns", new Object[0]));
/*      */     }
/*  456 */     setTotalWidth(columnWidth);
/*  457 */     this.widthPercentage = (this.totalWidth / (pageSize.getRight() - pageSize.getLeft()) * 100.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getTotalWidth()
/*      */   {
/*  466 */     return this.totalWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float calculateHeights()
/*      */   {
/*  477 */     if (this.totalWidth <= 0.0F) {
/*  478 */       return 0.0F;
/*      */     }
/*  480 */     this.totalHeight = 0.0F;
/*  481 */     for (int k = 0; k < this.rows.size(); k++) {
/*  482 */       this.totalHeight += getRowHeight(k, true);
/*      */     }
/*  484 */     return this.totalHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetColumnCount(int newColCount)
/*      */   {
/*  494 */     if (newColCount <= 0) {
/*  495 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("the.number.of.columns.in.pdfptable.constructor.must.be.greater.than.zero", new Object[0]));
/*      */     }
/*  497 */     this.relativeWidths = new float[newColCount];
/*  498 */     for (int k = 0; k < newColCount; k++) {
/*  499 */       this.relativeWidths[k] = 1.0F;
/*      */     }
/*  501 */     this.absoluteWidths = new float[this.relativeWidths.length];
/*  502 */     calculateWidths();
/*  503 */     this.currentRow = new PdfPCell[this.absoluteWidths.length];
/*  504 */     this.totalHeight = 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell getDefaultCell()
/*      */   {
/*  515 */     return this.defaultCell;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell addCell(PdfPCell cell)
/*      */   {
/*  524 */     this.rowCompleted = false;
/*      */     PdfPCell ncell;
/*  526 */     PdfPCell ncell; if ((cell instanceof PdfPHeaderCell)) {
/*  527 */       ncell = new PdfPHeaderCell((PdfPHeaderCell)cell);
/*      */     } else {
/*  529 */       ncell = new PdfPCell(cell);
/*      */     }
/*      */     
/*  532 */     int colspan = ncell.getColspan();
/*  533 */     colspan = Math.max(colspan, 1);
/*  534 */     colspan = Math.min(colspan, this.currentRow.length - this.currentColIdx);
/*  535 */     ncell.setColspan(colspan);
/*      */     
/*  537 */     if (colspan != 1) {
/*  538 */       this.isColspan = true;
/*      */     }
/*  540 */     int rdir = ncell.getRunDirection();
/*  541 */     if (rdir == 0) {
/*  542 */       ncell.setRunDirection(this.runDirection);
/*      */     }
/*      */     
/*  545 */     skipColsWithRowspanAbove();
/*      */     
/*  547 */     boolean cellAdded = false;
/*  548 */     if (this.currentColIdx < this.currentRow.length) {
/*  549 */       this.currentRow[this.currentColIdx] = ncell;
/*  550 */       this.currentColIdx += colspan;
/*  551 */       cellAdded = true;
/*      */     }
/*      */     
/*  554 */     skipColsWithRowspanAbove();
/*      */     
/*  556 */     while (this.currentColIdx >= this.currentRow.length) {
/*  557 */       int numCols = getNumberOfColumns();
/*  558 */       if (this.runDirection == 3) {
/*  559 */         PdfPCell[] rtlRow = new PdfPCell[numCols];
/*  560 */         int rev = this.currentRow.length;
/*  561 */         for (int k = 0; k < this.currentRow.length; k++) {
/*  562 */           PdfPCell rcell = this.currentRow[k];
/*  563 */           int cspan = rcell.getColspan();
/*  564 */           rev -= cspan;
/*  565 */           rtlRow[rev] = rcell;
/*  566 */           k += cspan - 1;
/*      */         }
/*  568 */         this.currentRow = rtlRow;
/*      */       }
/*  570 */       PdfPRow row = new PdfPRow(this.currentRow);
/*  571 */       if (this.totalWidth > 0.0F) {
/*  572 */         row.setWidths(this.absoluteWidths);
/*  573 */         this.totalHeight += row.getMaxHeights();
/*      */       }
/*  575 */       this.rows.add(row);
/*  576 */       this.currentRow = new PdfPCell[numCols];
/*  577 */       this.currentColIdx = 0;
/*  578 */       skipColsWithRowspanAbove();
/*  579 */       this.rowCompleted = true;
/*      */     }
/*      */     
/*  582 */     if (!cellAdded) {
/*  583 */       this.currentRow[this.currentColIdx] = ncell;
/*  584 */       this.currentColIdx += colspan;
/*      */     }
/*  586 */     return ncell;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void skipColsWithRowspanAbove()
/*      */   {
/*  596 */     int direction = 1;
/*  597 */     if (this.runDirection == 3) {
/*  598 */       direction = -1;
/*      */     }
/*  600 */     while (rowSpanAbove(this.rows.size(), this.currentColIdx)) {
/*  601 */       this.currentColIdx += direction;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfPCell cellAt(int row, int col)
/*      */   {
/*  614 */     PdfPCell[] cells = ((PdfPRow)this.rows.get(row)).getCells();
/*  615 */     for (int i = 0; i < cells.length; i++) {
/*  616 */       if ((cells[i] != null) && 
/*  617 */         (col >= i) && (col < i + cells[i].getColspan())) {
/*  618 */         return cells[i];
/*      */       }
/*      */     }
/*      */     
/*  622 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean rowSpanAbove(int currRow, int currCol)
/*      */   {
/*  634 */     if ((currCol >= getNumberOfColumns()) || (currCol < 0) || (currRow < 1))
/*      */     {
/*      */ 
/*  637 */       return false;
/*      */     }
/*  639 */     int row = currRow - 1;
/*  640 */     PdfPRow aboveRow = (PdfPRow)this.rows.get(row);
/*  641 */     if (aboveRow == null) {
/*  642 */       return false;
/*      */     }
/*  644 */     PdfPCell aboveCell = cellAt(row, currCol);
/*  645 */     while ((aboveCell == null) && (row > 0)) {
/*  646 */       aboveRow = (PdfPRow)this.rows.get(--row);
/*  647 */       if (aboveRow == null) {
/*  648 */         return false;
/*      */       }
/*  650 */       aboveCell = cellAt(row, currCol);
/*      */     }
/*      */     
/*  653 */     int distance = currRow - row;
/*      */     
/*  655 */     if ((aboveCell.getRowspan() == 1) && (distance > 1)) {
/*  656 */       int col = currCol - 1;
/*  657 */       aboveRow = (PdfPRow)this.rows.get(row + 1);
/*  658 */       distance--;
/*  659 */       aboveCell = aboveRow.getCells()[col];
/*  660 */       while ((aboveCell == null) && (col > 0)) {
/*  661 */         aboveCell = aboveRow.getCells()[(--col)];
/*      */       }
/*      */     }
/*      */     
/*  665 */     return (aboveCell != null) && (aboveCell.getRowspan() > distance);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCell(String text)
/*      */   {
/*  674 */     addCell(new Phrase(text));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCell(PdfPTable table)
/*      */   {
/*  683 */     this.defaultCell.setTable(table);
/*  684 */     PdfPCell newCell = addCell(this.defaultCell);
/*  685 */     newCell.id = new AccessibleElementId();
/*  686 */     this.defaultCell.setTable(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCell(Image image)
/*      */   {
/*  696 */     this.defaultCell.setImage(image);
/*  697 */     PdfPCell newCell = addCell(this.defaultCell);
/*  698 */     newCell.id = new AccessibleElementId();
/*  699 */     this.defaultCell.setImage(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCell(Phrase phrase)
/*      */   {
/*  708 */     this.defaultCell.setPhrase(phrase);
/*  709 */     PdfPCell newCell = addCell(this.defaultCell);
/*  710 */     newCell.id = new AccessibleElementId();
/*  711 */     this.defaultCell.setPhrase(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float writeSelectedRows(int rowStart, int rowEnd, float xPos, float yPos, PdfContentByte[] canvases)
/*      */   {
/*  729 */     return writeSelectedRows(0, -1, rowStart, rowEnd, xPos, yPos, canvases);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float writeSelectedRows(int colStart, int colEnd, int rowStart, int rowEnd, float xPos, float yPos, PdfContentByte[] canvases)
/*      */   {
/*  753 */     return writeSelectedRows(colStart, colEnd, rowStart, rowEnd, xPos, yPos, canvases, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float writeSelectedRows(int colStart, int colEnd, int rowStart, int rowEnd, float xPos, float yPos, PdfContentByte[] canvases, boolean reusable)
/*      */   {
/*  781 */     if (this.totalWidth <= 0.0F) {
/*  782 */       throw new RuntimeException(MessageLocalization.getComposedMessage("the.table.width.must.be.greater.than.zero", new Object[0]));
/*      */     }
/*      */     
/*  785 */     int totalRows = this.rows.size();
/*  786 */     if (rowStart < 0) {
/*  787 */       rowStart = 0;
/*      */     }
/*  789 */     if (rowEnd < 0) {
/*  790 */       rowEnd = totalRows;
/*      */     } else {
/*  792 */       rowEnd = Math.min(rowEnd, totalRows);
/*      */     }
/*  794 */     if (rowStart >= rowEnd) {
/*  795 */       return yPos;
/*      */     }
/*      */     
/*  798 */     int totalCols = getNumberOfColumns();
/*  799 */     if (colStart < 0) {
/*  800 */       colStart = 0;
/*      */     } else {
/*  802 */       colStart = Math.min(colStart, totalCols);
/*      */     }
/*  804 */     if (colEnd < 0) {
/*  805 */       colEnd = totalCols;
/*      */     } else {
/*  807 */       colEnd = Math.min(colEnd, totalCols);
/*      */     }
/*      */     
/*  810 */     this.LOGGER.info(String.format("Writing row %s to %s; column %s to %s", new Object[] { Integer.valueOf(rowStart), Integer.valueOf(rowEnd), Integer.valueOf(colStart), Integer.valueOf(colEnd) }));
/*      */     
/*  812 */     float yPosStart = yPos;
/*      */     
/*  814 */     PdfPTableBody currentBlock = null;
/*  815 */     if (this.rowsNotChecked) {
/*  816 */       getFittingRows(Float.MAX_VALUE, rowStart);
/*      */     }
/*  818 */     List<PdfPRow> rows = getRows(rowStart, rowEnd);
/*  819 */     int k = rowStart;
/*  820 */     for (PdfPRow row : rows) {
/*  821 */       if ((getHeader().rows != null) && (getHeader().rows.contains(row)) && (currentBlock == null)) {
/*  822 */         currentBlock = openTableBlock(getHeader(), canvases[3]);
/*  823 */       } else if ((getBody().rows != null) && (getBody().rows.contains(row)) && (currentBlock == null)) {
/*  824 */         currentBlock = openTableBlock(getBody(), canvases[3]);
/*  825 */       } else if ((getFooter().rows != null) && (getFooter().rows.contains(row)) && (currentBlock == null)) {
/*  826 */         currentBlock = openTableBlock(getFooter(), canvases[3]);
/*      */       }
/*  828 */       if (row != null) {
/*  829 */         row.writeCells(colStart, colEnd, xPos, yPos, canvases, reusable);
/*  830 */         yPos -= row.getMaxHeights();
/*      */       }
/*  832 */       if ((getHeader().rows != null) && (getHeader().rows.contains(row)) && ((k == rowEnd - 1) || (!getHeader().rows.contains(rows.get(k + 1))))) {
/*  833 */         currentBlock = closeTableBlock(getHeader(), canvases[3]);
/*  834 */       } else if ((getBody().rows != null) && (getBody().rows.contains(row)) && ((k == rowEnd - 1) || (!getBody().rows.contains(rows.get(k + 1))))) {
/*  835 */         currentBlock = closeTableBlock(getBody(), canvases[3]);
/*  836 */       } else if ((getFooter().rows != null) && (getFooter().rows.contains(row)) && ((k == rowEnd - 1) || (!getFooter().rows.contains(rows.get(k + 1))))) {
/*  837 */         currentBlock = closeTableBlock(getFooter(), canvases[3]);
/*      */       }
/*  839 */       k++;
/*      */     }
/*      */     
/*  842 */     if ((this.tableEvent != null) && (colStart == 0) && (colEnd == totalCols)) {
/*  843 */       float[] heights = new float[rowEnd - rowStart + 1];
/*  844 */       heights[0] = yPosStart;
/*  845 */       for (k = rowStart; k < rowEnd; k++) {
/*  846 */         PdfPRow row = (PdfPRow)rows.get(k);
/*  847 */         float hr = 0.0F;
/*  848 */         if (row != null) {
/*  849 */           hr = row.getMaxHeights();
/*      */         }
/*  851 */         heights[(k - rowStart + 1)] = (heights[(k - rowStart)] - hr);
/*      */       }
/*  853 */       this.tableEvent.tableLayout(this, getEventWidths(xPos, rowStart, rowEnd, this.headersInEvent), heights, this.headersInEvent ? this.headerRows : 0, rowStart, canvases);
/*      */     }
/*      */     
/*  856 */     return yPos;
/*      */   }
/*      */   
/*      */   private PdfPTableBody openTableBlock(PdfPTableBody block, PdfContentByte canvas) {
/*  860 */     if (canvas.writer.getStandardStructElems().contains(block.getRole())) {
/*  861 */       canvas.openMCBlock(block);
/*  862 */       return block;
/*      */     }
/*  864 */     return null;
/*      */   }
/*      */   
/*      */   private PdfPTableBody closeTableBlock(PdfPTableBody block, PdfContentByte canvas) {
/*  868 */     if (canvas.writer.getStandardStructElems().contains(block.getRole())) {
/*  869 */       canvas.closeMCBlock(block);
/*      */     }
/*  871 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float writeSelectedRows(int rowStart, int rowEnd, float xPos, float yPos, PdfContentByte canvas)
/*      */   {
/*  887 */     return writeSelectedRows(0, -1, rowStart, rowEnd, xPos, yPos, canvas);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float writeSelectedRows(int colStart, int colEnd, int rowStart, int rowEnd, float xPos, float yPos, PdfContentByte canvas)
/*      */   {
/*  908 */     return writeSelectedRows(colStart, colEnd, rowStart, rowEnd, xPos, yPos, canvas, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float writeSelectedRows(int colStart, int colEnd, int rowStart, int rowEnd, float xPos, float yPos, PdfContentByte canvas, boolean reusable)
/*      */   {
/*  933 */     int totalCols = getNumberOfColumns();
/*  934 */     if (colStart < 0) {
/*  935 */       colStart = 0;
/*      */     } else {
/*  937 */       colStart = Math.min(colStart, totalCols);
/*      */     }
/*      */     
/*  940 */     if (colEnd < 0) {
/*  941 */       colEnd = totalCols;
/*      */     } else {
/*  943 */       colEnd = Math.min(colEnd, totalCols);
/*      */     }
/*      */     
/*  946 */     boolean clip = (colStart != 0) || (colEnd != totalCols);
/*      */     
/*  948 */     if (clip) {
/*  949 */       float w = 0.0F;
/*  950 */       for (int k = colStart; k < colEnd; k++) {
/*  951 */         w += this.absoluteWidths[k];
/*      */       }
/*  953 */       canvas.saveState();
/*  954 */       float lx = colStart == 0 ? 10000.0F : 0.0F;
/*  955 */       float rx = colEnd == totalCols ? 10000.0F : 0.0F;
/*  956 */       canvas.rectangle(xPos - lx, -10000.0F, w + lx + rx, 20000.0F);
/*  957 */       canvas.clip();
/*  958 */       canvas.newPath();
/*      */     }
/*      */     
/*  961 */     PdfContentByte[] canvases = beginWritingRows(canvas);
/*  962 */     float y = writeSelectedRows(colStart, colEnd, rowStart, rowEnd, xPos, yPos, canvases, reusable);
/*  963 */     endWritingRows(canvases);
/*      */     
/*  965 */     if (clip) {
/*  966 */       canvas.restoreState();
/*      */     }
/*      */     
/*  969 */     return y;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfContentByte[] beginWritingRows(PdfContentByte canvas)
/*      */   {
/*  999 */     return new PdfContentByte[] { canvas, canvas.getDuplicate(), canvas.getDuplicate(), canvas.getDuplicate() };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void endWritingRows(PdfContentByte[] canvases)
/*      */   {
/* 1008 */     PdfContentByte canvas = canvases[0];
/* 1009 */     PdfArtifact artifact = new PdfArtifact();
/* 1010 */     canvas.openMCBlock(artifact);
/* 1011 */     canvas.saveState();
/* 1012 */     canvas.add(canvases[1]);
/* 1013 */     canvas.restoreState();
/* 1014 */     canvas.saveState();
/* 1015 */     canvas.setLineCap(2);
/* 1016 */     canvas.resetRGBColorStroke();
/* 1017 */     canvas.add(canvases[2]);
/* 1018 */     canvas.restoreState();
/* 1019 */     canvas.closeMCBlock(artifact);
/* 1020 */     canvas.add(canvases[3]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/* 1029 */     return this.rows.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getTotalHeight()
/*      */   {
/* 1038 */     return this.totalHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getRowHeight(int idx)
/*      */   {
/* 1048 */     return getRowHeight(idx, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float getRowHeight(int idx, boolean firsttime)
/*      */   {
/* 1060 */     if ((this.totalWidth <= 0.0F) || (idx < 0) || (idx >= this.rows.size())) {
/* 1061 */       return 0.0F;
/*      */     }
/* 1063 */     PdfPRow row = (PdfPRow)this.rows.get(idx);
/* 1064 */     if (row == null) {
/* 1065 */       return 0.0F;
/*      */     }
/* 1067 */     if (firsttime) {
/* 1068 */       row.setWidths(this.absoluteWidths);
/*      */     }
/* 1070 */     float height = row.getMaxHeights();
/*      */     
/*      */ 
/* 1073 */     for (int i = 0; i < this.relativeWidths.length; i++) {
/* 1074 */       if (rowSpanAbove(idx, i))
/*      */       {
/*      */ 
/* 1077 */         int rs = 1;
/* 1078 */         while (rowSpanAbove(idx - rs, i)) {
/* 1079 */           rs++;
/*      */         }
/* 1081 */         PdfPRow tmprow = (PdfPRow)this.rows.get(idx - rs);
/* 1082 */         PdfPCell cell = tmprow.getCells()[i];
/* 1083 */         float tmp = 0.0F;
/* 1084 */         if ((cell != null) && (cell.getRowspan() == rs + 1)) {
/* 1085 */           tmp = cell.getMaxHeight();
/* 1086 */           while (rs > 0) {
/* 1087 */             tmp -= getRowHeight(idx - rs);
/* 1088 */             rs--;
/*      */           }
/*      */         }
/* 1091 */         if (tmp > height)
/* 1092 */           height = tmp;
/*      */       }
/*      */     }
/* 1095 */     row.setMaxHeights(height);
/* 1096 */     return height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getRowspanHeight(int rowIndex, int cellIndex)
/*      */   {
/* 1110 */     if ((this.totalWidth <= 0.0F) || (rowIndex < 0) || (rowIndex >= this.rows.size())) {
/* 1111 */       return 0.0F;
/*      */     }
/* 1113 */     PdfPRow row = (PdfPRow)this.rows.get(rowIndex);
/* 1114 */     if ((row == null) || (cellIndex >= row.getCells().length)) {
/* 1115 */       return 0.0F;
/*      */     }
/* 1117 */     PdfPCell cell = row.getCells()[cellIndex];
/* 1118 */     if (cell == null) {
/* 1119 */       return 0.0F;
/*      */     }
/* 1121 */     float rowspanHeight = 0.0F;
/* 1122 */     for (int j = 0; j < cell.getRowspan(); j++) {
/* 1123 */       rowspanHeight += getRowHeight(rowIndex + j);
/*      */     }
/* 1125 */     return rowspanHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasRowspan(int rowIdx)
/*      */   {
/* 1134 */     if ((rowIdx < this.rows.size()) && (getRow(rowIdx).hasRowspan())) {
/* 1135 */       return true;
/*      */     }
/* 1137 */     PdfPRow previousRow = rowIdx > 0 ? getRow(rowIdx - 1) : null;
/* 1138 */     if ((previousRow != null) && (previousRow.hasRowspan())) {
/* 1139 */       return true;
/*      */     }
/* 1141 */     for (int i = 0; i < getNumberOfColumns(); i++) {
/* 1142 */       if (rowSpanAbove(rowIdx - 1, i)) {
/* 1143 */         return true;
/*      */       }
/*      */     }
/* 1146 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void normalizeHeadersFooters()
/*      */   {
/* 1155 */     if (this.footerRows > this.headerRows) {
/* 1156 */       this.footerRows = this.headerRows;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getHeaderHeight()
/*      */   {
/* 1167 */     float total = 0.0F;
/* 1168 */     int size = Math.min(this.rows.size(), this.headerRows);
/* 1169 */     for (int k = 0; k < size; k++) {
/* 1170 */       PdfPRow row = (PdfPRow)this.rows.get(k);
/* 1171 */       if (row != null) {
/* 1172 */         total += row.getMaxHeights();
/*      */       }
/*      */     }
/* 1175 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFooterHeight()
/*      */   {
/* 1186 */     float total = 0.0F;
/* 1187 */     int start = Math.max(0, this.headerRows - this.footerRows);
/* 1188 */     int size = Math.min(this.rows.size(), this.headerRows);
/* 1189 */     for (int k = start; k < size; k++) {
/* 1190 */       PdfPRow row = (PdfPRow)this.rows.get(k);
/* 1191 */       if (row != null) {
/* 1192 */         total += row.getMaxHeights();
/*      */       }
/*      */     }
/* 1195 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean deleteRow(int rowNumber)
/*      */   {
/* 1205 */     if ((rowNumber < 0) || (rowNumber >= this.rows.size())) {
/* 1206 */       return false;
/*      */     }
/* 1208 */     if (this.totalWidth > 0.0F) {
/* 1209 */       PdfPRow row = (PdfPRow)this.rows.get(rowNumber);
/* 1210 */       if (row != null) {
/* 1211 */         this.totalHeight -= row.getMaxHeights();
/*      */       }
/*      */     }
/* 1214 */     this.rows.remove(rowNumber);
/* 1215 */     if (rowNumber < this.headerRows) {
/* 1216 */       this.headerRows -= 1;
/* 1217 */       if (rowNumber >= this.headerRows - this.footerRows) {
/* 1218 */         this.footerRows -= 1;
/*      */       }
/*      */     }
/* 1221 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean deleteLastRow()
/*      */   {
/* 1230 */     return deleteRow(this.rows.size() - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void deleteBodyRows()
/*      */   {
/* 1237 */     ArrayList<PdfPRow> rows2 = new ArrayList();
/* 1238 */     for (int k = 0; k < this.headerRows; k++) {
/* 1239 */       rows2.add(this.rows.get(k));
/*      */     }
/* 1241 */     this.rows = rows2;
/* 1242 */     this.totalHeight = 0.0F;
/* 1243 */     if (this.totalWidth > 0.0F) {
/* 1244 */       this.totalHeight = getHeaderHeight();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumberOfColumns()
/*      */   {
/* 1255 */     return this.relativeWidths.length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHeaderRows()
/*      */   {
/* 1264 */     return this.headerRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderRows(int headerRows)
/*      */   {
/* 1275 */     if (headerRows < 0) {
/* 1276 */       headerRows = 0;
/*      */     }
/* 1278 */     this.headerRows = headerRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<Chunk> getChunks()
/*      */   {
/* 1287 */     return new ArrayList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int type()
/*      */   {
/* 1296 */     return 23;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isContent()
/*      */   {
/* 1304 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNestable()
/*      */   {
/* 1312 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean process(ElementListener listener)
/*      */   {
/*      */     try
/*      */     {
/* 1324 */       return listener.add(this);
/*      */     } catch (DocumentException de) {}
/* 1326 */     return false;
/*      */   }
/*      */   
/*      */   public String getSummary()
/*      */   {
/* 1331 */     return getAccessibleAttribute(PdfName.SUMMARY).toString();
/*      */   }
/*      */   
/*      */   public void setSummary(String summary) {
/* 1335 */     setAccessibleAttribute(PdfName.SUMMARY, new PdfString(summary));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWidthPercentage()
/*      */   {
/* 1344 */     return this.widthPercentage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidthPercentage(float widthPercentage)
/*      */   {
/* 1354 */     this.widthPercentage = widthPercentage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHorizontalAlignment()
/*      */   {
/* 1363 */     return this.horizontalAlignment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHorizontalAlignment(int horizontalAlignment)
/*      */   {
/* 1374 */     this.horizontalAlignment = horizontalAlignment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPRow getRow(int idx)
/*      */   {
/* 1384 */     return (PdfPRow)this.rows.get(idx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<PdfPRow> getRows()
/*      */   {
/* 1393 */     return this.rows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastCompletedRowIndex()
/*      */   {
/* 1402 */     return this.rows.size() - 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBreakPoints(int... breakPoints)
/*      */   {
/* 1413 */     keepRowsTogether(0, this.rows.size());
/*      */     
/* 1415 */     for (int i = 0; i < breakPoints.length; i++) {
/* 1416 */       getRow(breakPoints[i]).setMayNotBreak(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void keepRowsTogether(int[] rows)
/*      */   {
/* 1428 */     for (int i = 0; i < rows.length; i++) {
/* 1429 */       getRow(rows[i]).setMayNotBreak(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void keepRowsTogether(int start, int end)
/*      */   {
/* 1442 */     if (start < end) {
/* 1443 */       while (start < end) {
/* 1444 */         getRow(start).setMayNotBreak(true);
/* 1445 */         start++;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void keepRowsTogether(int start)
/*      */   {
/* 1460 */     keepRowsTogether(start, this.rows.size());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<PdfPRow> getRows(int start, int end)
/*      */   {
/* 1472 */     ArrayList<PdfPRow> list = new ArrayList();
/* 1473 */     if ((start < 0) || (end > size())) {
/* 1474 */       return list;
/*      */     }
/* 1476 */     for (int i = start; i < end; i++) {
/* 1477 */       list.add(adjustCellsInRow(i, end));
/*      */     }
/* 1479 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfPRow adjustCellsInRow(int start, int end)
/*      */   {
/* 1490 */     PdfPRow row = getRow(start);
/* 1491 */     if (row.isAdjusted()) {
/* 1492 */       return row;
/*      */     }
/* 1494 */     row = new PdfPRow(row);
/*      */     
/* 1496 */     PdfPCell[] cells = row.getCells();
/* 1497 */     for (int i = 0; i < cells.length; i++) {
/* 1498 */       PdfPCell cell = cells[i];
/* 1499 */       if ((cell != null) && (cell.getRowspan() != 1))
/*      */       {
/*      */ 
/* 1502 */         int stop = Math.min(end, start + cell.getRowspan());
/* 1503 */         float extra = 0.0F;
/* 1504 */         for (int k = start + 1; k < stop; k++) {
/* 1505 */           extra += getRow(k).getMaxHeights();
/*      */         }
/* 1507 */         row.setExtraHeight(i, extra);
/*      */       } }
/* 1509 */     row.setAdjusted(true);
/* 1510 */     return row;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTableEvent(PdfPTableEvent event)
/*      */   {
/* 1519 */     if (event == null) {
/* 1520 */       this.tableEvent = null;
/* 1521 */     } else if (this.tableEvent == null) {
/* 1522 */       this.tableEvent = event;
/* 1523 */     } else if ((this.tableEvent instanceof PdfPTableEventForwarder)) {
/* 1524 */       ((PdfPTableEventForwarder)this.tableEvent).addTableEvent(event);
/*      */     } else {
/* 1526 */       PdfPTableEventForwarder forward = new PdfPTableEventForwarder();
/* 1527 */       forward.addTableEvent(this.tableEvent);
/* 1528 */       forward.addTableEvent(event);
/* 1529 */       this.tableEvent = forward;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPTableEvent getTableEvent()
/*      */   {
/* 1539 */     return this.tableEvent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float[] getAbsoluteWidths()
/*      */   {
/* 1548 */     return this.absoluteWidths;
/*      */   }
/*      */   
/*      */   float[][] getEventWidths(float xPos, int firstRow, int lastRow, boolean includeHeaders) {
/* 1552 */     if (includeHeaders) {
/* 1553 */       firstRow = Math.max(firstRow, this.headerRows);
/* 1554 */       lastRow = Math.max(lastRow, this.headerRows);
/*      */     }
/* 1556 */     float[][] widths = new float[(includeHeaders ? this.headerRows : 0) + lastRow - firstRow][];
/* 1557 */     if (this.isColspan) {
/* 1558 */       int n = 0;
/* 1559 */       if (includeHeaders) {
/* 1560 */         for (int k = 0; k < this.headerRows; k++) {
/* 1561 */           PdfPRow row = (PdfPRow)this.rows.get(k);
/* 1562 */           if (row == null) {
/* 1563 */             n++;
/*      */           } else {
/* 1565 */             widths[(n++)] = row.getEventWidth(xPos, this.absoluteWidths);
/*      */           }
/*      */         }
/*      */       }
/* 1569 */       for (; firstRow < lastRow; firstRow++) {
/* 1570 */         PdfPRow row = (PdfPRow)this.rows.get(firstRow);
/* 1571 */         if (row == null) {
/* 1572 */           n++;
/*      */         } else {
/* 1574 */           widths[(n++)] = row.getEventWidth(xPos, this.absoluteWidths);
/*      */         }
/*      */       }
/*      */     } else {
/* 1578 */       int numCols = getNumberOfColumns();
/* 1579 */       float[] width = new float[numCols + 1];
/* 1580 */       width[0] = xPos;
/* 1581 */       for (int k = 0; k < numCols; k++) {
/* 1582 */         width[(k + 1)] = (width[k] + this.absoluteWidths[k]);
/*      */       }
/* 1584 */       for (int k = 0; k < widths.length; k++) {
/* 1585 */         widths[k] = width;
/*      */       }
/*      */     }
/* 1588 */     return widths;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSkipFirstHeader()
/*      */   {
/* 1598 */     return this.skipFirstHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSkipLastFooter()
/*      */   {
/* 1609 */     return this.skipLastFooter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSkipFirstHeader(boolean skipFirstHeader)
/*      */   {
/* 1619 */     this.skipFirstHeader = skipFirstHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSkipLastFooter(boolean skipLastFooter)
/*      */   {
/* 1630 */     this.skipLastFooter = skipLastFooter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunDirection(int runDirection)
/*      */   {
/* 1641 */     switch (runDirection) {
/*      */     case 0: 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/* 1646 */       this.runDirection = runDirection;
/* 1647 */       break;
/*      */     default: 
/* 1649 */       throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.run.direction.1", runDirection));
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRunDirection()
/*      */   {
/* 1661 */     return this.runDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLockedWidth()
/*      */   {
/* 1670 */     return this.lockedWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLockedWidth(boolean lockedWidth)
/*      */   {
/* 1681 */     this.lockedWidth = lockedWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSplitRows()
/*      */   {
/* 1690 */     return this.splitRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSplitRows(boolean splitRows)
/*      */   {
/* 1701 */     this.splitRows = splitRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpacingBefore(float spacing)
/*      */   {
/* 1710 */     this.spacingBefore = spacing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpacingAfter(float spacing)
/*      */   {
/* 1719 */     this.spacingAfter = spacing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float spacingBefore()
/*      */   {
/* 1728 */     return this.spacingBefore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float spacingAfter()
/*      */   {
/* 1737 */     return this.spacingAfter;
/*      */   }
/*      */   
/*      */   public float getPaddingTop() {
/* 1741 */     return this.paddingTop;
/*      */   }
/*      */   
/*      */   public void setPaddingTop(float paddingTop) {
/* 1745 */     this.paddingTop = paddingTop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isExtendLastRow()
/*      */   {
/* 1754 */     return this.extendLastRow[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExtendLastRow(boolean extendLastRows)
/*      */   {
/* 1764 */     this.extendLastRow[0] = extendLastRows;
/* 1765 */     this.extendLastRow[1] = extendLastRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExtendLastRow(boolean extendLastRows, boolean extendFinalRow)
/*      */   {
/* 1779 */     this.extendLastRow[0] = extendLastRows;
/* 1780 */     this.extendLastRow[1] = extendFinalRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isExtendLastRow(boolean newPageFollows)
/*      */   {
/* 1791 */     if (newPageFollows) {
/* 1792 */       return this.extendLastRow[0];
/*      */     }
/* 1794 */     return this.extendLastRow[1];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHeadersInEvent()
/*      */   {
/* 1803 */     return this.headersInEvent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeadersInEvent(boolean headersInEvent)
/*      */   {
/* 1812 */     this.headersInEvent = headersInEvent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSplitLate()
/*      */   {
/* 1821 */     return this.splitLate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSplitLate(boolean splitLate)
/*      */   {
/* 1831 */     this.splitLate = splitLate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setKeepTogether(boolean keepTogether)
/*      */   {
/* 1842 */     this.keepTogether = keepTogether;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getKeepTogether()
/*      */   {
/* 1852 */     return this.keepTogether;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFooterRows()
/*      */   {
/* 1861 */     return this.footerRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFooterRows(int footerRows)
/*      */   {
/* 1877 */     if (footerRows < 0) {
/* 1878 */       footerRows = 0;
/*      */     }
/* 1880 */     this.footerRows = footerRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void completeRow()
/*      */   {
/* 1889 */     while (!this.rowCompleted) {
/* 1890 */       addCell(this.defaultCell);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flushContent()
/*      */   {
/* 1899 */     deleteBodyRows();
/*      */     
/*      */ 
/* 1902 */     if (this.numberOfWrittenRows > 0) {
/* 1903 */       setSkipFirstHeader(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addNumberOfRowsWritten(int numberOfWrittenRows)
/*      */   {
/* 1914 */     this.numberOfWrittenRows += numberOfWrittenRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isComplete()
/*      */   {
/* 1922 */     return this.complete;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setComplete(boolean complete)
/*      */   {
/* 1930 */     this.complete = complete;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public float getSpacingBefore()
/*      */   {
/* 1937 */     return this.spacingBefore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public float getSpacingAfter()
/*      */   {
/* 1944 */     return this.spacingAfter;
/*      */   }
/*      */   
/*      */   public boolean isLoopCheck() {
/* 1948 */     return this.loopCheck;
/*      */   }
/*      */   
/*      */   public void setLoopCheck(boolean loopCheck) {
/* 1952 */     this.loopCheck = loopCheck;
/*      */   }
/*      */   
/*      */   public PdfObject getAccessibleAttribute(PdfName key) {
/* 1956 */     if (this.accessibleAttributes != null) {
/* 1957 */       return (PdfObject)this.accessibleAttributes.get(key);
/*      */     }
/* 1959 */     return null;
/*      */   }
/*      */   
/*      */   public void setAccessibleAttribute(PdfName key, PdfObject value)
/*      */   {
/* 1964 */     if (this.accessibleAttributes == null) {
/* 1965 */       this.accessibleAttributes = new HashMap();
/*      */     }
/* 1967 */     this.accessibleAttributes.put(key, value);
/*      */   }
/*      */   
/*      */   public HashMap<PdfName, PdfObject> getAccessibleAttributes() {
/* 1971 */     return this.accessibleAttributes;
/*      */   }
/*      */   
/*      */   public PdfName getRole() {
/* 1975 */     return this.role;
/*      */   }
/*      */   
/*      */   public void setRole(PdfName role) {
/* 1979 */     this.role = role;
/*      */   }
/*      */   
/*      */   public AccessibleElementId getId() {
/* 1983 */     return this.id;
/*      */   }
/*      */   
/*      */   public void setId(AccessibleElementId id) {
/* 1987 */     this.id = id;
/*      */   }
/*      */   
/*      */   public boolean isInline() {
/* 1991 */     return false;
/*      */   }
/*      */   
/*      */   public PdfPTableHeader getHeader() {
/* 1995 */     if (this.header == null) {
/* 1996 */       this.header = new PdfPTableHeader();
/*      */     }
/* 1998 */     return this.header;
/*      */   }
/*      */   
/*      */   public PdfPTableBody getBody() {
/* 2002 */     if (this.body == null) {
/* 2003 */       this.body = new PdfPTableBody();
/*      */     }
/* 2005 */     return this.body;
/*      */   }
/*      */   
/*      */   public PdfPTableFooter getFooter() {
/* 2009 */     if (this.footer == null) {
/* 2010 */       this.footer = new PdfPTableFooter();
/*      */     }
/* 2012 */     return this.footer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCellStartRowIndex(int rowIdx, int colIdx)
/*      */   {
/* 2025 */     int lastRow = rowIdx;
/* 2026 */     while ((getRow(lastRow).getCells()[colIdx] == null) && (lastRow > 0)) {
/* 2027 */       lastRow--;
/*      */     }
/* 2029 */     return lastRow;
/*      */   }
/*      */   
/*      */ 
/*      */   public static class FittingRows
/*      */   {
/*      */     public final int firstRow;
/*      */     
/*      */     public final int lastRow;
/*      */     
/*      */     public final float height;
/*      */     
/*      */     public final float completedRowsHeight;
/*      */     
/*      */     private final Map<Integer, Float> correctedHeightsForLastRow;
/*      */     
/*      */     public FittingRows(int firstRow, int lastRow, float height, float completedRowsHeight, Map<Integer, Float> correctedHeightsForLastRow)
/*      */     {
/* 2047 */       this.firstRow = firstRow;
/* 2048 */       this.lastRow = lastRow;
/* 2049 */       this.height = height;
/* 2050 */       this.completedRowsHeight = completedRowsHeight;
/* 2051 */       this.correctedHeightsForLastRow = correctedHeightsForLastRow;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void correctLastRowChosen(PdfPTable table, int k)
/*      */     {
/* 2060 */       PdfPRow row = table.getRow(k);
/* 2061 */       Float value = (Float)this.correctedHeightsForLastRow.get(Integer.valueOf(k));
/* 2062 */       if (value != null) {
/* 2063 */         row.setFinalMaxHeights(value.floatValue());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class ColumnMeasurementState
/*      */   {
/* 2076 */     public float height = 0.0F;
/*      */     
/* 2078 */     public int rowspan = 1; public int colspan = 1;
/*      */     
/*      */     public void beginCell(PdfPCell cell, float completedRowsHeight, float rowHeight) {
/* 2081 */       this.rowspan = cell.getRowspan();
/* 2082 */       this.colspan = cell.getColspan();
/* 2083 */       this.height = (completedRowsHeight + Math.max(cell.hasCachedMaxHeight() ? cell.getCachedMaxHeight() : cell.getMaxHeight(), rowHeight));
/*      */     }
/*      */     
/*      */     public void consumeRowspan(float completedRowsHeight, float rowHeight) {
/* 2087 */       this.rowspan -= 1;
/*      */     }
/*      */     
/*      */     public boolean cellEnds() {
/* 2091 */       return this.rowspan == 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FittingRows getFittingRows(float availableHeight, int startIdx)
/*      */   {
/* 2111 */     this.LOGGER.info(String.format("getFittingRows(%s, %s)", new Object[] { Float.valueOf(availableHeight), Integer.valueOf(startIdx) }));
/* 2112 */     if ((startIdx > 0) && (startIdx < this.rows.size()) && 
/* 2113 */       (!$assertionsDisabled) && (getRow(startIdx).getCells()[0] == null)) { throw new AssertionError();
/*      */     }
/* 2115 */     int cols = getNumberOfColumns();
/* 2116 */     ColumnMeasurementState[] states = new ColumnMeasurementState[cols];
/* 2117 */     for (int i = 0; i < cols; i++) {
/* 2118 */       states[i] = new ColumnMeasurementState();
/*      */     }
/* 2120 */     float completedRowsHeight = 0.0F;
/*      */     
/* 2122 */     float totalHeight = 0.0F;
/* 2123 */     Map<Integer, Float> correctedHeightsForLastRow = new HashMap();
/*      */     
/* 2125 */     for (int k = startIdx; k < size(); k++) {
/* 2126 */       PdfPRow row = getRow(k);
/* 2127 */       float rowHeight = row.getMaxRowHeightsWithoutCalculating();
/* 2128 */       float maxCompletedRowsHeight = 0.0F;
/* 2129 */       int i = 0;
/* 2130 */       ColumnMeasurementState state; int j; while (i < cols) {
/* 2131 */         PdfPCell cell = row.getCells()[i];
/* 2132 */         state = states[i];
/* 2133 */         if (cell == null) {
/* 2134 */           state.consumeRowspan(completedRowsHeight, rowHeight);
/*      */         } else {
/* 2136 */           state.beginCell(cell, completedRowsHeight, rowHeight);
/* 2137 */           this.LOGGER.info(String.format("Height after beginCell: %s (cell: %s)", new Object[] { Float.valueOf(state.height), Float.valueOf(cell.getCachedMaxHeight()) }));
/*      */         }
/* 2139 */         if ((state.cellEnds()) && (state.height > maxCompletedRowsHeight)) {
/* 2140 */           maxCompletedRowsHeight = state.height;
/*      */         }
/* 2142 */         for (j = 1; j < state.colspan; j++) {
/* 2143 */           states[(i + j)].height = state.height;
/*      */         }
/* 2145 */         i += state.colspan;
/*      */       }
/*      */       
/* 2148 */       float maxTotalHeight = 0.0F;
/* 2149 */       for (ColumnMeasurementState state : states) {
/* 2150 */         if (state.height > maxTotalHeight) {
/* 2151 */           maxTotalHeight = state.height;
/*      */         }
/*      */       }
/* 2154 */       row.setFinalMaxHeights(maxCompletedRowsHeight - completedRowsHeight);
/*      */       
/* 2156 */       float remainingHeight = availableHeight - (isSplitLate() ? maxTotalHeight : maxCompletedRowsHeight);
/* 2157 */       if (remainingHeight < 0.0F) {
/*      */         break;
/*      */       }
/* 2160 */       correctedHeightsForLastRow.put(Integer.valueOf(k), Float.valueOf(maxTotalHeight - completedRowsHeight));
/* 2161 */       completedRowsHeight = maxCompletedRowsHeight;
/* 2162 */       totalHeight = maxTotalHeight;
/*      */     }
/* 2164 */     this.rowsNotChecked = false;
/* 2165 */     return new FittingRows(startIdx, k - 1, totalHeight, completedRowsHeight, correctedHeightsForLastRow);
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfPTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */