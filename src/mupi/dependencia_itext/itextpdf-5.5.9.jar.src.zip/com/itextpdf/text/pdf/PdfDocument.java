/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.AccessibleElementId;
/*      */ import com.itextpdf.text.Anchor;
/*      */ import com.itextpdf.text.Annotation;
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.Chunk;
/*      */ import com.itextpdf.text.Document;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.Element;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Font;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.List;
/*      */ import com.itextpdf.text.ListItem;
/*      */ import com.itextpdf.text.ListLabel;
/*      */ import com.itextpdf.text.MarkedObject;
/*      */ import com.itextpdf.text.MarkedSection;
/*      */ import com.itextpdf.text.Meta;
/*      */ import com.itextpdf.text.Paragraph;
/*      */ import com.itextpdf.text.Phrase;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.Section;
/*      */ import com.itextpdf.text.TabSettings;
/*      */ import com.itextpdf.text.TabStop;
/*      */ import com.itextpdf.text.Version;
/*      */ import com.itextpdf.text.api.WriterOperation;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.io.TempFileCache;
/*      */ import com.itextpdf.text.io.TempFileCache.ObjectPosition;
/*      */ import com.itextpdf.text.pdf.collection.PdfCollection;
/*      */ import com.itextpdf.text.pdf.draw.DrawInterface;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import com.itextpdf.text.pdf.internal.PdfAnnotationsImp;
/*      */ import com.itextpdf.text.pdf.internal.PdfVersionImp;
/*      */ import com.itextpdf.text.pdf.internal.PdfViewerPreferencesImp;
/*      */ import java.io.IOException;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfDocument
/*      */   extends Document
/*      */ {
/*      */   protected PdfWriter writer;
/*      */   
/*      */   public static class PdfInfo
/*      */     extends PdfDictionary
/*      */   {
/*      */     PdfInfo()
/*      */     {
/*   97 */       addProducer();
/*   98 */       addCreationDate();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     PdfInfo(String author, String title, String subject)
/*      */     {
/*  110 */       this();
/*  111 */       addTitle(title);
/*  112 */       addSubject(subject);
/*  113 */       addAuthor(author);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addTitle(String title)
/*      */     {
/*  123 */       put(PdfName.TITLE, new PdfString(title, "UnicodeBig"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addSubject(String subject)
/*      */     {
/*  133 */       put(PdfName.SUBJECT, new PdfString(subject, "UnicodeBig"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addKeywords(String keywords)
/*      */     {
/*  143 */       put(PdfName.KEYWORDS, new PdfString(keywords, "UnicodeBig"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addAuthor(String author)
/*      */     {
/*  153 */       put(PdfName.AUTHOR, new PdfString(author, "UnicodeBig"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addCreator(String creator)
/*      */     {
/*  163 */       put(PdfName.CREATOR, new PdfString(creator, "UnicodeBig"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void addProducer()
/*      */     {
/*  171 */       put(PdfName.PRODUCER, new PdfString(Version.getInstance().getVersion()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void addCreationDate()
/*      */     {
/*  179 */       PdfString date = new PdfDate();
/*  180 */       put(PdfName.CREATIONDATE, date);
/*  181 */       put(PdfName.MODDATE, date);
/*      */     }
/*      */     
/*      */     void addkey(String key, String value) {
/*  185 */       if ((key.equals("Producer")) || (key.equals("CreationDate")))
/*  186 */         return;
/*  187 */       put(new PdfName(key), new PdfString(value, "UnicodeBig"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static class PdfCatalog
/*      */     extends PdfDictionary
/*      */   {
/*      */     PdfWriter writer;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     PdfCatalog(PdfIndirectReference pages, PdfWriter writer)
/*      */     {
/*  218 */       super();
/*  219 */       this.writer = writer;
/*  220 */       put(PdfName.PAGES, pages);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addNames(TreeMap<String, PdfDocument.Destination> localDestinations, HashMap<String, PdfObject> documentLevelJS, HashMap<String, PdfObject> documentFileAttachment, PdfWriter writer)
/*      */     {
/*  231 */       if ((localDestinations.isEmpty()) && (documentLevelJS.isEmpty()) && (documentFileAttachment.isEmpty()))
/*  232 */         return;
/*      */       try {
/*  234 */         PdfDictionary names = new PdfDictionary();
/*  235 */         if (!localDestinations.isEmpty()) {
/*  236 */           HashMap<String, PdfObject> destmap = new HashMap();
/*  237 */           for (Map.Entry<String, PdfDocument.Destination> entry : localDestinations.entrySet()) {
/*  238 */             String name = (String)entry.getKey();
/*  239 */             PdfDocument.Destination dest = (PdfDocument.Destination)entry.getValue();
/*  240 */             if (dest.destination != null)
/*      */             {
/*  242 */               destmap.put(name, dest.reference); }
/*      */           }
/*  244 */           if (destmap.size() > 0) {
/*  245 */             names.put(PdfName.DESTS, writer.addToBody(PdfNameTree.writeTree(destmap, writer)).getIndirectReference());
/*      */           }
/*      */         }
/*  248 */         if (!documentLevelJS.isEmpty()) {
/*  249 */           PdfDictionary tree = PdfNameTree.writeTree(documentLevelJS, writer);
/*  250 */           names.put(PdfName.JAVASCRIPT, writer.addToBody(tree).getIndirectReference());
/*      */         }
/*  252 */         if (!documentFileAttachment.isEmpty()) {
/*  253 */           names.put(PdfName.EMBEDDEDFILES, writer.addToBody(PdfNameTree.writeTree(documentFileAttachment, writer)).getIndirectReference());
/*      */         }
/*  255 */         if (names.size() > 0) {
/*  256 */           put(PdfName.NAMES, writer.addToBody(names).getIndirectReference());
/*      */         }
/*      */       } catch (IOException e) {
/*  259 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void setOpenAction(PdfAction action)
/*      */     {
/*  268 */       put(PdfName.OPENACTION, action);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void setAdditionalActions(PdfDictionary actions)
/*      */     {
/*      */       try
/*      */       {
/*  278 */         put(PdfName.AA, this.writer.addToBody(actions).getIndirectReference());
/*      */       } catch (Exception e) {
/*  280 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDocument()
/*      */   {
/*  292 */     addProducer();
/*  293 */     addCreationDate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  299 */   private HashMap<AccessibleElementId, PdfStructureElement> structElements = new HashMap();
/*      */   
/*      */   private TempFileCache externalCache;
/*      */   
/*  303 */   private HashMap<AccessibleElementId, TempFileCache.ObjectPosition> externallyStoredStructElements = new HashMap();
/*  304 */   private HashMap<AccessibleElementId, AccessibleElementId> elementsParents = new HashMap();
/*  305 */   private boolean isToUseExternalCache = false;
/*      */   
/*      */ 
/*  308 */   protected boolean openMCDocument = false;
/*      */   
/*  310 */   protected HashMap<Object, int[]> structParentIndices = new HashMap();
/*      */   
/*  312 */   protected HashMap<Object, Integer> markPoints = new HashMap();
/*      */   
/*      */   protected PdfContentByte text;
/*      */   
/*      */   protected PdfContentByte graphics;
/*      */   
/*      */ 
/*      */   public void addWriter(PdfWriter writer)
/*      */     throws DocumentException
/*      */   {
/*  322 */     if (this.writer == null) {
/*  323 */       this.writer = writer;
/*  324 */       this.annotationsImp = new PdfAnnotationsImp(writer);
/*  325 */       return;
/*      */     }
/*  327 */     throw new DocumentException(MessageLocalization.getComposedMessage("you.can.only.add.a.writer.to.a.pdfdocument.once", new Object[0]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  341 */   protected float leading = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getLeading()
/*      */   {
/*  349 */     return this.leading;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setLeading(float leading)
/*      */   {
/*  358 */     this.leading = leading;
/*      */   }
/*      */   
/*      */ 
/*  362 */   protected int alignment = 0;
/*      */   
/*      */ 
/*  365 */   protected float currentHeight = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  371 */   protected boolean isSectionTitle = false;
/*      */   
/*      */ 
/*  374 */   protected PdfAction anchorAction = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected TabSettings tabSettings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  388 */   private Stack<Float> leadingStack = new Stack();
/*      */   private PdfBody body;
/*      */   protected int textEmptySize;
/*      */   protected float nextMarginLeft;
/*      */   protected float nextMarginRight;
/*      */   protected float nextMarginTop;
/*      */   protected float nextMarginBottom;
/*      */   
/*  396 */   protected void pushLeading() { this.leadingStack.push(Float.valueOf(this.leading)); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void popLeading()
/*      */   {
/*  403 */     this.leading = ((Float)this.leadingStack.pop()).floatValue();
/*  404 */     if (this.leadingStack.size() > 0) {
/*  405 */       this.leading = ((Float)this.leadingStack.peek()).floatValue();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TabSettings getTabSettings()
/*      */   {
/*  413 */     return this.tabSettings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTabSettings(TabSettings tabSettings)
/*      */   {
/*  422 */     this.tabSettings = tabSettings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean add(Element element)
/*      */     throws DocumentException
/*      */   {
/*  434 */     if ((this.writer != null) && (this.writer.isPaused())) {
/*  435 */       return false;
/*      */     }
/*      */     try {
/*  438 */       if (element.type() != 37) {
/*  439 */         flushFloatingElements();
/*      */       }
/*      */       
/*  442 */       switch (element.type())
/*      */       {
/*      */       case 0: 
/*  445 */         this.info.addkey(((Meta)element).getName(), ((Meta)element).getContent());
/*  446 */         break;
/*      */       case 1: 
/*  448 */         this.info.addTitle(((Meta)element).getContent());
/*  449 */         break;
/*      */       case 2: 
/*  451 */         this.info.addSubject(((Meta)element).getContent());
/*  452 */         break;
/*      */       case 3: 
/*  454 */         this.info.addKeywords(((Meta)element).getContent());
/*  455 */         break;
/*      */       case 4: 
/*  457 */         this.info.addAuthor(((Meta)element).getContent());
/*  458 */         break;
/*      */       case 7: 
/*  460 */         this.info.addCreator(((Meta)element).getContent());
/*  461 */         break;
/*      */       case 8: 
/*  463 */         setLanguage(((Meta)element).getContent());
/*  464 */         break;
/*      */       
/*      */       case 5: 
/*  467 */         this.info.addProducer();
/*  468 */         break;
/*      */       
/*      */       case 6: 
/*  471 */         this.info.addCreationDate();
/*  472 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/*  476 */         if (this.line == null) {
/*  477 */           carriageReturn();
/*      */         }
/*      */         
/*      */ 
/*  481 */         PdfChunk chunk = new PdfChunk((Chunk)element, this.anchorAction, this.tabSettings);
/*      */         
/*      */         PdfChunk overflow;
/*      */         
/*  485 */         while ((overflow = this.line.add(chunk, this.leading)) != null) {
/*  486 */           carriageReturn();
/*  487 */           boolean newlineSplit = chunk.isNewlineSplit();
/*  488 */           chunk = overflow;
/*  489 */           if (!newlineSplit) {
/*  490 */             chunk.trimFirstSpace();
/*      */           }
/*      */         }
/*      */         
/*  494 */         this.pageEmpty = false;
/*      */         
/*  496 */         if (chunk.isAttribute("NEWPAGE")) {
/*  497 */           newPage();
/*      */         }
/*      */         
/*      */         break;
/*      */       case 17: 
/*  502 */         Anchor anchor = (Anchor)element;
/*  503 */         String url = anchor.getReference();
/*  504 */         this.leading = anchor.getLeading();
/*  505 */         pushLeading();
/*  506 */         if (url != null) {
/*  507 */           this.anchorAction = new PdfAction(url);
/*      */         }
/*      */         
/*  510 */         element.process(this);
/*  511 */         this.anchorAction = null;
/*  512 */         popLeading();
/*  513 */         break;
/*      */       
/*      */       case 29: 
/*  516 */         if (this.line == null) {
/*  517 */           carriageReturn();
/*      */         }
/*  519 */         Annotation annot = (Annotation)element;
/*  520 */         Rectangle rect = new Rectangle(0.0F, 0.0F);
/*  521 */         if (this.line != null)
/*  522 */           rect = new Rectangle(annot.llx(indentRight() - this.line.widthLeft()), annot.ury(indentTop() - this.currentHeight - 20.0F), annot.urx(indentRight() - this.line.widthLeft() + 20.0F), annot.lly(indentTop() - this.currentHeight));
/*  523 */         PdfAnnotation an = PdfAnnotationsImp.convertAnnotation(this.writer, annot, rect);
/*  524 */         this.annotationsImp.addPlainAnnotation(an);
/*  525 */         this.pageEmpty = false;
/*  526 */         break;
/*      */       
/*      */       case 11: 
/*  529 */         TabSettings backupTabSettings = this.tabSettings;
/*  530 */         if (((Phrase)element).getTabSettings() != null) {
/*  531 */           this.tabSettings = ((Phrase)element).getTabSettings();
/*      */         }
/*  533 */         this.leading = ((Phrase)element).getTotalLeading();
/*  534 */         pushLeading();
/*      */         
/*  536 */         element.process(this);
/*  537 */         this.tabSettings = backupTabSettings;
/*  538 */         popLeading();
/*  539 */         break;
/*      */       
/*      */       case 12: 
/*  542 */         TabSettings backupTabSettings = this.tabSettings;
/*  543 */         if (((Phrase)element).getTabSettings() != null) {
/*  544 */           this.tabSettings = ((Phrase)element).getTabSettings();
/*      */         }
/*  546 */         Paragraph paragraph = (Paragraph)element;
/*  547 */         if (isTagged(this.writer)) {
/*  548 */           flushLines();
/*  549 */           this.text.openMCBlock(paragraph);
/*      */         }
/*  551 */         addSpacing(paragraph.getSpacingBefore(), this.leading, paragraph.getFont());
/*      */         
/*      */ 
/*  554 */         this.alignment = paragraph.getAlignment();
/*  555 */         this.leading = paragraph.getTotalLeading();
/*  556 */         pushLeading();
/*  557 */         carriageReturn();
/*      */         
/*      */ 
/*  560 */         if (this.currentHeight + calculateLineHeight() > indentTop() - indentBottom()) {
/*  561 */           newPage();
/*      */         }
/*      */         
/*  564 */         this.indentation.indentLeft += paragraph.getIndentationLeft();
/*  565 */         this.indentation.indentRight += paragraph.getIndentationRight();
/*  566 */         carriageReturn();
/*      */         
/*  568 */         PdfPageEvent pageEvent = this.writer.getPageEvent();
/*  569 */         if ((pageEvent != null) && (!this.isSectionTitle)) {
/*  570 */           pageEvent.onParagraph(this.writer, this, indentTop() - this.currentHeight);
/*      */         }
/*      */         
/*  573 */         if (paragraph.getKeepTogether()) {
/*  574 */           carriageReturn();
/*  575 */           PdfPTable table = new PdfPTable(1);
/*  576 */           table.setKeepTogether(paragraph.getKeepTogether());
/*  577 */           table.setWidthPercentage(100.0F);
/*  578 */           PdfPCell cell = new PdfPCell();
/*  579 */           cell.addElement(paragraph);
/*  580 */           cell.setBorder(0);
/*  581 */           cell.setPadding(0.0F);
/*  582 */           table.addCell(cell);
/*  583 */           this.indentation.indentLeft -= paragraph.getIndentationLeft();
/*  584 */           this.indentation.indentRight -= paragraph.getIndentationRight();
/*  585 */           add(table);
/*  586 */           this.indentation.indentLeft += paragraph.getIndentationLeft();
/*  587 */           this.indentation.indentRight += paragraph.getIndentationRight();
/*      */         }
/*      */         else {
/*  590 */           this.line.setExtraIndent(paragraph.getFirstLineIndent());
/*  591 */           float oldHeight = this.currentHeight;
/*  592 */           element.process(this);
/*  593 */           carriageReturn();
/*  594 */           if ((oldHeight != this.currentHeight) || (this.lines.size() > 0)) {
/*  595 */             addSpacing(paragraph.getSpacingAfter(), paragraph.getTotalLeading(), paragraph.getFont(), true);
/*      */           }
/*      */         }
/*      */         
/*  599 */         if ((pageEvent != null) && (!this.isSectionTitle)) {
/*  600 */           pageEvent.onParagraphEnd(this.writer, this, indentTop() - this.currentHeight);
/*      */         }
/*  602 */         this.alignment = 0;
/*  603 */         if ((this.floatingElements != null) && (this.floatingElements.size() != 0)) {
/*  604 */           flushFloatingElements();
/*      */         }
/*  606 */         this.indentation.indentLeft -= paragraph.getIndentationLeft();
/*  607 */         this.indentation.indentRight -= paragraph.getIndentationRight();
/*  608 */         carriageReturn();
/*  609 */         this.tabSettings = backupTabSettings;
/*  610 */         popLeading();
/*  611 */         if (isTagged(this.writer)) {
/*  612 */           flushLines();
/*  613 */           this.text.closeMCBlock(paragraph);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 13: 
/*      */       case 16: 
/*  621 */         Section section = (Section)element;
/*  622 */         PdfPageEvent pageEvent = this.writer.getPageEvent();
/*      */         
/*      */ 
/*  625 */         boolean hasTitle = (section.isNotAddedYet()) && (section.getTitle() != null);
/*      */         
/*      */ 
/*  628 */         if (section.isTriggerNewPage()) {
/*  629 */           newPage();
/*      */         }
/*      */         
/*  632 */         if (hasTitle) {
/*  633 */           float fith = indentTop() - this.currentHeight;
/*  634 */           int rotation = this.pageSize.getRotation();
/*  635 */           if ((rotation == 90) || (rotation == 180))
/*  636 */             fith = this.pageSize.getHeight() - fith;
/*  637 */           PdfDestination destination = new PdfDestination(2, fith);
/*  638 */           while (this.currentOutline.level() >= section.getDepth()) {
/*  639 */             this.currentOutline = this.currentOutline.parent();
/*      */           }
/*  641 */           PdfOutline outline = new PdfOutline(this.currentOutline, destination, section.getBookmarkTitle(), section.isBookmarkOpen());
/*  642 */           this.currentOutline = outline;
/*      */         }
/*      */         
/*      */ 
/*  646 */         carriageReturn();
/*  647 */         this.indentation.sectionIndentLeft += section.getIndentationLeft();
/*  648 */         this.indentation.sectionIndentRight += section.getIndentationRight();
/*      */         
/*  650 */         if ((section.isNotAddedYet()) && (pageEvent != null)) {
/*  651 */           if (element.type() == 16) {
/*  652 */             pageEvent.onChapter(this.writer, this, indentTop() - this.currentHeight, section.getTitle());
/*      */           } else {
/*  654 */             pageEvent.onSection(this.writer, this, indentTop() - this.currentHeight, section.getDepth(), section.getTitle());
/*      */           }
/*      */         }
/*  657 */         if (hasTitle) {
/*  658 */           this.isSectionTitle = true;
/*  659 */           add(section.getTitle());
/*  660 */           this.isSectionTitle = false;
/*      */         }
/*  662 */         this.indentation.sectionIndentLeft += section.getIndentation();
/*      */         
/*  664 */         element.process(this);
/*  665 */         flushLines();
/*      */         
/*  667 */         this.indentation.sectionIndentLeft -= section.getIndentationLeft() + section.getIndentation();
/*  668 */         this.indentation.sectionIndentRight -= section.getIndentationRight();
/*      */         
/*  670 */         if ((section.isComplete()) && (pageEvent != null)) {
/*  671 */           if (element.type() == 16) {
/*  672 */             pageEvent.onChapterEnd(this.writer, this, indentTop() - this.currentHeight);
/*      */           } else {
/*  674 */             pageEvent.onSectionEnd(this.writer, this, indentTop() - this.currentHeight);
/*      */           }
/*      */         }
/*      */         
/*      */         break;
/*      */       case 14: 
/*  680 */         List list = (List)element;
/*  681 */         if (isTagged(this.writer)) {
/*  682 */           flushLines();
/*  683 */           this.text.openMCBlock(list);
/*      */         }
/*  685 */         if (list.isAlignindent()) {
/*  686 */           list.normalizeIndentation();
/*      */         }
/*      */         
/*  689 */         this.indentation.listIndentLeft += list.getIndentationLeft();
/*  690 */         this.indentation.indentRight += list.getIndentationRight();
/*      */         
/*  692 */         element.process(this);
/*      */         
/*      */ 
/*  695 */         this.indentation.listIndentLeft -= list.getIndentationLeft();
/*  696 */         this.indentation.indentRight -= list.getIndentationRight();
/*  697 */         carriageReturn();
/*  698 */         if (isTagged(this.writer)) {
/*  699 */           flushLines();
/*  700 */           this.text.closeMCBlock(list);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 15: 
/*  706 */         ListItem listItem = (ListItem)element;
/*  707 */         if (isTagged(this.writer)) {
/*  708 */           flushLines();
/*  709 */           this.text.openMCBlock(listItem);
/*      */         }
/*      */         
/*  712 */         addSpacing(listItem.getSpacingBefore(), this.leading, listItem.getFont());
/*      */         
/*      */ 
/*  715 */         this.alignment = listItem.getAlignment();
/*  716 */         this.indentation.listIndentLeft += listItem.getIndentationLeft();
/*  717 */         this.indentation.indentRight += listItem.getIndentationRight();
/*  718 */         this.leading = listItem.getTotalLeading();
/*  719 */         pushLeading();
/*  720 */         carriageReturn();
/*      */         
/*      */ 
/*  723 */         this.line.setListItem(listItem);
/*      */         
/*  725 */         element.process(this);
/*  726 */         addSpacing(listItem.getSpacingAfter(), listItem.getTotalLeading(), listItem.getFont(), true);
/*      */         
/*      */ 
/*  729 */         if (this.line.hasToBeJustified()) {
/*  730 */           this.line.resetAlignment();
/*      */         }
/*      */         
/*  733 */         carriageReturn();
/*  734 */         this.indentation.listIndentLeft -= listItem.getIndentationLeft();
/*  735 */         this.indentation.indentRight -= listItem.getIndentationRight();
/*  736 */         popLeading();
/*  737 */         if (isTagged(this.writer)) {
/*  738 */           flushLines();
/*  739 */           this.text.closeMCBlock(listItem.getListBody());
/*  740 */           this.text.closeMCBlock(listItem);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 30: 
/*  745 */         Rectangle rectangle = (Rectangle)element;
/*  746 */         this.graphics.rectangle(rectangle);
/*  747 */         this.pageEmpty = false;
/*  748 */         break;
/*      */       
/*      */       case 23: 
/*  751 */         PdfPTable ptable = (PdfPTable)element;
/*  752 */         if (ptable.size() > ptable.getHeaderRows())
/*      */         {
/*      */ 
/*      */ 
/*  756 */           ensureNewLine();
/*  757 */           flushLines();
/*      */           
/*  759 */           addPTable(ptable);
/*  760 */           this.pageEmpty = false;
/*  761 */           newLine(); }
/*  762 */         break;
/*      */       
/*      */ 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 34: 
/*      */       case 35: 
/*      */       case 36: 
/*  770 */         if ((isTagged(this.writer)) && (!((Image)element).isImgTemplate())) {
/*  771 */           flushLines();
/*  772 */           this.text.openMCBlock((Image)element);
/*      */         }
/*  774 */         add((Image)element);
/*  775 */         if ((isTagged(this.writer)) && (!((Image)element).isImgTemplate())) {
/*  776 */           flushLines();
/*  777 */           this.text.closeMCBlock((Image)element);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 55: 
/*  782 */         DrawInterface zh = (DrawInterface)element;
/*  783 */         zh.draw(this.graphics, indentLeft(), indentBottom(), indentRight(), indentTop(), indentTop() - this.currentHeight - (this.leadingStack.size() > 0 ? this.leading : 0.0F));
/*  784 */         this.pageEmpty = false;
/*  785 */         break;
/*      */       
/*      */ 
/*      */       case 50: 
/*  789 */         if ((element instanceof MarkedSection)) {
/*  790 */           MarkedObject mo = ((MarkedSection)element).getTitle();
/*  791 */           if (mo != null) {
/*  792 */             mo.process(this);
/*      */           }
/*      */         }
/*  795 */         MarkedObject mo = (MarkedObject)element;
/*  796 */         mo.process(this);
/*  797 */         break;
/*      */       
/*      */       case 666: 
/*  800 */         if (null != this.writer) {
/*  801 */           ((WriterOperation)element).write(this.writer, this);
/*      */         }
/*      */         break;
/*      */       case 37: 
/*  805 */         ensureNewLine();
/*  806 */         flushLines();
/*  807 */         addDiv((PdfDiv)element);
/*  808 */         this.pageEmpty = false;
/*      */         
/*  810 */         break;
/*      */       case 38: 
/*  812 */         this.body = ((PdfBody)element);
/*  813 */         this.graphics.rectangle(this.body);
/*      */       default: 
/*  815 */         return false;
/*      */       }
/*  817 */       this.lastElementType = element.type();
/*  818 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/*  821 */       throw new DocumentException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void open()
/*      */   {
/*  835 */     if (!this.open) {
/*  836 */       super.open();
/*  837 */       this.writer.open();
/*  838 */       this.rootOutline = new PdfOutline(this.writer);
/*  839 */       this.currentOutline = this.rootOutline;
/*      */     }
/*      */     try {
/*  842 */       if (isTagged(this.writer)) {
/*  843 */         this.openMCDocument = true;
/*      */       }
/*  845 */       initPage();
/*      */     }
/*      */     catch (DocumentException de) {
/*  848 */       throw new ExceptionConverter(de);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/*  862 */     if (this.close) {
/*  863 */       return;
/*      */     }
/*      */     try {
/*  866 */       if (isTagged(this.writer)) {
/*  867 */         flushFloatingElements();
/*  868 */         flushLines();
/*  869 */         this.writer.flushAcroFields();
/*  870 */         this.writer.flushTaggedObjects();
/*  871 */         if (isPageEmpty()) {
/*  872 */           int pageReferenceCount = this.writer.pageReferences.size();
/*  873 */           if ((pageReferenceCount > 0) && (this.writer.currentPageNumber == pageReferenceCount)) {
/*  874 */             this.writer.pageReferences.remove(pageReferenceCount - 1);
/*      */           }
/*      */         }
/*      */       } else {
/*  878 */         this.writer.flushAcroFields(); }
/*  879 */       if (this.imageWait != null) {
/*  880 */         newPage();
/*      */       }
/*  882 */       endPage();
/*  883 */       if (isTagged(this.writer)) {
/*  884 */         this.writer.getDirectContent().closeMCBlock(this);
/*      */       }
/*  886 */       if (this.annotationsImp.hasUnusedAnnotations())
/*  887 */         throw new RuntimeException(MessageLocalization.getComposedMessage("not.all.annotations.could.be.added.to.the.document.the.document.doesn.t.have.enough.pages", new Object[0]));
/*  888 */       PdfPageEvent pageEvent = this.writer.getPageEvent();
/*  889 */       if (pageEvent != null)
/*  890 */         pageEvent.onCloseDocument(this.writer, this);
/*  891 */       super.close();
/*      */       
/*  893 */       this.writer.addLocalDestinations(this.localDestinations);
/*  894 */       calculateOutlineCount();
/*  895 */       writeOutlines();
/*      */     }
/*      */     catch (Exception e) {
/*  898 */       throw ExceptionConverter.convertException(e);
/*      */     }
/*      */     
/*  901 */     this.writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXmpMetadata(byte[] xmpMetadata)
/*      */     throws IOException
/*      */   {
/*  914 */     PdfStream xmp = new PdfStream(xmpMetadata);
/*  915 */     xmp.put(PdfName.TYPE, PdfName.METADATA);
/*  916 */     xmp.put(PdfName.SUBTYPE, PdfName.XML);
/*  917 */     PdfEncryption crypto = this.writer.getEncryption();
/*  918 */     if ((crypto != null) && (!crypto.isMetadataEncrypted())) {
/*  919 */       PdfArray ar = new PdfArray();
/*  920 */       ar.add(PdfName.CRYPT);
/*  921 */       xmp.put(PdfName.FILTER, ar);
/*      */     }
/*  923 */     this.writer.addPageDictEntry(PdfName.METADATA, this.writer.addToBody(xmp).getIndirectReference());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean newPage()
/*      */   {
/*  933 */     if (isPageEmpty()) {
/*  934 */       setNewPageSizeAndMargins();
/*  935 */       return false;
/*      */     }
/*  937 */     if ((!this.open) || (this.close)) {
/*  938 */       throw new RuntimeException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[0]));
/*      */     }
/*      */     
/*      */ 
/*  942 */     ArrayList<IAccessibleElement> savedMcBlocks = endPage();
/*      */     
/*      */ 
/*  945 */     super.newPage();
/*      */     
/*      */ 
/*  948 */     this.indentation.imageIndentLeft = 0.0F;
/*  949 */     this.indentation.imageIndentRight = 0.0F;
/*      */     try
/*      */     {
/*  952 */       if (isTagged(this.writer)) {
/*  953 */         flushStructureElementsOnNewPage();
/*  954 */         this.writer.getDirectContentUnder().restoreMCBlocks(savedMcBlocks);
/*      */       }
/*      */       
/*      */ 
/*  958 */       initPage();
/*      */       
/*  960 */       if ((this.body != null) && (this.body.getBackgroundColor() != null)) {
/*  961 */         this.graphics.rectangle(this.body);
/*      */       }
/*      */     }
/*      */     catch (DocumentException de)
/*      */     {
/*  966 */       throw new ExceptionConverter(de);
/*      */     }
/*  968 */     return true;
/*      */   }
/*      */   
/*      */   protected ArrayList<IAccessibleElement> endPage() {
/*  972 */     if (isPageEmpty()) {
/*  973 */       return null;
/*      */     }
/*      */     
/*  976 */     ArrayList<IAccessibleElement> savedMcBlocks = null;
/*      */     try
/*      */     {
/*  979 */       flushFloatingElements();
/*      */     }
/*      */     catch (DocumentException de) {
/*  982 */       throw new ExceptionConverter(de);
/*      */     }
/*  984 */     this.lastElementType = -1;
/*      */     
/*  986 */     PdfPageEvent pageEvent = this.writer.getPageEvent();
/*  987 */     if (pageEvent != null) {
/*  988 */       pageEvent.onEndPage(this.writer, this);
/*      */     }
/*      */     try
/*      */     {
/*  992 */       flushLines();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  997 */       int rotation = this.pageSize.getRotation();
/*      */       
/*      */ 
/* 1000 */       if (this.writer.isPdfIso()) {
/* 1001 */         if ((this.thisBoxSize.containsKey("art")) && (this.thisBoxSize.containsKey("trim")))
/* 1002 */           throw new PdfXConformanceException(MessageLocalization.getComposedMessage("only.one.of.artbox.or.trimbox.can.exist.in.the.page", new Object[0]));
/* 1003 */         if ((!this.thisBoxSize.containsKey("art")) && (!this.thisBoxSize.containsKey("trim"))) {
/* 1004 */           if (this.thisBoxSize.containsKey("crop")) {
/* 1005 */             this.thisBoxSize.put("trim", this.thisBoxSize.get("crop"));
/*      */           } else {
/* 1007 */             this.thisBoxSize.put("trim", new PdfRectangle(this.pageSize, this.pageSize.getRotation()));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1012 */       this.pageResources.addDefaultColorDiff(this.writer.getDefaultColorspace());
/* 1013 */       if (this.writer.isRgbTransparencyBlending()) {
/* 1014 */         PdfDictionary dcs = new PdfDictionary();
/* 1015 */         dcs.put(PdfName.CS, PdfName.DEVICERGB);
/* 1016 */         this.pageResources.addDefaultColorDiff(dcs);
/*      */       }
/* 1018 */       PdfDictionary resources = this.pageResources.getResources();
/*      */       
/*      */ 
/*      */ 
/* 1022 */       PdfPage page = new PdfPage(new PdfRectangle(this.pageSize, rotation), this.thisBoxSize, resources, rotation);
/* 1023 */       if (isTagged(this.writer)) {
/* 1024 */         page.put(PdfName.TABS, PdfName.S);
/*      */       } else {
/* 1026 */         page.put(PdfName.TABS, this.writer.getTabs());
/*      */       }
/* 1028 */       page.putAll(this.writer.getPageDictEntries());
/* 1029 */       this.writer.resetPageDictEntries();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1034 */       if (this.pageAA != null) {
/* 1035 */         page.put(PdfName.AA, this.writer.addToBody(this.pageAA).getIndirectReference());
/* 1036 */         this.pageAA = null;
/*      */       }
/*      */       
/*      */ 
/* 1040 */       if (this.annotationsImp.hasUnusedAnnotations()) {
/* 1041 */         PdfArray array = this.annotationsImp.rotateAnnotations(this.writer, this.pageSize);
/* 1042 */         if (array.size() != 0) {
/* 1043 */           page.put(PdfName.ANNOTS, array);
/*      */         }
/*      */       }
/*      */       
/* 1047 */       if (isTagged(this.writer)) {
/* 1048 */         page.put(PdfName.STRUCTPARENTS, new PdfNumber(getStructParentIndex(this.writer.getCurrentPage())));
/*      */       }
/* 1050 */       if ((this.text.size() > this.textEmptySize) || (isTagged(this.writer))) {
/* 1051 */         this.text.endText();
/*      */       } else {
/* 1053 */         this.text = null;
/*      */       }
/* 1055 */       if (isTagged(this.writer)) {
/* 1056 */         savedMcBlocks = this.writer.getDirectContent().saveMCBlocks();
/*      */       }
/* 1058 */       this.writer.add(page, new PdfContents(this.writer.getDirectContentUnder(), this.graphics, !isTagged(this.writer) ? this.text : null, this.writer.getDirectContent(), this.pageSize));
/*      */       
/* 1060 */       this.annotationsImp.resetAnnotations();
/* 1061 */       this.writer.resetContent();
/*      */     }
/*      */     catch (DocumentException de)
/*      */     {
/* 1065 */       throw new ExceptionConverter(de);
/*      */     }
/*      */     catch (IOException ioe) {
/* 1068 */       throw new ExceptionConverter(ioe);
/*      */     }
/*      */     
/* 1071 */     return savedMcBlocks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setPageSize(Rectangle pageSize)
/*      */   {
/* 1083 */     if ((this.writer != null) && (this.writer.isPaused())) {
/* 1084 */       return false;
/*      */     }
/* 1086 */     this.nextPageSize = new Rectangle(pageSize);
/* 1087 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setMargins(float marginLeft, float marginRight, float marginTop, float marginBottom)
/*      */   {
/* 1115 */     if ((this.writer != null) && (this.writer.isPaused())) {
/* 1116 */       return false;
/*      */     }
/* 1118 */     this.nextMarginLeft = marginLeft;
/* 1119 */     this.nextMarginRight = marginRight;
/* 1120 */     this.nextMarginTop = marginTop;
/* 1121 */     this.nextMarginBottom = marginBottom;
/* 1122 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setMarginMirroring(boolean MarginMirroring)
/*      */   {
/* 1132 */     if ((this.writer != null) && (this.writer.isPaused())) {
/* 1133 */       return false;
/*      */     }
/* 1135 */     return super.setMarginMirroring(MarginMirroring);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setMarginMirroringTopBottom(boolean MarginMirroringTopBottom)
/*      */   {
/* 1144 */     if ((this.writer != null) && (this.writer.isPaused())) {
/* 1145 */       return false;
/*      */     }
/* 1147 */     return super.setMarginMirroringTopBottom(MarginMirroringTopBottom);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageCount(int pageN)
/*      */   {
/* 1159 */     if ((this.writer != null) && (this.writer.isPaused())) {
/* 1160 */       return;
/*      */     }
/* 1162 */     super.setPageCount(pageN);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetPageCount()
/*      */   {
/* 1172 */     if ((this.writer != null) && (this.writer.isPaused())) {
/* 1173 */       return;
/*      */     }
/* 1175 */     super.resetPageCount();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1181 */   protected boolean firstPageEvent = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initPage()
/*      */     throws DocumentException
/*      */   {
/* 1191 */     this.pageN += 1;
/*      */     
/*      */ 
/* 1194 */     this.pageResources = new PageResources();
/*      */     
/* 1196 */     if (isTagged(this.writer)) {
/* 1197 */       this.graphics = this.writer.getDirectContentUnder().getDuplicate();
/* 1198 */       this.writer.getDirectContent().duplicatedFrom = this.graphics;
/*      */     } else {
/* 1200 */       this.graphics = new PdfContentByte(this.writer);
/*      */     }
/*      */     
/* 1203 */     setNewPageSizeAndMargins();
/* 1204 */     this.imageEnd = -1.0F;
/* 1205 */     this.indentation.imageIndentRight = 0.0F;
/* 1206 */     this.indentation.imageIndentLeft = 0.0F;
/* 1207 */     this.indentation.indentBottom = 0.0F;
/* 1208 */     this.indentation.indentTop = 0.0F;
/* 1209 */     this.currentHeight = 0.0F;
/*      */     
/*      */ 
/* 1212 */     this.thisBoxSize = new HashMap(this.boxSize);
/* 1213 */     if ((this.pageSize.getBackgroundColor() != null) || 
/* 1214 */       (this.pageSize.hasBorders()) || 
/* 1215 */       (this.pageSize.getBorderColor() != null)) {
/* 1216 */       add(this.pageSize);
/*      */     }
/*      */     
/* 1219 */     float oldleading = this.leading;
/* 1220 */     int oldAlignment = this.alignment;
/* 1221 */     this.pageEmpty = true;
/*      */     try
/*      */     {
/* 1224 */       if (this.imageWait != null) {
/* 1225 */         add(this.imageWait);
/* 1226 */         this.imageWait = null;
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1230 */       throw new ExceptionConverter(e);
/*      */     }
/* 1232 */     this.leading = oldleading;
/* 1233 */     this.alignment = oldAlignment;
/* 1234 */     carriageReturn();
/*      */     
/* 1236 */     PdfPageEvent pageEvent = this.writer.getPageEvent();
/* 1237 */     if (pageEvent != null) {
/* 1238 */       if (this.firstPageEvent) {
/* 1239 */         pageEvent.onOpenDocument(this.writer, this);
/*      */       }
/* 1241 */       pageEvent.onStartPage(this.writer, this);
/*      */     }
/* 1243 */     this.firstPageEvent = false;
/*      */   }
/*      */   
/*      */ 
/* 1247 */   protected PdfLine line = null;
/*      */   
/* 1249 */   protected ArrayList<PdfLine> lines = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */   protected void newLine()
/*      */     throws DocumentException
/*      */   {
/* 1256 */     this.lastElementType = -1;
/* 1257 */     carriageReturn();
/* 1258 */     if ((this.lines != null) && (!this.lines.isEmpty())) {
/* 1259 */       this.lines.add(this.line);
/* 1260 */       this.currentHeight += this.line.height();
/*      */     }
/* 1262 */     this.line = new PdfLine(indentLeft(), indentRight(), this.alignment, this.leading);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float calculateLineHeight()
/*      */   {
/* 1273 */     float tempHeight = this.line.height();
/*      */     
/* 1275 */     if (tempHeight != this.leading) {
/* 1276 */       tempHeight += this.leading;
/*      */     }
/*      */     
/* 1279 */     return tempHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void carriageReturn()
/*      */   {
/* 1288 */     if (this.lines == null) {
/* 1289 */       this.lines = new ArrayList();
/*      */     }
/*      */     
/* 1292 */     if ((this.line != null) && (this.line.size() > 0))
/*      */     {
/* 1294 */       if (this.currentHeight + calculateLineHeight() > indentTop() - indentBottom())
/*      */       {
/*      */ 
/*      */ 
/* 1298 */         if (this.currentHeight != 0.0F) {
/* 1299 */           PdfLine overflowLine = this.line;
/* 1300 */           this.line = null;
/* 1301 */           newPage();
/* 1302 */           this.line = overflowLine;
/*      */           
/* 1304 */           overflowLine.left = indentLeft();
/*      */         }
/*      */       }
/* 1307 */       this.currentHeight += this.line.height();
/* 1308 */       this.lines.add(this.line);
/* 1309 */       this.pageEmpty = false;
/*      */     }
/* 1311 */     if ((this.imageEnd > -1.0F) && (this.currentHeight > this.imageEnd)) {
/* 1312 */       this.imageEnd = -1.0F;
/* 1313 */       this.indentation.imageIndentRight = 0.0F;
/* 1314 */       this.indentation.imageIndentLeft = 0.0F;
/*      */     }
/*      */     
/* 1317 */     this.line = new PdfLine(indentLeft(), indentRight(), this.alignment, this.leading);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getVerticalPosition(boolean ensureNewLine)
/*      */   {
/* 1329 */     if (ensureNewLine) {
/* 1330 */       ensureNewLine();
/*      */     }
/* 1332 */     return top() - this.currentHeight - this.indentation.indentTop;
/*      */   }
/*      */   
/*      */ 
/* 1336 */   protected int lastElementType = -1;
/*      */   static final String hangingPunctuation = ".,;:'";
/*      */   
/*      */   protected void ensureNewLine()
/*      */   {
/*      */     try
/*      */     {
/* 1343 */       if ((this.lastElementType == 11) || (this.lastElementType == 10))
/*      */       {
/* 1345 */         newLine();
/* 1346 */         flushLines();
/*      */       }
/*      */     } catch (DocumentException ex) {
/* 1349 */       throw new ExceptionConverter(ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float flushLines()
/*      */     throws DocumentException
/*      */   {
/* 1361 */     if (this.lines == null) {
/* 1362 */       return 0.0F;
/*      */     }
/*      */     
/* 1365 */     if ((this.line != null) && (this.line.size() > 0)) {
/* 1366 */       this.lines.add(this.line);
/* 1367 */       this.line = new PdfLine(indentLeft(), indentRight(), this.alignment, this.leading);
/*      */     }
/*      */     
/*      */ 
/* 1371 */     if (this.lines.isEmpty()) {
/* 1372 */       return 0.0F;
/*      */     }
/*      */     
/*      */ 
/* 1376 */     Object[] currentValues = new Object[2];
/* 1377 */     PdfFont currentFont = null;
/* 1378 */     float displacement = 0.0F;
/* 1379 */     Float lastBaseFactor = new Float(0.0F);
/* 1380 */     currentValues[1] = lastBaseFactor;
/*      */     
/* 1382 */     for (PdfLine l : this.lines) {
/* 1383 */       float moveTextX = l.indentLeft() - indentLeft() + this.indentation.indentLeft + this.indentation.listIndentLeft + this.indentation.sectionIndentLeft;
/* 1384 */       this.text.moveText(moveTextX, -l.height());
/*      */       
/* 1386 */       l.flush();
/*      */       
/* 1388 */       if (l.listSymbol() != null) {
/* 1389 */         ListLabel lbl = null;
/* 1390 */         Chunk symbol = l.listSymbol();
/* 1391 */         if (isTagged(this.writer)) {
/* 1392 */           lbl = l.listItem().getListLabel();
/* 1393 */           this.graphics.openMCBlock(lbl);
/* 1394 */           symbol = new Chunk(symbol);
/* 1395 */           symbol.setRole(null);
/*      */         }
/* 1397 */         ColumnText.showTextAligned(this.graphics, 0, new Phrase(symbol), this.text.getXTLM() - l.listIndent(), this.text.getYTLM(), 0.0F);
/* 1398 */         if (lbl != null) {
/* 1399 */           this.graphics.closeMCBlock(lbl);
/*      */         }
/*      */       }
/*      */       
/* 1403 */       currentValues[0] = currentFont;
/*      */       
/* 1405 */       if ((isTagged(this.writer)) && (l.listItem() != null)) {
/* 1406 */         this.text.openMCBlock(l.listItem().getListBody());
/*      */       }
/* 1408 */       writeLineToContent(l, this.text, this.graphics, currentValues, this.writer.getSpaceCharRatio());
/*      */       
/* 1410 */       currentFont = (PdfFont)currentValues[0];
/* 1411 */       displacement += l.height();
/* 1412 */       this.text.moveText(-moveTextX, 0.0F);
/*      */     }
/*      */     
/* 1415 */     this.lines = new ArrayList();
/* 1416 */     return displacement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   float writeLineToContent(PdfLine line, PdfContentByte text, PdfContentByte graphics, Object[] currentValues, float ratio)
/*      */     throws DocumentException
/*      */   {
/* 1436 */     PdfFont currentFont = (PdfFont)currentValues[0];
/* 1437 */     float lastBaseFactor = ((Float)currentValues[1]).floatValue();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1442 */     float hangingCorrection = 0.0F;
/* 1443 */     float hScale = 1.0F;
/* 1444 */     float lastHScale = NaN.0F;
/* 1445 */     float baseWordSpacing = 0.0F;
/* 1446 */     float baseCharacterSpacing = 0.0F;
/* 1447 */     float glueWidth = 0.0F;
/* 1448 */     float lastX = text.getXTLM() + line.getOriginalWidth();
/* 1449 */     int numberOfSpaces = line.numberOfSpaces();
/* 1450 */     int lineLen = line.getLineLengthUtf32();
/*      */     
/* 1452 */     boolean isJustified = (line.hasToBeJustified()) && ((numberOfSpaces != 0) || (lineLen > 1));
/* 1453 */     int separatorCount = line.getSeparatorCount();
/* 1454 */     if (separatorCount > 0) {
/* 1455 */       glueWidth = line.widthLeft() / separatorCount;
/*      */     }
/* 1457 */     else if ((isJustified) && (separatorCount == 0)) {
/* 1458 */       if ((line.isNewlineSplit()) && (line.widthLeft() >= lastBaseFactor * (ratio * numberOfSpaces + lineLen - 1.0F))) {
/* 1459 */         if (line.isRTL()) {
/* 1460 */           text.moveText(line.widthLeft() - lastBaseFactor * (ratio * numberOfSpaces + lineLen - 1.0F), 0.0F);
/*      */         }
/* 1462 */         baseWordSpacing = ratio * lastBaseFactor;
/* 1463 */         baseCharacterSpacing = lastBaseFactor;
/*      */       }
/*      */       else {
/* 1466 */         float width = line.widthLeft();
/* 1467 */         PdfChunk last = line.getChunk(line.size() - 1);
/* 1468 */         if (last != null) {
/* 1469 */           String s = last.toString();
/*      */           char c;
/* 1471 */           if ((s.length() > 0) && (".,;:'".indexOf(c = s.charAt(s.length() - 1)) >= 0)) {
/* 1472 */             float oldWidth = width;
/* 1473 */             width += last.font().width(c) * 0.4F;
/* 1474 */             hangingCorrection = width - oldWidth;
/*      */           }
/*      */         }
/* 1477 */         float baseFactor = width / (ratio * numberOfSpaces + lineLen - 1.0F);
/* 1478 */         baseWordSpacing = ratio * baseFactor;
/* 1479 */         baseCharacterSpacing = baseFactor;
/* 1480 */         lastBaseFactor = baseFactor;
/*      */       }
/* 1482 */     } else if ((line.alignment == 0) || (line.alignment == -1)) {
/* 1483 */       lastX -= line.widthLeft();
/*      */     }
/*      */     
/* 1486 */     int lastChunkStroke = line.getLastStrokeChunk();
/* 1487 */     int chunkStrokeIdx = 0;
/* 1488 */     float xMarker = text.getXTLM();
/* 1489 */     float baseXMarker = xMarker;
/* 1490 */     float yMarker = text.getYTLM();
/* 1491 */     boolean adjustMatrix = false;
/* 1492 */     float tabPosition = 0.0F;
/* 1493 */     boolean isMCBlockOpened = false;
/*      */     
/* 1495 */     for (Iterator<PdfChunk> j = line.iterator(); j.hasNext();) {
/* 1496 */       PdfChunk chunk = (PdfChunk)j.next();
/* 1497 */       if ((isTagged(this.writer)) && (chunk.accessibleElement != null)) {
/* 1498 */         text.openMCBlock(chunk.accessibleElement);
/* 1499 */         isMCBlockOpened = true;
/*      */       }
/* 1501 */       BaseColor color = chunk.color();
/* 1502 */       float fontSize = chunk.font().size();
/*      */       float descender;
/*      */       float ascender;
/* 1505 */       float descender; if (chunk.isImage()) {
/* 1506 */         float ascender = chunk.height();
/* 1507 */         fontSize = chunk.height();
/* 1508 */         descender = 0.0F;
/*      */       } else {
/* 1510 */         ascender = chunk.font().getFont().getFontDescriptor(1, fontSize);
/* 1511 */         descender = chunk.font().getFont().getFontDescriptor(3, fontSize);
/*      */       }
/* 1513 */       hScale = 1.0F;
/*      */       
/* 1515 */       if (chunkStrokeIdx <= lastChunkStroke) { float width;
/*      */         float width;
/* 1517 */         if (isJustified) {
/* 1518 */           width = chunk.getWidthCorrected(baseCharacterSpacing, baseWordSpacing);
/*      */         }
/*      */         else {
/* 1521 */           width = chunk.width();
/*      */         }
/* 1523 */         if (chunk.isStroked()) {
/* 1524 */           PdfChunk nextChunk = line.getChunk(chunkStrokeIdx + 1);
/* 1525 */           if (chunk.isSeparator()) {
/* 1526 */             width = glueWidth;
/* 1527 */             Object[] sep = (Object[])chunk.getAttribute("SEPARATOR");
/* 1528 */             DrawInterface di = (DrawInterface)sep[0];
/* 1529 */             Boolean vertical = (Boolean)sep[1];
/* 1530 */             if (vertical.booleanValue()) {
/* 1531 */               di.draw(graphics, baseXMarker, yMarker + descender, baseXMarker + line.getOriginalWidth(), ascender - descender, yMarker);
/*      */             }
/*      */             else {
/* 1534 */               di.draw(graphics, xMarker, yMarker + descender, xMarker + width, ascender - descender, yMarker);
/*      */             }
/*      */           }
/* 1537 */           if (chunk.isTab()) {
/* 1538 */             if (chunk.isAttribute("TABSETTINGS")) {
/* 1539 */               TabStop tabStop = chunk.getTabStop();
/* 1540 */               if (tabStop != null) {
/* 1541 */                 tabPosition = tabStop.getPosition() + baseXMarker;
/* 1542 */                 if (tabStop.getLeader() != null)
/* 1543 */                   tabStop.getLeader().draw(graphics, xMarker, yMarker + descender, tabPosition, ascender - descender, yMarker);
/*      */               } else {
/* 1545 */                 tabPosition = xMarker;
/*      */               }
/*      */             }
/*      */             else {
/* 1549 */               Object[] tab = (Object[])chunk.getAttribute("TAB");
/* 1550 */               DrawInterface di = (DrawInterface)tab[0];
/* 1551 */               tabPosition = ((Float)tab[1]).floatValue() + ((Float)tab[3]).floatValue();
/* 1552 */               if (tabPosition > xMarker) {
/* 1553 */                 di.draw(graphics, xMarker, yMarker + descender, tabPosition, ascender - descender, yMarker);
/*      */               }
/*      */             }
/* 1556 */             float tmp = xMarker;
/* 1557 */             xMarker = tabPosition;
/* 1558 */             tabPosition = tmp;
/*      */           }
/* 1560 */           if (chunk.isAttribute("BACKGROUND")) {
/* 1561 */             Object[] bgr = (Object[])chunk.getAttribute("BACKGROUND");
/* 1562 */             if (bgr[0] != null) {
/* 1563 */               boolean inText = graphics.getInText();
/* 1564 */               if ((inText) && (isTagged(this.writer))) {
/* 1565 */                 graphics.endText();
/*      */               }
/* 1567 */               graphics.saveState();
/* 1568 */               float subtract = lastBaseFactor;
/* 1569 */               if ((nextChunk != null) && (nextChunk.isAttribute("BACKGROUND"))) {
/* 1570 */                 subtract = 0.0F;
/*      */               }
/* 1572 */               if (nextChunk == null) {
/* 1573 */                 subtract += hangingCorrection;
/*      */               }
/* 1575 */               BaseColor c = (BaseColor)bgr[0];
/* 1576 */               graphics.setColorFill(c);
/* 1577 */               float[] extra = (float[])bgr[1];
/* 1578 */               graphics.rectangle(xMarker - extra[0], yMarker + descender - extra[1] + chunk
/* 1579 */                 .getTextRise(), width - subtract + extra[0] + extra[2], ascender - descender + extra[1] + extra[3]);
/*      */               
/*      */ 
/* 1582 */               graphics.fill();
/* 1583 */               graphics.setGrayFill(0.0F);
/* 1584 */               graphics.restoreState();
/* 1585 */               if ((inText) && (isTagged(this.writer))) {
/* 1586 */                 graphics.beginText(true);
/*      */               }
/*      */             }
/*      */           }
/* 1590 */           if (chunk.isAttribute("UNDERLINE")) {
/* 1591 */             boolean inText = graphics.getInText();
/* 1592 */             if ((inText) && (isTagged(this.writer))) {
/* 1593 */               graphics.endText();
/*      */             }
/* 1595 */             float subtract = lastBaseFactor;
/* 1596 */             if ((nextChunk != null) && (nextChunk.isAttribute("UNDERLINE")))
/* 1597 */               subtract = 0.0F;
/* 1598 */             if (nextChunk == null)
/* 1599 */               subtract += hangingCorrection;
/* 1600 */             Object[][] unders = (Object[][])chunk.getAttribute("UNDERLINE");
/* 1601 */             BaseColor scolor = null;
/* 1602 */             for (int k = 0; k < unders.length; k++) {
/* 1603 */               Object[] obj = unders[k];
/* 1604 */               scolor = (BaseColor)obj[0];
/* 1605 */               float[] ps = (float[])obj[1];
/* 1606 */               if (scolor == null)
/* 1607 */                 scolor = color;
/* 1608 */               if (scolor != null)
/* 1609 */                 graphics.setColorStroke(scolor);
/* 1610 */               graphics.setLineWidth(ps[0] + chunk.font().size() * ps[1]);
/* 1611 */               float shift = ps[2] + chunk.font().size() * ps[3];
/* 1612 */               int cap2 = (int)ps[4];
/* 1613 */               if (cap2 != 0)
/* 1614 */                 graphics.setLineCap(cap2);
/* 1615 */               graphics.moveTo(xMarker, yMarker + shift);
/* 1616 */               graphics.lineTo(xMarker + width - subtract, yMarker + shift);
/* 1617 */               graphics.stroke();
/* 1618 */               if (scolor != null)
/* 1619 */                 graphics.resetGrayStroke();
/* 1620 */               if (cap2 != 0)
/* 1621 */                 graphics.setLineCap(0);
/*      */             }
/* 1623 */             graphics.setLineWidth(1.0F);
/* 1624 */             if ((inText) && (isTagged(this.writer))) {
/* 1625 */               graphics.beginText(true);
/*      */             }
/*      */           }
/* 1628 */           if (chunk.isAttribute("ACTION")) {
/* 1629 */             float subtract = lastBaseFactor;
/* 1630 */             if ((nextChunk != null) && (nextChunk.isAttribute("ACTION")))
/* 1631 */               subtract = 0.0F;
/* 1632 */             if (nextChunk == null)
/* 1633 */               subtract += hangingCorrection;
/* 1634 */             PdfAnnotation annot = null;
/* 1635 */             if (chunk.isImage()) {
/* 1636 */               annot = this.writer.createAnnotation(xMarker, yMarker + chunk.getImageOffsetY(), xMarker + width - subtract, yMarker + chunk.getImageHeight() + chunk.getImageOffsetY(), (PdfAction)chunk.getAttribute("ACTION"), null);
/*      */             }
/*      */             else {
/* 1639 */               annot = this.writer.createAnnotation(xMarker, yMarker + descender + chunk.getTextRise(), xMarker + width - subtract, yMarker + ascender + chunk.getTextRise(), (PdfAction)chunk.getAttribute("ACTION"), null);
/*      */             }
/* 1641 */             text.addAnnotation(annot, true);
/* 1642 */             if ((isTagged(this.writer)) && (chunk.accessibleElement != null)) {
/* 1643 */               PdfStructureElement strucElem = getStructElement(chunk.accessibleElement.getId());
/* 1644 */               if (strucElem != null) {
/* 1645 */                 int structParent = getStructParentIndex(annot);
/* 1646 */                 annot.put(PdfName.STRUCTPARENT, new PdfNumber(structParent));
/* 1647 */                 strucElem.setAnnotation(annot, this.writer.getCurrentPage());
/* 1648 */                 this.writer.getStructureTreeRoot().setAnnotationMark(structParent, strucElem.getReference());
/*      */               }
/*      */             }
/*      */           }
/* 1652 */           if (chunk.isAttribute("REMOTEGOTO")) {
/* 1653 */             float subtract = lastBaseFactor;
/* 1654 */             if ((nextChunk != null) && (nextChunk.isAttribute("REMOTEGOTO")))
/* 1655 */               subtract = 0.0F;
/* 1656 */             if (nextChunk == null)
/* 1657 */               subtract += hangingCorrection;
/* 1658 */             Object[] obj = (Object[])chunk.getAttribute("REMOTEGOTO");
/* 1659 */             String filename = (String)obj[0];
/* 1660 */             if ((obj[1] instanceof String)) {
/* 1661 */               remoteGoto(filename, (String)obj[1], xMarker, yMarker + descender + chunk.getTextRise(), xMarker + width - subtract, yMarker + ascender + chunk.getTextRise());
/*      */             } else
/* 1663 */               remoteGoto(filename, ((Integer)obj[1]).intValue(), xMarker, yMarker + descender + chunk.getTextRise(), xMarker + width - subtract, yMarker + ascender + chunk.getTextRise());
/*      */           }
/* 1665 */           if (chunk.isAttribute("LOCALGOTO")) {
/* 1666 */             float subtract = lastBaseFactor;
/* 1667 */             if ((nextChunk != null) && (nextChunk.isAttribute("LOCALGOTO")))
/* 1668 */               subtract = 0.0F;
/* 1669 */             if (nextChunk == null)
/* 1670 */               subtract += hangingCorrection;
/* 1671 */             localGoto((String)chunk.getAttribute("LOCALGOTO"), xMarker, yMarker, xMarker + width - subtract, yMarker + fontSize);
/*      */           }
/* 1673 */           if (chunk.isAttribute("LOCALDESTINATION"))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1679 */             localDestination((String)chunk.getAttribute("LOCALDESTINATION"), new PdfDestination(0, xMarker, yMarker + fontSize, 0.0F));
/*      */           }
/* 1681 */           if (chunk.isAttribute("GENERICTAG")) {
/* 1682 */             float subtract = lastBaseFactor;
/* 1683 */             if ((nextChunk != null) && (nextChunk.isAttribute("GENERICTAG")))
/* 1684 */               subtract = 0.0F;
/* 1685 */             if (nextChunk == null)
/* 1686 */               subtract += hangingCorrection;
/* 1687 */             Rectangle rect = new Rectangle(xMarker, yMarker, xMarker + width - subtract, yMarker + fontSize);
/* 1688 */             PdfPageEvent pev = this.writer.getPageEvent();
/* 1689 */             if (pev != null)
/* 1690 */               pev.onGenericTag(this.writer, this, rect, (String)chunk.getAttribute("GENERICTAG"));
/*      */           }
/* 1692 */           if (chunk.isAttribute("PDFANNOTATION")) {
/* 1693 */             float subtract = lastBaseFactor;
/* 1694 */             if ((nextChunk != null) && (nextChunk.isAttribute("PDFANNOTATION")))
/* 1695 */               subtract = 0.0F;
/* 1696 */             if (nextChunk == null)
/* 1697 */               subtract += hangingCorrection;
/* 1698 */             PdfAnnotation annot = PdfFormField.shallowDuplicate((PdfAnnotation)chunk.getAttribute("PDFANNOTATION"));
/* 1699 */             annot.put(PdfName.RECT, new PdfRectangle(xMarker, yMarker + descender, xMarker + width - subtract, yMarker + ascender));
/* 1700 */             text.addAnnotation(annot, true);
/*      */           }
/* 1702 */           float[] params = (float[])chunk.getAttribute("SKEW");
/* 1703 */           Float hs = (Float)chunk.getAttribute("HSCALE");
/* 1704 */           if ((params != null) || (hs != null)) {
/* 1705 */             float b = 0.0F;float c = 0.0F;
/* 1706 */             if (params != null) {
/* 1707 */               b = params[0];
/* 1708 */               c = params[1];
/*      */             }
/* 1710 */             if (hs != null)
/* 1711 */               hScale = hs.floatValue();
/* 1712 */             text.setTextMatrix(hScale, b, c, 1.0F, xMarker, yMarker);
/*      */           }
/* 1714 */           if (!isJustified) {
/* 1715 */             if (chunk.isAttribute("WORD_SPACING")) {
/* 1716 */               Float ws = (Float)chunk.getAttribute("WORD_SPACING");
/* 1717 */               text.setWordSpacing(ws.floatValue());
/*      */             }
/*      */             
/* 1720 */             if (chunk.isAttribute("CHAR_SPACING")) {
/* 1721 */               Float cs = (Float)chunk.getAttribute("CHAR_SPACING");
/* 1722 */               text.setCharacterSpacing(cs.floatValue());
/*      */             }
/*      */           }
/* 1725 */           if (chunk.isImage()) {
/* 1726 */             Image image = chunk.getImage();
/* 1727 */             width = chunk.getImageWidth();
/* 1728 */             float[] matrix = image.matrix(chunk.getImageScalePercentage());
/* 1729 */             matrix[4] = (xMarker + chunk.getImageOffsetX() - matrix[4]);
/* 1730 */             matrix[5] = (yMarker + chunk.getImageOffsetY() - matrix[5]);
/* 1731 */             graphics.addImage(image, matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5], false, isMCBlockOpened);
/* 1732 */             text.moveText(xMarker + lastBaseFactor + chunk.getImageWidth() - text.getXTLM(), 0.0F);
/*      */           }
/*      */         }
/*      */         
/* 1736 */         xMarker += width;
/* 1737 */         chunkStrokeIdx++;
/*      */       }
/*      */       
/* 1740 */       if ((!chunk.isImage()) && (chunk.font().compareTo(currentFont) != 0)) {
/* 1741 */         currentFont = chunk.font();
/* 1742 */         text.setFontAndSize(currentFont.getFont(), currentFont.size());
/*      */       }
/* 1744 */       float rise = 0.0F;
/* 1745 */       Object[] textRender = (Object[])chunk.getAttribute("TEXTRENDERMODE");
/* 1746 */       int tr = 0;
/* 1747 */       float strokeWidth = 1.0F;
/* 1748 */       BaseColor strokeColor = null;
/* 1749 */       Float fr = (Float)chunk.getAttribute("SUBSUPSCRIPT");
/* 1750 */       if (textRender != null) {
/* 1751 */         tr = ((Integer)textRender[0]).intValue() & 0x3;
/* 1752 */         if (tr != 0)
/* 1753 */           text.setTextRenderingMode(tr);
/* 1754 */         if ((tr == 1) || (tr == 2)) {
/* 1755 */           strokeWidth = ((Float)textRender[1]).floatValue();
/* 1756 */           if (strokeWidth != 1.0F)
/* 1757 */             text.setLineWidth(strokeWidth);
/* 1758 */           strokeColor = (BaseColor)textRender[2];
/* 1759 */           if (strokeColor == null)
/* 1760 */             strokeColor = color;
/* 1761 */           if (strokeColor != null)
/* 1762 */             text.setColorStroke(strokeColor);
/*      */         }
/*      */       }
/* 1765 */       if (fr != null)
/* 1766 */         rise = fr.floatValue();
/* 1767 */       if (color != null)
/* 1768 */         text.setColorFill(color);
/* 1769 */       if (rise != 0.0F)
/* 1770 */         text.setTextRise(rise);
/* 1771 */       if (chunk.isImage()) {
/* 1772 */         adjustMatrix = true;
/*      */       }
/* 1774 */       else if (chunk.isHorizontalSeparator()) {
/* 1775 */         PdfTextArray array = new PdfTextArray();
/* 1776 */         array.add(-glueWidth * 1000.0F / chunk.font.size() / hScale);
/* 1777 */         text.showText(array);
/*      */       }
/* 1779 */       else if ((chunk.isTab()) && (tabPosition != xMarker)) {
/* 1780 */         PdfTextArray array = new PdfTextArray();
/* 1781 */         array.add((tabPosition - xMarker) * 1000.0F / chunk.font.size() / hScale);
/* 1782 */         text.showText(array);
/*      */ 
/*      */ 
/*      */       }
/* 1786 */       else if ((isJustified) && (numberOfSpaces > 0) && (chunk.isSpecialEncoding())) {
/* 1787 */         if (hScale != lastHScale) {
/* 1788 */           lastHScale = hScale;
/* 1789 */           text.setWordSpacing(baseWordSpacing / hScale);
/* 1790 */           text.setCharacterSpacing(baseCharacterSpacing / hScale + text.getCharacterSpacing());
/*      */         }
/* 1792 */         String s = chunk.toString();
/* 1793 */         int idx = s.indexOf(' ');
/* 1794 */         if (idx < 0) {
/* 1795 */           text.showText(s);
/*      */         } else {
/* 1797 */           float spaceCorrection = -baseWordSpacing * 1000.0F / chunk.font.size() / hScale;
/* 1798 */           PdfTextArray textArray = new PdfTextArray(s.substring(0, idx));
/* 1799 */           int lastIdx = idx;
/* 1800 */           while ((idx = s.indexOf(' ', lastIdx + 1)) >= 0) {
/* 1801 */             textArray.add(spaceCorrection);
/* 1802 */             textArray.add(s.substring(lastIdx, idx));
/* 1803 */             lastIdx = idx;
/*      */           }
/* 1805 */           textArray.add(spaceCorrection);
/* 1806 */           textArray.add(s.substring(lastIdx));
/* 1807 */           text.showText(textArray);
/*      */         }
/*      */       }
/*      */       else {
/* 1811 */         if ((isJustified) && (hScale != lastHScale)) {
/* 1812 */           lastHScale = hScale;
/* 1813 */           text.setWordSpacing(baseWordSpacing / hScale);
/* 1814 */           text.setCharacterSpacing(baseCharacterSpacing / hScale + text.getCharacterSpacing());
/*      */         }
/* 1816 */         text.showText(chunk.toString());
/*      */       }
/*      */       
/* 1819 */       if (rise != 0.0F)
/* 1820 */         text.setTextRise(0.0F);
/* 1821 */       if (color != null)
/* 1822 */         text.resetRGBColorFill();
/* 1823 */       if (tr != 0)
/* 1824 */         text.setTextRenderingMode(0);
/* 1825 */       if (strokeColor != null)
/* 1826 */         text.resetRGBColorStroke();
/* 1827 */       if (strokeWidth != 1.0F)
/* 1828 */         text.setLineWidth(1.0F);
/* 1829 */       if ((chunk.isAttribute("SKEW")) || (chunk.isAttribute("HSCALE"))) {
/* 1830 */         adjustMatrix = true;
/* 1831 */         text.setTextMatrix(xMarker, yMarker);
/*      */       }
/* 1833 */       if (!isJustified) {
/* 1834 */         if (chunk.isAttribute("CHAR_SPACING")) {
/* 1835 */           text.setCharacterSpacing(baseCharacterSpacing);
/*      */         }
/* 1837 */         if (chunk.isAttribute("WORD_SPACING")) {
/* 1838 */           text.setWordSpacing(baseWordSpacing);
/*      */         }
/*      */       }
/* 1841 */       if ((isTagged(this.writer)) && (chunk.accessibleElement != null)) {
/* 1842 */         text.closeMCBlock(chunk.accessibleElement);
/*      */       }
/*      */     }
/*      */     
/* 1846 */     if (isJustified) {
/* 1847 */       text.setWordSpacing(0.0F);
/* 1848 */       text.setCharacterSpacing(0.0F);
/* 1849 */       if (line.isNewlineSplit())
/* 1850 */         lastBaseFactor = 0.0F;
/*      */     }
/* 1852 */     if (adjustMatrix)
/* 1853 */       text.moveText(baseXMarker - text.getXTLM(), 0.0F);
/* 1854 */     currentValues[0] = currentFont;
/* 1855 */     currentValues[1] = new Float(lastBaseFactor);
/* 1856 */     return lastX;
/*      */   }
/*      */   
/* 1859 */   protected Indentation indentation = new Indentation();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Indentation
/*      */   {
/* 1867 */     float indentLeft = 0.0F;
/*      */     
/*      */ 
/* 1870 */     float sectionIndentLeft = 0.0F;
/*      */     
/*      */ 
/* 1873 */     float listIndentLeft = 0.0F;
/*      */     
/*      */ 
/* 1876 */     float imageIndentLeft = 0.0F;
/*      */     
/*      */ 
/* 1879 */     float indentRight = 0.0F;
/*      */     
/*      */ 
/* 1882 */     float sectionIndentRight = 0.0F;
/*      */     
/*      */ 
/* 1885 */     float imageIndentRight = 0.0F;
/*      */     
/*      */ 
/* 1888 */     float indentTop = 0.0F;
/*      */     
/*      */ 
/* 1891 */     float indentBottom = 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float indentLeft()
/*      */   {
/* 1901 */     return left(this.indentation.indentLeft + this.indentation.listIndentLeft + this.indentation.imageIndentLeft + this.indentation.sectionIndentLeft);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float indentRight()
/*      */   {
/* 1911 */     return right(this.indentation.indentRight + this.indentation.sectionIndentRight + this.indentation.imageIndentRight);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float indentTop()
/*      */   {
/* 1921 */     return top(this.indentation.indentTop);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   float indentBottom()
/*      */   {
/* 1931 */     return bottom(this.indentation.indentBottom);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void addSpacing(float extraspace, float oldleading, Font f)
/*      */   {
/* 1938 */     addSpacing(extraspace, oldleading, f, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addSpacing(float extraspace, float oldleading, Font f, boolean spacingAfter)
/*      */   {
/* 1946 */     if (extraspace == 0.0F) {
/* 1947 */       return;
/*      */     }
/*      */     
/* 1950 */     if (this.pageEmpty) {
/* 1951 */       return;
/*      */     }
/*      */     
/* 1954 */     float height = spacingAfter ? extraspace : calculateLineHeight();
/*      */     
/* 1956 */     if (this.currentHeight + height > indentTop() - indentBottom()) {
/* 1957 */       newPage();
/* 1958 */       return;
/*      */     }
/*      */     
/* 1961 */     this.leading = extraspace;
/* 1962 */     carriageReturn();
/* 1963 */     if ((f.isUnderlined()) || (f.isStrikethru())) {
/* 1964 */       f = new Font(f);
/* 1965 */       int style = f.getStyle();
/* 1966 */       style &= 0xFFFFFFFB;
/* 1967 */       style &= 0xFFFFFFF7;
/* 1968 */       f.setStyle(style);
/*      */     }
/* 1970 */     Chunk space = new Chunk(" ", f);
/* 1971 */     if ((spacingAfter) && (this.pageEmpty)) {
/* 1972 */       space = new Chunk("", f);
/*      */     }
/* 1974 */     space.process(this);
/* 1975 */     carriageReturn();
/*      */     
/* 1977 */     this.leading = oldleading;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1983 */   protected PdfInfo info = new PdfInfo();
/*      */   
/*      */   protected PdfOutline rootOutline;
/*      */   
/*      */   protected PdfOutline currentOutline;
/*      */   
/*      */ 
/*      */   PdfInfo getInfo()
/*      */   {
/* 1992 */     return this.info;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfCatalog getCatalog(PdfIndirectReference pages)
/*      */   {
/* 2003 */     PdfCatalog catalog = new PdfCatalog(pages, this.writer);
/*      */     
/*      */ 
/* 2006 */     if (this.rootOutline.getKids().size() > 0) {
/* 2007 */       catalog.put(PdfName.PAGEMODE, PdfName.USEOUTLINES);
/* 2008 */       catalog.put(PdfName.OUTLINES, this.rootOutline.indirectReference());
/*      */     }
/*      */     
/*      */ 
/* 2012 */     this.writer.getPdfVersion().addToCatalog(catalog);
/*      */     
/*      */ 
/* 2015 */     this.viewerPreferences.addToCatalog(catalog);
/*      */     
/*      */ 
/* 2018 */     if (this.pageLabels != null) {
/* 2019 */       catalog.put(PdfName.PAGELABELS, this.pageLabels.getDictionary(this.writer));
/*      */     }
/*      */     
/*      */ 
/* 2023 */     catalog.addNames(this.localDestinations, getDocumentLevelJS(), this.documentFileAttachment, this.writer);
/*      */     
/*      */ 
/* 2026 */     if (this.openActionName != null) {
/* 2027 */       PdfAction action = getLocalGotoAction(this.openActionName);
/* 2028 */       catalog.setOpenAction(action);
/*      */     }
/* 2030 */     else if (this.openActionAction != null) {
/* 2031 */       catalog.setOpenAction(this.openActionAction); }
/* 2032 */     if (this.additionalActions != null) {
/* 2033 */       catalog.setAdditionalActions(this.additionalActions);
/*      */     }
/*      */     
/*      */ 
/* 2037 */     if (this.collection != null) {
/* 2038 */       catalog.put(PdfName.COLLECTION, this.collection);
/*      */     }
/*      */     
/*      */ 
/* 2042 */     if (this.annotationsImp.hasValidAcroForm()) {
/*      */       try {
/* 2044 */         catalog.put(PdfName.ACROFORM, this.writer.addToBody(this.annotationsImp.getAcroForm()).getIndirectReference());
/*      */       }
/*      */       catch (IOException e) {
/* 2047 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */     
/* 2051 */     if (this.language != null) {
/* 2052 */       catalog.put(PdfName.LANG, this.language);
/*      */     }
/*      */     
/* 2055 */     return catalog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addOutline(PdfOutline outline, String name)
/*      */   {
/* 2072 */     localDestination(name, outline.getPdfDestination());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfOutline getRootOutline()
/*      */   {
/* 2081 */     return this.rootOutline;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void calculateOutlineCount()
/*      */   {
/* 2089 */     if (this.rootOutline.getKids().size() == 0)
/* 2090 */       return;
/* 2091 */     traverseOutlineCount(this.rootOutline);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void traverseOutlineCount(PdfOutline outline)
/*      */   {
/* 2098 */     ArrayList<PdfOutline> kids = outline.getKids();
/* 2099 */     PdfOutline parent = outline.parent();
/* 2100 */     if (kids.isEmpty()) {
/* 2101 */       if (parent != null) {
/* 2102 */         parent.setCount(parent.getCount() + 1);
/*      */       }
/*      */     }
/*      */     else {
/* 2106 */       for (int k = 0; k < kids.size(); k++) {
/* 2107 */         traverseOutlineCount((PdfOutline)kids.get(k));
/*      */       }
/* 2109 */       if (parent != null) {
/* 2110 */         if (outline.isOpen()) {
/* 2111 */           parent.setCount(outline.getCount() + parent.getCount() + 1);
/*      */         }
/*      */         else {
/* 2114 */           parent.setCount(parent.getCount() + 1);
/* 2115 */           outline.setCount(-outline.getCount());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void writeOutlines()
/*      */     throws IOException
/*      */   {
/* 2125 */     if (this.rootOutline.getKids().size() == 0)
/* 2126 */       return;
/* 2127 */     outlineTree(this.rootOutline);
/* 2128 */     this.writer.addToBody(this.rootOutline, this.rootOutline.indirectReference());
/*      */   }
/*      */   
/*      */ 
/*      */   void outlineTree(PdfOutline outline)
/*      */     throws IOException
/*      */   {
/* 2135 */     outline.setIndirectReference(this.writer.getPdfIndirectReference());
/* 2136 */     if (outline.parent() != null)
/* 2137 */       outline.put(PdfName.PARENT, outline.parent().indirectReference());
/* 2138 */     ArrayList<PdfOutline> kids = outline.getKids();
/* 2139 */     int size = kids.size();
/* 2140 */     for (int k = 0; k < size; k++)
/* 2141 */       outlineTree((PdfOutline)kids.get(k));
/* 2142 */     for (int k = 0; k < size; k++) {
/* 2143 */       if (k > 0)
/* 2144 */         ((PdfOutline)kids.get(k)).put(PdfName.PREV, ((PdfOutline)kids.get(k - 1)).indirectReference());
/* 2145 */       if (k < size - 1)
/* 2146 */         ((PdfOutline)kids.get(k)).put(PdfName.NEXT, ((PdfOutline)kids.get(k + 1)).indirectReference());
/*      */     }
/* 2148 */     if (size > 0) {
/* 2149 */       outline.put(PdfName.FIRST, ((PdfOutline)kids.get(0)).indirectReference());
/* 2150 */       outline.put(PdfName.LAST, ((PdfOutline)kids.get(size - 1)).indirectReference());
/*      */     }
/* 2152 */     for (int k = 0; k < size; k++) {
/* 2153 */       PdfOutline kid = (PdfOutline)kids.get(k);
/* 2154 */       this.writer.addToBody(kid, kid.indirectReference());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2161 */   protected PdfViewerPreferencesImp viewerPreferences = new PdfViewerPreferencesImp();
/*      */   protected PdfPageLabels pageLabels;
/*      */   
/* 2164 */   void setViewerPreferences(int preferences) { this.viewerPreferences.setViewerPreferences(preferences); }
/*      */   
/*      */ 
/*      */   void addViewerPreference(PdfName key, PdfObject value)
/*      */   {
/* 2169 */     this.viewerPreferences.addViewerPreference(key, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setPageLabels(PdfPageLabels pageLabels)
/*      */   {
/* 2180 */     this.pageLabels = pageLabels;
/*      */   }
/*      */   
/*      */   public PdfPageLabels getPageLabels() {
/* 2184 */     return this.pageLabels;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void localGoto(String name, float llx, float lly, float urx, float ury)
/*      */   {
/* 2199 */     PdfAction action = getLocalGotoAction(name);
/* 2200 */     this.annotationsImp.addPlainAnnotation(this.writer.createAnnotation(llx, lly, urx, ury, action, null));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void remoteGoto(String filename, String name, float llx, float lly, float urx, float ury)
/*      */   {
/* 2213 */     this.annotationsImp.addPlainAnnotation(this.writer.createAnnotation(llx, lly, urx, ury, new PdfAction(filename, name), null));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void remoteGoto(String filename, int page, float llx, float lly, float urx, float ury)
/*      */   {
/* 2226 */     addAnnotation(this.writer.createAnnotation(llx, lly, urx, ury, new PdfAction(filename, page), null));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setAction(PdfAction action, float llx, float lly, float urx, float ury)
/*      */   {
/* 2237 */     addAnnotation(this.writer.createAnnotation(llx, lly, urx, ury, action, null));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2243 */   protected TreeMap<String, Destination> localDestinations = new TreeMap();
/*      */   int jsCounter;
/*      */   
/*      */   PdfAction getLocalGotoAction(String name) {
/* 2247 */     Destination dest = (Destination)this.localDestinations.get(name);
/* 2248 */     if (dest == null)
/* 2249 */       dest = new Destination();
/* 2250 */     PdfAction action; if (dest.action == null) {
/* 2251 */       if (dest.reference == null) {
/* 2252 */         dest.reference = this.writer.getPdfIndirectReference();
/*      */       }
/* 2254 */       PdfAction action = new PdfAction(dest.reference);
/* 2255 */       dest.action = action;
/* 2256 */       this.localDestinations.put(name, dest);
/*      */     }
/*      */     else {
/* 2259 */       action = dest.action;
/*      */     }
/* 2261 */     return action;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean localDestination(String name, PdfDestination destination)
/*      */   {
/* 2274 */     Destination dest = (Destination)this.localDestinations.get(name);
/* 2275 */     if (dest == null)
/* 2276 */       dest = new Destination();
/* 2277 */     if (dest.destination != null)
/* 2278 */       return false;
/* 2279 */     dest.destination = destination;
/* 2280 */     this.localDestinations.put(name, dest);
/* 2281 */     if (!destination.hasPage())
/* 2282 */       destination.addPage(this.writer.getCurrentPage());
/* 2283 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2290 */   protected HashMap<String, PdfObject> documentLevelJS = new HashMap();
/* 2291 */   protected static final DecimalFormat SIXTEEN_DIGITS = new DecimalFormat("0000000000000000");
/*      */   
/* 2293 */   void addJavaScript(PdfAction js) { if (js.get(PdfName.JS) == null)
/* 2294 */       throw new RuntimeException(MessageLocalization.getComposedMessage("only.javascript.actions.are.allowed", new Object[0]));
/*      */     try {
/* 2296 */       this.documentLevelJS.put(SIXTEEN_DIGITS.format(this.jsCounter++), this.writer.addToBody(js).getIndirectReference());
/*      */     }
/*      */     catch (IOException e) {
/* 2299 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/* 2303 */   void addJavaScript(String name, PdfAction js) { if (js.get(PdfName.JS) == null)
/* 2304 */       throw new RuntimeException(MessageLocalization.getComposedMessage("only.javascript.actions.are.allowed", new Object[0]));
/*      */     try {
/* 2306 */       this.documentLevelJS.put(name, this.writer.addToBody(js).getIndirectReference());
/*      */     }
/*      */     catch (IOException e) {
/* 2309 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */   HashMap<String, PdfObject> getDocumentLevelJS() {
/* 2314 */     return this.documentLevelJS;
/*      */   }
/*      */   
/* 2317 */   protected HashMap<String, PdfObject> documentFileAttachment = new HashMap();
/*      */   protected String openActionName;
/*      */   
/* 2320 */   void addFileAttachment(String description, PdfFileSpecification fs) throws IOException { if (description == null) {
/* 2321 */       PdfString desc = (PdfString)fs.get(PdfName.DESC);
/* 2322 */       if (desc == null) {
/* 2323 */         description = "";
/*      */       }
/*      */       else {
/* 2326 */         description = PdfEncodings.convertToString(desc.getBytes(), null);
/*      */       }
/*      */     }
/* 2329 */     fs.addDescription(description, true);
/* 2330 */     if (description.length() == 0)
/* 2331 */       description = "Unnamed";
/* 2332 */     String fn = PdfEncodings.convertToString(new PdfString(description, "UnicodeBig").getBytes(), null);
/* 2333 */     int k = 0;
/* 2334 */     while (this.documentFileAttachment.containsKey(fn)) {
/* 2335 */       k++;
/* 2336 */       fn = PdfEncodings.convertToString(new PdfString(description + " " + k, "UnicodeBig").getBytes(), null);
/*      */     }
/* 2338 */     this.documentFileAttachment.put(fn, fs.getReference());
/*      */   }
/*      */   
/*      */   HashMap<String, PdfObject> getDocumentFileAttachment() {
/* 2342 */     return this.documentFileAttachment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void setOpenAction(String name)
/*      */   {
/* 2350 */     this.openActionName = name;
/* 2351 */     this.openActionAction = null;
/*      */   }
/*      */   
/*      */   void setOpenAction(PdfAction action)
/*      */   {
/* 2356 */     this.openActionAction = action;
/* 2357 */     this.openActionName = null;
/*      */   }
/*      */   
/*      */   void addAdditionalAction(PdfName actionType, PdfAction action)
/*      */   {
/* 2362 */     if (this.additionalActions == null) {
/* 2363 */       this.additionalActions = new PdfDictionary();
/*      */     }
/* 2365 */     if (action == null) {
/* 2366 */       this.additionalActions.remove(actionType);
/*      */     } else
/* 2368 */       this.additionalActions.put(actionType, action);
/* 2369 */     if (this.additionalActions.size() == 0) {
/* 2370 */       this.additionalActions = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfAction openActionAction;
/*      */   
/*      */   protected PdfDictionary additionalActions;
/*      */   
/*      */   public void setCollection(PdfCollection collection)
/*      */   {
/* 2382 */     this.collection = collection;
/*      */   }
/*      */   
/*      */ 
/*      */   protected PdfCollection collection;
/*      */   
/*      */   PdfAnnotationsImp annotationsImp;
/*      */   
/*      */   protected PdfString language;
/*      */   
/*      */   PdfAcroForm getAcroForm()
/*      */   {
/* 2394 */     return this.annotationsImp.getAcroForm();
/*      */   }
/*      */   
/*      */   void setSigFlags(int f) {
/* 2398 */     this.annotationsImp.setSigFlags(f);
/*      */   }
/*      */   
/*      */   void addCalculationOrder(PdfFormField formField) {
/* 2402 */     this.annotationsImp.addCalculationOrder(formField);
/*      */   }
/*      */   
/*      */   void addAnnotation(PdfAnnotation annot) {
/* 2406 */     this.pageEmpty = false;
/* 2407 */     this.annotationsImp.addAnnotation(annot);
/*      */   }
/*      */   
/*      */   void setLanguage(String language)
/*      */   {
/* 2412 */     this.language = new PdfString(language);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2419 */   protected Rectangle nextPageSize = null;
/*      */   
/*      */ 
/* 2422 */   protected HashMap<String, PdfRectangle> thisBoxSize = new HashMap();
/*      */   
/*      */ 
/*      */ 
/* 2426 */   protected HashMap<String, PdfRectangle> boxSize = new HashMap();
/*      */   
/*      */   void setCropBoxSize(Rectangle crop) {
/* 2429 */     setBoxSize("crop", crop);
/*      */   }
/*      */   
/*      */   void setBoxSize(String boxName, Rectangle size) {
/* 2433 */     if (size == null) {
/* 2434 */       this.boxSize.remove(boxName);
/*      */     } else
/* 2436 */       this.boxSize.put(boxName, new PdfRectangle(size));
/*      */   }
/*      */   
/*      */   protected void setNewPageSizeAndMargins() {
/* 2440 */     this.pageSize = this.nextPageSize;
/* 2441 */     if ((this.marginMirroring) && ((getPageNumber() & 0x1) == 0)) {
/* 2442 */       this.marginRight = this.nextMarginLeft;
/* 2443 */       this.marginLeft = this.nextMarginRight;
/*      */     }
/*      */     else {
/* 2446 */       this.marginLeft = this.nextMarginLeft;
/* 2447 */       this.marginRight = this.nextMarginRight;
/*      */     }
/* 2449 */     if ((this.marginMirroringTopBottom) && ((getPageNumber() & 0x1) == 0)) {
/* 2450 */       this.marginTop = this.nextMarginBottom;
/* 2451 */       this.marginBottom = this.nextMarginTop;
/*      */     }
/*      */     else {
/* 2454 */       this.marginTop = this.nextMarginTop;
/* 2455 */       this.marginBottom = this.nextMarginBottom;
/*      */     }
/* 2457 */     if (!isTagged(this.writer)) {
/* 2458 */       this.text = new PdfContentByte(this.writer);
/* 2459 */       this.text.reset();
/*      */     } else {
/* 2461 */       this.text = this.graphics;
/*      */     }
/* 2463 */     this.text.beginText();
/*      */     
/* 2465 */     this.text.moveText(left(), top());
/* 2466 */     if (isTagged(this.writer)) {
/* 2467 */       this.textEmptySize = this.text.size();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Rectangle getBoxSize(String boxName)
/*      */   {
/* 2475 */     PdfRectangle r = (PdfRectangle)this.thisBoxSize.get(boxName);
/* 2476 */     if (r != null) {
/* 2477 */       return r.getRectangle();
/*      */     }
/* 2479 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2485 */   private boolean pageEmpty = true;
/*      */   
/*      */   void setPageEmpty(boolean pageEmpty) {
/* 2488 */     this.pageEmpty = pageEmpty;
/*      */   }
/*      */   
/*      */   boolean isPageEmpty() {
/* 2492 */     if (isTagged(this.writer)) {
/* 2493 */       return (this.writer == null) || ((this.writer.getDirectContent().size(false) == 0) && (this.writer.getDirectContentUnder().size(false) == 0) && (this.text.size(false) - this.textEmptySize == 0) && ((this.pageEmpty) || (this.writer.isPaused())));
/*      */     }
/* 2495 */     return (this.writer == null) || ((this.writer.getDirectContent().size() == 0) && (this.writer.getDirectContentUnder().size() == 0) && ((this.pageEmpty) || (this.writer.isPaused())));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDuration(int seconds)
/*      */   {
/* 2506 */     if (seconds > 0) {
/* 2507 */       this.writer.addPageDictEntry(PdfName.DUR, new PdfNumber(seconds));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void setTransition(PdfTransition transition)
/*      */   {
/* 2515 */     this.writer.addPageDictEntry(PdfName.TRANS, transition.getTransitionDictionary());
/*      */   }
/*      */   
/* 2518 */   protected PdfDictionary pageAA = null;
/*      */   
/* 2520 */   void setPageAction(PdfName actionType, PdfAction action) { if (this.pageAA == null) {
/* 2521 */       this.pageAA = new PdfDictionary();
/*      */     }
/* 2523 */     this.pageAA.put(actionType, action);
/*      */   }
/*      */   
/*      */   void setThumbnail(Image image)
/*      */     throws PdfException, DocumentException
/*      */   {
/* 2529 */     this.writer.addPageDictEntry(PdfName.THUMB, this.writer.getImageReference(this.writer.addDirectImageSimple(image)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected PageResources pageResources;
/*      */   
/*      */   PageResources getPageResources()
/*      */   {
/* 2538 */     return this.pageResources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2544 */   protected boolean strictImageSequence = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isStrictImageSequence()
/*      */   {
/* 2551 */     return this.strictImageSequence;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void setStrictImageSequence(boolean strictImageSequence)
/*      */   {
/* 2559 */     this.strictImageSequence = strictImageSequence;
/*      */   }
/*      */   
/*      */ 
/* 2563 */   protected float imageEnd = -1.0F;
/*      */   
/*      */ 
/*      */ 
/*      */   public void clearTextWrap()
/*      */   {
/* 2569 */     float tmpHeight = this.imageEnd - this.currentHeight;
/* 2570 */     if (this.line != null) {
/* 2571 */       tmpHeight += this.line.height();
/*      */     }
/* 2573 */     if ((this.imageEnd > -1.0F) && (tmpHeight > 0.0F)) {
/* 2574 */       carriageReturn();
/* 2575 */       this.currentHeight += tmpHeight;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getStructParentIndex(Object obj) {
/* 2580 */     int[] i = (int[])this.structParentIndices.get(obj);
/* 2581 */     if (i == null) {
/* 2582 */       i = new int[] { this.structParentIndices.size(), 0 };
/* 2583 */       this.structParentIndices.put(obj, i);
/*      */     }
/* 2585 */     return i[0];
/*      */   }
/*      */   
/*      */   public int getNextMarkPoint(Object obj) {
/* 2589 */     int[] i = (int[])this.structParentIndices.get(obj);
/* 2590 */     if (i == null) {
/* 2591 */       i = new int[] { this.structParentIndices.size(), 0 };
/* 2592 */       this.structParentIndices.put(obj, i);
/*      */     }
/* 2594 */     int markPoint = i[1];
/* 2595 */     i[1] += 1;
/* 2596 */     return markPoint;
/*      */   }
/*      */   
/*      */   public int[] getStructParentIndexAndNextMarkPoint(Object obj) {
/* 2600 */     int[] i = (int[])this.structParentIndices.get(obj);
/* 2601 */     if (i == null) {
/* 2602 */       i = new int[] { this.structParentIndices.size(), 0 };
/* 2603 */       this.structParentIndices.put(obj, i);
/*      */     }
/* 2605 */     int markPoint = i[1];
/* 2606 */     i[1] += 1;
/* 2607 */     return new int[] { i[0], markPoint };
/*      */   }
/*      */   
/*      */ 
/* 2611 */   protected Image imageWait = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void add(Image image)
/*      */     throws PdfException, DocumentException
/*      */   {
/* 2621 */     if (image.hasAbsoluteY()) {
/* 2622 */       this.graphics.addImage(image);
/* 2623 */       this.pageEmpty = false;
/* 2624 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2628 */     if ((this.currentHeight != 0.0F) && (indentTop() - this.currentHeight - image.getScaledHeight() < indentBottom())) {
/* 2629 */       if ((!this.strictImageSequence) && (this.imageWait == null)) {
/* 2630 */         this.imageWait = image;
/* 2631 */         return;
/*      */       }
/* 2633 */       newPage();
/* 2634 */       if ((this.currentHeight != 0.0F) && (indentTop() - this.currentHeight - image.getScaledHeight() < indentBottom())) {
/* 2635 */         this.imageWait = image;
/* 2636 */         return;
/*      */       }
/*      */     }
/* 2639 */     this.pageEmpty = false;
/*      */     
/* 2641 */     if (image == this.imageWait) {
/* 2642 */       this.imageWait = null;
/*      */     }
/* 2644 */     boolean textwrap = ((image.getAlignment() & 0x4) == 4) && ((image.getAlignment() & 0x1) != 1);
/* 2645 */     boolean underlying = (image.getAlignment() & 0x8) == 8;
/* 2646 */     float diff = this.leading / 2.0F;
/* 2647 */     if (textwrap) {
/* 2648 */       diff += this.leading;
/*      */     }
/* 2650 */     float lowerleft = indentTop() - this.currentHeight - image.getScaledHeight() - diff;
/* 2651 */     float[] mt = image.matrix();
/* 2652 */     float startPosition = indentLeft() - mt[4];
/* 2653 */     if ((image.getAlignment() & 0x2) == 2) startPosition = indentRight() - image.getScaledWidth() - mt[4];
/* 2654 */     if ((image.getAlignment() & 0x1) == 1) startPosition = indentLeft() + (indentRight() - indentLeft() - image.getScaledWidth()) / 2.0F - mt[4];
/* 2655 */     if (image.hasAbsoluteX()) startPosition = image.getAbsoluteX();
/* 2656 */     if (textwrap) {
/* 2657 */       if ((this.imageEnd < 0.0F) || (this.imageEnd < this.currentHeight + image.getScaledHeight() + diff)) {
/* 2658 */         this.imageEnd = (this.currentHeight + image.getScaledHeight() + diff);
/*      */       }
/* 2660 */       if ((image.getAlignment() & 0x2) == 2)
/*      */       {
/* 2662 */         this.indentation.imageIndentRight += image.getScaledWidth() + image.getIndentationLeft();
/*      */       }
/*      */       else
/*      */       {
/* 2666 */         this.indentation.imageIndentLeft += image.getScaledWidth() + image.getIndentationRight();
/*      */       }
/*      */       
/*      */     }
/* 2670 */     else if ((image.getAlignment() & 0x2) == 2) { startPosition -= image.getIndentationRight();
/* 2671 */     } else if ((image.getAlignment() & 0x1) == 1) { startPosition += image.getIndentationLeft() - image.getIndentationRight();
/* 2672 */     } else { startPosition += image.getIndentationLeft();
/*      */     }
/* 2674 */     this.graphics.addImage(image, mt[0], mt[1], mt[2], mt[3], startPosition, lowerleft - mt[5]);
/* 2675 */     if ((!textwrap) && (!underlying)) {
/* 2676 */       this.currentHeight += image.getScaledHeight() + diff;
/* 2677 */       flushLines();
/* 2678 */       this.text.moveText(0.0F, -(image.getScaledHeight() + diff));
/* 2679 */       newLine();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addPTable(PdfPTable ptable)
/*      */     throws DocumentException
/*      */   {
/* 2690 */     ColumnText ct = new ColumnText(isTagged(this.writer) ? this.text : this.writer.getDirectContent());
/* 2691 */     ct.setRunDirection(ptable.getRunDirection());
/*      */     
/*      */ 
/* 2694 */     if ((ptable.getKeepTogether()) && (!fitsPage(ptable, 0.0F)) && (this.currentHeight > 0.0F)) {
/* 2695 */       newPage();
/* 2696 */       if (isTagged(this.writer)) {
/* 2697 */         ct.setCanvas(this.text);
/*      */       }
/*      */     }
/* 2700 */     if (this.currentHeight == 0.0F) {
/* 2701 */       ct.setAdjustFirstLine(false);
/*      */     }
/* 2703 */     ct.addElement(ptable);
/* 2704 */     boolean he = ptable.isHeadersInEvent();
/* 2705 */     ptable.setHeadersInEvent(true);
/* 2706 */     int loop = 0;
/*      */     for (;;) {
/* 2708 */       ct.setSimpleColumn(indentLeft(), indentBottom(), indentRight(), indentTop() - this.currentHeight);
/* 2709 */       int status = ct.go();
/* 2710 */       if ((status & 0x1) != 0) {
/* 2711 */         if (isTagged(this.writer)) {
/* 2712 */           this.text.setTextMatrix(indentLeft(), ct.getYLine());
/*      */         } else {
/* 2714 */           this.text.moveText(0.0F, ct.getYLine() - indentTop() + this.currentHeight);
/*      */         }
/* 2716 */         this.currentHeight = (indentTop() - ct.getYLine());
/* 2717 */         break;
/*      */       }
/* 2719 */       if (indentTop() - this.currentHeight == ct.getYLine()) {
/* 2720 */         loop++;
/*      */       } else
/* 2722 */         loop = 0;
/* 2723 */       if (loop == 3) {
/* 2724 */         throw new DocumentException(MessageLocalization.getComposedMessage("infinite.table.loop", new Object[0]));
/*      */       }
/* 2726 */       this.currentHeight = (indentTop() - ct.getYLine());
/* 2727 */       newPage();
/* 2728 */       if (isTagged(this.writer)) {
/* 2729 */         ct.setCanvas(this.text);
/*      */       }
/*      */     }
/* 2732 */     ptable.setHeadersInEvent(he);
/*      */   }
/*      */   
/* 2735 */   private ArrayList<Element> floatingElements = new ArrayList();
/*      */   
/*      */   private void addDiv(PdfDiv div) throws DocumentException {
/* 2738 */     if (this.floatingElements == null) {
/* 2739 */       this.floatingElements = new ArrayList();
/*      */     }
/* 2741 */     this.floatingElements.add(div);
/*      */   }
/*      */   
/*      */   private void flushFloatingElements() throws DocumentException {
/* 2745 */     if ((this.floatingElements != null) && (!this.floatingElements.isEmpty())) {
/* 2746 */       ArrayList<Element> cachedFloatingElements = this.floatingElements;
/* 2747 */       this.floatingElements = null;
/* 2748 */       FloatLayout fl = new FloatLayout(cachedFloatingElements, false);
/* 2749 */       int loop = 0;
/*      */       for (;;) {
/* 2751 */         float left = indentLeft();
/* 2752 */         fl.setSimpleColumn(indentLeft(), indentBottom(), indentRight(), indentTop() - this.currentHeight);
/*      */         try {
/* 2754 */           int status = fl.layout(isTagged(this.writer) ? this.text : this.writer.getDirectContent(), false);
/* 2755 */           if ((status & 0x1) != 0) {
/* 2756 */             if (isTagged(this.writer)) {
/* 2757 */               this.text.setTextMatrix(indentLeft(), fl.getYLine());
/*      */             } else {
/* 2759 */               this.text.moveText(0.0F, fl.getYLine() - indentTop() + this.currentHeight);
/*      */             }
/* 2761 */             this.currentHeight = (indentTop() - fl.getYLine());
/* 2762 */             break;
/*      */           }
/*      */         } catch (Exception exc) {
/* 2765 */           return;
/*      */         }
/* 2767 */         if ((indentTop() - this.currentHeight == fl.getYLine()) || (isPageEmpty())) {
/* 2768 */           loop++;
/*      */         } else {
/* 2770 */           loop = 0;
/*      */         }
/* 2772 */         if (loop == 2) {
/* 2773 */           return;
/*      */         }
/* 2775 */         newPage();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean fitsPage(PdfPTable table, float margin)
/*      */   {
/* 2789 */     if (!table.isLockedWidth()) {
/* 2790 */       float totalWidth = (indentRight() - indentLeft()) * table.getWidthPercentage() / 100.0F;
/* 2791 */       table.setTotalWidth(totalWidth);
/*      */     }
/*      */     
/* 2794 */     ensureNewLine();
/* 2795 */     Float spaceNeeded = Float.valueOf(table.isSkipFirstHeader() ? table.getTotalHeight() - table.getHeaderHeight() : table.getTotalHeight());
/* 2796 */     return spaceNeeded.floatValue() + (this.currentHeight > 0.0F ? table.spacingBefore() : 0.0F) <= indentTop() - this.currentHeight - indentBottom() - margin;
/*      */   }
/*      */   
/*      */   private static boolean isTagged(PdfWriter writer) {
/* 2800 */     return (writer != null) && (writer.isTagged());
/*      */   }
/*      */   
/*      */   private PdfLine getLastLine() {
/* 2804 */     if (this.lines.size() > 0) {
/* 2805 */       return (PdfLine)this.lines.get(this.lines.size() - 1);
/*      */     }
/* 2807 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void useExternalCache(TempFileCache externalCache)
/*      */   {
/* 2820 */     this.isToUseExternalCache = true;
/* 2821 */     this.externalCache = externalCache;
/*      */   }
/*      */   
/*      */   protected void saveStructElement(AccessibleElementId id, PdfStructureElement element) {
/* 2825 */     this.structElements.put(id, element);
/*      */   }
/*      */   
/*      */   protected PdfStructureElement getStructElement(AccessibleElementId id) {
/* 2829 */     return getStructElement(id, true);
/*      */   }
/*      */   
/*      */   protected PdfStructureElement getStructElement(AccessibleElementId id, boolean toSaveFetchedElement) {
/* 2833 */     PdfStructureElement element = (PdfStructureElement)this.structElements.get(id);
/* 2834 */     if ((this.isToUseExternalCache) && (element == null)) {
/* 2835 */       TempFileCache.ObjectPosition pos = (TempFileCache.ObjectPosition)this.externallyStoredStructElements.get(id);
/* 2836 */       if (pos != null) {
/*      */         try {
/* 2838 */           element = (PdfStructureElement)this.externalCache.get(pos);
/* 2839 */           element.setStructureTreeRoot(this.writer.getStructureTreeRoot());
/* 2840 */           element.setStructureElementParent(getStructElement((AccessibleElementId)this.elementsParents.get(element.getElementId()), toSaveFetchedElement));
/*      */           
/* 2842 */           if (toSaveFetchedElement) {
/* 2843 */             this.externallyStoredStructElements.remove(id);
/* 2844 */             this.structElements.put(id, element);
/*      */           }
/*      */         } catch (IOException e) {
/* 2847 */           throw new ExceptionConverter(e);
/*      */         } catch (ClassNotFoundException e) {
/* 2849 */           throw new ExceptionConverter(e);
/*      */         }
/*      */       }
/*      */     }
/* 2853 */     return element;
/*      */   }
/*      */   
/*      */   protected void flushStructureElementsOnNewPage() {
/* 2857 */     if (!this.isToUseExternalCache) {
/* 2858 */       return;
/*      */     }
/* 2860 */     Iterator<Map.Entry<AccessibleElementId, PdfStructureElement>> iterator = this.structElements.entrySet().iterator();
/*      */     
/* 2862 */     while (iterator.hasNext()) {
/* 2863 */       Map.Entry<AccessibleElementId, PdfStructureElement> entry = (Map.Entry)iterator.next();
/* 2864 */       if (!((PdfStructureElement)entry.getValue()).getStructureType().equals(PdfName.DOCUMENT))
/*      */       {
/*      */         try
/*      */         {
/* 2868 */           PdfStructureElement el = (PdfStructureElement)entry.getValue();
/* 2869 */           PdfDictionary parentDict = el.getParent();
/* 2870 */           PdfStructureElement parent = null;
/* 2871 */           if ((parentDict instanceof PdfStructureElement)) {
/* 2872 */             parent = (PdfStructureElement)parentDict;
/*      */           }
/* 2874 */           if (parent != null) {
/* 2875 */             this.elementsParents.put(entry.getKey(), parent.getElementId());
/*      */           }
/*      */           
/* 2878 */           TempFileCache.ObjectPosition pos = this.externalCache.put(el);
/* 2879 */           this.externallyStoredStructElements.put(entry.getKey(), pos);
/* 2880 */           iterator.remove();
/*      */         } catch (IOException e) {
/* 2882 */           throw new ExceptionConverter(e);
/*      */         } }
/*      */     }
/*      */   }
/*      */   
/*      */   public Set<AccessibleElementId> getStructElements() {
/* 2888 */     Set<AccessibleElementId> elements = new HashSet();
/* 2889 */     elements.addAll(this.externallyStoredStructElements.keySet());
/* 2890 */     elements.addAll(this.structElements.keySet());
/* 2891 */     return elements;
/*      */   }
/*      */   
/*      */   public class Destination
/*      */   {
/*      */     public PdfAction action;
/*      */     public PdfIndirectReference reference;
/*      */     public PdfDestination destination;
/*      */     
/*      */     public Destination() {}
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */