/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringUtils
/*     */ {
/*  51 */   private static final byte[] r = DocWriter.getISOBytes("\\r");
/*  52 */   private static final byte[] n = DocWriter.getISOBytes("\\n");
/*  53 */   private static final byte[] t = DocWriter.getISOBytes("\\t");
/*  54 */   private static final byte[] b = DocWriter.getISOBytes("\\b");
/*  55 */   private static final byte[] f = DocWriter.getISOBytes("\\f");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] escapeString(byte[] bytes)
/*     */   {
/*  68 */     ByteBuffer content = new ByteBuffer();
/*  69 */     escapeString(bytes, content);
/*  70 */     return content.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeString(byte[] bytes, ByteBuffer content)
/*     */   {
/*  80 */     content.append_i(40);
/*  81 */     for (int k = 0; k < bytes.length; k++) {
/*  82 */       byte c = bytes[k];
/*  83 */       switch (c) {
/*     */       case 13: 
/*  85 */         content.append(r);
/*  86 */         break;
/*     */       case 10: 
/*  88 */         content.append(n);
/*  89 */         break;
/*     */       case 9: 
/*  91 */         content.append(t);
/*  92 */         break;
/*     */       case 8: 
/*  94 */         content.append(b);
/*  95 */         break;
/*     */       case 12: 
/*  97 */         content.append(f);
/*  98 */         break;
/*     */       case 40: 
/*     */       case 41: 
/*     */       case 92: 
/* 102 */         content.append_i(92).append_i(c);
/* 103 */         break;
/*     */       default: 
/* 105 */         content.append_i(c);
/*     */       }
/*     */     }
/* 108 */     content.append_i(41);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] convertCharsToBytes(char[] chars)
/*     */   {
/* 120 */     byte[] result = new byte[chars.length * 2];
/* 121 */     for (int i = 0; i < chars.length; i++) {
/* 122 */       result[(2 * i)] = ((byte)(chars[i] / 'Ā'));
/* 123 */       result[(2 * i + 1)] = ((byte)(chars[i] % 'Ā'));
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/StringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */