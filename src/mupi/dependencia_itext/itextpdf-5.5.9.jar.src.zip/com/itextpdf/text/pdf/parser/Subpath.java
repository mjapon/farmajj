/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.awt.geom.Point2D;
/*     */ import com.itextpdf.awt.geom.Point2D.Float;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Subpath
/*     */ {
/*     */   private Point2D startPoint;
/*  62 */   private List<Shape> segments = new ArrayList();
/*     */   
/*     */ 
/*     */   private boolean closed;
/*     */   
/*     */ 
/*     */   public Subpath() {}
/*     */   
/*     */ 
/*     */   public Subpath(Subpath subpath)
/*     */   {
/*  73 */     this.startPoint = subpath.startPoint;
/*  74 */     this.segments.addAll(subpath.getSegments());
/*  75 */     this.closed = subpath.closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Subpath(Point2D startPoint)
/*     */   {
/*  82 */     this((float)startPoint.getX(), (float)startPoint.getY());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Subpath(float startPointX, float startPointY)
/*     */   {
/*  89 */     this.startPoint = new Point2D.Float(startPointX, startPointY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStartPoint(Point2D startPoint)
/*     */   {
/*  97 */     setStartPoint((float)startPoint.getX(), (float)startPoint.getY());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStartPoint(float x, float y)
/*     */   {
/* 106 */     this.startPoint = new Point2D.Float(x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Point2D getStartPoint()
/*     */   {
/* 113 */     return this.startPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Point2D getLastPoint()
/*     */   {
/* 120 */     Point2D lastPoint = this.startPoint;
/*     */     
/* 122 */     if ((this.segments.size() > 0) && (!this.closed)) {
/* 123 */       Shape shape = (Shape)this.segments.get(this.segments.size() - 1);
/* 124 */       lastPoint = (Point2D)shape.getBasePoints().get(shape.getBasePoints().size() - 1);
/*     */     }
/*     */     
/* 127 */     return lastPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSegment(Shape segment)
/*     */   {
/* 136 */     if (this.closed) {
/* 137 */       return;
/*     */     }
/*     */     
/* 140 */     if (isSinglePointOpen()) {
/* 141 */       this.startPoint = ((Point2D)segment.getBasePoints().get(0));
/*     */     }
/*     */     
/* 144 */     this.segments.add(segment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Shape> getSegments()
/*     */   {
/* 152 */     return this.segments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 160 */     return this.startPoint == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSinglePointOpen()
/*     */   {
/* 168 */     return (this.segments.size() == 0) && (!this.closed);
/*     */   }
/*     */   
/*     */   public boolean isSinglePointClosed() {
/* 172 */     return (this.segments.size() == 0) && (this.closed);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 184 */     return this.closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setClosed(boolean closed)
/*     */   {
/* 191 */     this.closed = closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDegenerate()
/*     */   {
/* 203 */     if ((this.segments.size() > 0) && (this.closed)) {
/* 204 */       return false;
/*     */     }
/*     */     
/* 207 */     for (Shape segment : this.segments) {
/* 208 */       Set<Point2D> points = new HashSet(segment.getBasePoints());
/*     */       
/*     */ 
/* 211 */       if (points.size() != 1) {
/* 212 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 217 */     return (this.segments.size() > 0) || (this.closed);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Point2D> getPiecewiseLinearApproximation()
/*     */   {
/* 226 */     List<Point2D> result = new ArrayList();
/*     */     
/* 228 */     if (this.segments.size() == 0) {
/* 229 */       return result;
/*     */     }
/*     */     
/* 232 */     if ((this.segments.get(0) instanceof BezierCurve)) {
/* 233 */       result.addAll(((BezierCurve)this.segments.get(0)).getPiecewiseLinearApproximation());
/*     */     } else {
/* 235 */       result.addAll(((Shape)this.segments.get(0)).getBasePoints());
/*     */     }
/*     */     
/* 238 */     for (int i = 1; i < this.segments.size(); i++)
/*     */     {
/*     */       List<Point2D> segApprox;
/* 241 */       if ((this.segments.get(i) instanceof BezierCurve)) {
/* 242 */         List<Point2D> segApprox = ((BezierCurve)this.segments.get(i)).getPiecewiseLinearApproximation();
/* 243 */         segApprox = segApprox.subList(1, segApprox.size());
/*     */       } else {
/* 245 */         segApprox = ((Shape)this.segments.get(i)).getBasePoints();
/* 246 */         segApprox = segApprox.subList(1, segApprox.size());
/*     */       }
/*     */       
/* 249 */       result.addAll(segApprox);
/*     */     }
/*     */     
/* 252 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/Subpath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */