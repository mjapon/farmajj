/*    */ package com.itextpdf.text.pdf.crypto;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IVGenerator
/*    */ {
/* 56 */   private static ARCFOUREncryption arcfour = new ARCFOUREncryption();
/* 57 */   static { long time = System.currentTimeMillis();
/* 58 */     long mem = Runtime.getRuntime().freeMemory();
/* 59 */     String s = time + "+" + mem;
/* 60 */     arcfour.prepareARCFOURKey(s.getBytes());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static byte[] getIV()
/*    */   {
/* 72 */     return getIV(16);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static byte[] getIV(int len)
/*    */   {
/* 81 */     byte[] b = new byte[len];
/* 82 */     synchronized (arcfour) {
/* 83 */       arcfour.encryptARCFOUR(b);
/*    */     }
/* 85 */     return b;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/crypto/IVGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */