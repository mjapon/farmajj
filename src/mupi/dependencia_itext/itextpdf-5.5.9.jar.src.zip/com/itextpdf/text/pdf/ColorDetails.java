/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ColorDetails
/*    */ {
/*    */   PdfIndirectReference indirectReference;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   PdfName colorSpaceName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ICachedColorSpace colorSpace;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ColorDetails(PdfName colorName, PdfIndirectReference indirectReference, ICachedColorSpace scolor)
/*    */   {
/* 69 */     this.colorSpaceName = colorName;
/* 70 */     this.indirectReference = indirectReference;
/* 71 */     this.colorSpace = scolor;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PdfIndirectReference getIndirectReference()
/*    */   {
/* 78 */     return this.indirectReference;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   PdfName getColorSpaceName()
/*    */   {
/* 85 */     return this.colorSpaceName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PdfObject getPdfObject(PdfWriter writer)
/*    */   {
/* 92 */     return this.colorSpace.getPdfObject(writer);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/ColorDetails.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */