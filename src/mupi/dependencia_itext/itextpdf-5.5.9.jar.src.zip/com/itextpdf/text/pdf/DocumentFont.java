/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Utilities;
/*     */ import com.itextpdf.text.io.RandomAccessSourceFactory;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CMapParserEx;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CMapToUnicode;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CidLocationFromByte;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentFont
/*     */   extends BaseFont
/*     */ {
/*  65 */   private HashMap<Integer, int[]> metrics = new HashMap();
/*     */   private String fontName;
/*     */   private PRIndirectReference refFont;
/*     */   private PdfDictionary font;
/*  69 */   private IntHashtable uni2byte = new IntHashtable();
/*  70 */   private IntHashtable byte2uni = new IntHashtable();
/*     */   private IntHashtable diffmap;
/*  72 */   private float ascender = 800.0F;
/*  73 */   private float capHeight = 700.0F;
/*  74 */   private float descender = -200.0F;
/*  75 */   private float italicAngle = 0.0F;
/*  76 */   private float fontWeight = 0.0F;
/*  77 */   private float llx = -50.0F;
/*  78 */   private float lly = -200.0F;
/*  79 */   private float urx = 100.0F;
/*  80 */   private float ury = 900.0F;
/*  81 */   protected boolean isType0 = false;
/*  82 */   protected int defaultWidth = 1000;
/*     */   
/*     */   private IntHashtable hMetrics;
/*     */   
/*     */   protected String cjkEncoding;
/*     */   protected String uniMap;
/*     */   private BaseFont cjkMirror;
/*  89 */   private static final int[] stdEnc = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 33, 34, 35, 36, 37, 38, 8217, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 8216, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 161, 162, 163, 8260, 165, 402, 167, 164, 39, 8220, 171, 8249, 8250, 64257, 64258, 0, 8211, 8224, 8225, 183, 0, 182, 8226, 8218, 8222, 8221, 187, 8230, 8240, 0, 191, 0, 96, 180, 710, 732, 175, 728, 729, 168, 0, 730, 184, 0, 733, 731, 711, 8212, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 198, 0, 170, 0, 0, 0, 0, 321, 216, 338, 186, 0, 0, 0, 0, 0, 230, 0, 0, 0, 305, 0, 0, 322, 248, 339, 223, 0, 0, 0, 0 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DocumentFont(PdfDictionary font)
/*     */   {
/* 109 */     this.refFont = null;
/* 110 */     this.font = font;
/* 111 */     init();
/*     */   }
/*     */   
/*     */   DocumentFont(PRIndirectReference refFont) {
/* 115 */     this.refFont = refFont;
/* 116 */     this.font = ((PdfDictionary)PdfReader.getPdfObject(refFont));
/* 117 */     init();
/*     */   }
/*     */   
/*     */   DocumentFont(PRIndirectReference refFont, PdfDictionary drEncoding) {
/* 121 */     this.refFont = refFont;
/* 122 */     this.font = ((PdfDictionary)PdfReader.getPdfObject(refFont));
/* 123 */     if ((this.font.get(PdfName.ENCODING) == null) && (drEncoding != null))
/*     */     {
/* 125 */       for (PdfName key : drEncoding.getKeys()) {
/* 126 */         this.font.put(PdfName.ENCODING, drEncoding.get(key));
/*     */       }
/*     */     }
/* 129 */     init();
/*     */   }
/*     */   
/*     */   public PdfDictionary getFontDictionary() {
/* 133 */     return this.font;
/*     */   }
/*     */   
/*     */   private void init() {
/* 137 */     this.encoding = "";
/* 138 */     this.fontSpecific = false;
/* 139 */     this.fontType = 4;
/* 140 */     PdfName baseFont = this.font.getAsName(PdfName.BASEFONT);
/* 141 */     this.fontName = (baseFont != null ? PdfName.decodeName(baseFont.toString()) : "Unspecified Font Name");
/* 142 */     PdfName subType = this.font.getAsName(PdfName.SUBTYPE);
/* 143 */     if ((PdfName.TYPE1.equals(subType)) || (PdfName.TRUETYPE.equals(subType))) {
/* 144 */       doType1TT();
/* 145 */     } else if (PdfName.TYPE3.equals(subType))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */       fillEncoding(null);
/* 152 */       fillDiffMap(this.font.getAsDict(PdfName.ENCODING), null);
/* 153 */       fillWidths();
/*     */     }
/*     */     else {
/* 156 */       PdfName encodingName = this.font.getAsName(PdfName.ENCODING);
/* 157 */       if (encodingName != null) {
/* 158 */         String enc = PdfName.decodeName(encodingName.toString());
/* 159 */         String ffontname = CJKFont.GetCompatibleFont(enc);
/* 160 */         if (ffontname != null) {
/*     */           try {
/* 162 */             this.cjkMirror = BaseFont.createFont(ffontname, enc, false);
/*     */           }
/*     */           catch (Exception e) {
/* 165 */             throw new ExceptionConverter(e);
/*     */           }
/* 167 */           this.cjkEncoding = enc;
/* 168 */           this.uniMap = ((CJKFont)this.cjkMirror).getUniMap();
/*     */         }
/* 170 */         if (PdfName.TYPE0.equals(subType)) {
/* 171 */           this.isType0 = true;
/* 172 */           if ((!enc.equals("Identity-H")) && (this.cjkMirror != null)) {
/* 173 */             PdfArray df = (PdfArray)PdfReader.getPdfObjectRelease(this.font.get(PdfName.DESCENDANTFONTS));
/* 174 */             PdfDictionary cidft = (PdfDictionary)PdfReader.getPdfObjectRelease(df.getPdfObject(0));
/* 175 */             PdfNumber dwo = (PdfNumber)PdfReader.getPdfObjectRelease(cidft.get(PdfName.DW));
/* 176 */             if (dwo != null)
/* 177 */               this.defaultWidth = dwo.intValue();
/* 178 */             this.hMetrics = readWidths((PdfArray)PdfReader.getPdfObjectRelease(cidft.get(PdfName.W)));
/*     */             
/* 180 */             PdfDictionary fontDesc = (PdfDictionary)PdfReader.getPdfObjectRelease(cidft.get(PdfName.FONTDESCRIPTOR));
/* 181 */             fillFontDesc(fontDesc);
/*     */           } else {
/* 183 */             processType0(this.font);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void processType0(PdfDictionary font) {
/*     */     try {
/* 192 */       PdfObject toUniObject = PdfReader.getPdfObjectRelease(font.get(PdfName.TOUNICODE));
/* 193 */       PdfArray df = (PdfArray)PdfReader.getPdfObjectRelease(font.get(PdfName.DESCENDANTFONTS));
/* 194 */       PdfDictionary cidft = (PdfDictionary)PdfReader.getPdfObjectRelease(df.getPdfObject(0));
/* 195 */       PdfNumber dwo = (PdfNumber)PdfReader.getPdfObjectRelease(cidft.get(PdfName.DW));
/* 196 */       int dw = 1000;
/* 197 */       if (dwo != null)
/* 198 */         dw = dwo.intValue();
/* 199 */       IntHashtable widths = readWidths((PdfArray)PdfReader.getPdfObjectRelease(cidft.get(PdfName.W)));
/* 200 */       PdfDictionary fontDesc = (PdfDictionary)PdfReader.getPdfObjectRelease(cidft.get(PdfName.FONTDESCRIPTOR));
/* 201 */       fillFontDesc(fontDesc);
/* 202 */       if ((toUniObject instanceof PRStream)) {
/* 203 */         fillMetrics(PdfReader.getStreamBytes((PRStream)toUniObject), widths, dw);
/* 204 */       } else if (new PdfName("Identity-H").equals(toUniObject)) {
/* 205 */         fillMetricsIdentity(widths, dw);
/*     */       }
/*     */     } catch (Exception e) {
/* 208 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private IntHashtable readWidths(PdfArray ws) {
/* 213 */     IntHashtable hh = new IntHashtable();
/* 214 */     if (ws == null)
/* 215 */       return hh;
/* 216 */     for (int k = 0; k < ws.size(); k++) {
/* 217 */       int c1 = ((PdfNumber)PdfReader.getPdfObjectRelease(ws.getPdfObject(k))).intValue();
/* 218 */       PdfObject obj = PdfReader.getPdfObjectRelease(ws.getPdfObject(++k));
/* 219 */       if (obj.isArray()) {
/* 220 */         PdfArray a2 = (PdfArray)obj;
/* 221 */         for (int j = 0; j < a2.size(); j++) {
/* 222 */           int c2 = ((PdfNumber)PdfReader.getPdfObjectRelease(a2.getPdfObject(j))).intValue();
/* 223 */           hh.put(c1++, c2);
/*     */         }
/*     */       }
/*     */       else {
/* 227 */         int c2 = ((PdfNumber)obj).intValue();
/* 228 */         int w = ((PdfNumber)PdfReader.getPdfObjectRelease(ws.getPdfObject(++k))).intValue();
/* 229 */         for (; c1 <= c2; c1++)
/* 230 */           hh.put(c1, w);
/*     */       }
/*     */     }
/* 233 */     return hh;
/*     */   }
/*     */   
/*     */   private String decodeString(PdfString ps) {
/* 237 */     if (ps.isHexWriting()) {
/* 238 */       return PdfEncodings.convertToString(ps.getBytes(), "UnicodeBigUnmarked");
/*     */     }
/* 240 */     return ps.toUnicodeString();
/*     */   }
/*     */   
/*     */   private void fillMetricsIdentity(IntHashtable widths, int dw) {
/* 244 */     for (int i = 0; i < 65536; i++) {
/* 245 */       int w = dw;
/* 246 */       if (widths.containsKey(i))
/* 247 */         w = widths.get(i);
/* 248 */       this.metrics.put(Integer.valueOf(i), new int[] { i, w });
/*     */     }
/*     */   }
/*     */   
/*     */   private void fillMetrics(byte[] touni, IntHashtable widths, int dw) {
/*     */     try {
/* 254 */       PdfContentParser ps = new PdfContentParser(new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(touni))));
/* 255 */       PdfObject ob = null;
/* 256 */       boolean notFound = true;
/* 257 */       int nestLevel = 0;
/* 258 */       int maxExc = 50;
/* 259 */       while ((notFound) || (nestLevel > 0)) {
/*     */         try {
/* 261 */           ob = ps.readPRObject();
/*     */         }
/*     */         catch (Exception ex) {
/* 264 */           maxExc--; if (maxExc >= 0) break label80; }
/* 265 */         break;
/* 266 */         label80: continue;
/*     */         
/* 268 */         if (ob != null)
/*     */         {
/* 270 */           if (ob.type() == 200) {
/* 271 */             if (ob.toString().equals("begin")) {
/* 272 */               notFound = false;
/* 273 */               nestLevel++;
/*     */             }
/* 275 */             else if (ob.toString().equals("end")) {
/* 276 */               nestLevel--;
/*     */             } else {
/* 278 */               if (ob.toString().equals("beginbfchar")) {
/*     */                 for (;;) {
/* 280 */                   PdfObject nx = ps.readPRObject();
/* 281 */                   if (nx.toString().equals("endbfchar"))
/*     */                     break;
/* 283 */                   String cid = decodeString((PdfString)nx);
/* 284 */                   String uni = decodeString((PdfString)ps.readPRObject());
/* 285 */                   if (uni.length() == 1) {
/* 286 */                     int cidc = cid.charAt(0);
/* 287 */                     int unic = uni.charAt(uni.length() - 1);
/* 288 */                     int w = dw;
/* 289 */                     if (widths.containsKey(cidc))
/* 290 */                       w = widths.get(cidc);
/* 291 */                     this.metrics.put(Integer.valueOf(unic), new int[] { cidc, w });
/*     */                   }
/*     */                 }
/*     */               }
/* 295 */               if (ob.toString().equals("beginbfrange")) {
/*     */                 for (;;) {
/* 297 */                   PdfObject nx = ps.readPRObject();
/* 298 */                   if (nx.toString().equals("endbfrange"))
/*     */                     break;
/* 300 */                   String cid1 = decodeString((PdfString)nx);
/* 301 */                   String cid2 = decodeString((PdfString)ps.readPRObject());
/* 302 */                   int cid1c = cid1.charAt(0);
/* 303 */                   int cid2c = cid2.charAt(0);
/* 304 */                   PdfObject ob2 = ps.readPRObject();
/* 305 */                   if (ob2.isString()) {
/* 306 */                     String uni = decodeString((PdfString)ob2);
/* 307 */                     if (uni.length() == 1) {
/* 308 */                       for (int unic = uni.charAt(uni.length() - 1); 
/* 309 */                           cid1c <= cid2c; unic++) {
/* 310 */                         int w = dw;
/* 311 */                         if (widths.containsKey(cid1c))
/* 312 */                           w = widths.get(cid1c);
/* 313 */                         this.metrics.put(Integer.valueOf(unic), new int[] { cid1c, w });cid1c++;
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                   else {
/* 318 */                     PdfArray a = (PdfArray)ob2;
/* 319 */                     for (int j = 0; j < a.size(); cid1c++) {
/* 320 */                       String uni = decodeString(a.getAsString(j));
/* 321 */                       if (uni.length() == 1) {
/* 322 */                         int unic = uni.charAt(uni.length() - 1);
/* 323 */                         int w = dw;
/* 324 */                         if (widths.containsKey(cid1c))
/* 325 */                           w = widths.get(cid1c);
/* 326 */                         this.metrics.put(Integer.valueOf(unic), new int[] { cid1c, w });
/*     */                       }
/* 319 */                       j++;
/*     */                     }
/*     */                     
/*     */                   }
/*     */                   
/*     */                 }
/*     */                 
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 336 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doType1TT() {
/* 341 */     CMapToUnicode toUnicode = null;
/* 342 */     PdfObject enc = PdfReader.getPdfObject(this.font.get(PdfName.ENCODING));
/* 343 */     if (enc == null) {
/* 344 */       PdfName baseFont = this.font.getAsName(PdfName.BASEFONT);
/* 345 */       if ((BuiltinFonts14.containsKey(this.fontName)) && (
/* 346 */         (PdfName.SYMBOL.equals(baseFont)) || (PdfName.ZAPFDINGBATS.equals(baseFont)))) {
/* 347 */         fillEncoding(baseFont);
/*     */       } else
/* 349 */         fillEncoding(null);
/*     */       try {
/* 351 */         toUnicode = processToUnicode();
/* 352 */         if (toUnicode != null) {
/* 353 */           Map<Integer, Integer> rm = toUnicode.createReverseMapping();
/* 354 */           for (Map.Entry<Integer, Integer> kv : rm.entrySet()) {
/* 355 */             this.uni2byte.put(((Integer)kv.getKey()).intValue(), ((Integer)kv.getValue()).intValue());
/* 356 */             this.byte2uni.put(((Integer)kv.getValue()).intValue(), ((Integer)kv.getKey()).intValue());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 361 */         throw new ExceptionConverter(ex);
/*     */       }
/*     */       
/*     */     }
/* 365 */     else if (enc.isName()) {
/* 366 */       fillEncoding((PdfName)enc);
/* 367 */     } else if (enc.isDictionary()) {
/* 368 */       PdfDictionary encDic = (PdfDictionary)enc;
/* 369 */       enc = PdfReader.getPdfObject(encDic.get(PdfName.BASEENCODING));
/* 370 */       if (enc == null) {
/* 371 */         fillEncoding(null);
/*     */       } else
/* 373 */         fillEncoding((PdfName)enc);
/* 374 */       fillDiffMap(encDic, toUnicode);
/*     */     }
/*     */     
/*     */ 
/* 378 */     if (BuiltinFonts14.containsKey(this.fontName))
/*     */     {
/*     */       try {
/* 381 */         bf = BaseFont.createFont(this.fontName, "Cp1252", false);
/*     */       } catch (Exception e) {
/*     */         BaseFont bf;
/* 384 */         throw new ExceptionConverter(e); }
/*     */       BaseFont bf;
/* 386 */       int[] e = this.uni2byte.toOrderedKeys();
/* 387 */       for (int k = 0; k < e.length; k++) {
/* 388 */         int n = this.uni2byte.get(e[k]);
/* 389 */         this.widths[n] = bf.getRawWidth(n, GlyphList.unicodeToName(e[k]));
/*     */       }
/* 391 */       if (this.diffmap != null) {
/* 392 */         e = this.diffmap.toOrderedKeys();
/* 393 */         for (int k = 0; k < e.length; k++) {
/* 394 */           int n = this.diffmap.get(e[k]);
/* 395 */           this.widths[n] = bf.getRawWidth(n, GlyphList.unicodeToName(e[k]));
/*     */         }
/* 397 */         this.diffmap = null;
/*     */       }
/* 399 */       this.ascender = bf.getFontDescriptor(1, 1000.0F);
/* 400 */       this.capHeight = bf.getFontDescriptor(2, 1000.0F);
/* 401 */       this.descender = bf.getFontDescriptor(3, 1000.0F);
/* 402 */       this.italicAngle = bf.getFontDescriptor(4, 1000.0F);
/* 403 */       this.fontWeight = bf.getFontDescriptor(23, 1000.0F);
/* 404 */       this.llx = bf.getFontDescriptor(5, 1000.0F);
/* 405 */       this.lly = bf.getFontDescriptor(6, 1000.0F);
/* 406 */       this.urx = bf.getFontDescriptor(7, 1000.0F);
/* 407 */       this.ury = bf.getFontDescriptor(8, 1000.0F);
/*     */     }
/* 409 */     fillWidths();
/* 410 */     fillFontDesc(this.font.getAsDict(PdfName.FONTDESCRIPTOR));
/*     */   }
/*     */   
/*     */   private void fillWidths() {
/* 414 */     PdfArray newWidths = this.font.getAsArray(PdfName.WIDTHS);
/* 415 */     PdfNumber first = this.font.getAsNumber(PdfName.FIRSTCHAR);
/* 416 */     PdfNumber last = this.font.getAsNumber(PdfName.LASTCHAR);
/* 417 */     if ((first != null) && (last != null) && (newWidths != null)) {
/* 418 */       int f = first.intValue();
/* 419 */       int nSize = f + newWidths.size();
/* 420 */       if (this.widths.length < nSize) {
/* 421 */         int[] tmp = new int[nSize];
/* 422 */         System.arraycopy(this.widths, 0, tmp, 0, f);
/* 423 */         this.widths = tmp;
/*     */       }
/* 425 */       for (int k = 0; k < newWidths.size(); k++) {
/* 426 */         this.widths[(f + k)] = newWidths.getAsNumber(k).intValue();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void fillDiffMap(PdfDictionary encDic, CMapToUnicode toUnicode) {
/* 432 */     PdfArray diffs = encDic.getAsArray(PdfName.DIFFERENCES);
/* 433 */     if (diffs != null) {
/* 434 */       this.diffmap = new IntHashtable();
/* 435 */       int currentNumber = 0;
/* 436 */       for (int k = 0; k < diffs.size(); k++) {
/* 437 */         PdfObject obj = diffs.getPdfObject(k);
/* 438 */         if (obj.isNumber()) {
/* 439 */           currentNumber = ((PdfNumber)obj).intValue();
/*     */         } else {
/* 441 */           int[] c = GlyphList.nameToUnicode(PdfName.decodeName(((PdfName)obj).toString()));
/* 442 */           if ((c != null) && (c.length > 0)) {
/* 443 */             this.uni2byte.put(c[0], currentNumber);
/* 444 */             this.byte2uni.put(currentNumber, c[0]);
/* 445 */             this.diffmap.put(c[0], currentNumber);
/*     */           }
/*     */           else {
/* 448 */             if (toUnicode == null) {
/* 449 */               toUnicode = processToUnicode();
/* 450 */               if (toUnicode == null) {
/* 451 */                 toUnicode = new CMapToUnicode();
/*     */               }
/*     */             }
/* 454 */             String unicode = toUnicode.lookup(new byte[] { (byte)currentNumber }, 0, 1);
/* 455 */             if ((unicode != null) && (unicode.length() == 1)) {
/* 456 */               this.uni2byte.put(unicode.charAt(0), currentNumber);
/* 457 */               this.byte2uni.put(currentNumber, unicode.charAt(0));
/* 458 */               this.diffmap.put(unicode.charAt(0), currentNumber);
/*     */             }
/*     */           }
/* 461 */           currentNumber++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private CMapToUnicode processToUnicode() {
/* 468 */     CMapToUnicode cmapRet = null;
/* 469 */     PdfObject toUni = PdfReader.getPdfObjectRelease(this.font.get(PdfName.TOUNICODE));
/* 470 */     if ((toUni instanceof PRStream)) {
/*     */       try {
/* 472 */         byte[] touni = PdfReader.getStreamBytes((PRStream)toUni);
/* 473 */         CidLocationFromByte lb = new CidLocationFromByte(touni);
/* 474 */         cmapRet = new CMapToUnicode();
/* 475 */         CMapParserEx.parseCid("", cmapRet, lb);
/*     */       } catch (Exception e) {
/* 477 */         cmapRet = null;
/*     */       }
/*     */     }
/* 480 */     return cmapRet;
/*     */   }
/*     */   
/*     */   private void fillFontDesc(PdfDictionary fontDesc) {
/* 484 */     if (fontDesc == null)
/* 485 */       return;
/* 486 */     PdfNumber v = fontDesc.getAsNumber(PdfName.ASCENT);
/* 487 */     if (v != null)
/* 488 */       this.ascender = v.floatValue();
/* 489 */     v = fontDesc.getAsNumber(PdfName.CAPHEIGHT);
/* 490 */     if (v != null)
/* 491 */       this.capHeight = v.floatValue();
/* 492 */     v = fontDesc.getAsNumber(PdfName.DESCENT);
/* 493 */     if (v != null)
/* 494 */       this.descender = v.floatValue();
/* 495 */     v = fontDesc.getAsNumber(PdfName.ITALICANGLE);
/* 496 */     if (v != null)
/* 497 */       this.italicAngle = v.floatValue();
/* 498 */     v = fontDesc.getAsNumber(PdfName.FONTWEIGHT);
/* 499 */     if (v != null) {
/* 500 */       this.fontWeight = v.floatValue();
/*     */     }
/* 502 */     PdfArray bbox = fontDesc.getAsArray(PdfName.FONTBBOX);
/* 503 */     if (bbox != null) {
/* 504 */       this.llx = bbox.getAsNumber(0).floatValue();
/* 505 */       this.lly = bbox.getAsNumber(1).floatValue();
/* 506 */       this.urx = bbox.getAsNumber(2).floatValue();
/* 507 */       this.ury = bbox.getAsNumber(3).floatValue();
/* 508 */       if (this.llx > this.urx) {
/* 509 */         float t = this.llx;
/* 510 */         this.llx = this.urx;
/* 511 */         this.urx = t;
/*     */       }
/* 513 */       if (this.lly > this.ury) {
/* 514 */         float t = this.lly;
/* 515 */         this.lly = this.ury;
/* 516 */         this.ury = t;
/*     */       }
/*     */     }
/* 519 */     float maxAscent = Math.max(this.ury, this.ascender);
/* 520 */     float minDescent = Math.min(this.lly, this.descender);
/* 521 */     this.ascender = (maxAscent * 1000.0F / (maxAscent - minDescent));
/* 522 */     this.descender = (minDescent * 1000.0F / (maxAscent - minDescent));
/*     */   }
/*     */   
/*     */   private void fillEncoding(PdfName encoding) {
/* 526 */     if ((encoding == null) && (isSymbolic())) {
/* 527 */       for (int k = 0; k < 256; k++) {
/* 528 */         this.uni2byte.put(k, k);
/* 529 */         this.byte2uni.put(k, k);
/*     */       }
/* 531 */     } else if ((PdfName.MAC_ROMAN_ENCODING.equals(encoding)) || (PdfName.WIN_ANSI_ENCODING.equals(encoding)) || 
/* 532 */       (PdfName.SYMBOL.equals(encoding)) || (PdfName.ZAPFDINGBATS.equals(encoding))) {
/* 533 */       byte[] b = new byte['Ā'];
/* 534 */       for (int k = 0; k < 256; k++)
/* 535 */         b[k] = ((byte)k);
/* 536 */       String enc = "Cp1252";
/* 537 */       if (PdfName.MAC_ROMAN_ENCODING.equals(encoding)) {
/* 538 */         enc = "MacRoman";
/* 539 */       } else if (PdfName.SYMBOL.equals(encoding)) {
/* 540 */         enc = "Symbol";
/* 541 */       } else if (PdfName.ZAPFDINGBATS.equals(encoding))
/* 542 */         enc = "ZapfDingbats";
/* 543 */       String cv = PdfEncodings.convertToString(b, enc);
/* 544 */       char[] arr = cv.toCharArray();
/* 545 */       for (int k = 0; k < 256; k++) {
/* 546 */         this.uni2byte.put(arr[k], k);
/* 547 */         this.byte2uni.put(k, arr[k]);
/*     */       }
/* 549 */       this.encoding = enc;
/*     */     }
/*     */     else {
/* 552 */       for (int k = 0; k < 256; k++) {
/* 553 */         this.uni2byte.put(stdEnc[k], k);
/* 554 */         this.byte2uni.put(k, stdEnc[k]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getFamilyFontName()
/*     */   {
/* 570 */     return getFullFontName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getFontDescriptor(int key, float fontSize)
/*     */   {
/* 584 */     if (this.cjkMirror != null)
/* 585 */       return this.cjkMirror.getFontDescriptor(key, fontSize);
/* 586 */     switch (key) {
/*     */     case 1: 
/*     */     case 9: 
/* 589 */       return this.ascender * fontSize / 1000.0F;
/*     */     case 2: 
/* 591 */       return this.capHeight * fontSize / 1000.0F;
/*     */     case 3: 
/*     */     case 10: 
/* 594 */       return this.descender * fontSize / 1000.0F;
/*     */     case 4: 
/* 596 */       return this.italicAngle;
/*     */     case 5: 
/* 598 */       return this.llx * fontSize / 1000.0F;
/*     */     case 6: 
/* 600 */       return this.lly * fontSize / 1000.0F;
/*     */     case 7: 
/* 602 */       return this.urx * fontSize / 1000.0F;
/*     */     case 8: 
/* 604 */       return this.ury * fontSize / 1000.0F;
/*     */     case 11: 
/* 606 */       return 0.0F;
/*     */     case 12: 
/* 608 */       return (this.urx - this.llx) * fontSize / 1000.0F;
/*     */     case 23: 
/* 610 */       return this.fontWeight * fontSize / 1000.0F;
/*     */     }
/* 612 */     return 0.0F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getFullFontName()
/*     */   {
/* 626 */     return new String[][] { { "", "", "", this.fontName } };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getAllNameEntries()
/*     */   {
/* 640 */     return new String[][] { { "4", "", "", "", this.fontName } };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getKerning(int char1, int char2)
/*     */   {
/* 651 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPostscriptFontName()
/*     */   {
/* 660 */     return this.fontName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getRawWidth(int c, String name)
/*     */   {
/* 672 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasKernPairs()
/*     */   {
/* 681 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void writeFont(PdfWriter writer, PdfIndirectReference ref, Object[] params)
/*     */     throws DocumentException, IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStream getFullFontStream()
/*     */   {
/* 703 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth(int char1)
/*     */   {
/* 713 */     if (this.isType0) {
/* 714 */       if ((this.hMetrics != null) && (this.cjkMirror != null) && (!this.cjkMirror.isVertical())) {
/* 715 */         int c = this.cjkMirror.getCidCode(char1);
/* 716 */         int v = this.hMetrics.get(c);
/* 717 */         if (v > 0) {
/* 718 */           return v;
/*     */         }
/* 720 */         return this.defaultWidth;
/*     */       }
/* 722 */       int[] ws = (int[])this.metrics.get(Integer.valueOf(char1));
/* 723 */       if (ws != null) {
/* 724 */         return ws[1];
/*     */       }
/* 726 */       return 0;
/*     */     }
/*     */     
/* 729 */     if (this.cjkMirror != null)
/* 730 */       return this.cjkMirror.getWidth(char1);
/* 731 */     return super.getWidth(char1);
/*     */   }
/*     */   
/*     */   public int getWidth(String text)
/*     */   {
/* 736 */     if (this.isType0) {
/* 737 */       int total = 0;
/* 738 */       if ((this.hMetrics != null) && (this.cjkMirror != null) && (!this.cjkMirror.isVertical())) {
/* 739 */         if (((CJKFont)this.cjkMirror).isIdentity()) {
/* 740 */           for (int k = 0; k < text.length(); k++) {
/* 741 */             total += getWidth(text.charAt(k));
/*     */           }
/*     */           
/*     */         } else {
/* 745 */           for (int k = 0; k < text.length(); k++) {
/*     */             int val;
/* 747 */             if (Utilities.isSurrogatePair(text, k)) {
/* 748 */               int val = Utilities.convertToUtf32(text, k);
/* 749 */               k++;
/*     */             }
/*     */             else {
/* 752 */               val = text.charAt(k);
/*     */             }
/* 754 */             total += getWidth(val);
/*     */           }
/*     */         }
/*     */       } else {
/* 758 */         char[] chars = text.toCharArray();
/* 759 */         int len = chars.length;
/* 760 */         for (int k = 0; k < len; k++) {
/* 761 */           int[] ws = (int[])this.metrics.get(Integer.valueOf(chars[k]));
/* 762 */           if (ws != null)
/* 763 */             total += ws[1];
/*     */         }
/*     */       }
/* 766 */       return total;
/*     */     }
/* 768 */     if (this.cjkMirror != null)
/* 769 */       return this.cjkMirror.getWidth(text);
/* 770 */     return super.getWidth(text);
/*     */   }
/*     */   
/*     */   public byte[] convertToBytes(String text)
/*     */   {
/* 775 */     if (this.cjkMirror != null)
/* 776 */       return this.cjkMirror.convertToBytes(text);
/* 777 */     if (this.isType0) {
/* 778 */       char[] chars = text.toCharArray();
/* 779 */       int len = chars.length;
/* 780 */       byte[] b = new byte[len * 2];
/* 781 */       int bptr = 0;
/* 782 */       for (int k = 0; k < len; k++) {
/* 783 */         int[] ws = (int[])this.metrics.get(Integer.valueOf(chars[k]));
/* 784 */         if (ws != null) {
/* 785 */           int g = ws[0];
/* 786 */           b[(bptr++)] = ((byte)(g / 256));
/* 787 */           b[(bptr++)] = ((byte)g);
/*     */         }
/*     */       }
/* 790 */       if (bptr == b.length) {
/* 791 */         return b;
/*     */       }
/* 793 */       byte[] nb = new byte[bptr];
/* 794 */       System.arraycopy(b, 0, nb, 0, bptr);
/* 795 */       return nb;
/*     */     }
/*     */     
/*     */ 
/* 799 */     char[] cc = text.toCharArray();
/* 800 */     byte[] b = new byte[cc.length];
/* 801 */     int ptr = 0;
/* 802 */     for (int k = 0; k < cc.length; k++) {
/* 803 */       if (this.uni2byte.containsKey(cc[k]))
/* 804 */         b[(ptr++)] = ((byte)this.uni2byte.get(cc[k]));
/*     */     }
/* 806 */     if (ptr == b.length) {
/* 807 */       return b;
/*     */     }
/* 809 */     byte[] b2 = new byte[ptr];
/* 810 */     System.arraycopy(b, 0, b2, 0, ptr);
/* 811 */     return b2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   byte[] convertToBytes(int char1)
/*     */   {
/* 818 */     if (this.cjkMirror != null)
/* 819 */       return this.cjkMirror.convertToBytes(char1);
/* 820 */     if (this.isType0) {
/* 821 */       int[] ws = (int[])this.metrics.get(Integer.valueOf(char1));
/* 822 */       if (ws != null) {
/* 823 */         int g = ws[0];
/* 824 */         return new byte[] { (byte)(g / 256), (byte)g };
/*     */       }
/*     */       
/* 827 */       return new byte[0];
/*     */     }
/*     */     
/* 830 */     if (this.uni2byte.containsKey(char1)) {
/* 831 */       return new byte[] { (byte)this.uni2byte.get(char1) };
/*     */     }
/* 833 */     return new byte[0];
/*     */   }
/*     */   
/*     */   PdfIndirectReference getIndirectReference()
/*     */   {
/* 838 */     if (this.refFont == null)
/* 839 */       throw new IllegalArgumentException("Font reuse not allowed with direct font objects.");
/* 840 */     return this.refFont;
/*     */   }
/*     */   
/*     */   public boolean charExists(int c)
/*     */   {
/* 845 */     if (this.cjkMirror != null)
/* 846 */       return this.cjkMirror.charExists(c);
/* 847 */     if (this.isType0) {
/* 848 */       return this.metrics.containsKey(Integer.valueOf(c));
/*     */     }
/*     */     
/* 851 */     return super.charExists(c);
/*     */   }
/*     */   
/*     */   public double[] getFontMatrix()
/*     */   {
/* 856 */     if (this.font.getAsArray(PdfName.FONTMATRIX) != null) {
/* 857 */       return this.font.getAsArray(PdfName.FONTMATRIX).asDoubleArray();
/*     */     }
/* 859 */     return DEFAULT_FONT_MATRIX;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPostscriptFontName(String name) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setKerning(int char1, int char2, int kern)
/*     */   {
/* 874 */     return false;
/*     */   }
/*     */   
/*     */   public int[] getCharBBox(int c)
/*     */   {
/* 879 */     return null;
/*     */   }
/*     */   
/*     */   protected int[] getRawCharBBox(int c, String name)
/*     */   {
/* 884 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isVertical()
/*     */   {
/* 889 */     if (this.cjkMirror != null) {
/* 890 */       return this.cjkMirror.isVertical();
/*     */     }
/* 892 */     return super.isVertical();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   IntHashtable getUni2Byte()
/*     */   {
/* 901 */     return this.uni2byte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   IntHashtable getByte2Uni()
/*     */   {
/* 910 */     return this.byte2uni;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   IntHashtable getDiffmap()
/*     */   {
/* 919 */     return this.diffmap;
/*     */   }
/*     */   
/*     */   boolean isSymbolic() {
/* 923 */     PdfDictionary fontDescriptor = this.font.getAsDict(PdfName.FONTDESCRIPTOR);
/* 924 */     if (fontDescriptor == null)
/* 925 */       return false;
/* 926 */     PdfNumber flags = fontDescriptor.getAsNumber(PdfName.FLAGS);
/* 927 */     if (flags == null)
/* 928 */       return false;
/* 929 */     return (flags.intValue() & 0x4) != 0;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/DocumentFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */