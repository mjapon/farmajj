/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationTextExtractionStrategy
/*     */   implements TextExtractionStrategy
/*     */ {
/*  74 */   static boolean DUMP_STATE = false;
/*     */   
/*     */ 
/*  77 */   private final List<TextChunk> locationalResult = new ArrayList();
/*     */   
/*     */ 
/*     */   private final TextChunkLocationStrategy tclStrat;
/*     */   
/*     */ 
/*     */ 
/*     */   public LocationTextExtractionStrategy()
/*     */   {
/*  86 */     this(new TextChunkLocationStrategy() {
/*     */       public LocationTextExtractionStrategy.TextChunkLocation createLocation(TextRenderInfo renderInfo, LineSegment baseline) {
/*  88 */         return new LocationTextExtractionStrategy.TextChunkLocationDefaultImp(baseline.getStartPoint(), baseline.getEndPoint(), renderInfo.getSingleSpaceWidth());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LocationTextExtractionStrategy(TextChunkLocationStrategy strat)
/*     */   {
/* 100 */     this.tclStrat = strat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beginTextBlock() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endTextBlock() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean startsWithSpace(String str)
/*     */   {
/* 120 */     if (str.length() == 0) return false;
/* 121 */     return str.charAt(0) == ' ';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean endsWithSpace(String str)
/*     */   {
/* 129 */     if (str.length() == 0) return false;
/* 130 */     return str.charAt(str.length() - 1) == ' ';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<TextChunk> filterTextChunks(List<TextChunk> textChunks, TextChunkFilter filter)
/*     */   {
/* 141 */     if (filter == null) {
/* 142 */       return textChunks;
/*     */     }
/* 144 */     List<TextChunk> filtered = new ArrayList();
/* 145 */     for (TextChunk textChunk : textChunks) {
/* 146 */       if (filter.accept(textChunk))
/* 147 */         filtered.add(textChunk);
/*     */     }
/* 149 */     return filtered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isChunkAtWordBoundary(TextChunk chunk, TextChunk previousChunk)
/*     */   {
/* 163 */     return chunk.getLocation().isAtWordBoundary(previousChunk.getLocation());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResultantText(TextChunkFilter chunkFilter)
/*     */   {
/* 175 */     if (DUMP_STATE) { dumpState();
/*     */     }
/* 177 */     List<TextChunk> filteredTextChunks = filterTextChunks(this.locationalResult, chunkFilter);
/* 178 */     Collections.sort(filteredTextChunks);
/*     */     
/* 180 */     StringBuilder sb = new StringBuilder();
/* 181 */     TextChunk lastChunk = null;
/* 182 */     for (TextChunk chunk : filteredTextChunks)
/*     */     {
/* 184 */       if (lastChunk == null) {
/* 185 */         sb.append(chunk.text);
/*     */       }
/* 187 */       else if (chunk.sameLine(lastChunk))
/*     */       {
/* 189 */         if ((isChunkAtWordBoundary(chunk, lastChunk)) && (!startsWithSpace(chunk.text)) && (!endsWithSpace(lastChunk.text))) {
/* 190 */           sb.append(' ');
/*     */         }
/* 192 */         sb.append(chunk.text);
/*     */       } else {
/* 194 */         sb.append('\n');
/* 195 */         sb.append(chunk.text);
/*     */       }
/*     */       
/* 198 */       lastChunk = chunk;
/*     */     }
/*     */     
/* 201 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResultantText()
/*     */   {
/* 210 */     return getResultantText(null);
/*     */   }
/*     */   
/*     */ 
/*     */   private void dumpState()
/*     */   {
/* 216 */     for (TextChunk location : this.locationalResult) {
/* 217 */       location.printDiagnostics();
/*     */       
/* 219 */       System.out.println();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void renderText(TextRenderInfo renderInfo)
/*     */   {
/* 229 */     LineSegment segment = renderInfo.getBaseline();
/* 230 */     if (renderInfo.getRise() != 0.0F) {
/* 231 */       Matrix riseOffsetTransform = new Matrix(0.0F, -renderInfo.getRise());
/* 232 */       segment = segment.transformBy(riseOffsetTransform);
/*     */     }
/* 234 */     TextChunk tc = new TextChunk(renderInfo.getText(), this.tclStrat.createLocation(renderInfo, segment));
/* 235 */     this.locationalResult.add(tc);
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface TextChunkLocationStrategy
/*     */   {
/*     */     public abstract LocationTextExtractionStrategy.TextChunkLocation createLocation(TextRenderInfo paramTextRenderInfo, LineSegment paramLineSegment);
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface TextChunkLocation
/*     */     extends Comparable<TextChunkLocation>
/*     */   {
/*     */     public abstract float distParallelEnd();
/*     */     
/*     */ 
/*     */     public abstract float distParallelStart();
/*     */     
/*     */ 
/*     */     public abstract int distPerpendicular();
/*     */     
/*     */ 
/*     */     public abstract float getCharSpaceWidth();
/*     */     
/*     */     public abstract Vector getEndLocation();
/*     */     
/*     */     public abstract Vector getStartLocation();
/*     */     
/*     */     public abstract int orientationMagnitude();
/*     */     
/*     */     public abstract boolean sameLine(TextChunkLocation paramTextChunkLocation);
/*     */     
/*     */     public abstract float distanceFromEndOf(TextChunkLocation paramTextChunkLocation);
/*     */     
/*     */     public abstract boolean isAtWordBoundary(TextChunkLocation paramTextChunkLocation);
/*     */   }
/*     */   
/*     */   private static class TextChunkLocationDefaultImp
/*     */     implements LocationTextExtractionStrategy.TextChunkLocation
/*     */   {
/*     */     private final Vector startLocation;
/*     */     private final Vector endLocation;
/*     */     private final Vector orientationVector;
/*     */     private final int orientationMagnitude;
/*     */     private final int distPerpendicular;
/*     */     private final float distParallelStart;
/*     */     private final float distParallelEnd;
/*     */     private final float charSpaceWidth;
/*     */     
/*     */     public TextChunkLocationDefaultImp(Vector startLocation, Vector endLocation, float charSpaceWidth)
/*     */     {
/* 286 */       this.startLocation = startLocation;
/* 287 */       this.endLocation = endLocation;
/* 288 */       this.charSpaceWidth = charSpaceWidth;
/*     */       
/* 290 */       Vector oVector = endLocation.subtract(startLocation);
/* 291 */       if (oVector.length() == 0.0F) {
/* 292 */         oVector = new Vector(1.0F, 0.0F, 0.0F);
/*     */       }
/* 294 */       this.orientationVector = oVector.normalize();
/* 295 */       this.orientationMagnitude = ((int)(Math.atan2(this.orientationVector.get(1), this.orientationVector.get(0)) * 1000.0D));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 300 */       Vector origin = new Vector(0.0F, 0.0F, 1.0F);
/* 301 */       this.distPerpendicular = ((int)startLocation.subtract(origin).cross(this.orientationVector).get(2));
/*     */       
/* 303 */       this.distParallelStart = this.orientationVector.dot(startLocation);
/* 304 */       this.distParallelEnd = this.orientationVector.dot(endLocation);
/*     */     }
/*     */     
/*     */ 
/* 308 */     public int orientationMagnitude() { return this.orientationMagnitude; }
/* 309 */     public int distPerpendicular() { return this.distPerpendicular; }
/* 310 */     public float distParallelStart() { return this.distParallelStart; }
/* 311 */     public float distParallelEnd() { return this.distParallelEnd; }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Vector getStartLocation()
/*     */     {
/* 318 */       return this.startLocation;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Vector getEndLocation()
/*     */     {
/* 325 */       return this.endLocation;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public float getCharSpaceWidth()
/*     */     {
/* 332 */       return this.charSpaceWidth;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean sameLine(LocationTextExtractionStrategy.TextChunkLocation as)
/*     */     {
/* 341 */       return (orientationMagnitude() == as.orientationMagnitude()) && (distPerpendicular() == as.distPerpendicular());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public float distanceFromEndOf(LocationTextExtractionStrategy.TextChunkLocation other)
/*     */     {
/* 353 */       float distance = distParallelStart() - other.distParallelEnd();
/* 354 */       return distance;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isAtWordBoundary(LocationTextExtractionStrategy.TextChunkLocation previous)
/*     */     {
/* 366 */       if (getCharSpaceWidth() < 0.1F) {
/* 367 */         return false;
/*     */       }
/* 369 */       float dist = distanceFromEndOf(previous);
/*     */       
/* 371 */       return (dist < -getCharSpaceWidth()) || (dist > getCharSpaceWidth() / 2.0F);
/*     */     }
/*     */     
/*     */     public int compareTo(LocationTextExtractionStrategy.TextChunkLocation other) {
/* 375 */       if (this == other) { return 0;
/*     */       }
/*     */       
/* 378 */       int rslt = LocationTextExtractionStrategy.compareInts(orientationMagnitude(), other.orientationMagnitude());
/* 379 */       if (rslt != 0) { return rslt;
/*     */       }
/* 381 */       rslt = LocationTextExtractionStrategy.compareInts(distPerpendicular(), other.distPerpendicular());
/* 382 */       if (rslt != 0) { return rslt;
/*     */       }
/* 384 */       return Float.compare(distParallelStart(), other.distParallelStart());
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TextChunk
/*     */     implements Comparable<TextChunk>
/*     */   {
/*     */     private final String text;
/*     */     private final LocationTextExtractionStrategy.TextChunkLocation location;
/*     */     
/*     */     public TextChunk(String string, Vector startLocation, Vector endLocation, float charSpaceWidth)
/*     */     {
/* 396 */       this(string, new LocationTextExtractionStrategy.TextChunkLocationDefaultImp(startLocation, endLocation, charSpaceWidth));
/*     */     }
/*     */     
/*     */     public TextChunk(String string, LocationTextExtractionStrategy.TextChunkLocation loc) {
/* 400 */       this.text = string;
/* 401 */       this.location = loc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getText()
/*     */     {
/* 408 */       return this.text;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public LocationTextExtractionStrategy.TextChunkLocation getLocation()
/*     */     {
/* 415 */       return this.location;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Vector getStartLocation()
/*     */     {
/* 422 */       return this.location.getStartLocation();
/*     */     }
/*     */     
/*     */ 
/*     */     public Vector getEndLocation()
/*     */     {
/* 428 */       return this.location.getEndLocation();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public float getCharSpaceWidth()
/*     */     {
/* 435 */       return this.location.getCharSpaceWidth();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public float distanceFromEndOf(TextChunk other)
/*     */     {
/* 447 */       return this.location.distanceFromEndOf(other.location);
/*     */     }
/*     */     
/*     */     private void printDiagnostics() {
/* 451 */       System.out.println("Text (@" + this.location.getStartLocation() + " -> " + this.location.getEndLocation() + "): " + this.text);
/* 452 */       System.out.println("orientationMagnitude: " + this.location.orientationMagnitude());
/* 453 */       System.out.println("distPerpendicular: " + this.location.distPerpendicular());
/* 454 */       System.out.println("distParallel: " + this.location.distParallelStart());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int compareTo(TextChunk rhs)
/*     */     {
/* 463 */       return this.location.compareTo(rhs.location);
/*     */     }
/*     */     
/*     */     private boolean sameLine(TextChunk lastChunk) {
/* 467 */       return getLocation().sameLine(lastChunk.getLocation());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int compareInts(int int1, int int2)
/*     */   {
/* 479 */     return int1 < int2 ? -1 : int1 == int2 ? 0 : 1;
/*     */   }
/*     */   
/*     */   public void renderImage(ImageRenderInfo renderInfo) {}
/*     */   
/*     */   public static abstract interface TextChunkFilter
/*     */   {
/*     */     public abstract boolean accept(LocationTextExtractionStrategy.TextChunk paramTextChunk);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/LocationTextExtractionStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */