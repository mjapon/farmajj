/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfPTableFooter
/*    */   extends PdfPTableBody
/*    */ {
/* 49 */   protected PdfName role = PdfName.TFOOT;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PdfName getRole()
/*    */   {
/* 56 */     return this.role;
/*    */   }
/*    */   
/*    */   public void setRole(PdfName role) {
/* 60 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfPTableFooter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */