/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RefKey
/*    */ {
/*    */   int num;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   int gen;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   RefKey(int num, int gen)
/*    */   {
/* 55 */     this.num = num;
/* 56 */     this.gen = gen;
/*    */   }
/*    */   
/* 59 */   public RefKey(PdfIndirectReference ref) { this.num = ref.getNumber();
/* 60 */     this.gen = ref.getGeneration();
/*    */   }
/*    */   
/* 63 */   RefKey(PRIndirectReference ref) { this.num = ref.getNumber();
/* 64 */     this.gen = ref.getGeneration();
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 68 */     return (this.gen << 16) + this.num;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 72 */     if (!(o instanceof RefKey)) return false;
/* 73 */     RefKey other = (RefKey)o;
/* 74 */     return (this.gen == other.gen) && (this.num == other.num);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 78 */     return Integer.toString(this.num) + ' ' + this.gen;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/RefKey.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */