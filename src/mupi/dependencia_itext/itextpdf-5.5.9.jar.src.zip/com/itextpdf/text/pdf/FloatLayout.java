/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Element;
/*     */ import com.itextpdf.text.Paragraph;
/*     */ import com.itextpdf.text.WritableDirectElement;
/*     */ import com.itextpdf.text.api.Spaceable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatLayout
/*     */ {
/*     */   protected float maxY;
/*     */   protected float minY;
/*     */   protected float leftX;
/*     */   protected float rightX;
/*     */   protected float yLine;
/*     */   protected float floatLeftX;
/*     */   protected float floatRightX;
/*     */   protected float filledWidth;
/*     */   protected final ColumnText compositeColumn;
/*     */   protected final List<Element> content;
/*     */   protected final boolean useAscender;
/*     */   
/*     */   public float getYLine()
/*     */   {
/*  70 */     return this.yLine;
/*     */   }
/*     */   
/*     */   public void setYLine(float yLine) {
/*  74 */     this.yLine = yLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getFilledWidth()
/*     */   {
/*  84 */     return this.filledWidth;
/*     */   }
/*     */   
/*     */   public void setFilledWidth(float filledWidth) {
/*  88 */     this.filledWidth = filledWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRunDirection()
/*     */   {
/* 100 */     return this.compositeColumn.getRunDirection();
/*     */   }
/*     */   
/*     */   public void setRunDirection(int runDirection) {
/* 104 */     this.compositeColumn.setRunDirection(runDirection);
/*     */   }
/*     */   
/*     */   public FloatLayout(List<Element> elements, boolean useAscender) {
/* 108 */     this.compositeColumn = new ColumnText(null);
/* 109 */     this.compositeColumn.setUseAscender(useAscender);
/* 110 */     this.useAscender = useAscender;
/* 111 */     this.content = elements;
/*     */   }
/*     */   
/*     */   public void setSimpleColumn(float llx, float lly, float urx, float ury) {
/* 115 */     this.leftX = Math.min(llx, urx);
/* 116 */     this.maxY = Math.max(lly, ury);
/* 117 */     this.minY = Math.min(lly, ury);
/* 118 */     this.rightX = Math.max(llx, urx);
/* 119 */     this.floatLeftX = this.leftX;
/* 120 */     this.floatRightX = this.rightX;
/* 121 */     this.yLine = this.maxY;
/* 122 */     this.filledWidth = 0.0F;
/*     */   }
/*     */   
/*     */   public int layout(PdfContentByte canvas, boolean simulate) throws DocumentException {
/* 126 */     this.compositeColumn.setCanvas(canvas);
/* 127 */     int status = 1;
/*     */     
/* 129 */     ArrayList<Element> floatingElements = new ArrayList();
/* 130 */     List<Element> content = simulate ? new ArrayList(this.content) : this.content;
/*     */     
/* 132 */     while (!content.isEmpty()) {
/* 133 */       if ((content.get(0) instanceof PdfDiv)) {
/* 134 */         PdfDiv floatingElement = (PdfDiv)content.get(0);
/* 135 */         if ((floatingElement.getFloatType() == PdfDiv.FloatType.LEFT) || (floatingElement.getFloatType() == PdfDiv.FloatType.RIGHT)) {
/* 136 */           floatingElements.add(floatingElement);
/* 137 */           content.remove(0);
/*     */         } else {
/* 139 */           if (!floatingElements.isEmpty()) {
/* 140 */             status = floatingLayout(floatingElements, simulate);
/* 141 */             if ((status & 0x1) == 0) {
/*     */               break;
/*     */             }
/*     */           }
/*     */           
/* 146 */           content.remove(0);
/*     */           
/* 148 */           status = floatingElement.layout(canvas, this.useAscender, true, this.floatLeftX, this.minY, this.floatRightX, this.yLine);
/*     */           
/* 150 */           if ((floatingElement.getKeepTogether()) && ((status & 0x1) == 0))
/*     */           {
/* 152 */             if ((this.compositeColumn.getCanvas().getPdfDocument().currentHeight > 0.0F) || (this.yLine != this.maxY)) {
/* 153 */               content.add(0, floatingElement);
/* 154 */               break;
/*     */             }
/*     */           }
/*     */           
/* 158 */           if (!simulate) {
/* 159 */             canvas.openMCBlock(floatingElement);
/* 160 */             status = floatingElement.layout(canvas, this.useAscender, simulate, this.floatLeftX, this.minY, this.floatRightX, this.yLine);
/* 161 */             canvas.closeMCBlock(floatingElement);
/*     */           }
/*     */           
/* 164 */           if (floatingElement.getActualWidth() > this.filledWidth) {
/* 165 */             this.filledWidth = floatingElement.getActualWidth();
/*     */           }
/* 167 */           if ((status & 0x1) == 0) {
/* 168 */             content.add(0, floatingElement);
/* 169 */             this.yLine = floatingElement.getYLine();
/* 170 */             break;
/*     */           }
/* 172 */           this.yLine -= floatingElement.getActualHeight();
/*     */         }
/*     */       }
/*     */       else {
/* 176 */         floatingElements.add(content.get(0));
/* 177 */         content.remove(0);
/*     */       }
/*     */     }
/*     */     
/* 181 */     if (((status & 0x1) != 0) && (!floatingElements.isEmpty())) {
/* 182 */       status = floatingLayout(floatingElements, simulate);
/*     */     }
/*     */     
/* 185 */     content.addAll(0, floatingElements);
/*     */     
/* 187 */     return status;
/*     */   }
/*     */   
/*     */   private int floatingLayout(List<Element> floatingElements, boolean simulate) throws DocumentException {
/* 191 */     int status = 1;
/* 192 */     float minYLine = this.yLine;
/* 193 */     float leftWidth = 0.0F;
/* 194 */     float rightWidth = 0.0F;
/*     */     
/* 196 */     ColumnText currentCompositeColumn = this.compositeColumn;
/* 197 */     if (simulate) {
/* 198 */       currentCompositeColumn = ColumnText.duplicate(this.compositeColumn);
/*     */     }
/*     */     
/* 201 */     boolean ignoreSpacingBefore = this.maxY == this.yLine;
/*     */     
/* 203 */     while (!floatingElements.isEmpty()) {
/* 204 */       Element nextElement = (Element)floatingElements.get(0);
/* 205 */       floatingElements.remove(0);
/* 206 */       if ((nextElement instanceof PdfDiv)) {
/* 207 */         PdfDiv floatingElement = (PdfDiv)nextElement;
/* 208 */         status = floatingElement.layout(this.compositeColumn.getCanvas(), this.useAscender, true, this.floatLeftX, this.minY, this.floatRightX, this.yLine);
/* 209 */         if ((status & 0x1) == 0) {
/* 210 */           this.yLine = minYLine;
/* 211 */           this.floatLeftX = this.leftX;
/* 212 */           this.floatRightX = this.rightX;
/* 213 */           status = floatingElement.layout(this.compositeColumn.getCanvas(), this.useAscender, true, this.floatLeftX, this.minY, this.floatRightX, this.yLine);
/* 214 */           if ((status & 0x1) == 0) {
/* 215 */             floatingElements.add(0, floatingElement);
/* 216 */             break;
/*     */           }
/*     */         }
/* 219 */         if (floatingElement.getFloatType() == PdfDiv.FloatType.LEFT) {
/* 220 */           status = floatingElement.layout(this.compositeColumn.getCanvas(), this.useAscender, simulate, this.floatLeftX, this.minY, this.floatRightX, this.yLine);
/* 221 */           this.floatLeftX += floatingElement.getActualWidth();
/* 222 */           leftWidth += floatingElement.getActualWidth();
/* 223 */         } else if (floatingElement.getFloatType() == PdfDiv.FloatType.RIGHT) {
/* 224 */           status = floatingElement.layout(this.compositeColumn.getCanvas(), this.useAscender, simulate, this.floatRightX - floatingElement.getActualWidth() - 0.01F, this.minY, this.floatRightX, this.yLine);
/* 225 */           this.floatRightX -= floatingElement.getActualWidth();
/* 226 */           rightWidth += floatingElement.getActualWidth();
/*     */         }
/* 228 */         minYLine = Math.min(minYLine, this.yLine - floatingElement.getActualHeight());
/*     */       } else {
/* 230 */         if (this.minY > minYLine) {
/* 231 */           status = 2;
/* 232 */           floatingElements.add(0, nextElement);
/* 233 */           if (currentCompositeColumn == null) break;
/* 234 */           currentCompositeColumn.setText(null); break;
/*     */         }
/*     */         
/* 237 */         if (((nextElement instanceof Spaceable)) && ((!ignoreSpacingBefore) || (!currentCompositeColumn.isIgnoreSpacingBefore()) || (((Spaceable)nextElement).getPaddingTop() != 0.0F))) {
/* 238 */           this.yLine -= ((Spaceable)nextElement).getSpacingBefore();
/*     */         }
/* 240 */         if (simulate) {
/* 241 */           if ((nextElement instanceof PdfPTable)) {
/* 242 */             currentCompositeColumn.addElement(new PdfPTable((PdfPTable)nextElement));
/*     */           } else
/* 244 */             currentCompositeColumn.addElement(nextElement);
/*     */         } else {
/* 246 */           currentCompositeColumn.addElement(nextElement);
/*     */         }
/*     */         
/* 249 */         if (this.yLine > minYLine) {
/* 250 */           currentCompositeColumn.setSimpleColumn(this.floatLeftX, this.yLine, this.floatRightX, minYLine);
/*     */         } else {
/* 252 */           currentCompositeColumn.setSimpleColumn(this.floatLeftX, this.yLine, this.floatRightX, this.minY);
/*     */         }
/* 254 */         currentCompositeColumn.setFilledWidth(0.0F);
/*     */         
/* 256 */         status = currentCompositeColumn.go(simulate);
/* 257 */         if ((this.yLine > minYLine) && ((this.floatLeftX > this.leftX) || (this.floatRightX < this.rightX)) && ((status & 0x1) == 0)) {
/* 258 */           this.yLine = minYLine;
/* 259 */           this.floatLeftX = this.leftX;
/* 260 */           this.floatRightX = this.rightX;
/* 261 */           if ((leftWidth != 0.0F) && (rightWidth != 0.0F)) {
/* 262 */             this.filledWidth = (this.rightX - this.leftX);
/*     */           } else {
/* 264 */             if (leftWidth > this.filledWidth) {
/* 265 */               this.filledWidth = leftWidth;
/*     */             }
/* 267 */             if (rightWidth > this.filledWidth) {
/* 268 */               this.filledWidth = rightWidth;
/*     */             }
/*     */           }
/*     */           
/* 272 */           leftWidth = 0.0F;
/* 273 */           rightWidth = 0.0F;
/* 274 */           if ((simulate) && ((nextElement instanceof PdfPTable))) {
/* 275 */             currentCompositeColumn.addElement(new PdfPTable((PdfPTable)nextElement));
/*     */           }
/*     */           
/* 278 */           currentCompositeColumn.setSimpleColumn(this.floatLeftX, this.yLine, this.floatRightX, this.minY);
/* 279 */           status = currentCompositeColumn.go(simulate);
/* 280 */           minYLine = currentCompositeColumn.getYLine() + currentCompositeColumn.getDescender();
/* 281 */           this.yLine = minYLine;
/* 282 */           if (currentCompositeColumn.getFilledWidth() > this.filledWidth) {
/* 283 */             this.filledWidth = currentCompositeColumn.getFilledWidth();
/*     */           }
/*     */         } else {
/* 286 */           if (rightWidth > 0.0F) {
/* 287 */             rightWidth += currentCompositeColumn.getFilledWidth();
/* 288 */           } else if (leftWidth > 0.0F) {
/* 289 */             leftWidth += currentCompositeColumn.getFilledWidth();
/* 290 */           } else if (currentCompositeColumn.getFilledWidth() > this.filledWidth) {
/* 291 */             this.filledWidth = currentCompositeColumn.getFilledWidth();
/*     */           }
/* 293 */           minYLine = Math.min(currentCompositeColumn.getYLine() + currentCompositeColumn.getDescender(), minYLine);
/* 294 */           this.yLine = (currentCompositeColumn.getYLine() + currentCompositeColumn.getDescender());
/*     */         }
/*     */         
/* 297 */         if ((status & 0x1) == 0) {
/* 298 */           if (!simulate) {
/* 299 */             floatingElements.addAll(0, currentCompositeColumn.getCompositeElements());
/* 300 */             currentCompositeColumn.getCompositeElements().clear(); break;
/*     */           }
/* 302 */           floatingElements.add(0, nextElement);
/* 303 */           currentCompositeColumn.setText(null);
/*     */           
/* 305 */           break;
/*     */         }
/* 307 */         currentCompositeColumn.setText(null);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 312 */       if ((nextElement instanceof Paragraph)) {
/* 313 */         Paragraph p = (Paragraph)nextElement;
/* 314 */         for (Element e : p) {
/* 315 */           if ((e instanceof WritableDirectElement)) {
/* 316 */             WritableDirectElement writableElement = (WritableDirectElement)e;
/* 317 */             if ((writableElement.getDirectElementType() == 1) && (!simulate)) {
/* 318 */               PdfWriter writer = this.compositeColumn.getCanvas().getPdfWriter();
/* 319 */               PdfDocument doc = this.compositeColumn.getCanvas().getPdfDocument();
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 324 */               float savedHeight = doc.currentHeight;
/* 325 */               doc.currentHeight = (doc.top() - this.yLine - doc.indentation.indentTop);
/* 326 */               writableElement.write(writer, doc);
/* 327 */               doc.currentHeight = savedHeight;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 333 */       if ((ignoreSpacingBefore) && (nextElement.getChunks().size() == 0)) {
/* 334 */         if ((nextElement instanceof Paragraph)) {
/* 335 */           Paragraph p = (Paragraph)nextElement;
/* 336 */           Element e = (Element)p.get(0);
/* 337 */           if ((e instanceof WritableDirectElement)) {
/* 338 */             WritableDirectElement writableElement = (WritableDirectElement)e;
/* 339 */             if (writableElement.getDirectElementType() != 1) {
/* 340 */               ignoreSpacingBefore = false;
/*     */             }
/*     */           }
/* 343 */         } else if ((nextElement instanceof Spaceable)) {
/* 344 */           ignoreSpacingBefore = false;
/*     */         }
/*     */       }
/*     */       else {
/* 348 */         ignoreSpacingBefore = false;
/*     */       }
/*     */     }
/*     */     
/* 352 */     if ((leftWidth != 0.0F) && (rightWidth != 0.0F)) {
/* 353 */       this.filledWidth = (this.rightX - this.leftX);
/*     */     } else {
/* 355 */       if (leftWidth > this.filledWidth) {
/* 356 */         this.filledWidth = leftWidth;
/*     */       }
/* 358 */       if (rightWidth > this.filledWidth) {
/* 359 */         this.filledWidth = rightWidth;
/*     */       }
/*     */     }
/*     */     
/* 363 */     this.yLine = minYLine;
/* 364 */     this.floatLeftX = this.leftX;
/* 365 */     this.floatRightX = this.rightX;
/*     */     
/* 367 */     return status;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/FloatLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */