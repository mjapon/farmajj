/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.pdf.PRStream;
/*     */ import com.itextpdf.text.pdf.PdfDictionary;
/*     */ import com.itextpdf.text.pdf.PdfIndirectReference;
/*     */ import com.itextpdf.text.pdf.PdfReader;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageRenderInfo
/*     */ {
/*     */   private final GraphicsState gs;
/*     */   private final PdfIndirectReference ref;
/*     */   private final InlineImageInfo inlineImageInfo;
/*     */   private final PdfDictionary colorSpaceDictionary;
/*  69 */   private PdfImageObject imageObject = null;
/*     */   
/*     */   private ImageRenderInfo(GraphicsState gs, PdfIndirectReference ref, PdfDictionary colorSpaceDictionary) {
/*  72 */     this.gs = gs;
/*  73 */     this.ref = ref;
/*  74 */     this.inlineImageInfo = null;
/*  75 */     this.colorSpaceDictionary = colorSpaceDictionary;
/*     */   }
/*     */   
/*     */   private ImageRenderInfo(GraphicsState gs, InlineImageInfo inlineImageInfo, PdfDictionary colorSpaceDictionary) {
/*  79 */     this.gs = gs;
/*  80 */     this.ref = null;
/*  81 */     this.inlineImageInfo = inlineImageInfo;
/*  82 */     this.colorSpaceDictionary = colorSpaceDictionary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ImageRenderInfo createForXObject(GraphicsState gs, PdfIndirectReference ref, PdfDictionary colorSpaceDictionary)
/*     */   {
/*  93 */     return new ImageRenderInfo(gs, ref, colorSpaceDictionary);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static ImageRenderInfo createForEmbeddedImage(GraphicsState gs, InlineImageInfo inlineImageInfo, PdfDictionary colorSpaceDictionary)
/*     */   {
/* 105 */     ImageRenderInfo renderInfo = new ImageRenderInfo(gs, inlineImageInfo, colorSpaceDictionary);
/* 106 */     return renderInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfImageObject getImage()
/*     */     throws IOException
/*     */   {
/* 115 */     prepareImageObject();
/* 116 */     return this.imageObject;
/*     */   }
/*     */   
/*     */   private void prepareImageObject() throws IOException {
/* 120 */     if (this.imageObject != null) {
/* 121 */       return;
/*     */     }
/* 123 */     if (this.ref != null) {
/* 124 */       PRStream stream = (PRStream)PdfReader.getPdfObject(this.ref);
/* 125 */       this.imageObject = new PdfImageObject(stream, this.colorSpaceDictionary);
/* 126 */     } else if (this.inlineImageInfo != null) {
/* 127 */       this.imageObject = new PdfImageObject(this.inlineImageInfo.getImageDictionary(), this.inlineImageInfo.getSamples(), this.colorSpaceDictionary);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Vector getStartPoint()
/*     */   {
/* 135 */     return new Vector(0.0F, 0.0F, 1.0F).cross(this.gs.ctm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Matrix getImageCTM()
/*     */   {
/* 143 */     return this.gs.ctm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getArea()
/*     */   {
/* 152 */     return this.gs.ctm.getDeterminant();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfIndirectReference getRef()
/*     */   {
/* 160 */     return this.ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseColor getCurrentFillColor()
/*     */   {
/* 168 */     return this.gs.fillColor;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/ImageRenderInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */