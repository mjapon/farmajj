/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.Chunk;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.Element;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Font;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.ListBody;
/*      */ import com.itextpdf.text.ListItem;
/*      */ import com.itextpdf.text.ListLabel;
/*      */ import com.itextpdf.text.Paragraph;
/*      */ import com.itextpdf.text.Phrase;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.log.Logger;
/*      */ import com.itextpdf.text.log.LoggerFactory;
/*      */ import com.itextpdf.text.pdf.draw.DrawInterface;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Stack;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ColumnText
/*      */ {
/*   88 */   private final Logger LOGGER = LoggerFactory.getLogger(ColumnText.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int AR_NOVOWEL = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int AR_COMPOSEDTASHKEEL = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int AR_LIG = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIGITS_EN2AN = 32;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIGITS_AN2EN = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIGITS_EN2AN_INIT_LR = 96;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIGITS_EN2AN_INIT_AL = 128;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIGIT_TYPE_AN = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIGIT_TYPE_AN_EXTENDED = 256;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  145 */   protected int runDirection = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final float GLOBAL_SPACE_CHAR_RATIO = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int START_COLUMN = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int NO_MORE_TEXT = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int NO_MORE_COLUMN = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int LINE_STATUS_OK = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int LINE_STATUS_OFFLIMITS = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final int LINE_STATUS_NOLINE = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   protected float maxY;
/*      */   
/*      */ 
/*      */ 
/*      */   protected float minY;
/*      */   
/*      */ 
/*      */ 
/*      */   protected float leftX;
/*      */   
/*      */ 
/*      */ 
/*      */   protected float rightX;
/*      */   
/*      */ 
/*      */ 
/*  199 */   protected int alignment = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ArrayList<float[]> leftWall;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ArrayList<float[]> rightWall;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BidiLine bidiLine;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isWordSplit;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float yLine;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float lastX;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  235 */   protected float currentLeading = 16.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  240 */   protected float fixedLeading = 16.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  245 */   protected float multipliedLeading = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfContentByte canvas;
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfContentByte[] canvases;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int lineStatus;
/*      */   
/*      */ 
/*      */ 
/*  262 */   protected float indent = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  267 */   protected float followingIndent = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  272 */   protected float rightIndent = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  277 */   protected float extraParagraphSpace = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  282 */   protected float rectangularWidth = -1.0F;
/*      */   
/*  284 */   protected boolean rectangularMode = false;
/*      */   
/*      */ 
/*      */ 
/*  288 */   private float spaceCharRatio = 0.0F;
/*      */   
/*  290 */   private boolean lastWasNewline = true;
/*  291 */   private boolean repeatFirstLineIndent = true;
/*      */   
/*      */ 
/*      */   private int linesWritten;
/*      */   
/*      */ 
/*      */   private float firstLineY;
/*      */   
/*  299 */   private boolean firstLineYDone = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  304 */   private int arabicOptions = 0;
/*      */   
/*      */   protected float descender;
/*      */   
/*  308 */   protected boolean composite = false;
/*      */   
/*      */   protected ColumnText compositeColumn;
/*      */   
/*      */   protected LinkedList<Element> compositeElements;
/*      */   
/*  314 */   protected int listIdx = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  320 */   protected int rowIdx = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  329 */   private int splittedRow = -2;
/*      */   
/*      */ 
/*      */ 
/*      */   protected Phrase waitPhrase;
/*      */   
/*      */ 
/*      */ 
/*  337 */   private boolean useAscender = false;
/*      */   
/*      */ 
/*      */ 
/*      */   private float filledWidth;
/*      */   
/*      */ 
/*  344 */   private boolean adjustFirstLine = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  349 */   private boolean inheritGraphicState = false;
/*      */   
/*  351 */   private boolean ignoreSpacingBefore = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ColumnText(PdfContentByte canvas)
/*      */   {
/*  360 */     this.canvas = canvas;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ColumnText duplicate(ColumnText org)
/*      */   {
/*  370 */     ColumnText ct = new ColumnText(null);
/*  371 */     ct.setACopy(org);
/*  372 */     return ct;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ColumnText setACopy(ColumnText org)
/*      */   {
/*  382 */     if (org != null) {
/*  383 */       setSimpleVars(org);
/*  384 */       if (org.bidiLine != null) {
/*  385 */         this.bidiLine = new BidiLine(org.bidiLine);
/*      */       }
/*      */     }
/*  388 */     return this;
/*      */   }
/*      */   
/*      */   protected void setSimpleVars(ColumnText org) {
/*  392 */     this.maxY = org.maxY;
/*  393 */     this.minY = org.minY;
/*  394 */     this.alignment = org.alignment;
/*  395 */     this.leftWall = null;
/*  396 */     if (org.leftWall != null) {
/*  397 */       this.leftWall = new ArrayList(org.leftWall);
/*      */     }
/*  399 */     this.rightWall = null;
/*  400 */     if (org.rightWall != null) {
/*  401 */       this.rightWall = new ArrayList(org.rightWall);
/*      */     }
/*  403 */     this.yLine = org.yLine;
/*  404 */     this.currentLeading = org.currentLeading;
/*  405 */     this.fixedLeading = org.fixedLeading;
/*  406 */     this.multipliedLeading = org.multipliedLeading;
/*  407 */     this.canvas = org.canvas;
/*  408 */     this.canvases = org.canvases;
/*  409 */     this.lineStatus = org.lineStatus;
/*  410 */     this.indent = org.indent;
/*  411 */     this.followingIndent = org.followingIndent;
/*  412 */     this.rightIndent = org.rightIndent;
/*  413 */     this.extraParagraphSpace = org.extraParagraphSpace;
/*  414 */     this.rectangularWidth = org.rectangularWidth;
/*  415 */     this.rectangularMode = org.rectangularMode;
/*  416 */     this.spaceCharRatio = org.spaceCharRatio;
/*  417 */     this.lastWasNewline = org.lastWasNewline;
/*  418 */     this.repeatFirstLineIndent = org.repeatFirstLineIndent;
/*  419 */     this.linesWritten = org.linesWritten;
/*  420 */     this.arabicOptions = org.arabicOptions;
/*  421 */     this.runDirection = org.runDirection;
/*  422 */     this.descender = org.descender;
/*  423 */     this.composite = org.composite;
/*  424 */     this.splittedRow = org.splittedRow;
/*  425 */     if (org.composite) {
/*  426 */       this.compositeElements = new LinkedList();
/*  427 */       for (Element element : org.compositeElements) {
/*  428 */         if ((element instanceof PdfPTable)) {
/*  429 */           this.compositeElements.add(new PdfPTable((PdfPTable)element));
/*      */         } else {
/*  431 */           this.compositeElements.add(element);
/*      */         }
/*      */       }
/*  434 */       if (org.compositeColumn != null) {
/*  435 */         this.compositeColumn = duplicate(org.compositeColumn);
/*      */       }
/*      */     }
/*  438 */     this.listIdx = org.listIdx;
/*  439 */     this.rowIdx = org.rowIdx;
/*  440 */     this.firstLineY = org.firstLineY;
/*  441 */     this.leftX = org.leftX;
/*  442 */     this.rightX = org.rightX;
/*  443 */     this.firstLineYDone = org.firstLineYDone;
/*  444 */     this.waitPhrase = org.waitPhrase;
/*  445 */     this.useAscender = org.useAscender;
/*  446 */     this.filledWidth = org.filledWidth;
/*  447 */     this.adjustFirstLine = org.adjustFirstLine;
/*  448 */     this.inheritGraphicState = org.inheritGraphicState;
/*  449 */     this.ignoreSpacingBefore = org.ignoreSpacingBefore;
/*      */   }
/*      */   
/*      */   private void addWaitingPhrase() {
/*  453 */     if ((this.bidiLine == null) && (this.waitPhrase != null)) {
/*  454 */       this.bidiLine = new BidiLine();
/*  455 */       for (Chunk c : this.waitPhrase.getChunks()) {
/*  456 */         this.bidiLine.addChunk(new PdfChunk(c, null, this.waitPhrase.getTabSettings()));
/*      */       }
/*  458 */       this.waitPhrase = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addText(Phrase phrase)
/*      */   {
/*  469 */     if ((phrase == null) || (this.composite)) {
/*  470 */       return;
/*      */     }
/*  472 */     addWaitingPhrase();
/*  473 */     if (this.bidiLine == null) {
/*  474 */       this.waitPhrase = phrase;
/*  475 */       return;
/*      */     }
/*  477 */     for (Object element : phrase.getChunks()) {
/*  478 */       this.bidiLine.addChunk(new PdfChunk((Chunk)element, null, phrase.getTabSettings()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(Phrase phrase)
/*      */   {
/*  489 */     this.bidiLine = null;
/*  490 */     this.composite = false;
/*  491 */     this.compositeColumn = null;
/*  492 */     this.compositeElements = null;
/*  493 */     this.listIdx = 0;
/*  494 */     this.rowIdx = 0;
/*  495 */     this.splittedRow = -1;
/*  496 */     this.waitPhrase = phrase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addText(Chunk chunk)
/*      */   {
/*  506 */     if ((chunk == null) || (this.composite)) {
/*  507 */       return;
/*      */     }
/*  509 */     addText(new Phrase(chunk));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addElement(Element element)
/*      */   {
/*  523 */     if (element == null) {
/*  524 */       return;
/*      */     }
/*  526 */     if ((element instanceof Image)) {
/*  527 */       Image img = (Image)element;
/*  528 */       PdfPTable t = new PdfPTable(1);
/*  529 */       float w = img.getWidthPercentage();
/*  530 */       if (w == 0.0F) {
/*  531 */         t.setTotalWidth(img.getScaledWidth());
/*  532 */         t.setLockedWidth(true);
/*      */       } else {
/*  534 */         t.setWidthPercentage(w);
/*      */       }
/*  536 */       t.setSpacingAfter(img.getSpacingAfter());
/*  537 */       t.setSpacingBefore(img.getSpacingBefore());
/*  538 */       switch (img.getAlignment()) {
/*      */       case 0: 
/*  540 */         t.setHorizontalAlignment(0);
/*  541 */         break;
/*      */       case 2: 
/*  543 */         t.setHorizontalAlignment(2);
/*  544 */         break;
/*      */       default: 
/*  546 */         t.setHorizontalAlignment(1);
/*      */       }
/*      */       
/*  549 */       PdfPCell c = new PdfPCell(img, true);
/*  550 */       c.setPadding(0.0F);
/*  551 */       c.setBorder(img.getBorder());
/*  552 */       c.setBorderColor(img.getBorderColor());
/*  553 */       c.setBorderWidth(img.getBorderWidth());
/*  554 */       c.setBackgroundColor(img.getBackgroundColor());
/*  555 */       t.addCell(c);
/*  556 */       element = t;
/*      */     }
/*  558 */     if (element.type() == 10) {
/*  559 */       element = new Paragraph((Chunk)element);
/*  560 */     } else if (element.type() == 11) {
/*  561 */       element = new Paragraph((Phrase)element);
/*  562 */     } else if (element.type() == 23) {
/*  563 */       ((PdfPTable)element).init();
/*      */     }
/*  565 */     if ((element.type() != 12) && (element.type() != 14) && (element.type() != 23) && (element.type() != 55) && (element.type() != 37)) {
/*  566 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("element.not.allowed", new Object[0]));
/*      */     }
/*  568 */     if (!this.composite) {
/*  569 */       this.composite = true;
/*  570 */       this.compositeElements = new LinkedList();
/*  571 */       this.bidiLine = null;
/*  572 */       this.waitPhrase = null;
/*      */     }
/*  574 */     if (element.type() == 12) {
/*  575 */       Paragraph p = (Paragraph)element;
/*  576 */       this.compositeElements.addAll(p.breakUp());
/*  577 */       return;
/*      */     }
/*  579 */     this.compositeElements.add(element);
/*      */   }
/*      */   
/*      */   public static boolean isAllowedElement(Element element) {
/*  583 */     int type = element.type();
/*  584 */     if ((type == 10) || (type == 11) || (type == 37) || (type == 12) || (type == 14) || (type == 55) || (type == 23))
/*      */     {
/*      */ 
/*  587 */       return true;
/*      */     }
/*  589 */     if ((element instanceof Image)) {
/*  590 */       return true;
/*      */     }
/*  592 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ArrayList<float[]> convertColumn(float[] cLine)
/*      */   {
/*  606 */     if (cLine.length < 4) {
/*  607 */       throw new RuntimeException(MessageLocalization.getComposedMessage("no.valid.column.line.found", new Object[0]));
/*      */     }
/*  609 */     ArrayList<float[]> cc = new ArrayList();
/*  610 */     for (int k = 0; k < cLine.length - 2; k += 2) {
/*  611 */       float x1 = cLine[k];
/*  612 */       float y1 = cLine[(k + 1)];
/*  613 */       float x2 = cLine[(k + 2)];
/*  614 */       float y2 = cLine[(k + 3)];
/*  615 */       if (y1 != y2)
/*      */       {
/*      */ 
/*      */ 
/*  619 */         float a = (x1 - x2) / (y1 - y2);
/*  620 */         float b = x1 - a * y1;
/*  621 */         float[] r = new float[4];
/*  622 */         r[0] = Math.min(y1, y2);
/*  623 */         r[1] = Math.max(y1, y2);
/*  624 */         r[2] = a;
/*  625 */         r[3] = b;
/*  626 */         cc.add(r);
/*  627 */         this.maxY = Math.max(this.maxY, r[1]);
/*  628 */         this.minY = Math.min(this.minY, r[0]);
/*      */       } }
/*  630 */     if (cc.isEmpty()) {
/*  631 */       throw new RuntimeException(MessageLocalization.getComposedMessage("no.valid.column.line.found", new Object[0]));
/*      */     }
/*  633 */     return cc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float findLimitsPoint(ArrayList<float[]> wall)
/*      */   {
/*  644 */     this.lineStatus = 0;
/*  645 */     if ((this.yLine < this.minY) || (this.yLine > this.maxY)) {
/*  646 */       this.lineStatus = 1;
/*  647 */       return 0.0F;
/*      */     }
/*  649 */     for (int k = 0; k < wall.size(); k++) {
/*  650 */       float[] r = (float[])wall.get(k);
/*  651 */       if ((this.yLine >= r[0]) && (this.yLine <= r[1]))
/*      */       {
/*      */ 
/*  654 */         return r[2] * this.yLine + r[3]; }
/*      */     }
/*  656 */     this.lineStatus = 2;
/*  657 */     return 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float[] findLimitsOneLine()
/*      */   {
/*  667 */     float x1 = findLimitsPoint(this.leftWall);
/*  668 */     if ((this.lineStatus == 1) || (this.lineStatus == 2)) {
/*  669 */       return null;
/*      */     }
/*  671 */     float x2 = findLimitsPoint(this.rightWall);
/*  672 */     if (this.lineStatus == 2) {
/*  673 */       return null;
/*      */     }
/*  675 */     return new float[] { x1, x2 };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float[] findLimitsTwoLines()
/*      */   {
/*  686 */     boolean repeat = false;
/*      */     float[] x1;
/*  688 */     float[] x2; do { for (;;) { if ((repeat) && (this.currentLeading == 0.0F)) {
/*  689 */           return null;
/*      */         }
/*  691 */         repeat = true;
/*  692 */         x1 = findLimitsOneLine();
/*  693 */         if (this.lineStatus == 1) {
/*  694 */           return null;
/*      */         }
/*  696 */         this.yLine -= this.currentLeading;
/*  697 */         if (this.lineStatus != 2)
/*      */         {
/*      */ 
/*  700 */           x2 = findLimitsOneLine();
/*  701 */           if (this.lineStatus == 1) {
/*  702 */             return null;
/*      */           }
/*  704 */           if (this.lineStatus != 2) break;
/*  705 */           this.yLine -= this.currentLeading;
/*      */         }
/*      */       }
/*  708 */     } while ((x1[0] >= x2[1]) || (x2[0] >= x1[1]));
/*      */     
/*      */ 
/*  711 */     return new float[] { x1[0], x1[1], x2[0], x2[1] };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumns(float[] leftLine, float[] rightLine)
/*      */   {
/*  724 */     this.maxY = -1.0E21F;
/*  725 */     this.minY = 1.0E21F;
/*  726 */     setYLine(Math.max(leftLine[1], leftLine[(leftLine.length - 1)]));
/*  727 */     this.rightWall = convertColumn(rightLine);
/*  728 */     this.leftWall = convertColumn(leftLine);
/*  729 */     this.rectangularWidth = -1.0F;
/*  730 */     this.rectangularMode = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSimpleColumn(Phrase phrase, float llx, float lly, float urx, float ury, float leading, int alignment)
/*      */   {
/*  745 */     addText(phrase);
/*  746 */     setSimpleColumn(llx, lly, urx, ury, leading, alignment);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSimpleColumn(float llx, float lly, float urx, float ury, float leading, int alignment)
/*      */   {
/*  760 */     setLeading(leading);
/*  761 */     this.alignment = alignment;
/*  762 */     setSimpleColumn(llx, lly, urx, ury);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSimpleColumn(float llx, float lly, float urx, float ury)
/*      */   {
/*  774 */     this.leftX = Math.min(llx, urx);
/*  775 */     this.maxY = Math.max(lly, ury);
/*  776 */     this.minY = Math.min(lly, ury);
/*  777 */     this.rightX = Math.max(llx, urx);
/*  778 */     this.yLine = this.maxY;
/*  779 */     this.rectangularWidth = (this.rightX - this.leftX);
/*  780 */     if (this.rectangularWidth < 0.0F) {
/*  781 */       this.rectangularWidth = 0.0F;
/*      */     }
/*  783 */     this.rectangularMode = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSimpleColumn(Rectangle rect)
/*      */   {
/*  792 */     setSimpleColumn(rect.getLeft(), rect.getBottom(), rect.getRight(), rect.getTop());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeading(float leading)
/*      */   {
/*  801 */     this.fixedLeading = leading;
/*  802 */     this.multipliedLeading = 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeading(float fixedLeading, float multipliedLeading)
/*      */   {
/*  814 */     this.fixedLeading = fixedLeading;
/*  815 */     this.multipliedLeading = multipliedLeading;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getLeading()
/*      */   {
/*  824 */     return this.fixedLeading;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getMultipliedLeading()
/*      */   {
/*  833 */     return this.multipliedLeading;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setYLine(float yLine)
/*      */   {
/*  842 */     this.yLine = yLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getYLine()
/*      */   {
/*  851 */     return this.yLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getRowsDrawn()
/*      */   {
/*  858 */     return this.rowIdx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlignment(int alignment)
/*      */   {
/*  867 */     this.alignment = alignment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAlignment()
/*      */   {
/*  876 */     return this.alignment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndent(float indent)
/*      */   {
/*  885 */     setIndent(indent, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndent(float indent, boolean repeatFirstLineIndent)
/*      */   {
/*  896 */     this.indent = indent;
/*  897 */     this.lastWasNewline = true;
/*  898 */     this.repeatFirstLineIndent = repeatFirstLineIndent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getIndent()
/*      */   {
/*  907 */     return this.indent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFollowingIndent(float indent)
/*      */   {
/*  916 */     this.followingIndent = indent;
/*  917 */     this.lastWasNewline = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFollowingIndent()
/*      */   {
/*  926 */     return this.followingIndent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRightIndent(float indent)
/*      */   {
/*  935 */     this.rightIndent = indent;
/*  936 */     this.lastWasNewline = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getRightIndent()
/*      */   {
/*  945 */     return this.rightIndent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getCurrentLeading()
/*      */   {
/*  954 */     return this.currentLeading;
/*      */   }
/*      */   
/*      */   public boolean getInheritGraphicState() {
/*  958 */     return this.inheritGraphicState;
/*      */   }
/*      */   
/*      */   public void setInheritGraphicState(boolean inheritGraphicState) {
/*  962 */     this.inheritGraphicState = inheritGraphicState;
/*      */   }
/*      */   
/*      */   public boolean isIgnoreSpacingBefore() {
/*  966 */     return this.ignoreSpacingBefore;
/*      */   }
/*      */   
/*      */   public void setIgnoreSpacingBefore(boolean ignoreSpacingBefore) {
/*  970 */     this.ignoreSpacingBefore = ignoreSpacingBefore;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int go()
/*      */     throws DocumentException
/*      */   {
/*  982 */     return go(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int go(boolean simulate)
/*      */     throws DocumentException
/*      */   {
/*  994 */     return go(simulate, null);
/*      */   }
/*      */   
/*      */   public int go(boolean simulate, IAccessibleElement elementToGo) throws DocumentException {
/*  998 */     this.isWordSplit = false;
/*  999 */     if (this.composite) {
/* 1000 */       return goComposite(simulate);
/*      */     }
/*      */     
/* 1003 */     ListBody lBody = null;
/* 1004 */     if ((isTagged(this.canvas)) && ((elementToGo instanceof ListItem))) {
/* 1005 */       lBody = ((ListItem)elementToGo).getListBody();
/*      */     }
/*      */     
/* 1008 */     addWaitingPhrase();
/* 1009 */     if (this.bidiLine == null) {
/* 1010 */       return 1;
/*      */     }
/* 1012 */     this.descender = 0.0F;
/* 1013 */     this.linesWritten = 0;
/* 1014 */     this.lastX = 0.0F;
/* 1015 */     boolean dirty = false;
/* 1016 */     float ratio = this.spaceCharRatio;
/* 1017 */     Object[] currentValues = new Object[2];
/* 1018 */     PdfFont currentFont = null;
/* 1019 */     Float lastBaseFactor = new Float(0.0F);
/* 1020 */     currentValues[1] = lastBaseFactor;
/* 1021 */     PdfDocument pdf = null;
/* 1022 */     PdfContentByte graphics = null;
/* 1023 */     PdfContentByte text = null;
/* 1024 */     this.firstLineY = NaN.0F;
/* 1025 */     int localRunDirection = 1;
/* 1026 */     if (this.runDirection != 0) {
/* 1027 */       localRunDirection = this.runDirection;
/*      */     }
/* 1029 */     if (this.canvas != null) {
/* 1030 */       graphics = this.canvas;
/* 1031 */       pdf = this.canvas.getPdfDocument();
/* 1032 */       if (!isTagged(this.canvas)) {
/* 1033 */         text = this.canvas.getDuplicate(this.inheritGraphicState);
/*      */       } else {
/* 1035 */         text = this.canvas;
/*      */       }
/* 1037 */     } else if (!simulate) {
/* 1038 */       throw new NullPointerException(MessageLocalization.getComposedMessage("columntext.go.with.simulate.eq.eq.false.and.text.eq.eq.null", new Object[0]));
/*      */     }
/* 1040 */     if (!simulate) {
/* 1041 */       if (ratio == 0.0F) {
/* 1042 */         ratio = text.getPdfWriter().getSpaceCharRatio();
/* 1043 */       } else if (ratio < 0.001F) {
/* 1044 */         ratio = 0.001F;
/*      */       }
/*      */     }
/* 1047 */     if (!this.rectangularMode) {
/* 1048 */       float max = 0.0F;
/* 1049 */       for (PdfChunk c : this.bidiLine.chunks) {
/* 1050 */         max = Math.max(max, c.height());
/*      */       }
/* 1052 */       this.currentLeading = (this.fixedLeading + max * this.multipliedLeading);
/*      */     }
/* 1054 */     float firstIndent = 0.0F;
/*      */     
/*      */ 
/* 1057 */     int status = 0;
/* 1058 */     boolean rtl = false;
/*      */     for (;;) {
/* 1060 */       firstIndent = this.lastWasNewline ? this.indent : this.followingIndent;
/* 1061 */       float x1; float x1; PdfLine line; if (this.rectangularMode) {
/* 1062 */         if (this.rectangularWidth <= firstIndent + this.rightIndent) {
/* 1063 */           status = 2;
/* 1064 */           if (!this.bidiLine.isEmpty()) break;
/* 1065 */           status |= 0x1; break;
/*      */         }
/*      */         
/*      */ 
/* 1069 */         if (this.bidiLine.isEmpty()) {
/* 1070 */           status = 1;
/* 1071 */           break;
/*      */         }
/* 1073 */         PdfLine line = this.bidiLine.processLine(this.leftX, this.rectangularWidth - firstIndent - this.rightIndent, this.alignment, localRunDirection, this.arabicOptions, this.minY, this.yLine, this.descender);
/* 1074 */         this.isWordSplit |= this.bidiLine.isWordSplit();
/* 1075 */         if (line == null) {
/* 1076 */           status = 1;
/* 1077 */           break;
/*      */         }
/* 1079 */         float[] maxSize = line.getMaxSize(this.fixedLeading, this.multipliedLeading);
/* 1080 */         if ((isUseAscender()) && (Float.isNaN(this.firstLineY))) {
/* 1081 */           this.currentLeading = line.getAscender();
/*      */         } else {
/* 1083 */           this.currentLeading = Math.max(maxSize[0], maxSize[1] - this.descender);
/*      */         }
/* 1085 */         if ((this.yLine > this.maxY) || (this.yLine - this.currentLeading < this.minY)) {
/* 1086 */           status = 2;
/* 1087 */           this.bidiLine.restore();
/* 1088 */           break;
/*      */         }
/* 1090 */         this.yLine -= this.currentLeading;
/* 1091 */         if ((!simulate) && (!dirty)) {
/* 1092 */           if ((line.isRTL) && (this.canvas.isTagged()))
/*      */           {
/* 1094 */             this.canvas.beginMarkedContentSequence(PdfName.REVERSEDCHARS);
/* 1095 */             rtl = true;
/*      */           }
/* 1097 */           text.beginText();
/* 1098 */           dirty = true;
/*      */         }
/* 1100 */         if (Float.isNaN(this.firstLineY)) {
/* 1101 */           this.firstLineY = this.yLine;
/*      */         }
/* 1103 */         updateFilledWidth(this.rectangularWidth - line.widthLeft());
/* 1104 */         x1 = this.leftX;
/*      */       } else {
/* 1106 */         float yTemp = this.yLine - this.currentLeading;
/* 1107 */         float[] xx = findLimitsTwoLines();
/* 1108 */         if (xx == null) {
/* 1109 */           status = 2;
/* 1110 */           if (this.bidiLine.isEmpty()) {
/* 1111 */             status |= 0x1;
/*      */           }
/* 1113 */           this.yLine = yTemp;
/* 1114 */           break;
/*      */         }
/* 1116 */         if (this.bidiLine.isEmpty()) {
/* 1117 */           status = 1;
/* 1118 */           this.yLine = yTemp;
/* 1119 */           break;
/*      */         }
/* 1121 */         x1 = Math.max(xx[0], xx[2]);
/* 1122 */         float x2 = Math.min(xx[1], xx[3]);
/* 1123 */         if (x2 - x1 <= firstIndent + this.rightIndent) {
/*      */           continue;
/*      */         }
/* 1126 */         line = this.bidiLine.processLine(x1, x2 - x1 - firstIndent - this.rightIndent, this.alignment, localRunDirection, this.arabicOptions, this.minY, this.yLine, this.descender);
/* 1127 */         if ((!simulate) && (!dirty)) {
/* 1128 */           if ((line.isRTL) && (this.canvas.isTagged()))
/*      */           {
/* 1130 */             this.canvas.beginMarkedContentSequence(PdfName.REVERSEDCHARS);
/* 1131 */             rtl = true;
/*      */           }
/* 1133 */           text.beginText();
/* 1134 */           dirty = true;
/*      */         }
/* 1136 */         if (line == null) {
/* 1137 */           status = 1;
/* 1138 */           this.yLine = yTemp;
/* 1139 */           break;
/*      */         }
/*      */       }
/* 1142 */       if ((isTagged(this.canvas)) && ((elementToGo instanceof ListItem)) && 
/* 1143 */         (!Float.isNaN(this.firstLineY)) && (!this.firstLineYDone)) {
/* 1144 */         if (!simulate) {
/* 1145 */           ListLabel lbl = ((ListItem)elementToGo).getListLabel();
/* 1146 */           this.canvas.openMCBlock(lbl);
/* 1147 */           Chunk symbol = new Chunk(((ListItem)elementToGo).getListSymbol());
/* 1148 */           symbol.setRole(null);
/* 1149 */           showTextAligned(this.canvas, 0, new Phrase(symbol), this.leftX + lbl.getIndentation(), this.firstLineY, 0.0F);
/* 1150 */           this.canvas.closeMCBlock(lbl);
/*      */         }
/* 1152 */         this.firstLineYDone = true;
/*      */       }
/*      */       
/* 1155 */       if (!simulate) {
/* 1156 */         if (lBody != null) {
/* 1157 */           this.canvas.openMCBlock(lBody);
/* 1158 */           lBody = null;
/*      */         }
/* 1160 */         currentValues[0] = currentFont;
/* 1161 */         text.setTextMatrix(x1 + (line.isRTL() ? this.rightIndent : firstIndent) + line.indentLeft(), this.yLine);
/* 1162 */         this.lastX = pdf.writeLineToContent(line, text, graphics, currentValues, ratio);
/* 1163 */         currentFont = (PdfFont)currentValues[0];
/*      */       }
/* 1165 */       this.lastWasNewline = ((this.repeatFirstLineIndent) && (line.isNewlineSplit()));
/* 1166 */       this.yLine -= (line.isNewlineSplit() ? this.extraParagraphSpace : 0.0F);
/* 1167 */       this.linesWritten += 1;
/* 1168 */       this.descender = line.getDescender();
/*      */     }
/* 1170 */     if (dirty) {
/* 1171 */       text.endText();
/* 1172 */       if (this.canvas != text) {
/* 1173 */         this.canvas.add(text);
/*      */       }
/* 1175 */       if ((rtl) && (this.canvas.isTagged())) {
/* 1176 */         this.canvas.endMarkedContentSequence();
/*      */       }
/*      */     }
/* 1179 */     return status;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWordSplit()
/*      */   {
/* 1188 */     return this.isWordSplit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getExtraParagraphSpace()
/*      */   {
/* 1197 */     return this.extraParagraphSpace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExtraParagraphSpace(float extraParagraphSpace)
/*      */   {
/* 1206 */     this.extraParagraphSpace = extraParagraphSpace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearChunks()
/*      */   {
/* 1214 */     if (this.bidiLine != null) {
/* 1215 */       this.bidiLine.clearChunks();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getSpaceCharRatio()
/*      */   {
/* 1225 */     return this.spaceCharRatio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpaceCharRatio(float spaceCharRatio)
/*      */   {
/* 1239 */     this.spaceCharRatio = spaceCharRatio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunDirection(int runDirection)
/*      */   {
/* 1248 */     if ((runDirection < 0) || (runDirection > 3)) {
/* 1249 */       throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.run.direction.1", runDirection));
/*      */     }
/* 1251 */     this.runDirection = runDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRunDirection()
/*      */   {
/* 1260 */     return this.runDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLinesWritten()
/*      */   {
/* 1269 */     return this.linesWritten;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getLastX()
/*      */   {
/* 1279 */     return this.lastX;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getArabicOptions()
/*      */   {
/* 1288 */     return this.arabicOptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArabicOptions(int arabicOptions)
/*      */   {
/* 1298 */     this.arabicOptions = arabicOptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getDescender()
/*      */   {
/* 1307 */     return this.descender;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float getWidth(Phrase phrase, int runDirection, int arabicOptions)
/*      */   {
/* 1320 */     ColumnText ct = new ColumnText(null);
/* 1321 */     ct.addText(phrase);
/* 1322 */     ct.addWaitingPhrase();
/* 1323 */     PdfLine line = ct.bidiLine.processLine(0.0F, 20000.0F, 0, runDirection, arabicOptions, 0.0F, 0.0F, 0.0F);
/* 1324 */     if (line == null) {
/* 1325 */       return 0.0F;
/*      */     }
/* 1327 */     return 20000.0F - line.widthLeft();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float getWidth(Phrase phrase)
/*      */   {
/* 1339 */     return getWidth(phrase, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void showTextAligned(PdfContentByte canvas, int alignment, Phrase phrase, float x, float y, float rotation, int runDirection, int arabicOptions)
/*      */   {
/* 1355 */     if ((alignment != 0) && (alignment != 1) && (alignment != 2))
/*      */     {
/* 1357 */       alignment = 0;
/*      */     }
/* 1359 */     canvas.saveState();
/* 1360 */     ColumnText ct = new ColumnText(canvas);
/* 1361 */     float lly = -1.0F;
/* 1362 */     float ury = 2.0F;
/*      */     float urx;
/*      */     float urx;
/* 1365 */     float llx; float urx; switch (alignment) {
/*      */     case 0: 
/* 1367 */       float llx = 0.0F;
/* 1368 */       urx = 20000.0F;
/* 1369 */       break;
/*      */     case 2: 
/* 1371 */       float llx = -20000.0F;
/* 1372 */       urx = 0.0F;
/* 1373 */       break;
/*      */     default: 
/* 1375 */       llx = -20000.0F;
/* 1376 */       urx = 20000.0F;
/*      */     }
/*      */     
/* 1379 */     if (rotation == 0.0F) {
/* 1380 */       llx += x;
/* 1381 */       lly += y;
/* 1382 */       urx += x;
/* 1383 */       ury += y;
/*      */     } else {
/* 1385 */       double alpha = rotation * 3.141592653589793D / 180.0D;
/* 1386 */       float cos = (float)Math.cos(alpha);
/* 1387 */       float sin = (float)Math.sin(alpha);
/* 1388 */       canvas.concatCTM(cos, sin, -sin, cos, x, y);
/*      */     }
/* 1390 */     ct.setSimpleColumn(phrase, llx, lly, urx, ury, 2.0F, alignment);
/* 1391 */     if (runDirection == 3) {
/* 1392 */       if (alignment == 0) {
/* 1393 */         alignment = 2;
/* 1394 */       } else if (alignment == 2) {
/* 1395 */         alignment = 0;
/*      */       }
/*      */     }
/* 1398 */     ct.setAlignment(alignment);
/* 1399 */     ct.setArabicOptions(arabicOptions);
/* 1400 */     ct.setRunDirection(runDirection);
/*      */     try {
/* 1402 */       ct.go();
/*      */     } catch (DocumentException e) {
/* 1404 */       throw new ExceptionConverter(e);
/*      */     }
/* 1406 */     canvas.restoreState();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void showTextAligned(PdfContentByte canvas, int alignment, Phrase phrase, float x, float y, float rotation)
/*      */   {
/* 1420 */     showTextAligned(canvas, alignment, phrase, x, y, rotation, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float fitText(Font font, String text, Rectangle rect, float maxFontSize, int runDirection)
/*      */   {
/*      */     try
/*      */     {
/* 1435 */       ColumnText ct = null;
/* 1436 */       int status = 0;
/* 1437 */       if (maxFontSize <= 0.0F) {
/* 1438 */         int cr = 0;
/* 1439 */         int lf = 0;
/* 1440 */         char[] t = text.toCharArray();
/* 1441 */         for (int k = 0; k < t.length; k++) {
/* 1442 */           if (t[k] == '\n') {
/* 1443 */             lf++;
/* 1444 */           } else if (t[k] == '\r') {
/* 1445 */             cr++;
/*      */           }
/*      */         }
/* 1448 */         int minLines = Math.max(cr, lf) + 1;
/* 1449 */         maxFontSize = Math.abs(rect.getHeight()) / minLines - 0.001F;
/*      */       }
/* 1451 */       font.setSize(maxFontSize);
/* 1452 */       Phrase ph = new Phrase(text, font);
/* 1453 */       ct = new ColumnText(null);
/* 1454 */       ct.setSimpleColumn(ph, rect.getLeft(), rect.getBottom(), rect.getRight(), rect.getTop(), maxFontSize, 0);
/* 1455 */       ct.setRunDirection(runDirection);
/* 1456 */       status = ct.go(true);
/* 1457 */       if ((status & 0x1) != 0) {
/* 1458 */         return maxFontSize;
/*      */       }
/* 1460 */       float precision = 0.1F;
/* 1461 */       float min = 0.0F;
/* 1462 */       float max = maxFontSize;
/* 1463 */       float size = maxFontSize;
/* 1464 */       for (int k = 0; k < 50; k++) {
/* 1465 */         size = (min + max) / 2.0F;
/* 1466 */         ct = new ColumnText(null);
/* 1467 */         font.setSize(size);
/* 1468 */         ct.setSimpleColumn(new Phrase(text, font), rect.getLeft(), rect.getBottom(), rect.getRight(), rect.getTop(), size, 0);
/* 1469 */         ct.setRunDirection(runDirection);
/* 1470 */         status = ct.go(true);
/* 1471 */         if ((status & 0x1) != 0) {
/* 1472 */           if (max - min < size * precision) {
/* 1473 */             return size;
/*      */           }
/* 1475 */           min = size;
/*      */         } else {
/* 1477 */           max = size;
/*      */         }
/*      */       }
/* 1480 */       return size;
/*      */     } catch (Exception e) {
/* 1482 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected int goComposite(boolean simulate) throws DocumentException {
/* 1487 */     PdfDocument pdf = null;
/* 1488 */     if (this.canvas != null) {
/* 1489 */       pdf = this.canvas.pdf;
/*      */     }
/* 1491 */     if (!this.rectangularMode) {
/* 1492 */       throw new DocumentException(MessageLocalization.getComposedMessage("irregular.columns.are.not.supported.in.composite.mode", new Object[0]));
/*      */     }
/* 1494 */     this.linesWritten = 0;
/* 1495 */     this.descender = 0.0F;
/* 1496 */     boolean firstPass = true;
/* 1497 */     boolean isRTL = this.runDirection == 3;
/*      */     for (;;) {
/* 1499 */       if (this.compositeElements.isEmpty()) {
/* 1500 */         return 1;
/*      */       }
/* 1502 */       Element element = (Element)this.compositeElements.getFirst();
/* 1503 */       if (element.type() == 12) {
/* 1504 */         Paragraph para = (Paragraph)element;
/* 1505 */         int status = 0;
/* 1506 */         for (int keep = 0; keep < 2; keep++) {
/* 1507 */           float lastY = this.yLine;
/* 1508 */           boolean createHere = false;
/* 1509 */           if (this.compositeColumn == null) {
/* 1510 */             this.compositeColumn = new ColumnText(this.canvas);
/* 1511 */             this.compositeColumn.setAlignment(para.getAlignment());
/* 1512 */             this.compositeColumn.setIndent(para.getIndentationLeft() + para.getFirstLineIndent(), false);
/* 1513 */             this.compositeColumn.setExtraParagraphSpace(para.getExtraParagraphSpace());
/* 1514 */             this.compositeColumn.setFollowingIndent(para.getIndentationLeft());
/* 1515 */             this.compositeColumn.setRightIndent(para.getIndentationRight());
/* 1516 */             this.compositeColumn.setLeading(para.getLeading(), para.getMultipliedLeading());
/* 1517 */             this.compositeColumn.setRunDirection(this.runDirection);
/* 1518 */             this.compositeColumn.setArabicOptions(this.arabicOptions);
/* 1519 */             this.compositeColumn.setSpaceCharRatio(this.spaceCharRatio);
/* 1520 */             this.compositeColumn.addText(para);
/* 1521 */             if ((!firstPass) || (!this.adjustFirstLine)) {
/* 1522 */               this.yLine -= para.getSpacingBefore();
/*      */             }
/* 1524 */             createHere = true;
/*      */           }
/* 1526 */           this.compositeColumn.setUseAscender(((firstPass) || (this.descender == 0.0F)) && (this.adjustFirstLine) ? this.useAscender : false);
/* 1527 */           this.compositeColumn.setInheritGraphicState(this.inheritGraphicState);
/* 1528 */           this.compositeColumn.leftX = this.leftX;
/* 1529 */           this.compositeColumn.rightX = this.rightX;
/* 1530 */           this.compositeColumn.yLine = this.yLine;
/* 1531 */           this.compositeColumn.rectangularWidth = this.rectangularWidth;
/* 1532 */           this.compositeColumn.rectangularMode = this.rectangularMode;
/* 1533 */           this.compositeColumn.minY = this.minY;
/* 1534 */           this.compositeColumn.maxY = this.maxY;
/* 1535 */           boolean keepCandidate = (para.getKeepTogether()) && (createHere) && ((!firstPass) || (!this.adjustFirstLine));
/* 1536 */           boolean s = (simulate) || ((keepCandidate) && (keep == 0));
/* 1537 */           if ((isTagged(this.canvas)) && (!s)) {
/* 1538 */             this.canvas.openMCBlock(para);
/*      */           }
/* 1540 */           status = this.compositeColumn.go(s);
/* 1541 */           if ((isTagged(this.canvas)) && (!s)) {
/* 1542 */             this.canvas.closeMCBlock(para);
/*      */           }
/* 1544 */           this.lastX = this.compositeColumn.getLastX();
/* 1545 */           updateFilledWidth(this.compositeColumn.filledWidth);
/* 1546 */           if (((status & 0x1) == 0) && (keepCandidate)) {
/* 1547 */             this.compositeColumn = null;
/* 1548 */             this.yLine = lastY;
/* 1549 */             return 2;
/*      */           }
/* 1551 */           if ((simulate) || (!keepCandidate)) {
/*      */             break;
/*      */           }
/* 1554 */           if (keep == 0) {
/* 1555 */             this.compositeColumn = null;
/* 1556 */             this.yLine = lastY;
/*      */           }
/*      */         }
/* 1559 */         firstPass = false;
/* 1560 */         if (this.compositeColumn.getLinesWritten() > 0) {
/* 1561 */           this.yLine = this.compositeColumn.yLine;
/* 1562 */           this.linesWritten += this.compositeColumn.linesWritten;
/* 1563 */           this.descender = this.compositeColumn.descender;
/* 1564 */           this.isWordSplit |= this.compositeColumn.isWordSplit();
/*      */         }
/* 1566 */         this.currentLeading = this.compositeColumn.currentLeading;
/* 1567 */         if ((status & 0x1) != 0) {
/* 1568 */           this.compositeColumn = null;
/* 1569 */           this.compositeElements.removeFirst();
/* 1570 */           this.yLine -= para.getSpacingAfter();
/*      */         }
/* 1572 */         if ((status & 0x2) != 0) {
/* 1573 */           return 2;
/*      */         }
/* 1575 */       } else if (element.type() == 14) {
/* 1576 */         com.itextpdf.text.List list = (com.itextpdf.text.List)element;
/* 1577 */         ArrayList<Element> items = list.getItems();
/* 1578 */         ListItem item = null;
/* 1579 */         float listIndentation = list.getIndentationLeft();
/* 1580 */         int count = 0;
/* 1581 */         Stack<Object[]> stack = new Stack();
/* 1582 */         for (int k = 0; k < items.size(); k++) {
/* 1583 */           Object obj = items.get(k);
/* 1584 */           if ((obj instanceof ListItem)) {
/* 1585 */             if (count == this.listIdx) {
/* 1586 */               item = (ListItem)obj;
/* 1587 */               break;
/*      */             }
/* 1589 */             count++;
/*      */           }
/* 1591 */           else if ((obj instanceof com.itextpdf.text.List)) {
/* 1592 */             stack.push(new Object[] { list, Integer.valueOf(k), new Float(listIndentation) });
/* 1593 */             list = (com.itextpdf.text.List)obj;
/* 1594 */             items = list.getItems();
/* 1595 */             listIndentation += list.getIndentationLeft();
/* 1596 */             k = -1;
/* 1597 */             continue;
/*      */           }
/* 1599 */           while ((k == items.size() - 1) && (!stack.isEmpty())) {
/* 1600 */             Object[] objs = (Object[])stack.pop();
/* 1601 */             list = (com.itextpdf.text.List)objs[0];
/* 1602 */             items = list.getItems();
/* 1603 */             k = ((Integer)objs[1]).intValue();
/* 1604 */             listIndentation = ((Float)objs[2]).floatValue();
/*      */           }
/*      */         }
/* 1607 */         int status = 0;
/* 1608 */         boolean keepTogetherAndDontFit = false;
/* 1609 */         for (int keep = 0; keep < 2; keep++) {
/* 1610 */           float lastY = this.yLine;
/* 1611 */           boolean createHere = false;
/* 1612 */           if (this.compositeColumn == null) {
/* 1613 */             if (item == null) {
/* 1614 */               this.listIdx = 0;
/* 1615 */               this.compositeElements.removeFirst();
/* 1616 */               break;
/*      */             }
/* 1618 */             this.compositeColumn = new ColumnText(this.canvas);
/* 1619 */             this.compositeColumn.setUseAscender(((firstPass) || (this.descender == 0.0F)) && (this.adjustFirstLine) ? this.useAscender : false);
/* 1620 */             this.compositeColumn.setInheritGraphicState(this.inheritGraphicState);
/* 1621 */             this.compositeColumn.setAlignment(item.getAlignment());
/* 1622 */             this.compositeColumn.setIndent(item.getIndentationLeft() + listIndentation + item.getFirstLineIndent(), false);
/* 1623 */             this.compositeColumn.setExtraParagraphSpace(item.getExtraParagraphSpace());
/* 1624 */             this.compositeColumn.setFollowingIndent(this.compositeColumn.getIndent());
/* 1625 */             this.compositeColumn.setRightIndent(item.getIndentationRight() + list.getIndentationRight());
/* 1626 */             this.compositeColumn.setLeading(item.getLeading(), item.getMultipliedLeading());
/* 1627 */             this.compositeColumn.setRunDirection(this.runDirection);
/* 1628 */             this.compositeColumn.setArabicOptions(this.arabicOptions);
/* 1629 */             this.compositeColumn.setSpaceCharRatio(this.spaceCharRatio);
/* 1630 */             this.compositeColumn.addText(item);
/* 1631 */             if ((!firstPass) || (!this.adjustFirstLine)) {
/* 1632 */               this.yLine -= item.getSpacingBefore();
/*      */             }
/* 1634 */             createHere = true;
/*      */           }
/* 1636 */           this.compositeColumn.leftX = this.leftX;
/* 1637 */           this.compositeColumn.rightX = this.rightX;
/* 1638 */           this.compositeColumn.yLine = this.yLine;
/* 1639 */           this.compositeColumn.rectangularWidth = this.rectangularWidth;
/* 1640 */           this.compositeColumn.rectangularMode = this.rectangularMode;
/* 1641 */           this.compositeColumn.minY = this.minY;
/* 1642 */           this.compositeColumn.maxY = this.maxY;
/* 1643 */           boolean keepCandidate = (item.getKeepTogether()) && (createHere) && ((!firstPass) || (!this.adjustFirstLine));
/* 1644 */           boolean s = (simulate) || ((keepCandidate) && (keep == 0));
/* 1645 */           if ((isTagged(this.canvas)) && (!s)) {
/* 1646 */             item.getListLabel().setIndentation(listIndentation);
/* 1647 */             if ((list.getFirstItem() == item) || ((this.compositeColumn != null) && (this.compositeColumn.bidiLine != null))) {
/* 1648 */               this.canvas.openMCBlock(list);
/*      */             }
/* 1650 */             this.canvas.openMCBlock(item);
/*      */           }
/* 1652 */           status = this.compositeColumn.go(s, item);
/* 1653 */           if ((isTagged(this.canvas)) && (!s)) {
/* 1654 */             this.canvas.closeMCBlock(item.getListBody());
/* 1655 */             this.canvas.closeMCBlock(item);
/*      */           }
/* 1657 */           this.lastX = this.compositeColumn.getLastX();
/* 1658 */           updateFilledWidth(this.compositeColumn.filledWidth);
/* 1659 */           if (((status & 0x1) == 0) && (keepCandidate)) {
/* 1660 */             keepTogetherAndDontFit = true;
/* 1661 */             this.compositeColumn = null;
/* 1662 */             this.yLine = lastY;
/*      */           }
/* 1664 */           if ((simulate) || (!keepCandidate) || (keepTogetherAndDontFit)) {
/*      */             break;
/*      */           }
/* 1667 */           if (keep == 0) {
/* 1668 */             this.compositeColumn = null;
/* 1669 */             this.yLine = lastY;
/*      */           }
/*      */         }
/*      */         
/* 1673 */         if ((isTagged(this.canvas)) && (!simulate) && (
/* 1674 */           (item == null) || ((list.getLastItem() == item) && ((status & 0x1) != 0)) || ((status & 0x2) != 0))) {
/* 1675 */           this.canvas.closeMCBlock(list);
/*      */         }
/*      */         
/* 1678 */         if (keepTogetherAndDontFit) {
/* 1679 */           return 2;
/*      */         }
/* 1681 */         if (item != null)
/*      */         {
/*      */ 
/*      */ 
/* 1685 */           firstPass = false;
/* 1686 */           this.yLine = this.compositeColumn.yLine;
/* 1687 */           this.linesWritten += this.compositeColumn.linesWritten;
/* 1688 */           this.descender = this.compositeColumn.descender;
/* 1689 */           this.currentLeading = this.compositeColumn.currentLeading;
/* 1690 */           if ((!isTagged(this.canvas)) && 
/* 1691 */             (!Float.isNaN(this.compositeColumn.firstLineY)) && (!this.compositeColumn.firstLineYDone)) {
/* 1692 */             if (!simulate) {
/* 1693 */               if (isRTL) {
/* 1694 */                 showTextAligned(this.canvas, 2, new Phrase(item.getListSymbol()), this.compositeColumn.lastX + item.getIndentationLeft(), this.compositeColumn.firstLineY, 0.0F, this.runDirection, this.arabicOptions);
/*      */               } else {
/* 1696 */                 showTextAligned(this.canvas, 0, new Phrase(item.getListSymbol()), this.compositeColumn.leftX + listIndentation, this.compositeColumn.firstLineY, 0.0F);
/*      */               }
/*      */             }
/*      */             
/* 1700 */             this.compositeColumn.firstLineYDone = true;
/*      */           }
/*      */           
/* 1703 */           if ((status & 0x1) != 0) {
/* 1704 */             this.compositeColumn = null;
/* 1705 */             this.listIdx += 1;
/* 1706 */             this.yLine -= item.getSpacingAfter();
/*      */           }
/* 1708 */           if ((status & 0x2) != 0)
/* 1709 */             return 2;
/*      */         }
/* 1711 */       } else if (element.type() == 23)
/*      */       {
/*      */ 
/*      */ 
/* 1715 */         PdfPTable table = (PdfPTable)element;
/*      */         
/*      */ 
/* 1718 */         if (table.size() <= table.getHeaderRows()) {
/* 1719 */           this.compositeElements.removeFirst();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1724 */           float yTemp = this.yLine;
/* 1725 */           yTemp += this.descender;
/* 1726 */           if ((this.rowIdx == 0) && (this.adjustFirstLine)) {
/* 1727 */             yTemp -= table.spacingBefore();
/*      */           }
/*      */           
/*      */ 
/* 1731 */           if ((yTemp < this.minY) || (yTemp > this.maxY)) {
/* 1732 */             return 2;
/*      */           }
/*      */           
/*      */ 
/* 1736 */           float yLineWrite = yTemp;
/* 1737 */           float x1 = this.leftX;
/* 1738 */           this.currentLeading = 0.0F;
/*      */           
/*      */           float tableWidth;
/* 1741 */           if (table.isLockedWidth()) {
/* 1742 */             float tableWidth = table.getTotalWidth();
/* 1743 */             updateFilledWidth(tableWidth);
/*      */           } else {
/* 1745 */             tableWidth = this.rectangularWidth * table.getWidthPercentage() / 100.0F;
/* 1746 */             table.setTotalWidth(tableWidth);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1751 */           table.normalizeHeadersFooters();
/* 1752 */           int headerRows = table.getHeaderRows();
/* 1753 */           int footerRows = table.getFooterRows();
/* 1754 */           int realHeaderRows = headerRows - footerRows;
/* 1755 */           float footerHeight = table.getFooterHeight();
/* 1756 */           float headerHeight = table.getHeaderHeight() - footerHeight;
/*      */           
/*      */ 
/* 1759 */           boolean skipHeader = (table.isSkipFirstHeader()) && (this.rowIdx <= realHeaderRows) && ((table.isComplete()) || (this.rowIdx != realHeaderRows));
/*      */           
/* 1761 */           if (!skipHeader) {
/* 1762 */             yTemp -= headerHeight;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1767 */           int k = 0;
/* 1768 */           if (this.rowIdx < headerRows) {
/* 1769 */             this.rowIdx = headerRows;
/*      */           }
/* 1771 */           PdfPTable.FittingRows fittingRows = null;
/*      */           
/* 1773 */           if (table.isSkipLastFooter())
/*      */           {
/* 1775 */             fittingRows = table.getFittingRows(yTemp - this.minY, this.rowIdx);
/*      */           }
/*      */           
/*      */ 
/* 1779 */           if ((!table.isSkipLastFooter()) || (fittingRows.lastRow < table.size() - 1)) {
/* 1780 */             yTemp -= footerHeight;
/* 1781 */             fittingRows = table.getFittingRows(yTemp - this.minY, this.rowIdx);
/*      */           }
/*      */           
/*      */ 
/* 1785 */           if ((yTemp < this.minY) || (yTemp > this.maxY)) {
/* 1786 */             return 2;
/*      */           }
/*      */           
/*      */ 
/* 1790 */           k = fittingRows.lastRow + 1;
/* 1791 */           yTemp -= fittingRows.height;
/*      */           
/*      */ 
/* 1794 */           this.LOGGER.info("Want to split at row " + k);
/* 1795 */           int kTemp = k;
/* 1796 */           while ((kTemp > this.rowIdx) && (kTemp < table.size()) && (table.getRow(kTemp).isMayNotBreak())) {
/* 1797 */             kTemp--;
/*      */           }
/*      */           
/* 1800 */           if ((kTemp < table.size() - 1) && (!table.getRow(kTemp).isMayNotBreak())) {
/* 1801 */             kTemp++;
/*      */           }
/*      */           
/* 1804 */           if (((kTemp > this.rowIdx) && (kTemp < k)) || ((kTemp == headerRows) && (table.getRow(headerRows).isMayNotBreak()) && (table.isLoopCheck()))) {
/* 1805 */             yTemp = this.minY;
/* 1806 */             k = kTemp;
/* 1807 */             table.setLoopCheck(false);
/*      */           }
/* 1809 */           this.LOGGER.info("Will split at row " + k);
/*      */           
/*      */ 
/* 1812 */           if ((table.isSplitLate()) && (k > 0)) {
/* 1813 */             fittingRows.correctLastRowChosen(table, k - 1);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1818 */           if (!table.isComplete()) {
/* 1819 */             yTemp += footerHeight;
/*      */           }
/*      */           
/*      */ 
/* 1823 */           if (!table.isSplitRows()) {
/* 1824 */             this.splittedRow = -1;
/* 1825 */             if (k == this.rowIdx)
/*      */             {
/* 1827 */               if (k == table.size()) {
/* 1828 */                 this.compositeElements.removeFirst();
/* 1829 */                 continue;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 1834 */               if ((table.isComplete()) || (k != 1)) {
/* 1835 */                 table.getRows().remove(k);
/*      */               }
/* 1837 */               return 2;
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/* 1847 */           else if ((table.isSplitLate()) && ((this.rowIdx < k) || ((this.splittedRow == -2) && (
/* 1848 */             (table.getHeaderRows() == 0) || (table.isSkipFirstHeader()))))) {
/* 1849 */             this.splittedRow = -1;
/*      */           }
/* 1851 */           else if (k < table.size())
/*      */           {
/*      */ 
/*      */ 
/* 1855 */             yTemp -= fittingRows.completedRowsHeight - fittingRows.height;
/*      */             
/*      */ 
/* 1858 */             float h = yTemp - this.minY;
/*      */             
/* 1860 */             PdfPRow newRow = table.getRow(k).splitRow(table, k, h);
/*      */             
/* 1862 */             if (newRow == null) {
/* 1863 */               this.LOGGER.info("Didn't split row!");
/* 1864 */               this.splittedRow = -1;
/* 1865 */               if (this.rowIdx == k) {
/* 1866 */                 return 2;
/*      */               }
/*      */             }
/*      */             else {
/* 1870 */               if (k != this.splittedRow) {
/* 1871 */                 this.splittedRow = (k + 1);
/* 1872 */                 table = new PdfPTable(table);
/* 1873 */                 this.compositeElements.set(0, table);
/* 1874 */                 ArrayList<PdfPRow> rows = table.getRows();
/* 1875 */                 for (int i = headerRows; i < this.rowIdx; i++) {
/* 1876 */                   rows.set(i, null);
/*      */                 }
/*      */               }
/* 1879 */               yTemp = this.minY;
/* 1880 */               table.getRows().add(++k, newRow);
/* 1881 */               this.LOGGER.info("Inserting row at position " + k);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1886 */           firstPass = false;
/*      */           
/*      */ 
/* 1889 */           if (!simulate)
/*      */           {
/* 1891 */             switch (table.getHorizontalAlignment()) {
/*      */             case 2: 
/* 1893 */               if (!isRTL) {
/* 1894 */                 x1 += this.rectangularWidth - tableWidth;
/*      */               }
/*      */               break;
/*      */             case 1: 
/* 1898 */               x1 += (this.rectangularWidth - tableWidth) / 2.0F;
/* 1899 */               break;
/*      */             case 0: 
/*      */             default: 
/* 1902 */               if (isRTL) {
/* 1903 */                 x1 += this.rectangularWidth - tableWidth;
/*      */               }
/*      */               break;
/*      */             }
/*      */             
/* 1908 */             PdfPTable nt = PdfPTable.shallowCopy(table);
/* 1909 */             ArrayList<PdfPRow> sub = nt.getRows();
/*      */             
/* 1911 */             if ((!skipHeader) && (realHeaderRows > 0)) {
/* 1912 */               ArrayList<PdfPRow> rows = table.getRows(0, realHeaderRows);
/* 1913 */               if (isTagged(this.canvas)) {
/* 1914 */                 nt.getHeader().rows = rows;
/*      */               }
/* 1916 */               sub.addAll(rows);
/*      */             } else {
/* 1918 */               nt.setHeaderRows(footerRows);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1923 */             ArrayList<PdfPRow> rows = table.getRows(this.rowIdx, k);
/* 1924 */             if (isTagged(this.canvas)) {
/* 1925 */               nt.getBody().rows = rows;
/*      */             }
/* 1927 */             sub.addAll(rows);
/*      */             
/*      */ 
/* 1930 */             boolean showFooter = !table.isSkipLastFooter();
/* 1931 */             boolean newPageFollows = false;
/* 1932 */             if (k < table.size()) {
/* 1933 */               nt.setComplete(true);
/* 1934 */               showFooter = true;
/* 1935 */               newPageFollows = true;
/*      */             }
/*      */             
/* 1938 */             if ((footerRows > 0) && (nt.isComplete()) && (showFooter)) {
/* 1939 */               ArrayList<PdfPRow> rows = table.getRows(realHeaderRows, realHeaderRows + footerRows);
/* 1940 */               if (isTagged(this.canvas)) {
/* 1941 */                 nt.getFooter().rows = rows;
/*      */               }
/* 1943 */               sub.addAll(rows);
/*      */             } else {
/* 1945 */               footerRows = 0;
/*      */             }
/*      */             
/* 1948 */             if (sub.size() > 0)
/*      */             {
/* 1950 */               float rowHeight = 0.0F;
/* 1951 */               int lastIdx = sub.size() - 1 - footerRows;
/* 1952 */               PdfPRow last = (PdfPRow)sub.get(lastIdx);
/* 1953 */               if (table.isExtendLastRow(newPageFollows)) {
/* 1954 */                 rowHeight = last.getMaxHeights();
/* 1955 */                 last.setMaxHeights(yTemp - this.minY + rowHeight);
/* 1956 */                 yTemp = this.minY;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 1961 */               if (newPageFollows) {
/* 1962 */                 PdfPTableEvent tableEvent = table.getTableEvent();
/* 1963 */                 if ((tableEvent instanceof PdfPTableEventSplit)) {
/* 1964 */                   ((PdfPTableEventSplit)tableEvent).splitTable(table);
/*      */                 }
/*      */               }
/*      */               
/*      */ 
/* 1969 */               if (this.canvases != null) {
/* 1970 */                 if (isTagged(this.canvases[3])) {
/* 1971 */                   this.canvases[3].openMCBlock(table);
/*      */                 }
/* 1973 */                 nt.writeSelectedRows(0, -1, 0, -1, x1, yLineWrite, this.canvases, false);
/* 1974 */                 if (isTagged(this.canvases[3])) {
/* 1975 */                   this.canvases[3].closeMCBlock(table);
/*      */                 }
/*      */               } else {
/* 1978 */                 if (isTagged(this.canvas)) {
/* 1979 */                   this.canvas.openMCBlock(table);
/*      */                 }
/* 1981 */                 nt.writeSelectedRows(0, -1, 0, -1, x1, yLineWrite, this.canvas, false);
/* 1982 */                 if (isTagged(this.canvas)) {
/* 1983 */                   this.canvas.closeMCBlock(table);
/*      */                 }
/*      */               }
/*      */               
/* 1987 */               if (!table.isComplete()) {
/* 1988 */                 table.addNumberOfRowsWritten(k);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 1993 */               if ((this.splittedRow == k) && (k < table.size())) {
/* 1994 */                 PdfPRow splitted = (PdfPRow)table.getRows().get(k);
/* 1995 */                 splitted.copyRowContent(nt, lastIdx);
/*      */               }
/* 1997 */               else if ((k > 0) && (k < table.size()))
/*      */               {
/*      */ 
/* 2000 */                 PdfPRow row = table.getRow(k);
/* 2001 */                 row.splitRowspans(table, k - 1, nt, lastIdx);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 2006 */               if (table.isExtendLastRow(newPageFollows)) {
/* 2007 */                 last.setMaxHeights(rowHeight);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 2012 */               if (newPageFollows) {
/* 2013 */                 PdfPTableEvent tableEvent = table.getTableEvent();
/* 2014 */                 if ((tableEvent instanceof PdfPTableEventAfterSplit)) {
/* 2015 */                   PdfPRow row = table.getRow(k);
/* 2016 */                   ((PdfPTableEventAfterSplit)tableEvent).afterSplitTable(table, row, k);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/* 2021 */           else if ((table.isExtendLastRow()) && (this.minY > -1.07374182E9F)) {
/* 2022 */             yTemp = this.minY;
/*      */           }
/*      */           
/* 2025 */           this.yLine = yTemp;
/* 2026 */           this.descender = 0.0F;
/* 2027 */           this.currentLeading = 0.0F;
/* 2028 */           if ((!skipHeader) && (!table.isComplete())) {
/* 2029 */             this.yLine += footerHeight;
/*      */           }
/* 2031 */           while ((k < table.size()) && 
/* 2032 */             (table.getRowHeight(k) <= 0.0F) && (!table.hasRowspan(k)))
/*      */           {
/*      */ 
/* 2035 */             k++;
/*      */           }
/* 2037 */           if (k >= table.size())
/*      */           {
/* 2039 */             if (this.yLine - table.spacingAfter() < this.minY) {
/* 2040 */               this.yLine = this.minY;
/*      */             } else {
/* 2042 */               this.yLine -= table.spacingAfter();
/*      */             }
/* 2044 */             this.compositeElements.removeFirst();
/* 2045 */             this.splittedRow = -1;
/* 2046 */             this.rowIdx = 0;
/*      */           } else {
/* 2048 */             if (this.splittedRow > -1) {
/* 2049 */               ArrayList<PdfPRow> rows = table.getRows();
/* 2050 */               for (int i = this.rowIdx; i < k; i++) {
/* 2051 */                 rows.set(i, null);
/*      */               }
/*      */             }
/* 2054 */             this.rowIdx = k;
/* 2055 */             return 2;
/*      */           }
/* 2057 */         } } else if (element.type() == 55) {
/* 2058 */         if (!simulate) {
/* 2059 */           DrawInterface zh = (DrawInterface)element;
/* 2060 */           zh.draw(this.canvas, this.leftX, this.minY, this.rightX, this.maxY, this.yLine);
/*      */         }
/* 2062 */         this.compositeElements.removeFirst();
/* 2063 */       } else if (element.type() == 37) {
/* 2064 */         ArrayList<Element> floatingElements = new ArrayList();
/*      */         do {
/* 2066 */           floatingElements.add(element);
/* 2067 */           this.compositeElements.removeFirst();
/* 2068 */           element = !this.compositeElements.isEmpty() ? (Element)this.compositeElements.getFirst() : null;
/* 2069 */         } while ((element != null) && (element.type() == 37));
/*      */         
/* 2071 */         FloatLayout fl = new FloatLayout(floatingElements, this.useAscender);
/* 2072 */         fl.setSimpleColumn(this.leftX, this.minY, this.rightX, this.yLine);
/* 2073 */         fl.compositeColumn.setIgnoreSpacingBefore(isIgnoreSpacingBefore());
/* 2074 */         int status = fl.layout(this.canvas, simulate);
/*      */         
/*      */ 
/* 2077 */         this.yLine = fl.getYLine();
/* 2078 */         this.descender = 0.0F;
/* 2079 */         if ((status & 0x1) == 0) {
/* 2080 */           this.compositeElements.addAll(floatingElements);
/* 2081 */           return status;
/*      */         }
/*      */       } else {
/* 2084 */         this.compositeElements.removeFirst();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfContentByte getCanvas()
/*      */   {
/* 2096 */     return this.canvas;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCanvas(PdfContentByte canvas)
/*      */   {
/* 2106 */     this.canvas = canvas;
/* 2107 */     this.canvases = null;
/* 2108 */     if (this.compositeColumn != null) {
/* 2109 */       this.compositeColumn.setCanvas(canvas);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCanvases(PdfContentByte[] canvases)
/*      */   {
/* 2119 */     this.canvases = canvases;
/* 2120 */     this.canvas = canvases[3];
/* 2121 */     if (this.compositeColumn != null) {
/* 2122 */       this.compositeColumn.setCanvases(canvases);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfContentByte[] getCanvases()
/*      */   {
/* 2132 */     return this.canvases;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean zeroHeightElement()
/*      */   {
/* 2142 */     return (this.composite) && (!this.compositeElements.isEmpty()) && (((Element)this.compositeElements.getFirst()).type() == 55);
/*      */   }
/*      */   
/*      */   public java.util.List<Element> getCompositeElements() {
/* 2146 */     return this.compositeElements;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseAscender()
/*      */   {
/* 2156 */     return this.useAscender;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseAscender(boolean useAscender)
/*      */   {
/* 2165 */     this.useAscender = useAscender;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static boolean hasMoreText(int status)
/*      */   {
/* 2172 */     return (status & 0x1) == 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFilledWidth()
/*      */   {
/* 2181 */     return this.filledWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFilledWidth(float filledWidth)
/*      */   {
/* 2191 */     this.filledWidth = filledWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFilledWidth(float w)
/*      */   {
/* 2201 */     if (w > this.filledWidth) {
/* 2202 */       this.filledWidth = w;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAdjustFirstLine()
/*      */   {
/* 2212 */     return this.adjustFirstLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdjustFirstLine(boolean adjustFirstLine)
/*      */   {
/* 2226 */     this.adjustFirstLine = adjustFirstLine;
/*      */   }
/*      */   
/*      */   private static boolean isTagged(PdfContentByte canvas) {
/* 2230 */     return (canvas != null) && (canvas.pdf != null) && (canvas.writer != null) && (canvas.writer.isTagged());
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/ColumnText.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */