/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Point<T extends Number,  extends Comparable<T>>
/*     */ {
/*     */   public static class DoublePoint
/*     */     extends Point<Double>
/*     */   {
/*     */     public DoublePoint()
/*     */     {
/*  84 */       this(0.0D, 0.0D);
/*     */     }
/*     */     
/*     */     public DoublePoint(double x, double y) {
/*  88 */       this(x, y, 0.0D);
/*     */     }
/*     */     
/*     */     public DoublePoint(double x, double y, double z) {
/*  92 */       super(Double.valueOf(y), Double.valueOf(z));
/*     */     }
/*     */     
/*     */     public DoublePoint(DoublePoint other) {
/*  96 */       super();
/*     */     }
/*     */     
/*     */     public double getX() {
/* 100 */       return ((Double)this.x).doubleValue();
/*     */     }
/*     */     
/*     */     public double getY() {
/* 104 */       return ((Double)this.y).doubleValue();
/*     */     }
/*     */     
/*     */     public double getZ() {
/* 108 */       return ((Double)this.z).doubleValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LongPoint extends Point<Long> {
/*     */     public static double getDeltaX(LongPoint pt1, LongPoint pt2) {
/* 114 */       if (pt1.getY() == pt2.getY()) {
/* 115 */         return -3.4E38D;
/*     */       }
/*     */       
/* 118 */       return (pt2.getX() - pt1.getX()) / (pt2.getY() - pt1.getY());
/*     */     }
/*     */     
/*     */     public LongPoint()
/*     */     {
/* 123 */       this(0L, 0L);
/*     */     }
/*     */     
/*     */     public LongPoint(long x, long y) {
/* 127 */       this(x, y, 0L);
/*     */     }
/*     */     
/*     */     public LongPoint(double x, double y) {
/* 131 */       this(x, y);
/*     */     }
/*     */     
/*     */     public LongPoint(long x, long y, long z) {
/* 135 */       super(Long.valueOf(y), Long.valueOf(z));
/*     */     }
/*     */     
/*     */     public LongPoint(LongPoint other) {
/* 139 */       super();
/*     */     }
/*     */     
/*     */     public long getX() {
/* 143 */       return ((Long)this.x).longValue();
/*     */     }
/*     */     
/*     */     public long getY() {
/* 147 */       return ((Long)this.y).longValue();
/*     */     }
/*     */     
/*     */     public long getZ() {
/* 151 */       return ((Long)this.z).longValue();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NumberComparator<T extends Number,  extends Comparable<T>> implements Comparator<T>
/*     */   {
/*     */     public int compare(T a, T b) throws ClassCastException {
/* 158 */       return ((Comparable)a).compareTo(b);
/*     */     }
/*     */   }
/*     */   
/*     */   static boolean arePointsClose(Point<? extends Number> pt1, Point<? extends Number> pt2, double distSqrd) {
/* 163 */     double dx = pt1.x.doubleValue() - pt2.x.doubleValue();
/* 164 */     double dy = pt1.y.doubleValue() - pt2.y.doubleValue();
/* 165 */     return dx * dx + dy * dy <= distSqrd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static double distanceFromLineSqrd(Point<? extends Number> pt, Point<? extends Number> ln1, Point<? extends Number> ln2)
/*     */   {
/* 175 */     double A = ln1.y.doubleValue() - ln2.y.doubleValue();
/* 176 */     double B = ln2.x.doubleValue() - ln1.x.doubleValue();
/* 177 */     double C = A * ln1.x.doubleValue() + B * ln1.y.doubleValue();
/* 178 */     C = A * pt.x.doubleValue() + B * pt.y.doubleValue() - C;
/* 179 */     return C * C / (A * A + B * B);
/*     */   }
/*     */   
/*     */   static DoublePoint getUnitNormal(LongPoint pt1, LongPoint pt2) {
/* 183 */     double dx = ((Long)pt2.x).longValue() - ((Long)pt1.x).longValue();
/* 184 */     double dy = ((Long)pt2.y).longValue() - ((Long)pt1.y).longValue();
/* 185 */     if ((dx == 0.0D) && (dy == 0.0D)) {
/* 186 */       return new DoublePoint();
/*     */     }
/*     */     
/* 189 */     double f = 1.0D / Math.sqrt(dx * dx + dy * dy);
/* 190 */     dx *= f;
/* 191 */     dy *= f;
/*     */     
/* 193 */     return new DoublePoint(dy, -dx);
/*     */   }
/*     */   
/*     */   protected static boolean isPt2BetweenPt1AndPt3(LongPoint pt1, LongPoint pt2, LongPoint pt3) {
/* 197 */     if ((pt1.equals(pt3)) || (pt1.equals(pt2)) || (pt3.equals(pt2))) {
/* 198 */       return false;
/*     */     }
/* 200 */     if (pt1.x != pt3.x) {
/* 201 */       return (((Long)pt2.x).longValue() > ((Long)pt1.x).longValue() ? 1 : 0) == (((Long)pt2.x).longValue() < ((Long)pt3.x).longValue() ? 1 : 0);
/*     */     }
/*     */     
/* 204 */     return (((Long)pt2.y).longValue() > ((Long)pt1.y).longValue() ? 1 : 0) == (((Long)pt2.y).longValue() < ((Long)pt3.y).longValue() ? 1 : 0);
/*     */   }
/*     */   
/*     */   protected static boolean slopesEqual(LongPoint pt1, LongPoint pt2, LongPoint pt3, boolean useFullRange)
/*     */   {
/* 209 */     if (useFullRange) {
/* 210 */       return BigInteger.valueOf(pt1.getY() - pt2.getY()).multiply(BigInteger.valueOf(pt2.getX() - pt3.getX())).equals(
/* 211 */         BigInteger.valueOf(pt1.getX() - pt2.getX()).multiply(BigInteger.valueOf(pt2.getY() - pt3.getY())));
/*     */     }
/* 213 */     return (pt1.getY() - pt2.getY()) * (pt2.getX() - pt3.getX()) - (pt1.getX() - pt2.getX()) * (pt2.getY() - pt3.getY()) == 0L;
/*     */   }
/*     */   
/*     */   protected static boolean slopesEqual(LongPoint pt1, LongPoint pt2, LongPoint pt3, LongPoint pt4, boolean useFullRange)
/*     */   {
/* 218 */     if (useFullRange) {
/* 219 */       return BigInteger.valueOf(pt1.getY() - pt2.getY()).multiply(BigInteger.valueOf(pt3.getX() - pt4.getX())).equals(
/* 220 */         BigInteger.valueOf(pt1.getX() - pt2.getX()).multiply(BigInteger.valueOf(pt3.getY() - pt4.getY())));
/*     */     }
/* 222 */     return (pt1.getY() - pt2.getY()) * (pt3.getX() - pt4.getX()) - (pt1.getX() - pt2.getX()) * (pt3.getY() - pt4.getY()) == 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean slopesNearCollinear(LongPoint pt1, LongPoint pt2, LongPoint pt3, double distSqrd)
/*     */   {
/* 230 */     if (Math.abs(((Long)pt1.x).longValue() - ((Long)pt2.x).longValue()) > Math.abs(((Long)pt1.y).longValue() - ((Long)pt2.y).longValue())) {
/* 231 */       if ((((Long)pt1.x).longValue() > ((Long)pt2.x).longValue() ? 1 : 0) == (((Long)pt1.x).longValue() < ((Long)pt3.x).longValue() ? 1 : 0)) {
/* 232 */         return distanceFromLineSqrd(pt1, pt2, pt3) < distSqrd;
/*     */       }
/* 234 */       if ((((Long)pt2.x).longValue() > ((Long)pt1.x).longValue() ? 1 : 0) == (((Long)pt2.x).longValue() < ((Long)pt3.x).longValue() ? 1 : 0)) {
/* 235 */         return distanceFromLineSqrd(pt2, pt1, pt3) < distSqrd;
/*     */       }
/*     */       
/* 238 */       return distanceFromLineSqrd(pt3, pt1, pt2) < distSqrd;
/*     */     }
/*     */     
/*     */ 
/* 242 */     if ((((Long)pt1.y).longValue() > ((Long)pt2.y).longValue() ? 1 : 0) == (((Long)pt1.y).longValue() < ((Long)pt3.y).longValue() ? 1 : 0)) {
/* 243 */       return distanceFromLineSqrd(pt1, pt2, pt3) < distSqrd;
/*     */     }
/* 245 */     if ((((Long)pt2.y).longValue() > ((Long)pt1.y).longValue() ? 1 : 0) == (((Long)pt2.y).longValue() < ((Long)pt3.y).longValue() ? 1 : 0)) {
/* 246 */       return distanceFromLineSqrd(pt2, pt1, pt3) < distSqrd;
/*     */     }
/*     */     
/* 249 */     return distanceFromLineSqrd(pt3, pt1, pt2) < distSqrd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 254 */   private static final NumberComparator NUMBER_COMPARATOR = new NumberComparator(null);
/*     */   
/*     */   protected T x;
/*     */   
/*     */   protected T y;
/*     */   protected T z;
/*     */   
/*     */   protected Point(Point<T> pt)
/*     */   {
/* 263 */     this(pt.x, pt.y, pt.z);
/*     */   }
/*     */   
/*     */   protected Point(T x, T y, T z) {
/* 267 */     this.x = x;
/* 268 */     this.y = y;
/* 269 */     this.z = z;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 274 */     if (obj == null) {
/* 275 */       return false;
/*     */     }
/* 277 */     if ((obj instanceof Point)) {
/* 278 */       Point<?> a = (Point)obj;
/* 279 */       return (NUMBER_COMPARATOR.compare(this.x, a.x) == 0) && (NUMBER_COMPARATOR.compare(this.y, a.y) == 0);
/*     */     }
/*     */     
/* 282 */     return false;
/*     */   }
/*     */   
/*     */   public void set(Point<T> other)
/*     */   {
/* 287 */     this.x = other.x;
/* 288 */     this.y = other.y;
/* 289 */     this.z = other.z;
/*     */   }
/*     */   
/*     */   public void setX(T x) {
/* 293 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(T y) {
/* 297 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setZ(T z) {
/* 301 */     this.z = z;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 306 */     return "Point [x=" + this.x + ", y=" + this.y + ", z=" + this.z + "]";
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/Point.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */