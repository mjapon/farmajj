/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.io.RASInputStream;
/*      */ import com.itextpdf.text.io.RandomAccessSourceFactory;
/*      */ import com.itextpdf.text.io.WindowRandomAccessSource;
/*      */ import com.itextpdf.text.pdf.codec.Base64;
/*      */ import com.itextpdf.text.pdf.security.PdfPKCS7;
/*      */ import com.itextpdf.text.xml.XmlToTxt;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AcroFields
/*      */ {
/*      */   PdfReader reader;
/*      */   PdfWriter writer;
/*      */   Map<String, Item> fields;
/*      */   private int topFirst;
/*      */   private HashMap<String, int[]> sigNames;
/*      */   private boolean append;
/*      */   public static final int DA_FONT = 0;
/*      */   public static final int DA_SIZE = 1;
/*      */   public static final int DA_COLOR = 2;
/*   81 */   private HashMap<Integer, BaseFont> extensionFonts = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private XfaForm xfa;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_NONE = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_PUSHBUTTON = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_CHECKBOX = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_RADIOBUTTON = 3;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_TEXT = 4;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_LIST = 5;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_COMBO = 6;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int FIELD_TYPE_SIGNATURE = 7;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean lastWasString;
/*      */   
/*      */ 
/*      */ 
/*  127 */   private boolean generateAppearances = true;
/*      */   
/*  129 */   private HashMap<String, BaseFont> localFonts = new HashMap();
/*      */   private float extraMarginLeft;
/*      */   private float extraMarginTop;
/*      */   private ArrayList<BaseFont> substitutionFonts;
/*      */   private ArrayList<String> orderedSignatureNames;
/*      */   
/*      */   AcroFields(PdfReader reader, PdfWriter writer) {
/*  136 */     this.reader = reader;
/*  137 */     this.writer = writer;
/*      */     try {
/*  139 */       this.xfa = new XfaForm(reader);
/*      */     }
/*      */     catch (Exception e) {
/*  142 */       throw new ExceptionConverter(e);
/*      */     }
/*  144 */     if ((writer instanceof PdfStamperImp)) {
/*  145 */       this.append = ((PdfStamperImp)writer).isAppend();
/*      */     }
/*  147 */     fill();
/*      */   }
/*      */   
/*      */   void fill() {
/*  151 */     this.fields = new LinkedHashMap();
/*  152 */     PdfDictionary top = (PdfDictionary)PdfReader.getPdfObjectRelease(this.reader.getCatalog().get(PdfName.ACROFORM));
/*  153 */     if (top == null)
/*  154 */       return;
/*  155 */     PdfBoolean needappearances = top.getAsBoolean(PdfName.NEEDAPPEARANCES);
/*  156 */     if ((needappearances == null) || (!needappearances.booleanValue())) {
/*  157 */       setGenerateAppearances(true);
/*      */     } else
/*  159 */       setGenerateAppearances(false);
/*  160 */     PdfArray arrfds = (PdfArray)PdfReader.getPdfObjectRelease(top.get(PdfName.FIELDS));
/*  161 */     if ((arrfds == null) || (arrfds.size() == 0))
/*  162 */       return;
/*  163 */     for (int k = 1; k <= this.reader.getNumberOfPages(); k++) {
/*  164 */       PdfDictionary page = this.reader.getPageNRelease(k);
/*  165 */       PdfArray annots = (PdfArray)PdfReader.getPdfObjectRelease(page.get(PdfName.ANNOTS), page);
/*  166 */       if (annots != null)
/*      */       {
/*  168 */         for (int j = 0; j < annots.size(); j++) {
/*  169 */           PdfDictionary annot = annots.getAsDict(j);
/*  170 */           if (annot == null) {
/*  171 */             PdfReader.releaseLastXrefPartial(annots.getAsIndirectObject(j));
/*      */ 
/*      */           }
/*  174 */           else if (!PdfName.WIDGET.equals(annot.getAsName(PdfName.SUBTYPE))) {
/*  175 */             PdfReader.releaseLastXrefPartial(annots.getAsIndirectObject(j));
/*      */           }
/*      */           else {
/*  178 */             PdfDictionary widget = annot;
/*  179 */             PdfDictionary dic = new PdfDictionary();
/*  180 */             dic.putAll(annot);
/*  181 */             String name = "";
/*  182 */             PdfDictionary value = null;
/*  183 */             PdfObject lastV = null;
/*  184 */             while (annot != null) {
/*  185 */               dic.mergeDifferent(annot);
/*  186 */               PdfString t = annot.getAsString(PdfName.T);
/*  187 */               if (t != null)
/*  188 */                 name = t.toUnicodeString() + "." + name;
/*  189 */               if ((lastV == null) && (annot.get(PdfName.V) != null))
/*  190 */                 lastV = PdfReader.getPdfObjectRelease(annot.get(PdfName.V));
/*  191 */               if ((value == null) && (t != null)) {
/*  192 */                 value = annot;
/*  193 */                 if ((annot.get(PdfName.V) == null) && (lastV != null))
/*  194 */                   value.put(PdfName.V, lastV);
/*      */               }
/*  196 */               annot = annot.getAsDict(PdfName.PARENT);
/*      */             }
/*  198 */             if (name.length() > 0)
/*  199 */               name = name.substring(0, name.length() - 1);
/*  200 */             Item item = (Item)this.fields.get(name);
/*  201 */             if (item == null) {
/*  202 */               item = new Item();
/*  203 */               this.fields.put(name, item);
/*      */             }
/*  205 */             if (value == null) {
/*  206 */               item.addValue(widget);
/*      */             } else
/*  208 */               item.addValue(value);
/*  209 */             item.addWidget(widget);
/*  210 */             item.addWidgetRef(annots.getAsIndirectObject(j));
/*  211 */             if (top != null)
/*  212 */               dic.mergeDifferent(top);
/*  213 */             item.addMerged(dic);
/*  214 */             item.addPage(k);
/*  215 */             item.addTabOrder(j);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  220 */     PdfNumber sigFlags = top.getAsNumber(PdfName.SIGFLAGS);
/*  221 */     if ((sigFlags == null) || ((sigFlags.intValue() & 0x1) != 1))
/*  222 */       return;
/*  223 */     for (int j = 0; j < arrfds.size(); j++) {
/*  224 */       PdfDictionary annot = arrfds.getAsDict(j);
/*  225 */       if (annot == null) {
/*  226 */         PdfReader.releaseLastXrefPartial(arrfds.getAsIndirectObject(j));
/*      */ 
/*      */       }
/*  229 */       else if (!PdfName.WIDGET.equals(annot.getAsName(PdfName.SUBTYPE))) {
/*  230 */         PdfReader.releaseLastXrefPartial(arrfds.getAsIndirectObject(j));
/*      */       }
/*      */       else {
/*  233 */         PdfArray kids = (PdfArray)PdfReader.getPdfObjectRelease(annot.get(PdfName.KIDS));
/*  234 */         if (kids == null)
/*      */         {
/*  236 */           PdfDictionary dic = new PdfDictionary();
/*  237 */           dic.putAll(annot);
/*  238 */           PdfString t = annot.getAsString(PdfName.T);
/*  239 */           if (t != null)
/*      */           {
/*  241 */             String name = t.toUnicodeString();
/*  242 */             if (!this.fields.containsKey(name))
/*      */             {
/*  244 */               Item item = new Item();
/*  245 */               this.fields.put(name, item);
/*  246 */               item.addValue(dic);
/*  247 */               item.addWidget(dic);
/*  248 */               item.addWidgetRef(arrfds.getAsIndirectObject(j));
/*  249 */               item.addMerged(dic);
/*  250 */               item.addPage(-1);
/*  251 */               item.addTabOrder(-1);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getAppearanceStates(String fieldName)
/*      */   {
/*  268 */     Item fd = (Item)this.fields.get(fieldName);
/*  269 */     if (fd == null)
/*  270 */       return null;
/*  271 */     HashSet<String> names = new LinkedHashSet();
/*  272 */     PdfDictionary vals = fd.getValue(0);
/*  273 */     PdfString stringOpt = vals.getAsString(PdfName.OPT);
/*      */     
/*      */     PdfObject pdfObject;
/*  276 */     if (stringOpt != null) {
/*  277 */       names.add(stringOpt.toUnicodeString());
/*      */     }
/*      */     else {
/*  280 */       PdfArray arrayOpt = vals.getAsArray(PdfName.OPT);
/*  281 */       if (arrayOpt != null) {
/*  282 */         for (int k = 0; k < arrayOpt.size(); k++) {
/*  283 */           pdfObject = arrayOpt.getDirectObject(k);
/*  284 */           PdfString valStr = null;
/*      */           
/*  286 */           switch (pdfObject.type()) {
/*      */           case 5: 
/*  288 */             PdfArray pdfArray = (PdfArray)pdfObject;
/*  289 */             valStr = pdfArray.getAsString(1);
/*  290 */             break;
/*      */           case 3: 
/*  292 */             valStr = (PdfString)pdfObject;
/*      */           }
/*      */           
/*      */           
/*  296 */           if (valStr != null)
/*  297 */             names.add(valStr.toUnicodeString());
/*      */         }
/*      */       }
/*      */     }
/*  301 */     for (int k = 0; k < fd.size(); k++) {
/*  302 */       PdfDictionary dic = fd.getWidget(k);
/*  303 */       dic = dic.getAsDict(PdfName.AP);
/*  304 */       if (dic != null)
/*      */       {
/*  306 */         dic = dic.getAsDict(PdfName.N);
/*  307 */         if (dic != null)
/*      */         {
/*  309 */           for (Object element : dic.getKeys()) {
/*  310 */             String name = PdfName.decodeName(((PdfName)element).toString());
/*  311 */             names.add(name);
/*      */           } }
/*      */       } }
/*  314 */     String[] out = new String[names.size()];
/*  315 */     return (String[])names.toArray(out);
/*      */   }
/*      */   
/*      */   private String[] getListOption(String fieldName, int idx) {
/*  319 */     Item fd = getFieldItem(fieldName);
/*  320 */     if (fd == null)
/*  321 */       return null;
/*  322 */     PdfArray ar = fd.getMerged(0).getAsArray(PdfName.OPT);
/*  323 */     if (ar == null)
/*  324 */       return null;
/*  325 */     String[] ret = new String[ar.size()];
/*  326 */     for (int k = 0; k < ar.size(); k++) {
/*  327 */       PdfObject obj = ar.getDirectObject(k);
/*      */       try {
/*  329 */         if (obj.isArray()) {
/*  330 */           obj = ((PdfArray)obj).getDirectObject(idx);
/*      */         }
/*  332 */         if (obj.isString()) {
/*  333 */           ret[k] = ((PdfString)obj).toUnicodeString();
/*      */         } else {
/*  335 */           ret[k] = obj.toString();
/*      */         }
/*      */       } catch (Exception e) {
/*  338 */         ret[k] = "";
/*      */       }
/*      */     }
/*  341 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getListOptionExport(String fieldName)
/*      */   {
/*  353 */     return getListOption(fieldName, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getListOptionDisplay(String fieldName)
/*      */   {
/*  365 */     return getListOption(fieldName, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setListOption(String fieldName, String[] exportValues, String[] displayValues)
/*      */   {
/*  391 */     if ((exportValues == null) && (displayValues == null))
/*  392 */       return false;
/*  393 */     if ((exportValues != null) && (displayValues != null) && (exportValues.length != displayValues.length))
/*  394 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("the.export.and.the.display.array.must.have.the.same.size", new Object[0]));
/*  395 */     int ftype = getFieldType(fieldName);
/*  396 */     if ((ftype != 6) && (ftype != 5))
/*  397 */       return false;
/*  398 */     Item fd = (Item)this.fields.get(fieldName);
/*  399 */     String[] sing = null;
/*  400 */     if ((exportValues == null) && (displayValues != null)) {
/*  401 */       sing = displayValues;
/*  402 */     } else if ((exportValues != null) && (displayValues == null))
/*  403 */       sing = exportValues;
/*  404 */     PdfArray opt = new PdfArray();
/*  405 */     if (sing != null) {
/*  406 */       for (int k = 0; k < sing.length; k++) {
/*  407 */         opt.add(new PdfString(sing[k], "UnicodeBig"));
/*      */       }
/*      */     } else {
/*  410 */       for (int k = 0; k < exportValues.length; k++) {
/*  411 */         PdfArray a = new PdfArray();
/*  412 */         a.add(new PdfString(exportValues[k], "UnicodeBig"));
/*  413 */         a.add(new PdfString(displayValues[k], "UnicodeBig"));
/*  414 */         opt.add(a);
/*      */       }
/*      */     }
/*  417 */     fd.writeToAll(PdfName.OPT, opt, 5);
/*  418 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFieldType(String fieldName)
/*      */   {
/*  434 */     Item fd = getFieldItem(fieldName);
/*  435 */     if (fd == null)
/*  436 */       return 0;
/*  437 */     PdfDictionary merged = fd.getMerged(0);
/*  438 */     PdfName type = merged.getAsName(PdfName.FT);
/*  439 */     if (type == null)
/*  440 */       return 0;
/*  441 */     int ff = 0;
/*  442 */     PdfNumber ffo = merged.getAsNumber(PdfName.FF);
/*  443 */     if (ffo != null) {
/*  444 */       ff = ffo.intValue();
/*      */     }
/*  446 */     if (PdfName.BTN.equals(type)) {
/*  447 */       if ((ff & 0x10000) != 0)
/*  448 */         return 1;
/*  449 */       if ((ff & 0x8000) != 0) {
/*  450 */         return 3;
/*      */       }
/*  452 */       return 2;
/*      */     }
/*  454 */     if (PdfName.TX.equals(type)) {
/*  455 */       return 4;
/*      */     }
/*  457 */     if (PdfName.CH.equals(type)) {
/*  458 */       if ((ff & 0x20000) != 0) {
/*  459 */         return 6;
/*      */       }
/*  461 */       return 5;
/*      */     }
/*  463 */     if (PdfName.SIG.equals(type)) {
/*  464 */       return 7;
/*      */     }
/*  466 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void exportAsFdf(FdfWriter writer)
/*      */   {
/*  475 */     for (Map.Entry<String, Item> entry : this.fields.entrySet()) {
/*  476 */       Item item = (Item)entry.getValue();
/*  477 */       String name = (String)entry.getKey();
/*  478 */       PdfObject v = item.getMerged(0).get(PdfName.V);
/*  479 */       if (v != null)
/*      */       {
/*  481 */         String value = getField(name);
/*  482 */         if (this.lastWasString) {
/*  483 */           writer.setFieldAsString(name, value);
/*      */         } else {
/*  485 */           writer.setFieldAsName(name, value);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean renameField(String oldName, String newName)
/*      */   {
/*  499 */     int idx1 = oldName.lastIndexOf('.') + 1;
/*  500 */     int idx2 = newName.lastIndexOf('.') + 1;
/*  501 */     if (idx1 != idx2)
/*  502 */       return false;
/*  503 */     if (!oldName.substring(0, idx1).equals(newName.substring(0, idx2)))
/*  504 */       return false;
/*  505 */     if (this.fields.containsKey(newName))
/*  506 */       return false;
/*  507 */     Item item = (Item)this.fields.get(oldName);
/*  508 */     if (item == null)
/*  509 */       return false;
/*  510 */     newName = newName.substring(idx2);
/*  511 */     PdfString ss = new PdfString(newName, "UnicodeBig");
/*      */     
/*  513 */     item.writeToAll(PdfName.T, ss, 5);
/*  514 */     item.markUsed(this, 4);
/*      */     
/*  516 */     this.fields.remove(oldName);
/*  517 */     this.fields.put(newName, item);
/*      */     
/*  519 */     return true;
/*      */   }
/*      */   
/*      */   public static Object[] splitDAelements(String da) {
/*      */     try {
/*  524 */       PRTokeniser tk = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(PdfEncodings.convertToBytes(da, null))));
/*  525 */       ArrayList<String> stack = new ArrayList();
/*  526 */       Object[] ret = new Object[3];
/*  527 */       while (tk.nextToken())
/*  528 */         if (tk.getTokenType() != PRTokeniser.TokenType.COMMENT)
/*      */         {
/*  530 */           if (tk.getTokenType() == PRTokeniser.TokenType.OTHER) {
/*  531 */             String operator = tk.getStringValue();
/*  532 */             if (operator.equals("Tf")) {
/*  533 */               if (stack.size() >= 2) {
/*  534 */                 ret[0] = stack.get(stack.size() - 2);
/*  535 */                 ret[1] = new Float((String)stack.get(stack.size() - 1));
/*      */               }
/*      */             }
/*  538 */             else if (operator.equals("g")) {
/*  539 */               if (stack.size() >= 1) {
/*  540 */                 float gray = new Float((String)stack.get(stack.size() - 1)).floatValue();
/*  541 */                 if (gray != 0.0F) {
/*  542 */                   ret[2] = new GrayColor(gray);
/*      */                 }
/*      */               }
/*  545 */             } else if (operator.equals("rg")) {
/*  546 */               if (stack.size() >= 3) {
/*  547 */                 float red = new Float((String)stack.get(stack.size() - 3)).floatValue();
/*  548 */                 float green = new Float((String)stack.get(stack.size() - 2)).floatValue();
/*  549 */                 float blue = new Float((String)stack.get(stack.size() - 1)).floatValue();
/*  550 */                 ret[2] = new BaseColor(red, green, blue);
/*      */               }
/*      */             }
/*  553 */             else if ((operator.equals("k")) && 
/*  554 */               (stack.size() >= 4)) {
/*  555 */               float cyan = new Float((String)stack.get(stack.size() - 4)).floatValue();
/*  556 */               float magenta = new Float((String)stack.get(stack.size() - 3)).floatValue();
/*  557 */               float yellow = new Float((String)stack.get(stack.size() - 2)).floatValue();
/*  558 */               float black = new Float((String)stack.get(stack.size() - 1)).floatValue();
/*  559 */               ret[2] = new CMYKColor(cyan, magenta, yellow, black);
/*      */             }
/*      */             
/*  562 */             stack.clear();
/*      */           }
/*      */           else {
/*  565 */             stack.add(tk.getStringValue());
/*      */           } }
/*  567 */       return ret;
/*      */     }
/*      */     catch (IOException ioe) {
/*  570 */       throw new ExceptionConverter(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void decodeGenericDictionary(PdfDictionary merged, BaseField tx) throws IOException, DocumentException {
/*  575 */     int flags = 0;
/*      */     
/*  577 */     PdfString da = merged.getAsString(PdfName.DA);
/*  578 */     if (da != null) {
/*  579 */       boolean fontfallback = false;
/*  580 */       Object[] dab = splitDAelements(da.toUnicodeString());
/*  581 */       if (dab[1] != null)
/*  582 */         tx.setFontSize(((Float)dab[1]).floatValue());
/*  583 */       if (dab[2] != null)
/*  584 */         tx.setTextColor((BaseColor)dab[2]);
/*  585 */       if (dab[0] != null) {
/*  586 */         PdfDictionary dr = merged.getAsDict(PdfName.DR);
/*  587 */         if (dr != null) {
/*  588 */           PdfDictionary font = dr.getAsDict(PdfName.FONT);
/*  589 */           if (font != null) {
/*  590 */             PdfObject po = font.get(new PdfName((String)dab[0]));
/*  591 */             if ((po != null) && (po.type() == 10)) {
/*  592 */               PRIndirectReference por = (PRIndirectReference)po;
/*  593 */               BaseFont bp = new DocumentFont((PRIndirectReference)po, dr.getAsDict(PdfName.ENCODING));
/*  594 */               tx.setFont(bp);
/*  595 */               Integer porkey = Integer.valueOf(por.getNumber());
/*  596 */               BaseFont porf = (BaseFont)this.extensionFonts.get(porkey);
/*  597 */               if ((porf == null) && 
/*  598 */                 (!this.extensionFonts.containsKey(porkey))) {
/*  599 */                 PdfDictionary fo = (PdfDictionary)PdfReader.getPdfObject(po);
/*  600 */                 PdfDictionary fd = fo.getAsDict(PdfName.FONTDESCRIPTOR);
/*  601 */                 if (fd != null) {
/*  602 */                   PRStream prs = (PRStream)PdfReader.getPdfObject(fd.get(PdfName.FONTFILE2));
/*  603 */                   if (prs == null)
/*  604 */                     prs = (PRStream)PdfReader.getPdfObject(fd.get(PdfName.FONTFILE3));
/*  605 */                   if (prs == null) {
/*  606 */                     this.extensionFonts.put(porkey, null);
/*      */                   }
/*      */                   else {
/*      */                     try {
/*  610 */                       porf = BaseFont.createFont("font.ttf", "Identity-H", true, false, PdfReader.getStreamBytes(prs), null);
/*      */                     }
/*      */                     catch (Exception localException) {}
/*      */                     
/*  614 */                     this.extensionFonts.put(porkey, porf);
/*      */                   }
/*      */                 }
/*      */               }
/*      */               
/*  619 */               if ((tx instanceof TextField)) {
/*  620 */                 ((TextField)tx).setExtensionFont(porf);
/*      */               }
/*      */             } else {
/*  623 */               fontfallback = true;
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  628 */             fontfallback = true;
/*      */           }
/*      */         }
/*      */         else {
/*  632 */           fontfallback = true;
/*      */         }
/*      */       }
/*  635 */       if (fontfallback) {
/*  636 */         BaseFont bf = (BaseFont)this.localFonts.get(dab[0]);
/*  637 */         if (bf == null) {
/*  638 */           String[] fn = (String[])stdFieldFontNames.get(dab[0]);
/*  639 */           if (fn != null) {
/*      */             try {
/*  641 */               String enc = "winansi";
/*  642 */               if (fn.length > 1)
/*  643 */                 enc = fn[1];
/*  644 */               bf = BaseFont.createFont(fn[0], enc, false);
/*  645 */               tx.setFont(bf);
/*      */ 
/*      */             }
/*      */             catch (Exception localException1) {}
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  653 */           tx.setFont(bf);
/*      */         }
/*      */       }
/*      */     }
/*  657 */     PdfDictionary mk = merged.getAsDict(PdfName.MK);
/*  658 */     if (mk != null) {
/*  659 */       PdfArray ar = mk.getAsArray(PdfName.BC);
/*  660 */       BaseColor border = getMKColor(ar);
/*  661 */       tx.setBorderColor(border);
/*  662 */       if (border != null)
/*  663 */         tx.setBorderWidth(1.0F);
/*  664 */       ar = mk.getAsArray(PdfName.BG);
/*  665 */       tx.setBackgroundColor(getMKColor(ar));
/*  666 */       PdfNumber rotation = mk.getAsNumber(PdfName.R);
/*  667 */       if (rotation != null) {
/*  668 */         tx.setRotation(rotation.intValue());
/*      */       }
/*      */     }
/*  671 */     PdfNumber nfl = merged.getAsNumber(PdfName.F);
/*  672 */     flags = 0;
/*  673 */     tx.setVisibility(2);
/*  674 */     if (nfl != null) {
/*  675 */       flags = nfl.intValue();
/*  676 */       if (((flags & 0x4) != 0) && ((flags & 0x2) != 0)) {
/*  677 */         tx.setVisibility(1);
/*  678 */       } else if (((flags & 0x4) != 0) && ((flags & 0x20) != 0)) {
/*  679 */         tx.setVisibility(3);
/*  680 */       } else if ((flags & 0x4) != 0) {
/*  681 */         tx.setVisibility(0);
/*      */       }
/*      */     }
/*  684 */     nfl = merged.getAsNumber(PdfName.FF);
/*  685 */     flags = 0;
/*  686 */     if (nfl != null)
/*  687 */       flags = nfl.intValue();
/*  688 */     tx.setOptions(flags);
/*  689 */     if ((flags & 0x1000000) != 0) {
/*  690 */       PdfNumber maxLen = merged.getAsNumber(PdfName.MAXLEN);
/*  691 */       int len = 0;
/*  692 */       if (maxLen != null)
/*  693 */         len = maxLen.intValue();
/*  694 */       tx.setMaxCharacterLength(len);
/*      */     }
/*      */     
/*  697 */     nfl = merged.getAsNumber(PdfName.Q);
/*  698 */     if (nfl != null) {
/*  699 */       if (nfl.intValue() == 1) {
/*  700 */         tx.setAlignment(1);
/*  701 */       } else if (nfl.intValue() == 2) {
/*  702 */         tx.setAlignment(2);
/*      */       }
/*      */     }
/*  705 */     PdfDictionary bs = merged.getAsDict(PdfName.BS);
/*  706 */     if (bs != null) {
/*  707 */       PdfNumber w = bs.getAsNumber(PdfName.W);
/*  708 */       if (w != null)
/*  709 */         tx.setBorderWidth(w.floatValue());
/*  710 */       PdfName s = bs.getAsName(PdfName.S);
/*  711 */       if (PdfName.D.equals(s)) {
/*  712 */         tx.setBorderStyle(1);
/*  713 */       } else if (PdfName.B.equals(s)) {
/*  714 */         tx.setBorderStyle(2);
/*  715 */       } else if (PdfName.I.equals(s)) {
/*  716 */         tx.setBorderStyle(3);
/*  717 */       } else if (PdfName.U.equals(s)) {
/*  718 */         tx.setBorderStyle(4);
/*      */       }
/*      */     } else {
/*  721 */       PdfArray bd = merged.getAsArray(PdfName.BORDER);
/*  722 */       if (bd != null) {
/*  723 */         if (bd.size() >= 3)
/*  724 */           tx.setBorderWidth(bd.getAsNumber(2).floatValue());
/*  725 */         if (bd.size() >= 4)
/*  726 */           tx.setBorderStyle(1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   PdfAppearance getAppearance(PdfDictionary merged, String[] values, String fieldName) throws IOException, DocumentException {
/*  732 */     PdfName fieldType = merged.getAsName(PdfName.FT);
/*      */     
/*  734 */     if (PdfName.BTN.equals(fieldType)) {
/*  735 */       PdfNumber fieldFlags = merged.getAsNumber(PdfName.FF);
/*  736 */       boolean isRadio = (fieldFlags != null) && ((fieldFlags.intValue() & 0x8000) != 0);
/*  737 */       RadioCheckField field = new RadioCheckField(this.writer, null, null, null);
/*  738 */       decodeGenericDictionary(merged, field);
/*      */       
/*  740 */       PdfArray rect = merged.getAsArray(PdfName.RECT);
/*  741 */       Rectangle box = PdfReader.getNormalizedRectangle(rect);
/*  742 */       if ((field.getRotation() == 90) || (field.getRotation() == 270))
/*  743 */         box = box.rotate();
/*  744 */       field.setBox(box);
/*  745 */       if (!isRadio)
/*  746 */         field.setCheckType(3);
/*  747 */       return field.getAppearance(isRadio, !merged.getAsName(PdfName.AS).equals(PdfName.Off));
/*      */     }
/*      */     
/*  750 */     this.topFirst = 0;
/*  751 */     String text = values.length > 0 ? values[0] : null;
/*      */     
/*  753 */     TextField tx = null;
/*  754 */     if ((this.fieldCache == null) || (!this.fieldCache.containsKey(fieldName))) {
/*  755 */       tx = new TextField(this.writer, null, null);
/*  756 */       tx.setExtraMargin(this.extraMarginLeft, this.extraMarginTop);
/*  757 */       tx.setBorderWidth(0.0F);
/*  758 */       tx.setSubstitutionFonts(this.substitutionFonts);
/*  759 */       decodeGenericDictionary(merged, tx);
/*      */       
/*  761 */       PdfArray rect = merged.getAsArray(PdfName.RECT);
/*  762 */       Rectangle box = PdfReader.getNormalizedRectangle(rect);
/*  763 */       if ((tx.getRotation() == 90) || (tx.getRotation() == 270))
/*  764 */         box = box.rotate();
/*  765 */       tx.setBox(box);
/*  766 */       if (this.fieldCache != null) {
/*  767 */         this.fieldCache.put(fieldName, tx);
/*      */       }
/*      */     } else {
/*  770 */       tx = (TextField)this.fieldCache.get(fieldName);
/*  771 */       tx.setWriter(this.writer);
/*      */     }
/*  773 */     if (PdfName.TX.equals(fieldType)) {
/*  774 */       if ((values.length > 0) && (values[0] != null)) {
/*  775 */         tx.setText(values[0]);
/*      */       }
/*  777 */       return tx.getAppearance();
/*      */     }
/*  779 */     if (!PdfName.CH.equals(fieldType))
/*  780 */       throw new DocumentException(MessageLocalization.getComposedMessage("an.appearance.was.requested.without.a.variable.text.field", new Object[0]));
/*  781 */     PdfArray opt = merged.getAsArray(PdfName.OPT);
/*  782 */     int flags = 0;
/*  783 */     PdfNumber nfl = merged.getAsNumber(PdfName.FF);
/*  784 */     if (nfl != null)
/*  785 */       flags = nfl.intValue();
/*  786 */     if (((flags & 0x20000) != 0) && (opt == null)) {
/*  787 */       tx.setText(text);
/*  788 */       return tx.getAppearance();
/*      */     }
/*  790 */     if (opt != null) {
/*  791 */       String[] choices = new String[opt.size()];
/*  792 */       String[] choicesExp = new String[opt.size()];
/*  793 */       for (int k = 0; k < opt.size(); k++) {
/*  794 */         PdfObject obj = opt.getPdfObject(k);
/*  795 */         if (obj.isString()) {
/*  796 */           choices[k] = (choicesExp[k] = ((PdfString)obj).toUnicodeString());
/*      */         }
/*      */         else {
/*  799 */           PdfArray a = (PdfArray)obj;
/*  800 */           choicesExp[k] = a.getAsString(0).toUnicodeString();
/*  801 */           choices[k] = a.getAsString(1).toUnicodeString();
/*      */         }
/*      */       }
/*  804 */       if ((flags & 0x20000) != 0) {
/*  805 */         for (int k = 0; k < choices.length; k++) {
/*  806 */           if (text.equals(choicesExp[k])) {
/*  807 */             text = choices[k];
/*  808 */             break;
/*      */           }
/*      */         }
/*  811 */         tx.setText(text);
/*  812 */         return tx.getAppearance();
/*      */       }
/*  814 */       ArrayList<Integer> indexes = new ArrayList();
/*  815 */       for (int k = 0; k < choicesExp.length; k++) {
/*  816 */         for (int j = 0; j < values.length; j++) {
/*  817 */           String val = values[j];
/*  818 */           if ((val != null) && (val.equals(choicesExp[k]))) {
/*  819 */             indexes.add(Integer.valueOf(k));
/*  820 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  824 */       tx.setChoices(choices);
/*  825 */       tx.setChoiceExports(choicesExp);
/*  826 */       tx.setChoiceSelections(indexes);
/*      */     }
/*  828 */     PdfAppearance app = tx.getListAppearance();
/*  829 */     this.topFirst = tx.getTopFirst();
/*  830 */     return app;
/*      */   }
/*      */   
/*      */   PdfAppearance getAppearance(PdfDictionary merged, String text, String fieldName) throws IOException, DocumentException {
/*  834 */     String[] valueArr = new String[1];
/*  835 */     valueArr[0] = text;
/*  836 */     return getAppearance(merged, valueArr, fieldName);
/*      */   }
/*      */   
/*      */   BaseColor getMKColor(PdfArray ar) {
/*  840 */     if (ar == null)
/*  841 */       return null;
/*  842 */     switch (ar.size()) {
/*      */     case 1: 
/*  844 */       return new GrayColor(ar.getAsNumber(0).floatValue());
/*      */     case 3: 
/*  846 */       return new BaseColor(ExtendedColor.normalize(ar.getAsNumber(0).floatValue()), ExtendedColor.normalize(ar.getAsNumber(1).floatValue()), ExtendedColor.normalize(ar.getAsNumber(2).floatValue()));
/*      */     case 4: 
/*  848 */       return new CMYKColor(ar.getAsNumber(0).floatValue(), ar.getAsNumber(1).floatValue(), ar.getAsNumber(2).floatValue(), ar.getAsNumber(3).floatValue());
/*      */     }
/*  850 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFieldRichValue(String name)
/*      */   {
/*  861 */     if (this.xfa.isXfaPresent()) {
/*  862 */       return null;
/*      */     }
/*      */     
/*  865 */     Item item = (Item)this.fields.get(name);
/*  866 */     if (item == null) {
/*  867 */       return null;
/*      */     }
/*      */     
/*  870 */     PdfDictionary merged = item.getMerged(0);
/*  871 */     PdfString rich = merged.getAsString(PdfName.RV);
/*      */     
/*  873 */     String markup = null;
/*  874 */     if (rich != null) {
/*  875 */       markup = rich.toString();
/*      */     }
/*      */     
/*  878 */     return markup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getField(String name)
/*      */   {
/*  887 */     if (this.xfa.isXfaPresent()) {
/*  888 */       name = this.xfa.findFieldName(name, this);
/*  889 */       if (name == null)
/*  890 */         return null;
/*  891 */       name = XfaForm.Xml2Som.getShortName(name);
/*  892 */       return XfaForm.getNodeText(this.xfa.findDatasetsNode(name));
/*      */     }
/*  894 */     Item item = (Item)this.fields.get(name);
/*  895 */     if (item == null)
/*  896 */       return null;
/*  897 */     this.lastWasString = false;
/*  898 */     PdfDictionary mergedDict = item.getMerged(0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  903 */     PdfObject v = PdfReader.getPdfObject(mergedDict.get(PdfName.V));
/*  904 */     if (v == null)
/*  905 */       return "";
/*  906 */     if ((v instanceof PRStream)) {
/*      */       try
/*      */       {
/*  909 */         byte[] valBytes = PdfReader.getStreamBytes((PRStream)v);
/*  910 */         return new String(valBytes);
/*      */       } catch (IOException e) {
/*  912 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */     
/*  916 */     PdfName type = mergedDict.getAsName(PdfName.FT);
/*  917 */     if (PdfName.BTN.equals(type)) {
/*  918 */       PdfNumber ff = mergedDict.getAsNumber(PdfName.FF);
/*  919 */       int flags = 0;
/*  920 */       if (ff != null)
/*  921 */         flags = ff.intValue();
/*  922 */       if ((flags & 0x10000) != 0)
/*  923 */         return "";
/*  924 */       String value = "";
/*  925 */       if ((v instanceof PdfName)) {
/*  926 */         value = PdfName.decodeName(v.toString());
/*  927 */       } else if ((v instanceof PdfString))
/*  928 */         value = ((PdfString)v).toUnicodeString();
/*  929 */       PdfArray opts = item.getValue(0).getAsArray(PdfName.OPT);
/*  930 */       if (opts != null) {
/*  931 */         int idx = 0;
/*      */         try {
/*  933 */           idx = Integer.parseInt(value);
/*  934 */           PdfString ps = opts.getAsString(idx);
/*  935 */           value = ps.toUnicodeString();
/*  936 */           this.lastWasString = true;
/*      */         }
/*      */         catch (Exception localException) {}
/*      */       }
/*      */       
/*  941 */       return value;
/*      */     }
/*  943 */     if ((v instanceof PdfString)) {
/*  944 */       this.lastWasString = true;
/*  945 */       return ((PdfString)v).toUnicodeString(); }
/*  946 */     if ((v instanceof PdfName)) {
/*  947 */       return PdfName.decodeName(v.toString());
/*      */     }
/*  949 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getListSelection(String name)
/*      */   {
/*  961 */     String s = getField(name);
/*  962 */     String[] ret; if (s == null) {
/*  963 */       ret = new String[0];
/*      */     }
/*      */     else {
/*  966 */       ret = new String[] { s };
/*      */     }
/*  968 */     Item item = (Item)this.fields.get(name);
/*  969 */     if (item == null) {
/*  970 */       return ret;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  975 */     PdfArray values = item.getMerged(0).getAsArray(PdfName.I);
/*  976 */     if (values == null)
/*  977 */       return ret;
/*  978 */     String[] ret = new String[values.size()];
/*  979 */     String[] options = getListOptionExport(name);
/*      */     
/*  981 */     int idx = 0;
/*  982 */     for (Iterator<PdfObject> i = values.listIterator(); i.hasNext();) {
/*  983 */       PdfNumber n = (PdfNumber)i.next();
/*  984 */       ret[(idx++)] = options[n.intValue()];
/*      */     }
/*  986 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setFieldProperty(String field, String name, Object value, int[] inst)
/*      */   {
/* 1011 */     if (this.writer == null)
/* 1012 */       throw new RuntimeException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[0]));
/*      */     try {
/* 1014 */       Item item = (Item)this.fields.get(field);
/* 1015 */       if (item == null)
/* 1016 */         return false;
/* 1017 */       InstHit hit = new InstHit(inst);
/*      */       
/*      */ 
/* 1020 */       if (name.equalsIgnoreCase("textfont")) {
/* 1021 */         for (int k = 0; k < item.size(); k++) {
/* 1022 */           if (hit.isHit(k)) {
/* 1023 */             PdfDictionary merged = item.getMerged(k);
/* 1024 */             PdfString da = merged.getAsString(PdfName.DA);
/* 1025 */             PdfDictionary dr = merged.getAsDict(PdfName.DR);
/* 1026 */             if (da != null) {
/* 1027 */               if (dr == null) {
/* 1028 */                 dr = new PdfDictionary();
/* 1029 */                 merged.put(PdfName.DR, dr);
/*      */               }
/* 1031 */               Object[] dao = splitDAelements(da.toUnicodeString());
/* 1032 */               PdfAppearance cb = new PdfAppearance();
/* 1033 */               if (dao[0] != null) {
/* 1034 */                 BaseFont bf = (BaseFont)value;
/* 1035 */                 PdfName psn = (PdfName)PdfAppearance.stdFieldFontNames.get(bf.getPostscriptFontName());
/* 1036 */                 if (psn == null) {
/* 1037 */                   psn = new PdfName(bf.getPostscriptFontName());
/*      */                 }
/* 1039 */                 PdfDictionary fonts = dr.getAsDict(PdfName.FONT);
/* 1040 */                 if (fonts == null) {
/* 1041 */                   fonts = new PdfDictionary();
/* 1042 */                   dr.put(PdfName.FONT, fonts);
/*      */                 }
/* 1044 */                 PdfIndirectReference fref = (PdfIndirectReference)fonts.get(psn);
/* 1045 */                 PdfDictionary top = this.reader.getCatalog().getAsDict(PdfName.ACROFORM);
/* 1046 */                 markUsed(top);
/* 1047 */                 dr = top.getAsDict(PdfName.DR);
/* 1048 */                 if (dr == null) {
/* 1049 */                   dr = new PdfDictionary();
/* 1050 */                   top.put(PdfName.DR, dr);
/*      */                 }
/* 1052 */                 markUsed(dr);
/* 1053 */                 PdfDictionary fontsTop = dr.getAsDict(PdfName.FONT);
/* 1054 */                 if (fontsTop == null) {
/* 1055 */                   fontsTop = new PdfDictionary();
/* 1056 */                   dr.put(PdfName.FONT, fontsTop);
/*      */                 }
/* 1058 */                 markUsed(fontsTop);
/* 1059 */                 PdfIndirectReference frefTop = (PdfIndirectReference)fontsTop.get(psn);
/* 1060 */                 if (frefTop != null) {
/* 1061 */                   if (fref == null) {
/* 1062 */                     fonts.put(psn, frefTop);
/*      */                   }
/* 1064 */                 } else if (fref == null) { FontDetails fd;
/*      */                   FontDetails fd;
/* 1066 */                   if (bf.getFontType() == 4) {
/* 1067 */                     fd = new FontDetails(null, ((DocumentFont)bf).getIndirectReference(), bf);
/*      */                   }
/*      */                   else {
/* 1070 */                     bf.setSubset(false);
/* 1071 */                     fd = this.writer.addSimple(bf);
/* 1072 */                     this.localFonts.put(psn.toString().substring(1), bf);
/*      */                   }
/* 1074 */                   fontsTop.put(psn, fd.getIndirectReference());
/* 1075 */                   fonts.put(psn, fd.getIndirectReference());
/*      */                 }
/* 1077 */                 ByteBuffer buf = cb.getInternalBuffer();
/* 1078 */                 buf.append(psn.getBytes()).append(' ').append(((Float)dao[1]).floatValue()).append(" Tf ");
/* 1079 */                 if (dao[2] != null)
/* 1080 */                   cb.setColorFill((BaseColor)dao[2]);
/* 1081 */                 PdfString s = new PdfString(cb.toString());
/* 1082 */                 item.getMerged(k).put(PdfName.DA, s);
/* 1083 */                 item.getWidget(k).put(PdfName.DA, s);
/* 1084 */                 markUsed(item.getWidget(k));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1090 */       else if (name.equalsIgnoreCase("textcolor")) {
/* 1091 */         for (int k = 0; k < item.size(); k++) {
/* 1092 */           if (hit.isHit(k)) {
/* 1093 */             PdfDictionary merged = item.getMerged(k);
/* 1094 */             PdfString da = merged.getAsString(PdfName.DA);
/* 1095 */             if (da != null) {
/* 1096 */               Object[] dao = splitDAelements(da.toUnicodeString());
/* 1097 */               PdfAppearance cb = new PdfAppearance();
/* 1098 */               if (dao[0] != null) {
/* 1099 */                 ByteBuffer buf = cb.getInternalBuffer();
/* 1100 */                 buf.append(new PdfName((String)dao[0]).getBytes()).append(' ').append(((Float)dao[1]).floatValue()).append(" Tf ");
/* 1101 */                 cb.setColorFill((BaseColor)value);
/* 1102 */                 PdfString s = new PdfString(cb.toString());
/* 1103 */                 item.getMerged(k).put(PdfName.DA, s);
/* 1104 */                 item.getWidget(k).put(PdfName.DA, s);
/* 1105 */                 markUsed(item.getWidget(k));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1111 */       else if (name.equalsIgnoreCase("textsize")) {
/* 1112 */         for (int k = 0; k < item.size(); k++) {
/* 1113 */           if (hit.isHit(k)) {
/* 1114 */             PdfDictionary merged = item.getMerged(k);
/* 1115 */             PdfString da = merged.getAsString(PdfName.DA);
/* 1116 */             if (da != null) {
/* 1117 */               Object[] dao = splitDAelements(da.toUnicodeString());
/* 1118 */               PdfAppearance cb = new PdfAppearance();
/* 1119 */               if (dao[0] != null) {
/* 1120 */                 ByteBuffer buf = cb.getInternalBuffer();
/* 1121 */                 buf.append(new PdfName((String)dao[0]).getBytes()).append(' ').append(((Float)value).floatValue()).append(" Tf ");
/* 1122 */                 if (dao[2] != null)
/* 1123 */                   cb.setColorFill((BaseColor)dao[2]);
/* 1124 */                 PdfString s = new PdfString(cb.toString());
/* 1125 */                 item.getMerged(k).put(PdfName.DA, s);
/* 1126 */                 item.getWidget(k).put(PdfName.DA, s);
/* 1127 */                 markUsed(item.getWidget(k));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1133 */       else if ((name.equalsIgnoreCase("bgcolor")) || (name.equalsIgnoreCase("bordercolor"))) {
/* 1134 */         PdfName dname = name.equalsIgnoreCase("bgcolor") ? PdfName.BG : PdfName.BC;
/* 1135 */         for (int k = 0; k < item.size(); k++) {
/* 1136 */           if (hit.isHit(k)) {
/* 1137 */             PdfDictionary merged = item.getMerged(k);
/* 1138 */             PdfDictionary mk = merged.getAsDict(PdfName.MK);
/* 1139 */             if (mk == null) {
/* 1140 */               if (value == null)
/* 1141 */                 return true;
/* 1142 */               mk = new PdfDictionary();
/* 1143 */               item.getMerged(k).put(PdfName.MK, mk);
/* 1144 */               item.getWidget(k).put(PdfName.MK, mk);
/* 1145 */               markUsed(item.getWidget(k));
/*      */             } else {
/* 1147 */               markUsed(mk);
/*      */             }
/* 1149 */             if (value == null) {
/* 1150 */               mk.remove(dname);
/*      */             } else {
/* 1152 */               mk.put(dname, PdfFormField.getMKColor((BaseColor)value));
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1157 */         return false; }
/* 1158 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/* 1161 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setFieldProperty(String field, String name, int value, int[] inst)
/*      */   {
/* 1193 */     if (this.writer == null)
/* 1194 */       throw new RuntimeException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[0]));
/* 1195 */     Item item = (Item)this.fields.get(field);
/* 1196 */     if (item == null)
/* 1197 */       return false;
/* 1198 */     InstHit hit = new InstHit(inst);
/* 1199 */     if (name.equalsIgnoreCase("flags")) {
/* 1200 */       PdfNumber num = new PdfNumber(value);
/* 1201 */       for (int k = 0; k < item.size(); k++) {
/* 1202 */         if (hit.isHit(k)) {
/* 1203 */           item.getMerged(k).put(PdfName.F, num);
/* 1204 */           item.getWidget(k).put(PdfName.F, num);
/* 1205 */           markUsed(item.getWidget(k));
/*      */         }
/*      */       }
/*      */     }
/* 1209 */     else if (name.equalsIgnoreCase("setflags")) {
/* 1210 */       for (int k = 0; k < item.size(); k++) {
/* 1211 */         if (hit.isHit(k)) {
/* 1212 */           PdfNumber num = item.getWidget(k).getAsNumber(PdfName.F);
/* 1213 */           int val = 0;
/* 1214 */           if (num != null)
/* 1215 */             val = num.intValue();
/* 1216 */           num = new PdfNumber(val | value);
/* 1217 */           item.getMerged(k).put(PdfName.F, num);
/* 1218 */           item.getWidget(k).put(PdfName.F, num);
/* 1219 */           markUsed(item.getWidget(k));
/*      */         }
/*      */       }
/*      */     }
/* 1223 */     else if (name.equalsIgnoreCase("clrflags")) {
/* 1224 */       for (int k = 0; k < item.size(); k++) {
/* 1225 */         if (hit.isHit(k)) {
/* 1226 */           PdfDictionary widget = item.getWidget(k);
/* 1227 */           PdfNumber num = widget.getAsNumber(PdfName.F);
/* 1228 */           int val = 0;
/* 1229 */           if (num != null)
/* 1230 */             val = num.intValue();
/* 1231 */           num = new PdfNumber(val & (value ^ 0xFFFFFFFF));
/* 1232 */           item.getMerged(k).put(PdfName.F, num);
/* 1233 */           widget.put(PdfName.F, num);
/* 1234 */           markUsed(widget);
/*      */         }
/*      */       }
/*      */     }
/* 1238 */     else if (name.equalsIgnoreCase("fflags")) {
/* 1239 */       PdfNumber num = new PdfNumber(value);
/* 1240 */       for (int k = 0; k < item.size(); k++) {
/* 1241 */         if (hit.isHit(k)) {
/* 1242 */           item.getMerged(k).put(PdfName.FF, num);
/* 1243 */           item.getValue(k).put(PdfName.FF, num);
/* 1244 */           markUsed(item.getValue(k));
/*      */         }
/*      */       }
/*      */     }
/* 1248 */     else if (name.equalsIgnoreCase("setfflags")) {
/* 1249 */       for (int k = 0; k < item.size(); k++) {
/* 1250 */         if (hit.isHit(k)) {
/* 1251 */           PdfDictionary valDict = item.getValue(k);
/* 1252 */           PdfNumber num = valDict.getAsNumber(PdfName.FF);
/* 1253 */           int val = 0;
/* 1254 */           if (num != null)
/* 1255 */             val = num.intValue();
/* 1256 */           num = new PdfNumber(val | value);
/* 1257 */           item.getMerged(k).put(PdfName.FF, num);
/* 1258 */           valDict.put(PdfName.FF, num);
/* 1259 */           markUsed(valDict);
/*      */         }
/*      */       }
/*      */     }
/* 1263 */     else if (name.equalsIgnoreCase("clrfflags")) {
/* 1264 */       for (int k = 0; k < item.size(); k++) {
/* 1265 */         if (hit.isHit(k)) {
/* 1266 */           PdfDictionary valDict = item.getValue(k);
/* 1267 */           PdfNumber num = valDict.getAsNumber(PdfName.FF);
/* 1268 */           int val = 0;
/* 1269 */           if (num != null)
/* 1270 */             val = num.intValue();
/* 1271 */           num = new PdfNumber(val & (value ^ 0xFFFFFFFF));
/* 1272 */           item.getMerged(k).put(PdfName.FF, num);
/* 1273 */           valDict.put(PdfName.FF, num);
/* 1274 */           markUsed(valDict);
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1279 */       return false; }
/* 1280 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mergeXfaData(Node n)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1291 */     XfaForm.Xml2SomDatasets data = new XfaForm.Xml2SomDatasets(n);
/* 1292 */     for (String string : data.getOrder()) {
/* 1293 */       String name = string;
/* 1294 */       String text = XfaForm.getNodeText((Node)data.getName2Node().get(name));
/* 1295 */       setField(name, text);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFields(FdfReader fdf)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1307 */     HashMap<String, PdfDictionary> fd = fdf.getFields();
/* 1308 */     for (String f : fd.keySet()) {
/* 1309 */       String v = fdf.getFieldValue(f);
/* 1310 */       if (v != null) {
/* 1311 */         setField(f, v);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFields(XfdfReader xfdf)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1323 */     HashMap<String, String> fd = xfdf.getFields();
/* 1324 */     for (String f : fd.keySet()) {
/* 1325 */       String v = xfdf.getFieldValue(f);
/* 1326 */       if (v != null)
/* 1327 */         setField(f, v);
/* 1328 */       List<String> l = xfdf.getListValues(f);
/* 1329 */       if (l != null) {
/* 1330 */         setListSelection(v, (String[])l.toArray(new String[l.size()]));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean regenerateField(String name)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1348 */     String value = getField(name);
/* 1349 */     return setField(name, value, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setField(String name, String value)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1363 */     return setField(name, value, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setField(String name, String value, boolean saveAppearance)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1378 */     return setField(name, value, null, saveAppearance);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setFieldRichValue(String name, String richValue)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1394 */     if (this.writer == null)
/*      */     {
/* 1396 */       throw new DocumentException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[0]));
/*      */     }
/*      */     
/* 1399 */     Item item = getFieldItem(name);
/* 1400 */     if (item == null)
/*      */     {
/* 1402 */       return false;
/*      */     }
/*      */     
/* 1405 */     if (getFieldType(name) != 4)
/*      */     {
/* 1407 */       return false;
/*      */     }
/*      */     
/* 1410 */     PdfDictionary merged = item.getMerged(0);
/* 1411 */     PdfNumber ffNum = merged.getAsNumber(PdfName.FF);
/* 1412 */     int flagVal = 0;
/* 1413 */     if (ffNum != null) {
/* 1414 */       flagVal = ffNum.intValue();
/*      */     }
/* 1416 */     if ((flagVal & 0x2000000) == 0)
/*      */     {
/* 1418 */       return false;
/*      */     }
/*      */     
/* 1421 */     PdfString richString = new PdfString(richValue);
/* 1422 */     item.writeToAll(PdfName.RV, richString, 5);
/*      */     
/* 1424 */     InputStream is = new ByteArrayInputStream(richValue.getBytes());
/* 1425 */     PdfString valueString = new PdfString(XmlToTxt.parse(is));
/* 1426 */     item.writeToAll(PdfName.V, valueString, 5);
/* 1427 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setField(String name, String value, String display)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1446 */     return setField(name, value, display, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setField(String name, String value, String display, boolean saveAppearance)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1466 */     if (this.writer == null)
/* 1467 */       throw new DocumentException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[0]));
/* 1468 */     if (this.xfa.isXfaPresent()) {
/* 1469 */       name = this.xfa.findFieldName(name, this);
/* 1470 */       if (name == null)
/* 1471 */         return false;
/* 1472 */       String shortName = XfaForm.Xml2Som.getShortName(name);
/* 1473 */       Node xn = this.xfa.findDatasetsNode(shortName);
/* 1474 */       if (xn == null) {
/* 1475 */         xn = this.xfa.getDatasetsSom().insertNode(this.xfa.getDatasetsNode(), shortName);
/*      */       }
/* 1477 */       this.xfa.setNodeText(xn, value);
/*      */     }
/* 1479 */     Item item = (Item)this.fields.get(name);
/* 1480 */     if (item == null)
/* 1481 */       return false;
/* 1482 */     PdfDictionary merged = item.getMerged(0);
/* 1483 */     PdfName type = merged.getAsName(PdfName.FT);
/* 1484 */     if (PdfName.TX.equals(type)) {
/* 1485 */       PdfNumber maxLen = merged.getAsNumber(PdfName.MAXLEN);
/* 1486 */       int len = 0;
/* 1487 */       if (maxLen != null)
/* 1488 */         len = maxLen.intValue();
/* 1489 */       if (len > 0)
/* 1490 */         value = value.substring(0, Math.min(len, value.length()));
/*      */     }
/* 1492 */     if (display == null)
/* 1493 */       display = value;
/* 1494 */     if ((PdfName.TX.equals(type)) || (PdfName.CH.equals(type))) {
/* 1495 */       PdfString v = new PdfString(value, "UnicodeBig");
/* 1496 */       for (int idx = 0; idx < item.size(); idx++) {
/* 1497 */         PdfDictionary valueDic = item.getValue(idx);
/* 1498 */         valueDic.put(PdfName.V, v);
/* 1499 */         valueDic.remove(PdfName.I);
/* 1500 */         markUsed(valueDic);
/* 1501 */         merged = item.getMerged(idx);
/* 1502 */         merged.remove(PdfName.I);
/* 1503 */         merged.put(PdfName.V, v);
/* 1504 */         PdfDictionary widget = item.getWidget(idx);
/* 1505 */         if (this.generateAppearances) {
/* 1506 */           PdfAppearance app = getAppearance(merged, display, name);
/* 1507 */           if (PdfName.CH.equals(type)) {
/* 1508 */             PdfNumber n = new PdfNumber(this.topFirst);
/* 1509 */             widget.put(PdfName.TI, n);
/* 1510 */             merged.put(PdfName.TI, n);
/*      */           }
/* 1512 */           PdfDictionary appDic = widget.getAsDict(PdfName.AP);
/* 1513 */           if (appDic == null) {
/* 1514 */             appDic = new PdfDictionary();
/* 1515 */             widget.put(PdfName.AP, appDic);
/* 1516 */             merged.put(PdfName.AP, appDic);
/*      */           }
/* 1518 */           appDic.put(PdfName.N, app.getIndirectReference());
/* 1519 */           this.writer.releaseTemplate(app);
/*      */         }
/*      */         else {
/* 1522 */           widget.remove(PdfName.AP);
/* 1523 */           merged.remove(PdfName.AP);
/*      */         }
/* 1525 */         markUsed(widget);
/*      */       }
/* 1527 */       return true;
/*      */     }
/* 1529 */     if (PdfName.BTN.equals(type)) {
/* 1530 */       PdfNumber ff = item.getMerged(0).getAsNumber(PdfName.FF);
/* 1531 */       int flags = 0;
/* 1532 */       if (ff != null)
/* 1533 */         flags = ff.intValue();
/* 1534 */       if ((flags & 0x10000) != 0)
/*      */       {
/*      */         try
/*      */         {
/* 1538 */           img = Image.getInstance(Base64.decode(value));
/*      */         } catch (Exception e) {
/*      */           Image img;
/* 1541 */           return false; }
/*      */         Image img;
/* 1543 */         PushbuttonField pb = getNewPushbuttonFromField(name);
/* 1544 */         pb.setImage(img);
/* 1545 */         replacePushbuttonField(name, pb.getField());
/* 1546 */         return true;
/*      */       }
/* 1548 */       PdfName v = new PdfName(value);
/* 1549 */       ArrayList<String> lopt = new ArrayList();
/* 1550 */       PdfArray opts = item.getValue(0).getAsArray(PdfName.OPT);
/* 1551 */       if (opts != null) {
/* 1552 */         for (int k = 0; k < opts.size(); k++) {
/* 1553 */           PdfString valStr = opts.getAsString(k);
/* 1554 */           if (valStr != null) {
/* 1555 */             lopt.add(valStr.toUnicodeString());
/*      */           } else
/* 1557 */             lopt.add(null);
/*      */         }
/*      */       }
/* 1560 */       int vidx = lopt.indexOf(value);
/*      */       PdfName vt;
/* 1562 */       PdfName vt; if (vidx >= 0) {
/* 1563 */         vt = new PdfName(String.valueOf(vidx));
/*      */       } else
/* 1565 */         vt = v;
/* 1566 */       for (int idx = 0; idx < item.size(); idx++) {
/* 1567 */         merged = item.getMerged(idx);
/* 1568 */         PdfDictionary widget = item.getWidget(idx);
/* 1569 */         PdfDictionary valDict = item.getValue(idx);
/* 1570 */         markUsed(item.getValue(idx));
/* 1571 */         valDict.put(PdfName.V, vt);
/* 1572 */         merged.put(PdfName.V, vt);
/* 1573 */         markUsed(widget);
/* 1574 */         PdfDictionary appDic = widget.getAsDict(PdfName.AP);
/* 1575 */         if (appDic == null)
/* 1576 */           return false;
/* 1577 */         PdfDictionary normal = appDic.getAsDict(PdfName.N);
/* 1578 */         if ((isInAP(normal, vt)) || (normal == null)) {
/* 1579 */           merged.put(PdfName.AS, vt);
/* 1580 */           widget.put(PdfName.AS, vt);
/*      */         }
/*      */         else {
/* 1583 */           merged.put(PdfName.AS, PdfName.Off);
/* 1584 */           widget.put(PdfName.AS, PdfName.Off);
/*      */         }
/* 1586 */         if ((this.generateAppearances) && (!saveAppearance)) {
/* 1587 */           PdfAppearance app = getAppearance(merged, display, name);
/* 1588 */           if (normal != null) {
/* 1589 */             normal.put(merged.getAsName(PdfName.AS), app.getIndirectReference());
/*      */           } else
/* 1591 */             appDic.put(PdfName.N, app.getIndirectReference());
/* 1592 */           this.writer.releaseTemplate(app);
/*      */         }
/*      */       }
/* 1595 */       return true;
/*      */     }
/* 1597 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setListSelection(String name, String[] value)
/*      */     throws IOException, DocumentException
/*      */   {
/* 1610 */     Item item = getFieldItem(name);
/* 1611 */     if (item == null)
/* 1612 */       return false;
/* 1613 */     PdfDictionary merged = item.getMerged(0);
/* 1614 */     PdfName type = merged.getAsName(PdfName.FT);
/* 1615 */     if (!PdfName.CH.equals(type)) {
/* 1616 */       return false;
/*      */     }
/* 1618 */     String[] options = getListOptionExport(name);
/* 1619 */     PdfArray array = new PdfArray();
/* 1620 */     for (String element : value) {
/* 1621 */       for (int j = 0; j < options.length; j++) {
/* 1622 */         if (options[j].equals(element)) {
/* 1623 */           array.add(new PdfNumber(j));
/* 1624 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1628 */     item.writeToAll(PdfName.I, array, 5);
/*      */     
/* 1630 */     PdfArray vals = new PdfArray();
/* 1631 */     for (int i = 0; i < value.length; i++) {
/* 1632 */       vals.add(new PdfString(value[i]));
/*      */     }
/* 1634 */     item.writeToAll(PdfName.V, vals, 5);
/*      */     
/* 1636 */     PdfAppearance app = getAppearance(merged, value, name);
/*      */     
/* 1638 */     PdfDictionary apDic = new PdfDictionary();
/* 1639 */     apDic.put(PdfName.N, app.getIndirectReference());
/* 1640 */     item.writeToAll(PdfName.AP, apDic, 3);
/*      */     
/* 1642 */     this.writer.releaseTemplate(app);
/*      */     
/* 1644 */     item.markUsed(this, 6);
/* 1645 */     return true;
/*      */   }
/*      */   
/*      */   boolean isInAP(PdfDictionary nDic, PdfName check) {
/* 1649 */     return (nDic != null) && (nDic.get(check) != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, Item> getFields()
/*      */   {
/* 1659 */     return this.fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Item getFieldItem(String name)
/*      */   {
/* 1670 */     if (this.xfa.isXfaPresent()) {
/* 1671 */       name = this.xfa.findFieldName(name, this);
/* 1672 */       if (name == null)
/* 1673 */         return null;
/*      */     }
/* 1675 */     return (Item)this.fields.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTranslatedFieldName(String name)
/*      */   {
/* 1685 */     if (this.xfa.isXfaPresent()) {
/* 1686 */       String namex = this.xfa.findFieldName(name, this);
/* 1687 */       if (namex != null)
/* 1688 */         name = namex;
/*      */     }
/* 1690 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<FieldPosition> getFieldPositions(String name)
/*      */   {
/* 1702 */     Item item = getFieldItem(name);
/* 1703 */     if (item == null)
/* 1704 */       return null;
/* 1705 */     ArrayList<FieldPosition> ret = new ArrayList();
/* 1706 */     for (int k = 0; k < item.size(); k++) {
/*      */       try {
/* 1708 */         PdfDictionary wd = item.getWidget(k);
/* 1709 */         PdfArray rect = wd.getAsArray(PdfName.RECT);
/* 1710 */         if (rect != null)
/*      */         {
/* 1712 */           Rectangle r = PdfReader.getNormalizedRectangle(rect);
/* 1713 */           int page = item.getPage(k).intValue();
/* 1714 */           int rotation = this.reader.getPageRotation(page);
/* 1715 */           FieldPosition fp = new FieldPosition();
/* 1716 */           fp.page = page;
/* 1717 */           if (rotation != 0) {
/* 1718 */             Rectangle pageSize = this.reader.getPageSize(page);
/* 1719 */             switch (rotation)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */             case 270: 
/* 1725 */               r = new Rectangle(pageSize.getTop() - r.getBottom(), r.getLeft(), pageSize.getTop() - r.getTop(), r.getRight());
/* 1726 */               break;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             case 180: 
/* 1732 */               r = new Rectangle(pageSize.getRight() - r.getLeft(), pageSize.getTop() - r.getBottom(), pageSize.getRight() - r.getRight(), pageSize.getTop() - r.getTop());
/* 1733 */               break;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             case 90: 
/* 1739 */               r = new Rectangle(r.getBottom(), pageSize.getRight() - r.getLeft(), r.getTop(), pageSize.getRight() - r.getRight());
/*      */             }
/*      */             
/* 1742 */             r.normalize();
/*      */           }
/* 1744 */           fp.position = r;
/* 1745 */           ret.add(fp);
/*      */         }
/*      */       }
/*      */       catch (Exception localException) {}
/*      */     }
/*      */     
/* 1751 */     return ret;
/*      */   }
/*      */   
/*      */   private int removeRefFromArray(PdfArray array, PdfObject refo) {
/* 1755 */     if ((refo == null) || (!refo.isIndirect()))
/* 1756 */       return array.size();
/* 1757 */     PdfIndirectReference ref = (PdfIndirectReference)refo;
/* 1758 */     for (int j = 0; j < array.size(); j++) {
/* 1759 */       PdfObject obj = array.getPdfObject(j);
/* 1760 */       if (obj.isIndirect())
/*      */       {
/* 1762 */         if (((PdfIndirectReference)obj).getNumber() == ref.getNumber())
/* 1763 */           array.remove(j--); }
/*      */     }
/* 1765 */     return array.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeFieldsFromPage(int page)
/*      */   {
/* 1775 */     if (page < 1)
/* 1776 */       return false;
/* 1777 */     String[] names = new String[this.fields.size()];
/* 1778 */     this.fields.keySet().toArray(names);
/* 1779 */     boolean found = false;
/* 1780 */     for (int k = 0; k < names.length; k++) {
/* 1781 */       boolean fr = removeField(names[k], page);
/* 1782 */       found = (found) || (fr);
/*      */     }
/* 1784 */     return found;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeField(String name, int page)
/*      */   {
/* 1797 */     Item item = getFieldItem(name);
/* 1798 */     if (item == null)
/* 1799 */       return false;
/* 1800 */     PdfDictionary acroForm = (PdfDictionary)PdfReader.getPdfObject(this.reader.getCatalog().get(PdfName.ACROFORM), this.reader.getCatalog());
/*      */     
/* 1802 */     if (acroForm == null)
/* 1803 */       return false;
/* 1804 */     PdfArray arrayf = acroForm.getAsArray(PdfName.FIELDS);
/* 1805 */     if (arrayf == null)
/* 1806 */       return false;
/* 1807 */     for (int k = 0; k < item.size(); k++) {
/* 1808 */       int pageV = item.getPage(k).intValue();
/* 1809 */       if ((page == -1) || (page == pageV))
/*      */       {
/* 1811 */         PdfIndirectReference ref = item.getWidgetRef(k);
/* 1812 */         PdfDictionary wd = item.getWidget(k);
/* 1813 */         PdfDictionary pageDic = this.reader.getPageN(pageV);
/* 1814 */         PdfArray annots = pageDic.getAsArray(PdfName.ANNOTS);
/* 1815 */         if (annots != null)
/* 1816 */           if (removeRefFromArray(annots, ref) == 0) {
/* 1817 */             pageDic.remove(PdfName.ANNOTS);
/* 1818 */             markUsed(pageDic);
/*      */           }
/*      */           else {
/* 1821 */             markUsed(annots);
/*      */           }
/* 1823 */         PdfReader.killIndirect(ref);
/* 1824 */         PdfIndirectReference kid = ref;
/* 1825 */         while ((ref = wd.getAsIndirectObject(PdfName.PARENT)) != null) {
/* 1826 */           wd = wd.getAsDict(PdfName.PARENT);
/* 1827 */           PdfArray kids = wd.getAsArray(PdfName.KIDS);
/* 1828 */           if (removeRefFromArray(kids, kid) != 0)
/*      */             break;
/* 1830 */           kid = ref;
/* 1831 */           PdfReader.killIndirect(ref);
/*      */         }
/* 1833 */         if (ref == null) {
/* 1834 */           removeRefFromArray(arrayf, kid);
/* 1835 */           markUsed(arrayf);
/*      */         }
/* 1837 */         if (page != -1) {
/* 1838 */           item.remove(k);
/* 1839 */           k--;
/*      */         }
/*      */       } }
/* 1842 */     if ((page == -1) || (item.size() == 0))
/* 1843 */       this.fields.remove(name);
/* 1844 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeField(String name)
/*      */   {
/* 1854 */     return removeField(name, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isGenerateAppearances()
/*      */   {
/* 1863 */     return this.generateAppearances;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGenerateAppearances(boolean generateAppearances)
/*      */   {
/* 1875 */     this.generateAppearances = generateAppearances;
/* 1876 */     PdfDictionary top = this.reader.getCatalog().getAsDict(PdfName.ACROFORM);
/* 1877 */     if (generateAppearances) {
/* 1878 */       top.remove(PdfName.NEEDAPPEARANCES);
/*      */     } else {
/* 1880 */       top.put(PdfName.NEEDAPPEARANCES, PdfBoolean.PDFTRUE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Item
/*      */   {
/*      */     public static final int WRITE_MERGED = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static final int WRITE_WIDGET = 2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static final int WRITE_VALUE = 4;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void writeToAll(PdfName key, PdfObject value, int writeFlags)
/*      */     {
/* 1919 */       PdfDictionary curDict = null;
/* 1920 */       if ((writeFlags & 0x1) != 0) {
/* 1921 */         for (int i = 0; i < this.merged.size(); i++) {
/* 1922 */           curDict = getMerged(i);
/* 1923 */           curDict.put(key, value);
/*      */         }
/*      */       }
/* 1926 */       if ((writeFlags & 0x2) != 0) {
/* 1927 */         for (int i = 0; i < this.widgets.size(); i++) {
/* 1928 */           curDict = getWidget(i);
/* 1929 */           curDict.put(key, value);
/*      */         }
/*      */       }
/* 1932 */       if ((writeFlags & 0x4) != 0) {
/* 1933 */         for (int i = 0; i < this.values.size(); i++) {
/* 1934 */           curDict = getValue(i);
/* 1935 */           curDict.put(key, value);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void markUsed(AcroFields parentFields, int writeFlags)
/*      */     {
/* 1947 */       if ((writeFlags & 0x4) != 0) {
/* 1948 */         for (int i = 0; i < size(); i++) {
/* 1949 */           parentFields.markUsed(getValue(i));
/*      */         }
/*      */       }
/* 1952 */       if ((writeFlags & 0x2) != 0) {
/* 1953 */         for (int i = 0; i < size(); i++) {
/* 1954 */           parentFields.markUsed(getWidget(i));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1965 */     protected ArrayList<PdfDictionary> values = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1972 */     protected ArrayList<PdfDictionary> widgets = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1979 */     protected ArrayList<PdfIndirectReference> widget_refs = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1987 */     protected ArrayList<PdfDictionary> merged = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1995 */     protected ArrayList<Integer> page = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2001 */     protected ArrayList<Integer> tabOrder = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int size()
/*      */     {
/* 2011 */       return this.values.size();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void remove(int killIdx)
/*      */     {
/* 2022 */       this.values.remove(killIdx);
/* 2023 */       this.widgets.remove(killIdx);
/* 2024 */       this.widget_refs.remove(killIdx);
/* 2025 */       this.merged.remove(killIdx);
/* 2026 */       this.page.remove(killIdx);
/* 2027 */       this.tabOrder.remove(killIdx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfDictionary getValue(int idx)
/*      */     {
/* 2038 */       return (PdfDictionary)this.values.get(idx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addValue(PdfDictionary value)
/*      */     {
/* 2048 */       this.values.add(value);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfDictionary getWidget(int idx)
/*      */     {
/* 2059 */       return (PdfDictionary)this.widgets.get(idx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addWidget(PdfDictionary widget)
/*      */     {
/* 2069 */       this.widgets.add(widget);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfIndirectReference getWidgetRef(int idx)
/*      */     {
/* 2080 */       return (PdfIndirectReference)this.widget_refs.get(idx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addWidgetRef(PdfIndirectReference widgRef)
/*      */     {
/* 2090 */       this.widget_refs.add(widgRef);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfDictionary getMerged(int idx)
/*      */     {
/* 2104 */       return (PdfDictionary)this.merged.get(idx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addMerged(PdfDictionary mergeDict)
/*      */     {
/* 2114 */       this.merged.add(mergeDict);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Integer getPage(int idx)
/*      */     {
/* 2125 */       return (Integer)this.page.get(idx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addPage(int pg)
/*      */     {
/* 2135 */       this.page.add(Integer.valueOf(pg));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void forcePage(int idx, int pg)
/*      */     {
/* 2145 */       this.page.set(idx, Integer.valueOf(pg));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Integer getTabOrder(int idx)
/*      */     {
/* 2156 */       return (Integer)this.tabOrder.get(idx);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2166 */     void addTabOrder(int order) { this.tabOrder.add(Integer.valueOf(order)); }
/*      */   }
/*      */   
/*      */   private static class InstHit {
/*      */     IntHashtable hits;
/*      */     
/*      */     public InstHit(int[] inst) {
/* 2173 */       if (inst == null)
/* 2174 */         return;
/* 2175 */       this.hits = new IntHashtable();
/* 2176 */       for (int k = 0; k < inst.length; k++)
/* 2177 */         this.hits.put(inst[k], 1);
/*      */     }
/*      */     
/*      */     public boolean isHit(int n) {
/* 2181 */       if (this.hits == null)
/* 2182 */         return true;
/* 2183 */       return this.hits.containsKey(n);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean clearSignatureField(String name)
/*      */   {
/* 2194 */     this.sigNames = null;
/* 2195 */     getSignatureNames();
/* 2196 */     if (!this.sigNames.containsKey(name))
/* 2197 */       return false;
/* 2198 */     Item sig = (Item)this.fields.get(name);
/* 2199 */     sig.markUsed(this, 6);
/* 2200 */     int n = sig.size();
/* 2201 */     for (int k = 0; k < n; k++) {
/* 2202 */       clearSigDic(sig.getMerged(k));
/* 2203 */       clearSigDic(sig.getWidget(k));
/* 2204 */       clearSigDic(sig.getValue(k));
/*      */     }
/* 2206 */     return true;
/*      */   }
/*      */   
/*      */   private static void clearSigDic(PdfDictionary dic) {
/* 2210 */     dic.remove(PdfName.AP);
/* 2211 */     dic.remove(PdfName.AS);
/* 2212 */     dic.remove(PdfName.V);
/* 2213 */     dic.remove(PdfName.DV);
/* 2214 */     dic.remove(PdfName.SV);
/* 2215 */     dic.remove(PdfName.FF);
/* 2216 */     dic.put(PdfName.F, new PdfNumber(4));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<String> getSignatureNames()
/*      */   {
/* 2227 */     if (this.sigNames != null)
/* 2228 */       return new ArrayList(this.orderedSignatureNames);
/* 2229 */     this.sigNames = new HashMap();
/* 2230 */     this.orderedSignatureNames = new ArrayList();
/* 2231 */     ArrayList<Object[]> sorter = new ArrayList();
/* 2232 */     for (Map.Entry<String, Item> entry : this.fields.entrySet()) {
/* 2233 */       Item item = (Item)entry.getValue();
/* 2234 */       PdfDictionary merged = item.getMerged(0);
/* 2235 */       if (PdfName.SIG.equals(merged.get(PdfName.FT)))
/*      */       {
/* 2237 */         PdfDictionary v = merged.getAsDict(PdfName.V);
/* 2238 */         if (v != null)
/*      */         {
/* 2240 */           PdfString contents = v.getAsString(PdfName.CONTENTS);
/* 2241 */           if (contents != null)
/*      */           {
/* 2243 */             PdfArray ro = v.getAsArray(PdfName.BYTERANGE);
/* 2244 */             if (ro != null)
/*      */             {
/* 2246 */               int rangeSize = ro.size();
/* 2247 */               if (rangeSize >= 2)
/*      */               {
/* 2249 */                 int length = ro.getAsNumber(rangeSize - 1).intValue() + ro.getAsNumber(rangeSize - 2).intValue();
/* 2250 */                 sorter.add(new Object[] { entry.getKey(), { length, 0 } });
/*      */               } } } } } }
/* 2252 */     Collections.sort(sorter, new SorterComparator(null));
/* 2253 */     if (!sorter.isEmpty()) {
/* 2254 */       if (((int[])(int[])((Object[])sorter.get(sorter.size() - 1))[1])[0] == this.reader.getFileLength()) {
/* 2255 */         this.totalRevisions = sorter.size();
/*      */       } else
/* 2257 */         this.totalRevisions = (sorter.size() + 1);
/* 2258 */       for (int k = 0; k < sorter.size(); k++) {
/* 2259 */         Object[] objs = (Object[])sorter.get(k);
/* 2260 */         String name = (String)objs[0];
/* 2261 */         int[] p = (int[])objs[1];
/* 2262 */         p[1] = (k + 1);
/* 2263 */         this.sigNames.put(name, p);
/* 2264 */         this.orderedSignatureNames.add(name);
/*      */       }
/*      */     }
/* 2267 */     return new ArrayList(this.orderedSignatureNames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<String> getBlankSignatureNames()
/*      */   {
/* 2276 */     getSignatureNames();
/* 2277 */     ArrayList<String> sigs = new ArrayList();
/* 2278 */     for (Map.Entry<String, Item> entry : this.fields.entrySet()) {
/* 2279 */       Item item = (Item)entry.getValue();
/* 2280 */       PdfDictionary merged = item.getMerged(0);
/* 2281 */       if ((PdfName.SIG.equals(merged.getAsName(PdfName.FT))) && 
/*      */       
/* 2283 */         (!this.sigNames.containsKey(entry.getKey())))
/*      */       {
/* 2285 */         sigs.add(entry.getKey()); }
/*      */     }
/* 2287 */     return sigs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getSignatureDictionary(String name)
/*      */   {
/* 2298 */     getSignatureNames();
/* 2299 */     name = getTranslatedFieldName(name);
/* 2300 */     if (!this.sigNames.containsKey(name))
/* 2301 */       return null;
/* 2302 */     Item item = (Item)this.fields.get(name);
/* 2303 */     PdfDictionary merged = item.getMerged(0);
/* 2304 */     return merged.getAsDict(PdfName.V);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectReference getNormalAppearance(String name)
/*      */   {
/* 2314 */     getSignatureNames();
/* 2315 */     name = getTranslatedFieldName(name);
/* 2316 */     Item item = (Item)this.fields.get(name);
/* 2317 */     if (item == null)
/* 2318 */       return null;
/* 2319 */     PdfDictionary merged = item.getMerged(0);
/* 2320 */     PdfDictionary ap = merged.getAsDict(PdfName.AP);
/* 2321 */     if (ap == null)
/* 2322 */       return null;
/* 2323 */     PdfIndirectReference ref = ap.getAsIndirectObject(PdfName.N);
/* 2324 */     if (ref == null)
/* 2325 */       return null;
/* 2326 */     return ref;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean signatureCoversWholeDocument(String name)
/*      */   {
/* 2337 */     getSignatureNames();
/* 2338 */     name = getTranslatedFieldName(name);
/* 2339 */     if (!this.sigNames.containsKey(name))
/* 2340 */       return false;
/* 2341 */     return ((int[])this.sigNames.get(name))[0] == this.reader.getFileLength();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPKCS7 verifySignature(String name)
/*      */   {
/* 2373 */     return verifySignature(name, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPKCS7 verifySignature(String name, String provider)
/*      */   {
/* 2406 */     PdfDictionary v = getSignatureDictionary(name);
/* 2407 */     if (v == null)
/* 2408 */       return null;
/*      */     try {
/* 2410 */       PdfName sub = v.getAsName(PdfName.SUBFILTER);
/* 2411 */       PdfString contents = v.getAsString(PdfName.CONTENTS);
/* 2412 */       PdfPKCS7 pk = null;
/* 2413 */       if (sub.equals(PdfName.ADBE_X509_RSA_SHA1)) {
/* 2414 */         PdfString cert = v.getAsString(PdfName.CERT);
/* 2415 */         if (cert == null)
/* 2416 */           cert = v.getAsArray(PdfName.CERT).getAsString(0);
/* 2417 */         pk = new PdfPKCS7(contents.getOriginalBytes(), cert.getBytes(), provider);
/*      */       }
/*      */       else {
/* 2420 */         pk = new PdfPKCS7(contents.getOriginalBytes(), sub, provider); }
/* 2421 */       updateByteRange(pk, v);
/* 2422 */       PdfString str = v.getAsString(PdfName.M);
/* 2423 */       if (str != null)
/* 2424 */         pk.setSignDate(PdfDate.decode(str.toString()));
/* 2425 */       PdfObject obj = PdfReader.getPdfObject(v.get(PdfName.NAME));
/* 2426 */       if (obj != null) {
/* 2427 */         if (obj.isString()) {
/* 2428 */           pk.setSignName(((PdfString)obj).toUnicodeString());
/* 2429 */         } else if (obj.isName())
/* 2430 */           pk.setSignName(PdfName.decodeName(obj.toString()));
/*      */       }
/* 2432 */       str = v.getAsString(PdfName.REASON);
/* 2433 */       if (str != null)
/* 2434 */         pk.setReason(str.toUnicodeString());
/* 2435 */       str = v.getAsString(PdfName.LOCATION);
/* 2436 */       if (str != null)
/* 2437 */         pk.setLocation(str.toUnicodeString());
/* 2438 */       return pk;
/*      */     }
/*      */     catch (Exception e) {
/* 2441 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateByteRange(PdfPKCS7 pkcs7, PdfDictionary v) {
/* 2446 */     PdfArray b = v.getAsArray(PdfName.BYTERANGE);
/* 2447 */     RandomAccessFileOrArray rf = this.reader.getSafeFile();
/* 2448 */     InputStream rg = null;
/*      */     try {
/* 2450 */       rg = new RASInputStream(new RandomAccessSourceFactory().createRanged(rf.createSourceView(), b.asLongArray()));
/* 2451 */       byte[] buf = new byte[' '];
/*      */       int rd;
/* 2453 */       while ((rd = rg.read(buf, 0, buf.length)) > 0) {
/* 2454 */         pkcs7.update(buf, 0, rd);
/*      */       }
/*      */       return;
/*      */     } catch (Exception e) {
/* 2458 */       throw new ExceptionConverter(e);
/*      */     } finally {
/*      */       try {
/* 2461 */         if (rg != null) rg.close();
/*      */       }
/*      */       catch (IOException e) {
/* 2464 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void markUsed(PdfObject obj) {
/* 2470 */     if (!this.append)
/* 2471 */       return;
/* 2472 */     ((PdfStamperImp)this.writer).markUsed(obj);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTotalRevisions()
/*      */   {
/* 2481 */     getSignatureNames();
/* 2482 */     return this.totalRevisions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRevision(String field)
/*      */   {
/* 2492 */     getSignatureNames();
/* 2493 */     field = getTranslatedFieldName(field);
/* 2494 */     if (!this.sigNames.containsKey(field))
/* 2495 */       return 0;
/* 2496 */     return ((int[])this.sigNames.get(field))[1];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream extractRevision(String field)
/*      */     throws IOException
/*      */   {
/* 2508 */     getSignatureNames();
/* 2509 */     field = getTranslatedFieldName(field);
/* 2510 */     if (!this.sigNames.containsKey(field))
/* 2511 */       return null;
/* 2512 */     int length = ((int[])this.sigNames.get(field))[0];
/* 2513 */     RandomAccessFileOrArray raf = this.reader.getSafeFile();
/* 2514 */     return new RASInputStream(new WindowRandomAccessSource(raf.createSourceView(), 0L, length));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, TextField> getFieldCache()
/*      */   {
/* 2524 */     return this.fieldCache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFieldCache(Map<String, TextField> fieldCache)
/*      */   {
/* 2554 */     this.fieldCache = fieldCache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExtraMargin(float extraMarginLeft, float extraMarginTop)
/*      */   {
/* 2564 */     this.extraMarginLeft = extraMarginLeft;
/* 2565 */     this.extraMarginTop = extraMarginTop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSubstitutionFont(BaseFont font)
/*      */   {
/* 2575 */     if (this.substitutionFonts == null)
/* 2576 */       this.substitutionFonts = new ArrayList();
/* 2577 */     this.substitutionFonts.add(font);
/*      */   }
/*      */   
/* 2580 */   private static final HashMap<String, String[]> stdFieldFontNames = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */   private int totalRevisions;
/*      */   
/*      */ 
/*      */ 
/*      */   private Map<String, TextField> fieldCache;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/* 2595 */     stdFieldFontNames.put("CoBO", new String[] { "Courier-BoldOblique" });
/* 2596 */     stdFieldFontNames.put("CoBo", new String[] { "Courier-Bold" });
/* 2597 */     stdFieldFontNames.put("CoOb", new String[] { "Courier-Oblique" });
/* 2598 */     stdFieldFontNames.put("Cour", new String[] { "Courier" });
/* 2599 */     stdFieldFontNames.put("HeBO", new String[] { "Helvetica-BoldOblique" });
/* 2600 */     stdFieldFontNames.put("HeBo", new String[] { "Helvetica-Bold" });
/* 2601 */     stdFieldFontNames.put("HeOb", new String[] { "Helvetica-Oblique" });
/* 2602 */     stdFieldFontNames.put("Helv", new String[] { "Helvetica" });
/* 2603 */     stdFieldFontNames.put("Symb", new String[] { "Symbol" });
/* 2604 */     stdFieldFontNames.put("TiBI", new String[] { "Times-BoldItalic" });
/* 2605 */     stdFieldFontNames.put("TiBo", new String[] { "Times-Bold" });
/* 2606 */     stdFieldFontNames.put("TiIt", new String[] { "Times-Italic" });
/* 2607 */     stdFieldFontNames.put("TiRo", new String[] { "Times-Roman" });
/* 2608 */     stdFieldFontNames.put("ZaDb", new String[] { "ZapfDingbats" });
/* 2609 */     stdFieldFontNames.put("HySm", new String[] { "HYSMyeongJo-Medium", "UniKS-UCS2-H" });
/* 2610 */     stdFieldFontNames.put("HyGo", new String[] { "HYGoThic-Medium", "UniKS-UCS2-H" });
/* 2611 */     stdFieldFontNames.put("KaGo", new String[] { "HeiseiKakuGo-W5", "UniKS-UCS2-H" });
/* 2612 */     stdFieldFontNames.put("KaMi", new String[] { "HeiseiMin-W3", "UniJIS-UCS2-H" });
/* 2613 */     stdFieldFontNames.put("MHei", new String[] { "MHei-Medium", "UniCNS-UCS2-H" });
/* 2614 */     stdFieldFontNames.put("MSun", new String[] { "MSung-Light", "UniCNS-UCS2-H" });
/* 2615 */     stdFieldFontNames.put("STSo", new String[] { "STSong-Light", "UniGB-UCS2-H" });
/*      */   }
/*      */   
/*      */   private static class SorterComparator implements Comparator<Object[]> {
/*      */     public int compare(Object[] o1, Object[] o2) {
/* 2620 */       int n1 = ((int[])(int[])o1[1])[0];
/* 2621 */       int n2 = ((int[])(int[])o2[1])[0];
/* 2622 */       return n1 - n2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<BaseFont> getSubstitutionFonts()
/*      */   {
/* 2633 */     return this.substitutionFonts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSubstitutionFonts(ArrayList<BaseFont> substitutionFonts)
/*      */   {
/* 2643 */     this.substitutionFonts = substitutionFonts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XfaForm getXfa()
/*      */   {
/* 2652 */     return this.xfa;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeXfa()
/*      */   {
/* 2659 */     PdfDictionary root = this.reader.getCatalog();
/* 2660 */     PdfDictionary acroform = root.getAsDict(PdfName.ACROFORM);
/* 2661 */     acroform.remove(PdfName.XFA);
/*      */     try {
/* 2663 */       this.xfa = new XfaForm(this.reader);
/*      */     }
/*      */     catch (Exception e) {
/* 2666 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/* 2670 */   private static final PdfName[] buttonRemove = { PdfName.MK, PdfName.F, PdfName.FF, PdfName.Q, PdfName.BS, PdfName.BORDER };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PushbuttonField getNewPushbuttonFromField(String field)
/*      */   {
/* 2682 */     return getNewPushbuttonFromField(field, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PushbuttonField getNewPushbuttonFromField(String field, int order)
/*      */   {
/*      */     try
/*      */     {
/* 2698 */       if (getFieldType(field) != 1)
/* 2699 */         return null;
/* 2700 */       Item item = getFieldItem(field);
/* 2701 */       if (order >= item.size())
/* 2702 */         return null;
/* 2703 */       List<FieldPosition> pos = getFieldPositions(field);
/* 2704 */       Rectangle box = ((FieldPosition)pos.get(order)).position;
/* 2705 */       PushbuttonField newButton = new PushbuttonField(this.writer, box, null);
/* 2706 */       PdfDictionary dic = item.getMerged(order);
/* 2707 */       decodeGenericDictionary(dic, newButton);
/* 2708 */       PdfDictionary mk = dic.getAsDict(PdfName.MK);
/* 2709 */       if (mk != null) {
/* 2710 */         PdfString text = mk.getAsString(PdfName.CA);
/* 2711 */         if (text != null)
/* 2712 */           newButton.setText(text.toUnicodeString());
/* 2713 */         PdfNumber tp = mk.getAsNumber(PdfName.TP);
/* 2714 */         if (tp != null)
/* 2715 */           newButton.setLayout(tp.intValue() + 1);
/* 2716 */         PdfDictionary ifit = mk.getAsDict(PdfName.IF);
/* 2717 */         if (ifit != null) {
/* 2718 */           PdfName sw = ifit.getAsName(PdfName.SW);
/* 2719 */           if (sw != null) {
/* 2720 */             int scale = 1;
/* 2721 */             if (sw.equals(PdfName.B)) {
/* 2722 */               scale = 3;
/* 2723 */             } else if (sw.equals(PdfName.S)) {
/* 2724 */               scale = 4;
/* 2725 */             } else if (sw.equals(PdfName.N))
/* 2726 */               scale = 2;
/* 2727 */             newButton.setScaleIcon(scale);
/*      */           }
/* 2729 */           sw = ifit.getAsName(PdfName.S);
/* 2730 */           if ((sw != null) && 
/* 2731 */             (sw.equals(PdfName.A))) {
/* 2732 */             newButton.setProportionalIcon(false);
/*      */           }
/* 2734 */           PdfArray aj = ifit.getAsArray(PdfName.A);
/* 2735 */           if ((aj != null) && (aj.size() == 2)) {
/* 2736 */             float left = aj.getAsNumber(0).floatValue();
/* 2737 */             float bottom = aj.getAsNumber(1).floatValue();
/* 2738 */             newButton.setIconHorizontalAdjustment(left);
/* 2739 */             newButton.setIconVerticalAdjustment(bottom);
/*      */           }
/* 2741 */           PdfBoolean fb = ifit.getAsBoolean(PdfName.FB);
/* 2742 */           if ((fb != null) && (fb.booleanValue()))
/* 2743 */             newButton.setIconFitToBounds(true);
/*      */         }
/* 2745 */         PdfObject i = mk.get(PdfName.I);
/* 2746 */         if ((i != null) && (i.isIndirect()))
/* 2747 */           newButton.setIconReference((PRIndirectReference)i);
/*      */       }
/* 2749 */       return newButton;
/*      */     }
/*      */     catch (Exception e) {
/* 2752 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean replacePushbuttonField(String field, PdfFormField button)
/*      */   {
/* 2767 */     return replacePushbuttonField(field, button, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean replacePushbuttonField(String field, PdfFormField button, int order)
/*      */   {
/* 2784 */     if (getFieldType(field) != 1)
/* 2785 */       return false;
/* 2786 */     Item item = getFieldItem(field);
/* 2787 */     if (order >= item.size())
/* 2788 */       return false;
/* 2789 */     PdfDictionary merged = item.getMerged(order);
/* 2790 */     PdfDictionary values = item.getValue(order);
/* 2791 */     PdfDictionary widgets = item.getWidget(order);
/* 2792 */     for (int k = 0; k < buttonRemove.length; k++) {
/* 2793 */       merged.remove(buttonRemove[k]);
/* 2794 */       values.remove(buttonRemove[k]);
/* 2795 */       widgets.remove(buttonRemove[k]);
/*      */     }
/* 2797 */     for (Object element : button.getKeys()) {
/* 2798 */       PdfName key = (PdfName)element;
/* 2799 */       if (!key.equals(PdfName.T))
/*      */       {
/* 2801 */         if (key.equals(PdfName.FF)) {
/* 2802 */           values.put(key, button.get(key));
/*      */         } else
/* 2804 */           widgets.put(key, button.get(key));
/* 2805 */         merged.put(key, button.get(key));
/* 2806 */         markUsed(values);
/* 2807 */         markUsed(widgets);
/*      */       } }
/* 2809 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean doesSignatureFieldExist(String name)
/*      */   {
/* 2819 */     return (getBlankSignatureNames().contains(name)) || (getSignatureNames().contains(name));
/*      */   }
/*      */   
/*      */   public static class FieldPosition
/*      */   {
/*      */     public int page;
/*      */     public Rectangle position;
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/AcroFields.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */