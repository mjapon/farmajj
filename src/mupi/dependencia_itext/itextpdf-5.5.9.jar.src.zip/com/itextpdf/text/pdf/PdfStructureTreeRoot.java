/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.pdf.interfaces.IPdfStructureElement;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfStructureTreeRoot
/*     */   extends PdfDictionary
/*     */   implements IPdfStructureElement
/*     */ {
/*  60 */   private HashMap<Integer, PdfObject> parentTree = new HashMap();
/*     */   private PdfIndirectReference reference;
/*  62 */   private PdfDictionary classMap = null;
/*  63 */   protected HashMap<PdfName, PdfObject> classes = null;
/*  64 */   private HashMap<Integer, PdfIndirectReference> numTree = null;
/*     */   
/*     */ 
/*     */   private HashMap<String, PdfObject> idTreeMap;
/*     */   
/*     */   private PdfWriter writer;
/*     */   
/*     */ 
/*     */   PdfStructureTreeRoot(PdfWriter writer)
/*     */   {
/*  74 */     super(PdfName.STRUCTTREEROOT);
/*  75 */     this.writer = writer;
/*  76 */     this.reference = writer.getPdfIndirectReference();
/*     */   }
/*     */   
/*     */   private void createNumTree() throws IOException {
/*  80 */     if (this.numTree != null) return;
/*  81 */     this.numTree = new HashMap();
/*  82 */     for (Integer i : this.parentTree.keySet()) {
/*  83 */       PdfObject obj = (PdfObject)this.parentTree.get(i);
/*  84 */       if (obj.isArray()) {
/*  85 */         PdfArray ar = (PdfArray)obj;
/*  86 */         this.numTree.put(i, this.writer.addToBody(ar).getIndirectReference());
/*  87 */       } else if ((obj instanceof PdfIndirectReference)) {
/*  88 */         this.numTree.put(i, (PdfIndirectReference)obj);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mapRole(PdfName used, PdfName standard)
/*     */   {
/* 100 */     PdfDictionary rm = (PdfDictionary)get(PdfName.ROLEMAP);
/* 101 */     if (rm == null) {
/* 102 */       rm = new PdfDictionary();
/* 103 */       put(PdfName.ROLEMAP, rm);
/*     */     }
/* 105 */     rm.put(used, standard);
/*     */   }
/*     */   
/*     */   public void mapClass(PdfName name, PdfObject object) {
/* 109 */     if (this.classMap == null) {
/* 110 */       this.classMap = new PdfDictionary();
/* 111 */       this.classes = new HashMap();
/*     */     }
/* 113 */     this.classes.put(name, object);
/*     */   }
/*     */   
/*     */   void putIDTree(String record, PdfObject reference) {
/* 117 */     if (this.idTreeMap == null)
/* 118 */       this.idTreeMap = new HashMap();
/* 119 */     this.idTreeMap.put(record, reference);
/*     */   }
/*     */   
/*     */   public PdfObject getMappedClass(PdfName name) {
/* 123 */     if (this.classes == null)
/* 124 */       return null;
/* 125 */     return (PdfObject)this.classes.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfWriter getWriter()
/*     */   {
/* 133 */     return this.writer;
/*     */   }
/*     */   
/*     */   public HashMap<Integer, PdfIndirectReference> getNumTree() throws IOException {
/* 137 */     if (this.numTree == null) createNumTree();
/* 138 */     return this.numTree;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfIndirectReference getReference()
/*     */   {
/* 147 */     return this.reference;
/*     */   }
/*     */   
/*     */   void setPageMark(int page, PdfIndirectReference struc) {
/* 151 */     Integer i = Integer.valueOf(page);
/* 152 */     PdfArray ar = (PdfArray)this.parentTree.get(i);
/* 153 */     if (ar == null) {
/* 154 */       ar = new PdfArray();
/* 155 */       this.parentTree.put(i, ar);
/*     */     }
/* 157 */     ar.add(struc);
/*     */   }
/*     */   
/*     */   void setAnnotationMark(int structParentIndex, PdfIndirectReference struc) {
/* 161 */     this.parentTree.put(Integer.valueOf(structParentIndex), struc);
/*     */   }
/*     */   
/*     */   void buildTree() throws IOException {
/* 165 */     createNumTree();
/* 166 */     PdfDictionary dicTree = PdfNumberTree.writeTree(this.numTree, this.writer);
/* 167 */     if (dicTree != null)
/* 168 */       put(PdfName.PARENTTREE, this.writer.addToBody(dicTree).getIndirectReference());
/* 169 */     if ((this.classMap != null) && (!this.classes.isEmpty())) {
/* 170 */       for (Map.Entry<PdfName, PdfObject> entry : this.classes.entrySet()) {
/* 171 */         PdfObject value = (PdfObject)entry.getValue();
/* 172 */         if (value.isDictionary()) {
/* 173 */           this.classMap.put((PdfName)entry.getKey(), this.writer.addToBody(value).getIndirectReference());
/* 174 */         } else if (value.isArray()) {
/* 175 */           PdfArray newArray = new PdfArray();
/* 176 */           PdfArray array = (PdfArray)value;
/* 177 */           for (int i = 0; i < array.size(); i++) {
/* 178 */             if (array.getPdfObject(i).isDictionary())
/* 179 */               newArray.add(this.writer.addToBody(array.getAsDict(i)).getIndirectReference());
/*     */           }
/* 181 */           this.classMap.put((PdfName)entry.getKey(), newArray);
/*     */         }
/*     */       }
/* 184 */       put(PdfName.CLASSMAP, this.writer.addToBody(this.classMap).getIndirectReference());
/*     */     }
/* 186 */     if ((this.idTreeMap != null) && (!this.idTreeMap.isEmpty())) {
/* 187 */       PdfDictionary dic = PdfNameTree.writeTree(this.idTreeMap, this.writer);
/* 188 */       put(PdfName.IDTREE, dic);
/*     */     }
/* 190 */     this.writer.addToBody(this, this.reference);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject getAttribute(PdfName name)
/*     */   {
/* 199 */     PdfDictionary attr = getAsDict(PdfName.A);
/* 200 */     if ((attr != null) && 
/* 201 */       (attr.contains(name))) {
/* 202 */       return attr.get(name);
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(PdfName name, PdfObject obj)
/*     */   {
/* 212 */     PdfDictionary attr = getAsDict(PdfName.A);
/* 213 */     if (attr == null) {
/* 214 */       attr = new PdfDictionary();
/* 215 */       put(PdfName.A, attr);
/*     */     }
/* 217 */     attr.put(name, obj);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfStructureTreeRoot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */