/*    */ package com.itextpdf.text.pdf.security;
/*    */ 
/*    */ import com.itextpdf.text.pdf.PdfDictionary;
/*    */ import com.itextpdf.text.pdf.PdfName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfSignatureBuildProperties
/*    */   extends PdfDictionary
/*    */ {
/*    */   public void setSignatureCreator(String name)
/*    */   {
/* 68 */     getPdfSignatureAppProperty().setSignatureCreator(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private PdfSignatureAppDictionary getPdfSignatureAppProperty()
/*    */   {
/* 79 */     PdfSignatureAppDictionary appPropDic = (PdfSignatureAppDictionary)getAsDict(PdfName.APP);
/* 80 */     if (appPropDic == null) {
/* 81 */       appPropDic = new PdfSignatureAppDictionary();
/* 82 */       put(PdfName.APP, appPropDic);
/*    */     }
/* 84 */     return appPropDic;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/PdfSignatureBuildProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */