package com.itextpdf.text.pdf.parser;

public abstract interface ExtRenderListener
  extends RenderListener
{
  public abstract void modifyPath(PathConstructionRenderInfo paramPathConstructionRenderInfo);
  
  public abstract Path renderPath(PathPaintingRenderInfo paramPathPaintingRenderInfo);
  
  public abstract void clipPath(int paramInt);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/ExtRenderListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */