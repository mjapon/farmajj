/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.Chunk;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Font;
/*     */ import com.itextpdf.text.Phrase;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextField
/*     */   extends BaseField
/*     */ {
/*     */   private String defaultText;
/*     */   private String[] choices;
/*     */   private String[] choiceExports;
/*  69 */   private ArrayList<Integer> choiceSelections = new ArrayList();
/*     */   
/*     */   private int topFirst;
/*     */   
/*  73 */   private int visibleTopChoice = -1;
/*     */   
/*     */   private float extraMarginLeft;
/*     */   
/*     */   private float extraMarginTop;
/*     */   
/*     */   private ArrayList<BaseFont> substitutionFonts;
/*     */   
/*     */   private BaseFont extensionFont;
/*     */   
/*     */ 
/*     */   public TextField(PdfWriter writer, Rectangle box, String fieldName)
/*     */   {
/*  86 */     super(writer, box, fieldName);
/*     */   }
/*     */   
/*     */   private static boolean checkRTL(String text) {
/*  90 */     if ((text == null) || (text.length() == 0))
/*  91 */       return false;
/*  92 */     char[] cc = text.toCharArray();
/*  93 */     for (int k = 0; k < cc.length; k++) {
/*  94 */       int c = cc[k];
/*  95 */       if ((c >= 1424) && (c < 1920))
/*  96 */         return true;
/*     */     }
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   private static void changeFontSize(Phrase p, float size) {
/* 102 */     for (int k = 0; k < p.size(); k++)
/* 103 */       ((Chunk)p.get(k)).getFont().setSize(size);
/*     */   }
/*     */   
/*     */   private Phrase composePhrase(String text, BaseFont ufont, BaseColor color, float fontSize) {
/* 107 */     Phrase phrase = null;
/* 108 */     if ((this.extensionFont == null) && ((this.substitutionFonts == null) || (this.substitutionFonts.isEmpty()))) {
/* 109 */       phrase = new Phrase(new Chunk(text, new Font(ufont, fontSize, 0, color)));
/*     */     } else {
/* 111 */       FontSelector fs = new FontSelector();
/* 112 */       fs.addFont(new Font(ufont, fontSize, 0, color));
/* 113 */       if (this.extensionFont != null)
/* 114 */         fs.addFont(new Font(this.extensionFont, fontSize, 0, color));
/* 115 */       if (this.substitutionFonts != null) {
/* 116 */         for (int k = 0; k < this.substitutionFonts.size(); k++)
/* 117 */           fs.addFont(new Font((BaseFont)this.substitutionFonts.get(k), fontSize, 0, color));
/*     */       }
/* 119 */       phrase = fs.process(text);
/*     */     }
/* 121 */     return phrase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String removeCRLF(String text)
/*     */   {
/* 132 */     if ((text.indexOf('\n') >= 0) || (text.indexOf('\r') >= 0)) {
/* 133 */       char[] p = text.toCharArray();
/* 134 */       StringBuffer sb = new StringBuffer(p.length);
/* 135 */       for (int k = 0; k < p.length; k++) {
/* 136 */         char c = p[k];
/* 137 */         if (c == '\n') {
/* 138 */           sb.append(' ');
/* 139 */         } else if (c == '\r') {
/* 140 */           sb.append(' ');
/* 141 */           if ((k < p.length - 1) && (p[(k + 1)] == '\n')) {
/* 142 */             k++;
/*     */           }
/*     */         } else {
/* 145 */           sb.append(c);
/*     */         } }
/* 147 */       return sb.toString();
/*     */     }
/* 149 */     return text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String obfuscatePassword(String text)
/*     */   {
/* 161 */     char[] pchar = new char[text.length()];
/* 162 */     for (int i = 0; i < text.length(); i++)
/* 163 */       pchar[i] = '*';
/* 164 */     return new String(pchar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfAppearance getAppearance()
/*     */     throws IOException, DocumentException
/*     */   {
/* 174 */     PdfAppearance app = getBorderAppearance();
/* 175 */     app.beginVariableText();
/* 176 */     if ((this.text == null) || (this.text.length() == 0)) {
/* 177 */       app.endVariableText();
/* 178 */       return app;
/*     */     }
/*     */     
/* 181 */     boolean borderExtra = (this.borderStyle == 2) || (this.borderStyle == 3);
/* 182 */     float h = this.box.getHeight() - this.borderWidth * 2.0F - this.extraMarginTop;
/* 183 */     float bw2 = this.borderWidth;
/* 184 */     if (borderExtra) {
/* 185 */       h -= this.borderWidth * 2.0F;
/* 186 */       bw2 *= 2.0F;
/*     */     }
/* 188 */     float offsetX = Math.max(bw2, 1.0F);
/* 189 */     float offX = Math.min(bw2, offsetX);
/* 190 */     app.saveState();
/* 191 */     app.rectangle(offX, offX, this.box.getWidth() - 2.0F * offX, this.box.getHeight() - 2.0F * offX);
/* 192 */     app.clip();
/* 193 */     app.newPath();
/*     */     String ptext;
/* 195 */     String ptext; if ((this.options & 0x2000) != 0) {
/* 196 */       ptext = obfuscatePassword(this.text); } else { String ptext;
/* 197 */       if ((this.options & 0x1000) == 0) {
/* 198 */         ptext = removeCRLF(this.text);
/*     */       } else
/* 200 */         ptext = this.text; }
/* 201 */     BaseFont ufont = getRealFont();
/* 202 */     BaseColor fcolor = this.textColor == null ? GrayColor.GRAYBLACK : this.textColor;
/* 203 */     int rtl = checkRTL(ptext) ? 2 : 1;
/* 204 */     float usize = this.fontSize;
/* 205 */     Phrase phrase = composePhrase(ptext, ufont, fcolor, usize);
/* 206 */     if ((this.options & 0x1000) != 0) {
/* 207 */       float width = this.box.getWidth() - 4.0F * offsetX - this.extraMarginLeft;
/* 208 */       float factor = ufont.getFontDescriptor(8, 1.0F) - ufont.getFontDescriptor(6, 1.0F);
/* 209 */       ColumnText ct = new ColumnText(null);
/* 210 */       if (usize == 0.0F) {
/* 211 */         usize = h / factor;
/* 212 */         if (usize > 4.0F) {
/* 213 */           if (usize > 12.0F)
/* 214 */             usize = 12.0F;
/* 215 */           float step = Math.max((usize - 4.0F) / 10.0F, 0.2F);
/* 216 */           ct.setSimpleColumn(0.0F, -h, width, 0.0F);
/* 217 */           ct.setAlignment(this.alignment);
/* 218 */           ct.setRunDirection(rtl);
/* 219 */           for (; usize > 4.0F; usize -= step) {
/* 220 */             ct.setYLine(0.0F);
/* 221 */             changeFontSize(phrase, usize);
/* 222 */             ct.setText(phrase);
/* 223 */             ct.setLeading(factor * usize);
/* 224 */             int status = ct.go(true);
/* 225 */             if ((status & 0x2) == 0)
/*     */               break;
/*     */           }
/*     */         }
/* 229 */         if (usize < 4.0F)
/* 230 */           usize = 4.0F;
/*     */       }
/* 232 */       changeFontSize(phrase, usize);
/* 233 */       ct.setCanvas(app);
/* 234 */       float leading = usize * factor;
/* 235 */       float offsetY = offsetX + h - ufont.getFontDescriptor(8, usize);
/* 236 */       ct.setSimpleColumn(this.extraMarginLeft + 2.0F * offsetX, -20000.0F, this.box.getWidth() - 2.0F * offsetX, offsetY + leading);
/* 237 */       ct.setLeading(leading);
/* 238 */       ct.setAlignment(this.alignment);
/* 239 */       ct.setRunDirection(rtl);
/* 240 */       ct.setText(phrase);
/* 241 */       ct.go();
/*     */     }
/*     */     else {
/* 244 */       if (usize == 0.0F) {
/* 245 */         float maxCalculatedSize = h / (ufont.getFontDescriptor(7, 1.0F) - ufont.getFontDescriptor(6, 1.0F));
/* 246 */         changeFontSize(phrase, 1.0F);
/* 247 */         float wd = ColumnText.getWidth(phrase, rtl, 0);
/* 248 */         if (wd == 0.0F) {
/* 249 */           usize = maxCalculatedSize;
/*     */         } else
/* 251 */           usize = Math.min(maxCalculatedSize, (this.box.getWidth() - this.extraMarginLeft - 4.0F * offsetX) / wd);
/* 252 */         if (usize < 4.0F)
/* 253 */           usize = 4.0F;
/*     */       }
/* 255 */       changeFontSize(phrase, usize);
/* 256 */       float offsetY = offX + (this.box.getHeight() - 2.0F * offX - ufont.getFontDescriptor(1, usize)) / 2.0F;
/* 257 */       if (offsetY < offX)
/* 258 */         offsetY = offX;
/* 259 */       if (offsetY - offX < -ufont.getFontDescriptor(3, usize)) {
/* 260 */         float ny = -ufont.getFontDescriptor(3, usize) + offX;
/* 261 */         float dy = this.box.getHeight() - offX - ufont.getFontDescriptor(1, usize);
/* 262 */         offsetY = Math.min(ny, Math.max(offsetY, dy));
/*     */       }
/* 264 */       if (((this.options & 0x1000000) != 0) && (this.maxCharacterLength > 0)) {
/* 265 */         int textLen = Math.min(this.maxCharacterLength, ptext.length());
/* 266 */         int position = 0;
/* 267 */         if (this.alignment == 2) {
/* 268 */           position = this.maxCharacterLength - textLen;
/* 269 */         } else if (this.alignment == 1)
/* 270 */           position = (this.maxCharacterLength - textLen) / 2;
/* 271 */         float step = (this.box.getWidth() - this.extraMarginLeft) / this.maxCharacterLength;
/* 272 */         float start = step / 2.0F + position * step;
/* 273 */         if (this.textColor == null) {
/* 274 */           app.setGrayFill(0.0F);
/*     */         } else
/* 276 */           app.setColorFill(this.textColor);
/* 277 */         app.beginText();
/* 278 */         for (int k = 0; k < phrase.size(); k++) {
/* 279 */           Chunk ck = (Chunk)phrase.get(k);
/* 280 */           BaseFont bf = ck.getFont().getBaseFont();
/* 281 */           app.setFontAndSize(bf, usize);
/* 282 */           StringBuffer sb = ck.append("");
/* 283 */           for (int j = 0; j < sb.length(); j++) {
/* 284 */             String c = sb.substring(j, j + 1);
/* 285 */             float wd = bf.getWidthPoint(c, usize);
/* 286 */             app.setTextMatrix(this.extraMarginLeft + start - wd / 2.0F, offsetY - this.extraMarginTop);
/* 287 */             app.showText(c);
/* 288 */             start += step;
/*     */           }
/*     */         }
/* 291 */         app.endText();
/*     */       } else { float x;
/*     */         float x;
/*     */         float x;
/* 295 */         switch (this.alignment) {
/*     */         case 2: 
/* 297 */           x = this.extraMarginLeft + this.box.getWidth() - 2.0F * offsetX;
/* 298 */           break;
/*     */         case 1: 
/* 300 */           x = this.extraMarginLeft + this.box.getWidth() / 2.0F;
/* 301 */           break;
/*     */         default: 
/* 303 */           x = this.extraMarginLeft + 2.0F * offsetX;
/*     */         }
/* 305 */         ColumnText.showTextAligned(app, this.alignment, phrase, x, offsetY - this.extraMarginTop, 0.0F, rtl, 0);
/*     */       }
/*     */     }
/* 308 */     app.restoreState();
/* 309 */     app.endVariableText();
/* 310 */     return app;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfAppearance getListAppearance()
/*     */     throws IOException, DocumentException
/*     */   {
/* 320 */     PdfAppearance app = getBorderAppearance();
/* 321 */     if ((this.choices == null) || (this.choices.length == 0)) {
/* 322 */       return app;
/*     */     }
/* 324 */     app.beginVariableText();
/*     */     
/* 326 */     int topChoice = getTopChoice();
/*     */     
/* 328 */     BaseFont ufont = getRealFont();
/* 329 */     float usize = this.fontSize;
/* 330 */     if (usize == 0.0F) {
/* 331 */       usize = 12.0F;
/*     */     }
/* 333 */     boolean borderExtra = (this.borderStyle == 2) || (this.borderStyle == 3);
/* 334 */     float h = this.box.getHeight() - this.borderWidth * 2.0F;
/* 335 */     float offsetX = this.borderWidth;
/* 336 */     if (borderExtra) {
/* 337 */       h -= this.borderWidth * 2.0F;
/* 338 */       offsetX *= 2.0F;
/*     */     }
/*     */     
/* 341 */     float leading = ufont.getFontDescriptor(8, usize) - ufont.getFontDescriptor(6, usize);
/* 342 */     int maxFit = (int)(h / leading) + 1;
/* 343 */     int first = 0;
/* 344 */     int last = 0;
/* 345 */     first = topChoice;
/* 346 */     last = first + maxFit;
/* 347 */     if (last > this.choices.length)
/* 348 */       last = this.choices.length;
/* 349 */     this.topFirst = first;
/* 350 */     app.saveState();
/* 351 */     app.rectangle(offsetX, offsetX, this.box.getWidth() - 2.0F * offsetX, this.box.getHeight() - 2.0F * offsetX);
/* 352 */     app.clip();
/* 353 */     app.newPath();
/* 354 */     BaseColor fcolor = this.textColor == null ? GrayColor.GRAYBLACK : this.textColor;
/*     */     
/*     */ 
/*     */ 
/* 358 */     app.setColorFill(new BaseColor(10, 36, 106));
/* 359 */     for (int curVal = 0; curVal < this.choiceSelections.size(); curVal++) {
/* 360 */       int curChoice = ((Integer)this.choiceSelections.get(curVal)).intValue();
/*     */       
/*     */ 
/* 363 */       if ((curChoice >= first) && (curChoice <= last)) {
/* 364 */         app.rectangle(offsetX, offsetX + h - (curChoice - first + 1) * leading, this.box.getWidth() - 2.0F * offsetX, leading);
/* 365 */         app.fill();
/*     */       }
/*     */     }
/* 368 */     float xp = offsetX * 2.0F;
/* 369 */     float yp = offsetX + h - ufont.getFontDescriptor(8, usize);
/* 370 */     for (int idx = first; idx < last; yp -= leading) {
/* 371 */       String ptext = this.choices[idx];
/* 372 */       int rtl = checkRTL(ptext) ? 2 : 1;
/* 373 */       ptext = removeCRLF(ptext);
/*     */       
/* 375 */       BaseColor textCol = this.choiceSelections.contains(Integer.valueOf(idx)) ? GrayColor.GRAYWHITE : fcolor;
/* 376 */       Phrase phrase = composePhrase(ptext, ufont, textCol, usize);
/* 377 */       ColumnText.showTextAligned(app, 0, phrase, xp, yp, 0.0F, rtl, 0);idx++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 379 */     app.restoreState();
/* 380 */     app.endVariableText();
/* 381 */     return app;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfFormField getTextField()
/*     */     throws IOException, DocumentException
/*     */   {
/* 391 */     if (this.maxCharacterLength <= 0)
/* 392 */       this.options &= 0xFEFFFFFF;
/* 393 */     if ((this.options & 0x1000000) != 0)
/* 394 */       this.options &= 0xEFFF;
/* 395 */     PdfFormField field = PdfFormField.createTextField(this.writer, false, false, this.maxCharacterLength);
/* 396 */     field.setWidget(this.box, PdfAnnotation.HIGHLIGHT_INVERT);
/* 397 */     switch (this.alignment) {
/*     */     case 1: 
/* 399 */       field.setQuadding(1);
/* 400 */       break;
/*     */     case 2: 
/* 402 */       field.setQuadding(2);
/*     */     }
/*     */     
/* 405 */     if (this.rotation != 0)
/* 406 */       field.setMKRotation(this.rotation);
/* 407 */     if (this.fieldName != null) {
/* 408 */       field.setFieldName(this.fieldName);
/* 409 */       if (!"".equals(this.text))
/* 410 */         field.setValueAsString(this.text);
/* 411 */       if (this.defaultText != null)
/* 412 */         field.setDefaultValueAsString(this.defaultText);
/* 413 */       if ((this.options & 0x1) != 0)
/* 414 */         field.setFieldFlags(1);
/* 415 */       if ((this.options & 0x2) != 0)
/* 416 */         field.setFieldFlags(2);
/* 417 */       if ((this.options & 0x1000) != 0)
/* 418 */         field.setFieldFlags(4096);
/* 419 */       if ((this.options & 0x800000) != 0)
/* 420 */         field.setFieldFlags(8388608);
/* 421 */       if ((this.options & 0x2000) != 0)
/* 422 */         field.setFieldFlags(8192);
/* 423 */       if ((this.options & 0x100000) != 0)
/* 424 */         field.setFieldFlags(1048576);
/* 425 */       if ((this.options & 0x400000) != 0)
/* 426 */         field.setFieldFlags(4194304);
/* 427 */       if ((this.options & 0x1000000) != 0)
/* 428 */         field.setFieldFlags(16777216);
/*     */     }
/* 430 */     field.setBorderStyle(new PdfBorderDictionary(this.borderWidth, this.borderStyle, new PdfDashPattern(3.0F)));
/* 431 */     PdfAppearance tp = getAppearance();
/* 432 */     field.setAppearance(PdfAnnotation.APPEARANCE_NORMAL, tp);
/* 433 */     PdfAppearance da = (PdfAppearance)tp.getDuplicate();
/* 434 */     da.setFontAndSize(getRealFont(), this.fontSize);
/* 435 */     if (this.textColor == null) {
/* 436 */       da.setGrayFill(0.0F);
/*     */     } else
/* 438 */       da.setColorFill(this.textColor);
/* 439 */     field.setDefaultAppearanceString(da);
/* 440 */     if (this.borderColor != null)
/* 441 */       field.setMKBorderColor(this.borderColor);
/* 442 */     if (this.backgroundColor != null)
/* 443 */       field.setMKBackgroundColor(this.backgroundColor);
/* 444 */     switch (this.visibility) {
/*     */     case 1: 
/* 446 */       field.setFlags(6);
/* 447 */       break;
/*     */     case 2: 
/*     */       break;
/*     */     case 3: 
/* 451 */       field.setFlags(36);
/* 452 */       break;
/*     */     default: 
/* 454 */       field.setFlags(4);
/*     */     }
/*     */     
/* 457 */     return field;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfFormField getComboField()
/*     */     throws IOException, DocumentException
/*     */   {
/* 467 */     return getChoiceField(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfFormField getListField()
/*     */     throws IOException, DocumentException
/*     */   {
/* 477 */     return getChoiceField(true);
/*     */   }
/*     */   
/*     */   private int getTopChoice() {
/* 481 */     if ((this.choiceSelections == null) || (this.choiceSelections.size() == 0)) {
/* 482 */       return 0;
/*     */     }
/*     */     
/* 485 */     Integer firstValue = (Integer)this.choiceSelections.get(0);
/*     */     
/* 487 */     if (firstValue == null) {
/* 488 */       return 0;
/*     */     }
/*     */     
/* 491 */     int topChoice = 0;
/* 492 */     if (this.choices != null) {
/* 493 */       if (this.visibleTopChoice != -1) {
/* 494 */         return this.visibleTopChoice;
/*     */       }
/*     */       
/* 497 */       topChoice = firstValue.intValue();
/* 498 */       topChoice = Math.min(topChoice, this.choices.length);
/* 499 */       topChoice = Math.max(0, topChoice);
/*     */     }
/* 501 */     return topChoice;
/*     */   }
/*     */   
/*     */   protected PdfFormField getChoiceField(boolean isList) throws IOException, DocumentException {
/* 505 */     this.options &= 0xFEFFEFFF;
/* 506 */     String[] uchoices = this.choices;
/* 507 */     if (uchoices == null) {
/* 508 */       uchoices = new String[0];
/*     */     }
/* 510 */     int topChoice = getTopChoice();
/*     */     
/* 512 */     if ((uchoices.length > 0) && (topChoice >= 0)) {
/* 513 */       this.text = uchoices[topChoice];
/*     */     }
/* 515 */     if (this.text == null) {
/* 516 */       this.text = "";
/*     */     }
/* 518 */     PdfFormField field = null;
/* 519 */     String[][] mix = (String[][])null;
/*     */     
/* 521 */     if (this.choiceExports == null) {
/* 522 */       if (isList) {
/* 523 */         field = PdfFormField.createList(this.writer, uchoices, topChoice);
/*     */       } else {
/* 525 */         field = PdfFormField.createCombo(this.writer, (this.options & 0x40000) != 0, uchoices, topChoice);
/*     */       }
/*     */     } else {
/* 528 */       mix = new String[uchoices.length][2];
/* 529 */       for (int k = 0; k < mix.length; k++)
/* 530 */         mix[k][0] = (mix[k][1] = uchoices[k]);
/* 531 */       int top = Math.min(uchoices.length, this.choiceExports.length);
/* 532 */       for (int k = 0; k < top; k++) {
/* 533 */         if (this.choiceExports[k] != null)
/* 534 */           mix[k][0] = this.choiceExports[k];
/*     */       }
/* 536 */       if (isList) {
/* 537 */         field = PdfFormField.createList(this.writer, mix, topChoice);
/*     */       } else
/* 539 */         field = PdfFormField.createCombo(this.writer, (this.options & 0x40000) != 0, mix, topChoice);
/*     */     }
/* 541 */     field.setWidget(this.box, PdfAnnotation.HIGHLIGHT_INVERT);
/* 542 */     if (this.rotation != 0)
/* 543 */       field.setMKRotation(this.rotation);
/* 544 */     if (this.fieldName != null) {
/* 545 */       field.setFieldName(this.fieldName);
/* 546 */       if (uchoices.length > 0) {
/* 547 */         if (mix != null) {
/* 548 */           if (this.choiceSelections.size() < 2) {
/* 549 */             field.setValueAsString(mix[topChoice][0]);
/* 550 */             field.setDefaultValueAsString(mix[topChoice][0]);
/*     */           } else {
/* 552 */             writeMultipleValues(field, mix);
/*     */           }
/*     */         }
/* 555 */         else if (this.choiceSelections.size() < 2) {
/* 556 */           field.setValueAsString(this.text);
/* 557 */           field.setDefaultValueAsString(this.text);
/*     */         } else {
/* 559 */           writeMultipleValues(field, (String[][])null);
/*     */         }
/*     */       }
/*     */       
/* 563 */       if ((this.options & 0x1) != 0)
/* 564 */         field.setFieldFlags(1);
/* 565 */       if ((this.options & 0x2) != 0)
/* 566 */         field.setFieldFlags(2);
/* 567 */       if ((this.options & 0x400000) != 0)
/* 568 */         field.setFieldFlags(4194304);
/* 569 */       if ((this.options & 0x200000) != 0) {
/* 570 */         field.setFieldFlags(2097152);
/*     */       }
/*     */     }
/* 573 */     field.setBorderStyle(new PdfBorderDictionary(this.borderWidth, this.borderStyle, new PdfDashPattern(3.0F)));
/*     */     PdfAppearance tp;
/* 575 */     if (isList) {
/* 576 */       PdfAppearance tp = getListAppearance();
/* 577 */       if (this.topFirst > 0) {
/* 578 */         field.put(PdfName.TI, new PdfNumber(this.topFirst));
/*     */       }
/*     */     } else {
/* 581 */       tp = getAppearance(); }
/* 582 */     field.setAppearance(PdfAnnotation.APPEARANCE_NORMAL, tp);
/* 583 */     PdfAppearance da = (PdfAppearance)tp.getDuplicate();
/* 584 */     da.setFontAndSize(getRealFont(), this.fontSize);
/* 585 */     if (this.textColor == null) {
/* 586 */       da.setGrayFill(0.0F);
/*     */     } else
/* 588 */       da.setColorFill(this.textColor);
/* 589 */     field.setDefaultAppearanceString(da);
/* 590 */     if (this.borderColor != null)
/* 591 */       field.setMKBorderColor(this.borderColor);
/* 592 */     if (this.backgroundColor != null)
/* 593 */       field.setMKBackgroundColor(this.backgroundColor);
/* 594 */     switch (this.visibility) {
/*     */     case 1: 
/* 596 */       field.setFlags(6);
/* 597 */       break;
/*     */     case 2: 
/*     */       break;
/*     */     case 3: 
/* 601 */       field.setFlags(36);
/* 602 */       break;
/*     */     default: 
/* 604 */       field.setFlags(4);
/*     */     }
/*     */     
/* 607 */     return field;
/*     */   }
/*     */   
/*     */   private void writeMultipleValues(PdfFormField field, String[][] mix) {
/* 611 */     PdfArray indexes = new PdfArray();
/* 612 */     PdfArray values = new PdfArray();
/* 613 */     for (int i = 0; i < this.choiceSelections.size(); i++) {
/* 614 */       int idx = ((Integer)this.choiceSelections.get(i)).intValue();
/* 615 */       indexes.add(new PdfNumber(idx));
/*     */       
/* 617 */       if (mix != null) {
/* 618 */         values.add(new PdfString(mix[idx][0]));
/* 619 */       } else if (this.choices != null) {
/* 620 */         values.add(new PdfString(this.choices[idx]));
/*     */       }
/*     */     }
/* 623 */     field.put(PdfName.V, values);
/* 624 */     field.put(PdfName.I, indexes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultText()
/*     */   {
/* 633 */     return this.defaultText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultText(String defaultText)
/*     */   {
/* 641 */     this.defaultText = defaultText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getChoices()
/*     */   {
/* 649 */     return this.choices;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChoices(String[] choices)
/*     */   {
/* 657 */     this.choices = choices;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getChoiceExports()
/*     */   {
/* 665 */     return this.choiceExports;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChoiceExports(String[] choiceExports)
/*     */   {
/* 675 */     this.choiceExports = choiceExports;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getChoiceSelection()
/*     */   {
/* 683 */     return getTopChoice();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<Integer> getChoiceSelections()
/*     */   {
/* 693 */     return this.choiceSelections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisibleTopChoice(int visibleTopChoice)
/*     */   {
/* 703 */     if (visibleTopChoice < 0) {
/* 704 */       return;
/*     */     }
/*     */     
/* 707 */     if ((this.choices != null) && 
/* 708 */       (visibleTopChoice < this.choices.length)) {
/* 709 */       this.visibleTopChoice = visibleTopChoice;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVisibleTopChoice()
/*     */   {
/* 720 */     return this.visibleTopChoice;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChoiceSelection(int choiceSelection)
/*     */   {
/* 728 */     this.choiceSelections = new ArrayList();
/* 729 */     this.choiceSelections.add(Integer.valueOf(choiceSelection));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChoiceSelection(int selection)
/*     */   {
/* 738 */     if ((this.options & 0x200000) != 0) {
/* 739 */       this.choiceSelections.add(Integer.valueOf(selection));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChoiceSelections(ArrayList<Integer> selections)
/*     */   {
/* 749 */     if (selections != null) {
/* 750 */       this.choiceSelections = new ArrayList(selections);
/* 751 */       if ((this.choiceSelections.size() > 1) && ((this.options & 0x200000) == 0))
/*     */       {
/* 753 */         while (this.choiceSelections.size() > 1) {
/* 754 */           this.choiceSelections.remove(1);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 759 */       this.choiceSelections.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   int getTopFirst() {
/* 764 */     return this.topFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExtraMargin(float extraMarginLeft, float extraMarginTop)
/*     */   {
/* 773 */     this.extraMarginLeft = extraMarginLeft;
/* 774 */     this.extraMarginTop = extraMarginTop;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<BaseFont> getSubstitutionFonts()
/*     */   {
/* 788 */     return this.substitutionFonts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubstitutionFonts(ArrayList<BaseFont> substitutionFonts)
/*     */   {
/* 797 */     this.substitutionFonts = substitutionFonts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseFont getExtensionFont()
/*     */   {
/* 811 */     return this.extensionFont;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExtensionFont(BaseFont extensionFont)
/*     */   {
/* 820 */     this.extensionFont = extensionFont;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/TextField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */