package com.itextpdf.text.pdf.interfaces;

import com.itextpdf.text.pdf.PdfDeveloperExtension;
import com.itextpdf.text.pdf.PdfName;

public abstract interface PdfVersion
{
  public abstract void setPdfVersion(char paramChar);
  
  public abstract void setAtLeastPdfVersion(char paramChar);
  
  public abstract void setPdfVersion(PdfName paramPdfName);
  
  public abstract void addDeveloperExtension(PdfDeveloperExtension paramPdfDeveloperExtension);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/interfaces/PdfVersion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */