/*    */ package com.itextpdf.text.pdf.fonts.otf;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Language
/*    */ {
/* 56 */   BENGALI(new String[] { "beng", "bng2" });
/*    */   
/*    */   private final List<String> codes;
/*    */   
/*    */   private Language(String... codes) {
/* 61 */     this.codes = Arrays.asList(codes);
/*    */   }
/*    */   
/*    */   public boolean isSupported(String languageCode) {
/* 65 */     return this.codes.contains(languageCode);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/otf/Language.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */