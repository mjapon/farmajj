package com.itextpdf.text.pdf.hyphenation;

import java.util.ArrayList;

public abstract interface PatternConsumer
{
  public abstract void addClass(String paramString);
  
  public abstract void addException(String paramString, ArrayList<Object> paramArrayList);
  
  public abstract void addPattern(String paramString1, String paramString2);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/hyphenation/PatternConsumer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */