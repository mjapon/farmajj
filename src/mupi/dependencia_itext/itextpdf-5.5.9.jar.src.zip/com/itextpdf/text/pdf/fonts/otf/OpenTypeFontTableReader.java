/*     */ package com.itextpdf.text.pdf.fonts.otf;
/*     */ 
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import com.itextpdf.text.pdf.RandomAccessFileOrArray;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OpenTypeFontTableReader
/*     */ {
/*  67 */   protected static final Logger LOG = LoggerFactory.getLogger(OpenTypeFontTableReader.class);
/*     */   
/*     */   protected final RandomAccessFileOrArray rf;
/*     */   protected final int tableLocation;
/*     */   private List<String> supportedLanguages;
/*     */   
/*     */   public OpenTypeFontTableReader(RandomAccessFileOrArray rf, int tableLocation)
/*     */     throws IOException
/*     */   {
/*  76 */     this.rf = rf;
/*  77 */     this.tableLocation = tableLocation;
/*     */   }
/*     */   
/*     */   public Language getSupportedLanguage() throws FontReadingException
/*     */   {
/*  82 */     Language[] allLangs = Language.values();
/*     */     
/*  84 */     for (String supportedLang : this.supportedLanguages) {
/*  85 */       for (Language lang : allLangs) {
/*  86 */         if (lang.isSupported(supportedLang)) {
/*  87 */           return lang;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  92 */     throw new FontReadingException("Unsupported languages " + this.supportedLanguages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void startReadingTable()
/*     */     throws FontReadingException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       TableHeader header = readHeader();
/*     */       
/* 105 */       readScriptListTable(this.tableLocation + header.scriptListOffset);
/*     */       
/*     */ 
/* 108 */       readFeatureListTable(this.tableLocation + header.featureListOffset);
/*     */       
/*     */ 
/* 111 */       readLookupListTable(this.tableLocation + header.lookupListOffset);
/*     */     } catch (IOException e) {
/* 113 */       throw new FontReadingException("Error reading font file", e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void readSubTable(int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */   
/*     */   private void readLookupListTable(int lookupListTableLocation) throws IOException
/*     */   {
/* 122 */     this.rf.seek(lookupListTableLocation);
/* 123 */     int lookupCount = this.rf.readShort();
/*     */     
/* 125 */     List<Integer> lookupTableOffsets = new ArrayList();
/*     */     
/* 127 */     for (int i = 0; i < lookupCount; i++) {
/* 128 */       int lookupTableOffset = this.rf.readShort();
/* 129 */       lookupTableOffsets.add(Integer.valueOf(lookupTableOffset));
/*     */     }
/*     */     
/*     */ 
/* 133 */     for (int i = 0; i < lookupCount; i++)
/*     */     {
/* 135 */       int lookupTableOffset = ((Integer)lookupTableOffsets.get(i)).intValue();
/* 136 */       readLookupTable(lookupListTableLocation + lookupTableOffset);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readLookupTable(int lookupTableLocation) throws IOException
/*     */   {
/* 142 */     this.rf.seek(lookupTableLocation);
/* 143 */     int lookupType = this.rf.readShort();
/*     */     
/*     */ 
/*     */ 
/* 147 */     this.rf.skipBytes(2);
/*     */     
/* 149 */     int subTableCount = this.rf.readShort();
/*     */     
/*     */ 
/* 152 */     List<Integer> subTableOffsets = new ArrayList();
/*     */     
/* 154 */     for (int i = 0; i < subTableCount; i++) {
/* 155 */       int subTableOffset = this.rf.readShort();
/* 156 */       subTableOffsets.add(Integer.valueOf(subTableOffset));
/*     */     }
/*     */     
/* 159 */     for (i = subTableOffsets.iterator(); i.hasNext();) { int subTableOffset = ((Integer)i.next()).intValue();
/*     */       
/* 161 */       readSubTable(lookupType, lookupTableLocation + subTableOffset);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final List<Integer> readCoverageFormat(int coverageLocation) throws IOException
/*     */   {
/* 167 */     this.rf.seek(coverageLocation);
/* 168 */     int coverageFormat = this.rf.readShort();
/*     */     
/*     */ 
/*     */ 
/* 172 */     if (coverageFormat == 1) {
/* 173 */       int glyphCount = this.rf.readShort();
/*     */       
/* 175 */       List<Integer> glyphIds = new ArrayList(glyphCount);
/*     */       
/* 177 */       for (int i = 0; i < glyphCount; i++) {
/* 178 */         int coverageGlyphId = this.rf.readShort();
/* 179 */         glyphIds.add(Integer.valueOf(coverageGlyphId));
/*     */       }
/*     */     }
/* 182 */     else if (coverageFormat == 2)
/*     */     {
/* 184 */       int rangeCount = this.rf.readShort();
/*     */       
/* 186 */       List<Integer> glyphIds = new ArrayList();
/*     */       
/* 188 */       for (int i = 0; i < rangeCount; i++) {
/* 189 */         readRangeRecord(glyphIds);
/*     */       }
/*     */     }
/*     */     else {
/* 193 */       throw new UnsupportedOperationException("Invalid coverage format: " + coverageFormat);
/*     */     }
/*     */     
/*     */     List<Integer> glyphIds;
/* 197 */     return Collections.unmodifiableList(glyphIds);
/*     */   }
/*     */   
/*     */   private void readRangeRecord(List<Integer> glyphIds) throws IOException {
/* 201 */     int startGlyphId = this.rf.readShort();
/* 202 */     int endGlyphId = this.rf.readShort();
/* 203 */     int startCoverageIndex = this.rf.readShort();
/*     */     
/* 205 */     for (int glyphId = startGlyphId; glyphId <= endGlyphId; glyphId++) {
/* 206 */       glyphIds.add(Integer.valueOf(glyphId));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readScriptListTable(int scriptListTableLocationOffset)
/*     */     throws IOException
/*     */   {
/* 219 */     this.rf.seek(scriptListTableLocationOffset);
/*     */     
/* 221 */     int scriptCount = this.rf.readShort();
/*     */     
/* 223 */     Map<String, Integer> scriptRecords = new HashMap(scriptCount);
/*     */     
/*     */ 
/* 226 */     for (int i = 0; i < scriptCount; i++) {
/* 227 */       readScriptRecord(scriptListTableLocationOffset, scriptRecords);
/*     */     }
/*     */     
/* 230 */     List<String> supportedLanguages = new ArrayList(scriptCount);
/*     */     
/* 232 */     for (String scriptName : scriptRecords.keySet()) {
/* 233 */       readScriptTable(((Integer)scriptRecords.get(scriptName)).intValue());
/* 234 */       supportedLanguages.add(scriptName);
/*     */     }
/*     */     
/* 237 */     this.supportedLanguages = Collections.unmodifiableList(supportedLanguages);
/*     */   }
/*     */   
/*     */   private void readScriptRecord(int scriptListTableLocationOffset, Map<String, Integer> scriptRecords) throws IOException
/*     */   {
/* 242 */     String scriptTag = this.rf.readString(4, "utf-8");
/*     */     
/* 244 */     int scriptOffset = this.rf.readShort();
/*     */     
/* 246 */     scriptRecords.put(scriptTag, Integer.valueOf(scriptListTableLocationOffset + scriptOffset));
/*     */   }
/*     */   
/*     */   private void readScriptTable(int scriptTableLocationOffset)
/*     */     throws IOException
/*     */   {
/* 252 */     this.rf.seek(scriptTableLocationOffset);
/* 253 */     int defaultLangSys = this.rf.readShort();
/* 254 */     int langSysCount = this.rf.readShort();
/*     */     Map<String, Integer> langSysRecords;
/* 256 */     int i; if (langSysCount > 0) {
/* 257 */       langSysRecords = new LinkedHashMap(langSysCount);
/*     */       
/*     */ 
/* 260 */       for (i = 0; i < langSysCount; i++) {
/* 261 */         readLangSysRecord(langSysRecords);
/*     */       }
/*     */       
/*     */ 
/* 265 */       for (String langSysTag : langSysRecords.keySet()) {
/* 266 */         readLangSysTable(scriptTableLocationOffset + 
/* 267 */           ((Integer)langSysRecords.get(langSysTag)).intValue());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 272 */     readLangSysTable(scriptTableLocationOffset + defaultLangSys);
/*     */   }
/*     */   
/*     */   private void readLangSysRecord(Map<String, Integer> langSysRecords) throws IOException
/*     */   {
/* 277 */     String langSysTag = this.rf.readString(4, "utf-8");
/* 278 */     int langSys = this.rf.readShort();
/* 279 */     langSysRecords.put(langSysTag, Integer.valueOf(langSys));
/*     */   }
/*     */   
/*     */   private void readLangSysTable(int langSysTableLocationOffset) throws IOException
/*     */   {
/* 284 */     this.rf.seek(langSysTableLocationOffset);
/* 285 */     int lookupOrderOffset = this.rf.readShort();
/* 286 */     LOG.debug("lookupOrderOffset=" + lookupOrderOffset);
/* 287 */     int reqFeatureIndex = this.rf.readShort();
/* 288 */     LOG.debug("reqFeatureIndex=" + reqFeatureIndex);
/* 289 */     int featureCount = this.rf.readShort();
/*     */     
/* 291 */     List<Short> featureListIndices = new ArrayList(featureCount);
/* 292 */     for (int i = 0; i < featureCount; i++) {
/* 293 */       featureListIndices.add(Short.valueOf(this.rf.readShort()));
/*     */     }
/*     */     
/* 296 */     LOG.debug("featureListIndices=" + featureListIndices);
/*     */   }
/*     */   
/*     */   private void readFeatureListTable(int featureListTableLocationOffset)
/*     */     throws IOException
/*     */   {
/* 302 */     this.rf.seek(featureListTableLocationOffset);
/* 303 */     int featureCount = this.rf.readShort();
/* 304 */     LOG.debug("featureCount=" + featureCount);
/*     */     
/* 306 */     Map<String, Short> featureRecords = new LinkedHashMap(featureCount);
/*     */     
/* 308 */     for (int i = 0; i < featureCount; i++) {
/* 309 */       featureRecords.put(this.rf.readString(4, "utf-8"), Short.valueOf(this.rf.readShort()));
/*     */     }
/*     */     
/* 312 */     for (String featureName : featureRecords.keySet()) {
/* 313 */       LOG.debug("*************featureName=" + featureName);
/* 314 */       readFeatureTable(featureListTableLocationOffset + 
/* 315 */         ((Short)featureRecords.get(featureName)).shortValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void readFeatureTable(int featureTableLocationOffset)
/*     */     throws IOException
/*     */   {
/* 322 */     this.rf.seek(featureTableLocationOffset);
/* 323 */     int featureParamsOffset = this.rf.readShort();
/* 324 */     LOG.debug("featureParamsOffset=" + featureParamsOffset);
/*     */     
/* 326 */     int lookupCount = this.rf.readShort();
/* 327 */     LOG.debug("lookupCount=" + lookupCount);
/*     */     
/* 329 */     List<Short> lookupListIndices = new ArrayList(lookupCount);
/* 330 */     for (int i = 0; i < lookupCount; i++) {
/* 331 */       lookupListIndices.add(Short.valueOf(this.rf.readShort()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private TableHeader readHeader()
/*     */     throws IOException
/*     */   {
/* 339 */     this.rf.seek(this.tableLocation);
/*     */     
/* 341 */     int version = this.rf.readInt();
/*     */     
/* 343 */     int scriptListOffset = this.rf.readUnsignedShort();
/* 344 */     int featureListOffset = this.rf.readUnsignedShort();
/* 345 */     int lookupListOffset = this.rf.readUnsignedShort();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 352 */     TableHeader header = new TableHeader(version, scriptListOffset, featureListOffset, lookupListOffset);
/*     */     
/*     */ 
/* 355 */     return header;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/otf/OpenTypeFontTableReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */