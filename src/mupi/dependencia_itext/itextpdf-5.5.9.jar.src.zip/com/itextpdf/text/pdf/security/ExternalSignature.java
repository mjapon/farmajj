package com.itextpdf.text.pdf.security;

import java.security.GeneralSecurityException;

public abstract interface ExternalSignature
{
  public abstract String getHashAlgorithm();
  
  public abstract String getEncryptionAlgorithm();
  
  public abstract byte[] sign(byte[] paramArrayOfByte)
    throws GeneralSecurityException;
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/ExternalSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */