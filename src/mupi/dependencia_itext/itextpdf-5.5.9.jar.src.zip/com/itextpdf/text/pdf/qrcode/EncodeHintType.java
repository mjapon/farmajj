/*    */ package com.itextpdf.text.pdf.qrcode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EncodeHintType
/*    */ {
/* 30 */   public static final EncodeHintType ERROR_CORRECTION = new EncodeHintType();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 35 */   public static final EncodeHintType CHARACTER_SET = new EncodeHintType();
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/qrcode/EncodeHintType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */