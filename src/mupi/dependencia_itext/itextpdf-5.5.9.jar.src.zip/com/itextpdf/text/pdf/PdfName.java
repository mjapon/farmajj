/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfName
/*      */   extends PdfObject
/*      */   implements Comparable<PdfName>
/*      */ {
/*   80 */   public static final PdfName _3D = new PdfName("3D");
/*      */   
/*   82 */   public static final PdfName A = new PdfName("A");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   87 */   public static final PdfName A85 = new PdfName("A85");
/*      */   
/*   89 */   public static final PdfName AA = new PdfName("AA");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   94 */   public static final PdfName ABSOLUTECOLORIMETRIC = new PdfName("AbsoluteColorimetric");
/*      */   
/*   96 */   public static final PdfName AC = new PdfName("AC");
/*      */   
/*   98 */   public static final PdfName ACROFORM = new PdfName("AcroForm");
/*      */   
/*  100 */   public static final PdfName ACTION = new PdfName("Action");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  105 */   public static final PdfName ACTIVATION = new PdfName("Activation");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  110 */   public static final PdfName ADBE = new PdfName("ADBE");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  115 */   public static final PdfName ACTUALTEXT = new PdfName("ActualText");
/*      */   
/*  117 */   public static final PdfName ADBE_PKCS7_DETACHED = new PdfName("adbe.pkcs7.detached");
/*      */   
/*  119 */   public static final PdfName ADBE_PKCS7_S4 = new PdfName("adbe.pkcs7.s4");
/*      */   
/*  121 */   public static final PdfName ADBE_PKCS7_S5 = new PdfName("adbe.pkcs7.s5");
/*      */   
/*  123 */   public static final PdfName ADBE_PKCS7_SHA1 = new PdfName("adbe.pkcs7.sha1");
/*      */   
/*  125 */   public static final PdfName ADBE_X509_RSA_SHA1 = new PdfName("adbe.x509.rsa_sha1");
/*      */   
/*  127 */   public static final PdfName ADOBE_PPKLITE = new PdfName("Adobe.PPKLite");
/*      */   
/*  129 */   public static final PdfName ADOBE_PPKMS = new PdfName("Adobe.PPKMS");
/*      */   
/*  131 */   public static final PdfName AESV2 = new PdfName("AESV2");
/*      */   
/*  133 */   public static final PdfName AESV3 = new PdfName("AESV3");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  138 */   public static final PdfName AF = new PdfName("AF");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  143 */   public static final PdfName AFRELATIONSHIP = new PdfName("AFRelationship");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  148 */   public static final PdfName AHX = new PdfName("AHx");
/*      */   
/*  150 */   public static final PdfName AIS = new PdfName("AIS");
/*      */   
/*  152 */   public static final PdfName ALL = new PdfName("All");
/*      */   
/*  154 */   public static final PdfName ALLPAGES = new PdfName("AllPages");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  159 */   public static final PdfName ALT = new PdfName("Alt");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  165 */   public static final PdfName ALTERNATE = new PdfName("Alternate");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  170 */   public static final PdfName ALTERNATEPRESENTATION = new PdfName("AlternatePresentations");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  175 */   public static final PdfName ALTERNATES = new PdfName("Alternates");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  180 */   public static final PdfName AND = new PdfName("And");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  185 */   public static final PdfName ANIMATION = new PdfName("Animation");
/*      */   
/*  187 */   public static final PdfName ANNOT = new PdfName("Annot");
/*      */   
/*  189 */   public static final PdfName ANNOTS = new PdfName("Annots");
/*      */   
/*  191 */   public static final PdfName ANTIALIAS = new PdfName("AntiAlias");
/*      */   
/*  193 */   public static final PdfName AP = new PdfName("AP");
/*      */   
/*  195 */   public static final PdfName APP = new PdfName("App");
/*      */   
/*  197 */   public static final PdfName APPDEFAULT = new PdfName("AppDefault");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  202 */   public static final PdfName ART = new PdfName("Art");
/*      */   
/*  204 */   public static final PdfName ARTBOX = new PdfName("ArtBox");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  209 */   public static final PdfName ARTIFACT = new PdfName("Artifact");
/*      */   
/*  211 */   public static final PdfName ASCENT = new PdfName("Ascent");
/*      */   
/*  213 */   public static final PdfName AS = new PdfName("AS");
/*      */   
/*  215 */   public static final PdfName ASCII85DECODE = new PdfName("ASCII85Decode");
/*      */   
/*  217 */   public static final PdfName ASCIIHEXDECODE = new PdfName("ASCIIHexDecode");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  222 */   public static final PdfName ASSET = new PdfName("Asset");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  227 */   public static final PdfName ASSETS = new PdfName("Assets");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  232 */   public static final PdfName ATTACHED = new PdfName("Attached");
/*      */   
/*  234 */   public static final PdfName AUTHEVENT = new PdfName("AuthEvent");
/*      */   
/*  236 */   public static final PdfName AUTHOR = new PdfName("Author");
/*      */   
/*  238 */   public static final PdfName B = new PdfName("B");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  243 */   public static final PdfName BACKGROUND = new PdfName("Background");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  248 */   public static final PdfName BACKGROUNDCOLOR = new PdfName("BackgroundColor");
/*      */   
/*  250 */   public static final PdfName BASEENCODING = new PdfName("BaseEncoding");
/*      */   
/*  252 */   public static final PdfName BASEFONT = new PdfName("BaseFont");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  257 */   public static final PdfName BASEVERSION = new PdfName("BaseVersion");
/*      */   
/*  259 */   public static final PdfName BBOX = new PdfName("BBox");
/*      */   
/*  261 */   public static final PdfName BC = new PdfName("BC");
/*      */   
/*  263 */   public static final PdfName BG = new PdfName("BG");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  268 */   public static final PdfName BIBENTRY = new PdfName("BibEntry");
/*      */   
/*  270 */   public static final PdfName BIGFIVE = new PdfName("BigFive");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  275 */   public static final PdfName BINDING = new PdfName("Binding");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  280 */   public static final PdfName BINDINGMATERIALNAME = new PdfName("BindingMaterialName");
/*      */   
/*  282 */   public static final PdfName BITSPERCOMPONENT = new PdfName("BitsPerComponent");
/*      */   
/*  284 */   public static final PdfName BITSPERSAMPLE = new PdfName("BitsPerSample");
/*      */   
/*  286 */   public static final PdfName BL = new PdfName("Bl");
/*      */   
/*  288 */   public static final PdfName BLACKIS1 = new PdfName("BlackIs1");
/*      */   
/*  290 */   public static final PdfName BLACKPOINT = new PdfName("BlackPoint");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  295 */   public static final PdfName BLOCKQUOTE = new PdfName("BlockQuote");
/*      */   
/*  297 */   public static final PdfName BLEEDBOX = new PdfName("BleedBox");
/*      */   
/*  299 */   public static final PdfName BLINDS = new PdfName("Blinds");
/*      */   
/*  301 */   public static final PdfName BM = new PdfName("BM");
/*      */   
/*  303 */   public static final PdfName BORDER = new PdfName("Border");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  308 */   public static final PdfName BOTH = new PdfName("Both");
/*      */   
/*  310 */   public static final PdfName BOUNDS = new PdfName("Bounds");
/*      */   
/*  312 */   public static final PdfName BOX = new PdfName("Box");
/*      */   
/*  314 */   public static final PdfName BS = new PdfName("BS");
/*      */   
/*  316 */   public static final PdfName BTN = new PdfName("Btn");
/*      */   
/*  318 */   public static final PdfName BYTERANGE = new PdfName("ByteRange");
/*      */   
/*  320 */   public static final PdfName C = new PdfName("C");
/*      */   
/*  322 */   public static final PdfName C0 = new PdfName("C0");
/*      */   
/*  324 */   public static final PdfName C1 = new PdfName("C1");
/*      */   
/*  326 */   public static final PdfName CA = new PdfName("CA");
/*      */   
/*  328 */   public static final PdfName ca = new PdfName("ca");
/*      */   
/*  330 */   public static final PdfName CALGRAY = new PdfName("CalGray");
/*      */   
/*  332 */   public static final PdfName CALRGB = new PdfName("CalRGB");
/*      */   
/*  334 */   public static final PdfName CAPHEIGHT = new PdfName("CapHeight");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  339 */   public static final PdfName CARET = new PdfName("Caret");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  344 */   public static final PdfName CAPTION = new PdfName("Caption");
/*      */   
/*  346 */   public static final PdfName CATALOG = new PdfName("Catalog");
/*      */   
/*  348 */   public static final PdfName CATEGORY = new PdfName("Category");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  353 */   public static final PdfName CB = new PdfName("cb");
/*      */   
/*  355 */   public static final PdfName CCITTFAXDECODE = new PdfName("CCITTFaxDecode");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  360 */   public static final PdfName CENTER = new PdfName("Center");
/*      */   
/*  362 */   public static final PdfName CENTERWINDOW = new PdfName("CenterWindow");
/*      */   
/*  364 */   public static final PdfName CERT = new PdfName("Cert");
/*      */   
/*      */ 
/*      */ 
/*  368 */   public static final PdfName CERTS = new PdfName("Certs");
/*      */   
/*  370 */   public static final PdfName CF = new PdfName("CF");
/*      */   
/*  372 */   public static final PdfName CFM = new PdfName("CFM");
/*      */   
/*  374 */   public static final PdfName CH = new PdfName("Ch");
/*      */   
/*  376 */   public static final PdfName CHARPROCS = new PdfName("CharProcs");
/*      */   
/*  378 */   public static final PdfName CHECKSUM = new PdfName("CheckSum");
/*      */   
/*  380 */   public static final PdfName CI = new PdfName("CI");
/*      */   
/*  382 */   public static final PdfName CIDFONTTYPE0 = new PdfName("CIDFontType0");
/*      */   
/*  384 */   public static final PdfName CIDFONTTYPE2 = new PdfName("CIDFontType2");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  389 */   public static final PdfName CIDSET = new PdfName("CIDSet");
/*      */   
/*  391 */   public static final PdfName CIDSYSTEMINFO = new PdfName("CIDSystemInfo");
/*      */   
/*  393 */   public static final PdfName CIDTOGIDMAP = new PdfName("CIDToGIDMap");
/*      */   
/*  395 */   public static final PdfName CIRCLE = new PdfName("Circle");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  400 */   public static final PdfName CLASSMAP = new PdfName("ClassMap");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  405 */   public static final PdfName CLOUD = new PdfName("Cloud");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  410 */   public static final PdfName CMD = new PdfName("CMD");
/*      */   
/*  412 */   public static final PdfName CO = new PdfName("CO");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  417 */   public static final PdfName CODE = new PdfName("Code");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  422 */   public static final PdfName COLOR = new PdfName("Color");
/*  423 */   public static final PdfName COLORANTS = new PdfName("Colorants");
/*      */   
/*  425 */   public static final PdfName COLORS = new PdfName("Colors");
/*      */   
/*  427 */   public static final PdfName COLORSPACE = new PdfName("ColorSpace");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  432 */   public static final PdfName COLORTRANSFORM = new PdfName("ColorTransform");
/*      */   
/*  434 */   public static final PdfName COLLECTION = new PdfName("Collection");
/*      */   
/*  436 */   public static final PdfName COLLECTIONFIELD = new PdfName("CollectionField");
/*      */   
/*  438 */   public static final PdfName COLLECTIONITEM = new PdfName("CollectionItem");
/*      */   
/*  440 */   public static final PdfName COLLECTIONSCHEMA = new PdfName("CollectionSchema");
/*      */   
/*  442 */   public static final PdfName COLLECTIONSORT = new PdfName("CollectionSort");
/*      */   
/*  444 */   public static final PdfName COLLECTIONSUBITEM = new PdfName("CollectionSubitem");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  449 */   public static final PdfName COLSPAN = new PdfName("ColSpan");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  454 */   public static final PdfName COLUMN = new PdfName("Column");
/*      */   
/*  456 */   public static final PdfName COLUMNS = new PdfName("Columns");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  461 */   public static final PdfName CONDITION = new PdfName("Condition");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  466 */   public static final PdfName CONFIGS = new PdfName("Configs");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  471 */   public static final PdfName CONFIGURATION = new PdfName("Configuration");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  476 */   public static final PdfName CONFIGURATIONS = new PdfName("Configurations");
/*      */   
/*  478 */   public static final PdfName CONTACTINFO = new PdfName("ContactInfo");
/*      */   
/*  480 */   public static final PdfName CONTENT = new PdfName("Content");
/*      */   
/*  482 */   public static final PdfName CONTENTS = new PdfName("Contents");
/*      */   
/*  484 */   public static final PdfName COORDS = new PdfName("Coords");
/*      */   
/*  486 */   public static final PdfName COUNT = new PdfName("Count");
/*      */   
/*  488 */   public static final PdfName COURIER = new PdfName("Courier");
/*      */   
/*  490 */   public static final PdfName COURIER_BOLD = new PdfName("Courier-Bold");
/*      */   
/*  492 */   public static final PdfName COURIER_OBLIQUE = new PdfName("Courier-Oblique");
/*      */   
/*  494 */   public static final PdfName COURIER_BOLDOBLIQUE = new PdfName("Courier-BoldOblique");
/*      */   
/*  496 */   public static final PdfName CREATIONDATE = new PdfName("CreationDate");
/*      */   
/*  498 */   public static final PdfName CREATOR = new PdfName("Creator");
/*      */   
/*  500 */   public static final PdfName CREATORINFO = new PdfName("CreatorInfo");
/*      */   
/*      */ 
/*      */ 
/*  504 */   public static final PdfName CRL = new PdfName("CRL");
/*      */   
/*      */ 
/*      */ 
/*  508 */   public static final PdfName CRLS = new PdfName("CRLs");
/*      */   
/*  510 */   public static final PdfName CROPBOX = new PdfName("CropBox");
/*      */   
/*  512 */   public static final PdfName CRYPT = new PdfName("Crypt");
/*      */   
/*  514 */   public static final PdfName CS = new PdfName("CS");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  519 */   public static final PdfName CUEPOINT = new PdfName("CuePoint");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  524 */   public static final PdfName CUEPOINTS = new PdfName("CuePoints");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  529 */   public static final PdfName CYX = new PdfName("CYX");
/*      */   
/*  531 */   public static final PdfName D = new PdfName("D");
/*      */   
/*  533 */   public static final PdfName DA = new PdfName("DA");
/*      */   
/*  535 */   public static final PdfName DATA = new PdfName("Data");
/*      */   
/*  537 */   public static final PdfName DC = new PdfName("DC");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  542 */   public static final PdfName DCS = new PdfName("DCS");
/*      */   
/*  544 */   public static final PdfName DCTDECODE = new PdfName("DCTDecode");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  549 */   public static final PdfName DECIMAL = new PdfName("Decimal");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  554 */   public static final PdfName DEACTIVATION = new PdfName("Deactivation");
/*      */   
/*  556 */   public static final PdfName DECODE = new PdfName("Decode");
/*      */   
/*  558 */   public static final PdfName DECODEPARMS = new PdfName("DecodeParms");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  563 */   public static final PdfName DEFAULT = new PdfName("Default");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  568 */   public static final PdfName DEFAULTCRYPTFILTER = new PdfName("DefaultCryptFilter");
/*      */   
/*  570 */   public static final PdfName DEFAULTCMYK = new PdfName("DefaultCMYK");
/*      */   
/*  572 */   public static final PdfName DEFAULTGRAY = new PdfName("DefaultGray");
/*      */   
/*  574 */   public static final PdfName DEFAULTRGB = new PdfName("DefaultRGB");
/*      */   
/*  576 */   public static final PdfName DESC = new PdfName("Desc");
/*      */   
/*  578 */   public static final PdfName DESCENDANTFONTS = new PdfName("DescendantFonts");
/*      */   
/*  580 */   public static final PdfName DESCENT = new PdfName("Descent");
/*      */   
/*  582 */   public static final PdfName DEST = new PdfName("Dest");
/*      */   
/*  584 */   public static final PdfName DESTOUTPUTPROFILE = new PdfName("DestOutputProfile");
/*      */   
/*  586 */   public static final PdfName DESTS = new PdfName("Dests");
/*      */   
/*  588 */   public static final PdfName DEVICEGRAY = new PdfName("DeviceGray");
/*      */   
/*  590 */   public static final PdfName DEVICERGB = new PdfName("DeviceRGB");
/*      */   
/*  592 */   public static final PdfName DEVICECMYK = new PdfName("DeviceCMYK");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  597 */   public static final PdfName DEVICEN = new PdfName("DeviceN");
/*      */   
/*  599 */   public static final PdfName DI = new PdfName("Di");
/*      */   
/*  601 */   public static final PdfName DIFFERENCES = new PdfName("Differences");
/*      */   
/*  603 */   public static final PdfName DISSOLVE = new PdfName("Dissolve");
/*      */   
/*  605 */   public static final PdfName DIRECTION = new PdfName("Direction");
/*      */   
/*  607 */   public static final PdfName DISPLAYDOCTITLE = new PdfName("DisplayDocTitle");
/*      */   
/*  609 */   public static final PdfName DIV = new PdfName("Div");
/*      */   
/*  611 */   public static final PdfName DL = new PdfName("DL");
/*      */   
/*  613 */   public static final PdfName DM = new PdfName("Dm");
/*      */   
/*  615 */   public static final PdfName DOCMDP = new PdfName("DocMDP");
/*      */   
/*  617 */   public static final PdfName DOCOPEN = new PdfName("DocOpen");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  622 */   public static final PdfName DOCTIMESTAMP = new PdfName("DocTimeStamp");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  627 */   public static final PdfName DOCUMENT = new PdfName("Document");
/*      */   
/*  629 */   public static final PdfName DOMAIN = new PdfName("Domain");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  634 */   public static final PdfName DOS = new PdfName("DOS");
/*      */   
/*  636 */   public static final PdfName DP = new PdfName("DP");
/*      */   
/*  638 */   public static final PdfName DR = new PdfName("DR");
/*      */   
/*  640 */   public static final PdfName DS = new PdfName("DS");
/*      */   
/*      */ 
/*      */ 
/*  644 */   public static final PdfName DSS = new PdfName("DSS");
/*      */   
/*  646 */   public static final PdfName DUR = new PdfName("Dur");
/*      */   
/*  648 */   public static final PdfName DUPLEX = new PdfName("Duplex");
/*      */   
/*  650 */   public static final PdfName DUPLEXFLIPSHORTEDGE = new PdfName("DuplexFlipShortEdge");
/*      */   
/*  652 */   public static final PdfName DUPLEXFLIPLONGEDGE = new PdfName("DuplexFlipLongEdge");
/*      */   
/*  654 */   public static final PdfName DV = new PdfName("DV");
/*      */   
/*  656 */   public static final PdfName DW = new PdfName("DW");
/*      */   
/*  658 */   public static final PdfName E = new PdfName("E");
/*      */   
/*  660 */   public static final PdfName EARLYCHANGE = new PdfName("EarlyChange");
/*      */   
/*  662 */   public static final PdfName EF = new PdfName("EF");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  667 */   public static final PdfName EFF = new PdfName("EFF");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  672 */   public static final PdfName EFOPEN = new PdfName("EFOpen");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  677 */   public static final PdfName EMBEDDED = new PdfName("Embedded");
/*      */   
/*  679 */   public static final PdfName EMBEDDEDFILE = new PdfName("EmbeddedFile");
/*      */   
/*  681 */   public static final PdfName EMBEDDEDFILES = new PdfName("EmbeddedFiles");
/*      */   
/*  683 */   public static final PdfName ENCODE = new PdfName("Encode");
/*      */   
/*  685 */   public static final PdfName ENCODEDBYTEALIGN = new PdfName("EncodedByteAlign");
/*      */   
/*  687 */   public static final PdfName ENCODING = new PdfName("Encoding");
/*      */   
/*  689 */   public static final PdfName ENCRYPT = new PdfName("Encrypt");
/*      */   
/*  691 */   public static final PdfName ENCRYPTMETADATA = new PdfName("EncryptMetadata");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  696 */   public static final PdfName END = new PdfName("End");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  701 */   public static final PdfName ENDINDENT = new PdfName("EndIndent");
/*      */   
/*  703 */   public static final PdfName ENDOFBLOCK = new PdfName("EndOfBlock");
/*      */   
/*  705 */   public static final PdfName ENDOFLINE = new PdfName("EndOfLine");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  710 */   public static final PdfName EPSG = new PdfName("EPSG");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  715 */   public static final PdfName ESIC = new PdfName("ESIC");
/*      */   
/*      */ 
/*      */ 
/*  719 */   public static final PdfName ETSI_CADES_DETACHED = new PdfName("ETSI.CAdES.detached");
/*      */   
/*  721 */   public static final PdfName ETSI_RFC3161 = new PdfName("ETSI.RFC3161");
/*      */   
/*  723 */   public static final PdfName EXCLUDE = new PdfName("Exclude");
/*      */   
/*  725 */   public static final PdfName EXTEND = new PdfName("Extend");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  730 */   public static final PdfName EXTENSIONS = new PdfName("Extensions");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  735 */   public static final PdfName EXTENSIONLEVEL = new PdfName("ExtensionLevel");
/*      */   
/*  737 */   public static final PdfName EXTGSTATE = new PdfName("ExtGState");
/*      */   
/*  739 */   public static final PdfName EXPORT = new PdfName("Export");
/*      */   
/*  741 */   public static final PdfName EXPORTSTATE = new PdfName("ExportState");
/*      */   
/*  743 */   public static final PdfName EVENT = new PdfName("Event");
/*      */   
/*  745 */   public static final PdfName F = new PdfName("F");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  750 */   public static final PdfName FAR = new PdfName("Far");
/*      */   
/*  752 */   public static final PdfName FB = new PdfName("FB");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  757 */   public static final PdfName FD = new PdfName("FD");
/*      */   
/*  759 */   public static final PdfName FDECODEPARMS = new PdfName("FDecodeParms");
/*      */   
/*  761 */   public static final PdfName FDF = new PdfName("FDF");
/*      */   
/*  763 */   public static final PdfName FF = new PdfName("Ff");
/*      */   
/*  765 */   public static final PdfName FFILTER = new PdfName("FFilter");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  770 */   public static final PdfName FG = new PdfName("FG");
/*      */   
/*  772 */   public static final PdfName FIELDMDP = new PdfName("FieldMDP");
/*      */   
/*  774 */   public static final PdfName FIELDS = new PdfName("Fields");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  779 */   public static final PdfName FIGURE = new PdfName("Figure");
/*      */   
/*  781 */   public static final PdfName FILEATTACHMENT = new PdfName("FileAttachment");
/*      */   
/*  783 */   public static final PdfName FILESPEC = new PdfName("Filespec");
/*      */   
/*  785 */   public static final PdfName FILTER = new PdfName("Filter");
/*      */   
/*  787 */   public static final PdfName FIRST = new PdfName("First");
/*      */   
/*  789 */   public static final PdfName FIRSTCHAR = new PdfName("FirstChar");
/*      */   
/*  791 */   public static final PdfName FIRSTPAGE = new PdfName("FirstPage");
/*      */   
/*  793 */   public static final PdfName FIT = new PdfName("Fit");
/*      */   
/*  795 */   public static final PdfName FITH = new PdfName("FitH");
/*      */   
/*  797 */   public static final PdfName FITV = new PdfName("FitV");
/*      */   
/*  799 */   public static final PdfName FITR = new PdfName("FitR");
/*      */   
/*  801 */   public static final PdfName FITB = new PdfName("FitB");
/*      */   
/*  803 */   public static final PdfName FITBH = new PdfName("FitBH");
/*      */   
/*  805 */   public static final PdfName FITBV = new PdfName("FitBV");
/*      */   
/*  807 */   public static final PdfName FITWINDOW = new PdfName("FitWindow");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  812 */   public static final PdfName FL = new PdfName("Fl");
/*      */   
/*  814 */   public static final PdfName FLAGS = new PdfName("Flags");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  819 */   public static final PdfName FLASH = new PdfName("Flash");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  824 */   public static final PdfName FLASHVARS = new PdfName("FlashVars");
/*      */   
/*  826 */   public static final PdfName FLATEDECODE = new PdfName("FlateDecode");
/*      */   
/*  828 */   public static final PdfName FO = new PdfName("Fo");
/*      */   
/*  830 */   public static final PdfName FONT = new PdfName("Font");
/*      */   
/*  832 */   public static final PdfName FONTBBOX = new PdfName("FontBBox");
/*      */   
/*  834 */   public static final PdfName FONTDESCRIPTOR = new PdfName("FontDescriptor");
/*      */   
/*  836 */   public static final PdfName FONTFAMILY = new PdfName("FontFamily");
/*      */   
/*  838 */   public static final PdfName FONTFILE = new PdfName("FontFile");
/*      */   
/*  840 */   public static final PdfName FONTFILE2 = new PdfName("FontFile2");
/*      */   
/*  842 */   public static final PdfName FONTFILE3 = new PdfName("FontFile3");
/*      */   
/*  844 */   public static final PdfName FONTMATRIX = new PdfName("FontMatrix");
/*      */   
/*  846 */   public static final PdfName FONTNAME = new PdfName("FontName");
/*      */   
/*  848 */   public static final PdfName FONTWEIGHT = new PdfName("FontWeight");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  853 */   public static final PdfName FOREGROUND = new PdfName("Foreground");
/*      */   
/*  855 */   public static final PdfName FORM = new PdfName("Form");
/*      */   
/*  857 */   public static final PdfName FORMTYPE = new PdfName("FormType");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  862 */   public static final PdfName FORMULA = new PdfName("Formula");
/*      */   
/*  864 */   public static final PdfName FREETEXT = new PdfName("FreeText");
/*      */   
/*  866 */   public static final PdfName FRM = new PdfName("FRM");
/*      */   
/*  868 */   public static final PdfName FS = new PdfName("FS");
/*      */   
/*  870 */   public static final PdfName FT = new PdfName("FT");
/*      */   
/*  872 */   public static final PdfName FULLSCREEN = new PdfName("FullScreen");
/*      */   
/*  874 */   public static final PdfName FUNCTION = new PdfName("Function");
/*      */   
/*  876 */   public static final PdfName FUNCTIONS = new PdfName("Functions");
/*      */   
/*  878 */   public static final PdfName FUNCTIONTYPE = new PdfName("FunctionType");
/*      */   
/*  880 */   public static final PdfName GAMMA = new PdfName("Gamma");
/*      */   
/*  882 */   public static final PdfName GBK = new PdfName("GBK");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  887 */   public static final PdfName GCS = new PdfName("GCS");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  892 */   public static final PdfName GEO = new PdfName("GEO");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  897 */   public static final PdfName GEOGCS = new PdfName("GEOGCS");
/*      */   
/*  899 */   public static final PdfName GLITTER = new PdfName("Glitter");
/*      */   
/*  901 */   public static final PdfName GOTO = new PdfName("GoTo");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  906 */   public static final PdfName GOTO3DVIEW = new PdfName("GoTo3DView");
/*      */   
/*  908 */   public static final PdfName GOTOE = new PdfName("GoToE");
/*      */   
/*  910 */   public static final PdfName GOTOR = new PdfName("GoToR");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  915 */   public static final PdfName GPTS = new PdfName("GPTS");
/*      */   
/*  917 */   public static final PdfName GROUP = new PdfName("Group");
/*      */   
/*  919 */   public static final PdfName GTS_PDFA1 = new PdfName("GTS_PDFA1");
/*      */   
/*  921 */   public static final PdfName GTS_PDFX = new PdfName("GTS_PDFX");
/*      */   
/*  923 */   public static final PdfName GTS_PDFXVERSION = new PdfName("GTS_PDFXVersion");
/*      */   
/*  925 */   public static final PdfName H = new PdfName("H");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  930 */   public static final PdfName H1 = new PdfName("H1");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  935 */   public static final PdfName H2 = new PdfName("H2");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  940 */   public static final PdfName H3 = new PdfName("H3");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  945 */   public static final PdfName H4 = new PdfName("H4");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  950 */   public static final PdfName H5 = new PdfName("H5");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  955 */   public static final PdfName H6 = new PdfName("H6");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  960 */   public static final PdfName HALFTONENAME = new PdfName("HalftoneName");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  965 */   public static final PdfName HALFTONETYPE = new PdfName("HalftoneType");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  971 */   public static final PdfName HALIGN = new PdfName("HAlign");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  976 */   public static final PdfName HEADERS = new PdfName("Headers");
/*      */   
/*  978 */   public static final PdfName HEIGHT = new PdfName("Height");
/*      */   
/*  980 */   public static final PdfName HELV = new PdfName("Helv");
/*      */   
/*  982 */   public static final PdfName HELVETICA = new PdfName("Helvetica");
/*      */   
/*  984 */   public static final PdfName HELVETICA_BOLD = new PdfName("Helvetica-Bold");
/*      */   
/*  986 */   public static final PdfName HELVETICA_OBLIQUE = new PdfName("Helvetica-Oblique");
/*      */   
/*  988 */   public static final PdfName HELVETICA_BOLDOBLIQUE = new PdfName("Helvetica-BoldOblique");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  993 */   public static final PdfName HF = new PdfName("HF");
/*      */   
/*  995 */   public static final PdfName HID = new PdfName("Hid");
/*      */   
/*  997 */   public static final PdfName HIDE = new PdfName("Hide");
/*      */   
/*  999 */   public static final PdfName HIDEMENUBAR = new PdfName("HideMenubar");
/*      */   
/* 1001 */   public static final PdfName HIDETOOLBAR = new PdfName("HideToolbar");
/*      */   
/* 1003 */   public static final PdfName HIDEWINDOWUI = new PdfName("HideWindowUI");
/*      */   
/* 1005 */   public static final PdfName HIGHLIGHT = new PdfName("Highlight");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1010 */   public static final PdfName HOFFSET = new PdfName("HOffset");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1015 */   public static final PdfName HT = new PdfName("HT");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1020 */   public static final PdfName HTP = new PdfName("HTP");
/*      */   
/* 1022 */   public static final PdfName I = new PdfName("I");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1027 */   public static final PdfName IC = new PdfName("IC");
/*      */   
/* 1029 */   public static final PdfName ICCBASED = new PdfName("ICCBased");
/*      */   
/* 1031 */   public static final PdfName ID = new PdfName("ID");
/*      */   
/* 1033 */   public static final PdfName IDENTITY = new PdfName("Identity");
/*      */   
/* 1035 */   public static final PdfName IDTREE = new PdfName("IDTree");
/*      */   
/* 1037 */   public static final PdfName IF = new PdfName("IF");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1042 */   public static final PdfName IM = new PdfName("IM");
/*      */   
/* 1044 */   public static final PdfName IMAGE = new PdfName("Image");
/*      */   
/* 1046 */   public static final PdfName IMAGEB = new PdfName("ImageB");
/*      */   
/* 1048 */   public static final PdfName IMAGEC = new PdfName("ImageC");
/*      */   
/* 1050 */   public static final PdfName IMAGEI = new PdfName("ImageI");
/*      */   
/* 1052 */   public static final PdfName IMAGEMASK = new PdfName("ImageMask");
/*      */   
/* 1054 */   public static final PdfName INCLUDE = new PdfName("Include");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1059 */   public static final PdfName IND = new PdfName("Ind");
/*      */   
/* 1061 */   public static final PdfName INDEX = new PdfName("Index");
/*      */   
/* 1063 */   public static final PdfName INDEXED = new PdfName("Indexed");
/*      */   
/* 1065 */   public static final PdfName INFO = new PdfName("Info");
/*      */   
/* 1067 */   public static final PdfName INK = new PdfName("Ink");
/*      */   
/* 1069 */   public static final PdfName INKLIST = new PdfName("InkList");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1074 */   public static final PdfName INSTANCES = new PdfName("Instances");
/*      */   
/* 1076 */   public static final PdfName IMPORTDATA = new PdfName("ImportData");
/*      */   
/* 1078 */   public static final PdfName INTENT = new PdfName("Intent");
/*      */   
/* 1080 */   public static final PdfName INTERPOLATE = new PdfName("Interpolate");
/*      */   
/* 1082 */   public static final PdfName ISMAP = new PdfName("IsMap");
/*      */   
/* 1084 */   public static final PdfName IRT = new PdfName("IRT");
/*      */   
/* 1086 */   public static final PdfName ITALICANGLE = new PdfName("ItalicAngle");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1091 */   public static final PdfName ITXT = new PdfName("ITXT");
/*      */   
/* 1093 */   public static final PdfName IX = new PdfName("IX");
/*      */   
/* 1095 */   public static final PdfName JAVASCRIPT = new PdfName("JavaScript");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1100 */   public static final PdfName JBIG2DECODE = new PdfName("JBIG2Decode");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1105 */   public static final PdfName JBIG2GLOBALS = new PdfName("JBIG2Globals");
/*      */   
/* 1107 */   public static final PdfName JPXDECODE = new PdfName("JPXDecode");
/*      */   
/* 1109 */   public static final PdfName JS = new PdfName("JS");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1114 */   public static final PdfName JUSTIFY = new PdfName("Justify");
/*      */   
/* 1116 */   public static final PdfName K = new PdfName("K");
/*      */   
/* 1118 */   public static final PdfName KEYWORDS = new PdfName("Keywords");
/*      */   
/* 1120 */   public static final PdfName KIDS = new PdfName("Kids");
/*      */   
/* 1122 */   public static final PdfName L = new PdfName("L");
/*      */   
/* 1124 */   public static final PdfName L2R = new PdfName("L2R");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1129 */   public static final PdfName LAB = new PdfName("Lab");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1135 */   public static final PdfName LANG = new PdfName("Lang");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1140 */   public static final PdfName LANGUAGE = new PdfName("Language");
/*      */   
/* 1142 */   public static final PdfName LAST = new PdfName("Last");
/*      */   
/* 1144 */   public static final PdfName LASTCHAR = new PdfName("LastChar");
/*      */   
/* 1146 */   public static final PdfName LASTPAGE = new PdfName("LastPage");
/*      */   
/* 1148 */   public static final PdfName LAUNCH = new PdfName("Launch");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1153 */   public static final PdfName LAYOUT = new PdfName("Layout");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1158 */   public static final PdfName LBL = new PdfName("Lbl");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1163 */   public static final PdfName LBODY = new PdfName("LBody");
/*      */   
/* 1165 */   public static final PdfName LENGTH = new PdfName("Length");
/*      */   
/* 1167 */   public static final PdfName LENGTH1 = new PdfName("Length1");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1172 */   public static final PdfName LI = new PdfName("LI");
/*      */   
/* 1174 */   public static final PdfName LIMITS = new PdfName("Limits");
/*      */   
/* 1176 */   public static final PdfName LINE = new PdfName("Line");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1181 */   public static final PdfName LINEAR = new PdfName("Linear");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1186 */   public static final PdfName LINEHEIGHT = new PdfName("LineHeight");
/*      */   
/* 1188 */   public static final PdfName LINK = new PdfName("Link");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1193 */   public static final PdfName LIST = new PdfName("List");
/*      */   
/* 1195 */   public static final PdfName LISTMODE = new PdfName("ListMode");
/*      */   
/* 1197 */   public static final PdfName LISTNUMBERING = new PdfName("ListNumbering");
/*      */   
/* 1199 */   public static final PdfName LOCATION = new PdfName("Location");
/*      */   
/* 1201 */   public static final PdfName LOCK = new PdfName("Lock");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1206 */   public static final PdfName LOCKED = new PdfName("Locked");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1211 */   public static final PdfName LOWERALPHA = new PdfName("LowerAlpha");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1216 */   public static final PdfName LOWERROMAN = new PdfName("LowerRoman");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1221 */   public static final PdfName LPTS = new PdfName("LPTS");
/*      */   
/* 1223 */   public static final PdfName LZWDECODE = new PdfName("LZWDecode");
/*      */   
/* 1225 */   public static final PdfName M = new PdfName("M");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1230 */   public static final PdfName MAC = new PdfName("Mac");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1235 */   public static final PdfName MATERIAL = new PdfName("Material");
/*      */   
/* 1237 */   public static final PdfName MATRIX = new PdfName("Matrix");
/*      */   
/* 1239 */   public static final PdfName MAC_EXPERT_ENCODING = new PdfName("MacExpertEncoding");
/*      */   
/* 1241 */   public static final PdfName MAC_ROMAN_ENCODING = new PdfName("MacRomanEncoding");
/*      */   
/* 1243 */   public static final PdfName MARKED = new PdfName("Marked");
/*      */   
/* 1245 */   public static final PdfName MARKINFO = new PdfName("MarkInfo");
/*      */   
/* 1247 */   public static final PdfName MASK = new PdfName("Mask");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1252 */   public static final PdfName MAX_LOWER_CASE = new PdfName("max");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1257 */   public static final PdfName MAX_CAMEL_CASE = new PdfName("Max");
/*      */   
/* 1259 */   public static final PdfName MAXLEN = new PdfName("MaxLen");
/*      */   
/* 1261 */   public static final PdfName MEDIABOX = new PdfName("MediaBox");
/*      */   
/* 1263 */   public static final PdfName MCID = new PdfName("MCID");
/*      */   
/* 1265 */   public static final PdfName MCR = new PdfName("MCR");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1270 */   public static final PdfName MEASURE = new PdfName("Measure");
/*      */   
/* 1272 */   public static final PdfName METADATA = new PdfName("Metadata");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1277 */   public static final PdfName MIN_LOWER_CASE = new PdfName("min");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1282 */   public static final PdfName MIN_CAMEL_CASE = new PdfName("Min");
/*      */   
/* 1284 */   public static final PdfName MK = new PdfName("MK");
/*      */   
/* 1286 */   public static final PdfName MMTYPE1 = new PdfName("MMType1");
/*      */   
/* 1288 */   public static final PdfName MODDATE = new PdfName("ModDate");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1293 */   public static final PdfName MOVIE = new PdfName("Movie");
/*      */   
/* 1295 */   public static final PdfName N = new PdfName("N");
/*      */   
/* 1297 */   public static final PdfName N0 = new PdfName("n0");
/*      */   
/* 1299 */   public static final PdfName N1 = new PdfName("n1");
/*      */   
/* 1301 */   public static final PdfName N2 = new PdfName("n2");
/*      */   
/* 1303 */   public static final PdfName N3 = new PdfName("n3");
/*      */   
/* 1305 */   public static final PdfName N4 = new PdfName("n4");
/*      */   
/* 1307 */   public static final PdfName NAME = new PdfName("Name");
/*      */   
/* 1309 */   public static final PdfName NAMED = new PdfName("Named");
/*      */   
/* 1311 */   public static final PdfName NAMES = new PdfName("Names");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1316 */   public static final PdfName NAVIGATION = new PdfName("Navigation");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1321 */   public static final PdfName NAVIGATIONPANE = new PdfName("NavigationPane");
/* 1322 */   public static final PdfName NCHANNEL = new PdfName("NChannel");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1327 */   public static final PdfName NEAR = new PdfName("Near");
/*      */   
/* 1329 */   public static final PdfName NEEDAPPEARANCES = new PdfName("NeedAppearances");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1334 */   public static final PdfName NEEDRENDERING = new PdfName("NeedsRendering");
/*      */   
/* 1336 */   public static final PdfName NEWWINDOW = new PdfName("NewWindow");
/*      */   
/* 1338 */   public static final PdfName NEXT = new PdfName("Next");
/*      */   
/* 1340 */   public static final PdfName NEXTPAGE = new PdfName("NextPage");
/*      */   
/* 1342 */   public static final PdfName NM = new PdfName("NM");
/*      */   
/* 1344 */   public static final PdfName NONE = new PdfName("None");
/*      */   
/* 1346 */   public static final PdfName NONFULLSCREENPAGEMODE = new PdfName("NonFullScreenPageMode");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1351 */   public static final PdfName NONSTRUCT = new PdfName("NonStruct");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1356 */   public static final PdfName NOT = new PdfName("Not");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1361 */   public static final PdfName NOTE = new PdfName("Note");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1366 */   public static final PdfName NUMBERFORMAT = new PdfName("NumberFormat");
/*      */   
/* 1368 */   public static final PdfName NUMCOPIES = new PdfName("NumCopies");
/*      */   
/* 1370 */   public static final PdfName NUMS = new PdfName("Nums");
/*      */   
/* 1372 */   public static final PdfName O = new PdfName("O");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1377 */   public static final PdfName OBJ = new PdfName("Obj");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1382 */   public static final PdfName OBJR = new PdfName("OBJR");
/*      */   
/* 1384 */   public static final PdfName OBJSTM = new PdfName("ObjStm");
/*      */   
/* 1386 */   public static final PdfName OC = new PdfName("OC");
/*      */   
/* 1388 */   public static final PdfName OCG = new PdfName("OCG");
/*      */   
/* 1390 */   public static final PdfName OCGS = new PdfName("OCGs");
/*      */   
/* 1392 */   public static final PdfName OCMD = new PdfName("OCMD");
/*      */   
/* 1394 */   public static final PdfName OCPROPERTIES = new PdfName("OCProperties");
/*      */   
/*      */ 
/*      */ 
/* 1398 */   public static final PdfName OCSP = new PdfName("OCSP");
/*      */   
/*      */ 
/*      */ 
/* 1402 */   public static final PdfName OCSPS = new PdfName("OCSPs");
/*      */   
/* 1404 */   public static final PdfName OE = new PdfName("OE");
/*      */   
/* 1406 */   public static final PdfName Off = new PdfName("Off");
/*      */   
/* 1408 */   public static final PdfName OFF = new PdfName("OFF");
/*      */   
/* 1410 */   public static final PdfName ON = new PdfName("ON");
/*      */   
/* 1412 */   public static final PdfName ONECOLUMN = new PdfName("OneColumn");
/*      */   
/* 1414 */   public static final PdfName OPEN = new PdfName("Open");
/*      */   
/* 1416 */   public static final PdfName OPENACTION = new PdfName("OpenAction");
/*      */   
/* 1418 */   public static final PdfName OP = new PdfName("OP");
/*      */   
/* 1420 */   public static final PdfName op = new PdfName("op");
/*      */   
/*      */ 
/*      */ 
/* 1424 */   public static final PdfName OPI = new PdfName("OPI");
/*      */   
/* 1426 */   public static final PdfName OPM = new PdfName("OPM");
/*      */   
/* 1428 */   public static final PdfName OPT = new PdfName("Opt");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1433 */   public static final PdfName OR = new PdfName("Or");
/*      */   
/* 1435 */   public static final PdfName ORDER = new PdfName("Order");
/*      */   
/* 1437 */   public static final PdfName ORDERING = new PdfName("Ordering");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1442 */   public static final PdfName ORG = new PdfName("Org");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1447 */   public static final PdfName OSCILLATING = new PdfName("Oscillating");
/*      */   
/*      */ 
/* 1450 */   public static final PdfName OUTLINES = new PdfName("Outlines");
/*      */   
/* 1452 */   public static final PdfName OUTPUTCONDITION = new PdfName("OutputCondition");
/*      */   
/* 1454 */   public static final PdfName OUTPUTCONDITIONIDENTIFIER = new PdfName("OutputConditionIdentifier");
/*      */   
/* 1456 */   public static final PdfName OUTPUTINTENT = new PdfName("OutputIntent");
/*      */   
/* 1458 */   public static final PdfName OUTPUTINTENTS = new PdfName("OutputIntents");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1463 */   public static final PdfName OVERLAYTEXT = new PdfName("OverlayText");
/*      */   
/* 1465 */   public static final PdfName P = new PdfName("P");
/*      */   
/* 1467 */   public static final PdfName PAGE = new PdfName("Page");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1472 */   public static final PdfName PAGEELEMENT = new PdfName("PageElement");
/*      */   
/* 1474 */   public static final PdfName PAGELABELS = new PdfName("PageLabels");
/*      */   
/* 1476 */   public static final PdfName PAGELAYOUT = new PdfName("PageLayout");
/*      */   
/* 1478 */   public static final PdfName PAGEMODE = new PdfName("PageMode");
/*      */   
/* 1480 */   public static final PdfName PAGES = new PdfName("Pages");
/*      */   
/* 1482 */   public static final PdfName PAINTTYPE = new PdfName("PaintType");
/*      */   
/* 1484 */   public static final PdfName PANOSE = new PdfName("Panose");
/*      */   
/* 1486 */   public static final PdfName PARAMS = new PdfName("Params");
/*      */   
/* 1488 */   public static final PdfName PARENT = new PdfName("Parent");
/*      */   
/* 1490 */   public static final PdfName PARENTTREE = new PdfName("ParentTree");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1495 */   public static final PdfName PARENTTREENEXTKEY = new PdfName("ParentTreeNextKey");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1500 */   public static final PdfName PART = new PdfName("Part");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1505 */   public static final PdfName PASSCONTEXTCLICK = new PdfName("PassContextClick");
/*      */   
/* 1507 */   public static final PdfName PATTERN = new PdfName("Pattern");
/*      */   
/* 1509 */   public static final PdfName PATTERNTYPE = new PdfName("PatternType");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1514 */   public static final PdfName PB = new PdfName("pb");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1519 */   public static final PdfName PC = new PdfName("PC");
/*      */   
/* 1521 */   public static final PdfName PDF = new PdfName("PDF");
/*      */   
/* 1523 */   public static final PdfName PDFDOCENCODING = new PdfName("PDFDocEncoding");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1528 */   public static final PdfName PDU = new PdfName("PDU");
/*      */   
/* 1530 */   public static final PdfName PERCEPTUAL = new PdfName("Perceptual");
/*      */   
/* 1532 */   public static final PdfName PERMS = new PdfName("Perms");
/*      */   
/* 1534 */   public static final PdfName PG = new PdfName("Pg");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1539 */   public static final PdfName PI = new PdfName("PI");
/*      */   
/* 1541 */   public static final PdfName PICKTRAYBYPDFSIZE = new PdfName("PickTrayByPDFSize");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1546 */   public static final PdfName PIECEINFO = new PdfName("PieceInfo");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1551 */   public static final PdfName PLAYCOUNT = new PdfName("PlayCount");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1556 */   public static final PdfName PO = new PdfName("PO");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1561 */   public static final PdfName POLYGON = new PdfName("Polygon");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1566 */   public static final PdfName POLYLINE = new PdfName("PolyLine");
/*      */   
/* 1568 */   public static final PdfName POPUP = new PdfName("Popup");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1573 */   public static final PdfName POSITION = new PdfName("Position");
/*      */   
/* 1575 */   public static final PdfName PREDICTOR = new PdfName("Predictor");
/*      */   
/* 1577 */   public static final PdfName PREFERRED = new PdfName("Preferred");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1582 */   public static final PdfName PRESENTATION = new PdfName("Presentation");
/*      */   
/* 1584 */   public static final PdfName PRESERVERB = new PdfName("PreserveRB");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1589 */   public static final PdfName PRESSTEPS = new PdfName("PresSteps");
/*      */   
/* 1591 */   public static final PdfName PREV = new PdfName("Prev");
/*      */   
/* 1593 */   public static final PdfName PREVPAGE = new PdfName("PrevPage");
/*      */   
/* 1595 */   public static final PdfName PRINT = new PdfName("Print");
/*      */   
/* 1597 */   public static final PdfName PRINTAREA = new PdfName("PrintArea");
/*      */   
/* 1599 */   public static final PdfName PRINTCLIP = new PdfName("PrintClip");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1604 */   public static final PdfName PRINTERMARK = new PdfName("PrinterMark");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1609 */   public static final PdfName PRINTFIELD = new PdfName("PrintField");
/*      */   
/* 1611 */   public static final PdfName PRINTPAGERANGE = new PdfName("PrintPageRange");
/*      */   
/* 1613 */   public static final PdfName PRINTSCALING = new PdfName("PrintScaling");
/*      */   
/* 1615 */   public static final PdfName PRINTSTATE = new PdfName("PrintState");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1620 */   public static final PdfName PRIVATE = new PdfName("Private");
/*      */   
/* 1622 */   public static final PdfName PROCSET = new PdfName("ProcSet");
/*      */   
/* 1624 */   public static final PdfName PRODUCER = new PdfName("Producer");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1629 */   public static final PdfName PROJCS = new PdfName("PROJCS");
/*      */   
/* 1631 */   public static final PdfName PROP_BUILD = new PdfName("Prop_Build");
/*      */   
/* 1633 */   public static final PdfName PROPERTIES = new PdfName("Properties");
/*      */   
/* 1635 */   public static final PdfName PS = new PdfName("PS");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1640 */   public static final PdfName PTDATA = new PdfName("PtData");
/*      */   
/* 1642 */   public static final PdfName PUBSEC = new PdfName("Adobe.PubSec");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1647 */   public static final PdfName PV = new PdfName("PV");
/*      */   
/* 1649 */   public static final PdfName Q = new PdfName("Q");
/*      */   
/* 1651 */   public static final PdfName QUADPOINTS = new PdfName("QuadPoints");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1656 */   public static final PdfName QUOTE = new PdfName("Quote");
/*      */   
/* 1658 */   public static final PdfName R = new PdfName("R");
/*      */   
/* 1660 */   public static final PdfName R2L = new PdfName("R2L");
/*      */   
/* 1662 */   public static final PdfName RANGE = new PdfName("Range");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1667 */   public static final PdfName RB = new PdfName("RB");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1672 */   public static final PdfName rb = new PdfName("rb");
/*      */   
/* 1674 */   public static final PdfName RBGROUPS = new PdfName("RBGroups");
/*      */   
/* 1676 */   public static final PdfName RC = new PdfName("RC");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1681 */   public static final PdfName RD = new PdfName("RD");
/*      */   
/* 1683 */   public static final PdfName REASON = new PdfName("Reason");
/*      */   
/* 1685 */   public static final PdfName RECIPIENTS = new PdfName("Recipients");
/*      */   
/* 1687 */   public static final PdfName RECT = new PdfName("Rect");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1692 */   public static final PdfName REDACT = new PdfName("Redact");
/*      */   
/* 1694 */   public static final PdfName REFERENCE = new PdfName("Reference");
/*      */   
/* 1696 */   public static final PdfName REGISTRY = new PdfName("Registry");
/*      */   
/* 1698 */   public static final PdfName REGISTRYNAME = new PdfName("RegistryName");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1703 */   public static final PdfName RELATIVECOLORIMETRIC = new PdfName("RelativeColorimetric");
/*      */   
/* 1705 */   public static final PdfName RENDITION = new PdfName("Rendition");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1710 */   public static final PdfName REPEAT = new PdfName("Repeat");
/*      */   
/* 1712 */   public static final PdfName RESETFORM = new PdfName("ResetForm");
/*      */   
/* 1714 */   public static final PdfName RESOURCES = new PdfName("Resources");
/* 1715 */   public static final PdfName REQUIREMENTS = new PdfName("Requirements");
/* 1716 */   public static final PdfName REVERSEDCHARS = new PdfName("ReversedChars");
/*      */   
/* 1718 */   public static final PdfName RI = new PdfName("RI");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1723 */   public static final PdfName RICHMEDIA = new PdfName("RichMedia");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1728 */   public static final PdfName RICHMEDIAACTIVATION = new PdfName("RichMediaActivation");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1733 */   public static final PdfName RICHMEDIAANIMATION = new PdfName("RichMediaAnimation");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1738 */   public static final PdfName RICHMEDIACOMMAND = new PdfName("RichMediaCommand");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1743 */   public static final PdfName RICHMEDIACONFIGURATION = new PdfName("RichMediaConfiguration");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1748 */   public static final PdfName RICHMEDIACONTENT = new PdfName("RichMediaContent");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1753 */   public static final PdfName RICHMEDIADEACTIVATION = new PdfName("RichMediaDeactivation");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1758 */   public static final PdfName RICHMEDIAEXECUTE = new PdfName("RichMediaExecute");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1763 */   public static final PdfName RICHMEDIAINSTANCE = new PdfName("RichMediaInstance");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1768 */   public static final PdfName RICHMEDIAPARAMS = new PdfName("RichMediaParams");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1773 */   public static final PdfName RICHMEDIAPOSITION = new PdfName("RichMediaPosition");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1778 */   public static final PdfName RICHMEDIAPRESENTATION = new PdfName("RichMediaPresentation");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1783 */   public static final PdfName RICHMEDIASETTINGS = new PdfName("RichMediaSettings");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1788 */   public static final PdfName RICHMEDIAWINDOW = new PdfName("RichMediaWindow");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1793 */   public static final PdfName RL = new PdfName("RL");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1798 */   public static final PdfName ROLE = new PdfName("Role");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1803 */   public static final PdfName RO = new PdfName("RO");
/*      */   
/* 1805 */   public static final PdfName ROLEMAP = new PdfName("RoleMap");
/*      */   
/* 1807 */   public static final PdfName ROOT = new PdfName("Root");
/*      */   
/* 1809 */   public static final PdfName ROTATE = new PdfName("Rotate");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1814 */   public static final PdfName ROW = new PdfName("Row");
/*      */   
/* 1816 */   public static final PdfName ROWS = new PdfName("Rows");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1821 */   public static final PdfName ROWSPAN = new PdfName("RowSpan");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1826 */   public static final PdfName RP = new PdfName("RP");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1831 */   public static final PdfName RT = new PdfName("RT");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1836 */   public static final PdfName RUBY = new PdfName("Ruby");
/*      */   
/* 1838 */   public static final PdfName RUNLENGTHDECODE = new PdfName("RunLengthDecode");
/*      */   
/* 1840 */   public static final PdfName RV = new PdfName("RV");
/*      */   
/* 1842 */   public static final PdfName S = new PdfName("S");
/*      */   
/* 1844 */   public static final PdfName SATURATION = new PdfName("Saturation");
/*      */   
/* 1846 */   public static final PdfName SCHEMA = new PdfName("Schema");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1851 */   public static final PdfName SCOPE = new PdfName("Scope");
/*      */   
/* 1853 */   public static final PdfName SCREEN = new PdfName("Screen");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1858 */   public static final PdfName SCRIPTS = new PdfName("Scripts");
/*      */   
/* 1860 */   public static final PdfName SECT = new PdfName("Sect");
/*      */   
/* 1862 */   public static final PdfName SEPARATION = new PdfName("Separation");
/*      */   
/* 1864 */   public static final PdfName SETOCGSTATE = new PdfName("SetOCGState");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1869 */   public static final PdfName SETTINGS = new PdfName("Settings");
/*      */   
/* 1871 */   public static final PdfName SHADING = new PdfName("Shading");
/*      */   
/* 1873 */   public static final PdfName SHADINGTYPE = new PdfName("ShadingType");
/*      */   
/* 1875 */   public static final PdfName SHIFT_JIS = new PdfName("Shift-JIS");
/*      */   
/* 1877 */   public static final PdfName SIG = new PdfName("Sig");
/*      */   
/* 1879 */   public static final PdfName SIGFIELDLOCK = new PdfName("SigFieldLock");
/*      */   
/* 1881 */   public static final PdfName SIGFLAGS = new PdfName("SigFlags");
/*      */   
/* 1883 */   public static final PdfName SIGREF = new PdfName("SigRef");
/*      */   
/* 1885 */   public static final PdfName SIMPLEX = new PdfName("Simplex");
/*      */   
/* 1887 */   public static final PdfName SINGLEPAGE = new PdfName("SinglePage");
/*      */   
/* 1889 */   public static final PdfName SIZE = new PdfName("Size");
/*      */   
/* 1891 */   public static final PdfName SMASK = new PdfName("SMask");
/*      */   
/* 1893 */   public static final PdfName SMASKINDATA = new PdfName("SMaskInData");
/*      */   
/* 1895 */   public static final PdfName SORT = new PdfName("Sort");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1900 */   public static final PdfName SOUND = new PdfName("Sound");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1905 */   public static final PdfName SPACEAFTER = new PdfName("SpaceAfter");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1910 */   public static final PdfName SPACEBEFORE = new PdfName("SpaceBefore");
/*      */   
/* 1912 */   public static final PdfName SPAN = new PdfName("Span");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1917 */   public static final PdfName SPEED = new PdfName("Speed");
/*      */   
/* 1919 */   public static final PdfName SPLIT = new PdfName("Split");
/*      */   
/* 1921 */   public static final PdfName SQUARE = new PdfName("Square");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1926 */   public static final PdfName SQUIGGLY = new PdfName("Squiggly");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1931 */   public static final PdfName SS = new PdfName("SS");
/*      */   
/* 1933 */   public static final PdfName ST = new PdfName("St");
/*      */   
/* 1935 */   public static final PdfName STAMP = new PdfName("Stamp");
/*      */   
/* 1937 */   public static final PdfName STATUS = new PdfName("Status");
/*      */   
/* 1939 */   public static final PdfName STANDARD = new PdfName("Standard");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1944 */   public static final PdfName START = new PdfName("Start");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1949 */   public static final PdfName STARTINDENT = new PdfName("StartIndent");
/*      */   
/* 1951 */   public static final PdfName STATE = new PdfName("State");
/*      */   
/* 1953 */   public static final PdfName STDCF = new PdfName("StdCF");
/*      */   
/* 1955 */   public static final PdfName STEMV = new PdfName("StemV");
/*      */   
/* 1957 */   public static final PdfName STMF = new PdfName("StmF");
/*      */   
/* 1959 */   public static final PdfName STRF = new PdfName("StrF");
/*      */   
/* 1961 */   public static final PdfName STRIKEOUT = new PdfName("StrikeOut");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1966 */   public static final PdfName STRUCTELEM = new PdfName("StructElem");
/*      */   
/* 1968 */   public static final PdfName STRUCTPARENT = new PdfName("StructParent");
/*      */   
/* 1970 */   public static final PdfName STRUCTPARENTS = new PdfName("StructParents");
/*      */   
/* 1972 */   public static final PdfName STRUCTTREEROOT = new PdfName("StructTreeRoot");
/*      */   
/* 1974 */   public static final PdfName STYLE = new PdfName("Style");
/*      */   
/* 1976 */   public static final PdfName SUBFILTER = new PdfName("SubFilter");
/*      */   
/* 1978 */   public static final PdfName SUBJECT = new PdfName("Subject");
/*      */   
/* 1980 */   public static final PdfName SUBMITFORM = new PdfName("SubmitForm");
/*      */   
/* 1982 */   public static final PdfName SUBTYPE = new PdfName("Subtype");
/*      */   
/*      */ 
/*      */ 
/* 1986 */   public static final PdfName SUMMARY = new PdfName("Summary");
/*      */   
/* 1988 */   public static final PdfName SUPPLEMENT = new PdfName("Supplement");
/*      */   
/* 1990 */   public static final PdfName SV = new PdfName("SV");
/*      */   
/* 1992 */   public static final PdfName SW = new PdfName("SW");
/*      */   
/* 1994 */   public static final PdfName SYMBOL = new PdfName("Symbol");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1999 */   public static final PdfName T = new PdfName("T");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2004 */   public static final PdfName TA = new PdfName("TA");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2009 */   public static final PdfName TABLE = new PdfName("Table");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2014 */   public static final PdfName TABS = new PdfName("Tabs");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2019 */   public static final PdfName TBODY = new PdfName("TBody");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2024 */   public static final PdfName TD = new PdfName("TD");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2029 */   public static final PdfName TR = new PdfName("TR");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2034 */   public static final PdfName TR2 = new PdfName("TR2");
/*      */   
/* 2036 */   public static final PdfName TEXT = new PdfName("Text");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2041 */   public static final PdfName TEXTALIGN = new PdfName("TextAlign");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2046 */   public static final PdfName TEXTDECORATIONCOLOR = new PdfName("TextDecorationColor");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2051 */   public static final PdfName TEXTDECORATIONTHICKNESS = new PdfName("TextDecorationThickness");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2056 */   public static final PdfName TEXTDECORATIONTYPE = new PdfName("TextDecorationType");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2061 */   public static final PdfName TEXTINDENT = new PdfName("TextIndent");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2066 */   public static final PdfName TFOOT = new PdfName("TFoot");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2071 */   public static final PdfName TH = new PdfName("TH");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2076 */   public static final PdfName THEAD = new PdfName("THead");
/*      */   
/* 2078 */   public static final PdfName THUMB = new PdfName("Thumb");
/*      */   
/* 2080 */   public static final PdfName THREADS = new PdfName("Threads");
/*      */   
/* 2082 */   public static final PdfName TI = new PdfName("TI");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2087 */   public static final PdfName TIME = new PdfName("Time");
/*      */   
/* 2089 */   public static final PdfName TILINGTYPE = new PdfName("TilingType");
/*      */   
/* 2091 */   public static final PdfName TIMES_ROMAN = new PdfName("Times-Roman");
/*      */   
/* 2093 */   public static final PdfName TIMES_BOLD = new PdfName("Times-Bold");
/*      */   
/* 2095 */   public static final PdfName TIMES_ITALIC = new PdfName("Times-Italic");
/*      */   
/* 2097 */   public static final PdfName TIMES_BOLDITALIC = new PdfName("Times-BoldItalic");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2103 */   public static final PdfName TITLE = new PdfName("Title");
/*      */   
/* 2105 */   public static final PdfName TK = new PdfName("TK");
/*      */   
/* 2107 */   public static final PdfName TM = new PdfName("TM");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2112 */   public static final PdfName TOC = new PdfName("TOC");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2117 */   public static final PdfName TOCI = new PdfName("TOCI");
/*      */   
/* 2119 */   public static final PdfName TOGGLE = new PdfName("Toggle");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2124 */   public static final PdfName TOOLBAR = new PdfName("Toolbar");
/*      */   
/* 2126 */   public static final PdfName TOUNICODE = new PdfName("ToUnicode");
/*      */   
/* 2128 */   public static final PdfName TP = new PdfName("TP");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2133 */   public static final PdfName TABLEROW = new PdfName("TR");
/*      */   
/* 2135 */   public static final PdfName TRANS = new PdfName("Trans");
/*      */   
/* 2137 */   public static final PdfName TRANSFORMPARAMS = new PdfName("TransformParams");
/*      */   
/* 2139 */   public static final PdfName TRANSFORMMETHOD = new PdfName("TransformMethod");
/*      */   
/* 2141 */   public static final PdfName TRANSPARENCY = new PdfName("Transparency");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2146 */   public static final PdfName TRANSPARENT = new PdfName("Transparent");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2151 */   public static final PdfName TRAPNET = new PdfName("TrapNet");
/*      */   
/* 2153 */   public static final PdfName TRAPPED = new PdfName("Trapped");
/*      */   
/* 2155 */   public static final PdfName TRIMBOX = new PdfName("TrimBox");
/*      */   
/* 2157 */   public static final PdfName TRUETYPE = new PdfName("TrueType");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2162 */   public static final PdfName TS = new PdfName("TS");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2167 */   public static final PdfName TTL = new PdfName("Ttl");
/*      */   
/* 2169 */   public static final PdfName TU = new PdfName("TU");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2174 */   public static final PdfName TV = new PdfName("tv");
/*      */   
/* 2176 */   public static final PdfName TWOCOLUMNLEFT = new PdfName("TwoColumnLeft");
/*      */   
/* 2178 */   public static final PdfName TWOCOLUMNRIGHT = new PdfName("TwoColumnRight");
/*      */   
/* 2180 */   public static final PdfName TWOPAGELEFT = new PdfName("TwoPageLeft");
/*      */   
/* 2182 */   public static final PdfName TWOPAGERIGHT = new PdfName("TwoPageRight");
/*      */   
/* 2184 */   public static final PdfName TX = new PdfName("Tx");
/*      */   
/* 2186 */   public static final PdfName TYPE = new PdfName("Type");
/*      */   
/* 2188 */   public static final PdfName TYPE0 = new PdfName("Type0");
/*      */   
/* 2190 */   public static final PdfName TYPE1 = new PdfName("Type1");
/*      */   
/* 2192 */   public static final PdfName TYPE3 = new PdfName("Type3");
/*      */   
/* 2194 */   public static final PdfName U = new PdfName("U");
/*      */   
/* 2196 */   public static final PdfName UE = new PdfName("UE");
/*      */   
/* 2198 */   public static final PdfName UF = new PdfName("UF");
/*      */   
/* 2200 */   public static final PdfName UHC = new PdfName("UHC");
/*      */   
/* 2202 */   public static final PdfName UNDERLINE = new PdfName("Underline");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2207 */   public static final PdfName UNIX = new PdfName("Unix");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2212 */   public static final PdfName UPPERALPHA = new PdfName("UpperAlpha");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2217 */   public static final PdfName UPPERROMAN = new PdfName("UpperRoman");
/*      */   
/* 2219 */   public static final PdfName UR = new PdfName("UR");
/*      */   
/* 2221 */   public static final PdfName UR3 = new PdfName("UR3");
/*      */   
/* 2223 */   public static final PdfName URI = new PdfName("URI");
/*      */   
/* 2225 */   public static final PdfName URL = new PdfName("URL");
/*      */   
/* 2227 */   public static final PdfName USAGE = new PdfName("Usage");
/*      */   
/* 2229 */   public static final PdfName USEATTACHMENTS = new PdfName("UseAttachments");
/*      */   
/* 2231 */   public static final PdfName USENONE = new PdfName("UseNone");
/*      */   
/* 2233 */   public static final PdfName USEOC = new PdfName("UseOC");
/*      */   
/* 2235 */   public static final PdfName USEOUTLINES = new PdfName("UseOutlines");
/*      */   
/* 2237 */   public static final PdfName USER = new PdfName("User");
/*      */   
/* 2239 */   public static final PdfName USERPROPERTIES = new PdfName("UserProperties");
/*      */   
/* 2241 */   public static final PdfName USERUNIT = new PdfName("UserUnit");
/*      */   
/* 2243 */   public static final PdfName USETHUMBS = new PdfName("UseThumbs");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2248 */   public static final PdfName UTF_8 = new PdfName("utf_8");
/*      */   
/* 2250 */   public static final PdfName V = new PdfName("V");
/*      */   
/* 2252 */   public static final PdfName V2 = new PdfName("V2");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2257 */   public static final PdfName VALIGN = new PdfName("VAlign");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2262 */   public static final PdfName VE = new PdfName("VE");
/*      */   
/* 2264 */   public static final PdfName VERISIGN_PPKVS = new PdfName("VeriSign.PPKVS");
/*      */   
/* 2266 */   public static final PdfName VERSION = new PdfName("Version");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2271 */   public static final PdfName VERTICES = new PdfName("Vertices");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2276 */   public static final PdfName VIDEO = new PdfName("Video");
/*      */   
/* 2278 */   public static final PdfName VIEW = new PdfName("View");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2283 */   public static final PdfName VIEWS = new PdfName("Views");
/*      */   
/* 2285 */   public static final PdfName VIEWAREA = new PdfName("ViewArea");
/*      */   
/* 2287 */   public static final PdfName VIEWCLIP = new PdfName("ViewClip");
/*      */   
/* 2289 */   public static final PdfName VIEWERPREFERENCES = new PdfName("ViewerPreferences");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2294 */   public static final PdfName VIEWPORT = new PdfName("Viewport");
/*      */   
/* 2296 */   public static final PdfName VIEWSTATE = new PdfName("ViewState");
/*      */   
/* 2298 */   public static final PdfName VISIBLEPAGES = new PdfName("VisiblePages");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2303 */   public static final PdfName VOFFSET = new PdfName("VOffset");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2308 */   public static final PdfName VP = new PdfName("VP");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2313 */   public static final PdfName VRI = new PdfName("VRI");
/*      */   
/* 2315 */   public static final PdfName W = new PdfName("W");
/*      */   
/* 2317 */   public static final PdfName W2 = new PdfName("W2");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2322 */   public static final PdfName WARICHU = new PdfName("Warichu");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2327 */   public static final PdfName WATERMARK = new PdfName("Watermark");
/*      */   
/* 2329 */   public static final PdfName WC = new PdfName("WC");
/*      */   
/* 2331 */   public static final PdfName WIDGET = new PdfName("Widget");
/*      */   
/* 2333 */   public static final PdfName WIDTH = new PdfName("Width");
/*      */   
/* 2335 */   public static final PdfName WIDTHS = new PdfName("Widths");
/*      */   
/* 2337 */   public static final PdfName WIN = new PdfName("Win");
/*      */   
/* 2339 */   public static final PdfName WIN_ANSI_ENCODING = new PdfName("WinAnsiEncoding");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2344 */   public static final PdfName WINDOW = new PdfName("Window");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2349 */   public static final PdfName WINDOWED = new PdfName("Windowed");
/*      */   
/* 2351 */   public static final PdfName WIPE = new PdfName("Wipe");
/*      */   
/* 2353 */   public static final PdfName WHITEPOINT = new PdfName("WhitePoint");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2358 */   public static final PdfName WKT = new PdfName("WKT");
/*      */   
/* 2360 */   public static final PdfName WP = new PdfName("WP");
/*      */   
/* 2362 */   public static final PdfName WS = new PdfName("WS");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2367 */   public static final PdfName WT = new PdfName("WT");
/*      */   
/* 2369 */   public static final PdfName X = new PdfName("X");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2374 */   public static final PdfName XA = new PdfName("XA");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2379 */   public static final PdfName XD = new PdfName("XD");
/*      */   
/* 2381 */   public static final PdfName XFA = new PdfName("XFA");
/*      */   
/* 2383 */   public static final PdfName XML = new PdfName("XML");
/*      */   
/* 2385 */   public static final PdfName XOBJECT = new PdfName("XObject");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2390 */   public static final PdfName XPTS = new PdfName("XPTS");
/*      */   
/* 2392 */   public static final PdfName XREF = new PdfName("XRef");
/*      */   
/* 2394 */   public static final PdfName XREFSTM = new PdfName("XRefStm");
/*      */   
/* 2396 */   public static final PdfName XSTEP = new PdfName("XStep");
/*      */   
/* 2398 */   public static final PdfName XYZ = new PdfName("XYZ");
/*      */   
/* 2400 */   public static final PdfName YSTEP = new PdfName("YStep");
/*      */   
/* 2402 */   public static final PdfName ZADB = new PdfName("ZaDb");
/*      */   
/* 2404 */   public static final PdfName ZAPFDINGBATS = new PdfName("ZapfDingbats");
/*      */   
/* 2406 */   public static final PdfName ZOOM = new PdfName("Zoom");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Map<String, PdfName> staticNames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/* 2423 */     Field[] fields = PdfName.class.getDeclaredFields();
/* 2424 */     staticNames = new HashMap(fields.length);
/* 2425 */     int flags = 25;
/*      */     try {
/* 2427 */       for (int fldIdx = 0; fldIdx < fields.length; fldIdx++) {
/* 2428 */         Field curFld = fields[fldIdx];
/* 2429 */         if (((curFld.getModifiers() & 0x19) == 25) && 
/* 2430 */           (curFld.getType().equals(PdfName.class))) {
/* 2431 */           PdfName name = (PdfName)curFld.get(null);
/* 2432 */           staticNames.put(decodeName(name.toString()), name);
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/* 2436 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 2441 */   private int hash = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName(String name)
/*      */   {
/* 2451 */     this(name, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName(String name, boolean lengthCheck)
/*      */   {
/* 2461 */     super(4);
/*      */     
/* 2463 */     int length = name.length();
/* 2464 */     if ((lengthCheck) && (length > 127))
/* 2465 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("the.name.1.is.too.long.2.characters", new Object[] { name, String.valueOf(length) }));
/* 2466 */     this.bytes = encodeName(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName(byte[] bytes)
/*      */   {
/* 2475 */     super(4, bytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int compareTo(PdfName name)
/*      */   {
/* 2492 */     byte[] myBytes = this.bytes;
/* 2493 */     byte[] objBytes = name.bytes;
/* 2494 */     int len = Math.min(myBytes.length, objBytes.length);
/* 2495 */     for (int i = 0; i < len; i++) {
/* 2496 */       if (myBytes[i] > objBytes[i])
/* 2497 */         return 1;
/* 2498 */       if (myBytes[i] < objBytes[i])
/* 2499 */         return -1;
/*      */     }
/* 2501 */     if (myBytes.length < objBytes.length)
/* 2502 */       return -1;
/* 2503 */     if (myBytes.length > objBytes.length)
/* 2504 */       return 1;
/* 2505 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/* 2517 */     if (this == obj)
/* 2518 */       return true;
/* 2519 */     if ((obj instanceof PdfName))
/* 2520 */       return compareTo((PdfName)obj) == 0;
/* 2521 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 2533 */     int h = this.hash;
/* 2534 */     if (h == 0) {
/* 2535 */       int ptr = 0;
/* 2536 */       int len = this.bytes.length;
/* 2537 */       for (int i = 0; i < len; i++)
/* 2538 */         h = 31 * h + (this.bytes[(ptr++)] & 0xFF);
/* 2539 */       this.hash = h;
/*      */     }
/* 2541 */     return h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] encodeName(String name)
/*      */   {
/* 2552 */     int length = name.length();
/* 2553 */     ByteBuffer buf = new ByteBuffer(length + 20);
/* 2554 */     buf.append('/');
/*      */     
/* 2556 */     char[] chars = name.toCharArray();
/* 2557 */     for (int k = 0; k < length; k++) {
/* 2558 */       char c = (char)(chars[k] & 0xFF);
/*      */       
/* 2560 */       switch (c) {
/*      */       case ' ': 
/*      */       case '#': 
/*      */       case '%': 
/*      */       case '(': 
/*      */       case ')': 
/*      */       case '/': 
/*      */       case '<': 
/*      */       case '>': 
/*      */       case '[': 
/*      */       case ']': 
/*      */       case '{': 
/*      */       case '}': 
/* 2573 */         buf.append('#');
/* 2574 */         buf.append(Integer.toString(c, 16));
/* 2575 */         break;
/*      */       default: 
/* 2577 */         if ((c >= ' ') && (c <= '~')) {
/* 2578 */           buf.append(c);
/*      */         } else {
/* 2580 */           buf.append('#');
/* 2581 */           if (c < '\020')
/* 2582 */             buf.append('0');
/* 2583 */           buf.append(Integer.toString(c, 16));
/*      */         }
/*      */         break;
/*      */       }
/*      */     }
/* 2588 */     return buf.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String decodeName(String name)
/*      */   {
/* 2598 */     StringBuffer buf = new StringBuffer();
/*      */     try {
/* 2600 */       int len = name.length();
/* 2601 */       for (int k = 1; k < len; k++) {
/* 2602 */         char c = name.charAt(k);
/* 2603 */         if (c == '#') {
/* 2604 */           char c1 = name.charAt(k + 1);
/* 2605 */           char c2 = name.charAt(k + 2);
/* 2606 */           c = (char)((PRTokeniser.getHex(c1) << 4) + PRTokeniser.getHex(c2));
/* 2607 */           k += 2;
/*      */         }
/* 2609 */         buf.append(c);
/*      */       }
/*      */     }
/*      */     catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*      */     
/*      */ 
/* 2615 */     return buf.toString();
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */