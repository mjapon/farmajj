/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.text.pdf.PdfDictionary;
/*     */ import com.itextpdf.text.pdf.PdfName;
/*     */ import com.itextpdf.text.pdf.PdfReader;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfReaderContentParser
/*     */ {
/*     */   private final PdfReader reader;
/*     */   
/*     */   public PdfReaderContentParser(PdfReader reader)
/*     */   {
/*  66 */     this.reader = reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <E extends RenderListener> E processContent(int pageNumber, E renderListener, Map<String, ContentOperator> additionalContentOperators)
/*     */     throws IOException
/*     */   {
/*  81 */     PdfDictionary pageDic = this.reader.getPageN(pageNumber);
/*  82 */     PdfDictionary resourcesDic = pageDic.getAsDict(PdfName.RESOURCES);
/*     */     
/*  84 */     PdfContentStreamProcessor processor = new PdfContentStreamProcessor(renderListener);
/*  85 */     for (Map.Entry<String, ContentOperator> entry : additionalContentOperators.entrySet()) {
/*  86 */       processor.registerContentOperator((String)entry.getKey(), (ContentOperator)entry.getValue());
/*     */     }
/*  88 */     processor.processContent(ContentByteUtils.getContentBytesForPage(this.reader, pageNumber), resourcesDic);
/*  89 */     return renderListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <E extends RenderListener> E processContent(int pageNumber, E renderListener)
/*     */     throws IOException
/*     */   {
/* 105 */     return processContent(pageNumber, renderListener, new HashMap());
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/PdfReaderContentParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */