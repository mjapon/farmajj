package com.itextpdf.text.pdf.parser;

import com.itextpdf.text.pdf.PdfIndirectReference;
import com.itextpdf.text.pdf.PdfStream;

public abstract interface XObjectDoHandler
{
  public abstract void handleXObject(PdfContentStreamProcessor paramPdfContentStreamProcessor, PdfStream paramPdfStream, PdfIndirectReference paramPdfIndirectReference);
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/XObjectDoHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */