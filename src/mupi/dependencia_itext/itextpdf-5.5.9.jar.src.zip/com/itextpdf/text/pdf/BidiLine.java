/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.Chunk;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.TabStop;
/*      */ import com.itextpdf.text.TabStop.Alignment;
/*      */ import com.itextpdf.text.Utilities;
/*      */ import com.itextpdf.text.pdf.draw.DrawInterface;
/*      */ import com.itextpdf.text.pdf.draw.LineSeparator;
/*      */ import com.itextpdf.text.pdf.languages.ArabicLigaturizer;
/*      */ import java.util.ArrayList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BidiLine
/*      */ {
/*      */   protected int runDirection;
/*   64 */   protected int pieceSize = 256;
/*   65 */   protected char[] text = new char[this.pieceSize];
/*   66 */   protected PdfChunk[] detailChunks = new PdfChunk[this.pieceSize];
/*   67 */   protected int totalTextLength = 0;
/*      */   
/*   69 */   protected byte[] orderLevels = new byte[this.pieceSize];
/*   70 */   protected int[] indexChars = new int[this.pieceSize];
/*      */   
/*   72 */   protected ArrayList<PdfChunk> chunks = new ArrayList();
/*   73 */   protected int indexChunk = 0;
/*   74 */   protected int indexChunkChar = 0;
/*   75 */   protected int currentChar = 0;
/*      */   
/*      */   protected int storedRunDirection;
/*   78 */   protected char[] storedText = new char[0];
/*   79 */   protected PdfChunk[] storedDetailChunks = new PdfChunk[0];
/*   80 */   protected int storedTotalTextLength = 0;
/*      */   
/*   82 */   protected byte[] storedOrderLevels = new byte[0];
/*   83 */   protected int[] storedIndexChars = new int[0];
/*      */   
/*   85 */   protected int storedIndexChunk = 0;
/*   86 */   protected int storedIndexChunkChar = 0;
/*   87 */   protected int storedCurrentChar = 0;
/*      */   
/*   89 */   protected boolean isWordSplit = false;
/*      */   
/*      */   protected boolean shortStore;
/*      */   
/*   93 */   protected static final IntHashtable mirrorChars = new IntHashtable();
/*      */   
/*      */ 
/*      */   protected int arabicOptions;
/*      */   
/*      */ 
/*      */   public BidiLine(BidiLine org)
/*      */   {
/*  101 */     this.runDirection = org.runDirection;
/*  102 */     this.pieceSize = org.pieceSize;
/*  103 */     this.text = ((char[])org.text.clone());
/*  104 */     this.detailChunks = ((PdfChunk[])org.detailChunks.clone());
/*  105 */     this.totalTextLength = org.totalTextLength;
/*      */     
/*  107 */     this.orderLevels = ((byte[])org.orderLevels.clone());
/*  108 */     this.indexChars = ((int[])org.indexChars.clone());
/*      */     
/*  110 */     this.chunks = new ArrayList(org.chunks);
/*  111 */     this.indexChunk = org.indexChunk;
/*  112 */     this.indexChunkChar = org.indexChunkChar;
/*  113 */     this.currentChar = org.currentChar;
/*      */     
/*  115 */     this.storedRunDirection = org.storedRunDirection;
/*  116 */     this.storedText = ((char[])org.storedText.clone());
/*  117 */     this.storedDetailChunks = ((PdfChunk[])org.storedDetailChunks.clone());
/*  118 */     this.storedTotalTextLength = org.storedTotalTextLength;
/*      */     
/*  120 */     this.storedOrderLevels = ((byte[])org.storedOrderLevels.clone());
/*  121 */     this.storedIndexChars = ((int[])org.storedIndexChars.clone());
/*      */     
/*  123 */     this.storedIndexChunk = org.storedIndexChunk;
/*  124 */     this.storedIndexChunkChar = org.storedIndexChunkChar;
/*  125 */     this.storedCurrentChar = org.storedCurrentChar;
/*      */     
/*  127 */     this.shortStore = org.shortStore;
/*  128 */     this.arabicOptions = org.arabicOptions;
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/*  132 */     return (this.currentChar >= this.totalTextLength) && (this.indexChunk >= this.chunks.size());
/*      */   }
/*      */   
/*      */   public void clearChunks() {
/*  136 */     this.chunks.clear();
/*  137 */     this.totalTextLength = 0;
/*  138 */     this.currentChar = 0;
/*      */   }
/*      */   
/*      */   public boolean getParagraph(int runDirection) {
/*  142 */     this.runDirection = runDirection;
/*  143 */     this.currentChar = 0;
/*  144 */     this.totalTextLength = 0;
/*      */     
/*  146 */     boolean hasText = false;
/*  150 */     for (; 
/*      */         
/*      */ 
/*  150 */         this.indexChunk < this.chunks.size(); this.indexChunk += 1) {
/*  151 */       PdfChunk ck = (PdfChunk)this.chunks.get(this.indexChunk);
/*  152 */       BaseFont bf = ck.font().getFont();
/*  153 */       String s = ck.toString();
/*  154 */       int len = s.length();
/*  155 */       for (; this.indexChunkChar < len; this.indexChunkChar += 1) {
/*  156 */         char c = s.charAt(this.indexChunkChar);
/*  157 */         char uniC = (char)bf.getUnicodeEquivalent(c);
/*  158 */         if ((uniC == '\r') || (uniC == '\n'))
/*      */         {
/*  160 */           if ((uniC == '\r') && (this.indexChunkChar + 1 < len) && (s.charAt(this.indexChunkChar + 1) == '\n'))
/*  161 */             this.indexChunkChar += 1;
/*  162 */           this.indexChunkChar += 1;
/*  163 */           if (this.indexChunkChar >= len) {
/*  164 */             this.indexChunkChar = 0;
/*  165 */             this.indexChunk += 1;
/*      */           }
/*  167 */           hasText = true;
/*  168 */           if (this.totalTextLength != 0) break;
/*  169 */           this.detailChunks[0] = ck; break;
/*      */         }
/*      */         
/*  172 */         addPiece(c, ck);
/*      */       }
/*  174 */       if (hasText)
/*      */         break;
/*  176 */       this.indexChunkChar = 0;
/*      */     }
/*  178 */     if (this.totalTextLength == 0) {
/*  179 */       return hasText;
/*      */     }
/*      */     
/*  182 */     this.totalTextLength = (trimRight(0, this.totalTextLength - 1) + 1);
/*  183 */     if (this.totalTextLength == 0) {
/*  184 */       return true;
/*      */     }
/*      */     
/*  187 */     if ((runDirection == 2) || (runDirection == 3)) {
/*  188 */       if (this.orderLevels.length < this.totalTextLength) {
/*  189 */         this.orderLevels = new byte[this.pieceSize];
/*  190 */         this.indexChars = new int[this.pieceSize];
/*      */       }
/*  192 */       ArabicLigaturizer.processNumbers(this.text, 0, this.totalTextLength, this.arabicOptions);
/*  193 */       BidiOrder order = new BidiOrder(this.text, 0, this.totalTextLength, (byte)(runDirection == 3 ? 1 : 0));
/*  194 */       byte[] od = order.getLevels();
/*  195 */       for (int k = 0; k < this.totalTextLength; k++) {
/*  196 */         this.orderLevels[k] = od[k];
/*  197 */         this.indexChars[k] = k;
/*      */       }
/*  199 */       doArabicShapping();
/*  200 */       mirrorGlyphs();
/*      */     }
/*  202 */     this.totalTextLength = (trimRightEx(0, this.totalTextLength - 1) + 1);
/*  203 */     return true;
/*      */   }
/*      */   
/*      */   public void addChunk(PdfChunk chunk) {
/*  207 */     this.chunks.add(chunk);
/*      */   }
/*      */   
/*      */   public void addChunks(ArrayList<PdfChunk> chunks) {
/*  211 */     this.chunks.addAll(chunks);
/*      */   }
/*      */   
/*      */   public void addPiece(char c, PdfChunk chunk) {
/*  215 */     if (this.totalTextLength >= this.pieceSize) {
/*  216 */       char[] tempText = this.text;
/*  217 */       PdfChunk[] tempDetailChunks = this.detailChunks;
/*  218 */       this.pieceSize *= 2;
/*  219 */       this.text = new char[this.pieceSize];
/*  220 */       this.detailChunks = new PdfChunk[this.pieceSize];
/*  221 */       System.arraycopy(tempText, 0, this.text, 0, this.totalTextLength);
/*  222 */       System.arraycopy(tempDetailChunks, 0, this.detailChunks, 0, this.totalTextLength);
/*      */     }
/*  224 */     this.text[this.totalTextLength] = c;
/*  225 */     this.detailChunks[(this.totalTextLength++)] = chunk;
/*      */   }
/*      */   
/*      */   public void save() {
/*  229 */     if (this.indexChunk > 0) {
/*  230 */       if (this.indexChunk >= this.chunks.size()) {
/*  231 */         this.chunks.clear();
/*      */       } else {
/*  233 */         for (this.indexChunk -= 1; this.indexChunk >= 0; this.indexChunk -= 1)
/*  234 */           this.chunks.remove(this.indexChunk);
/*      */       }
/*  236 */       this.indexChunk = 0;
/*      */     }
/*  238 */     this.storedRunDirection = this.runDirection;
/*  239 */     this.storedTotalTextLength = this.totalTextLength;
/*  240 */     this.storedIndexChunk = this.indexChunk;
/*  241 */     this.storedIndexChunkChar = this.indexChunkChar;
/*  242 */     this.storedCurrentChar = this.currentChar;
/*  243 */     this.shortStore = (this.currentChar < this.totalTextLength);
/*  244 */     if (!this.shortStore)
/*      */     {
/*  246 */       if (this.storedText.length < this.totalTextLength) {
/*  247 */         this.storedText = new char[this.totalTextLength];
/*  248 */         this.storedDetailChunks = new PdfChunk[this.totalTextLength];
/*      */       }
/*  250 */       System.arraycopy(this.text, 0, this.storedText, 0, this.totalTextLength);
/*  251 */       System.arraycopy(this.detailChunks, 0, this.storedDetailChunks, 0, this.totalTextLength);
/*      */     }
/*  253 */     if ((this.runDirection == 2) || (this.runDirection == 3)) {
/*  254 */       if (this.storedOrderLevels.length < this.totalTextLength) {
/*  255 */         this.storedOrderLevels = new byte[this.totalTextLength];
/*  256 */         this.storedIndexChars = new int[this.totalTextLength];
/*      */       }
/*  258 */       System.arraycopy(this.orderLevels, this.currentChar, this.storedOrderLevels, this.currentChar, this.totalTextLength - this.currentChar);
/*  259 */       System.arraycopy(this.indexChars, this.currentChar, this.storedIndexChars, this.currentChar, this.totalTextLength - this.currentChar);
/*      */     }
/*      */   }
/*      */   
/*      */   public void restore() {
/*  264 */     this.runDirection = this.storedRunDirection;
/*  265 */     this.totalTextLength = this.storedTotalTextLength;
/*  266 */     this.indexChunk = this.storedIndexChunk;
/*  267 */     this.indexChunkChar = this.storedIndexChunkChar;
/*  268 */     this.currentChar = this.storedCurrentChar;
/*  269 */     if (!this.shortStore)
/*      */     {
/*  271 */       System.arraycopy(this.storedText, 0, this.text, 0, this.totalTextLength);
/*  272 */       System.arraycopy(this.storedDetailChunks, 0, this.detailChunks, 0, this.totalTextLength);
/*      */     }
/*  274 */     if ((this.runDirection == 2) || (this.runDirection == 3)) {
/*  275 */       System.arraycopy(this.storedOrderLevels, this.currentChar, this.orderLevels, this.currentChar, this.totalTextLength - this.currentChar);
/*  276 */       System.arraycopy(this.storedIndexChars, this.currentChar, this.indexChars, this.currentChar, this.totalTextLength - this.currentChar);
/*      */     }
/*      */   }
/*      */   
/*      */   public void mirrorGlyphs() {
/*  281 */     for (int k = 0; k < this.totalTextLength; k++) {
/*  282 */       if ((this.orderLevels[k] & 0x1) == 1) {
/*  283 */         int mirror = mirrorChars.get(this.text[k]);
/*  284 */         if (mirror != 0)
/*  285 */           this.text[k] = ((char)mirror);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void doArabicShapping() {
/*  291 */     int src = 0;
/*  292 */     int dest = 0;
/*      */     for (;;) {
/*  294 */       if (src < this.totalTextLength) {
/*  295 */         char c = this.text[src];
/*  296 */         if ((c < '؀') || (c > 'ۿ'))
/*      */         {
/*  298 */           if (src != dest) {
/*  299 */             this.text[dest] = this.text[src];
/*  300 */             this.detailChunks[dest] = this.detailChunks[src];
/*  301 */             this.orderLevels[dest] = this.orderLevels[src];
/*      */           }
/*  303 */           src++;
/*  304 */           dest++;
/*  305 */           continue; } }
/*  306 */       if (src >= this.totalTextLength) {
/*  307 */         this.totalTextLength = dest;
/*  308 */         return;
/*      */       }
/*  310 */       int startArabicIdx = src;
/*  311 */       src++;
/*  312 */       while (src < this.totalTextLength) {
/*  313 */         char c = this.text[src];
/*  314 */         if ((c < '؀') || (c > 'ۿ'))
/*      */           break;
/*  316 */         src++;
/*      */       }
/*  318 */       int arabicWordSize = src - startArabicIdx;
/*  319 */       int size = ArabicLigaturizer.arabic_shape(this.text, startArabicIdx, arabicWordSize, this.text, dest, arabicWordSize, this.arabicOptions);
/*  320 */       if (startArabicIdx != dest) {
/*  321 */         for (int k = 0; k < size; k++) {
/*  322 */           this.detailChunks[dest] = this.detailChunks[startArabicIdx];
/*  323 */           this.orderLevels[(dest++)] = this.orderLevels[(startArabicIdx++)];
/*      */         }
/*      */         
/*      */       } else
/*  327 */         dest += size;
/*      */     }
/*      */   }
/*      */   
/*      */   public PdfLine processLine(float leftX, float width, int alignment, int runDirection, int arabicOptions, float minY, float yLine, float descender) {
/*  332 */     this.isWordSplit = false;
/*  333 */     this.arabicOptions = arabicOptions;
/*  334 */     save();
/*  335 */     boolean isRTL = runDirection == 3;
/*  336 */     if (this.currentChar >= this.totalTextLength) {
/*  337 */       boolean hasText = getParagraph(runDirection);
/*  338 */       if (!hasText)
/*  339 */         return null;
/*  340 */       if (this.totalTextLength == 0) {
/*  341 */         ArrayList<PdfChunk> ar = new ArrayList();
/*  342 */         PdfChunk ck = new PdfChunk("", this.detailChunks[0]);
/*  343 */         ar.add(ck);
/*  344 */         return new PdfLine(0.0F, 0.0F, width, alignment, true, ar, isRTL);
/*      */       }
/*      */     }
/*  347 */     float originalWidth = width;
/*  348 */     int lastSplit = -1;
/*  349 */     if (this.currentChar != 0) {
/*  350 */       this.currentChar = trimLeftEx(this.currentChar, this.totalTextLength - 1);
/*      */     }
/*  352 */     int oldCurrentChar = this.currentChar;
/*  353 */     int uniC = 0;
/*  354 */     PdfChunk ck = null;
/*  355 */     float charWidth = 0.0F;
/*  356 */     PdfChunk lastValidChunk = null;
/*  357 */     TabStop tabStop = null;
/*  358 */     float tabStopAnchorPosition = NaN.0F;
/*  359 */     float tabPosition = NaN.0F;
/*  360 */     boolean surrogate = false;
/*  361 */     for (; this.currentChar < this.totalTextLength; this.currentChar += 1) {
/*  362 */       ck = this.detailChunks[this.currentChar];
/*  363 */       if ((ck.isImage()) && (minY < yLine)) {
/*  364 */         Image img = ck.getImage();
/*  365 */         if ((img.isScaleToFitHeight()) && (yLine + 2.0F * descender - img.getScaledHeight() - ck.getImageOffsetY() - img.getSpacingBefore() < minY)) {
/*  366 */           float scalePercent = (yLine + 2.0F * descender - ck.getImageOffsetY() - img.getSpacingBefore() - minY) / img.getScaledHeight();
/*  367 */           ck.setImageScalePercentage(scalePercent);
/*      */         }
/*      */       }
/*  370 */       surrogate = Utilities.isSurrogatePair(this.text, this.currentChar);
/*  371 */       if (surrogate) {
/*  372 */         uniC = ck.getUnicodeEquivalent(Utilities.convertToUtf32(this.text, this.currentChar));
/*      */       } else
/*  374 */         uniC = ck.getUnicodeEquivalent(this.text[this.currentChar]);
/*  375 */       if (!PdfChunk.noPrint(uniC))
/*      */       {
/*  377 */         if (surrogate) {
/*  378 */           charWidth = ck.getCharWidth(uniC);
/*      */         }
/*  380 */         else if (ck.isImage()) {
/*  381 */           charWidth = ck.getImageWidth();
/*      */         } else {
/*  383 */           charWidth = ck.getCharWidth(this.text[this.currentChar]);
/*      */         }
/*      */         
/*  386 */         if (width - charWidth < 0.0F)
/*      */         {
/*      */ 
/*  389 */           if ((lastValidChunk == null) && (ck.isImage())) {
/*  390 */             Image img = ck.getImage();
/*  391 */             if (img.isScaleToFitLineWhenOverflow())
/*      */             {
/*      */ 
/*  394 */               float scalePercent = width / img.getWidth();
/*  395 */               ck.setImageScalePercentage(scalePercent);
/*  396 */               charWidth = width;
/*      */             }
/*      */           }
/*      */         }
/*  400 */         if (ck.isTab()) {
/*  401 */           if (ck.isAttribute("TABSETTINGS")) {
/*  402 */             lastSplit = this.currentChar;
/*  403 */             if (tabStop != null) {
/*  404 */               float tabStopPosition = tabStop.getPosition(tabPosition, originalWidth - width, tabStopAnchorPosition);
/*  405 */               width = originalWidth - (tabStopPosition + (originalWidth - width - tabPosition));
/*  406 */               if (width < 0.0F) {
/*  407 */                 tabStopPosition += width;
/*  408 */                 width = 0.0F;
/*      */               }
/*  410 */               tabStop.setPosition(tabStopPosition);
/*      */             }
/*      */             
/*  413 */             tabStop = PdfChunk.getTabStop(ck, originalWidth - width);
/*  414 */             if (tabStop.getPosition() > originalWidth) {
/*  415 */               tabStop = null;
/*  416 */               break;
/*      */             }
/*  418 */             ck.setTabStop(tabStop);
/*  419 */             if ((!isRTL) && (tabStop.getAlignment() == TabStop.Alignment.LEFT)) {
/*  420 */               width = originalWidth - tabStop.getPosition();
/*  421 */               tabStop = null;
/*  422 */               tabPosition = NaN.0F;
/*  423 */               tabStopAnchorPosition = NaN.0F;
/*      */             } else {
/*  425 */               tabPosition = originalWidth - width;
/*  426 */               tabStopAnchorPosition = NaN.0F;
/*      */             }
/*      */           } else {
/*  429 */             Object[] tab = (Object[])ck.getAttribute("TAB");
/*      */             
/*  431 */             float tabStopPosition = ((Float)tab[1]).floatValue();
/*  432 */             boolean newLine = ((Boolean)tab[2]).booleanValue();
/*  433 */             if ((newLine) && (tabStopPosition < originalWidth - width)) {
/*  434 */               return new PdfLine(0.0F, originalWidth, width, alignment, true, createArrayOfPdfChunks(oldCurrentChar, this.currentChar - 1), isRTL);
/*      */             }
/*  436 */             this.detailChunks[this.currentChar].adjustLeft(leftX);
/*  437 */             width = originalWidth - tabStopPosition;
/*      */           }
/*      */         }
/*  440 */         else if (ck.isSeparator()) {
/*  441 */           Object[] sep = (Object[])ck.getAttribute("SEPARATOR");
/*  442 */           DrawInterface di = (DrawInterface)sep[0];
/*  443 */           Boolean vertical = (Boolean)sep[1];
/*  444 */           if ((vertical.booleanValue()) && ((di instanceof LineSeparator))) {
/*  445 */             float separatorWidth = originalWidth * ((LineSeparator)di).getPercentage() / 100.0F;
/*  446 */             width -= separatorWidth;
/*  447 */             if (width < 0.0F) {
/*  448 */               width = 0.0F;
/*      */             }
/*      */           }
/*      */         } else {
/*  452 */           boolean splitChar = ck.isExtSplitCharacter(oldCurrentChar, this.currentChar, this.totalTextLength, this.text, this.detailChunks);
/*  453 */           if ((splitChar) && (Character.isWhitespace((char)uniC)))
/*  454 */             lastSplit = this.currentChar;
/*  455 */           if (width - charWidth < 0.0F)
/*      */             break;
/*  457 */           if ((tabStop != null) && (tabStop.getAlignment() == TabStop.Alignment.ANCHOR) && (Float.isNaN(tabStopAnchorPosition)) && (tabStop.getAnchorChar() == (char)uniC)) {
/*  458 */             tabStopAnchorPosition = originalWidth - width;
/*      */           }
/*  460 */           width -= charWidth;
/*  461 */           if (splitChar)
/*  462 */             lastSplit = this.currentChar;
/*      */         }
/*  464 */         lastValidChunk = ck;
/*  465 */         if (surrogate)
/*  466 */           this.currentChar += 1;
/*      */       } }
/*  468 */     if (lastValidChunk == null)
/*      */     {
/*  470 */       this.currentChar += 1;
/*  471 */       if (surrogate)
/*  472 */         this.currentChar += 1;
/*  473 */       return new PdfLine(0.0F, originalWidth, 0.0F, alignment, false, createArrayOfPdfChunks(this.currentChar - 1, this.currentChar - 1), isRTL);
/*      */     }
/*      */     
/*  476 */     if (tabStop != null) {
/*  477 */       float tabStopPosition = tabStop.getPosition(tabPosition, originalWidth - width, tabStopAnchorPosition);
/*  478 */       width -= tabStopPosition - tabPosition;
/*  479 */       if (width < 0.0F) {
/*  480 */         tabStopPosition += width;
/*  481 */         width = 0.0F;
/*      */       }
/*  483 */       if (!isRTL) {
/*  484 */         tabStop.setPosition(tabStopPosition);
/*      */       } else {
/*  486 */         tabStop.setPosition(originalWidth - width - tabPosition);
/*      */       }
/*      */     }
/*  489 */     if (this.currentChar >= this.totalTextLength)
/*      */     {
/*  491 */       return new PdfLine(0.0F, originalWidth, width, alignment, true, createArrayOfPdfChunks(oldCurrentChar, this.totalTextLength - 1), isRTL);
/*      */     }
/*  493 */     int newCurrentChar = trimRightEx(oldCurrentChar, this.currentChar - 1);
/*  494 */     if (newCurrentChar < oldCurrentChar)
/*      */     {
/*  496 */       return new PdfLine(0.0F, originalWidth, width, alignment, false, createArrayOfPdfChunks(oldCurrentChar, this.currentChar - 1), isRTL);
/*      */     }
/*  498 */     if (newCurrentChar == this.currentChar - 1) {
/*  499 */       HyphenationEvent he = (HyphenationEvent)lastValidChunk.getAttribute("HYPHENATION");
/*  500 */       if (he != null) {
/*  501 */         int[] word = getWord(oldCurrentChar, newCurrentChar);
/*  502 */         if (word != null) {
/*  503 */           float testWidth = width + getWidth(word[0], this.currentChar - 1);
/*  504 */           String pre = he.getHyphenatedWordPre(new String(this.text, word[0], word[1] - word[0]), lastValidChunk.font().getFont(), lastValidChunk.font().size(), testWidth);
/*  505 */           String post = he.getHyphenatedWordPost();
/*  506 */           if (pre.length() > 0) {
/*  507 */             PdfChunk extra = new PdfChunk(pre, lastValidChunk);
/*  508 */             this.currentChar = (word[1] - post.length());
/*  509 */             return new PdfLine(0.0F, originalWidth, testWidth - lastValidChunk.width(pre), alignment, false, createArrayOfPdfChunks(oldCurrentChar, word[0] - 1, extra), isRTL);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  514 */     if (lastSplit == -1)
/*  515 */       this.isWordSplit = true;
/*  516 */     if ((lastSplit == -1) || (lastSplit >= newCurrentChar))
/*      */     {
/*  518 */       return new PdfLine(0.0F, originalWidth, width + getWidth(newCurrentChar + 1, this.currentChar - 1, originalWidth), alignment, false, createArrayOfPdfChunks(oldCurrentChar, newCurrentChar), isRTL);
/*      */     }
/*      */     
/*  521 */     this.currentChar = (lastSplit + 1);
/*  522 */     newCurrentChar = trimRightEx(oldCurrentChar, lastSplit);
/*  523 */     if (newCurrentChar < oldCurrentChar)
/*      */     {
/*  525 */       newCurrentChar = this.currentChar - 1;
/*      */     }
/*  527 */     return new PdfLine(0.0F, originalWidth, originalWidth - getWidth(oldCurrentChar, newCurrentChar, originalWidth), alignment, false, createArrayOfPdfChunks(oldCurrentChar, newCurrentChar), isRTL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWordSplit()
/*      */   {
/*  535 */     return this.isWordSplit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWidth(int startIdx, int lastIdx)
/*      */   {
/*  544 */     return getWidth(startIdx, lastIdx, 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWidth(int startIdx, int lastIdx, float originalWidth)
/*      */   {
/*  554 */     char c = '\000';
/*  555 */     PdfChunk ck = null;
/*  556 */     float width = 0.0F;
/*  557 */     TabStop tabStop = null;
/*  558 */     float tabStopAnchorPosition = NaN.0F;
/*  559 */     float tabPosition = NaN.0F;
/*  560 */     for (; startIdx <= lastIdx; startIdx++) {
/*  561 */       boolean surrogate = Utilities.isSurrogatePair(this.text, startIdx);
/*  562 */       if (this.detailChunks[startIdx].isTab())
/*      */       {
/*  564 */         if (this.detailChunks[startIdx].isAttribute("TABSETTINGS")) {
/*  565 */           if (tabStop != null) {
/*  566 */             float tabStopPosition = tabStop.getPosition(tabPosition, width, tabStopAnchorPosition);
/*  567 */             width = tabStopPosition + (width - tabPosition);
/*  568 */             tabStop.setPosition(tabStopPosition);
/*      */           }
/*  570 */           tabStop = this.detailChunks[startIdx].getTabStop();
/*  571 */           if (tabStop == null) {
/*  572 */             tabStop = PdfChunk.getTabStop(this.detailChunks[startIdx], width);
/*  573 */             tabPosition = width;
/*  574 */             tabStopAnchorPosition = NaN.0F; continue;
/*      */           }
/*  576 */           if (this.runDirection == 3) {
/*  577 */             width = originalWidth - tabStop.getPosition();
/*      */           } else {
/*  579 */             width = tabStop.getPosition();
/*      */           }
/*  581 */           tabStop = null;
/*  582 */           tabPosition = NaN.0F;
/*  583 */           tabStopAnchorPosition = NaN.0F; continue;
/*      */         } }
/*  585 */       if (surrogate) {
/*  586 */         width += this.detailChunks[startIdx].getCharWidth(Utilities.convertToUtf32(this.text, startIdx));
/*  587 */         startIdx++;
/*      */       }
/*      */       else {
/*  590 */         c = this.text[startIdx];
/*  591 */         ck = this.detailChunks[startIdx];
/*  592 */         if (!PdfChunk.noPrint(ck.getUnicodeEquivalent(c)))
/*      */         {
/*  594 */           if ((tabStop != null) && (tabStop.getAlignment() != TabStop.Alignment.ANCHOR) && (Float.isNaN(tabStopAnchorPosition)) && (tabStop.getAnchorChar() == (char)ck.getUnicodeEquivalent(c))) {
/*  595 */             tabStopAnchorPosition = width;
/*      */           }
/*  597 */           width += this.detailChunks[startIdx].getCharWidth(c);
/*      */         }
/*      */       } }
/*  600 */     if (tabStop != null) {
/*  601 */       float tabStopPosition = tabStop.getPosition(tabPosition, width, tabStopAnchorPosition);
/*  602 */       width = tabStopPosition + (width - tabPosition);
/*  603 */       tabStop.setPosition(tabStopPosition);
/*      */     }
/*  605 */     return width;
/*      */   }
/*      */   
/*      */   public ArrayList<PdfChunk> createArrayOfPdfChunks(int startIdx, int endIdx) {
/*  609 */     return createArrayOfPdfChunks(startIdx, endIdx, null);
/*      */   }
/*      */   
/*      */   public ArrayList<PdfChunk> createArrayOfPdfChunks(int startIdx, int endIdx, PdfChunk extraPdfChunk) {
/*  613 */     boolean bidi = (this.runDirection == 2) || (this.runDirection == 3);
/*  614 */     if (bidi) {
/*  615 */       reorder(startIdx, endIdx);
/*      */     }
/*  617 */     ArrayList<PdfChunk> ar = new ArrayList();
/*  618 */     PdfChunk refCk = this.detailChunks[startIdx];
/*  619 */     PdfChunk ck = null;
/*  620 */     StringBuffer buf = new StringBuffer();
/*      */     
/*  622 */     int idx = 0;
/*  623 */     for (; startIdx <= endIdx; startIdx++) {
/*  624 */       idx = bidi ? this.indexChars[startIdx] : startIdx;
/*  625 */       char c = this.text[idx];
/*  626 */       ck = this.detailChunks[idx];
/*  627 */       if (!PdfChunk.noPrint(ck.getUnicodeEquivalent(c)))
/*      */       {
/*  629 */         if ((ck.isImage()) || (ck.isSeparator()) || (ck.isTab())) {
/*  630 */           if (buf.length() > 0) {
/*  631 */             ar.add(new PdfChunk(buf.toString(), refCk));
/*  632 */             buf = new StringBuffer();
/*      */           }
/*  634 */           ar.add(ck);
/*      */         }
/*  636 */         else if (ck == refCk) {
/*  637 */           buf.append(c);
/*      */         }
/*      */         else {
/*  640 */           if (buf.length() > 0) {
/*  641 */             ar.add(new PdfChunk(buf.toString(), refCk));
/*  642 */             buf = new StringBuffer();
/*      */           }
/*  644 */           if ((!ck.isImage()) && (!ck.isSeparator()) && (!ck.isTab()))
/*  645 */             buf.append(c);
/*  646 */           refCk = ck;
/*      */         } }
/*      */     }
/*  649 */     if (buf.length() > 0) {
/*  650 */       ar.add(new PdfChunk(buf.toString(), refCk));
/*      */     }
/*  652 */     if (extraPdfChunk != null)
/*  653 */       ar.add(extraPdfChunk);
/*  654 */     return ar;
/*      */   }
/*      */   
/*      */   public int[] getWord(int startIdx, int idx) {
/*  658 */     int last = idx;
/*  659 */     int first = idx;
/*  661 */     for (; 
/*  661 */         last < this.totalTextLength; last++) {
/*  662 */       if ((!Character.isLetter(this.text[last])) && (!Character.isDigit(this.text[last])))
/*      */         break;
/*      */     }
/*  665 */     if (last == idx) {
/*  666 */       return null;
/*      */     }
/*  668 */     for (; first >= startIdx; first--) {
/*  669 */       if ((!Character.isLetter(this.text[first])) && (!Character.isDigit(this.text[first])))
/*      */         break;
/*      */     }
/*  672 */     first++;
/*  673 */     return new int[] { first, last };
/*      */   }
/*      */   
/*      */   public int trimRight(int startIdx, int endIdx) {
/*  677 */     for (int idx = endIdx; 
/*      */         
/*  679 */         idx >= startIdx; idx--) {
/*  680 */       char c = (char)this.detailChunks[idx].getUnicodeEquivalent(this.text[idx]);
/*  681 */       if (!isWS(c))
/*      */         break;
/*      */     }
/*  684 */     return idx;
/*      */   }
/*      */   
/*      */   public int trimLeft(int startIdx, int endIdx) {
/*  688 */     for (int idx = startIdx; 
/*      */         
/*  690 */         idx <= endIdx; idx++) {
/*  691 */       char c = (char)this.detailChunks[idx].getUnicodeEquivalent(this.text[idx]);
/*  692 */       if (!isWS(c))
/*      */         break;
/*      */     }
/*  695 */     return idx;
/*      */   }
/*      */   
/*      */   public int trimRightEx(int startIdx, int endIdx) {
/*  699 */     int idx = endIdx;
/*  700 */     char c = '\000';
/*  701 */     for (; idx >= startIdx; idx--) {
/*  702 */       c = (char)this.detailChunks[idx].getUnicodeEquivalent(this.text[idx]);
/*  703 */       if ((!isWS(c)) && (!PdfChunk.noPrint(c))) {
/*  704 */         if (!this.detailChunks[idx].isTab())
/*      */           break;
/*  706 */         if (!this.detailChunks[idx].isAttribute("TABSETTINGS")) break;
/*  707 */         Object[] tab = (Object[])this.detailChunks[idx].getAttribute("TAB");
/*  708 */         boolean isWhitespace = ((Boolean)tab[1]).booleanValue();
/*  709 */         if (!isWhitespace) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  715 */     return idx;
/*      */   }
/*      */   
/*      */   public int trimLeftEx(int startIdx, int endIdx) {
/*  719 */     int idx = startIdx;
/*  720 */     char c = '\000';
/*  721 */     for (; idx <= endIdx; idx++) {
/*  722 */       c = (char)this.detailChunks[idx].getUnicodeEquivalent(this.text[idx]);
/*  723 */       if ((!isWS(c)) && (!PdfChunk.noPrint(c))) {
/*  724 */         if (!this.detailChunks[idx].isTab())
/*      */           break;
/*  726 */         if (!this.detailChunks[idx].isAttribute("TABSETTINGS")) break;
/*  727 */         Object[] tab = (Object[])this.detailChunks[idx].getAttribute("TAB");
/*  728 */         boolean isWhitespace = ((Boolean)tab[1]).booleanValue();
/*  729 */         if (!isWhitespace) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  735 */     return idx;
/*      */   }
/*      */   
/*      */   public void reorder(int start, int end) {
/*  739 */     byte maxLevel = this.orderLevels[start];
/*  740 */     byte minLevel = maxLevel;
/*  741 */     byte onlyOddLevels = maxLevel;
/*  742 */     byte onlyEvenLevels = maxLevel;
/*  743 */     for (int k = start + 1; k <= end; k++) {
/*  744 */       byte b = this.orderLevels[k];
/*  745 */       if (b > maxLevel) {
/*  746 */         maxLevel = b;
/*  747 */       } else if (b < minLevel)
/*  748 */         minLevel = b;
/*  749 */       onlyOddLevels = (byte)(onlyOddLevels & b);
/*  750 */       onlyEvenLevels = (byte)(onlyEvenLevels | b);
/*      */     }
/*  752 */     if ((onlyEvenLevels & 0x1) == 0)
/*  753 */       return;
/*  754 */     if ((onlyOddLevels & 0x1) == 1) {
/*  755 */       flip(start, end + 1);
/*  756 */       return;
/*      */     }
/*  758 */     minLevel = (byte)(minLevel | 0x1);
/*  759 */     for (; maxLevel >= minLevel; maxLevel = (byte)(maxLevel - 1)) {
/*  760 */       int pstart = start;
/*      */       for (;;) {
/*  762 */         if (pstart <= end) {
/*  763 */           if (this.orderLevels[pstart] < maxLevel)
/*      */           {
/*  762 */             pstart++; continue;
/*      */           }
/*      */         }
/*      */         
/*  766 */         if (pstart > end)
/*      */           break;
/*  768 */         for (int pend = pstart + 1; 
/*  769 */             pend <= end; pend++) {
/*  770 */           if (this.orderLevels[pend] < maxLevel)
/*      */             break;
/*      */         }
/*  773 */         flip(pstart, pend);
/*  774 */         pstart = pend + 1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void flip(int start, int end) {
/*  780 */     int mid = (start + end) / 2;
/*  781 */     end--;
/*  782 */     for (; start < mid; end--) {
/*  783 */       int temp = this.indexChars[start];
/*  784 */       this.indexChars[start] = this.indexChars[end];
/*  785 */       this.indexChars[end] = temp;start++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static boolean isWS(char c)
/*      */   {
/*  790 */     return c <= ' ';
/*      */   }
/*      */   
/*      */   static {
/*  794 */     mirrorChars.put(40, 41);
/*  795 */     mirrorChars.put(41, 40);
/*  796 */     mirrorChars.put(60, 62);
/*  797 */     mirrorChars.put(62, 60);
/*  798 */     mirrorChars.put(91, 93);
/*  799 */     mirrorChars.put(93, 91);
/*  800 */     mirrorChars.put(123, 125);
/*  801 */     mirrorChars.put(125, 123);
/*  802 */     mirrorChars.put(171, 187);
/*  803 */     mirrorChars.put(187, 171);
/*  804 */     mirrorChars.put(8249, 8250);
/*  805 */     mirrorChars.put(8250, 8249);
/*  806 */     mirrorChars.put(8261, 8262);
/*  807 */     mirrorChars.put(8262, 8261);
/*  808 */     mirrorChars.put(8317, 8318);
/*  809 */     mirrorChars.put(8318, 8317);
/*  810 */     mirrorChars.put(8333, 8334);
/*  811 */     mirrorChars.put(8334, 8333);
/*  812 */     mirrorChars.put(8712, 8715);
/*  813 */     mirrorChars.put(8713, 8716);
/*  814 */     mirrorChars.put(8714, 8717);
/*  815 */     mirrorChars.put(8715, 8712);
/*  816 */     mirrorChars.put(8716, 8713);
/*  817 */     mirrorChars.put(8717, 8714);
/*  818 */     mirrorChars.put(8725, 10741);
/*  819 */     mirrorChars.put(8764, 8765);
/*  820 */     mirrorChars.put(8765, 8764);
/*  821 */     mirrorChars.put(8771, 8909);
/*  822 */     mirrorChars.put(8786, 8787);
/*  823 */     mirrorChars.put(8787, 8786);
/*  824 */     mirrorChars.put(8788, 8789);
/*  825 */     mirrorChars.put(8789, 8788);
/*  826 */     mirrorChars.put(8804, 8805);
/*  827 */     mirrorChars.put(8805, 8804);
/*  828 */     mirrorChars.put(8806, 8807);
/*  829 */     mirrorChars.put(8807, 8806);
/*  830 */     mirrorChars.put(8808, 8809);
/*  831 */     mirrorChars.put(8809, 8808);
/*  832 */     mirrorChars.put(8810, 8811);
/*  833 */     mirrorChars.put(8811, 8810);
/*  834 */     mirrorChars.put(8814, 8815);
/*  835 */     mirrorChars.put(8815, 8814);
/*  836 */     mirrorChars.put(8816, 8817);
/*  837 */     mirrorChars.put(8817, 8816);
/*  838 */     mirrorChars.put(8818, 8819);
/*  839 */     mirrorChars.put(8819, 8818);
/*  840 */     mirrorChars.put(8820, 8821);
/*  841 */     mirrorChars.put(8821, 8820);
/*  842 */     mirrorChars.put(8822, 8823);
/*  843 */     mirrorChars.put(8823, 8822);
/*  844 */     mirrorChars.put(8824, 8825);
/*  845 */     mirrorChars.put(8825, 8824);
/*  846 */     mirrorChars.put(8826, 8827);
/*  847 */     mirrorChars.put(8827, 8826);
/*  848 */     mirrorChars.put(8828, 8829);
/*  849 */     mirrorChars.put(8829, 8828);
/*  850 */     mirrorChars.put(8830, 8831);
/*  851 */     mirrorChars.put(8831, 8830);
/*  852 */     mirrorChars.put(8832, 8833);
/*  853 */     mirrorChars.put(8833, 8832);
/*  854 */     mirrorChars.put(8834, 8835);
/*  855 */     mirrorChars.put(8835, 8834);
/*  856 */     mirrorChars.put(8836, 8837);
/*  857 */     mirrorChars.put(8837, 8836);
/*  858 */     mirrorChars.put(8838, 8839);
/*  859 */     mirrorChars.put(8839, 8838);
/*  860 */     mirrorChars.put(8840, 8841);
/*  861 */     mirrorChars.put(8841, 8840);
/*  862 */     mirrorChars.put(8842, 8843);
/*  863 */     mirrorChars.put(8843, 8842);
/*  864 */     mirrorChars.put(8847, 8848);
/*  865 */     mirrorChars.put(8848, 8847);
/*  866 */     mirrorChars.put(8849, 8850);
/*  867 */     mirrorChars.put(8850, 8849);
/*  868 */     mirrorChars.put(8856, 10680);
/*  869 */     mirrorChars.put(8866, 8867);
/*  870 */     mirrorChars.put(8867, 8866);
/*  871 */     mirrorChars.put(8870, 10974);
/*  872 */     mirrorChars.put(8872, 10980);
/*  873 */     mirrorChars.put(8873, 10979);
/*  874 */     mirrorChars.put(8875, 10981);
/*  875 */     mirrorChars.put(8880, 8881);
/*  876 */     mirrorChars.put(8881, 8880);
/*  877 */     mirrorChars.put(8882, 8883);
/*  878 */     mirrorChars.put(8883, 8882);
/*  879 */     mirrorChars.put(8884, 8885);
/*  880 */     mirrorChars.put(8885, 8884);
/*  881 */     mirrorChars.put(8886, 8887);
/*  882 */     mirrorChars.put(8887, 8886);
/*  883 */     mirrorChars.put(8905, 8906);
/*  884 */     mirrorChars.put(8906, 8905);
/*  885 */     mirrorChars.put(8907, 8908);
/*  886 */     mirrorChars.put(8908, 8907);
/*  887 */     mirrorChars.put(8909, 8771);
/*  888 */     mirrorChars.put(8912, 8913);
/*  889 */     mirrorChars.put(8913, 8912);
/*  890 */     mirrorChars.put(8918, 8919);
/*  891 */     mirrorChars.put(8919, 8918);
/*  892 */     mirrorChars.put(8920, 8921);
/*  893 */     mirrorChars.put(8921, 8920);
/*  894 */     mirrorChars.put(8922, 8923);
/*  895 */     mirrorChars.put(8923, 8922);
/*  896 */     mirrorChars.put(8924, 8925);
/*  897 */     mirrorChars.put(8925, 8924);
/*  898 */     mirrorChars.put(8926, 8927);
/*  899 */     mirrorChars.put(8927, 8926);
/*  900 */     mirrorChars.put(8928, 8929);
/*  901 */     mirrorChars.put(8929, 8928);
/*  902 */     mirrorChars.put(8930, 8931);
/*  903 */     mirrorChars.put(8931, 8930);
/*  904 */     mirrorChars.put(8932, 8933);
/*  905 */     mirrorChars.put(8933, 8932);
/*  906 */     mirrorChars.put(8934, 8935);
/*  907 */     mirrorChars.put(8935, 8934);
/*  908 */     mirrorChars.put(8936, 8937);
/*  909 */     mirrorChars.put(8937, 8936);
/*  910 */     mirrorChars.put(8938, 8939);
/*  911 */     mirrorChars.put(8939, 8938);
/*  912 */     mirrorChars.put(8940, 8941);
/*  913 */     mirrorChars.put(8941, 8940);
/*  914 */     mirrorChars.put(8944, 8945);
/*  915 */     mirrorChars.put(8945, 8944);
/*  916 */     mirrorChars.put(8946, 8954);
/*  917 */     mirrorChars.put(8947, 8955);
/*  918 */     mirrorChars.put(8948, 8956);
/*  919 */     mirrorChars.put(8950, 8957);
/*  920 */     mirrorChars.put(8951, 8958);
/*  921 */     mirrorChars.put(8954, 8946);
/*  922 */     mirrorChars.put(8955, 8947);
/*  923 */     mirrorChars.put(8956, 8948);
/*  924 */     mirrorChars.put(8957, 8950);
/*  925 */     mirrorChars.put(8958, 8951);
/*  926 */     mirrorChars.put(8968, 8969);
/*  927 */     mirrorChars.put(8969, 8968);
/*  928 */     mirrorChars.put(8970, 8971);
/*  929 */     mirrorChars.put(8971, 8970);
/*  930 */     mirrorChars.put(9001, 9002);
/*  931 */     mirrorChars.put(9002, 9001);
/*  932 */     mirrorChars.put(10088, 10089);
/*  933 */     mirrorChars.put(10089, 10088);
/*  934 */     mirrorChars.put(10090, 10091);
/*  935 */     mirrorChars.put(10091, 10090);
/*  936 */     mirrorChars.put(10092, 10093);
/*  937 */     mirrorChars.put(10093, 10092);
/*  938 */     mirrorChars.put(10094, 10095);
/*  939 */     mirrorChars.put(10095, 10094);
/*  940 */     mirrorChars.put(10096, 10097);
/*  941 */     mirrorChars.put(10097, 10096);
/*  942 */     mirrorChars.put(10098, 10099);
/*  943 */     mirrorChars.put(10099, 10098);
/*  944 */     mirrorChars.put(10100, 10101);
/*  945 */     mirrorChars.put(10101, 10100);
/*  946 */     mirrorChars.put(10197, 10198);
/*  947 */     mirrorChars.put(10198, 10197);
/*  948 */     mirrorChars.put(10205, 10206);
/*  949 */     mirrorChars.put(10206, 10205);
/*  950 */     mirrorChars.put(10210, 10211);
/*  951 */     mirrorChars.put(10211, 10210);
/*  952 */     mirrorChars.put(10212, 10213);
/*  953 */     mirrorChars.put(10213, 10212);
/*  954 */     mirrorChars.put(10214, 10215);
/*  955 */     mirrorChars.put(10215, 10214);
/*  956 */     mirrorChars.put(10216, 10217);
/*  957 */     mirrorChars.put(10217, 10216);
/*  958 */     mirrorChars.put(10218, 10219);
/*  959 */     mirrorChars.put(10219, 10218);
/*  960 */     mirrorChars.put(10627, 10628);
/*  961 */     mirrorChars.put(10628, 10627);
/*  962 */     mirrorChars.put(10629, 10630);
/*  963 */     mirrorChars.put(10630, 10629);
/*  964 */     mirrorChars.put(10631, 10632);
/*  965 */     mirrorChars.put(10632, 10631);
/*  966 */     mirrorChars.put(10633, 10634);
/*  967 */     mirrorChars.put(10634, 10633);
/*  968 */     mirrorChars.put(10635, 10636);
/*  969 */     mirrorChars.put(10636, 10635);
/*  970 */     mirrorChars.put(10637, 10640);
/*  971 */     mirrorChars.put(10638, 10639);
/*  972 */     mirrorChars.put(10639, 10638);
/*  973 */     mirrorChars.put(10640, 10637);
/*  974 */     mirrorChars.put(10641, 10642);
/*  975 */     mirrorChars.put(10642, 10641);
/*  976 */     mirrorChars.put(10643, 10644);
/*  977 */     mirrorChars.put(10644, 10643);
/*  978 */     mirrorChars.put(10645, 10646);
/*  979 */     mirrorChars.put(10646, 10645);
/*  980 */     mirrorChars.put(10647, 10648);
/*  981 */     mirrorChars.put(10648, 10647);
/*  982 */     mirrorChars.put(10680, 8856);
/*  983 */     mirrorChars.put(10688, 10689);
/*  984 */     mirrorChars.put(10689, 10688);
/*  985 */     mirrorChars.put(10692, 10693);
/*  986 */     mirrorChars.put(10693, 10692);
/*  987 */     mirrorChars.put(10703, 10704);
/*  988 */     mirrorChars.put(10704, 10703);
/*  989 */     mirrorChars.put(10705, 10706);
/*  990 */     mirrorChars.put(10706, 10705);
/*  991 */     mirrorChars.put(10708, 10709);
/*  992 */     mirrorChars.put(10709, 10708);
/*  993 */     mirrorChars.put(10712, 10713);
/*  994 */     mirrorChars.put(10713, 10712);
/*  995 */     mirrorChars.put(10714, 10715);
/*  996 */     mirrorChars.put(10715, 10714);
/*  997 */     mirrorChars.put(10741, 8725);
/*  998 */     mirrorChars.put(10744, 10745);
/*  999 */     mirrorChars.put(10745, 10744);
/* 1000 */     mirrorChars.put(10748, 10749);
/* 1001 */     mirrorChars.put(10749, 10748);
/* 1002 */     mirrorChars.put(10795, 10796);
/* 1003 */     mirrorChars.put(10796, 10795);
/* 1004 */     mirrorChars.put(10797, 10796);
/* 1005 */     mirrorChars.put(10798, 10797);
/* 1006 */     mirrorChars.put(10804, 10805);
/* 1007 */     mirrorChars.put(10805, 10804);
/* 1008 */     mirrorChars.put(10812, 10813);
/* 1009 */     mirrorChars.put(10813, 10812);
/* 1010 */     mirrorChars.put(10852, 10853);
/* 1011 */     mirrorChars.put(10853, 10852);
/* 1012 */     mirrorChars.put(10873, 10874);
/* 1013 */     mirrorChars.put(10874, 10873);
/* 1014 */     mirrorChars.put(10877, 10878);
/* 1015 */     mirrorChars.put(10878, 10877);
/* 1016 */     mirrorChars.put(10879, 10880);
/* 1017 */     mirrorChars.put(10880, 10879);
/* 1018 */     mirrorChars.put(10881, 10882);
/* 1019 */     mirrorChars.put(10882, 10881);
/* 1020 */     mirrorChars.put(10883, 10884);
/* 1021 */     mirrorChars.put(10884, 10883);
/* 1022 */     mirrorChars.put(10891, 10892);
/* 1023 */     mirrorChars.put(10892, 10891);
/* 1024 */     mirrorChars.put(10897, 10898);
/* 1025 */     mirrorChars.put(10898, 10897);
/* 1026 */     mirrorChars.put(10899, 10900);
/* 1027 */     mirrorChars.put(10900, 10899);
/* 1028 */     mirrorChars.put(10901, 10902);
/* 1029 */     mirrorChars.put(10902, 10901);
/* 1030 */     mirrorChars.put(10903, 10904);
/* 1031 */     mirrorChars.put(10904, 10903);
/* 1032 */     mirrorChars.put(10905, 10906);
/* 1033 */     mirrorChars.put(10906, 10905);
/* 1034 */     mirrorChars.put(10907, 10908);
/* 1035 */     mirrorChars.put(10908, 10907);
/* 1036 */     mirrorChars.put(10913, 10914);
/* 1037 */     mirrorChars.put(10914, 10913);
/* 1038 */     mirrorChars.put(10918, 10919);
/* 1039 */     mirrorChars.put(10919, 10918);
/* 1040 */     mirrorChars.put(10920, 10921);
/* 1041 */     mirrorChars.put(10921, 10920);
/* 1042 */     mirrorChars.put(10922, 10923);
/* 1043 */     mirrorChars.put(10923, 10922);
/* 1044 */     mirrorChars.put(10924, 10925);
/* 1045 */     mirrorChars.put(10925, 10924);
/* 1046 */     mirrorChars.put(10927, 10928);
/* 1047 */     mirrorChars.put(10928, 10927);
/* 1048 */     mirrorChars.put(10931, 10932);
/* 1049 */     mirrorChars.put(10932, 10931);
/* 1050 */     mirrorChars.put(10939, 10940);
/* 1051 */     mirrorChars.put(10940, 10939);
/* 1052 */     mirrorChars.put(10941, 10942);
/* 1053 */     mirrorChars.put(10942, 10941);
/* 1054 */     mirrorChars.put(10943, 10944);
/* 1055 */     mirrorChars.put(10944, 10943);
/* 1056 */     mirrorChars.put(10945, 10946);
/* 1057 */     mirrorChars.put(10946, 10945);
/* 1058 */     mirrorChars.put(10947, 10948);
/* 1059 */     mirrorChars.put(10948, 10947);
/* 1060 */     mirrorChars.put(10949, 10950);
/* 1061 */     mirrorChars.put(10950, 10949);
/* 1062 */     mirrorChars.put(10957, 10958);
/* 1063 */     mirrorChars.put(10958, 10957);
/* 1064 */     mirrorChars.put(10959, 10960);
/* 1065 */     mirrorChars.put(10960, 10959);
/* 1066 */     mirrorChars.put(10961, 10962);
/* 1067 */     mirrorChars.put(10962, 10961);
/* 1068 */     mirrorChars.put(10963, 10964);
/* 1069 */     mirrorChars.put(10964, 10963);
/* 1070 */     mirrorChars.put(10965, 10966);
/* 1071 */     mirrorChars.put(10966, 10965);
/* 1072 */     mirrorChars.put(10974, 8870);
/* 1073 */     mirrorChars.put(10979, 8873);
/* 1074 */     mirrorChars.put(10980, 8872);
/* 1075 */     mirrorChars.put(10981, 8875);
/* 1076 */     mirrorChars.put(10988, 10989);
/* 1077 */     mirrorChars.put(10989, 10988);
/* 1078 */     mirrorChars.put(10999, 11000);
/* 1079 */     mirrorChars.put(11000, 10999);
/* 1080 */     mirrorChars.put(11001, 11002);
/* 1081 */     mirrorChars.put(11002, 11001);
/* 1082 */     mirrorChars.put(12296, 12297);
/* 1083 */     mirrorChars.put(12297, 12296);
/* 1084 */     mirrorChars.put(12298, 12299);
/* 1085 */     mirrorChars.put(12299, 12298);
/* 1086 */     mirrorChars.put(12300, 12301);
/* 1087 */     mirrorChars.put(12301, 12300);
/* 1088 */     mirrorChars.put(12302, 12303);
/* 1089 */     mirrorChars.put(12303, 12302);
/* 1090 */     mirrorChars.put(12304, 12305);
/* 1091 */     mirrorChars.put(12305, 12304);
/* 1092 */     mirrorChars.put(12308, 12309);
/* 1093 */     mirrorChars.put(12309, 12308);
/* 1094 */     mirrorChars.put(12310, 12311);
/* 1095 */     mirrorChars.put(12311, 12310);
/* 1096 */     mirrorChars.put(12312, 12313);
/* 1097 */     mirrorChars.put(12313, 12312);
/* 1098 */     mirrorChars.put(12314, 12315);
/* 1099 */     mirrorChars.put(12315, 12314);
/* 1100 */     mirrorChars.put(65288, 65289);
/* 1101 */     mirrorChars.put(65289, 65288);
/* 1102 */     mirrorChars.put(65308, 65310);
/* 1103 */     mirrorChars.put(65310, 65308);
/* 1104 */     mirrorChars.put(65339, 65341);
/* 1105 */     mirrorChars.put(65341, 65339);
/* 1106 */     mirrorChars.put(65371, 65373);
/* 1107 */     mirrorChars.put(65373, 65371);
/* 1108 */     mirrorChars.put(65375, 65376);
/* 1109 */     mirrorChars.put(65376, 65375);
/* 1110 */     mirrorChars.put(65378, 65379);
/* 1111 */     mirrorChars.put(65379, 65378);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String processLTR(String s, int runDirection, int arabicOptions)
/*      */   {
/* 1122 */     BidiLine bidi = new BidiLine();
/* 1123 */     bidi.addChunk(new PdfChunk(new Chunk(s), null));
/* 1124 */     bidi.arabicOptions = arabicOptions;
/* 1125 */     bidi.getParagraph(runDirection);
/* 1126 */     ArrayList<PdfChunk> arr = bidi.createArrayOfPdfChunks(0, bidi.totalTextLength - 1);
/* 1127 */     StringBuilder sb = new StringBuilder();
/* 1128 */     for (PdfChunk ck : arr) {
/* 1129 */       sb.append(ck.toString());
/*      */     }
/* 1131 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public BidiLine() {}
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/BidiLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */