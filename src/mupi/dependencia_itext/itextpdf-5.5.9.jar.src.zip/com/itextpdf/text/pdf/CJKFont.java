/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Utilities;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.io.StreamUtil;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CMapCache;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CMapCidByte;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CMapCidUni;
/*     */ import com.itextpdf.text.pdf.fonts.cmaps.CMapUniCid;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CJKFont
/*     */   extends BaseFont
/*     */ {
/*     */   static final String CJK_ENCODING = "UnicodeBigUnmarked";
/*     */   private static final int FIRST = 0;
/*     */   private static final int BRACKET = 1;
/*     */   private static final int SERIAL = 2;
/*     */   private static final int V1Y = 880;
/*  78 */   static Properties cjkFonts = new Properties();
/*  79 */   static Properties cjkEncodings = new Properties();
/*  80 */   private static final HashMap<String, HashMap<String, Object>> allFonts = new HashMap();
/*  81 */   private static boolean propertiesLoaded = false;
/*     */   
/*     */   public static final String RESOURCE_PATH_CMAP = "com/itextpdf/text/pdf/fonts/cmaps/";
/*     */   
/*  85 */   private static final HashMap<String, Set<String>> registryNames = new HashMap();
/*     */   
/*     */   private CMapCidByte cidByte;
/*     */   
/*     */   private CMapUniCid uniCid;
/*     */   
/*     */   private CMapCidUni cidUni;
/*     */   private String uniMap;
/*     */   private String fontName;
/*  94 */   private String style = "";
/*     */   
/*     */   private String CMap;
/*     */   
/*  98 */   private boolean cidDirect = false;
/*     */   
/*     */   private IntHashtable vMetrics;
/*     */   private IntHashtable hMetrics;
/*     */   private HashMap<String, Object> fontDesc;
/*     */   
/*     */   private static void loadProperties()
/*     */   {
/* 106 */     if (propertiesLoaded)
/* 107 */       return;
/* 108 */     synchronized (allFonts) {
/* 109 */       if (propertiesLoaded)
/* 110 */         return;
/*     */       try {
/* 112 */         loadRegistry();
/* 113 */         for (String font : (Set)registryNames.get("fonts")) {
/* 114 */           allFonts.put(font, readFontProperties(font));
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */       
/* 119 */       propertiesLoaded = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void loadRegistry() throws IOException {
/* 124 */     InputStream is = StreamUtil.getResourceStream("com/itextpdf/text/pdf/fonts/cmaps/cjk_registry.properties");
/* 125 */     Properties p = new Properties();
/* 126 */     p.load(is);
/* 127 */     is.close();
/* 128 */     for (Object key : p.keySet()) {
/* 129 */       String value = p.getProperty((String)key);
/* 130 */       String[] sp = value.split(" ");
/* 131 */       Set<String> hs = new HashSet();
/* 132 */       for (String s : sp) {
/* 133 */         if (s.length() > 0)
/* 134 */           hs.add(s);
/*     */       }
/* 136 */       registryNames.put((String)key, hs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CJKFont(String fontName, String enc, boolean emb)
/*     */     throws DocumentException
/*     */   {
/* 147 */     loadProperties();
/* 148 */     this.fontType = 2;
/* 149 */     String nameBase = getBaseName(fontName);
/* 150 */     if (!isCJKFont(nameBase, enc))
/* 151 */       throw new DocumentException(MessageLocalization.getComposedMessage("font.1.with.2.encoding.is.not.a.cjk.font", new Object[] { fontName, enc }));
/* 152 */     if (nameBase.length() < fontName.length()) {
/* 153 */       this.style = fontName.substring(nameBase.length());
/* 154 */       fontName = nameBase;
/*     */     }
/* 156 */     this.fontName = fontName;
/* 157 */     this.encoding = "UnicodeBigUnmarked";
/* 158 */     this.vertical = enc.endsWith("V");
/* 159 */     this.CMap = enc;
/* 160 */     if ((enc.equals("Identity-H")) || (enc.equals("Identity-V")))
/* 161 */       this.cidDirect = true;
/* 162 */     loadCMaps();
/*     */   }
/*     */   
/*     */   String getUniMap() {
/* 166 */     return this.uniMap;
/*     */   }
/*     */   
/*     */   private void loadCMaps() throws DocumentException {
/*     */     try {
/* 171 */       this.fontDesc = ((HashMap)allFonts.get(this.fontName));
/* 172 */       this.hMetrics = ((IntHashtable)this.fontDesc.get("W"));
/* 173 */       this.vMetrics = ((IntHashtable)this.fontDesc.get("W2"));
/* 174 */       String registry = (String)this.fontDesc.get("Registry");
/* 175 */       this.uniMap = "";
/* 176 */       for (String name : (Set)registryNames.get(registry + "_Uni")) {
/* 177 */         this.uniMap = name;
/* 178 */         if ((name.endsWith("V")) && (this.vertical))
/*     */           break;
/* 180 */         if ((!name.endsWith("V")) && (!this.vertical))
/*     */           break;
/*     */       }
/* 183 */       if (this.cidDirect) {
/* 184 */         this.cidUni = CMapCache.getCachedCMapCidUni(this.uniMap);
/*     */       }
/*     */       else {
/* 187 */         this.uniCid = CMapCache.getCachedCMapUniCid(this.uniMap);
/* 188 */         this.cidByte = CMapCache.getCachedCMapCidByte(this.CMap);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 192 */       throw new DocumentException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String GetCompatibleFont(String enc)
/*     */   {
/* 202 */     loadProperties();
/* 203 */     String registry = null;
/* 204 */     for (Map.Entry<String, Set<String>> e : registryNames.entrySet()) {
/* 205 */       if (((Set)e.getValue()).contains(enc)) {
/* 206 */         registry = (String)e.getKey();
/* 207 */         for (Map.Entry<String, HashMap<String, Object>> e1 : allFonts.entrySet()) {
/* 208 */           if (registry.equals(((HashMap)e1.getValue()).get("Registry")))
/* 209 */             return (String)e1.getKey();
/*     */         }
/*     */       }
/*     */     }
/* 213 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isCJKFont(String fontName, String enc)
/*     */   {
/*     */     
/*     */     
/*     */ 
/* 223 */     if (!registryNames.containsKey("fonts"))
/* 224 */       return false;
/* 225 */     if (!((Set)registryNames.get("fonts")).contains(fontName))
/* 226 */       return false;
/* 227 */     if ((enc.equals("Identity-H")) || (enc.equals("Identity-V")))
/* 228 */       return true;
/* 229 */     String registry = (String)((HashMap)allFonts.get(fontName)).get("Registry");
/* 230 */     Set<String> encodings = (Set)registryNames.get(registry);
/* 231 */     return (encodings != null) && (encodings.contains(enc));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth(int char1)
/*     */   {
/* 241 */     int c = char1;
/* 242 */     if (!this.cidDirect)
/* 243 */       c = this.uniCid.lookup(char1);
/*     */     int v;
/* 245 */     int v; if (this.vertical) {
/* 246 */       v = this.vMetrics.get(c);
/*     */     } else
/* 248 */       v = this.hMetrics.get(c);
/* 249 */     if (v > 0) {
/* 250 */       return v;
/*     */     }
/* 252 */     return 1000;
/*     */   }
/*     */   
/*     */   public int getWidth(String text)
/*     */   {
/* 257 */     int total = 0;
/* 258 */     if (this.cidDirect) {
/* 259 */       for (int k = 0; k < text.length(); k++) {
/* 260 */         total += getWidth(text.charAt(k));
/*     */       }
/*     */       
/*     */     } else {
/* 264 */       for (int k = 0; k < text.length(); k++) {
/*     */         int val;
/* 266 */         if (Utilities.isSurrogatePair(text, k)) {
/* 267 */           int val = Utilities.convertToUtf32(text, k);
/* 268 */           k++;
/*     */         }
/*     */         else {
/* 271 */           val = text.charAt(k);
/*     */         }
/* 273 */         total += getWidth(val);
/*     */       }
/*     */     }
/* 276 */     return total;
/*     */   }
/*     */   
/*     */   int getRawWidth(int c, String name)
/*     */   {
/* 281 */     return 0;
/*     */   }
/*     */   
/*     */   public int getKerning(int char1, int char2)
/*     */   {
/* 286 */     return 0;
/*     */   }
/*     */   
/*     */   private PdfDictionary getFontDescriptor() {
/* 290 */     PdfDictionary dic = new PdfDictionary(PdfName.FONTDESCRIPTOR);
/* 291 */     dic.put(PdfName.ASCENT, new PdfLiteral((String)this.fontDesc.get("Ascent")));
/* 292 */     dic.put(PdfName.CAPHEIGHT, new PdfLiteral((String)this.fontDesc.get("CapHeight")));
/* 293 */     dic.put(PdfName.DESCENT, new PdfLiteral((String)this.fontDesc.get("Descent")));
/* 294 */     dic.put(PdfName.FLAGS, new PdfLiteral((String)this.fontDesc.get("Flags")));
/* 295 */     dic.put(PdfName.FONTBBOX, new PdfLiteral((String)this.fontDesc.get("FontBBox")));
/* 296 */     dic.put(PdfName.FONTNAME, new PdfName(this.fontName + this.style));
/* 297 */     dic.put(PdfName.ITALICANGLE, new PdfLiteral((String)this.fontDesc.get("ItalicAngle")));
/* 298 */     dic.put(PdfName.STEMV, new PdfLiteral((String)this.fontDesc.get("StemV")));
/* 299 */     PdfDictionary pdic = new PdfDictionary();
/* 300 */     pdic.put(PdfName.PANOSE, new PdfString((String)this.fontDesc.get("Panose"), null));
/* 301 */     dic.put(PdfName.STYLE, pdic);
/* 302 */     return dic;
/*     */   }
/*     */   
/*     */   private PdfDictionary getCIDFont(PdfIndirectReference fontDescriptor, IntHashtable cjkTag) {
/* 306 */     PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 307 */     dic.put(PdfName.SUBTYPE, PdfName.CIDFONTTYPE0);
/* 308 */     dic.put(PdfName.BASEFONT, new PdfName(this.fontName + this.style));
/* 309 */     dic.put(PdfName.FONTDESCRIPTOR, fontDescriptor);
/* 310 */     int[] keys = cjkTag.toOrderedKeys();
/* 311 */     String w = convertToHCIDMetrics(keys, this.hMetrics);
/* 312 */     if (w != null)
/* 313 */       dic.put(PdfName.W, new PdfLiteral(w));
/* 314 */     if (this.vertical) {
/* 315 */       w = convertToVCIDMetrics(keys, this.vMetrics, this.hMetrics);
/* 316 */       if (w != null) {
/* 317 */         dic.put(PdfName.W2, new PdfLiteral(w));
/*     */       }
/*     */     } else {
/* 320 */       dic.put(PdfName.DW, new PdfNumber(1000)); }
/* 321 */     PdfDictionary cdic = new PdfDictionary();
/* 322 */     if (this.cidDirect) {
/* 323 */       cdic.put(PdfName.REGISTRY, new PdfString(this.cidUni.getRegistry(), null));
/* 324 */       cdic.put(PdfName.ORDERING, new PdfString(this.cidUni.getOrdering(), null));
/* 325 */       cdic.put(PdfName.SUPPLEMENT, new PdfNumber(this.cidUni.getSupplement()));
/*     */     }
/*     */     else {
/* 328 */       cdic.put(PdfName.REGISTRY, new PdfString(this.cidByte.getRegistry(), null));
/* 329 */       cdic.put(PdfName.ORDERING, new PdfString(this.cidByte.getOrdering(), null));
/* 330 */       cdic.put(PdfName.SUPPLEMENT, new PdfNumber(this.cidByte.getSupplement()));
/*     */     }
/* 332 */     dic.put(PdfName.CIDSYSTEMINFO, cdic);
/* 333 */     return dic;
/*     */   }
/*     */   
/*     */   private PdfDictionary getFontBaseType(PdfIndirectReference CIDFont) {
/* 337 */     PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 338 */     dic.put(PdfName.SUBTYPE, PdfName.TYPE0);
/* 339 */     String name = this.fontName;
/* 340 */     if (this.style.length() > 0)
/* 341 */       name = name + "-" + this.style.substring(1);
/* 342 */     name = name + "-" + this.CMap;
/* 343 */     dic.put(PdfName.BASEFONT, new PdfName(name));
/* 344 */     dic.put(PdfName.ENCODING, new PdfName(this.CMap));
/* 345 */     dic.put(PdfName.DESCENDANTFONTS, new PdfArray(CIDFont));
/* 346 */     return dic;
/*     */   }
/*     */   
/*     */   void writeFont(PdfWriter writer, PdfIndirectReference ref, Object[] params) throws DocumentException, IOException
/*     */   {
/* 351 */     IntHashtable cjkTag = (IntHashtable)params[0];
/* 352 */     PdfIndirectReference ind_font = null;
/* 353 */     PdfObject pobj = null;
/* 354 */     PdfIndirectObject obj = null;
/* 355 */     pobj = getFontDescriptor();
/* 356 */     if (pobj != null) {
/* 357 */       obj = writer.addToBody(pobj);
/* 358 */       ind_font = obj.getIndirectReference();
/*     */     }
/* 360 */     pobj = getCIDFont(ind_font, cjkTag);
/* 361 */     if (pobj != null) {
/* 362 */       obj = writer.addToBody(pobj);
/* 363 */       ind_font = obj.getIndirectReference();
/*     */     }
/* 365 */     pobj = getFontBaseType(ind_font);
/* 366 */     writer.addToBody(pobj, ref);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStream getFullFontStream()
/*     */   {
/* 377 */     return null;
/*     */   }
/*     */   
/*     */   private float getDescNumber(String name) {
/* 381 */     return Integer.parseInt((String)this.fontDesc.get(name));
/*     */   }
/*     */   
/*     */   private float getBBox(int idx) {
/* 385 */     String s = (String)this.fontDesc.get("FontBBox");
/* 386 */     StringTokenizer tk = new StringTokenizer(s, " []\r\n\t\f");
/* 387 */     String ret = tk.nextToken();
/* 388 */     for (int k = 0; k < idx; k++)
/* 389 */       ret = tk.nextToken();
/* 390 */     return Integer.parseInt(ret);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getFontDescriptor(int key, float fontSize)
/*     */   {
/* 402 */     switch (key) {
/*     */     case 1: 
/*     */     case 9: 
/* 405 */       return getDescNumber("Ascent") * fontSize / 1000.0F;
/*     */     case 2: 
/* 407 */       return getDescNumber("CapHeight") * fontSize / 1000.0F;
/*     */     case 3: 
/*     */     case 10: 
/* 410 */       return getDescNumber("Descent") * fontSize / 1000.0F;
/*     */     case 4: 
/* 412 */       return getDescNumber("ItalicAngle");
/*     */     case 5: 
/* 414 */       return fontSize * getBBox(0) / 1000.0F;
/*     */     case 6: 
/* 416 */       return fontSize * getBBox(1) / 1000.0F;
/*     */     case 7: 
/* 418 */       return fontSize * getBBox(2) / 1000.0F;
/*     */     case 8: 
/* 420 */       return fontSize * getBBox(3) / 1000.0F;
/*     */     case 11: 
/* 422 */       return 0.0F;
/*     */     case 12: 
/* 424 */       return fontSize * (getBBox(2) - getBBox(0)) / 1000.0F;
/*     */     }
/* 426 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public String getPostscriptFontName()
/*     */   {
/* 431 */     return this.fontName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getFullFontName()
/*     */   {
/* 444 */     return new String[][] { { "", "", "", this.fontName } };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getAllNameEntries()
/*     */   {
/* 457 */     return new String[][] { { "4", "", "", "", this.fontName } };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getFamilyFontName()
/*     */   {
/* 470 */     return getFullFontName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static IntHashtable createMetric(String s)
/*     */   {
/* 490 */     IntHashtable h = new IntHashtable();
/* 491 */     StringTokenizer tk = new StringTokenizer(s);
/* 492 */     while (tk.hasMoreTokens()) {
/* 493 */       int n1 = Integer.parseInt(tk.nextToken());
/* 494 */       h.put(n1, Integer.parseInt(tk.nextToken()));
/*     */     }
/* 496 */     return h;
/*     */   }
/*     */   
/*     */   static String convertToHCIDMetrics(int[] keys, IntHashtable h) {
/* 500 */     if (keys.length == 0)
/* 501 */       return null;
/* 502 */     int lastCid = 0;
/* 503 */     int lastValue = 0;
/*     */     
/* 505 */     for (int start = 0; start < keys.length; start++) {
/* 506 */       lastCid = keys[start];
/* 507 */       lastValue = h.get(lastCid);
/* 508 */       if (lastValue != 0) {
/* 509 */         start++;
/* 510 */         break;
/*     */       }
/*     */     }
/* 513 */     if (lastValue == 0)
/* 514 */       return null;
/* 515 */     StringBuilder buf = new StringBuilder();
/* 516 */     buf.append('[');
/* 517 */     buf.append(lastCid);
/* 518 */     int state = 0;
/* 519 */     for (int k = start; k < keys.length; k++) {
/* 520 */       int cid = keys[k];
/* 521 */       int value = h.get(cid);
/* 522 */       if (value != 0)
/*     */       {
/* 524 */         switch (state) {
/*     */         case 0: 
/* 526 */           if ((cid == lastCid + 1) && (value == lastValue)) {
/* 527 */             state = 2;
/*     */           }
/* 529 */           else if (cid == lastCid + 1) {
/* 530 */             state = 1;
/* 531 */             buf.append('[').append(lastValue);
/*     */           }
/*     */           else {
/* 534 */             buf.append('[').append(lastValue).append(']').append(cid);
/*     */           }
/* 536 */           break;
/*     */         
/*     */         case 1: 
/* 539 */           if ((cid == lastCid + 1) && (value == lastValue)) {
/* 540 */             state = 2;
/* 541 */             buf.append(']').append(lastCid);
/*     */           }
/* 543 */           else if (cid == lastCid + 1) {
/* 544 */             buf.append(' ').append(lastValue);
/*     */           }
/*     */           else {
/* 547 */             state = 0;
/* 548 */             buf.append(' ').append(lastValue).append(']').append(cid);
/*     */           }
/* 550 */           break;
/*     */         
/*     */         case 2: 
/* 553 */           if ((cid != lastCid + 1) || (value != lastValue)) {
/* 554 */             buf.append(' ').append(lastCid).append(' ').append(lastValue).append(' ').append(cid);
/* 555 */             state = 0;
/*     */           }
/*     */           break;
/*     */         }
/*     */         
/* 560 */         lastValue = value;
/* 561 */         lastCid = cid;
/*     */       } }
/* 563 */     switch (state) {
/*     */     case 0: 
/* 565 */       buf.append('[').append(lastValue).append("]]");
/* 566 */       break;
/*     */     
/*     */     case 1: 
/* 569 */       buf.append(' ').append(lastValue).append("]]");
/* 570 */       break;
/*     */     
/*     */     case 2: 
/* 573 */       buf.append(' ').append(lastCid).append(' ').append(lastValue).append(']');
/*     */     }
/*     */     
/*     */     
/* 577 */     return buf.toString();
/*     */   }
/*     */   
/*     */   static String convertToVCIDMetrics(int[] keys, IntHashtable v, IntHashtable h) {
/* 581 */     if (keys.length == 0)
/* 582 */       return null;
/* 583 */     int lastCid = 0;
/* 584 */     int lastValue = 0;
/* 585 */     int lastHValue = 0;
/*     */     
/* 587 */     for (int start = 0; start < keys.length; start++) {
/* 588 */       lastCid = keys[start];
/* 589 */       lastValue = v.get(lastCid);
/* 590 */       if (lastValue != 0) {
/* 591 */         start++;
/* 592 */         break;
/*     */       }
/*     */       
/* 595 */       lastHValue = h.get(lastCid);
/*     */     }
/* 597 */     if (lastValue == 0)
/* 598 */       return null;
/* 599 */     if (lastHValue == 0)
/* 600 */       lastHValue = 1000;
/* 601 */     StringBuilder buf = new StringBuilder();
/* 602 */     buf.append('[');
/* 603 */     buf.append(lastCid);
/* 604 */     int state = 0;
/* 605 */     for (int k = start; k < keys.length; k++) {
/* 606 */       int cid = keys[k];
/* 607 */       int value = v.get(cid);
/* 608 */       if (value != 0)
/*     */       {
/* 610 */         int hValue = h.get(lastCid);
/* 611 */         if (hValue == 0)
/* 612 */           hValue = 1000;
/* 613 */         switch (state) {
/*     */         case 0: 
/* 615 */           if ((cid == lastCid + 1) && (value == lastValue) && (hValue == lastHValue)) {
/* 616 */             state = 2;
/*     */           }
/*     */           else {
/* 619 */             buf.append(' ').append(lastCid).append(' ').append(-lastValue).append(' ').append(lastHValue / 2).append(' ').append(880).append(' ').append(cid);
/*     */           }
/* 621 */           break;
/*     */         
/*     */         case 2: 
/* 624 */           if ((cid != lastCid + 1) || (value != lastValue) || (hValue != lastHValue)) {
/* 625 */             buf.append(' ').append(lastCid).append(' ').append(-lastValue).append(' ').append(lastHValue / 2).append(' ').append(880).append(' ').append(cid);
/* 626 */             state = 0;
/*     */           }
/*     */           break;
/*     */         }
/*     */         
/* 631 */         lastValue = value;
/* 632 */         lastCid = cid;
/* 633 */         lastHValue = hValue;
/*     */       } }
/* 635 */     buf.append(' ').append(lastCid).append(' ').append(-lastValue).append(' ').append(lastHValue / 2).append(' ').append(880).append(" ]");
/* 636 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private static HashMap<String, Object> readFontProperties(String name) throws IOException {
/* 640 */     name = name + ".properties";
/* 641 */     InputStream is = StreamUtil.getResourceStream("com/itextpdf/text/pdf/fonts/cmaps/" + name);
/* 642 */     Properties p = new Properties();
/* 643 */     p.load(is);
/* 644 */     is.close();
/* 645 */     IntHashtable W = createMetric(p.getProperty("W"));
/* 646 */     p.remove("W");
/* 647 */     IntHashtable W2 = createMetric(p.getProperty("W2"));
/* 648 */     p.remove("W2");
/* 649 */     HashMap<String, Object> map = new HashMap();
/* 650 */     for (Enumeration<Object> e = p.keys(); e.hasMoreElements();) {
/* 651 */       Object obj = e.nextElement();
/* 652 */       map.put((String)obj, p.getProperty((String)obj));
/*     */     }
/* 654 */     map.put("W", W);
/* 655 */     map.put("W2", W2);
/* 656 */     return map;
/*     */   }
/*     */   
/*     */   public int getUnicodeEquivalent(int c)
/*     */   {
/* 661 */     if (this.cidDirect) {
/* 662 */       if (c == 32767)
/* 663 */         return 10;
/* 664 */       return this.cidUni.lookup(c);
/*     */     }
/* 666 */     return c;
/*     */   }
/*     */   
/*     */   public int getCidCode(int c)
/*     */   {
/* 671 */     if (this.cidDirect)
/* 672 */       return c;
/* 673 */     return this.uniCid.lookup(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasKernPairs()
/*     */   {
/* 681 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean charExists(int c)
/*     */   {
/* 692 */     if (this.cidDirect)
/* 693 */       return true;
/* 694 */     return this.cidByte.lookup(this.uniCid.lookup(c)).length > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setCharAdvance(int c, int advance)
/*     */   {
/* 706 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPostscriptFontName(String name)
/*     */   {
/* 716 */     this.fontName = name;
/*     */   }
/*     */   
/*     */   public boolean setKerning(int char1, int char2, int kern)
/*     */   {
/* 721 */     return false;
/*     */   }
/*     */   
/*     */   public int[] getCharBBox(int c)
/*     */   {
/* 726 */     return null;
/*     */   }
/*     */   
/*     */   protected int[] getRawCharBBox(int c, String name)
/*     */   {
/* 731 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] convertToBytes(String text)
/*     */   {
/* 742 */     if (this.cidDirect)
/* 743 */       return super.convertToBytes(text);
/*     */     try {
/* 745 */       if (text.length() == 1)
/* 746 */         return convertToBytes(text.charAt(0));
/* 747 */       ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 748 */       for (int k = 0; k < text.length(); k++) {
/*     */         int val;
/* 750 */         if (Utilities.isSurrogatePair(text, k)) {
/* 751 */           int val = Utilities.convertToUtf32(text, k);
/* 752 */           k++;
/*     */         }
/*     */         else {
/* 755 */           val = text.charAt(k);
/*     */         }
/* 757 */         bout.write(convertToBytes(val));
/*     */       }
/* 759 */       return bout.toByteArray();
/*     */     }
/*     */     catch (Exception ex) {
/* 762 */       throw new ExceptionConverter(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] convertToBytes(int char1)
/*     */   {
/* 774 */     if (this.cidDirect)
/* 775 */       return super.convertToBytes(char1);
/* 776 */     return this.cidByte.lookup(this.uniCid.lookup(char1));
/*     */   }
/*     */   
/*     */   public boolean isIdentity() {
/* 780 */     return this.cidDirect;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/CJKFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */