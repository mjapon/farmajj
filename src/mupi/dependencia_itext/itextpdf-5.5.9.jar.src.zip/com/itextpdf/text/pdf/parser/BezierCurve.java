/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.awt.geom.Point2D;
/*     */ import com.itextpdf.awt.geom.Point2D.Double;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BezierCurve
/*     */   implements Shape
/*     */ {
/*  63 */   public static double curveCollinearityEpsilon = 1.0E-30D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   public static double distanceToleranceSquare = 0.025D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   public static double distanceToleranceManhattan = 0.4D;
/*     */   
/*     */ 
/*     */   private final List<Point2D> controlPoints;
/*     */   
/*     */ 
/*     */ 
/*     */   public BezierCurve(List<Point2D> controlPoints)
/*     */   {
/*  94 */     this.controlPoints = new ArrayList(controlPoints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Point2D> getBasePoints()
/*     */   {
/* 101 */     return this.controlPoints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Point2D> getPiecewiseLinearApproximation()
/*     */   {
/* 114 */     List<Point2D> points = new ArrayList();
/* 115 */     points.add(this.controlPoints.get(0));
/*     */     
/* 117 */     recursiveApproximation(((Point2D)this.controlPoints.get(0)).getX(), ((Point2D)this.controlPoints.get(0)).getY(), 
/* 118 */       ((Point2D)this.controlPoints.get(1)).getX(), ((Point2D)this.controlPoints.get(1)).getY(), 
/* 119 */       ((Point2D)this.controlPoints.get(2)).getX(), ((Point2D)this.controlPoints.get(2)).getY(), 
/* 120 */       ((Point2D)this.controlPoints.get(3)).getX(), ((Point2D)this.controlPoints.get(3)).getY(), points);
/*     */     
/* 122 */     points.add(this.controlPoints.get(this.controlPoints.size() - 1));
/* 123 */     return points;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void recursiveApproximation(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4, List<Point2D> points)
/*     */   {
/* 130 */     double x12 = (x1 + x2) / 2.0D;
/* 131 */     double y12 = (y1 + y2) / 2.0D;
/* 132 */     double x23 = (x2 + x3) / 2.0D;
/* 133 */     double y23 = (y2 + y3) / 2.0D;
/* 134 */     double x34 = (x3 + x4) / 2.0D;
/* 135 */     double y34 = (y3 + y4) / 2.0D;
/* 136 */     double x123 = (x12 + x23) / 2.0D;
/* 137 */     double y123 = (y12 + y23) / 2.0D;
/* 138 */     double x234 = (x23 + x34) / 2.0D;
/* 139 */     double y234 = (y23 + y34) / 2.0D;
/* 140 */     double x1234 = (x123 + x234) / 2.0D;
/* 141 */     double y1234 = (y123 + y234) / 2.0D;
/*     */     
/* 143 */     double dx = x4 - x1;
/* 144 */     double dy = y4 - y1;
/*     */     
/*     */ 
/*     */ 
/* 148 */     double d2 = Math.abs((x2 - x4) * dy - (y2 - y4) * dx);
/*     */     
/*     */ 
/* 151 */     double d3 = Math.abs((x3 - x4) * dy - (y3 - y4) * dx);
/*     */     
/*     */ 
/*     */ 
/* 155 */     if ((d2 > curveCollinearityEpsilon) || (d3 > curveCollinearityEpsilon))
/*     */     {
/*     */ 
/* 158 */       if ((d2 + d3) * (d2 + d3) <= distanceToleranceSquare * (dx * dx + dy * dy)) {
/* 159 */         points.add(new Point2D.Double(x1234, y1234));
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 165 */     else if (Math.abs(x1 + x3 - x2 - x2) + Math.abs(y1 + y3 - y2 - y2) + Math.abs(x2 + x4 - x3 - x3) + Math.abs(y2 + y4 - y3 - y3) <= distanceToleranceManhattan) {
/* 166 */       points.add(new Point2D.Double(x1234, y1234));
/* 167 */       return;
/*     */     }
/*     */     
/*     */ 
/* 171 */     recursiveApproximation(x1, y1, x12, y12, x123, y123, x1234, y1234, points);
/* 172 */     recursiveApproximation(x1234, y1234, x234, y234, x34, y34, x4, y4, points);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/BezierCurve.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */