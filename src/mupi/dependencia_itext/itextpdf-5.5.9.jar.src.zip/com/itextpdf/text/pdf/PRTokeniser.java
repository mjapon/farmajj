/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.exceptions.InvalidPdfException;
/*     */ import com.itextpdf.text.io.RandomAccessSourceFactory;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PRTokeniser
/*     */ {
/*  58 */   private final StringBuilder outBuf = new StringBuilder();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum TokenType
/*     */   {
/*  65 */     NUMBER, 
/*  66 */     STRING, 
/*  67 */     NAME, 
/*  68 */     COMMENT, 
/*  69 */     START_ARRAY, 
/*  70 */     END_ARRAY, 
/*  71 */     START_DIC, 
/*  72 */     END_DIC, 
/*  73 */     REF, 
/*  74 */     OTHER, 
/*  75 */     ENDOFFILE;
/*     */     
/*     */     private TokenType() {} }
/*  78 */   public static final boolean[] delims = { true, true, false, false, false, false, false, false, false, false, true, true, false, true, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, true, false, false, true, true, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String EMPTY = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final RandomAccessFileOrArray file;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TokenType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String stringValue;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int reference;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int generation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hexString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PRTokeniser(RandomAccessFileOrArray file)
/*     */   {
/* 124 */     this.file = file;
/*     */   }
/*     */   
/*     */   public void seek(long pos) throws IOException {
/* 128 */     this.file.seek(pos);
/*     */   }
/*     */   
/*     */   public long getFilePointer() throws IOException {
/* 132 */     return this.file.getFilePointer();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 136 */     this.file.close();
/*     */   }
/*     */   
/*     */   public long length() throws IOException {
/* 140 */     return this.file.length();
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 144 */     return this.file.read();
/*     */   }
/*     */   
/*     */   public RandomAccessFileOrArray getSafeFile() {
/* 148 */     return new RandomAccessFileOrArray(this.file);
/*     */   }
/*     */   
/*     */   public RandomAccessFileOrArray getFile()
/*     */   {
/* 153 */     return this.file;
/*     */   }
/*     */   
/*     */   public String readString(int size) throws IOException {
/* 157 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 159 */     while (size-- > 0) {
/* 160 */       int ch = read();
/* 161 */       if (ch == -1)
/*     */         break;
/* 163 */       buf.append((char)ch);
/*     */     }
/* 165 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isWhitespace(int ch)
/*     */   {
/* 176 */     return isWhitespace(ch, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isWhitespace(int ch, boolean isWhitespace)
/*     */   {
/* 187 */     return ((isWhitespace) && (ch == 0)) || (ch == 9) || (ch == 10) || (ch == 12) || (ch == 13) || (ch == 32);
/*     */   }
/*     */   
/*     */   public static final boolean isDelimiter(int ch) {
/* 191 */     return (ch == 40) || (ch == 41) || (ch == 60) || (ch == 62) || (ch == 91) || (ch == 93) || (ch == 47) || (ch == 37);
/*     */   }
/*     */   
/*     */   public static final boolean isDelimiterWhitespace(int ch) {
/* 195 */     return delims[(ch + 1)];
/*     */   }
/*     */   
/*     */   public TokenType getTokenType() {
/* 199 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getStringValue() {
/* 203 */     return this.stringValue;
/*     */   }
/*     */   
/*     */   public int getReference() {
/* 207 */     return this.reference;
/*     */   }
/*     */   
/*     */   public int getGeneration() {
/* 211 */     return this.generation;
/*     */   }
/*     */   
/*     */   public void backOnePosition(int ch) {
/* 215 */     if (ch != -1)
/* 216 */       this.file.pushBack((byte)ch);
/*     */   }
/*     */   
/*     */   public void throwError(String error) throws IOException {
/* 220 */     throw new InvalidPdfException(MessageLocalization.getComposedMessage("1.at.file.pointer.2", new Object[] { error, String.valueOf(this.file.getFilePointer()) }));
/*     */   }
/*     */   
/*     */   public int getHeaderOffset() throws IOException {
/* 224 */     String str = readString(1024);
/* 225 */     int idx = str.indexOf("%PDF-");
/* 226 */     if (idx < 0) {
/* 227 */       idx = str.indexOf("%FDF-");
/* 228 */       if (idx < 0) {
/* 229 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("pdf.header.not.found", new Object[0]));
/*     */       }
/*     */     }
/* 232 */     return idx;
/*     */   }
/*     */   
/*     */   public char checkPdfHeader() throws IOException {
/* 236 */     this.file.seek(0L);
/* 237 */     String str = readString(1024);
/* 238 */     int idx = str.indexOf("%PDF-");
/* 239 */     if (idx != 0)
/* 240 */       throw new InvalidPdfException(MessageLocalization.getComposedMessage("pdf.header.not.found", new Object[0]));
/* 241 */     return str.charAt(7);
/*     */   }
/*     */   
/*     */   public void checkFdfHeader() throws IOException {
/* 245 */     this.file.seek(0L);
/* 246 */     String str = readString(1024);
/* 247 */     int idx = str.indexOf("%FDF-");
/* 248 */     if (idx != 0)
/* 249 */       throw new InvalidPdfException(MessageLocalization.getComposedMessage("fdf.header.not.found", new Object[0]));
/*     */   }
/*     */   
/*     */   public long getStartxref() throws IOException {
/* 253 */     int arrLength = 1024;
/* 254 */     long fileLength = this.file.length();
/* 255 */     long pos = fileLength - arrLength;
/* 256 */     if (pos < 1L) pos = 1L;
/* 257 */     while (pos > 0L) {
/* 258 */       this.file.seek(pos);
/* 259 */       String str = readString(arrLength);
/* 260 */       int idx = str.lastIndexOf("startxref");
/* 261 */       if (idx >= 0) return pos + idx;
/* 262 */       pos = pos - arrLength + 9L;
/*     */     }
/* 264 */     throw new InvalidPdfException(MessageLocalization.getComposedMessage("pdf.startxref.not.found", new Object[0]));
/*     */   }
/*     */   
/*     */   public static int getHex(int v) {
/* 268 */     if ((v >= 48) && (v <= 57))
/* 269 */       return v - 48;
/* 270 */     if ((v >= 65) && (v <= 70))
/* 271 */       return v - 65 + 10;
/* 272 */     if ((v >= 97) && (v <= 102))
/* 273 */       return v - 97 + 10;
/* 274 */     return -1;
/*     */   }
/*     */   
/*     */   public void nextValidToken() throws IOException {
/* 278 */     int level = 0;
/* 279 */     String n1 = null;
/* 280 */     String n2 = null;
/* 281 */     long ptr = 0L;
/* 282 */     while (nextToken()) {
/* 283 */       if (this.type != TokenType.COMMENT)
/*     */       {
/* 285 */         switch (level)
/*     */         {
/*     */         case 0: 
/* 288 */           if (this.type != TokenType.NUMBER)
/* 289 */             return;
/* 290 */           ptr = this.file.getFilePointer();
/* 291 */           n1 = this.stringValue;
/* 292 */           level++;
/* 293 */           break;
/*     */         
/*     */ 
/*     */         case 1: 
/* 297 */           if (this.type != TokenType.NUMBER) {
/* 298 */             this.file.seek(ptr);
/* 299 */             this.type = TokenType.NUMBER;
/* 300 */             this.stringValue = n1;
/* 301 */             return;
/*     */           }
/* 303 */           n2 = this.stringValue;
/* 304 */           level++;
/* 305 */           break;
/*     */         
/*     */ 
/*     */         default: 
/* 309 */           if ((this.type != TokenType.OTHER) || (!this.stringValue.equals("R"))) {
/* 310 */             this.file.seek(ptr);
/* 311 */             this.type = TokenType.NUMBER;
/* 312 */             this.stringValue = n1;
/* 313 */             return;
/*     */           }
/* 315 */           this.type = TokenType.REF;
/* 316 */           this.reference = Integer.parseInt(n1);
/* 317 */           this.generation = Integer.parseInt(n2);
/* 318 */           return;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 323 */     if (level == 1) {
/* 324 */       this.type = TokenType.NUMBER;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean nextToken()
/*     */     throws IOException
/*     */   {
/* 332 */     int ch = 0;
/*     */     do {
/* 334 */       ch = this.file.read();
/* 335 */     } while ((ch != -1) && (isWhitespace(ch)));
/* 336 */     if (ch == -1) {
/* 337 */       this.type = TokenType.ENDOFFILE;
/* 338 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 344 */     this.outBuf.setLength(0);
/* 345 */     this.stringValue = "";
/*     */     
/* 347 */     switch (ch) {
/*     */     case 91: 
/* 349 */       this.type = TokenType.START_ARRAY;
/* 350 */       break;
/*     */     case 93: 
/* 352 */       this.type = TokenType.END_ARRAY;
/* 353 */       break;
/*     */     
/*     */     case 47: 
/* 356 */       this.outBuf.setLength(0);
/* 357 */       this.type = TokenType.NAME;
/*     */       for (;;) {
/* 359 */         ch = this.file.read();
/* 360 */         if (delims[(ch + 1)] != 0)
/*     */           break;
/* 362 */         if (ch == 35) {
/* 363 */           ch = (getHex(this.file.read()) << 4) + getHex(this.file.read());
/*     */         }
/* 365 */         this.outBuf.append((char)ch);
/*     */       }
/* 367 */       backOnePosition(ch);
/* 368 */       break;
/*     */     
/*     */     case 62: 
/* 371 */       ch = this.file.read();
/* 372 */       if (ch != 62)
/* 373 */         throwError(MessageLocalization.getComposedMessage("greaterthan.not.expected", new Object[0]));
/* 374 */       this.type = TokenType.END_DIC;
/* 375 */       break;
/*     */     
/*     */     case 60: 
/* 378 */       int v1 = this.file.read();
/* 379 */       if (v1 == 60) {
/* 380 */         this.type = TokenType.START_DIC;
/*     */       }
/*     */       else {
/* 383 */         this.outBuf.setLength(0);
/* 384 */         this.type = TokenType.STRING;
/* 385 */         this.hexString = true;
/* 386 */         int v2 = 0;
/*     */         for (;;) {
/* 388 */           if (isWhitespace(v1)) {
/* 389 */             v1 = this.file.read();
/* 390 */           } else { if (v1 == 62)
/*     */               break;
/* 392 */             v1 = getHex(v1);
/* 393 */             if (v1 < 0)
/*     */               break;
/* 395 */             v2 = this.file.read();
/* 396 */             while (isWhitespace(v2))
/* 397 */               v2 = this.file.read();
/* 398 */             if (v2 == 62) {
/* 399 */               ch = v1 << 4;
/* 400 */               this.outBuf.append((char)ch);
/* 401 */               break;
/*     */             }
/* 403 */             v2 = getHex(v2);
/* 404 */             if (v2 < 0)
/*     */               break;
/* 406 */             ch = (v1 << 4) + v2;
/* 407 */             this.outBuf.append((char)ch);
/* 408 */             v1 = this.file.read();
/*     */           } }
/* 410 */         if ((v1 < 0) || (v2 < 0))
/* 411 */           throwError(MessageLocalization.getComposedMessage("error.reading.string", new Object[0]));
/*     */       }
/*     */       break;
/*     */     case 37: 
/* 415 */       this.type = TokenType.COMMENT;
/*     */       do {
/* 417 */         ch = this.file.read();
/* 418 */         if ((ch == -1) || (ch == 13)) break; } while (ch != 10);
/* 419 */       break;
/*     */     
/*     */     case 40: 
/* 422 */       this.outBuf.setLength(0);
/* 423 */       this.type = TokenType.STRING;
/* 424 */       this.hexString = false;
/* 425 */       int nesting = 0;
/*     */       for (;;) {
/* 427 */         ch = this.file.read();
/* 428 */         if (ch == -1)
/*     */           break;
/* 430 */         if (ch == 40) {
/* 431 */           nesting++;
/*     */         }
/* 433 */         else if (ch == 41) {
/* 434 */           nesting--;
/*     */         }
/* 436 */         else if (ch == 92) {
/* 437 */           boolean lineBreak = false;
/* 438 */           ch = this.file.read();
/* 439 */           switch (ch) {
/*     */           case 110: 
/* 441 */             ch = 10;
/* 442 */             break;
/*     */           case 114: 
/* 444 */             ch = 13;
/* 445 */             break;
/*     */           case 116: 
/* 447 */             ch = 9;
/* 448 */             break;
/*     */           case 98: 
/* 450 */             ch = 8;
/* 451 */             break;
/*     */           case 102: 
/* 453 */             ch = 12;
/* 454 */             break;
/*     */           case 40: 
/*     */           case 41: 
/*     */           case 92: 
/*     */             break;
/*     */           case 13: 
/* 460 */             lineBreak = true;
/* 461 */             ch = this.file.read();
/* 462 */             if (ch != 10)
/* 463 */               backOnePosition(ch);
/*     */             break;
/*     */           case 10: 
/* 466 */             lineBreak = true;
/* 467 */             break;
/*     */           
/*     */           default: 
/* 470 */             if ((ch >= 48) && (ch <= 55))
/*     */             {
/*     */ 
/* 473 */               int octal = ch - 48;
/* 474 */               ch = this.file.read();
/* 475 */               if ((ch < 48) || (ch > 55)) {
/* 476 */                 backOnePosition(ch);
/* 477 */                 ch = octal;
/*     */               }
/*     */               else {
/* 480 */                 octal = (octal << 3) + ch - 48;
/* 481 */                 ch = this.file.read();
/* 482 */                 if ((ch < 48) || (ch > 55)) {
/* 483 */                   backOnePosition(ch);
/* 484 */                   ch = octal;
/*     */                 }
/*     */                 else {
/* 487 */                   octal = (octal << 3) + ch - 48;
/* 488 */                   ch = octal & 0xFF; } } }
/* 489 */             break;
/*     */           }
/*     */           
/* 492 */           if (lineBreak)
/*     */             continue;
/* 494 */           if (ch < 0) {
/*     */             break;
/*     */           }
/* 497 */         } else if (ch == 13) {
/* 498 */           ch = this.file.read();
/* 499 */           if (ch < 0)
/*     */             break;
/* 501 */           if (ch != 10) {
/* 502 */             backOnePosition(ch);
/* 503 */             ch = 10;
/*     */           }
/*     */         }
/* 506 */         if (nesting == -1)
/*     */           break;
/* 508 */         this.outBuf.append((char)ch);
/*     */       }
/* 510 */       if (ch == -1) {
/* 511 */         throwError(MessageLocalization.getComposedMessage("error.reading.string", new Object[0]));
/*     */       }
/*     */       
/*     */       break;
/*     */     default: 
/* 516 */       this.outBuf.setLength(0);
/* 517 */       if ((ch == 45) || (ch == 43) || (ch == 46) || ((ch >= 48) && (ch <= 57))) {
/* 518 */         this.type = TokenType.NUMBER;
/* 519 */         boolean isReal = false;
/* 520 */         int numberOfMinuses = 0;
/* 521 */         if (ch == 45)
/*     */         {
/*     */           do {
/* 524 */             numberOfMinuses++;
/* 525 */             ch = this.file.read();
/* 526 */           } while (ch == 45);
/* 527 */           this.outBuf.append('-');
/*     */         }
/*     */         else {
/* 530 */           this.outBuf.append((char)ch);
/*     */           
/*     */ 
/* 533 */           ch = this.file.read();
/*     */         }
/* 535 */         while ((ch != -1) && (((ch >= 48) && (ch <= 57)) || (ch == 46))) {
/* 536 */           if (ch == 46)
/* 537 */             isReal = true;
/* 538 */           this.outBuf.append((char)ch);
/* 539 */           ch = this.file.read();
/*     */         }
/* 541 */         if ((numberOfMinuses > 1) && (!isReal))
/*     */         {
/*     */ 
/* 544 */           this.outBuf.setLength(0);
/* 545 */           this.outBuf.append('0');
/*     */         }
/*     */       }
/*     */       else {
/* 549 */         this.type = TokenType.OTHER;
/*     */         do {
/* 551 */           this.outBuf.append((char)ch);
/* 552 */           ch = this.file.read();
/* 553 */         } while (delims[(ch + 1)] == 0);
/*     */       }
/* 555 */       if (ch != -1) {
/* 556 */         backOnePosition(ch);
/*     */       }
/*     */       break;
/*     */     }
/* 560 */     if (this.outBuf != null)
/* 561 */       this.stringValue = this.outBuf.toString();
/* 562 */     return true;
/*     */   }
/*     */   
/*     */   public long longValue() {
/* 566 */     return Long.parseLong(this.stringValue);
/*     */   }
/*     */   
/*     */   public int intValue() {
/* 570 */     return Integer.parseInt(this.stringValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readLineSegment(byte[] input)
/*     */     throws IOException
/*     */   {
/* 585 */     return readLineSegment(input, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readLineSegment(byte[] input, boolean isNullWhitespace)
/*     */     throws IOException
/*     */   {
/* 601 */     int c = -1;
/* 602 */     boolean eol = false;
/* 603 */     int ptr = 0;
/* 604 */     int len = input.length;
/*     */     
/*     */ 
/*     */ 
/* 608 */     while ((ptr < len) && 
/* 609 */       (isWhitespace(c = read(), isNullWhitespace))) {}
/*     */     
/* 611 */     while ((!eol) && (ptr < len)) {
/* 612 */       switch (c) {
/*     */       case -1: 
/*     */       case 10: 
/* 615 */         eol = true;
/* 616 */         break;
/*     */       case 13: 
/* 618 */         eol = true;
/* 619 */         long cur = getFilePointer();
/* 620 */         if (read() != 10) {
/* 621 */           seek(cur);
/*     */         }
/*     */         break;
/*     */       default: 
/* 625 */         input[(ptr++)] = ((byte)c);
/*     */       }
/*     */       
/*     */       
/*     */ 
/* 630 */       if ((eol) || (len <= ptr)) {
/*     */         break;
/*     */       }
/* 633 */       c = read();
/*     */     }
/*     */     
/* 636 */     if (ptr >= len) {
/* 637 */       eol = false;
/* 638 */       while (!eol) {
/* 639 */         switch (c = read()) {
/*     */         case -1: 
/*     */         case 10: 
/* 642 */           eol = true;
/* 643 */           break;
/*     */         case 13: 
/* 645 */           eol = true;
/* 646 */           long cur = getFilePointer();
/* 647 */           if (read() != 10) {
/* 648 */             seek(cur);
/*     */           }
/*     */           break;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 655 */     if ((c == -1) && (ptr == 0)) {
/* 656 */       return false;
/*     */     }
/* 658 */     if (ptr + 2 <= len) {
/* 659 */       input[(ptr++)] = 32;
/* 660 */       input[ptr] = 88;
/*     */     }
/* 662 */     return true;
/*     */   }
/*     */   
/*     */   public static long[] checkObjectStart(byte[] line) {
/*     */     try {
/* 667 */       PRTokeniser tk = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(line)));
/* 668 */       int num = 0;
/* 669 */       int gen = 0;
/* 670 */       if ((!tk.nextToken()) || (tk.getTokenType() != TokenType.NUMBER))
/* 671 */         return null;
/* 672 */       num = tk.intValue();
/* 673 */       if ((!tk.nextToken()) || (tk.getTokenType() != TokenType.NUMBER))
/* 674 */         return null;
/* 675 */       gen = tk.intValue();
/* 676 */       if (!tk.nextToken())
/* 677 */         return null;
/* 678 */       if (!tk.getStringValue().equals("obj"))
/* 679 */         return null;
/* 680 */       return new long[] { num, gen };
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/* 685 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isHexString() {
/* 689 */     return this.hexString;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PRTokeniser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */