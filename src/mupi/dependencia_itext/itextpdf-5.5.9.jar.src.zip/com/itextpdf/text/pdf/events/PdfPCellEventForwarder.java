/*    */ package com.itextpdf.text.pdf.events;
/*    */ 
/*    */ import com.itextpdf.text.Rectangle;
/*    */ import com.itextpdf.text.pdf.PdfContentByte;
/*    */ import com.itextpdf.text.pdf.PdfPCell;
/*    */ import com.itextpdf.text.pdf.PdfPCellEvent;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfPCellEventForwarder
/*    */   implements PdfPCellEvent
/*    */ {
/* 64 */   protected ArrayList<PdfPCellEvent> events = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addCellEvent(PdfPCellEvent event)
/*    */   {
/* 71 */     this.events.add(event);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void cellLayout(PdfPCell cell, Rectangle position, PdfContentByte[] canvases)
/*    */   {
/* 78 */     for (PdfPCellEvent event : this.events) {
/* 79 */       event.cellLayout(cell, position, canvases);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/events/PdfPCellEventForwarder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */