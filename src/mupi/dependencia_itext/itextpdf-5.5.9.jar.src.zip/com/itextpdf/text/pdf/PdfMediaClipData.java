/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfMediaClipData
/*    */   extends PdfDictionary
/*    */ {
/*    */   PdfMediaClipData(String file, PdfFileSpecification fs, String mimeType)
/*    */     throws IOException
/*    */   {
/* 52 */     put(PdfName.TYPE, new PdfName("MediaClip"));
/* 53 */     put(PdfName.S, new PdfName("MCD"));
/* 54 */     put(PdfName.N, new PdfString("Media clip for " + file));
/* 55 */     put(new PdfName("CT"), new PdfString(mimeType));
/* 56 */     PdfDictionary dic = new PdfDictionary();
/* 57 */     dic.put(new PdfName("TF"), new PdfString("TEMPACCESS"));
/* 58 */     put(new PdfName("P"), dic);
/* 59 */     put(PdfName.D, fs.getReference());
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfMediaClipData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */