/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.Document;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.log.Counter;
/*     */ import com.itextpdf.text.log.CounterFactory;
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfSmartCopy
/*     */   extends PdfCopy
/*     */ {
/*  73 */   private static final Logger LOGGER = LoggerFactory.getLogger(PdfSmartCopy.class);
/*     */   
/*     */ 
/*  76 */   private HashMap<ByteStore, PdfIndirectReference> streamMap = null;
/*  77 */   private final HashMap<RefKey, Integer> serialized = new HashMap();
/*     */   
/*  79 */   protected Counter COUNTER = CounterFactory.getCounter(PdfSmartCopy.class);
/*     */   
/*  81 */   protected Counter getCounter() { return this.COUNTER; }
/*     */   
/*     */   public PdfSmartCopy(Document document, OutputStream os)
/*     */     throws DocumentException
/*     */   {
/*  86 */     super(document, os);
/*  87 */     this.streamMap = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PdfIndirectReference copyIndirect(PRIndirectReference in)
/*     */     throws IOException, BadPdfFormatException
/*     */   {
/* 103 */     PdfObject srcObj = PdfReader.getPdfObjectRelease(in);
/* 104 */     ByteStore streamKey = null;
/* 105 */     boolean validStream = false;
/* 106 */     if (srcObj.isStream()) {
/* 107 */       streamKey = new ByteStore((PRStream)srcObj, this.serialized);
/* 108 */       validStream = true;
/* 109 */       PdfIndirectReference streamRef = (PdfIndirectReference)this.streamMap.get(streamKey);
/* 110 */       if (streamRef != null) {
/* 111 */         return streamRef;
/*     */       }
/*     */     }
/* 114 */     else if (srcObj.isDictionary()) {
/* 115 */       streamKey = new ByteStore((PdfDictionary)srcObj, this.serialized);
/* 116 */       validStream = true;
/* 117 */       PdfIndirectReference streamRef = (PdfIndirectReference)this.streamMap.get(streamKey);
/* 118 */       if (streamRef != null) {
/* 119 */         return streamRef;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 124 */     RefKey key = new RefKey(in);
/* 125 */     PdfCopy.IndirectReferences iRef = (PdfCopy.IndirectReferences)this.indirects.get(key);
/* 126 */     PdfIndirectReference theRef; if (iRef != null) {
/* 127 */       PdfIndirectReference theRef = iRef.getRef();
/* 128 */       if (iRef.getCopied()) {
/* 129 */         return theRef;
/*     */       }
/*     */     } else {
/* 132 */       theRef = this.body.getPdfIndirectReference();
/* 133 */       iRef = new PdfCopy.IndirectReferences(theRef);
/* 134 */       this.indirects.put(key, iRef);
/*     */     }
/* 136 */     if (srcObj.isDictionary()) {
/* 137 */       PdfObject type = PdfReader.getPdfObjectRelease(((PdfDictionary)srcObj).get(PdfName.TYPE));
/* 138 */       if (type != null) {
/* 139 */         if (PdfName.PAGE.equals(type)) {
/* 140 */           return theRef;
/*     */         }
/* 142 */         if (PdfName.CATALOG.equals(type)) {
/* 143 */           LOGGER.warn(MessageLocalization.getComposedMessage("make.copy.of.catalog.dictionary.is.forbidden", new Object[0]));
/* 144 */           return null;
/*     */         }
/*     */       }
/*     */     }
/* 148 */     iRef.setCopied();
/*     */     
/* 150 */     if (validStream) {
/* 151 */       this.streamMap.put(streamKey, theRef);
/*     */     }
/*     */     
/* 154 */     PdfObject obj = copyObject(srcObj);
/* 155 */     addToBody(obj, theRef);
/* 156 */     return theRef;
/*     */   }
/*     */   
/*     */   public void freeReader(PdfReader reader) throws IOException
/*     */   {
/* 161 */     this.serialized.clear();
/* 162 */     super.freeReader(reader);
/*     */   }
/*     */   
/*     */   public void addPage(PdfImportedPage iPage) throws IOException, BadPdfFormatException
/*     */   {
/* 167 */     if (this.currentPdfReaderInstance.getReader() != this.reader)
/* 168 */       this.serialized.clear();
/* 169 */     super.addPage(iPage);
/*     */   }
/*     */   
/*     */   static class ByteStore {
/*     */     private final byte[] b;
/*     */     private final int hash;
/*     */     private MessageDigest md5;
/*     */     
/*     */     private void serObject(PdfObject obj, int level, ByteBuffer bb, HashMap<RefKey, Integer> serialized) throws IOException {
/* 178 */       if (level <= 0)
/* 179 */         return;
/* 180 */       if (obj == null) {
/* 181 */         bb.append("$Lnull");
/* 182 */         return;
/*     */       }
/* 184 */       PdfIndirectReference ref = null;
/* 185 */       ByteBuffer savedBb = null;
/*     */       
/* 187 */       if (obj.isIndirect()) {
/* 188 */         ref = (PdfIndirectReference)obj;
/* 189 */         RefKey key = new RefKey(ref);
/* 190 */         if (serialized.containsKey(key)) {
/* 191 */           bb.append(((Integer)serialized.get(key)).intValue());
/* 192 */           return;
/*     */         }
/*     */         
/* 195 */         savedBb = bb;
/* 196 */         bb = new ByteBuffer();
/*     */       }
/*     */       
/* 199 */       obj = PdfReader.getPdfObject(obj);
/* 200 */       if (obj.isStream()) {
/* 201 */         bb.append("$B");
/* 202 */         serDic((PdfDictionary)obj, level - 1, bb, serialized);
/* 203 */         if (level > 0) {
/* 204 */           this.md5.reset();
/* 205 */           bb.append(this.md5.digest(PdfReader.getStreamBytesRaw((PRStream)obj)));
/*     */         }
/*     */       }
/* 208 */       else if (obj.isDictionary()) {
/* 209 */         serDic((PdfDictionary)obj, level - 1, bb, serialized);
/*     */       }
/* 211 */       else if (obj.isArray()) {
/* 212 */         serArray((PdfArray)obj, level - 1, bb, serialized);
/*     */       }
/* 214 */       else if (obj.isString()) {
/* 215 */         bb.append("$S").append(obj.toString());
/*     */       }
/* 217 */       else if (obj.isName()) {
/* 218 */         bb.append("$N").append(obj.toString());
/*     */       }
/*     */       else {
/* 221 */         bb.append("$L").append(obj.toString());
/*     */       }
/* 223 */       if (savedBb != null) {
/* 224 */         RefKey key = new RefKey(ref);
/* 225 */         if (!serialized.containsKey(key))
/* 226 */           serialized.put(key, Integer.valueOf(calculateHash(bb.getBuffer())));
/* 227 */         savedBb.append(bb);
/*     */       }
/*     */     }
/*     */     
/*     */     private void serDic(PdfDictionary dic, int level, ByteBuffer bb, HashMap<RefKey, Integer> serialized) throws IOException {
/* 232 */       bb.append("$D");
/* 233 */       if (level <= 0)
/* 234 */         return;
/* 235 */       Object[] keys = dic.getKeys().toArray();
/* 236 */       Arrays.sort(keys);
/* 237 */       for (int k = 0; k < keys.length; k++) {
/* 238 */         if ((!keys[k].equals(PdfName.P)) || ((!dic.get((PdfName)keys[k]).isIndirect()) && (!dic.get((PdfName)keys[k]).isDictionary())))
/*     */         {
/* 240 */           serObject((PdfObject)keys[k], level, bb, serialized);
/* 241 */           serObject(dic.get((PdfName)keys[k]), level, bb, serialized);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void serArray(PdfArray array, int level, ByteBuffer bb, HashMap<RefKey, Integer> serialized) throws IOException {
/* 247 */       bb.append("$A");
/* 248 */       if (level <= 0)
/* 249 */         return;
/* 250 */       for (int k = 0; k < array.size(); k++) {
/* 251 */         serObject(array.getPdfObject(k), level, bb, serialized);
/*     */       }
/*     */     }
/*     */     
/*     */     ByteStore(PRStream str, HashMap<RefKey, Integer> serialized) throws IOException {
/*     */       try {
/* 257 */         this.md5 = MessageDigest.getInstance("MD5");
/*     */       }
/*     */       catch (Exception e) {
/* 260 */         throw new ExceptionConverter(e);
/*     */       }
/* 262 */       ByteBuffer bb = new ByteBuffer();
/* 263 */       int level = 100;
/* 264 */       serObject(str, level, bb, serialized);
/* 265 */       this.b = bb.toByteArray();
/* 266 */       this.hash = calculateHash(this.b);
/* 267 */       this.md5 = null;
/*     */     }
/*     */     
/*     */     ByteStore(PdfDictionary dict, HashMap<RefKey, Integer> serialized) throws IOException {
/*     */       try {
/* 272 */         this.md5 = MessageDigest.getInstance("MD5");
/*     */       }
/*     */       catch (Exception e) {
/* 275 */         throw new ExceptionConverter(e);
/*     */       }
/* 277 */       ByteBuffer bb = new ByteBuffer();
/* 278 */       int level = 100;
/* 279 */       serObject(dict, level, bb, serialized);
/* 280 */       this.b = bb.toByteArray();
/* 281 */       this.hash = calculateHash(this.b);
/* 282 */       this.md5 = null;
/*     */     }
/*     */     
/*     */     private static int calculateHash(byte[] b) {
/* 286 */       int hash = 0;
/* 287 */       int len = b.length;
/* 288 */       for (int k = 0; k < len; k++)
/* 289 */         hash = hash * 31 + (b[k] & 0xFF);
/* 290 */       return hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 295 */       if (!(obj instanceof ByteStore))
/* 296 */         return false;
/* 297 */       if (hashCode() != obj.hashCode())
/* 298 */         return false;
/* 299 */       return Arrays.equals(this.b, ((ByteStore)obj).b);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 304 */       return this.hash;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfSmartCopy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */