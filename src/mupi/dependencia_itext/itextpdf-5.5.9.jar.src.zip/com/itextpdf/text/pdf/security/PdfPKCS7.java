/*      */ package com.itextpdf.text.pdf.security;
/*      */ 
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.pdf.PdfName;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.math.BigInteger;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.InvalidKeyException;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.security.Principal;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.PublicKey;
/*      */ import java.security.Signature;
/*      */ import java.security.SignatureException;
/*      */ import java.security.cert.CRL;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.X509CRL;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Set;
/*      */ import org.bouncycastle.asn1.ASN1Encodable;
/*      */ import org.bouncycastle.asn1.ASN1EncodableVector;
/*      */ import org.bouncycastle.asn1.ASN1Enumerated;
/*      */ import org.bouncycastle.asn1.ASN1InputStream;
/*      */ import org.bouncycastle.asn1.ASN1Integer;
/*      */ import org.bouncycastle.asn1.ASN1ObjectIdentifier;
/*      */ import org.bouncycastle.asn1.ASN1OctetString;
/*      */ import org.bouncycastle.asn1.ASN1OutputStream;
/*      */ import org.bouncycastle.asn1.ASN1Primitive;
/*      */ import org.bouncycastle.asn1.ASN1Sequence;
/*      */ import org.bouncycastle.asn1.ASN1Set;
/*      */ import org.bouncycastle.asn1.ASN1TaggedObject;
/*      */ import org.bouncycastle.asn1.DERNull;
/*      */ import org.bouncycastle.asn1.DEROctetString;
/*      */ import org.bouncycastle.asn1.DERSequence;
/*      */ import org.bouncycastle.asn1.DERSet;
/*      */ import org.bouncycastle.asn1.DERTaggedObject;
/*      */ import org.bouncycastle.asn1.cms.Attribute;
/*      */ import org.bouncycastle.asn1.cms.AttributeTable;
/*      */ import org.bouncycastle.asn1.cms.ContentInfo;
/*      */ import org.bouncycastle.asn1.ess.ESSCertID;
/*      */ import org.bouncycastle.asn1.ess.ESSCertIDv2;
/*      */ import org.bouncycastle.asn1.ess.SigningCertificate;
/*      */ import org.bouncycastle.asn1.ess.SigningCertificateV2;
/*      */ import org.bouncycastle.asn1.ocsp.BasicOCSPResponse;
/*      */ import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
/*      */ import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
/*      */ import org.bouncycastle.asn1.tsp.MessageImprint;
/*      */ import org.bouncycastle.asn1.tsp.TSTInfo;
/*      */ import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
/*      */ import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
/*      */ import org.bouncycastle.cert.ocsp.BasicOCSPResp;
/*      */ import org.bouncycastle.cert.ocsp.CertificateID;
/*      */ import org.bouncycastle.cert.ocsp.SingleResp;
/*      */ import org.bouncycastle.jce.X509Principal;
/*      */ import org.bouncycastle.jce.provider.X509CertParser;
/*      */ import org.bouncycastle.operator.DigestCalculator;
/*      */ import org.bouncycastle.operator.DigestCalculatorProvider;
/*      */ import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
/*      */ import org.bouncycastle.tsp.TimeStampToken;
/*      */ import org.bouncycastle.tsp.TimeStampTokenInfo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfPKCS7
/*      */ {
/*      */   private String provider;
/*      */   private String signName;
/*      */   private String reason;
/*      */   private String location;
/*      */   private Calendar signDate;
/*      */   
/*      */   public PdfPKCS7(PrivateKey privKey, Certificate[] certChain, String hashAlgorithm, String provider, ExternalDigest interfaceDigest, boolean hasRSAdata)
/*      */     throws InvalidKeyException, NoSuchProviderException, NoSuchAlgorithmException
/*      */   {
/*  144 */     this.provider = provider;
/*  145 */     this.interfaceDigest = interfaceDigest;
/*      */     
/*  147 */     this.digestAlgorithmOid = DigestAlgorithms.getAllowedDigests(hashAlgorithm);
/*  148 */     if (this.digestAlgorithmOid == null) {
/*  149 */       throw new NoSuchAlgorithmException(MessageLocalization.getComposedMessage("unknown.hash.algorithm.1", new Object[] { hashAlgorithm }));
/*      */     }
/*      */     
/*  152 */     this.signCert = ((X509Certificate)certChain[0]);
/*  153 */     this.certs = new ArrayList();
/*  154 */     for (Certificate element : certChain) {
/*  155 */       this.certs.add(element);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  160 */     this.digestalgos = new HashSet();
/*  161 */     this.digestalgos.add(this.digestAlgorithmOid);
/*      */     
/*      */ 
/*  164 */     if (privKey != null) {
/*  165 */       this.digestEncryptionAlgorithmOid = privKey.getAlgorithm();
/*  166 */       if (this.digestEncryptionAlgorithmOid.equals("RSA")) {
/*  167 */         this.digestEncryptionAlgorithmOid = "1.2.840.113549.1.1.1";
/*      */       }
/*  169 */       else if (this.digestEncryptionAlgorithmOid.equals("DSA")) {
/*  170 */         this.digestEncryptionAlgorithmOid = "1.2.840.10040.4.1";
/*      */       }
/*      */       else {
/*  173 */         throw new NoSuchAlgorithmException(MessageLocalization.getComposedMessage("unknown.key.algorithm.1", new Object[] { this.digestEncryptionAlgorithmOid }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  178 */     if (hasRSAdata) {
/*  179 */       this.RSAdata = new byte[0];
/*  180 */       this.messageDigest = DigestAlgorithms.getMessageDigest(getHashAlgorithm(), provider);
/*      */     }
/*      */     
/*      */ 
/*  184 */     if (privKey != null) {
/*  185 */       this.sig = initSignature(privKey);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPKCS7(byte[] contentsKey, byte[] certsKey, String provider)
/*      */   {
/*      */     try
/*      */     {
/*  200 */       this.provider = provider;
/*  201 */       X509CertParser cr = new X509CertParser();
/*  202 */       cr.engineInit(new ByteArrayInputStream(certsKey));
/*  203 */       this.certs = cr.engineReadAll();
/*  204 */       this.signCerts = this.certs;
/*  205 */       this.signCert = ((X509Certificate)this.certs.iterator().next());
/*  206 */       this.crls = new ArrayList();
/*      */       
/*  208 */       ASN1InputStream in = new ASN1InputStream(new ByteArrayInputStream(contentsKey));
/*  209 */       this.digest = ((ASN1OctetString)in.readObject()).getOctets();
/*      */       
/*  211 */       if (provider == null) {
/*  212 */         this.sig = Signature.getInstance("SHA1withRSA");
/*      */       } else {
/*  214 */         this.sig = Signature.getInstance("SHA1withRSA", provider);
/*      */       }
/*      */       
/*  217 */       this.sig.initVerify(this.signCert.getPublicKey());
/*      */       
/*      */ 
/*  220 */       this.digestAlgorithmOid = "1.2.840.10040.4.3";
/*  221 */       this.digestEncryptionAlgorithmOid = "1.3.36.3.3.1.2";
/*      */     } catch (Exception e) {
/*  223 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPKCS7(byte[] contentsKey, PdfName filterSubtype, String provider)
/*      */   {
/*  235 */     this.filterSubtype = filterSubtype;
/*  236 */     this.isTsp = PdfName.ETSI_RFC3161.equals(filterSubtype);
/*  237 */     this.isCades = PdfName.ETSI_CADES_DETACHED.equals(filterSubtype);
/*      */     try {
/*  239 */       this.provider = provider;
/*  240 */       ASN1InputStream din = new ASN1InputStream(new ByteArrayInputStream(contentsKey));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  248 */         pkcs = din.readObject();
/*      */       } catch (IOException e) {
/*      */         ASN1Primitive pkcs;
/*  251 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("can.t.decode.pkcs7signeddata.object", new Object[0])); }
/*      */       ASN1Primitive pkcs;
/*  253 */       if (!(pkcs instanceof ASN1Sequence)) {
/*  254 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("not.a.valid.pkcs.7.object.not.a.sequence", new Object[0]));
/*      */       }
/*  256 */       ASN1Sequence signedData = (ASN1Sequence)pkcs;
/*  257 */       ASN1ObjectIdentifier objId = (ASN1ObjectIdentifier)signedData.getObjectAt(0);
/*  258 */       if (!objId.getId().equals("1.2.840.113549.1.7.2"))
/*  259 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("not.a.valid.pkcs.7.object.not.signed.data", new Object[0]));
/*  260 */       ASN1Sequence content = (ASN1Sequence)((ASN1TaggedObject)signedData.getObjectAt(1)).getObject();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  269 */       this.version = ((ASN1Integer)content.getObjectAt(0)).getValue().intValue();
/*      */       
/*      */ 
/*  272 */       this.digestalgos = new HashSet();
/*  273 */       Enumeration<ASN1Sequence> e = ((ASN1Set)content.getObjectAt(1)).getObjects();
/*  274 */       while (e.hasMoreElements()) {
/*  275 */         ASN1Sequence s = (ASN1Sequence)e.nextElement();
/*  276 */         ASN1ObjectIdentifier o = (ASN1ObjectIdentifier)s.getObjectAt(0);
/*  277 */         this.digestalgos.add(o.getId());
/*      */       }
/*      */       
/*      */ 
/*  281 */       ASN1Sequence rsaData = (ASN1Sequence)content.getObjectAt(2);
/*  282 */       if (rsaData.size() > 1) {
/*  283 */         ASN1OctetString rsaDataContent = (ASN1OctetString)((ASN1TaggedObject)rsaData.getObjectAt(1)).getObject();
/*  284 */         this.RSAdata = rsaDataContent.getOctets();
/*      */       }
/*      */       
/*  287 */       int next = 3;
/*  288 */       while ((content.getObjectAt(next) instanceof ASN1TaggedObject)) {
/*  289 */         next++;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  296 */       X509CertParser cr = new X509CertParser();
/*  297 */       cr.engineInit(new ByteArrayInputStream(contentsKey));
/*  298 */       this.certs = cr.engineReadAll();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  333 */       ASN1Set signerInfos = (ASN1Set)content.getObjectAt(next);
/*  334 */       if (signerInfos.size() != 1)
/*  335 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("this.pkcs.7.object.has.multiple.signerinfos.only.one.is.supported.at.this.time", new Object[0]));
/*  336 */       ASN1Sequence signerInfo = (ASN1Sequence)signerInfos.getObjectAt(0);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  343 */       this.signerversion = ((ASN1Integer)signerInfo.getObjectAt(0)).getValue().intValue();
/*      */       
/*  345 */       ASN1Sequence issuerAndSerialNumber = (ASN1Sequence)signerInfo.getObjectAt(1);
/*  346 */       X509Principal issuer = new X509Principal(issuerAndSerialNumber.getObjectAt(0).toASN1Primitive().getEncoded());
/*  347 */       BigInteger serialNumber = ((ASN1Integer)issuerAndSerialNumber.getObjectAt(1)).getValue();
/*  348 */       for (Object element : this.certs) {
/*  349 */         X509Certificate cert = (X509Certificate)element;
/*  350 */         if ((cert.getIssuerDN().equals(issuer)) && (serialNumber.equals(cert.getSerialNumber()))) {
/*  351 */           this.signCert = cert;
/*  352 */           break;
/*      */         }
/*      */       }
/*  355 */       if (this.signCert == null) {
/*  356 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("can.t.find.signing.certificate.with.serial.1", new Object[] {issuer
/*  357 */           .getName() + " / " + serialNumber.toString(16) }));
/*      */       }
/*  359 */       signCertificateChain();
/*  360 */       this.digestAlgorithmOid = ((ASN1ObjectIdentifier)((ASN1Sequence)signerInfo.getObjectAt(2)).getObjectAt(0)).getId();
/*  361 */       next = 3;
/*  362 */       boolean foundCades = false;
/*  363 */       if ((signerInfo.getObjectAt(next) instanceof ASN1TaggedObject)) {
/*  364 */         ASN1TaggedObject tagsig = (ASN1TaggedObject)signerInfo.getObjectAt(next);
/*  365 */         ASN1Set sseq = ASN1Set.getInstance(tagsig, false);
/*  366 */         this.sigAttr = sseq.getEncoded();
/*      */         
/*  368 */         this.sigAttrDer = sseq.getEncoded("DER");
/*      */         
/*  370 */         for (int k = 0; k < sseq.size(); k++) {
/*  371 */           ASN1Sequence seq2 = (ASN1Sequence)sseq.getObjectAt(k);
/*  372 */           String idSeq2 = ((ASN1ObjectIdentifier)seq2.getObjectAt(0)).getId();
/*  373 */           if (idSeq2.equals("1.2.840.113549.1.9.4")) {
/*  374 */             ASN1Set set = (ASN1Set)seq2.getObjectAt(1);
/*  375 */             this.digestAttr = ((ASN1OctetString)set.getObjectAt(0)).getOctets();
/*      */           }
/*  377 */           else if (idSeq2.equals("1.2.840.113583.1.1.8")) {
/*  378 */             ASN1Set setout = (ASN1Set)seq2.getObjectAt(1);
/*  379 */             ASN1Sequence seqout = (ASN1Sequence)setout.getObjectAt(0);
/*  380 */             for (int j = 0; j < seqout.size(); j++) {
/*  381 */               ASN1TaggedObject tg = (ASN1TaggedObject)seqout.getObjectAt(j);
/*  382 */               if (tg.getTagNo() == 0) {
/*  383 */                 ASN1Sequence seqin = (ASN1Sequence)tg.getObject();
/*  384 */                 findCRL(seqin);
/*      */               }
/*  386 */               if (tg.getTagNo() == 1) {
/*  387 */                 ASN1Sequence seqin = (ASN1Sequence)tg.getObject();
/*  388 */                 findOcsp(seqin);
/*      */               }
/*      */             }
/*      */           }
/*  392 */           else if ((this.isCades) && (idSeq2.equals("1.2.840.113549.1.9.16.2.12"))) {
/*  393 */             ASN1Set setout = (ASN1Set)seq2.getObjectAt(1);
/*  394 */             ASN1Sequence seqout = (ASN1Sequence)setout.getObjectAt(0);
/*  395 */             SigningCertificate sv2 = SigningCertificate.getInstance(seqout);
/*  396 */             ESSCertID[] cerv2m = sv2.getCerts();
/*  397 */             ESSCertID cerv2 = cerv2m[0];
/*  398 */             byte[] enc2 = this.signCert.getEncoded();
/*  399 */             MessageDigest m2 = new BouncyCastleDigest().getMessageDigest("SHA-1");
/*  400 */             byte[] signCertHash = m2.digest(enc2);
/*  401 */             byte[] hs2 = cerv2.getCertHash();
/*  402 */             if (!Arrays.equals(signCertHash, hs2))
/*  403 */               throw new IllegalArgumentException("Signing certificate doesn't match the ESS information.");
/*  404 */             foundCades = true;
/*      */           }
/*  406 */           else if ((this.isCades) && (idSeq2.equals("1.2.840.113549.1.9.16.2.47"))) {
/*  407 */             ASN1Set setout = (ASN1Set)seq2.getObjectAt(1);
/*  408 */             ASN1Sequence seqout = (ASN1Sequence)setout.getObjectAt(0);
/*  409 */             SigningCertificateV2 sv2 = SigningCertificateV2.getInstance(seqout);
/*  410 */             ESSCertIDv2[] cerv2m = sv2.getCerts();
/*  411 */             ESSCertIDv2 cerv2 = cerv2m[0];
/*  412 */             AlgorithmIdentifier ai2 = cerv2.getHashAlgorithm();
/*  413 */             byte[] enc2 = this.signCert.getEncoded();
/*  414 */             MessageDigest m2 = new BouncyCastleDigest().getMessageDigest(DigestAlgorithms.getDigest(ai2.getAlgorithm().getId()));
/*  415 */             byte[] signCertHash = m2.digest(enc2);
/*  416 */             byte[] hs2 = cerv2.getCertHash();
/*  417 */             if (!Arrays.equals(signCertHash, hs2))
/*  418 */               throw new IllegalArgumentException("Signing certificate doesn't match the ESS information.");
/*  419 */             foundCades = true;
/*      */           }
/*      */         }
/*  422 */         if (this.digestAttr == null)
/*  423 */           throw new IllegalArgumentException(MessageLocalization.getComposedMessage("authenticated.attribute.is.missing.the.digest", new Object[0]));
/*  424 */         next++;
/*      */       }
/*  426 */       if ((this.isCades) && (!foundCades))
/*  427 */         throw new IllegalArgumentException("CAdES ESS information missing.");
/*  428 */       this.digestEncryptionAlgorithmOid = ((ASN1ObjectIdentifier)((ASN1Sequence)signerInfo.getObjectAt(next++)).getObjectAt(0)).getId();
/*  429 */       this.digest = ((ASN1OctetString)signerInfo.getObjectAt(next++)).getOctets();
/*  430 */       if ((next < signerInfo.size()) && ((signerInfo.getObjectAt(next) instanceof ASN1TaggedObject))) {
/*  431 */         ASN1TaggedObject taggedObject = (ASN1TaggedObject)signerInfo.getObjectAt(next);
/*  432 */         ASN1Set unat = ASN1Set.getInstance(taggedObject, false);
/*  433 */         AttributeTable attble = new AttributeTable(unat);
/*  434 */         Attribute ts = attble.get(PKCSObjectIdentifiers.id_aa_signatureTimeStampToken);
/*  435 */         if ((ts != null) && (ts.getAttrValues().size() > 0)) {
/*  436 */           ASN1Set attributeValues = ts.getAttrValues();
/*  437 */           ASN1Sequence tokenSequence = ASN1Sequence.getInstance(attributeValues.getObjectAt(0));
/*  438 */           ContentInfo contentInfo = new ContentInfo(tokenSequence);
/*  439 */           this.timeStampToken = new TimeStampToken(contentInfo);
/*      */         }
/*      */       }
/*  442 */       if (this.isTsp) {
/*  443 */         ContentInfo contentInfoTsp = new ContentInfo(signedData);
/*  444 */         this.timeStampToken = new TimeStampToken(contentInfoTsp);
/*  445 */         TimeStampTokenInfo info = this.timeStampToken.getTimeStampInfo();
/*  446 */         String algOID = info.getMessageImprintAlgOID().getId();
/*  447 */         this.messageDigest = DigestAlgorithms.getMessageDigestFromOid(algOID, null);
/*      */       }
/*      */       else {
/*  450 */         if ((this.RSAdata != null) || (this.digestAttr != null)) {
/*  451 */           if (PdfName.ADBE_PKCS7_SHA1.equals(getFilterSubtype())) {
/*  452 */             this.messageDigest = DigestAlgorithms.getMessageDigest("SHA1", provider);
/*      */           }
/*      */           else {
/*  455 */             this.messageDigest = DigestAlgorithms.getMessageDigest(getHashAlgorithm(), provider);
/*      */           }
/*  457 */           this.encContDigest = DigestAlgorithms.getMessageDigest(getHashAlgorithm(), provider);
/*      */         }
/*  459 */         this.sig = initSignature(this.signCert.getPublicKey());
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  463 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSignName()
/*      */   {
/*  491 */     return this.signName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSignName(String signName)
/*      */   {
/*  499 */     this.signName = signName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReason()
/*      */   {
/*  507 */     return this.reason;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReason(String reason)
/*      */   {
/*  515 */     this.reason = reason;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocation()
/*      */   {
/*  523 */     return this.location;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocation(String location)
/*      */   {
/*  531 */     this.location = location;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Calendar getSignDate()
/*      */   {
/*  539 */     Calendar dt = getTimeStampDate();
/*  540 */     if (dt == null) {
/*  541 */       return this.signDate;
/*      */     }
/*  543 */     return dt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSignDate(Calendar signDate)
/*      */   {
/*  551 */     this.signDate = signDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  557 */   private int version = 1;
/*      */   
/*      */ 
/*  560 */   private int signerversion = 1;
/*      */   private String digestAlgorithmOid;
/*      */   private MessageDigest messageDigest;
/*      */   private Set<String> digestalgos;
/*      */   
/*      */   public int getVersion()
/*      */   {
/*  567 */     return this.version;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSigningInfoVersion()
/*      */   {
/*  575 */     return this.signerversion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] digestAttr;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PdfName filterSubtype;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String digestEncryptionAlgorithmOid;
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDigestAlgorithmOid()
/*      */   {
/*  598 */     return this.digestAlgorithmOid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHashAlgorithm()
/*      */   {
/*  606 */     return DigestAlgorithms.getDigest(this.digestAlgorithmOid);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDigestEncryptionAlgorithmOid()
/*      */   {
/*  618 */     return this.digestEncryptionAlgorithmOid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDigestAlgorithm()
/*      */   {
/*  626 */     return getHashAlgorithm() + "with" + getEncryptionAlgorithm();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private ExternalDigest interfaceDigest;
/*      */   
/*      */ 
/*      */   private byte[] externalDigest;
/*      */   
/*      */ 
/*      */   private byte[] externalRSAdata;
/*      */   
/*      */ 
/*      */   private Signature sig;
/*      */   
/*      */ 
/*      */   private byte[] digest;
/*      */   
/*      */ 
/*      */   private byte[] RSAdata;
/*      */   
/*      */ 
/*      */   public void setExternalDigest(byte[] digest, byte[] RSAdata, String digestEncryptionAlgorithm)
/*      */   {
/*  651 */     this.externalDigest = digest;
/*  652 */     this.externalRSAdata = RSAdata;
/*  653 */     if (digestEncryptionAlgorithm != null) {
/*  654 */       if (digestEncryptionAlgorithm.equals("RSA")) {
/*  655 */         this.digestEncryptionAlgorithmOid = "1.2.840.113549.1.1.1";
/*      */       }
/*  657 */       else if (digestEncryptionAlgorithm.equals("DSA")) {
/*  658 */         this.digestEncryptionAlgorithmOid = "1.2.840.10040.4.1";
/*      */       }
/*  660 */       else if (digestEncryptionAlgorithm.equals("ECDSA")) {
/*  661 */         this.digestEncryptionAlgorithmOid = "1.2.840.10045.2.1";
/*      */       }
/*      */       else {
/*  664 */         throw new ExceptionConverter(new NoSuchAlgorithmException(MessageLocalization.getComposedMessage("unknown.key.algorithm.1", new Object[] { digestEncryptionAlgorithm })));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Signature initSignature(PrivateKey key)
/*      */     throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
/*      */   {
/*      */     Signature signature;
/*      */     
/*      */ 
/*      */ 
/*      */     Signature signature;
/*      */     
/*      */ 
/*      */ 
/*  683 */     if (this.provider == null) {
/*  684 */       signature = Signature.getInstance(getDigestAlgorithm());
/*      */     } else
/*  686 */       signature = Signature.getInstance(getDigestAlgorithm(), this.provider);
/*  687 */     signature.initSign(key);
/*  688 */     return signature;
/*      */   }
/*      */   
/*      */   private Signature initSignature(PublicKey key) throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException {
/*  692 */     String digestAlgorithm = getDigestAlgorithm();
/*  693 */     if (PdfName.ADBE_X509_RSA_SHA1.equals(getFilterSubtype()))
/*  694 */       digestAlgorithm = "SHA1withRSA";
/*      */     Signature signature;
/*  696 */     Signature signature; if (this.provider == null) {
/*  697 */       signature = Signature.getInstance(digestAlgorithm);
/*      */     } else {
/*  699 */       signature = Signature.getInstance(digestAlgorithm, this.provider);
/*      */     }
/*  701 */     signature.initVerify(key);
/*  702 */     return signature;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void update(byte[] buf, int off, int len)
/*      */     throws SignatureException
/*      */   {
/*  714 */     if ((this.RSAdata != null) || (this.digestAttr != null) || (this.isTsp)) {
/*  715 */       this.messageDigest.update(buf, off, len);
/*      */     } else {
/*  717 */       this.sig.update(buf, off, len);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getEncodedPKCS1()
/*      */   {
/*      */     try
/*      */     {
/*  728 */       if (this.externalDigest != null) {
/*  729 */         this.digest = this.externalDigest;
/*      */       } else
/*  731 */         this.digest = this.sig.sign();
/*  732 */       ByteArrayOutputStream bOut = new ByteArrayOutputStream();
/*      */       
/*  734 */       ASN1OutputStream dout = new ASN1OutputStream(bOut);
/*  735 */       dout.writeObject(new DEROctetString(this.digest));
/*  736 */       dout.close();
/*      */       
/*  738 */       return bOut.toByteArray();
/*      */     }
/*      */     catch (Exception e) {
/*  741 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getEncodedPKCS7()
/*      */   {
/*  752 */     return getEncodedPKCS7(null, null, null, null, MakeSignature.CryptoStandard.CMS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getEncodedPKCS7(byte[] secondDigest)
/*      */   {
/*  762 */     return getEncodedPKCS7(secondDigest, null, null, null, MakeSignature.CryptoStandard.CMS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getEncodedPKCS7(byte[] secondDigest, TSAClient tsaClient, byte[] ocsp, Collection<byte[]> crlBytes, MakeSignature.CryptoStandard sigtype)
/*      */   {
/*      */     try
/*      */     {
/*  776 */       if (this.externalDigest != null) {
/*  777 */         this.digest = this.externalDigest;
/*  778 */         if (this.RSAdata != null) {
/*  779 */           this.RSAdata = this.externalRSAdata;
/*      */         }
/*  781 */       } else if ((this.externalRSAdata != null) && (this.RSAdata != null)) {
/*  782 */         this.RSAdata = this.externalRSAdata;
/*  783 */         this.sig.update(this.RSAdata);
/*  784 */         this.digest = this.sig.sign();
/*      */       }
/*      */       else {
/*  787 */         if (this.RSAdata != null) {
/*  788 */           this.RSAdata = this.messageDigest.digest();
/*  789 */           this.sig.update(this.RSAdata);
/*      */         }
/*  791 */         this.digest = this.sig.sign();
/*      */       }
/*      */       
/*      */ 
/*  795 */       ASN1EncodableVector digestAlgorithms = new ASN1EncodableVector();
/*  796 */       for (Object element : this.digestalgos) {
/*  797 */         algos = new ASN1EncodableVector();
/*  798 */         algos.add(new ASN1ObjectIdentifier((String)element));
/*  799 */         algos.add(DERNull.INSTANCE);
/*  800 */         digestAlgorithms.add(new DERSequence(algos));
/*      */       }
/*      */       
/*      */       ASN1EncodableVector algos;
/*  804 */       ASN1EncodableVector v = new ASN1EncodableVector();
/*  805 */       v.add(new ASN1ObjectIdentifier("1.2.840.113549.1.7.1"));
/*  806 */       if (this.RSAdata != null)
/*  807 */         v.add(new DERTaggedObject(0, new DEROctetString(this.RSAdata)));
/*  808 */       DERSequence contentinfo = new DERSequence(v);
/*      */       
/*      */ 
/*      */ 
/*  812 */       v = new ASN1EncodableVector();
/*  813 */       for (Object element : this.certs) {
/*  814 */         ASN1InputStream tempstream = new ASN1InputStream(new ByteArrayInputStream(((X509Certificate)element).getEncoded()));
/*  815 */         v.add(tempstream.readObject());
/*      */       }
/*      */       
/*  818 */       DERSet dercertificates = new DERSet(v);
/*      */       
/*      */ 
/*      */ 
/*  822 */       ASN1EncodableVector signerinfo = new ASN1EncodableVector();
/*      */       
/*      */ 
/*      */ 
/*  826 */       signerinfo.add(new ASN1Integer(this.signerversion));
/*      */       
/*  828 */       v = new ASN1EncodableVector();
/*  829 */       v.add(CertificateInfo.getIssuer(this.signCert.getTBSCertificate()));
/*  830 */       v.add(new ASN1Integer(this.signCert.getSerialNumber()));
/*  831 */       signerinfo.add(new DERSequence(v));
/*      */       
/*      */ 
/*  834 */       v = new ASN1EncodableVector();
/*  835 */       v.add(new ASN1ObjectIdentifier(this.digestAlgorithmOid));
/*  836 */       v.add(new DERNull());
/*  837 */       signerinfo.add(new DERSequence(v));
/*      */       
/*      */ 
/*  840 */       if (secondDigest != null) {
/*  841 */         signerinfo.add(new DERTaggedObject(false, 0, getAuthenticatedAttributeSet(secondDigest, ocsp, crlBytes, sigtype)));
/*      */       }
/*      */       
/*  844 */       v = new ASN1EncodableVector();
/*  845 */       v.add(new ASN1ObjectIdentifier(this.digestEncryptionAlgorithmOid));
/*  846 */       v.add(new DERNull());
/*  847 */       signerinfo.add(new DERSequence(v));
/*      */       
/*      */ 
/*  850 */       signerinfo.add(new DEROctetString(this.digest));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  855 */       if (tsaClient != null) {
/*  856 */         byte[] tsImprint = tsaClient.getMessageDigest().digest(this.digest);
/*  857 */         byte[] tsToken = tsaClient.getTimeStampToken(tsImprint);
/*  858 */         if (tsToken != null) {
/*  859 */           ASN1EncodableVector unauthAttributes = buildUnauthenticatedAttributes(tsToken);
/*  860 */           if (unauthAttributes != null) {
/*  861 */             signerinfo.add(new DERTaggedObject(false, 1, new DERSet(unauthAttributes)));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  867 */       ASN1EncodableVector body = new ASN1EncodableVector();
/*  868 */       body.add(new ASN1Integer(this.version));
/*  869 */       body.add(new DERSet(digestAlgorithms));
/*  870 */       body.add(contentinfo);
/*  871 */       body.add(new DERTaggedObject(false, 0, dercertificates));
/*      */       
/*      */ 
/*  874 */       body.add(new DERSet(new DERSequence(signerinfo)));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  879 */       ASN1EncodableVector whole = new ASN1EncodableVector();
/*  880 */       whole.add(new ASN1ObjectIdentifier("1.2.840.113549.1.7.2"));
/*  881 */       whole.add(new DERTaggedObject(0, new DERSequence(body)));
/*      */       
/*  883 */       ByteArrayOutputStream bOut = new ByteArrayOutputStream();
/*      */       
/*  885 */       ASN1OutputStream dout = new ASN1OutputStream(bOut);
/*  886 */       dout.writeObject(new DERSequence(whole));
/*  887 */       dout.close();
/*      */       
/*  889 */       return bOut.toByteArray();
/*      */     }
/*      */     catch (Exception e) {
/*  892 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ASN1EncodableVector buildUnauthenticatedAttributes(byte[] timeStampToken)
/*      */     throws IOException
/*      */   {
/*  906 */     if (timeStampToken == null) {
/*  907 */       return null;
/*      */     }
/*      */     
/*  910 */     String ID_TIME_STAMP_TOKEN = "1.2.840.113549.1.9.16.2.14";
/*      */     
/*  912 */     ASN1InputStream tempstream = new ASN1InputStream(new ByteArrayInputStream(timeStampToken));
/*  913 */     ASN1EncodableVector unauthAttributes = new ASN1EncodableVector();
/*      */     
/*  915 */     ASN1EncodableVector v = new ASN1EncodableVector();
/*  916 */     v.add(new ASN1ObjectIdentifier(ID_TIME_STAMP_TOKEN));
/*  917 */     ASN1Sequence seq = (ASN1Sequence)tempstream.readObject();
/*  918 */     v.add(new DERSet(seq));
/*      */     
/*  920 */     unauthAttributes.add(new DERSequence(v));
/*  921 */     return unauthAttributes;
/*      */   }
/*      */   
/*      */ 
/*      */   private byte[] sigAttr;
/*      */   
/*      */   private byte[] sigAttrDer;
/*      */   
/*      */   private MessageDigest encContDigest;
/*      */   
/*      */   private boolean verified;
/*      */   
/*      */   private boolean verifyResult;
/*      */   
/*      */   private Collection<Certificate> certs;
/*      */   
/*      */   private Collection<Certificate> signCerts;
/*      */   
/*      */   private X509Certificate signCert;
/*      */   
/*      */   private Collection<CRL> crls;
/*      */   
/*      */   private BasicOCSPResp basicResp;
/*      */   
/*      */   private boolean isTsp;
/*      */   
/*      */   private boolean isCades;
/*      */   
/*      */   private TimeStampToken timeStampToken;
/*      */   public byte[] getAuthenticatedAttributeBytes(byte[] secondDigest, byte[] ocsp, Collection<byte[]> crlBytes, MakeSignature.CryptoStandard sigtype)
/*      */   {
/*      */     try
/*      */     {
/*  954 */       return getAuthenticatedAttributeSet(secondDigest, ocsp, crlBytes, sigtype).getEncoded("DER");
/*      */     }
/*      */     catch (Exception e) {
/*  957 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DERSet getAuthenticatedAttributeSet(byte[] secondDigest, byte[] ocsp, Collection<byte[]> crlBytes, MakeSignature.CryptoStandard sigtype)
/*      */   {
/*      */     try
/*      */     {
/*  970 */       ASN1EncodableVector attribute = new ASN1EncodableVector();
/*  971 */       ASN1EncodableVector v = new ASN1EncodableVector();
/*  972 */       v.add(new ASN1ObjectIdentifier("1.2.840.113549.1.9.3"));
/*  973 */       v.add(new DERSet(new ASN1ObjectIdentifier("1.2.840.113549.1.7.1")));
/*  974 */       attribute.add(new DERSequence(v));
/*  975 */       v = new ASN1EncodableVector();
/*  976 */       v.add(new ASN1ObjectIdentifier("1.2.840.113549.1.9.4"));
/*  977 */       v.add(new DERSet(new DEROctetString(secondDigest)));
/*  978 */       attribute.add(new DERSequence(v));
/*  979 */       boolean haveCrl = false;
/*  980 */       if (crlBytes != null) {
/*  981 */         for (byte[] bCrl : crlBytes) {
/*  982 */           if (bCrl != null) {
/*  983 */             haveCrl = true;
/*  984 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  988 */       if ((ocsp != null) || (haveCrl)) {
/*  989 */         v = new ASN1EncodableVector();
/*  990 */         v.add(new ASN1ObjectIdentifier("1.2.840.113583.1.1.8"));
/*      */         
/*  992 */         ASN1EncodableVector revocationV = new ASN1EncodableVector();
/*      */         
/*  994 */         if (haveCrl) {
/*  995 */           ASN1EncodableVector v2 = new ASN1EncodableVector();
/*  996 */           for (byte[] bCrl : crlBytes)
/*  997 */             if (bCrl != null)
/*      */             {
/*  999 */               ASN1InputStream t = new ASN1InputStream(new ByteArrayInputStream(bCrl));
/* 1000 */               v2.add(t.readObject());
/*      */             }
/* 1002 */           revocationV.add(new DERTaggedObject(true, 0, new DERSequence(v2)));
/*      */         }
/*      */         
/* 1005 */         if (ocsp != null) {
/* 1006 */           DEROctetString doctet = new DEROctetString(ocsp);
/* 1007 */           ASN1EncodableVector vo1 = new ASN1EncodableVector();
/* 1008 */           ASN1EncodableVector v2 = new ASN1EncodableVector();
/* 1009 */           v2.add(OCSPObjectIdentifiers.id_pkix_ocsp_basic);
/* 1010 */           v2.add(doctet);
/* 1011 */           ASN1Enumerated den = new ASN1Enumerated(0);
/* 1012 */           ASN1EncodableVector v3 = new ASN1EncodableVector();
/* 1013 */           v3.add(den);
/* 1014 */           v3.add(new DERTaggedObject(true, 0, new DERSequence(v2)));
/* 1015 */           vo1.add(new DERSequence(v3));
/* 1016 */           revocationV.add(new DERTaggedObject(true, 1, new DERSequence(vo1)));
/*      */         }
/*      */         
/* 1019 */         v.add(new DERSet(new DERSequence(revocationV)));
/* 1020 */         attribute.add(new DERSequence(v));
/*      */       }
/* 1022 */       if (sigtype == MakeSignature.CryptoStandard.CADES) {
/* 1023 */         v = new ASN1EncodableVector();
/* 1024 */         v.add(new ASN1ObjectIdentifier("1.2.840.113549.1.9.16.2.47"));
/*      */         
/* 1026 */         ASN1EncodableVector aaV2 = new ASN1EncodableVector();
/* 1027 */         String sha256Oid = DigestAlgorithms.getAllowedDigests("SHA-256");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1032 */         if (!sha256Oid.equals(this.digestAlgorithmOid)) {
/* 1033 */           AlgorithmIdentifier algoId = new AlgorithmIdentifier(new ASN1ObjectIdentifier(this.digestAlgorithmOid));
/* 1034 */           aaV2.add(algoId);
/*      */         }
/*      */         
/* 1037 */         MessageDigest md = this.interfaceDigest.getMessageDigest(getHashAlgorithm());
/* 1038 */         byte[] dig = md.digest(this.signCert.getEncoded());
/* 1039 */         aaV2.add(new DEROctetString(dig));
/*      */         
/* 1041 */         v.add(new DERSet(new DERSequence(new DERSequence(new DERSequence(aaV2)))));
/* 1042 */         attribute.add(new DERSequence(v));
/*      */       }
/*      */       
/* 1045 */       return new DERSet(attribute);
/*      */     }
/*      */     catch (Exception e) {
/* 1048 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean verify()
/*      */     throws GeneralSecurityException
/*      */   {
/* 1080 */     if (this.verified)
/* 1081 */       return this.verifyResult;
/* 1082 */     if (this.isTsp) {
/* 1083 */       TimeStampTokenInfo info = this.timeStampToken.getTimeStampInfo();
/* 1084 */       MessageImprint imprint = info.toASN1Structure().getMessageImprint();
/* 1085 */       byte[] md = this.messageDigest.digest();
/* 1086 */       byte[] imphashed = imprint.getHashedMessage();
/* 1087 */       this.verifyResult = Arrays.equals(md, imphashed);
/*      */ 
/*      */     }
/* 1090 */     else if ((this.sigAttr != null) || (this.sigAttrDer != null)) {
/* 1091 */       byte[] msgDigestBytes = this.messageDigest.digest();
/* 1092 */       boolean verifyRSAdata = true;
/*      */       
/* 1094 */       boolean encContDigestCompare = false;
/* 1095 */       if (this.RSAdata != null) {
/* 1096 */         verifyRSAdata = Arrays.equals(msgDigestBytes, this.RSAdata);
/* 1097 */         this.encContDigest.update(this.RSAdata);
/* 1098 */         encContDigestCompare = Arrays.equals(this.encContDigest.digest(), this.digestAttr);
/*      */       }
/* 1100 */       boolean absentEncContDigestCompare = Arrays.equals(msgDigestBytes, this.digestAttr);
/* 1101 */       boolean concludingDigestCompare = (absentEncContDigestCompare) || (encContDigestCompare);
/* 1102 */       boolean sigVerify = (verifySigAttributes(this.sigAttr)) || (verifySigAttributes(this.sigAttrDer));
/* 1103 */       this.verifyResult = ((concludingDigestCompare) && (sigVerify) && (verifyRSAdata));
/*      */     }
/*      */     else {
/* 1106 */       if (this.RSAdata != null)
/* 1107 */         this.sig.update(this.messageDigest.digest());
/* 1108 */       this.verifyResult = this.sig.verify(this.digest);
/*      */     }
/*      */     
/* 1111 */     this.verified = true;
/* 1112 */     return this.verifyResult;
/*      */   }
/*      */   
/*      */   private boolean verifySigAttributes(byte[] attr) throws GeneralSecurityException {
/* 1116 */     Signature signature = initSignature(this.signCert.getPublicKey());
/* 1117 */     signature.update(attr);
/* 1118 */     return signature.verify(this.digest);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean verifyTimestampImprint()
/*      */     throws GeneralSecurityException
/*      */   {
/* 1128 */     if (this.timeStampToken == null)
/* 1129 */       return false;
/* 1130 */     TimeStampTokenInfo info = this.timeStampToken.getTimeStampInfo();
/* 1131 */     MessageImprint imprint = info.toASN1Structure().getMessageImprint();
/* 1132 */     String algOID = info.getMessageImprintAlgOID().getId();
/* 1133 */     byte[] md = new BouncyCastleDigest().getMessageDigest(DigestAlgorithms.getDigest(algOID)).digest(this.digest);
/* 1134 */     byte[] imphashed = imprint.getHashedMessage();
/* 1135 */     boolean res = Arrays.equals(md, imphashed);
/* 1136 */     return res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Certificate[] getCertificates()
/*      */   {
/* 1156 */     return (Certificate[])this.certs.toArray(new X509Certificate[this.certs.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Certificate[] getSignCertificateChain()
/*      */   {
/* 1167 */     return (Certificate[])this.signCerts.toArray(new X509Certificate[this.signCerts.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public X509Certificate getSigningCertificate()
/*      */   {
/* 1175 */     return this.signCert;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void signCertificateChain()
/*      */   {
/* 1184 */     ArrayList<Certificate> cc = new ArrayList();
/* 1185 */     cc.add(this.signCert);
/* 1186 */     ArrayList<Certificate> oc = new ArrayList(this.certs);
/* 1187 */     for (int k = 0; k < oc.size(); k++) {
/* 1188 */       if (this.signCert.equals(oc.get(k))) {
/* 1189 */         oc.remove(k);
/* 1190 */         k--;
/*      */       }
/*      */     }
/*      */     
/* 1194 */     boolean found = true;
/* 1195 */     while (found) {
/* 1196 */       X509Certificate v = (X509Certificate)cc.get(cc.size() - 1);
/* 1197 */       found = false;
/* 1198 */       for (int k = 0; k < oc.size(); k++) {
/* 1199 */         X509Certificate issuer = (X509Certificate)oc.get(k);
/*      */         try {
/* 1201 */           if (this.provider == null) {
/* 1202 */             v.verify(issuer.getPublicKey());
/*      */           } else
/* 1204 */             v.verify(issuer.getPublicKey(), this.provider);
/* 1205 */           found = true;
/* 1206 */           cc.add(oc.get(k));
/* 1207 */           oc.remove(k);
/*      */         }
/*      */         catch (Exception localException) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1214 */     this.signCerts = cc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<CRL> getCRLs()
/*      */   {
/* 1226 */     return this.crls;
/*      */   }
/*      */   
/*      */ 
/*      */   private void findCRL(ASN1Sequence seq)
/*      */   {
/*      */     try
/*      */     {
/* 1234 */       this.crls = new ArrayList();
/* 1235 */       for (int k = 0; k < seq.size(); k++) {
/* 1236 */         ByteArrayInputStream ar = new ByteArrayInputStream(seq.getObjectAt(k).toASN1Primitive().getEncoded("DER"));
/* 1237 */         CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 1238 */         X509CRL crl = (X509CRL)cf.generateCRL(ar);
/* 1239 */         this.crls.add(crl);
/*      */       }
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BasicOCSPResp getOcsp()
/*      */   {
/* 1258 */     return this.basicResp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRevocationValid()
/*      */   {
/* 1267 */     if (this.basicResp == null)
/* 1268 */       return false;
/* 1269 */     if (this.signCerts.size() < 2)
/* 1270 */       return false;
/*      */     try {
/* 1272 */       X509Certificate[] cs = (X509Certificate[])getSignCertificateChain();
/* 1273 */       SingleResp sr = this.basicResp.getResponses()[0];
/* 1274 */       CertificateID cid = sr.getCertID();
/* 1275 */       DigestCalculator digestalg = new JcaDigestCalculatorProviderBuilder().build().get(new AlgorithmIdentifier(cid.getHashAlgOID(), DERNull.INSTANCE));
/* 1276 */       X509Certificate sigcer = getSigningCertificate();
/* 1277 */       X509Certificate isscer = cs[1];
/*      */       
/* 1279 */       CertificateID tis = new CertificateID(digestalg, new JcaX509CertificateHolder(isscer), sigcer.getSerialNumber());
/* 1280 */       return tis.equals(cid);
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/* 1284 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void findOcsp(ASN1Sequence seq)
/*      */     throws IOException
/*      */   {
/* 1293 */     this.basicResp = null;
/* 1294 */     boolean ret = false;
/*      */     
/* 1296 */     while ((!(seq.getObjectAt(0) instanceof ASN1ObjectIdentifier)) || 
/* 1297 */       (!((ASN1ObjectIdentifier)seq.getObjectAt(0)).getId().equals(OCSPObjectIdentifiers.id_pkix_ocsp_basic.getId())))
/*      */     {
/*      */ 
/* 1300 */       ret = true;
/* 1301 */       for (int k = 0; k < seq.size(); k++) {
/* 1302 */         if ((seq.getObjectAt(k) instanceof ASN1Sequence)) {
/* 1303 */           seq = (ASN1Sequence)seq.getObjectAt(0);
/* 1304 */           ret = false;
/* 1305 */           break;
/*      */         }
/* 1307 */         if ((seq.getObjectAt(k) instanceof ASN1TaggedObject)) {
/* 1308 */           ASN1TaggedObject tag = (ASN1TaggedObject)seq.getObjectAt(k);
/* 1309 */           if ((tag.getObject() instanceof ASN1Sequence)) {
/* 1310 */             seq = (ASN1Sequence)tag.getObject();
/* 1311 */             ret = false;
/* 1312 */             break;
/*      */           }
/*      */           
/* 1315 */           return;
/*      */         }
/*      */       }
/* 1318 */       if (ret)
/* 1319 */         return;
/*      */     }
/* 1321 */     ASN1OctetString os = (ASN1OctetString)seq.getObjectAt(1);
/* 1322 */     ASN1InputStream inp = new ASN1InputStream(os.getOctets());
/* 1323 */     BasicOCSPResponse resp = BasicOCSPResponse.getInstance(inp.readObject());
/* 1324 */     this.basicResp = new BasicOCSPResp(resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTsp()
/*      */   {
/* 1343 */     return this.isTsp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeStampToken getTimeStampToken()
/*      */   {
/* 1352 */     return this.timeStampToken;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Calendar getTimeStampDate()
/*      */   {
/* 1361 */     if (this.timeStampToken == null)
/* 1362 */       return null;
/* 1363 */     Calendar cal = new GregorianCalendar();
/* 1364 */     Date date = this.timeStampToken.getTimeStampInfo().getGenTime();
/* 1365 */     cal.setTime(date);
/* 1366 */     return cal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public PdfName getFilterSubtype()
/*      */   {
/* 1373 */     return this.filterSubtype;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncryptionAlgorithm()
/*      */   {
/* 1381 */     String encryptAlgo = EncryptionAlgorithms.getAlgorithm(this.digestEncryptionAlgorithmOid);
/* 1382 */     if (encryptAlgo == null)
/* 1383 */       encryptAlgo = this.digestEncryptionAlgorithmOid;
/* 1384 */     return encryptAlgo;
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/PdfPKCS7.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */