/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathPaintingRenderInfo
/*     */ {
/*     */   public static final int NONZERO_WINDING_RULE = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int EVEN_ODD_RULE = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int NO_OP = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int STROKE = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int FILL = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int operation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rule;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private GraphicsState gs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathPaintingRenderInfo(int operation, int rule, GraphicsState gs)
/*     */   {
/* 102 */     this.operation = operation;
/* 103 */     this.rule = rule;
/* 104 */     this.gs = gs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathPaintingRenderInfo(int operation, GraphicsState gs)
/*     */   {
/* 114 */     this(operation, 1, gs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOperation()
/*     */   {
/* 122 */     return this.operation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRule()
/*     */   {
/* 129 */     return this.rule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Matrix getCtm()
/*     */   {
/* 136 */     return this.gs.ctm;
/*     */   }
/*     */   
/*     */   public float getLineWidth() {
/* 140 */     return this.gs.getLineWidth();
/*     */   }
/*     */   
/*     */   public int getLineCapStyle() {
/* 144 */     return this.gs.getLineCapStyle();
/*     */   }
/*     */   
/*     */   public int getLineJoinStyle() {
/* 148 */     return this.gs.getLineJoinStyle();
/*     */   }
/*     */   
/*     */   public float getMiterLimit() {
/* 152 */     return this.gs.getMiterLimit();
/*     */   }
/*     */   
/*     */   public LineDashPattern getLineDashPattern() {
/* 156 */     return this.gs.getLineDashPattern();
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/PathPaintingRenderInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */