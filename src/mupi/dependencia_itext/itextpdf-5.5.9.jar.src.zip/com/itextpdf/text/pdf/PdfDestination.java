/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfDestination
/*     */   extends PdfArray
/*     */ {
/*     */   public static final int XYZ = 0;
/*     */   public static final int FIT = 1;
/*     */   public static final int FITH = 2;
/*     */   public static final int FITV = 3;
/*     */   public static final int FITR = 4;
/*     */   public static final int FITB = 5;
/*     */   public static final int FITBH = 6;
/*     */   public static final int FITBV = 7;
/*  84 */   private boolean status = false;
/*     */   
/*     */ 
/*     */   public PdfDestination(PdfDestination d)
/*     */   {
/*  89 */     super(d);
/*  90 */     this.status = d.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDestination(int type)
/*     */   {
/* 105 */     if (type == 5) {
/* 106 */       add(PdfName.FITB);
/*     */     }
/*     */     else {
/* 109 */       add(PdfName.FIT);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDestination(int type, float parameter)
/*     */   {
/* 129 */     super(new PdfNumber(parameter));
/* 130 */     switch (type) {
/*     */     case 4: case 5: default: 
/* 132 */       addFirst(PdfName.FITH);
/* 133 */       break;
/*     */     case 3: 
/* 135 */       addFirst(PdfName.FITV);
/* 136 */       break;
/*     */     case 6: 
/* 138 */       addFirst(PdfName.FITBH);
/* 139 */       break;
/*     */     case 7: 
/* 141 */       addFirst(PdfName.FITBV);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDestination(int type, float left, float top, float zoom)
/*     */   {
/* 158 */     super(PdfName.XYZ);
/* 159 */     if (left < 0.0F) {
/* 160 */       add(PdfNull.PDFNULL);
/*     */     } else
/* 162 */       add(new PdfNumber(left));
/* 163 */     if (top < 0.0F) {
/* 164 */       add(PdfNull.PDFNULL);
/*     */     } else
/* 166 */       add(new PdfNumber(top));
/* 167 */     add(new PdfNumber(zoom));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDestination(int type, float left, float bottom, float right, float top)
/*     */   {
/* 187 */     super(PdfName.FITR);
/* 188 */     add(new PdfNumber(left));
/* 189 */     add(new PdfNumber(bottom));
/* 190 */     add(new PdfNumber(right));
/* 191 */     add(new PdfNumber(top));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDestination(String dest)
/*     */   {
/* 203 */     StringTokenizer tokens = new StringTokenizer(dest);
/* 204 */     if (tokens.hasMoreTokens()) {
/* 205 */       add(new PdfName(tokens.nextToken()));
/*     */     }
/* 207 */     while (tokens.hasMoreTokens()) {
/* 208 */       String token = tokens.nextToken();
/* 209 */       if ("null".equals(token)) {
/* 210 */         add(new PdfNull());
/*     */       } else {
/*     */         try {
/* 213 */           add(new PdfNumber(token));
/*     */         } catch (RuntimeException e) {
/* 215 */           add(new PdfNull());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasPage()
/*     */   {
/* 230 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addPage(PdfIndirectReference page)
/*     */   {
/* 240 */     if (!this.status) {
/* 241 */       addFirst(page);
/* 242 */       this.status = true;
/* 243 */       return true;
/*     */     }
/* 245 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfDestination.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */