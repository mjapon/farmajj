/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClipperOffset
/*     */ {
/*     */   private Paths destPolys;
/*     */   private Path srcPoly;
/*     */   private Path destPoly;
/*     */   private final List<Point.DoublePoint> normals;
/*     */   private double delta;
/*     */   private double inA;
/*     */   private double sin;
/*     */   private double cos;
/*     */   private double miterLim;
/*     */   private double stepsPerRad;
/*     */   private Point.LongPoint lowest;
/*     */   private final PolyNode polyNodes;
/*     */   private final double arcTolerance;
/*     */   private final double miterLimit;
/*     */   private static final double TWO_PI = 6.283185307179586D;
/*     */   private static final double DEFAULT_ARC_TOLERANCE = 0.25D;
/*     */   private static final double TOLERANCE = 1.0E-20D;
/*     */   
/*     */   private static boolean nearZero(double val)
/*     */   {
/*  61 */     return (val > -1.0E-20D) && (val < 1.0E-20D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClipperOffset()
/*     */   {
/*  85 */     this(2.0D, 0.25D);
/*     */   }
/*     */   
/*     */   public ClipperOffset(double miterLimit) {
/*  89 */     this(miterLimit, 0.25D);
/*     */   }
/*     */   
/*     */   public ClipperOffset(double miterLimit, double arcTolerance) {
/*  93 */     this.miterLimit = miterLimit;
/*  94 */     this.arcTolerance = arcTolerance;
/*  95 */     this.lowest = new Point.LongPoint();
/*  96 */     this.lowest.setX(Long.valueOf(-1L));
/*  97 */     this.polyNodes = new PolyNode();
/*  98 */     this.normals = new ArrayList();
/*     */   }
/*     */   
/*     */   public void addPath(Path path, Clipper.JoinType joinType, Clipper.EndType endType) {
/* 102 */     int highI = path.size() - 1;
/* 103 */     if (highI < 0) {
/* 104 */       return;
/*     */     }
/* 106 */     PolyNode newNode = new PolyNode();
/* 107 */     newNode.setJoinType(joinType);
/* 108 */     newNode.setEndType(endType);
/*     */     
/*     */ 
/* 111 */     if ((endType == Clipper.EndType.CLOSED_LINE) || (endType == Clipper.EndType.CLOSED_POLYGON)) {
/* 112 */       while ((highI > 0) && (path.get(0) == path.get(highI))) {
/* 113 */         highI--;
/*     */       }
/*     */     }
/*     */     
/* 117 */     newNode.getPolygon().add(path.get(0));
/* 118 */     int j = 0;int k = 0;
/* 119 */     for (int i = 1; i <= highI; i++) {
/* 120 */       if (newNode.getPolygon().get(j) != path.get(i)) {
/* 121 */         j++;
/* 122 */         newNode.getPolygon().add(path.get(i));
/* 123 */         if ((((Point.LongPoint)path.get(i)).getY() > ((Point.LongPoint)newNode.getPolygon().get(k)).getY()) || ((((Point.LongPoint)path.get(i)).getY() == ((Point.LongPoint)newNode.getPolygon().get(k)).getY()) && 
/* 124 */           (((Point.LongPoint)path.get(i)).getX() < ((Point.LongPoint)newNode.getPolygon().get(k)).getX()))) {
/* 125 */           k = j;
/*     */         }
/*     */       }
/*     */     }
/* 129 */     if ((endType == Clipper.EndType.CLOSED_POLYGON) && (j < 2)) {
/* 130 */       return;
/*     */     }
/*     */     
/* 133 */     this.polyNodes.addChild(newNode);
/*     */     
/*     */ 
/* 136 */     if (endType != Clipper.EndType.CLOSED_POLYGON) {
/* 137 */       return;
/*     */     }
/* 139 */     if (this.lowest.getX() < 0L) {
/* 140 */       this.lowest = new Point.LongPoint(this.polyNodes.getChildCount() - 1, k);
/*     */     }
/*     */     else {
/* 143 */       Point.LongPoint ip = (Point.LongPoint)((PolyNode)this.polyNodes.getChilds().get((int)this.lowest.getX())).getPolygon().get((int)this.lowest.getY());
/* 144 */       if ((((Point.LongPoint)newNode.getPolygon().get(k)).getY() > ip.getY()) || ((((Point.LongPoint)newNode.getPolygon().get(k)).getY() == ip.getY()) && 
/* 145 */         (((Point.LongPoint)newNode.getPolygon().get(k)).getX() < ip.getX()))) {
/* 146 */         this.lowest = new Point.LongPoint(this.polyNodes.getChildCount() - 1, k);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addPaths(Paths paths, Clipper.JoinType joinType, Clipper.EndType endType) {
/* 152 */     for (Path p : paths) {
/* 153 */       addPath(p, joinType, endType);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() {
/* 158 */     this.polyNodes.getChilds().clear();
/* 159 */     this.lowest.setX(Long.valueOf(-1L));
/*     */   }
/*     */   
/*     */   private void doMiter(int j, int k, double r) {
/* 163 */     double q = this.delta / r;
/* 164 */     this.destPoly.add(new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(j)).getX() + (((Point.DoublePoint)this.normals.get(k)).getX() + ((Point.DoublePoint)this.normals.get(j)).getX()) * q), 
/* 165 */       Math.round(((Point.LongPoint)this.srcPoly.get(j)).getY() + (((Point.DoublePoint)this.normals.get(k)).getY() + ((Point.DoublePoint)this.normals.get(j)).getY()) * q)));
/*     */   }
/*     */   
/*     */   private void doOffset(double delta) {
/* 169 */     this.destPolys = new Paths();
/* 170 */     this.delta = delta;
/*     */     
/*     */ 
/* 173 */     if (nearZero(delta)) {
/* 174 */       for (int i = 0; i < this.polyNodes.getChildCount(); i++) {
/* 175 */         PolyNode node = (PolyNode)this.polyNodes.getChilds().get(i);
/* 176 */         if (node.getEndType() == Clipper.EndType.CLOSED_POLYGON) {
/* 177 */           this.destPolys.add(node.getPolygon());
/*     */         }
/*     */       }
/* 180 */       return;
/*     */     }
/*     */     
/*     */ 
/* 184 */     if (this.miterLimit > 2.0D) {
/* 185 */       this.miterLim = (2.0D / (this.miterLimit * this.miterLimit));
/*     */     }
/*     */     else {
/* 188 */       this.miterLim = 0.5D;
/*     */     }
/*     */     double y;
/*     */     double y;
/* 192 */     if (this.arcTolerance <= 0.0D) {
/* 193 */       y = 0.25D;
/*     */     } else { double y;
/* 195 */       if (this.arcTolerance > Math.abs(delta) * 0.25D) {
/* 196 */         y = Math.abs(delta) * 0.25D;
/*     */       }
/*     */       else {
/* 199 */         y = this.arcTolerance;
/*     */       }
/*     */     }
/* 202 */     double steps = 3.141592653589793D / Math.acos(1.0D - y / Math.abs(delta));
/* 203 */     this.sin = Math.sin(6.283185307179586D / steps);
/* 204 */     this.cos = Math.cos(6.283185307179586D / steps);
/* 205 */     this.stepsPerRad = (steps / 6.283185307179586D);
/* 206 */     if (delta < 0.0D) {
/* 207 */       this.sin = (-this.sin);
/*     */     }
/*     */     
/* 210 */     for (int i = 0; i < this.polyNodes.getChildCount(); i++) {
/* 211 */       PolyNode node = (PolyNode)this.polyNodes.getChilds().get(i);
/* 212 */       this.srcPoly = node.getPolygon();
/*     */       
/* 214 */       int len = this.srcPoly.size();
/*     */       
/* 216 */       if ((len != 0) && ((delta > 0.0D) || ((len >= 3) && (node.getEndType() == Clipper.EndType.CLOSED_POLYGON))))
/*     */       {
/*     */ 
/*     */ 
/* 220 */         this.destPoly = new Path();
/*     */         
/* 222 */         if (len == 1) {
/* 223 */           if (node.getJoinType() == Clipper.JoinType.ROUND) {
/* 224 */             double X = 1.0D;double Y = 0.0D;
/* 225 */             for (int j = 1; j <= steps; j++) {
/* 226 */               this.destPoly.add(new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(0)).getX() + X * delta), Math.round(((Point.LongPoint)this.srcPoly.get(0)).getY() + Y * delta)));
/*     */               
/* 228 */               double X2 = X;
/* 229 */               X = X * this.cos - this.sin * Y;
/* 230 */               Y = X2 * this.sin + Y * this.cos;
/*     */             }
/*     */           }
/*     */           else {
/* 234 */             double X = -1.0D;double Y = -1.0D;
/* 235 */             for (int j = 0; j < 4; j++) {
/* 236 */               this.destPoly.add(new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(0)).getX() + X * delta), Math.round(((Point.LongPoint)this.srcPoly.get(0)).getY() + Y * delta)));
/*     */               
/* 238 */               if (X < 0.0D) {
/* 239 */                 X = 1.0D;
/*     */               }
/* 241 */               else if (Y < 0.0D) {
/* 242 */                 Y = 1.0D;
/*     */               }
/*     */               else {
/* 245 */                 X = -1.0D;
/*     */               }
/*     */             }
/*     */           }
/* 249 */           this.destPolys.add(this.destPoly);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 254 */           this.normals.clear();
/* 255 */           for (int j = 0; j < len - 1; j++) {
/* 256 */             this.normals.add(Point.getUnitNormal((Point.LongPoint)this.srcPoly.get(j), (Point.LongPoint)this.srcPoly.get(j + 1)));
/*     */           }
/* 258 */           if ((node.getEndType() == Clipper.EndType.CLOSED_LINE) || (node.getEndType() == Clipper.EndType.CLOSED_POLYGON)) {
/* 259 */             this.normals.add(Point.getUnitNormal((Point.LongPoint)this.srcPoly.get(len - 1), (Point.LongPoint)this.srcPoly.get(0)));
/*     */           }
/*     */           else {
/* 262 */             this.normals.add(new Point.DoublePoint((Point.DoublePoint)this.normals.get(len - 2)));
/*     */           }
/*     */           
/* 265 */           if (node.getEndType() == Clipper.EndType.CLOSED_POLYGON) {
/* 266 */             int[] k = { len - 1 };
/* 267 */             for (int j = 0; j < len; j++) {
/* 268 */               offsetPoint(j, k, node.getJoinType());
/*     */             }
/* 270 */             this.destPolys.add(this.destPoly);
/*     */           }
/* 272 */           else if (node.getEndType() == Clipper.EndType.CLOSED_LINE) {
/* 273 */             int[] k = { len - 1 };
/* 274 */             for (int j = 0; j < len; j++) {
/* 275 */               offsetPoint(j, k, node.getJoinType());
/*     */             }
/* 277 */             this.destPolys.add(this.destPoly);
/* 278 */             this.destPoly = new Path();
/*     */             
/* 280 */             Point.DoublePoint n = (Point.DoublePoint)this.normals.get(len - 1);
/* 281 */             for (int j = len - 1; j > 0; j--) {
/* 282 */               this.normals.set(j, new Point.DoublePoint(-((Point.DoublePoint)this.normals.get(j - 1)).getX(), -((Point.DoublePoint)this.normals.get(j - 1)).getY()));
/*     */             }
/* 284 */             this.normals.set(0, new Point.DoublePoint(-n.getX(), -n.getY(), 0.0D));
/* 285 */             k[0] = 0;
/* 286 */             for (int j = len - 1; j >= 0; j--) {
/* 287 */               offsetPoint(j, k, node.getJoinType());
/*     */             }
/* 289 */             this.destPolys.add(this.destPoly);
/*     */           }
/*     */           else {
/* 292 */             int[] k = new int[1];
/* 293 */             for (int j = 1; j < len - 1; j++) {
/* 294 */               offsetPoint(j, k, node.getJoinType());
/*     */             }
/*     */             
/*     */ 
/* 298 */             if (node.getEndType() == Clipper.EndType.OPEN_BUTT) {
/* 299 */               int j = len - 1;
/* 300 */               Point.LongPoint pt1 = new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(j)).getX() + ((Point.DoublePoint)this.normals.get(j)).getX() * delta), Math.round(((Point.LongPoint)this.srcPoly.get(j))
/* 301 */                 .getY() + ((Point.DoublePoint)this.normals.get(j)).getY() * delta), 0L);
/* 302 */               this.destPoly.add(pt1);
/* 303 */               pt1 = new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(j)).getX() - ((Point.DoublePoint)this.normals.get(j)).getX() * delta), Math.round(((Point.LongPoint)this.srcPoly.get(j))
/* 304 */                 .getY() - ((Point.DoublePoint)this.normals.get(j)).getY() * delta), 0L);
/* 305 */               this.destPoly.add(pt1);
/*     */             }
/*     */             else {
/* 308 */               int j = len - 1;
/* 309 */               k[0] = (len - 2);
/* 310 */               this.inA = 0.0D;
/* 311 */               this.normals.set(j, new Point.DoublePoint(-((Point.DoublePoint)this.normals.get(j)).getX(), -((Point.DoublePoint)this.normals.get(j)).getY()));
/* 312 */               if (node.getEndType() == Clipper.EndType.OPEN_SQUARE) {
/* 313 */                 doSquare(j, k[0], true);
/*     */               }
/*     */               else {
/* 316 */                 doRound(j, k[0]);
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 321 */             for (int j = len - 1; j > 0; j--) {
/* 322 */               this.normals.set(j, new Point.DoublePoint(-((Point.DoublePoint)this.normals.get(j - 1)).getX(), -((Point.DoublePoint)this.normals.get(j - 1)).getY()));
/*     */             }
/*     */             
/* 325 */             this.normals.set(0, new Point.DoublePoint(-((Point.DoublePoint)this.normals.get(1)).getX(), -((Point.DoublePoint)this.normals.get(1)).getY()));
/*     */             
/* 327 */             k[0] = (len - 1);
/* 328 */             for (int j = k[0] - 1; j > 0; j--) {
/* 329 */               offsetPoint(j, k, node.getJoinType());
/*     */             }
/*     */             
/* 332 */             if (node.getEndType() == Clipper.EndType.OPEN_BUTT) {
/* 333 */               Point.LongPoint pt1 = new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(0)).getX() - ((Point.DoublePoint)this.normals.get(0)).getX() * delta), Math.round(((Point.LongPoint)this.srcPoly.get(0))
/* 334 */                 .getY() - ((Point.DoublePoint)this.normals.get(0)).getY() * delta));
/* 335 */               this.destPoly.add(pt1);
/* 336 */               pt1 = new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(0)).getX() + ((Point.DoublePoint)this.normals.get(0)).getX() * delta), Math.round(((Point.LongPoint)this.srcPoly.get(0))
/* 337 */                 .getY() + ((Point.DoublePoint)this.normals.get(0)).getY() * delta));
/* 338 */               this.destPoly.add(pt1);
/*     */             }
/*     */             else {
/* 341 */               k[0] = 1;
/* 342 */               this.inA = 0.0D;
/* 343 */               if (node.getEndType() == Clipper.EndType.OPEN_SQUARE) {
/* 344 */                 doSquare(0, 1, true);
/*     */               }
/*     */               else {
/* 347 */                 doRound(0, 1);
/*     */               }
/*     */             }
/* 350 */             this.destPolys.add(this.destPoly);
/*     */           }
/*     */         }
/*     */       }
/*     */     } }
/*     */   
/* 356 */   private void doRound(int j, int k) { double a = Math.atan2(this.inA, ((Point.DoublePoint)this.normals.get(k)).getX() * ((Point.DoublePoint)this.normals.get(j)).getX() + ((Point.DoublePoint)this.normals.get(k)).getY() * ((Point.DoublePoint)this.normals.get(j)).getY());
/* 357 */     int steps = Math.max((int)Math.round(this.stepsPerRad * Math.abs(a)), 1);
/*     */     
/* 359 */     double X = ((Point.DoublePoint)this.normals.get(k)).getX();double Y = ((Point.DoublePoint)this.normals.get(k)).getY();
/* 360 */     for (int i = 0; i < steps; i++) {
/* 361 */       this.destPoly.add(new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(j)).getX() + X * this.delta), Math.round(((Point.LongPoint)this.srcPoly.get(j)).getY() + Y * this.delta)));
/* 362 */       double X2 = X;
/* 363 */       X = X * this.cos - this.sin * Y;
/* 364 */       Y = X2 * this.sin + Y * this.cos;
/*     */     }
/* 366 */     this.destPoly.add(new Point.LongPoint(Math.round(((Point.LongPoint)this.srcPoly.get(j)).getX() + ((Point.DoublePoint)this.normals.get(j)).getX() * this.delta), Math.round(((Point.LongPoint)this.srcPoly.get(j)).getY() + 
/* 367 */       ((Point.DoublePoint)this.normals.get(j)).getY() * this.delta)));
/*     */   }
/*     */   
/*     */   private void doSquare(int j, int k, boolean addExtra) {
/* 371 */     double nkx = ((Point.DoublePoint)this.normals.get(k)).getX();
/* 372 */     double nky = ((Point.DoublePoint)this.normals.get(k)).getY();
/* 373 */     double njx = ((Point.DoublePoint)this.normals.get(j)).getX();
/* 374 */     double njy = ((Point.DoublePoint)this.normals.get(j)).getY();
/* 375 */     double sjx = ((Point.LongPoint)this.srcPoly.get(j)).getX();
/* 376 */     double sjy = ((Point.LongPoint)this.srcPoly.get(j)).getY();
/* 377 */     double dx = Math.tan(Math.atan2(this.inA, nkx * njx + nky * njy) / 4.0D);
/* 378 */     this.destPoly.add(new Point.LongPoint(Math.round(sjx + this.delta * (nkx - (addExtra ? nky * dx : 0.0D))), Math.round(sjy + this.delta * (nky + (addExtra ? nkx * dx : 0.0D))), 0L));
/* 379 */     this.destPoly.add(new Point.LongPoint(Math.round(sjx + this.delta * (njx + (addExtra ? njy * dx : 0.0D))), Math.round(sjy + this.delta * (njy - (addExtra ? njx * dx : 0.0D))), 0L));
/*     */   }
/*     */   
/*     */ 
/*     */   public void execute(Paths solution, double delta)
/*     */   {
/* 385 */     solution.clear();
/* 386 */     fixOrientations();
/* 387 */     doOffset(delta);
/*     */     
/* 389 */     DefaultClipper clpr = new DefaultClipper(1);
/* 390 */     clpr.addPaths(this.destPolys, Clipper.PolyType.SUBJECT, true);
/* 391 */     if (delta > 0.0D) {
/* 392 */       clpr.execute(Clipper.ClipType.UNION, solution, Clipper.PolyFillType.POSITIVE, Clipper.PolyFillType.POSITIVE);
/*     */     }
/*     */     else {
/* 395 */       LongRect r = this.destPolys.getBounds();
/* 396 */       Path outer = new Path(4);
/*     */       
/* 398 */       outer.add(new Point.LongPoint(r.left - 10L, r.bottom + 10L, 0L));
/* 399 */       outer.add(new Point.LongPoint(r.right + 10L, r.bottom + 10L, 0L));
/* 400 */       outer.add(new Point.LongPoint(r.right + 10L, r.top - 10L, 0L));
/* 401 */       outer.add(new Point.LongPoint(r.left - 10L, r.top - 10L, 0L));
/*     */       
/* 403 */       clpr.addPath(outer, Clipper.PolyType.SUBJECT, true);
/*     */       
/* 405 */       clpr.execute(Clipper.ClipType.UNION, solution, Clipper.PolyFillType.NEGATIVE, Clipper.PolyFillType.NEGATIVE);
/* 406 */       if (solution.size() > 0) {
/* 407 */         solution.remove(0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void execute(PolyTree solution, double delta)
/*     */   {
/* 415 */     solution.Clear();
/* 416 */     fixOrientations();
/* 417 */     doOffset(delta);
/*     */     
/*     */ 
/* 420 */     DefaultClipper clpr = new DefaultClipper(1);
/* 421 */     clpr.addPaths(this.destPolys, Clipper.PolyType.SUBJECT, true);
/* 422 */     if (delta > 0.0D) {
/* 423 */       clpr.execute(Clipper.ClipType.UNION, solution, Clipper.PolyFillType.POSITIVE, Clipper.PolyFillType.POSITIVE);
/*     */     }
/*     */     else {
/* 426 */       LongRect r = this.destPolys.getBounds();
/* 427 */       Path outer = new Path(4);
/*     */       
/* 429 */       outer.add(new Point.LongPoint(r.left - 10L, r.bottom + 10L, 0L));
/* 430 */       outer.add(new Point.LongPoint(r.right + 10L, r.bottom + 10L, 0L));
/* 431 */       outer.add(new Point.LongPoint(r.right + 10L, r.top - 10L, 0L));
/* 432 */       outer.add(new Point.LongPoint(r.left - 10L, r.top - 10L, 0L));
/*     */       
/* 434 */       clpr.addPath(outer, Clipper.PolyType.SUBJECT, true);
/*     */       
/* 436 */       clpr.execute(Clipper.ClipType.UNION, solution, Clipper.PolyFillType.NEGATIVE, Clipper.PolyFillType.NEGATIVE);
/*     */       
/* 438 */       if ((solution.getChildCount() == 1) && (((PolyNode)solution.getChilds().get(0)).getChildCount() > 0)) {
/* 439 */         PolyNode outerNode = (PolyNode)solution.getChilds().get(0);
/* 440 */         solution.getChilds().set(0, outerNode.getChilds().get(0));
/* 441 */         ((PolyNode)solution.getChilds().get(0)).setParent(solution);
/* 442 */         for (int i = 1; i < outerNode.getChildCount(); i++) {
/* 443 */           solution.addChild((PolyNode)outerNode.getChilds().get(i));
/*     */         }
/*     */       }
/*     */       else {
/* 447 */         solution.Clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fixOrientations()
/*     */   {
/* 457 */     if ((this.lowest.getX() >= 0L) && (!((PolyNode)this.polyNodes.childs.get((int)this.lowest.getX())).getPolygon().orientation())) {
/* 458 */       for (int i = 0; i < this.polyNodes.getChildCount(); i++) {
/* 459 */         PolyNode node = (PolyNode)this.polyNodes.childs.get(i);
/* 460 */         if ((node.getEndType() == Clipper.EndType.CLOSED_POLYGON) || ((node.getEndType() == Clipper.EndType.CLOSED_LINE) && (node.getPolygon().orientation()))) {
/* 461 */           Collections.reverse(node.getPolygon());
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     } else {
/* 467 */       for (int i = 0; i < this.polyNodes.getChildCount(); i++) {
/* 468 */         PolyNode node = (PolyNode)this.polyNodes.childs.get(i);
/* 469 */         if ((node.getEndType() == Clipper.EndType.CLOSED_LINE) && (!node.getPolygon().orientation())) {
/* 470 */           Collections.reverse(node.getPolygon());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void offsetPoint(int j, int[] kV, Clipper.JoinType jointype)
/*     */   {
/* 478 */     int k = kV[0];
/* 479 */     double nkx = ((Point.DoublePoint)this.normals.get(k)).getX();
/* 480 */     double nky = ((Point.DoublePoint)this.normals.get(k)).getY();
/* 481 */     double njy = ((Point.DoublePoint)this.normals.get(j)).getY();
/* 482 */     double njx = ((Point.DoublePoint)this.normals.get(j)).getX();
/* 483 */     long sjx = ((Point.LongPoint)this.srcPoly.get(j)).getX();
/* 484 */     long sjy = ((Point.LongPoint)this.srcPoly.get(j)).getY();
/* 485 */     this.inA = (nkx * njy - njx * nky);
/*     */     
/* 487 */     if (Math.abs(this.inA * this.delta) < 1.0D)
/*     */     {
/*     */ 
/* 490 */       double cosA = nkx * njx + njy * nky;
/* 491 */       if (cosA > 0.0D)
/*     */       {
/* 493 */         this.destPoly.add(new Point.LongPoint(Math.round(sjx + nkx * this.delta), Math.round(sjy + nky * this.delta), 0L));
/* 494 */         return;
/*     */       }
/*     */       
/*     */     }
/* 498 */     else if (this.inA > 1.0D) {
/* 499 */       this.inA = 1.0D;
/*     */     }
/* 501 */     else if (this.inA < -1.0D) {
/* 502 */       this.inA = -1.0D;
/*     */     }
/*     */     
/* 505 */     if (this.inA * this.delta < 0.0D) {
/* 506 */       this.destPoly.add(new Point.LongPoint(Math.round(sjx + nkx * this.delta), Math.round(sjy + nky * this.delta)));
/* 507 */       this.destPoly.add(this.srcPoly.get(j));
/* 508 */       this.destPoly.add(new Point.LongPoint(Math.round(sjx + njx * this.delta), Math.round(sjy + njy * this.delta)));
/*     */     }
/*     */     else {
/* 511 */       switch (jointype) {
/*     */       case MITER: 
/* 513 */         double r = 1.0D + njx * nkx + njy * nky;
/* 514 */         if (r >= this.miterLim) {
/* 515 */           doMiter(j, k, r);
/*     */         }
/*     */         else {
/* 518 */           doSquare(j, k, false);
/*     */         }
/* 520 */         break;
/*     */       
/*     */       case BEVEL: 
/* 523 */         doSquare(j, k, false);
/* 524 */         break;
/*     */       case ROUND: 
/* 526 */         doRound(j, k);
/*     */       }
/*     */       
/*     */     }
/* 530 */     kV[0] = j;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/ClipperOffset.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */