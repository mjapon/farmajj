/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.factories.RomanAlphabetFactory;
/*     */ import com.itextpdf.text.factories.RomanNumberFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfPageLabels
/*     */ {
/*     */   public static final int DECIMAL_ARABIC_NUMERALS = 0;
/*     */   public static final int UPPERCASE_ROMAN_NUMERALS = 1;
/*     */   public static final int LOWERCASE_ROMAN_NUMERALS = 2;
/*     */   public static final int UPPERCASE_LETTERS = 3;
/*     */   public static final int LOWERCASE_LETTERS = 4;
/*     */   public static final int EMPTY = 5;
/*  85 */   static PdfName[] numberingStyle = { PdfName.D, PdfName.R, new PdfName("r"), PdfName.A, new PdfName("a") };
/*     */   
/*     */ 
/*     */   private HashMap<Integer, PdfDictionary> map;
/*     */   
/*     */ 
/*     */ 
/*     */   public PdfPageLabels()
/*     */   {
/*  94 */     this.map = new HashMap();
/*  95 */     addPageLabel(1, 0, null, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPageLabel(int page, int numberStyle, String text, int firstPage)
/*     */   {
/* 105 */     if ((page < 1) || (firstPage < 1))
/* 106 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("in.a.page.label.the.page.numbers.must.be.greater.or.equal.to.1", new Object[0]));
/* 107 */     PdfDictionary dic = new PdfDictionary();
/* 108 */     if ((numberStyle >= 0) && (numberStyle < numberingStyle.length))
/* 109 */       dic.put(PdfName.S, numberingStyle[numberStyle]);
/* 110 */     if (text != null) {
/* 111 */       dic.put(PdfName.P, new PdfString(text, "UnicodeBig"));
/*     */     }
/* 113 */     if (firstPage != 1)
/* 114 */       dic.put(PdfName.ST, new PdfNumber(firstPage));
/* 115 */     this.map.put(Integer.valueOf(page - 1), dic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPageLabel(int page, int numberStyle, String text, int firstPage, boolean includeFirstPage)
/*     */   {
/* 127 */     if ((page < 1) || (firstPage < 1))
/* 128 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("in.a.page.label.the.page.numbers.must.be.greater.or.equal.to.1", new Object[0]));
/* 129 */     PdfDictionary dic = new PdfDictionary();
/* 130 */     if ((numberStyle >= 0) && (numberStyle < numberingStyle.length))
/* 131 */       dic.put(PdfName.S, numberingStyle[numberStyle]);
/* 132 */     if (text != null)
/* 133 */       dic.put(PdfName.P, new PdfString(text, "UnicodeBig"));
/* 134 */     if ((firstPage != 1) || (includeFirstPage))
/* 135 */       dic.put(PdfName.ST, new PdfNumber(firstPage));
/* 136 */     this.map.put(Integer.valueOf(page - 1), dic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPageLabel(int page, int numberStyle, String text)
/*     */   {
/* 146 */     addPageLabel(page, numberStyle, text, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPageLabel(int page, int numberStyle)
/*     */   {
/* 155 */     addPageLabel(page, numberStyle, null, 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addPageLabel(PdfPageLabelFormat format)
/*     */   {
/* 161 */     addPageLabel(format.physicalPage, format.numberStyle, format.prefix, format.logicalPage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removePageLabel(int page)
/*     */   {
/* 168 */     if (page <= 1)
/* 169 */       return;
/* 170 */     this.map.remove(Integer.valueOf(page - 1));
/*     */   }
/*     */   
/*     */ 
/*     */   public PdfDictionary getDictionary(PdfWriter writer)
/*     */   {
/*     */     try
/*     */     {
/* 178 */       return PdfNumberTree.writeTree(this.map, writer);
/*     */     }
/*     */     catch (IOException e) {
/* 181 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getPageLabels(PdfReader reader)
/*     */   {
/* 191 */     int n = reader.getNumberOfPages();
/*     */     
/* 193 */     PdfDictionary dict = reader.getCatalog();
/* 194 */     PdfDictionary labels = (PdfDictionary)PdfReader.getPdfObjectRelease(dict.get(PdfName.PAGELABELS));
/*     */     
/* 196 */     if (labels == null) {
/* 197 */       return null;
/*     */     }
/* 199 */     String[] labelstrings = new String[n];
/*     */     
/* 201 */     HashMap<Integer, PdfObject> numberTree = PdfNumberTree.readTree(labels);
/*     */     
/* 203 */     int pagecount = 1;
/*     */     
/* 205 */     String prefix = "";
/* 206 */     char type = 'D';
/* 207 */     for (int i = 0; i < n; i++) {
/* 208 */       Integer current = Integer.valueOf(i);
/* 209 */       if (numberTree.containsKey(current)) {
/* 210 */         PdfDictionary d = (PdfDictionary)PdfReader.getPdfObjectRelease((PdfObject)numberTree.get(current));
/* 211 */         if (d.contains(PdfName.ST)) {
/* 212 */           pagecount = ((PdfNumber)d.get(PdfName.ST)).intValue();
/*     */         }
/*     */         else {
/* 215 */           pagecount = 1;
/*     */         }
/* 217 */         if (d.contains(PdfName.P)) {
/* 218 */           prefix = ((PdfString)d.get(PdfName.P)).toUnicodeString();
/*     */         }
/*     */         else {
/* 221 */           prefix = "";
/*     */         }
/* 223 */         if (d.contains(PdfName.S)) {
/* 224 */           type = ((PdfName)d.get(PdfName.S)).toString().charAt(1);
/*     */         }
/*     */         else {
/* 227 */           type = 'e';
/*     */         }
/*     */       }
/* 230 */       switch (type) {
/*     */       default: 
/* 232 */         labelstrings[i] = (prefix + pagecount);
/* 233 */         break;
/*     */       case 'R': 
/* 235 */         labelstrings[i] = (prefix + RomanNumberFactory.getUpperCaseString(pagecount));
/* 236 */         break;
/*     */       case 'r': 
/* 238 */         labelstrings[i] = (prefix + RomanNumberFactory.getLowerCaseString(pagecount));
/* 239 */         break;
/*     */       case 'A': 
/* 241 */         labelstrings[i] = (prefix + RomanAlphabetFactory.getUpperCaseString(pagecount));
/* 242 */         break;
/*     */       case 'a': 
/* 244 */         labelstrings[i] = (prefix + RomanAlphabetFactory.getLowerCaseString(pagecount));
/* 245 */         break;
/*     */       case 'e': 
/* 247 */         labelstrings[i] = prefix;
/*     */       }
/*     */       
/* 250 */       pagecount++;
/*     */     }
/* 252 */     return labelstrings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PdfPageLabelFormat[] getPageLabelFormats(PdfReader reader)
/*     */   {
/* 262 */     PdfDictionary dict = reader.getCatalog();
/* 263 */     PdfDictionary labels = (PdfDictionary)PdfReader.getPdfObjectRelease(dict.get(PdfName.PAGELABELS));
/* 264 */     if (labels == null)
/* 265 */       return null;
/* 266 */     HashMap<Integer, PdfObject> numberTree = PdfNumberTree.readTree(labels);
/* 267 */     Integer[] numbers = new Integer[numberTree.size()];
/* 268 */     numbers = (Integer[])numberTree.keySet().toArray(numbers);
/* 269 */     Arrays.sort(numbers);
/* 270 */     PdfPageLabelFormat[] formats = new PdfPageLabelFormat[numberTree.size()];
/*     */     
/*     */ 
/*     */ 
/* 274 */     for (int k = 0; k < numbers.length; k++) {
/* 275 */       Integer key = numbers[k];
/* 276 */       PdfDictionary d = (PdfDictionary)PdfReader.getPdfObjectRelease((PdfObject)numberTree.get(key));
/* 277 */       int pagecount; int pagecount; if (d.contains(PdfName.ST)) {
/* 278 */         pagecount = ((PdfNumber)d.get(PdfName.ST)).intValue();
/*     */       } else
/* 280 */         pagecount = 1;
/*     */       String prefix;
/* 282 */       String prefix; if (d.contains(PdfName.P)) {
/* 283 */         prefix = ((PdfString)d.get(PdfName.P)).toUnicodeString();
/*     */       } else
/* 285 */         prefix = "";
/*     */       int numberStyle;
/* 287 */       int numberStyle; if (d.contains(PdfName.S)) {
/* 288 */         char type = ((PdfName)d.get(PdfName.S)).toString().charAt(1);
/* 289 */         int numberStyle; int numberStyle; int numberStyle; int numberStyle; switch (type) {
/* 290 */         case 'R':  numberStyle = 1; break;
/* 291 */         case 'r':  numberStyle = 2; break;
/* 292 */         case 'A':  numberStyle = 3; break;
/* 293 */         case 'a':  numberStyle = 4; break;
/* 294 */         default:  numberStyle = 0;
/*     */         }
/*     */       } else {
/* 297 */         numberStyle = 5;
/*     */       }
/* 299 */       formats[k] = new PdfPageLabelFormat(key.intValue() + 1, numberStyle, prefix, pagecount);
/*     */     }
/* 301 */     return formats;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class PdfPageLabelFormat
/*     */   {
/*     */     public int physicalPage;
/*     */     
/*     */     public int numberStyle;
/*     */     
/*     */     public String prefix;
/*     */     
/*     */     public int logicalPage;
/*     */     
/*     */ 
/*     */     public PdfPageLabelFormat(int physicalPage, int numberStyle, String prefix, int logicalPage)
/*     */     {
/* 318 */       this.physicalPage = physicalPage;
/* 319 */       this.numberStyle = numberStyle;
/* 320 */       this.prefix = prefix;
/* 321 */       this.logicalPage = logicalPage;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 326 */       return String.format("Physical page %s: style: %s; prefix '%s'; logical page: %s", new Object[] { Integer.valueOf(this.physicalPage), Integer.valueOf(this.numberStyle), this.prefix, Integer.valueOf(this.logicalPage) });
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfPageLabels.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */