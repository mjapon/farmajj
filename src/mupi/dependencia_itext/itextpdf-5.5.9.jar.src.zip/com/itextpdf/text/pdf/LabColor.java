/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import com.itextpdf.text.BaseColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabColor
/*    */   extends ExtendedColor
/*    */ {
/*    */   PdfLabColor labColorSpace;
/*    */   private float l;
/*    */   private float a;
/*    */   private float b;
/*    */   
/*    */   public LabColor(PdfLabColor labColorSpace, float l, float a, float b)
/*    */   {
/* 56 */     super(7);
/* 57 */     this.labColorSpace = labColorSpace;
/* 58 */     this.l = l;
/* 59 */     this.a = a;
/* 60 */     this.b = b;
/* 61 */     BaseColor altRgbColor = labColorSpace.lab2Rgb(l, a, b);
/* 62 */     setValue(altRgbColor.getRed(), altRgbColor.getGreen(), altRgbColor.getBlue(), 255);
/*    */   }
/*    */   
/*    */   public PdfLabColor getLabColorSpace() {
/* 66 */     return this.labColorSpace;
/*    */   }
/*    */   
/*    */   public float getL() {
/* 70 */     return this.l;
/*    */   }
/*    */   
/*    */   public float getA() {
/* 74 */     return this.a;
/*    */   }
/*    */   
/*    */   public float getB() {
/* 78 */     return this.b;
/*    */   }
/*    */   
/*    */   public BaseColor toRgb() {
/* 82 */     return this.labColorSpace.lab2Rgb(this.l, this.a, this.b);
/*    */   }
/*    */   
/*    */   CMYKColor toCmyk() {
/* 86 */     return this.labColorSpace.lab2Cmyk(this.l, this.a, this.b);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/LabColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */