/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfBorderArray
/*    */   extends PdfArray
/*    */ {
/*    */   public PdfBorderArray(float hRadius, float vRadius, float width)
/*    */   {
/* 62 */     this(hRadius, vRadius, width, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PdfBorderArray(float hRadius, float vRadius, float width, PdfDashPattern dash)
/*    */   {
/* 70 */     super(new PdfNumber(hRadius));
/* 71 */     add(new PdfNumber(vRadius));
/* 72 */     add(new PdfNumber(width));
/* 73 */     if (dash != null) {
/* 74 */       add(dash);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfBorderArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */