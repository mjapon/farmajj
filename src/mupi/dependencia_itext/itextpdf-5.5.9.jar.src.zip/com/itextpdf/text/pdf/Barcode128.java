/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Barcode128
/*     */   extends Barcode
/*     */ {
/*  77 */   private static final byte[][] BARS = { { 2, 1, 2, 2, 2, 2 }, { 2, 2, 2, 1, 2, 2 }, { 2, 2, 2, 2, 2, 1 }, { 1, 2, 1, 2, 2, 3 }, { 1, 2, 1, 3, 2, 2 }, { 1, 3, 1, 2, 2, 2 }, { 1, 2, 2, 2, 1, 3 }, { 1, 2, 2, 3, 1, 2 }, { 1, 3, 2, 2, 1, 2 }, { 2, 2, 1, 2, 1, 3 }, { 2, 2, 1, 3, 1, 2 }, { 2, 3, 1, 2, 1, 2 }, { 1, 1, 2, 2, 3, 2 }, { 1, 2, 2, 1, 3, 2 }, { 1, 2, 2, 2, 3, 1 }, { 1, 1, 3, 2, 2, 2 }, { 1, 2, 3, 1, 2, 2 }, { 1, 2, 3, 2, 2, 1 }, { 2, 2, 3, 2, 1, 1 }, { 2, 2, 1, 1, 3, 2 }, { 2, 2, 1, 2, 3, 1 }, { 2, 1, 3, 2, 1, 2 }, { 2, 2, 3, 1, 1, 2 }, { 3, 1, 2, 1, 3, 1 }, { 3, 1, 1, 2, 2, 2 }, { 3, 2, 1, 1, 2, 2 }, { 3, 2, 1, 2, 2, 1 }, { 3, 1, 2, 2, 1, 2 }, { 3, 2, 2, 1, 1, 2 }, { 3, 2, 2, 2, 1, 1 }, { 2, 1, 2, 1, 2, 3 }, { 2, 1, 2, 3, 2, 1 }, { 2, 3, 2, 1, 2, 1 }, { 1, 1, 1, 3, 2, 3 }, { 1, 3, 1, 1, 2, 3 }, { 1, 3, 1, 3, 2, 1 }, { 1, 1, 2, 3, 1, 3 }, { 1, 3, 2, 1, 1, 3 }, { 1, 3, 2, 3, 1, 1 }, { 2, 1, 1, 3, 1, 3 }, { 2, 3, 1, 1, 1, 3 }, { 2, 3, 1, 3, 1, 1 }, { 1, 1, 2, 1, 3, 3 }, { 1, 1, 2, 3, 3, 1 }, { 1, 3, 2, 1, 3, 1 }, { 1, 1, 3, 1, 2, 3 }, { 1, 1, 3, 3, 2, 1 }, { 1, 3, 3, 1, 2, 1 }, { 3, 1, 3, 1, 2, 1 }, { 2, 1, 1, 3, 3, 1 }, { 2, 3, 1, 1, 3, 1 }, { 2, 1, 3, 1, 1, 3 }, { 2, 1, 3, 3, 1, 1 }, { 2, 1, 3, 1, 3, 1 }, { 3, 1, 1, 1, 2, 3 }, { 3, 1, 1, 3, 2, 1 }, { 3, 3, 1, 1, 2, 1 }, { 3, 1, 2, 1, 1, 3 }, { 3, 1, 2, 3, 1, 1 }, { 3, 3, 2, 1, 1, 1 }, { 3, 1, 4, 1, 1, 1 }, { 2, 2, 1, 4, 1, 1 }, { 4, 3, 1, 1, 1, 1 }, { 1, 1, 1, 2, 2, 4 }, { 1, 1, 1, 4, 2, 2 }, { 1, 2, 1, 1, 2, 4 }, { 1, 2, 1, 4, 2, 1 }, { 1, 4, 1, 1, 2, 2 }, { 1, 4, 1, 2, 2, 1 }, { 1, 1, 2, 2, 1, 4 }, { 1, 1, 2, 4, 1, 2 }, { 1, 2, 2, 1, 1, 4 }, { 1, 2, 2, 4, 1, 1 }, { 1, 4, 2, 1, 1, 2 }, { 1, 4, 2, 2, 1, 1 }, { 2, 4, 1, 2, 1, 1 }, { 2, 2, 1, 1, 1, 4 }, { 4, 1, 3, 1, 1, 1 }, { 2, 4, 1, 1, 1, 2 }, { 1, 3, 4, 1, 1, 1 }, { 1, 1, 1, 2, 4, 2 }, { 1, 2, 1, 1, 4, 2 }, { 1, 2, 1, 2, 4, 1 }, { 1, 1, 4, 2, 1, 2 }, { 1, 2, 4, 1, 1, 2 }, { 1, 2, 4, 2, 1, 1 }, { 4, 1, 1, 2, 1, 2 }, { 4, 2, 1, 1, 1, 2 }, { 4, 2, 1, 2, 1, 1 }, { 2, 1, 2, 1, 4, 1 }, { 2, 1, 4, 1, 2, 1 }, { 4, 1, 2, 1, 2, 1 }, { 1, 1, 1, 1, 4, 3 }, { 1, 1, 1, 3, 4, 1 }, { 1, 3, 1, 1, 4, 1 }, { 1, 1, 4, 1, 1, 3 }, { 1, 1, 4, 3, 1, 1 }, { 4, 1, 1, 1, 1, 3 }, { 4, 1, 1, 3, 1, 1 }, { 1, 1, 3, 1, 4, 1 }, { 1, 1, 4, 1, 3, 1 }, { 3, 1, 1, 1, 4, 1 }, { 4, 1, 1, 1, 3, 1 }, { 2, 1, 1, 4, 1, 2 }, { 2, 1, 1, 2, 1, 4 }, { 2, 1, 1, 2, 3, 2 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */   private static final byte[] BARS_STOP = { 2, 3, 3, 1, 1, 1, 2 };
/*     */   
/*     */   public static final char CODE_AB_TO_C = 'c';
/*     */   
/*     */   public static final char CODE_AC_TO_B = 'd';
/*     */   
/*     */   public static final char CODE_BC_TO_A = 'e';
/*     */   
/*     */   public static final char FNC1_INDEX = 'f';
/*     */   
/*     */   public static final char START_A = 'g';
/*     */   
/*     */   public static final char START_B = 'h';
/*     */   
/*     */   public static final char START_C = 'i';
/*     */   
/*     */   public static final char FNC1 = 'Ê';
/*     */   
/*     */   public static final char DEL = 'Ã';
/*     */   
/*     */   public static final char FNC3 = 'Ä';
/*     */   
/*     */   public static final char FNC2 = 'Å';
/*     */   
/*     */   public static final char SHIFT = 'Æ';
/*     */   
/*     */   public static final char CODE_C = 'Ç';
/*     */   
/*     */   public static final char CODE_A = 'È';
/*     */   
/*     */   public static final char FNC4 = 'È';
/*     */   
/*     */   public static final char STARTA = 'Ë';
/*     */   public static final char STARTB = 'Ì';
/*     */   public static final char STARTC = 'Í';
/* 224 */   private static final IntHashtable ais = new IntHashtable();
/*     */   
/*     */   public Barcode128() {
/*     */     try {
/* 228 */       this.x = 0.8F;
/* 229 */       this.font = BaseFont.createFont("Helvetica", "winansi", false);
/* 230 */       this.size = 8.0F;
/* 231 */       this.baseline = this.size;
/* 232 */       this.barHeight = (this.size * 3.0F);
/* 233 */       this.textAlignment = 1;
/* 234 */       this.codeType = 9;
/*     */     }
/*     */     catch (Exception e) {
/* 237 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static enum Barcode128CodeSet {
/* 242 */     A, 
/* 243 */     B, 
/* 244 */     C, 
/* 245 */     AUTO;
/*     */     
/*     */     private Barcode128CodeSet() {}
/* 248 */     public char getStartSymbol() { switch (Barcode128.1.$SwitchMap$com$itextpdf$text$pdf$Barcode128$Barcode128CodeSet[ordinal()]) {
/*     */       case 1: 
/* 250 */         return 'g';
/*     */       case 2: 
/* 252 */         return 'h';
/*     */       case 3: 
/* 254 */         return 'i';
/*     */       }
/* 256 */       return 'h';
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCodeSet(Barcode128CodeSet codeSet)
/*     */   {
/* 262 */     this.codeSet = codeSet;
/*     */   }
/*     */   
/*     */   public Barcode128CodeSet getCodeSet() {
/* 266 */     return this.codeSet;
/*     */   }
/*     */   
/* 269 */   private Barcode128CodeSet codeSet = Barcode128CodeSet.AUTO;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String removeFNC1(String code)
/*     */   {
/* 277 */     int len = code.length();
/* 278 */     StringBuffer buf = new StringBuffer(len);
/* 279 */     for (int k = 0; k < len; k++) {
/* 280 */       char c = code.charAt(k);
/* 281 */       if ((c >= ' ') && (c <= '~'))
/* 282 */         buf.append(c);
/*     */     }
/* 284 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getHumanReadableUCCEAN(String code)
/*     */   {
/* 293 */     StringBuffer buf = new StringBuffer();
/* 294 */     String fnc1 = String.valueOf('Ê');
/*     */     try {
/*     */       for (;;) {
/* 297 */         if (code.startsWith(fnc1)) {
/* 298 */           code = code.substring(1);
/*     */         }
/*     */         else {
/* 301 */           int n = 0;
/* 302 */           int idlen = 0;
/* 303 */           for (int k = 2; k < 5; k++) {
/* 304 */             if (code.length() < k)
/*     */               break;
/* 306 */             if ((n = ais.get(Integer.parseInt(code.substring(0, k)))) != 0) {
/* 307 */               idlen = k;
/* 308 */               break;
/*     */             }
/*     */           }
/* 311 */           if (idlen == 0)
/*     */             break;
/* 313 */           buf.append('(').append(code.substring(0, idlen)).append(')');
/* 314 */           code = code.substring(idlen);
/* 315 */           if (n > 0) {
/* 316 */             n -= idlen;
/* 317 */             if (code.length() <= n)
/*     */               break;
/* 319 */             buf.append(removeFNC1(code.substring(0, n)));
/* 320 */             code = code.substring(n);
/*     */           }
/*     */           else {
/* 323 */             int idx = code.indexOf('Ê');
/* 324 */             if (idx < 0)
/*     */               break;
/* 326 */             buf.append(code.substring(0, idx));
/* 327 */             code = code.substring(idx + 1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/* 334 */     buf.append(removeFNC1(code));
/* 335 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isNextDigits(String text, int textIndex, int numDigits)
/*     */   {
/* 346 */     int len = text.length();
/* 347 */     while ((textIndex < len) && (numDigits > 0))
/* 348 */       if (text.charAt(textIndex) == 'Ê') {
/* 349 */         textIndex++;
/*     */       }
/*     */       else {
/* 352 */         int n = Math.min(2, numDigits);
/* 353 */         if (textIndex + n > len)
/* 354 */           return false;
/* 355 */         while (n-- > 0) {
/* 356 */           char c = text.charAt(textIndex++);
/* 357 */           if ((c < '0') || (c > '9'))
/* 358 */             return false;
/* 359 */           numDigits--;
/*     */         }
/*     */       }
/* 362 */     return numDigits == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String getPackedRawDigits(String text, int textIndex, int numDigits)
/*     */   {
/* 373 */     StringBuilder out = new StringBuilder("");
/* 374 */     int start = textIndex;
/* 375 */     while (numDigits > 0)
/* 376 */       if (text.charAt(textIndex) == 'Ê') {
/* 377 */         out.append('f');
/* 378 */         textIndex++;
/*     */       }
/*     */       else {
/* 381 */         numDigits -= 2;
/* 382 */         int c1 = text.charAt(textIndex++) - '0';
/* 383 */         int c2 = text.charAt(textIndex++) - '0';
/* 384 */         out.append((char)(c1 * 10 + c2));
/*     */       }
/* 386 */     return (char)(textIndex - start) + out.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getRawText(String text, boolean ucc, Barcode128CodeSet codeSet)
/*     */   {
/* 398 */     String out = "";
/* 399 */     int tLen = text.length();
/* 400 */     if (tLen == 0) {
/* 401 */       out = out + codeSet.getStartSymbol();
/* 402 */       if (ucc)
/* 403 */         out = out + 'f';
/* 404 */       return out;
/*     */     }
/* 406 */     int c = 0;
/* 407 */     for (int k = 0; k < tLen; k++) {
/* 408 */       c = text.charAt(k);
/* 409 */       if ((c > 127) && (c != 202))
/* 410 */         throw new RuntimeException(MessageLocalization.getComposedMessage("there.are.illegal.characters.for.barcode.128.in.1", new Object[] { text }));
/*     */     }
/* 412 */     c = text.charAt(0);
/* 413 */     char currentCode = 'h';
/* 414 */     int index = 0;
/* 415 */     if (((codeSet == Barcode128CodeSet.AUTO) || (codeSet == Barcode128CodeSet.C)) && (isNextDigits(text, index, 2))) {
/* 416 */       currentCode = 'i';
/* 417 */       out = out + currentCode;
/* 418 */       if (ucc)
/* 419 */         out = out + 'f';
/* 420 */       String out2 = getPackedRawDigits(text, index, 2);
/* 421 */       index += out2.charAt(0);
/* 422 */       out = out + out2.substring(1);
/*     */     }
/* 424 */     else if (c < 32) {
/* 425 */       currentCode = 'g';
/* 426 */       out = out + currentCode;
/* 427 */       if (ucc)
/* 428 */         out = out + 'f';
/* 429 */       out = out + (char)(c + 64);
/* 430 */       index++;
/*     */     }
/*     */     else {
/* 433 */       out = out + currentCode;
/* 434 */       if (ucc)
/* 435 */         out = out + 'f';
/* 436 */       if (c == 202) {
/* 437 */         out = out + 'f';
/*     */       } else
/* 439 */         out = out + (char)(c - 32);
/* 440 */       index++;
/*     */     }
/* 442 */     if ((codeSet != Barcode128CodeSet.AUTO) && (currentCode != codeSet.getStartSymbol()))
/* 443 */       throw new RuntimeException(MessageLocalization.getComposedMessage("there.are.illegal.characters.for.barcode.128.in.1", new Object[] { text }));
/* 444 */     while (index < tLen) {
/* 445 */       switch (currentCode) {
/*     */       case 'g': 
/* 447 */         if ((codeSet == Barcode128CodeSet.AUTO) && (isNextDigits(text, index, 4))) {
/* 448 */           currentCode = 'i';
/* 449 */           out = out + 'c';
/* 450 */           String out2 = getPackedRawDigits(text, index, 4);
/* 451 */           index += out2.charAt(0);
/* 452 */           out = out + out2.substring(1);
/*     */         }
/*     */         else {
/* 455 */           c = text.charAt(index++);
/* 456 */           if (c == 202) {
/* 457 */             out = out + 'f';
/* 458 */           } else if (c > 95) {
/* 459 */             currentCode = 'h';
/* 460 */             out = out + 'd';
/* 461 */             out = out + (char)(c - 32);
/*     */           }
/* 463 */           else if (c < 32) {
/* 464 */             out = out + (char)(c + 64);
/*     */           } else {
/* 466 */             out = out + (char)(c - 32);
/*     */           }
/*     */         }
/* 469 */         break;
/*     */       case 'h': 
/* 471 */         if ((codeSet == Barcode128CodeSet.AUTO) && (isNextDigits(text, index, 4))) {
/* 472 */           currentCode = 'i';
/* 473 */           out = out + 'c';
/* 474 */           String out2 = getPackedRawDigits(text, index, 4);
/* 475 */           index += out2.charAt(0);
/* 476 */           out = out + out2.substring(1);
/*     */         }
/*     */         else {
/* 479 */           c = text.charAt(index++);
/* 480 */           if (c == 202) {
/* 481 */             out = out + 'f';
/* 482 */           } else if (c < 32) {
/* 483 */             currentCode = 'g';
/* 484 */             out = out + 'e';
/* 485 */             out = out + (char)(c + 64);
/*     */           }
/*     */           else {
/* 488 */             out = out + (char)(c - 32);
/*     */           }
/*     */         }
/*     */         
/* 492 */         break;
/*     */       case 'i': 
/* 494 */         if (isNextDigits(text, index, 2)) {
/* 495 */           String out2 = getPackedRawDigits(text, index, 2);
/* 496 */           index += out2.charAt(0);
/* 497 */           out = out + out2.substring(1);
/*     */         }
/*     */         else {
/* 500 */           c = text.charAt(index++);
/* 501 */           if (c == 202) {
/* 502 */             out = out + 'f';
/* 503 */           } else if (c < 32) {
/* 504 */             currentCode = 'g';
/* 505 */             out = out + 'e';
/* 506 */             out = out + (char)(c + 64);
/*     */           }
/*     */           else {
/* 509 */             currentCode = 'h';
/* 510 */             out = out + 'd';
/* 511 */             out = out + (char)(c - 32);
/*     */           }
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/* 517 */       if ((codeSet != Barcode128CodeSet.AUTO) && (currentCode != codeSet.getStartSymbol()))
/* 518 */         throw new RuntimeException(MessageLocalization.getComposedMessage("there.are.illegal.characters.for.barcode.128.in.1", new Object[] { text }));
/*     */     }
/* 520 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getRawText(String text, boolean ucc)
/*     */   {
/* 531 */     return getRawText(text, ucc, Barcode128CodeSet.AUTO);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBarsCode128Raw(String text)
/*     */   {
/* 540 */     int idx = text.indexOf(65535);
/* 541 */     if (idx >= 0)
/* 542 */       text = text.substring(0, idx);
/* 543 */     int chk = text.charAt(0);
/* 544 */     for (int k = 1; k < text.length(); k++)
/* 545 */       chk += k * text.charAt(k);
/* 546 */     chk %= 103;
/* 547 */     text = text + (char)chk;
/* 548 */     byte[] bars = new byte[(text.length() + 1) * 6 + 7];
/*     */     
/* 550 */     for (int k = 0; k < text.length(); k++)
/* 551 */       System.arraycopy(BARS[text.charAt(k)], 0, bars, k * 6, 6);
/* 552 */     System.arraycopy(BARS_STOP, 0, bars, k * 6, 7);
/* 553 */     return bars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBarcodeSize()
/*     */   {
/* 561 */     float fontX = 0.0F;
/* 562 */     float fontY = 0.0F;
/*     */     
/* 564 */     if (this.font != null) {
/* 565 */       if (this.baseline > 0.0F) {
/* 566 */         fontY = this.baseline - this.font.getFontDescriptor(3, this.size);
/*     */       } else
/* 568 */         fontY = -this.baseline + this.size;
/* 569 */       String fullCode; String fullCode; if (this.codeType == 11) {
/* 570 */         int idx = this.code.indexOf(65535);
/* 571 */         String fullCode; if (idx < 0) {
/* 572 */           fullCode = "";
/*     */         } else
/* 574 */           fullCode = this.code.substring(idx + 1);
/*     */       } else { String fullCode;
/* 576 */         if (this.codeType == 10) {
/* 577 */           fullCode = getHumanReadableUCCEAN(this.code);
/*     */         } else
/* 579 */           fullCode = removeFNC1(this.code); }
/* 580 */       fontX = this.font.getWidthPoint(this.altText != null ? this.altText : fullCode, this.size); }
/*     */     String fullCode;
/* 582 */     String fullCode; if (this.codeType == 11) {
/* 583 */       int idx = this.code.indexOf(65535);
/* 584 */       String fullCode; if (idx >= 0) {
/* 585 */         fullCode = this.code.substring(0, idx);
/*     */       } else {
/* 587 */         fullCode = this.code;
/*     */       }
/*     */     } else {
/* 590 */       fullCode = getRawText(this.code, this.codeType == 10, this.codeSet);
/*     */     }
/* 592 */     int len = fullCode.length();
/* 593 */     float fullWidth = (len + 2) * 11 * this.x + 2.0F * this.x;
/* 594 */     fullWidth = Math.max(fullWidth, fontX);
/* 595 */     float fullHeight = this.barHeight + fontY;
/* 596 */     return new Rectangle(fullWidth, fullHeight);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle placeBarcode(PdfContentByte cb, BaseColor barColor, BaseColor textColor)
/*     */   {
/*     */     String fullCode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     String fullCode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 637 */     if (this.codeType == 11) {
/* 638 */       int idx = this.code.indexOf(65535);
/* 639 */       String fullCode; if (idx < 0) {
/* 640 */         fullCode = "";
/*     */       } else
/* 642 */         fullCode = this.code.substring(idx + 1);
/*     */     } else { String fullCode;
/* 644 */       if (this.codeType == 10) {
/* 645 */         fullCode = getHumanReadableUCCEAN(this.code);
/*     */       } else
/* 647 */         fullCode = removeFNC1(this.code); }
/* 648 */     float fontX = 0.0F;
/* 649 */     if (this.font != null)
/* 650 */       fontX = this.font.getWidthPoint(fullCode = this.altText != null ? this.altText : fullCode, this.size);
/*     */     String bCode;
/*     */     String bCode;
/* 653 */     if (this.codeType == 11) {
/* 654 */       int idx = this.code.indexOf(65535);
/* 655 */       String bCode; if (idx >= 0) {
/* 656 */         bCode = this.code.substring(0, idx);
/*     */       } else {
/* 658 */         bCode = this.code;
/*     */       }
/*     */     } else {
/* 661 */       bCode = getRawText(this.code, this.codeType == 10, this.codeSet);
/*     */     }
/* 663 */     int len = bCode.length();
/* 664 */     float fullWidth = (len + 2) * 11 * this.x + 2.0F * this.x;
/* 665 */     float barStartX = 0.0F;
/* 666 */     float textStartX = 0.0F;
/* 667 */     switch (this.textAlignment) {
/*     */     case 0: 
/*     */       break;
/*     */     case 2: 
/* 671 */       if (fontX > fullWidth) {
/* 672 */         barStartX = fontX - fullWidth;
/*     */       } else
/* 674 */         textStartX = fullWidth - fontX;
/* 675 */       break;
/*     */     default: 
/* 677 */       if (fontX > fullWidth) {
/* 678 */         barStartX = (fontX - fullWidth) / 2.0F;
/*     */       } else
/* 680 */         textStartX = (fullWidth - fontX) / 2.0F;
/*     */       break;
/*     */     }
/* 683 */     float barStartY = 0.0F;
/* 684 */     float textStartY = 0.0F;
/* 685 */     if (this.font != null) {
/* 686 */       if (this.baseline <= 0.0F) {
/* 687 */         textStartY = this.barHeight - this.baseline;
/*     */       } else {
/* 689 */         textStartY = -this.font.getFontDescriptor(3, this.size);
/* 690 */         barStartY = textStartY + this.baseline;
/*     */       }
/*     */     }
/* 693 */     byte[] bars = getBarsCode128Raw(bCode);
/* 694 */     boolean print = true;
/* 695 */     if (barColor != null)
/* 696 */       cb.setColorFill(barColor);
/* 697 */     for (int k = 0; k < bars.length; k++) {
/* 698 */       float w = bars[k] * this.x;
/* 699 */       if (print)
/* 700 */         cb.rectangle(barStartX, barStartY, w - this.inkSpreading, this.barHeight);
/* 701 */       print = !print;
/* 702 */       barStartX += w;
/*     */     }
/* 704 */     cb.fill();
/* 705 */     if (this.font != null) {
/* 706 */       if (textColor != null)
/* 707 */         cb.setColorFill(textColor);
/* 708 */       cb.beginText();
/* 709 */       cb.setFontAndSize(this.font, this.size);
/* 710 */       cb.setTextMatrix(textStartX, textStartY);
/* 711 */       cb.showText(fullCode);
/* 712 */       cb.endText();
/*     */     }
/* 714 */     return getBarcodeSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCode(String code)
/*     */   {
/* 725 */     if ((getCodeType() == 10) && (code.startsWith("("))) {
/* 726 */       int idx = 0;
/* 727 */       StringBuilder ret = new StringBuilder("");
/* 728 */       while (idx >= 0) {
/* 729 */         int end = code.indexOf(')', idx);
/* 730 */         if (end < 0)
/* 731 */           throw new IllegalArgumentException(MessageLocalization.getComposedMessage("badly.formed.ucc.string.1", new Object[] { code }));
/* 732 */         String sai = code.substring(idx + 1, end);
/* 733 */         if (sai.length() < 2)
/* 734 */           throw new IllegalArgumentException(MessageLocalization.getComposedMessage("ai.too.short.1", new Object[] { sai }));
/* 735 */         int ai = Integer.parseInt(sai);
/* 736 */         int len = ais.get(ai);
/* 737 */         if (len == 0)
/* 738 */           throw new IllegalArgumentException(MessageLocalization.getComposedMessage("ai.not.found.1", new Object[] { sai }));
/* 739 */         sai = String.valueOf(ai);
/* 740 */         if (sai.length() == 1)
/* 741 */           sai = "0" + sai;
/* 742 */         idx = code.indexOf('(', end);
/* 743 */         int next = idx < 0 ? code.length() : idx;
/* 744 */         ret.append(sai).append(code.substring(end + 1, next));
/* 745 */         if (len < 0) {
/* 746 */           if (idx >= 0) {
/* 747 */             ret.append('Ê');
/*     */           }
/* 749 */         } else if (next - end - 1 + sai.length() != len)
/* 750 */           throw new IllegalArgumentException(MessageLocalization.getComposedMessage("invalid.ai.length.1", new Object[] { sai }));
/*     */       }
/* 752 */       super.setCode(ret.toString());
/*     */     }
/*     */     else {
/* 755 */       super.setCode(code);
/*     */     }
/*     */   }
/*     */   
/* 759 */   static { ais.put(0, 20);
/* 760 */     ais.put(1, 16);
/* 761 */     ais.put(2, 16);
/* 762 */     ais.put(10, -1);
/* 763 */     ais.put(11, 9);
/* 764 */     ais.put(12, 8);
/* 765 */     ais.put(13, 8);
/* 766 */     ais.put(15, 8);
/* 767 */     ais.put(17, 8);
/* 768 */     ais.put(20, 4);
/* 769 */     ais.put(21, -1);
/* 770 */     ais.put(22, -1);
/* 771 */     ais.put(23, -1);
/* 772 */     ais.put(240, -1);
/* 773 */     ais.put(241, -1);
/* 774 */     ais.put(250, -1);
/* 775 */     ais.put(251, -1);
/* 776 */     ais.put(252, -1);
/* 777 */     ais.put(30, -1);
/* 778 */     for (int k = 3100; k < 3700; k++)
/* 779 */       ais.put(k, 10);
/* 780 */     ais.put(37, -1);
/* 781 */     for (int k = 3900; k < 3940; k++)
/* 782 */       ais.put(k, -1);
/* 783 */     ais.put(400, -1);
/* 784 */     ais.put(401, -1);
/* 785 */     ais.put(402, 20);
/* 786 */     ais.put(403, -1);
/* 787 */     for (int k = 410; k < 416; k++)
/* 788 */       ais.put(k, 16);
/* 789 */     ais.put(420, -1);
/* 790 */     ais.put(421, -1);
/* 791 */     ais.put(422, 6);
/* 792 */     ais.put(423, -1);
/* 793 */     ais.put(424, 6);
/* 794 */     ais.put(425, 6);
/* 795 */     ais.put(426, 6);
/* 796 */     ais.put(7001, 17);
/* 797 */     ais.put(7002, -1);
/* 798 */     for (int k = 7030; k < 7040; k++)
/* 799 */       ais.put(k, -1);
/* 800 */     ais.put(8001, 18);
/* 801 */     ais.put(8002, -1);
/* 802 */     ais.put(8003, -1);
/* 803 */     ais.put(8004, -1);
/* 804 */     ais.put(8005, 10);
/* 805 */     ais.put(8006, 22);
/* 806 */     ais.put(8007, -1);
/* 807 */     ais.put(8008, -1);
/* 808 */     ais.put(8018, 22);
/* 809 */     ais.put(8020, -1);
/* 810 */     ais.put(8100, 10);
/* 811 */     ais.put(8101, 14);
/* 812 */     ais.put(8102, 6);
/* 813 */     for (int k = 90; k < 100; k++) {
/* 814 */       ais.put(k, -1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image createAwtImage(Color foreground, Color background)
/*     */   {
/* 826 */     int f = foreground.getRGB();
/* 827 */     int g = background.getRGB();
/* 828 */     Canvas canvas = new Canvas();
/*     */     String bCode;
/* 830 */     String bCode; if (this.codeType == 11) {
/* 831 */       int idx = this.code.indexOf(65535);
/* 832 */       String bCode; if (idx >= 0) {
/* 833 */         bCode = this.code.substring(0, idx);
/*     */       } else {
/* 835 */         bCode = this.code;
/*     */       }
/*     */     } else {
/* 838 */       bCode = getRawText(this.code, this.codeType == 10);
/*     */     }
/* 840 */     int len = bCode.length();
/* 841 */     int fullWidth = (len + 2) * 11 + 2;
/* 842 */     byte[] bars = getBarsCode128Raw(bCode);
/*     */     
/* 844 */     boolean print = true;
/* 845 */     int ptr = 0;
/* 846 */     int height = (int)this.barHeight;
/* 847 */     int[] pix = new int[fullWidth * height];
/* 848 */     for (int k = 0; k < bars.length; k++) {
/* 849 */       int w = bars[k];
/* 850 */       int c = g;
/* 851 */       if (print)
/* 852 */         c = f;
/* 853 */       print = !print;
/* 854 */       for (int j = 0; j < w; j++)
/* 855 */         pix[(ptr++)] = c;
/*     */     }
/* 857 */     for (int k = fullWidth; k < pix.length; k += fullWidth) {
/* 858 */       System.arraycopy(pix, 0, pix, k, fullWidth);
/*     */     }
/* 860 */     Image img = canvas.createImage(new MemoryImageSource(fullWidth, height, pix, 0, fullWidth));
/*     */     
/* 862 */     return img;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/Barcode128.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */