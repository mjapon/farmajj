/*    */ package com.itextpdf.text.pdf.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlyphRenderListener
/*    */   implements RenderListener
/*    */ {
/*    */   private final RenderListener delegate;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GlyphRenderListener(RenderListener delegate)
/*    */   {
/* 53 */     this.delegate = delegate;
/*    */   }
/*    */   
/*    */   public void beginTextBlock() {
/* 57 */     this.delegate.beginTextBlock();
/*    */   }
/*    */   
/*    */   public void renderText(TextRenderInfo renderInfo) {
/* 61 */     for (TextRenderInfo glyphInfo : renderInfo.getCharacterRenderInfos())
/* 62 */       this.delegate.renderText(glyphInfo);
/*    */   }
/*    */   
/*    */   public void endTextBlock() {
/* 66 */     this.delegate.endTextBlock();
/*    */   }
/*    */   
/*    */   public void renderImage(ImageRenderInfo renderInfo) {
/* 70 */     this.delegate.renderImage(renderInfo);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/GlyphRenderListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */