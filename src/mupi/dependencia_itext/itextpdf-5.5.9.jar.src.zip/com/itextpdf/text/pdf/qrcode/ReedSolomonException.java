/*    */ package com.itextpdf.text.pdf.qrcode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReedSolomonException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 2168232776886684292L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReedSolomonException(String message)
/*    */   {
/* 34 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/qrcode/ReedSolomonException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */