/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfDictionary
/*     */   extends PdfObject
/*     */ {
/*  82 */   public static final PdfName FONT = PdfName.FONT;
/*     */   
/*     */ 
/*  85 */   public static final PdfName OUTLINES = PdfName.OUTLINES;
/*     */   
/*     */ 
/*  88 */   public static final PdfName PAGE = PdfName.PAGE;
/*     */   
/*     */ 
/*  91 */   public static final PdfName PAGES = PdfName.PAGES;
/*     */   
/*     */ 
/*  94 */   public static final PdfName CATALOG = PdfName.CATALOG;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  99 */   private PdfName dictionaryType = null;
/*     */   
/*     */ 
/*     */ 
/*     */   protected LinkedHashMap<PdfName, PdfObject> hashMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDictionary()
/*     */   {
/* 110 */     super(6);
/* 111 */     this.hashMap = new LinkedHashMap();
/*     */   }
/*     */   
/*     */   public PdfDictionary(int capacity) {
/* 115 */     super(6);
/* 116 */     this.hashMap = new LinkedHashMap(capacity);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDictionary(PdfName type)
/*     */   {
/* 125 */     this();
/*     */     
/* 127 */     put(PdfName.TYPE, this.dictionaryType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toPdf(PdfWriter writer, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 142 */     PdfWriter.checkPdfIsoConformance(writer, 11, this);
/* 143 */     os.write(60);
/* 144 */     os.write(60);
/*     */     
/*     */ 
/* 147 */     int type = 0;
/* 148 */     for (Map.Entry<PdfName, PdfObject> e : this.hashMap.entrySet()) {
/* 149 */       ((PdfName)e.getKey()).toPdf(writer, os);
/* 150 */       PdfObject value = (PdfObject)e.getValue();
/* 151 */       type = value.type();
/* 152 */       if ((type != 5) && (type != 6) && (type != 4) && (type != 3))
/* 153 */         os.write(32);
/* 154 */       value.toPdf(writer, os);
/*     */     }
/* 156 */     os.write(62);
/* 157 */     os.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 172 */     if (get(PdfName.TYPE) == null)
/* 173 */       return "Dictionary";
/* 174 */     return "Dictionary of type: " + get(PdfName.TYPE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(PdfName key, PdfObject object)
/*     */   {
/* 192 */     if ((object == null) || (object.isNull())) {
/* 193 */       this.hashMap.remove(key);
/*     */     } else {
/* 195 */       this.hashMap.put(key, object);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putEx(PdfName key, PdfObject value)
/*     */   {
/* 211 */     if (value == null)
/* 212 */       return;
/* 213 */     put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putAll(PdfDictionary dic)
/*     */   {
/* 227 */     this.hashMap.putAll(dic.hashMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(PdfName key)
/*     */   {
/* 237 */     this.hashMap.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 246 */     this.hashMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject get(PdfName key)
/*     */   {
/* 258 */     return (PdfObject)this.hashMap.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject getDirectObject(PdfName key)
/*     */   {
/* 273 */     return PdfReader.getPdfObject(get(key));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<PdfName> getKeys()
/*     */   {
/* 282 */     return this.hashMap.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 293 */     return this.hashMap.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(PdfName key)
/*     */   {
/* 303 */     return this.hashMap.containsKey(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFont()
/*     */   {
/* 314 */     return checkType(FONT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPage()
/*     */   {
/* 323 */     return checkType(PAGE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPages()
/*     */   {
/* 332 */     return checkType(PAGES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCatalog()
/*     */   {
/* 341 */     return checkType(CATALOG);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOutlineTree()
/*     */   {
/* 350 */     return checkType(OUTLINES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkType(PdfName type)
/*     */   {
/* 359 */     if (type == null)
/* 360 */       return false;
/* 361 */     if (this.dictionaryType == null)
/* 362 */       this.dictionaryType = getAsName(PdfName.TYPE);
/* 363 */     return type.equals(this.dictionaryType);
/*     */   }
/*     */   
/*     */ 
/*     */   public void merge(PdfDictionary other)
/*     */   {
/* 369 */     this.hashMap.putAll(other.hashMap);
/*     */   }
/*     */   
/*     */   public void mergeDifferent(PdfDictionary other) {
/* 373 */     for (PdfName key : other.hashMap.keySet()) {
/* 374 */       if (!this.hashMap.containsKey(key)) {
/* 375 */         this.hashMap.put(key, other.hashMap.get(key));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDictionary getAsDict(PdfName key)
/*     */   {
/* 396 */     PdfDictionary dict = null;
/* 397 */     PdfObject orig = getDirectObject(key);
/* 398 */     if ((orig != null) && (orig.isDictionary()))
/* 399 */       dict = (PdfDictionary)orig;
/* 400 */     return dict;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray getAsArray(PdfName key)
/*     */   {
/* 417 */     PdfArray array = null;
/* 418 */     PdfObject orig = getDirectObject(key);
/* 419 */     if ((orig != null) && (orig.isArray()))
/* 420 */       array = (PdfArray)orig;
/* 421 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStream getAsStream(PdfName key)
/*     */   {
/* 438 */     PdfStream stream = null;
/* 439 */     PdfObject orig = getDirectObject(key);
/* 440 */     if ((orig != null) && (orig.isStream()))
/* 441 */       stream = (PdfStream)orig;
/* 442 */     return stream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfString getAsString(PdfName key)
/*     */   {
/* 459 */     PdfString string = null;
/* 460 */     PdfObject orig = getDirectObject(key);
/* 461 */     if ((orig != null) && (orig.isString()))
/* 462 */       string = (PdfString)orig;
/* 463 */     return string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfNumber getAsNumber(PdfName key)
/*     */   {
/* 480 */     PdfNumber number = null;
/* 481 */     PdfObject orig = getDirectObject(key);
/* 482 */     if ((orig != null) && (orig.isNumber()))
/* 483 */       number = (PdfNumber)orig;
/* 484 */     return number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfName getAsName(PdfName key)
/*     */   {
/* 501 */     PdfName name = null;
/* 502 */     PdfObject orig = getDirectObject(key);
/* 503 */     if ((orig != null) && (orig.isName()))
/* 504 */       name = (PdfName)orig;
/* 505 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfBoolean getAsBoolean(PdfName key)
/*     */   {
/* 522 */     PdfBoolean bool = null;
/* 523 */     PdfObject orig = getDirectObject(key);
/* 524 */     if ((orig != null) && (orig.isBoolean()))
/* 525 */       bool = (PdfBoolean)orig;
/* 526 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfIndirectReference getAsIndirectObject(PdfName key)
/*     */   {
/* 541 */     PdfIndirectReference ref = null;
/* 542 */     PdfObject orig = get(key);
/* 543 */     if ((orig != null) && (orig.isIndirect()))
/* 544 */       ref = (PdfIndirectReference)orig;
/* 545 */     return ref;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfDictionary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */