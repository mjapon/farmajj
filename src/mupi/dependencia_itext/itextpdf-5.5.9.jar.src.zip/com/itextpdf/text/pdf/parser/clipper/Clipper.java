/*    */ package com.itextpdf.text.pdf.parser.clipper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface Clipper
/*    */ {
/*    */   public static final int REVERSE_SOLUTION = 1;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final int STRICTLY_SIMPLE = 2;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final int PRESERVE_COLINEAR = 4;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract boolean addPath(Path paramPath, PolyType paramPolyType, boolean paramBoolean);
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract boolean addPaths(Paths paramPaths, PolyType paramPolyType, boolean paramBoolean);
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract void clear();
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract boolean execute(ClipType paramClipType, Paths paramPaths);
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract boolean execute(ClipType paramClipType, Paths paramPaths, PolyFillType paramPolyFillType1, PolyFillType paramPolyFillType2);
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract boolean execute(ClipType paramClipType, PolyTree paramPolyTree);
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract boolean execute(ClipType paramClipType, PolyTree paramPolyTree, PolyFillType paramPolyFillType1, PolyFillType paramPolyFillType2);
/*    */   
/*    */ 
/*    */ 
/*    */   public static enum ClipType
/*    */   {
/* 51 */     INTERSECTION,  UNION,  DIFFERENCE,  XOR;
/*    */     
/*    */     private ClipType() {} }
/*    */   
/* 55 */   public static enum Direction { RIGHT_TO_LEFT,  LEFT_TO_RIGHT;
/*    */     
/*    */     private Direction() {} }
/*    */   
/* 59 */   public static enum EndType { CLOSED_POLYGON,  CLOSED_LINE,  OPEN_BUTT,  OPEN_SQUARE,  OPEN_ROUND;
/*    */     
/*    */     private EndType() {} }
/*    */   
/* 63 */   public static enum JoinType { BEVEL,  ROUND,  MITER;
/*    */     
/*    */     private JoinType() {} }
/*    */   
/* 67 */   public static enum PolyFillType { EVEN_ODD,  NON_ZERO,  POSITIVE,  NEGATIVE;
/*    */     
/*    */     private PolyFillType() {} }
/*    */   
/* 71 */   public static enum PolyType { SUBJECT,  CLIP;
/*    */     
/*    */     private PolyType() {}
/*    */   }
/*    */   
/*    */   public static abstract interface ZFillCallback
/*    */   {
/*    */     public abstract void zFill(Point.LongPoint paramLongPoint1, Point.LongPoint paramLongPoint2, Point.LongPoint paramLongPoint3, Point.LongPoint paramLongPoint4, Point.LongPoint paramLongPoint5);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/Clipper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */