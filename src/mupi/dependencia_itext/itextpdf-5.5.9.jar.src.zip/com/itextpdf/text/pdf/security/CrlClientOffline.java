/*    */ package com.itextpdf.text.pdf.security;
/*    */ 
/*    */ import com.itextpdf.text.ExceptionConverter;
/*    */ import java.security.cert.CRL;
/*    */ import java.security.cert.X509CRL;
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CrlClientOffline
/*    */   implements CrlClient
/*    */ {
/* 62 */   private ArrayList<byte[]> crls = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CrlClientOffline(byte[] crlEncoded)
/*    */   {
/* 70 */     this.crls.add(crlEncoded);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CrlClientOffline(CRL crl)
/*    */   {
/*    */     try
/*    */     {
/* 80 */       this.crls.add(((X509CRL)crl).getEncoded());
/*    */     }
/*    */     catch (Exception ex) {
/* 83 */       throw new ExceptionConverter(ex);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Collection<byte[]> getEncoded(X509Certificate checkCert, String url)
/*    */   {
/* 92 */     return this.crls;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/CrlClientOffline.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */