/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfStructTreeController
/*     */ {
/*     */   private PdfDictionary structTreeRoot;
/*     */   private PdfCopy writer;
/*     */   private PdfStructureTreeRoot structureTreeRoot;
/*     */   private PdfDictionary parentTree;
/*     */   protected PdfReader reader;
/*  61 */   private PdfDictionary roleMap = null;
/*  62 */   private PdfDictionary sourceRoleMap = null;
/*  63 */   private PdfDictionary sourceClassMap = null;
/*  64 */   private PdfIndirectReference nullReference = null;
/*     */   
/*     */   public static enum returnType {
/*  67 */     BELOW,  FOUND,  ABOVE,  NOTFOUND;
/*     */     
/*     */     private returnType() {} }
/*  70 */   protected PdfStructTreeController(PdfReader reader, PdfCopy writer) throws BadPdfFormatException { if (!writer.isTagged())
/*  71 */       throw new BadPdfFormatException(MessageLocalization.getComposedMessage("no.structtreeroot.found", new Object[0]));
/*  72 */     this.writer = writer;
/*  73 */     this.structureTreeRoot = writer.getStructureTreeRoot();
/*  74 */     this.structureTreeRoot.put(PdfName.PARENTTREE, new PdfDictionary(PdfName.STRUCTELEM));
/*  75 */     setReader(reader);
/*     */   }
/*     */   
/*     */   protected void setReader(PdfReader reader) throws BadPdfFormatException {
/*  79 */     this.reader = reader;
/*  80 */     PdfObject obj = reader.getCatalog().get(PdfName.STRUCTTREEROOT);
/*  81 */     obj = getDirectObject(obj);
/*  82 */     if ((obj == null) || (!obj.isDictionary()))
/*  83 */       throw new BadPdfFormatException(MessageLocalization.getComposedMessage("no.structtreeroot.found", new Object[0]));
/*  84 */     this.structTreeRoot = ((PdfDictionary)obj);
/*  85 */     obj = getDirectObject(this.structTreeRoot.get(PdfName.PARENTTREE));
/*  86 */     if ((obj == null) || (!obj.isDictionary()))
/*  87 */       throw new BadPdfFormatException(MessageLocalization.getComposedMessage("the.document.does.not.contain.parenttree", new Object[0]));
/*  88 */     this.parentTree = ((PdfDictionary)obj);
/*  89 */     this.sourceRoleMap = null;
/*  90 */     this.sourceClassMap = null;
/*  91 */     this.nullReference = null;
/*     */   }
/*     */   
/*     */   public static boolean checkTagged(PdfReader reader) {
/*  95 */     PdfObject obj = reader.getCatalog().get(PdfName.STRUCTTREEROOT);
/*  96 */     obj = getDirectObject(obj);
/*  97 */     if ((obj == null) || (!obj.isDictionary()))
/*  98 */       return false;
/*  99 */     PdfDictionary structTreeRoot = (PdfDictionary)obj;
/* 100 */     obj = getDirectObject(structTreeRoot.get(PdfName.PARENTTREE));
/* 101 */     if ((obj == null) || (!obj.isDictionary()))
/* 102 */       return false;
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   public static PdfObject getDirectObject(PdfObject object) {
/* 107 */     if (object == null)
/* 108 */       return null;
/* 109 */     while (object.isIndirect())
/* 110 */       object = PdfReader.getPdfObjectRelease(object);
/* 111 */     return object;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyStructTreeForPage(PdfNumber sourceArrayNumber, int newArrayNumber)
/*     */     throws BadPdfFormatException, IOException
/*     */   {
/* 120 */     if (copyPageMarks(this.parentTree, sourceArrayNumber, newArrayNumber) == returnType.NOTFOUND) {
/* 121 */       throw new BadPdfFormatException(MessageLocalization.getComposedMessage("invalid.structparent", new Object[0]));
/*     */     }
/*     */   }
/*     */   
/*     */   private returnType copyPageMarks(PdfDictionary parentTree, PdfNumber arrayNumber, int newArrayNumber) throws BadPdfFormatException, IOException {
/* 126 */     PdfArray pages = (PdfArray)getDirectObject(parentTree.get(PdfName.NUMS));
/* 127 */     if (pages == null) {
/* 128 */       PdfArray kids = (PdfArray)getDirectObject(parentTree.get(PdfName.KIDS));
/* 129 */       if (kids == null)
/* 130 */         return returnType.NOTFOUND;
/* 131 */       int cur = kids.size() / 2;
/* 132 */       int begin = 0;
/*     */       for (;;) {
/* 134 */         PdfDictionary kidTree = (PdfDictionary)getDirectObject(kids.getPdfObject(cur + begin));
/* 135 */         switch (copyPageMarks(kidTree, arrayNumber, newArrayNumber)) {
/*     */         case FOUND: 
/* 137 */           return returnType.FOUND;
/*     */         case ABOVE: 
/* 139 */           begin += cur;
/* 140 */           cur /= 2;
/* 141 */           if (cur == 0)
/* 142 */             cur = 1;
/* 143 */           if (cur + begin == kids.size())
/* 144 */             return returnType.ABOVE;
/*     */           break;
/*     */         case BELOW: 
/* 147 */           if (cur + begin == 0)
/* 148 */             return returnType.BELOW;
/* 149 */           if (cur == 0)
/* 150 */             return returnType.NOTFOUND;
/* 151 */           cur /= 2;
/* 152 */           break;
/*     */         default: 
/* 154 */           return returnType.NOTFOUND;
/*     */         }
/*     */       }
/*     */     }
/* 158 */     if (pages.size() == 0)
/* 159 */       return returnType.NOTFOUND;
/* 160 */     return findAndCopyMarks(pages, arrayNumber.intValue(), newArrayNumber);
/*     */   }
/*     */   
/*     */   private returnType findAndCopyMarks(PdfArray pages, int arrayNumber, int newArrayNumber) throws BadPdfFormatException, IOException
/*     */   {
/* 165 */     if (pages.getAsNumber(0).intValue() > arrayNumber)
/* 166 */       return returnType.BELOW;
/* 167 */     if (pages.getAsNumber(pages.size() - 2).intValue() < arrayNumber)
/* 168 */       return returnType.ABOVE;
/* 169 */     int cur = pages.size() / 4;
/* 170 */     int begin = 0;
/*     */     
/*     */     for (;;)
/*     */     {
/* 174 */       int curNumber = pages.getAsNumber((begin + cur) * 2).intValue();
/* 175 */       if (curNumber == arrayNumber) {
/* 176 */         PdfObject obj = pages.getPdfObject((begin + cur) * 2 + 1);
/* 177 */         PdfObject obj1 = obj;
/* 178 */         while (obj.isIndirect()) obj = PdfReader.getPdfObjectRelease(obj);
/* 179 */         if (obj.isArray()) {
/* 180 */           PdfObject firstNotNullKid = null;
/* 181 */           for (PdfObject numObj : (PdfArray)obj) {
/* 182 */             if (numObj.isNull()) {
/* 183 */               if (this.nullReference == null)
/* 184 */                 this.nullReference = this.writer.addToBody(new PdfNull()).getIndirectReference();
/* 185 */               this.structureTreeRoot.setPageMark(newArrayNumber, this.nullReference);
/*     */             } else {
/* 187 */               PdfObject res = this.writer.copyObject(numObj, true, false);
/* 188 */               if (firstNotNullKid == null) firstNotNullKid = res;
/* 189 */               this.structureTreeRoot.setPageMark(newArrayNumber, (PdfIndirectReference)res);
/*     */             }
/*     */           }
/* 192 */           attachStructTreeRootKids(firstNotNullKid);
/* 193 */         } else if (obj.isDictionary()) {
/* 194 */           PdfDictionary k = getKDict((PdfDictionary)obj);
/* 195 */           if (k == null)
/* 196 */             return returnType.NOTFOUND;
/* 197 */           PdfObject res = this.writer.copyObject(obj1, true, false);
/* 198 */           this.structureTreeRoot.setAnnotationMark(newArrayNumber, (PdfIndirectReference)res);
/*     */         } else {
/* 200 */           return returnType.NOTFOUND; }
/* 201 */         return returnType.FOUND;
/*     */       }
/* 203 */       if (curNumber < arrayNumber) {
/* 204 */         if (cur == 0)
/* 205 */           return returnType.NOTFOUND;
/* 206 */         begin += cur;
/* 207 */         if (cur != 1)
/* 208 */           cur /= 2;
/* 209 */         if (cur + begin == pages.size()) {
/* 210 */           return returnType.NOTFOUND;
/*     */         }
/*     */       } else {
/* 213 */         if (cur + begin == 0)
/* 214 */           return returnType.BELOW;
/* 215 */         if (cur == 0)
/* 216 */           return returnType.NOTFOUND;
/* 217 */         cur /= 2;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void attachStructTreeRootKids(PdfObject firstNotNullKid)
/*     */     throws IOException, BadPdfFormatException
/*     */   {
/* 225 */     PdfObject structKids = this.structTreeRoot.get(PdfName.K);
/* 226 */     if ((structKids == null) || ((!structKids.isArray()) && (!structKids.isIndirect())))
/*     */     {
/* 228 */       addKid(this.structureTreeRoot, firstNotNullKid);
/*     */     }
/* 230 */     else if (structKids.isIndirect()) {
/* 231 */       addKid(structKids);
/*     */     } else {
/* 233 */       for (PdfObject kid : (PdfArray)structKids) {
/* 234 */         addKid(kid);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static PdfDictionary getKDict(PdfDictionary obj) {
/* 240 */     PdfDictionary k = obj.getAsDict(PdfName.K);
/* 241 */     if (k != null) {
/* 242 */       if (PdfName.OBJR.equals(k.getAsName(PdfName.TYPE))) {
/* 243 */         return k;
/*     */       }
/*     */     } else {
/* 246 */       PdfArray k1 = obj.getAsArray(PdfName.K);
/* 247 */       if (k1 == null)
/* 248 */         return null;
/* 249 */       for (int i = 0; i < k1.size(); i++) {
/* 250 */         k = k1.getAsDict(i);
/* 251 */         if ((k != null) && 
/* 252 */           (PdfName.OBJR.equals(k.getAsName(PdfName.TYPE)))) {
/* 253 */           return k;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 258 */     return null;
/*     */   }
/*     */   
/*     */   private void addKid(PdfObject obj) throws IOException, BadPdfFormatException {
/* 262 */     if (!obj.isIndirect()) return;
/* 263 */     PRIndirectReference currRef = (PRIndirectReference)obj;
/* 264 */     RefKey key = new RefKey(currRef);
/* 265 */     if (!this.writer.indirects.containsKey(key)) {
/* 266 */       this.writer.copyIndirect(currRef, true, false);
/*     */     }
/* 268 */     PdfIndirectReference newKid = ((PdfCopy.IndirectReferences)this.writer.indirects.get(key)).getRef();
/*     */     
/* 270 */     if (this.writer.updateRootKids) {
/* 271 */       addKid(this.structureTreeRoot, newKid);
/* 272 */       this.writer.structureTreeRootKidsForReaderImported(this.reader);
/*     */     }
/*     */   }
/*     */   
/*     */   private static PdfArray getDirectArray(PdfArray in) {
/* 277 */     PdfArray out = new PdfArray();
/* 278 */     for (int i = 0; i < in.size(); i++) {
/* 279 */       PdfObject value = getDirectObject(in.getPdfObject(i));
/* 280 */       if (value != null)
/*     */       {
/* 282 */         if (value.isArray()) {
/* 283 */           out.add(getDirectArray((PdfArray)value));
/* 284 */         } else if (value.isDictionary()) {
/* 285 */           out.add(getDirectDict((PdfDictionary)value));
/*     */         } else
/* 287 */           out.add(value);
/*     */       }
/*     */     }
/* 290 */     return out;
/*     */   }
/*     */   
/*     */   private static PdfDictionary getDirectDict(PdfDictionary in) {
/* 294 */     PdfDictionary out = new PdfDictionary();
/* 295 */     for (Map.Entry<PdfName, PdfObject> entry : in.hashMap.entrySet()) {
/* 296 */       PdfObject value = getDirectObject((PdfObject)entry.getValue());
/* 297 */       if (value != null)
/*     */       {
/* 299 */         if (value.isArray()) {
/* 300 */           out.put((PdfName)entry.getKey(), getDirectArray((PdfArray)value));
/* 301 */         } else if (value.isDictionary()) {
/* 302 */           out.put((PdfName)entry.getKey(), getDirectDict((PdfDictionary)value));
/*     */         } else
/* 304 */           out.put((PdfName)entry.getKey(), value);
/*     */       }
/*     */     }
/* 307 */     return out;
/*     */   }
/*     */   
/*     */   public static boolean compareObjects(PdfObject value1, PdfObject value2) {
/* 311 */     value2 = getDirectObject(value2);
/* 312 */     if (value2 == null)
/* 313 */       return false;
/* 314 */     if (value1.type() != value2.type()) {
/* 315 */       return false;
/*     */     }
/* 317 */     if (value1.isBoolean()) {
/* 318 */       if (value1 == value2)
/* 319 */         return true;
/* 320 */       if ((value2 instanceof PdfBoolean)) {
/* 321 */         return ((PdfBoolean)value1).booleanValue() == ((PdfBoolean)value2).booleanValue();
/*     */       }
/* 323 */       return false; }
/* 324 */     if (value1.isName())
/* 325 */       return value1.equals(value2);
/* 326 */     if (value1.isNumber()) {
/* 327 */       if (value1 == value2)
/* 328 */         return true;
/* 329 */       if ((value2 instanceof PdfNumber)) {
/* 330 */         return ((PdfNumber)value1).doubleValue() == ((PdfNumber)value2).doubleValue();
/*     */       }
/* 332 */       return false; }
/* 333 */     if (value1.isNull()) {
/* 334 */       if (value1 == value2)
/* 335 */         return true;
/* 336 */       if ((value2 instanceof PdfNull))
/* 337 */         return true;
/* 338 */       return false; }
/* 339 */     if (value1.isString()) {
/* 340 */       if (value1 == value2)
/* 341 */         return true;
/* 342 */       if ((value2 instanceof PdfString))
/*     */       {
/* 344 */         return ((((PdfString)value2).value == null) && (((PdfString)value1).value == null)) || ((((PdfString)value1).value != null) && (((PdfString)value1).value.equals(((PdfString)value2).value)));
/*     */       }
/* 346 */       return false; }
/*     */     int i;
/* 348 */     if (value1.isArray()) {
/* 349 */       PdfArray array1 = (PdfArray)value1;
/* 350 */       PdfArray array2 = (PdfArray)value2;
/* 351 */       if (array1.size() != array2.size())
/* 352 */         return false;
/* 353 */       for (i = 0; i < array1.size(); i++)
/* 354 */         if (!compareObjects(array1.getPdfObject(i), array2.getPdfObject(i)))
/* 355 */           return false;
/* 356 */       return true;
/*     */     }
/* 358 */     if (value1.isDictionary()) {
/* 359 */       PdfDictionary first = (PdfDictionary)value1;
/* 360 */       PdfDictionary second = (PdfDictionary)value2;
/* 361 */       if (first.size() != second.size())
/* 362 */         return false;
/* 363 */       for (PdfName name : first.hashMap.keySet()) {
/* 364 */         if (!compareObjects(first.get(name), second.get(name)))
/* 365 */           return false;
/*     */       }
/* 367 */       return true;
/*     */     }
/* 369 */     return false;
/*     */   }
/*     */   
/*     */   protected void addClass(PdfObject object) throws BadPdfFormatException {
/* 373 */     object = getDirectObject(object);
/* 374 */     if (object.isDictionary()) {
/* 375 */       PdfObject curClass = ((PdfDictionary)object).get(PdfName.C);
/* 376 */       if (curClass == null)
/* 377 */         return;
/* 378 */       if (curClass.isArray()) {
/* 379 */         PdfArray array = (PdfArray)curClass;
/* 380 */         for (int i = 0; i < array.size(); i++) {
/* 381 */           addClass(array.getPdfObject(i));
/*     */         }
/* 383 */       } else if (curClass.isName()) {
/* 384 */         addClass(curClass);
/* 385 */       } } else if (object.isName()) {
/* 386 */       PdfName name = (PdfName)object;
/* 387 */       if (this.sourceClassMap == null) {
/* 388 */         object = getDirectObject(this.structTreeRoot.get(PdfName.CLASSMAP));
/* 389 */         if ((object == null) || (!object.isDictionary())) {
/* 390 */           return;
/*     */         }
/* 392 */         this.sourceClassMap = ((PdfDictionary)object);
/*     */       }
/* 394 */       object = getDirectObject(this.sourceClassMap.get(name));
/* 395 */       if (object == null) {
/* 396 */         return;
/*     */       }
/* 398 */       PdfObject put = this.structureTreeRoot.getMappedClass(name);
/* 399 */       if (put != null) {
/* 400 */         if (!compareObjects(put, object)) {
/* 401 */           throw new BadPdfFormatException(MessageLocalization.getComposedMessage("conflict.in.classmap", new Object[] { name }));
/*     */         }
/*     */       }
/* 404 */       else if (object.isDictionary()) {
/* 405 */         this.structureTreeRoot.mapClass(name, getDirectDict((PdfDictionary)object));
/* 406 */       } else if (object.isArray()) {
/* 407 */         this.structureTreeRoot.mapClass(name, getDirectArray((PdfArray)object));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addRole(PdfName structType) throws BadPdfFormatException
/*     */   {
/* 414 */     if (structType == null) {
/* 415 */       return;
/*     */     }
/* 417 */     for (PdfName name : this.writer.getStandardStructElems()) {
/* 418 */       if (name.equals(structType))
/* 419 */         return;
/*     */     }
/* 421 */     if (this.sourceRoleMap == null) {
/* 422 */       PdfObject object = getDirectObject(this.structTreeRoot.get(PdfName.ROLEMAP));
/* 423 */       if ((object == null) || (!object.isDictionary())) {
/* 424 */         return;
/*     */       }
/* 426 */       this.sourceRoleMap = ((PdfDictionary)object);
/*     */     }
/* 428 */     PdfObject object = this.sourceRoleMap.get(structType);
/* 429 */     if ((object == null) || (!object.isName())) {
/* 430 */       return;
/*     */     }
/*     */     
/* 433 */     if (this.roleMap == null) {
/* 434 */       this.roleMap = new PdfDictionary();
/* 435 */       this.structureTreeRoot.put(PdfName.ROLEMAP, this.roleMap);
/* 436 */       this.roleMap.put(structType, object); } else { PdfObject currentRole;
/* 437 */       if ((currentRole = this.roleMap.get(structType)) != null) {
/* 438 */         if (!currentRole.equals(object)) {
/* 439 */           throw new BadPdfFormatException(MessageLocalization.getComposedMessage("conflict.in.rolemap", new Object[] { object }));
/*     */         }
/*     */       } else
/* 442 */         this.roleMap.put(structType, object);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addKid(PdfDictionary parent, PdfObject kid) {
/* 447 */     PdfObject kidObj = parent.get(PdfName.K);
/*     */     PdfArray kids;
/* 449 */     PdfArray kids; if ((kidObj instanceof PdfArray)) {
/* 450 */       kids = (PdfArray)kidObj;
/*     */     } else {
/* 452 */       kids = new PdfArray();
/* 453 */       if (kidObj != null)
/* 454 */         kids.add(kidObj);
/*     */     }
/* 456 */     kids.add(kid);
/* 457 */     parent.put(PdfName.K, kids);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfStructTreeController.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */