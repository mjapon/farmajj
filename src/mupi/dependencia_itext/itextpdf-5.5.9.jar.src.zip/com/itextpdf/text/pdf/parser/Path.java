/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.awt.geom.Point2D;
/*     */ import com.itextpdf.awt.geom.Point2D.Float;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Path
/*     */ {
/*     */   private static final String START_PATH_ERR_MSG = "Path shall start with \"re\" or \"m\" operator";
/*  65 */   private List<Subpath> subpaths = new ArrayList();
/*     */   private Point2D currentPoint;
/*     */   
/*     */   public Path() {}
/*     */   
/*     */   public Path(List<? extends Subpath> subpaths)
/*     */   {
/*  72 */     addSubpaths(subpaths);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Subpath> getSubpaths()
/*     */   {
/*  79 */     return this.subpaths;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSubpath(Subpath subpath)
/*     */   {
/*  88 */     this.subpaths.add(subpath);
/*  89 */     this.currentPoint = subpath.getLastPoint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSubpaths(List<? extends Subpath> subpaths)
/*     */   {
/*  98 */     if (subpaths.size() > 0) {
/*  99 */       this.subpaths.addAll(subpaths);
/* 100 */       this.currentPoint = ((Subpath)this.subpaths.get(subpaths.size() - 1)).getLastPoint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point2D getCurrentPoint()
/*     */   {
/* 110 */     return this.currentPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void moveTo(float x, float y)
/*     */   {
/* 117 */     this.currentPoint = new Point2D.Float(x, y);
/* 118 */     Subpath lastSubpath = getLastSubpath();
/*     */     
/* 120 */     if ((lastSubpath != null) && (lastSubpath.isSinglePointOpen())) {
/* 121 */       lastSubpath.setStartPoint(this.currentPoint);
/*     */     } else {
/* 123 */       this.subpaths.add(new Subpath(this.currentPoint));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void lineTo(float x, float y)
/*     */   {
/* 131 */     if (this.currentPoint == null) {
/* 132 */       throw new RuntimeException("Path shall start with \"re\" or \"m\" operator");
/*     */     }
/*     */     
/* 135 */     Point2D targetPoint = new Point2D.Float(x, y);
/* 136 */     getLastSubpath().addSegment(new Line(this.currentPoint, targetPoint));
/* 137 */     this.currentPoint = targetPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void curveTo(float x1, float y1, float x2, float y2, float x3, float y3)
/*     */   {
/* 145 */     if (this.currentPoint == null) {
/* 146 */       throw new RuntimeException("Path shall start with \"re\" or \"m\" operator");
/*     */     }
/*     */     
/* 149 */     Point2D secondPoint = new Point2D.Float(x1, y1);
/* 150 */     Point2D thirdPoint = new Point2D.Float(x2, y2);
/* 151 */     Point2D fourthPoint = new Point2D.Float(x3, y3);
/*     */     
/* 153 */     List<Point2D> controlPoints = new ArrayList(Arrays.asList(new Point2D[] { this.currentPoint, secondPoint, thirdPoint, fourthPoint }));
/* 154 */     getLastSubpath().addSegment(new BezierCurve(controlPoints));
/*     */     
/* 156 */     this.currentPoint = fourthPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void curveTo(float x2, float y2, float x3, float y3)
/*     */   {
/* 165 */     if (this.currentPoint == null) {
/* 166 */       throw new RuntimeException("Path shall start with \"re\" or \"m\" operator");
/*     */     }
/*     */     
/* 169 */     curveTo((float)this.currentPoint.getX(), (float)this.currentPoint.getY(), x2, y2, x3, y3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void curveFromTo(float x1, float y1, float x3, float y3)
/*     */   {
/* 178 */     if (this.currentPoint == null) {
/* 179 */       throw new RuntimeException("Path shall start with \"re\" or \"m\" operator");
/*     */     }
/*     */     
/* 182 */     curveTo(x1, y1, x3, y3, x3, y3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rectangle(float x, float y, float w, float h)
/*     */   {
/* 189 */     moveTo(x, y);
/* 190 */     lineTo(x + w, y);
/* 191 */     lineTo(x + w, y + h);
/* 192 */     lineTo(x, y + h);
/* 193 */     closeSubpath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeSubpath()
/*     */   {
/* 200 */     Subpath lastSubpath = getLastSubpath();
/* 201 */     lastSubpath.setClosed(true);
/*     */     
/* 203 */     Point2D startPoint = lastSubpath.getStartPoint();
/* 204 */     moveTo((float)startPoint.getX(), (float)startPoint.getY());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeAllSubpaths()
/*     */   {
/* 211 */     for (Subpath subpath : this.subpaths) {
/* 212 */       subpath.setClosed(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Integer> replaceCloseWithLine()
/*     */   {
/* 223 */     List<Integer> modifiedSubpathsIndices = new ArrayList();
/* 224 */     int i = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     for (Subpath subpath : this.subpaths) {
/* 231 */       if (subpath.isClosed()) {
/* 232 */         subpath.setClosed(false);
/* 233 */         subpath.addSegment(new Line(subpath.getLastPoint(), subpath.getStartPoint()));
/* 234 */         modifiedSubpathsIndices.add(Integer.valueOf(i));
/*     */       }
/*     */       
/* 237 */       i++;
/*     */     }
/*     */     
/* 240 */     return modifiedSubpathsIndices;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 247 */     return this.subpaths.size() == 0;
/*     */   }
/*     */   
/*     */   private Subpath getLastSubpath() {
/* 251 */     return this.subpaths.size() > 0 ? (Subpath)this.subpaths.get(this.subpaths.size() - 1) : null;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/Path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */