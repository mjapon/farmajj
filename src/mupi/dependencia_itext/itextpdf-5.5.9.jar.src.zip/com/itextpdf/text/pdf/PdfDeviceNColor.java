/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfDeviceNColor
/*     */   implements ICachedColorSpace, IPdfSpecialColorSpace
/*     */ {
/*     */   PdfSpotColor[] spotColors;
/*     */   ColorDetails[] colorantsDetails;
/*     */   
/*     */   public PdfDeviceNColor(PdfSpotColor[] spotColors)
/*     */   {
/*  58 */     this.spotColors = spotColors;
/*     */   }
/*     */   
/*     */   public int getNumberOfColorants() {
/*  62 */     return this.spotColors.length;
/*     */   }
/*     */   
/*     */   public PdfSpotColor[] getSpotColors() {
/*  66 */     return this.spotColors;
/*     */   }
/*     */   
/*     */   public ColorDetails[] getColorantDetails(PdfWriter writer) {
/*  70 */     if (this.colorantsDetails == null) {
/*  71 */       this.colorantsDetails = new ColorDetails[this.spotColors.length];
/*  72 */       int i = 0;
/*  73 */       for (PdfSpotColor spotColorant : this.spotColors) {
/*  74 */         this.colorantsDetails[i] = writer.addSimple(spotColorant);
/*  75 */         i++;
/*     */       }
/*     */     }
/*  78 */     return this.colorantsDetails;
/*     */   }
/*     */   
/*     */   public PdfObject getPdfObject(PdfWriter writer) {
/*  82 */     PdfArray array = new PdfArray(PdfName.DEVICEN);
/*     */     
/*  84 */     PdfArray colorants = new PdfArray();
/*  85 */     float[] colorantsRanges = new float[this.spotColors.length * 2];
/*  86 */     PdfDictionary colorantsDict = new PdfDictionary();
/*  87 */     String psFunFooter = "";
/*     */     
/*  89 */     int numberOfColorants = this.spotColors.length;
/*  90 */     float[][] CMYK = new float[4][numberOfColorants];
/*  91 */     for (int i = 0; 
/*  92 */         i < numberOfColorants; i++) {
/*  93 */       PdfSpotColor spotColorant = this.spotColors[i];
/*  94 */       colorantsRanges[(2 * i)] = 0.0F;
/*  95 */       colorantsRanges[(2 * i + 1)] = 1.0F;
/*  96 */       colorants.add(spotColorant.getName());
/*  97 */       if (colorantsDict.get(spotColorant.getName()) != null)
/*  98 */         throw new RuntimeException(MessageLocalization.getComposedMessage("devicen.component.names.shall.be.different", new Object[0]));
/*  99 */       if (this.colorantsDetails != null) {
/* 100 */         colorantsDict.put(spotColorant.getName(), this.colorantsDetails[i].getIndirectReference());
/*     */       } else
/* 102 */         colorantsDict.put(spotColorant.getName(), spotColorant.getPdfObject(writer));
/* 103 */       BaseColor color = spotColorant.getAlternativeCS();
/* 104 */       if ((color instanceof ExtendedColor)) {
/* 105 */         int type = ((ExtendedColor)color).type;
/* 106 */         switch (type) {
/*     */         case 1: 
/* 108 */           CMYK[0][i] = 0.0F;
/* 109 */           CMYK[1][i] = 0.0F;
/* 110 */           CMYK[2][i] = 0.0F;
/* 111 */           CMYK[3][i] = (1.0F - ((GrayColor)color).getGray());
/* 112 */           break;
/*     */         case 2: 
/* 114 */           CMYK[0][i] = ((CMYKColor)color).getCyan();
/* 115 */           CMYK[1][i] = ((CMYKColor)color).getMagenta();
/* 116 */           CMYK[2][i] = ((CMYKColor)color).getYellow();
/* 117 */           CMYK[3][i] = ((CMYKColor)color).getBlack();
/* 118 */           break;
/*     */         case 7: 
/* 120 */           CMYKColor cmyk = ((LabColor)color).toCmyk();
/* 121 */           CMYK[0][i] = cmyk.getCyan();
/* 122 */           CMYK[1][i] = cmyk.getMagenta();
/* 123 */           CMYK[2][i] = cmyk.getYellow();
/* 124 */           CMYK[3][i] = cmyk.getBlack();
/* 125 */           break;
/*     */         default: 
/* 127 */           throw new RuntimeException(MessageLocalization.getComposedMessage("only.rgb.gray.and.cmyk.are.supported.as.alternative.color.spaces", new Object[0]));
/*     */         }
/*     */       } else {
/* 130 */         float r = color.getRed();
/* 131 */         float g = color.getGreen();
/* 132 */         float b = color.getBlue();
/* 133 */         float computedC = 0.0F;float computedM = 0.0F;float computedY = 0.0F;float computedK = 0.0F;
/*     */         
/*     */ 
/* 136 */         if ((r == 0.0F) && (g == 0.0F) && (b == 0.0F)) {
/* 137 */           computedK = 1.0F;
/*     */         } else {
/* 139 */           computedC = 1.0F - r / 255.0F;
/* 140 */           computedM = 1.0F - g / 255.0F;
/* 141 */           computedY = 1.0F - b / 255.0F;
/*     */           
/* 143 */           float minCMY = Math.min(computedC, 
/* 144 */             Math.min(computedM, computedY));
/* 145 */           computedC = (computedC - minCMY) / (1.0F - minCMY);
/* 146 */           computedM = (computedM - minCMY) / (1.0F - minCMY);
/* 147 */           computedY = (computedY - minCMY) / (1.0F - minCMY);
/* 148 */           computedK = minCMY;
/*     */         }
/* 150 */         CMYK[0][i] = computedC;
/* 151 */         CMYK[1][i] = computedM;
/* 152 */         CMYK[2][i] = computedY;
/* 153 */         CMYK[3][i] = computedK;
/*     */       }
/* 155 */       psFunFooter = psFunFooter + "pop ";
/*     */     }
/* 157 */     array.add(colorants);
/*     */     
/* 159 */     String psFunHeader = String.format(Locale.US, "1.000000 %d 1 roll ", new Object[] { Integer.valueOf(numberOfColorants + 1) });
/* 160 */     array.add(PdfName.DEVICECMYK);
/* 161 */     psFunHeader = psFunHeader + psFunHeader + psFunHeader + psFunHeader;
/* 162 */     String psFun = "";
/* 163 */     for (i = numberOfColorants + 4; 
/* 164 */         i > numberOfColorants; i--) {
/* 165 */       psFun = psFun + String.format(Locale.US, "%d -1 roll ", new Object[] { Integer.valueOf(i) });
/* 166 */       for (int j = numberOfColorants; j > 0; j--) {
/* 167 */         psFun = psFun + String.format(Locale.US, "%d index %f mul 1.000000 cvr exch sub mul ", new Object[] { Integer.valueOf(j), Float.valueOf(CMYK[(numberOfColorants + 4 - i)][(numberOfColorants - j)]) });
/*     */       }
/* 169 */       psFun = psFun + String.format(Locale.US, "1.000000 cvr exch sub %d 1 roll ", new Object[] { Integer.valueOf(i) });
/*     */     }
/*     */     
/* 172 */     PdfFunction func = PdfFunction.type4(writer, colorantsRanges, new float[] { 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 1.0F }, "{ " + psFunHeader + psFun + psFunFooter + "}");
/* 173 */     array.add(func.getReference());
/*     */     
/* 175 */     PdfDictionary attr = new PdfDictionary();
/* 176 */     attr.put(PdfName.SUBTYPE, PdfName.NCHANNEL);
/* 177 */     attr.put(PdfName.COLORANTS, colorantsDict);
/* 178 */     array.add(attr);
/*     */     
/* 180 */     return array;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 185 */     if (this == o) return true;
/* 186 */     if (!(o instanceof PdfDeviceNColor)) { return false;
/*     */     }
/* 188 */     PdfDeviceNColor that = (PdfDeviceNColor)o;
/*     */     
/* 190 */     if (!Arrays.equals(this.spotColors, that.spotColors)) { return false;
/*     */     }
/* 192 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 197 */     return Arrays.hashCode(this.spotColors);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfDeviceNColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */