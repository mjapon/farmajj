/*     */ package com.itextpdf.text.pdf.languages;
/*     */ 
/*     */ import com.itextpdf.text.pdf.BidiLine;
/*     */ import com.itextpdf.text.pdf.BidiOrder;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArabicLigaturizer
/*     */   implements LanguageProcessor
/*     */ {
/*  61 */   private static final HashMap<Character, char[]> maptable = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private static final HashMap<Character, Character> reverseLigatureMapTable = new HashMap();
/*     */   private static final char ALEF = 'ا';
/*     */   
/*  69 */   static boolean isVowel(char s) { return ((s >= 'ً') && (s <= 'ٕ')) || (s == 'ٰ'); }
/*     */   
/*     */   private static final char ALEFHAMZA = 'أ';
/*     */   private static final char ALEFHAMZABELOW = 'إ';
/*     */   static char charshape(char s, int which)
/*     */   {
/*  75 */     if ((s >= 'ء') && (s <= 'ۓ')) {
/*  76 */       char[] c = (char[])maptable.get(Character.valueOf(s));
/*  77 */       if (c != null) {
/*  78 */         return c[(which + 1)];
/*     */       }
/*  80 */     } else if ((s >= 65269) && (s <= 65275)) {
/*  81 */       return (char)(s + which); }
/*  82 */     return s;
/*     */   }
/*     */   
/*     */   static int shapecount(char s) {
/*  86 */     if ((s >= 'ء') && (s <= 'ۓ') && (!isVowel(s))) {
/*  87 */       char[] c = (char[])maptable.get(Character.valueOf(s));
/*  88 */       if (c != null) {
/*  89 */         return c.length - 1;
/*     */       }
/*  91 */     } else if (s == '‍') {
/*  92 */       return 4;
/*     */     }
/*  94 */     return 1;
/*     */   }
/*     */   
/*     */   static int ligature(char newchar, charstruct oldchar)
/*     */   {
/*  99 */     int retval = 0;
/*     */     
/* 101 */     if (oldchar.basechar == 0)
/* 102 */       return 0;
/* 103 */     if (isVowel(newchar)) {
/* 104 */       retval = 1;
/* 105 */       if ((oldchar.vowel != 0) && (newchar != 'ّ')) {
/* 106 */         retval = 2;
/*     */       }
/* 108 */       switch (newchar) {
/*     */       case 'ّ': 
/* 110 */         if (oldchar.mark1 == 0) {
/* 111 */           oldchar.mark1 = 'ّ';
/*     */         }
/*     */         else {
/* 114 */           return 0;
/*     */         }
/*     */         break;
/*     */       case 'ٕ': 
/* 118 */         switch (oldchar.basechar) {
/*     */         case 'ا': 
/* 120 */           oldchar.basechar = 'إ';
/* 121 */           retval = 2;
/* 122 */           break;
/*     */         case 'ﻻ': 
/* 124 */           oldchar.basechar = 65273;
/* 125 */           retval = 2;
/* 126 */           break;
/*     */         default: 
/* 128 */           oldchar.mark1 = 'ٕ'; }
/* 129 */         break;
/*     */       
/*     */ 
/*     */       case 'ٔ': 
/* 133 */         switch (oldchar.basechar) {
/*     */         case 'ا': 
/* 135 */           oldchar.basechar = 'أ';
/* 136 */           retval = 2;
/* 137 */           break;
/*     */         case 'ﻻ': 
/* 139 */           oldchar.basechar = 65271;
/* 140 */           retval = 2;
/* 141 */           break;
/*     */         case 'و': 
/* 143 */           oldchar.basechar = 'ؤ';
/* 144 */           retval = 2;
/* 145 */           break;
/*     */         case 'ى': 
/*     */         case 'ي': 
/*     */         case 'ی': 
/* 149 */           oldchar.basechar = 'ئ';
/* 150 */           retval = 2;
/* 151 */           break;
/*     */         default: 
/* 153 */           oldchar.mark1 = 'ٔ'; }
/* 154 */         break;
/*     */       
/*     */ 
/*     */       case 'ٓ': 
/* 158 */         switch (oldchar.basechar) {
/*     */         case 'ا': 
/* 160 */           oldchar.basechar = 'آ';
/* 161 */           retval = 2;
/*     */         }
/*     */         
/* 164 */         break;
/*     */       case 'ْ': default: 
/* 166 */         oldchar.vowel = newchar;
/*     */       }
/*     */       
/* 169 */       if (retval == 1) {
/* 170 */         oldchar.lignum += 1;
/*     */       }
/* 172 */       return retval;
/*     */     }
/* 174 */     if (oldchar.vowel != 0) {
/* 175 */       return 0;
/*     */     }
/*     */     
/* 178 */     switch (oldchar.basechar) {
/*     */     case 'ل': 
/* 180 */       switch (newchar) {
/*     */       case 'ا': 
/* 182 */         oldchar.basechar = 65275;
/* 183 */         oldchar.numshapes = 2;
/* 184 */         retval = 3;
/* 185 */         break;
/*     */       case 'أ': 
/* 187 */         oldchar.basechar = 65271;
/* 188 */         oldchar.numshapes = 2;
/* 189 */         retval = 3;
/* 190 */         break;
/*     */       case 'إ': 
/* 192 */         oldchar.basechar = 65273;
/* 193 */         oldchar.numshapes = 2;
/* 194 */         retval = 3;
/* 195 */         break;
/*     */       case 'آ': 
/* 197 */         oldchar.basechar = 65269;
/* 198 */         oldchar.numshapes = 2;
/* 199 */         retval = 3;
/*     */       }
/*     */       
/* 202 */       break;
/*     */     case '\000': 
/* 204 */       oldchar.basechar = newchar;
/* 205 */       oldchar.numshapes = shapecount(newchar);
/* 206 */       retval = 1;
/*     */     }
/*     */     
/* 209 */     return retval;
/*     */   }
/*     */   
/*     */   static void copycstostring(StringBuffer string, charstruct s, int level)
/*     */   {
/* 214 */     if (s.basechar == 0) {
/* 215 */       return;
/*     */     }
/* 217 */     string.append(s.basechar);
/* 218 */     s.lignum -= 1;
/* 219 */     if (s.mark1 != 0) {
/* 220 */       if ((level & 0x1) == 0) {
/* 221 */         string.append(s.mark1);
/* 222 */         s.lignum -= 1;
/*     */       }
/*     */       else {
/* 225 */         s.lignum -= 1;
/*     */       }
/*     */     }
/* 228 */     if (s.vowel != 0) {
/* 229 */       if ((level & 0x1) == 0) {
/* 230 */         string.append(s.vowel);
/* 231 */         s.lignum -= 1;
/*     */       }
/*     */       else {
/* 234 */         s.lignum -= 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final char ALEFMADDA = 'آ';
/*     */   
/*     */   private static final char LAM = 'ل';
/*     */   
/*     */   private static final char HAMZA = 'ء';
/*     */   
/*     */   static void doublelig(StringBuffer string, int level)
/*     */   {
/*     */     int len;
/*     */     
/* 250 */     int olen = len = string.length();
/* 251 */     int j = 0;int si = 1;
/*     */     
/*     */ 
/* 254 */     while (si < olen) {
/* 255 */       char lapresult = '\000';
/* 256 */       if ((level & 0x4) != 0) {
/* 257 */         switch (string.charAt(j)) {
/*     */         case 'ّ': 
/* 259 */           switch (string.charAt(si)) {
/*     */           case 'ِ': 
/* 261 */             lapresult = 64610;
/* 262 */             break;
/*     */           case 'َ': 
/* 264 */             lapresult = 64608;
/* 265 */             break;
/*     */           case 'ُ': 
/* 267 */             lapresult = 64609;
/* 268 */             break;
/*     */           case 'ٌ': 
/* 270 */             lapresult = 64606;
/* 271 */             break;
/*     */           case 'ٍ': 
/* 273 */             lapresult = 64607;
/*     */           }
/*     */           
/* 276 */           break;
/*     */         case 'ِ': 
/* 278 */           if (string.charAt(si) == 'ّ')
/* 279 */             lapresult = 64610;
/*     */           break;
/*     */         case 'َ': 
/* 282 */           if (string.charAt(si) == 'ّ')
/* 283 */             lapresult = 64608;
/*     */           break;
/*     */         case 'ُ': 
/* 286 */           if (string.charAt(si) == 'ّ') {
/* 287 */             lapresult = 64609;
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/* 292 */       if ((level & 0x8) != 0) {
/* 293 */         switch (string.charAt(j)) {
/*     */         case 'ﻟ': 
/* 295 */           switch (string.charAt(si)) {
/*     */           case 'ﺞ': 
/* 297 */             lapresult = 64575;
/* 298 */             break;
/*     */           case 'ﺠ': 
/* 300 */             lapresult = 64713;
/* 301 */             break;
/*     */           case 'ﺢ': 
/* 303 */             lapresult = 64576;
/* 304 */             break;
/*     */           case 'ﺤ': 
/* 306 */             lapresult = 64714;
/* 307 */             break;
/*     */           case 'ﺦ': 
/* 309 */             lapresult = 64577;
/* 310 */             break;
/*     */           case 'ﺨ': 
/* 312 */             lapresult = 64715;
/* 313 */             break;
/*     */           case 'ﻢ': 
/* 315 */             lapresult = 64578;
/* 316 */             break;
/*     */           case 'ﻤ': 
/* 318 */             lapresult = 64716;
/*     */           }
/*     */           
/* 321 */           break;
/*     */         case 'ﺗ': 
/* 323 */           switch (string.charAt(si)) {
/*     */           case 'ﺠ': 
/* 325 */             lapresult = 64673;
/* 326 */             break;
/*     */           case 'ﺤ': 
/* 328 */             lapresult = 64674;
/* 329 */             break;
/*     */           case 'ﺨ': 
/* 331 */             lapresult = 64675;
/*     */           }
/*     */           
/* 334 */           break;
/*     */         case 'ﺑ': 
/* 336 */           switch (string.charAt(si)) {
/*     */           case 'ﺠ': 
/* 338 */             lapresult = 64668;
/* 339 */             break;
/*     */           case 'ﺤ': 
/* 341 */             lapresult = 64669;
/* 342 */             break;
/*     */           case 'ﺨ': 
/* 344 */             lapresult = 64670;
/*     */           }
/*     */           
/* 347 */           break;
/*     */         case 'ﻧ': 
/* 349 */           switch (string.charAt(si)) {
/*     */           case 'ﺠ': 
/* 351 */             lapresult = 64722;
/* 352 */             break;
/*     */           case 'ﺤ': 
/* 354 */             lapresult = 64723;
/* 355 */             break;
/*     */           case 'ﺨ': 
/* 357 */             lapresult = 64724;
/*     */           }
/*     */           
/* 360 */           break;
/*     */         
/*     */         case 'ﻨ': 
/* 363 */           switch (string.charAt(si)) {
/*     */           case 'ﺮ': 
/* 365 */             lapresult = 64650;
/* 366 */             break;
/*     */           case 'ﺰ': 
/* 368 */             lapresult = 64651;
/*     */           }
/*     */           
/* 371 */           break;
/*     */         case 'ﻣ': 
/* 373 */           switch (string.charAt(si)) {
/*     */           case 'ﺠ': 
/* 375 */             lapresult = 64718;
/* 376 */             break;
/*     */           case 'ﺤ': 
/* 378 */             lapresult = 64719;
/* 379 */             break;
/*     */           case 'ﺨ': 
/* 381 */             lapresult = 64720;
/* 382 */             break;
/*     */           case 'ﻤ': 
/* 384 */             lapresult = 64721;
/*     */           }
/*     */           
/* 387 */           break;
/*     */         
/*     */         case 'ﻓ': 
/* 390 */           switch (string.charAt(si)) {
/*     */           case 'ﻲ': 
/* 392 */             lapresult = 64562;
/*     */           }
/*     */           
/* 395 */           break;
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/* 401 */       if (lapresult != 0) {
/* 402 */         string.setCharAt(j, lapresult);
/* 403 */         len--;
/* 404 */         si++;
/*     */       }
/*     */       else
/*     */       {
/* 408 */         j++;
/* 409 */         string.setCharAt(j, string.charAt(si));
/* 410 */         si++;
/*     */       }
/*     */     }
/* 413 */     string.setLength(len);
/*     */   }
/*     */   
/*     */   static boolean connects_to_left(charstruct a) {
/* 417 */     return a.numshapes > 2;
/*     */   }
/*     */   
/*     */ 
/*     */   private static final char TATWEEL = 'ـ';
/*     */   
/*     */   private static final char ZWJ = '‍';
/*     */   
/*     */   private static final char HAMZAABOVE = 'ٔ';
/*     */   
/*     */   private static final char HAMZABELOW = 'ٕ';
/*     */   private static final char WAWHAMZA = 'ؤ';
/*     */   private static final char YEHHAMZA = 'ئ';
/*     */   static void shape(char[] text, StringBuffer string, int level)
/*     */   {
/* 432 */     int p = 0;
/* 433 */     charstruct oldchar = new charstruct();
/* 434 */     charstruct curchar = new charstruct();
/* 435 */     while (p < text.length) {
/* 436 */       char nextletter = text[(p++)];
/*     */       
/*     */ 
/* 439 */       int join = ligature(nextletter, curchar);
/* 440 */       if (join == 0) {
/* 441 */         int nc = shapecount(nextletter);
/*     */         int which;
/* 443 */         int which; if (nc == 1) {
/* 444 */           which = 0;
/*     */         }
/*     */         else {
/* 447 */           which = 2;
/*     */         }
/* 449 */         if (connects_to_left(oldchar)) {
/* 450 */           which++;
/*     */         }
/*     */         
/* 453 */         which %= curchar.numshapes;
/* 454 */         curchar.basechar = charshape(curchar.basechar, which);
/*     */         
/*     */ 
/* 457 */         copycstostring(string, oldchar, level);
/* 458 */         oldchar = curchar;
/*     */         
/*     */ 
/* 461 */         curchar = new charstruct();
/* 462 */         curchar.basechar = nextletter;
/* 463 */         curchar.numshapes = nc;
/* 464 */         curchar.lignum += 1;
/*     */ 
/*     */       }
/* 467 */       else if (join != 1) {}
/*     */     }
/*     */     
/*     */ 
/*     */     int which;
/*     */     
/*     */ 
/*     */     int which;
/*     */     
/*     */ 
/* 477 */     if (connects_to_left(oldchar)) {
/* 478 */       which = 1;
/*     */     } else
/* 480 */       which = 0;
/* 481 */     which %= curchar.numshapes;
/* 482 */     curchar.basechar = charshape(curchar.basechar, which);
/*     */     
/*     */ 
/* 485 */     copycstostring(string, oldchar, level);
/* 486 */     copycstostring(string, curchar, level);
/*     */   }
/*     */   
/*     */   public static int arabic_shape(char[] src, int srcoffset, int srclength, char[] dest, int destoffset, int destlength, int level) {
/* 490 */     char[] str = new char[srclength];
/* 491 */     for (int k = srclength + srcoffset - 1; k >= srcoffset; k--)
/* 492 */       str[(k - srcoffset)] = src[k];
/* 493 */     StringBuffer string = new StringBuffer(srclength);
/* 494 */     shape(str, string, level);
/* 495 */     if ((level & 0xC) != 0) {
/* 496 */       doublelig(string, level);
/*     */     }
/* 498 */     System.arraycopy(string.toString().toCharArray(), 0, dest, destoffset, string.length());
/* 499 */     return string.length();
/*     */   }
/*     */   
/*     */   public static void processNumbers(char[] text, int offset, int length, int options) {
/* 503 */     int limit = offset + length;
/* 504 */     if ((options & 0xE0) != 0) {
/* 505 */       char digitBase = '0';
/* 506 */       switch (options & 0x100) {
/*     */       case 0: 
/* 508 */         digitBase = '٠';
/* 509 */         break;
/*     */       
/*     */       case 256: 
/* 512 */         digitBase = '۰';
/* 513 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */ 
/* 519 */       switch (options & 0xE0) {
/*     */       case 32: 
/* 521 */         int digitDelta = digitBase - '0';
/* 522 */         for (int i = offset; i < limit; i++) {
/* 523 */           char ch = text[i];
/* 524 */           if ((ch <= '9') && (ch >= '0')) {
/* 525 */             int tmp152_150 = i;text[tmp152_150] = ((char)(text[tmp152_150] + digitDelta));
/*     */           }
/*     */         }
/*     */         
/* 529 */         break;
/*     */       
/*     */       case 64: 
/* 532 */         char digitTop = (char)(digitBase + '\t');
/* 533 */         int digitDelta = '0' - digitBase;
/* 534 */         for (int i = offset; i < limit; i++) {
/* 535 */           char ch = text[i];
/* 536 */           if ((ch <= digitTop) && (ch >= digitBase)) {
/* 537 */             int tmp216_214 = i;text[tmp216_214] = ((char)(text[tmp216_214] + digitDelta));
/*     */           }
/*     */         }
/*     */         
/* 541 */         break;
/*     */       
/*     */       case 96: 
/* 544 */         shapeToArabicDigitsWithContext(text, 0, length, digitBase, false);
/* 545 */         break;
/*     */       
/*     */       case 128: 
/* 548 */         shapeToArabicDigitsWithContext(text, 0, length, digitBase, true);
/* 549 */         break;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static void shapeToArabicDigitsWithContext(char[] dest, int start, int length, char digitBase, boolean lastStrongWasAL)
/*     */   {
/* 558 */     digitBase = (char)(digitBase - '0');
/*     */     
/* 560 */     int limit = start + length;
/* 561 */     for (int i = start; i < limit; i++) {
/* 562 */       char ch = dest[i];
/* 563 */       switch (BidiOrder.getDirection(ch)) {
/*     */       case 0: 
/*     */       case 3: 
/* 566 */         lastStrongWasAL = false;
/* 567 */         break;
/*     */       case 4: 
/* 569 */         lastStrongWasAL = true;
/* 570 */         break;
/*     */       case 8: 
/* 572 */         if ((lastStrongWasAL) && (ch <= '9')) {
/* 573 */           dest[i] = ((char)(ch + digitBase));
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */   public static Character getReverseMapping(char c)
/*     */   {
/* 583 */     return (Character)reverseLigatureMapTable.get(Character.valueOf(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final char WAW = 'و';
/*     */   
/*     */ 
/*     */   private static final char ALEFMAKSURA = 'ى';
/*     */   
/*     */ 
/*     */   private static final char YEH = 'ي';
/*     */   
/*     */   private static final char FARSIYEH = 'ی';
/*     */   
/*     */   private static final char SHADDA = 'ّ';
/*     */   
/*     */   private static final char KASRA = 'ِ';
/*     */   
/*     */   private static final char FATHA = 'َ';
/*     */   
/*     */   private static final char DAMMA = 'ُ';
/*     */   
/*     */   private static final char MADDA = 'ٓ';
/*     */   
/*     */   private static final char LAM_ALEF = 'ﻻ';
/*     */   
/*     */   private static final char LAM_ALEFHAMZA = 'ﻷ';
/*     */   
/*     */   private static final char LAM_ALEFHAMZABELOW = 'ﻹ';
/*     */   
/*     */   private static final char LAM_ALEFMADDA = 'ﻵ';
/*     */   
/* 616 */   private static final char[][] chartable = { { 'ء', 65152 }, { 'آ', 65153, 65154 }, { 'أ', 65155, 65156 }, { 'ؤ', 65157, 65158 }, { 'إ', 65159, 65160 }, { 'ئ', 65161, 65162, 65163, 65164 }, { 'ا', 65165, 65166 }, { 'ب', 65167, 65168, 65169, 65170 }, { 'ة', 65171, 65172 }, { 'ت', 65173, 65174, 65175, 65176 }, { 'ث', 65177, 65178, 65179, 65180 }, { 'ج', 65181, 65182, 65183, 65184 }, { 'ح', 65185, 65186, 65187, 65188 }, { 'خ', 65189, 65190, 65191, 65192 }, { 'د', 65193, 65194 }, { 'ذ', 65195, 65196 }, { 'ر', 65197, 65198 }, { 'ز', 65199, 65200 }, { 'س', 65201, 65202, 65203, 65204 }, { 'ش', 65205, 65206, 65207, 65208 }, { 'ص', 65209, 65210, 65211, 65212 }, { 'ض', 65213, 65214, 65215, 65216 }, { 'ط', 65217, 65218, 65219, 65220 }, { 'ظ', 65221, 65222, 65223, 65224 }, { 'ع', 65225, 65226, 65227, 65228 }, { 'غ', 65229, 65230, 65231, 65232 }, { 'ـ', 'ـ', 'ـ', 'ـ', 'ـ' }, { 'ف', 65233, 65234, 65235, 65236 }, { 'ق', 65237, 65238, 65239, 65240 }, { 'ك', 65241, 65242, 65243, 65244 }, { 'ل', 65245, 65246, 65247, 65248 }, { 'م', 65249, 65250, 65251, 65252 }, { 'ن', 65253, 65254, 65255, 65256 }, { 'ه', 65257, 65258, 65259, 65260 }, { 'و', 65261, 65262 }, { 'ى', 65263, 65264, 64488, 64489 }, { 'ي', 65265, 65266, 65267, 65268 }, { 'ٱ', 64336, 64337 }, { 'ٹ', 64358, 64359, 64360, 64361 }, { 'ٺ', 64350, 64351, 64352, 64353 }, { 'ٻ', 64338, 64339, 64340, 64341 }, { 'پ', 64342, 64343, 64344, 64345 }, { 'ٿ', 64354, 64355, 64356, 64357 }, { 'ڀ', 64346, 64347, 64348, 64349 }, { 'ڃ', 64374, 64375, 64376, 64377 }, { 'ڄ', 64370, 64371, 64372, 64373 }, { 'چ', 64378, 64379, 64380, 64381 }, { 'ڇ', 64382, 64383, 64384, 64385 }, { 'ڈ', 64392, 64393 }, { 'ڌ', 64388, 64389 }, { 'ڍ', 64386, 64387 }, { 'ڎ', 64390, 64391 }, { 'ڑ', 64396, 64397 }, { 'ژ', 64394, 64395 }, { 'ڤ', 64362, 64363, 64364, 64365 }, { 'ڦ', 64366, 64367, 64368, 64369 }, { 'ک', 64398, 64399, 64400, 64401 }, { 'ڭ', 64467, 64468, 64469, 64470 }, { 'گ', 64402, 64403, 64404, 64405 }, { 'ڱ', 64410, 64411, 64412, 64413 }, { 'ڳ', 64406, 64407, 64408, 64409 }, { 'ں', 64414, 64415 }, { 'ڻ', 64416, 64417, 64418, 64419 }, { 'ھ', 64426, 64427, 64428, 64429 }, { 'ۀ', 64420, 64421 }, { 'ہ', 64422, 64423, 64424, 64425 }, { 'ۅ', 64480, 64481 }, { 'ۆ', 64473, 64474 }, { 'ۇ', 64471, 64472 }, { 'ۈ', 64475, 64476 }, { 'ۉ', 64482, 64483 }, { 'ۋ', 64478, 64479 }, { 'ی', 64508, 64509, 64510, 64511 }, { 'ې', 64484, 64485, 64486, 64487 }, { 'ے', 64430, 64431 }, { 'ۓ', 64432, 64433 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ar_nothing = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ar_novowel = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ar_composedtashkeel = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ar_lig = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGITS_EN2AN = 32;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGITS_AN2EN = 64;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGITS_EN2AN_INIT_LR = 96;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGITS_EN2AN_INIT_AL = 128;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int DIGITS_RESERVED = 160;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGITS_MASK = 224;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGIT_TYPE_AN = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGIT_TYPE_AN_EXTENDED = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIGIT_TYPE_MASK = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArabicLigaturizer() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class charstruct
/*     */   {
/*     */     char basechar;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     char mark1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     char vowel;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int lignum;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 759 */     int numshapes = 1;
/*     */   }
/*     */   
/*     */ 
/* 763 */   protected int options = 0;
/* 764 */   protected int runDirection = 3;
/*     */   
/*     */ 
/*     */ 
/*     */   public ArabicLigaturizer(int runDirection, int options)
/*     */   {
/* 770 */     this.runDirection = runDirection;
/* 771 */     this.options = options;
/*     */   }
/*     */   
/*     */   public String process(String s) {
/* 775 */     return BidiLine.processLTR(s, this.runDirection, this.options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRTL()
/*     */   {
/* 784 */     return true;
/*     */   }
/*     */   
/*     */   static {
/* 788 */     for (char[] c : chartable) {
/* 789 */       maptable.put(Character.valueOf(c[0]), c);
/* 790 */       switch (c.length)
/*     */       {
/*     */       case 5: 
/* 793 */         reverseLigatureMapTable.put(Character.valueOf(c[4]), Character.valueOf(c[3]));
/*     */       case 3: 
/* 795 */         reverseLigatureMapTable.put(Character.valueOf(c[2]), Character.valueOf(c[1]));
/*     */       }
/*     */       
/* 798 */       if ((c[0] == 'ط') || (c[0] == 'ظ')) {
/* 799 */         reverseLigatureMapTable.put(Character.valueOf(c[4]), Character.valueOf(c[1]));
/* 800 */         reverseLigatureMapTable.put(Character.valueOf(c[3]), Character.valueOf(c[1]));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/languages/ArabicLigaturizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */