package com.itextpdf.text.pdf.interfaces;

public abstract interface PdfXConformance
  extends PdfIsoConformance
{
  public abstract void setPDFXConformance(int paramInt);
  
  public abstract int getPDFXConformance();
  
  public abstract boolean isPdfX();
}


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/interfaces/PdfXConformance.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */