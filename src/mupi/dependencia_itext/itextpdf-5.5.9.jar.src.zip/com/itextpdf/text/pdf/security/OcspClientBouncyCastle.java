/*     */ package com.itextpdf.text.pdf.security;
/*     */ 
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.io.StreamUtil;
/*     */ import com.itextpdf.text.log.Level;
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import com.itextpdf.text.pdf.PdfEncryption;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.Security;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.bouncycastle.asn1.DEROctetString;
/*     */ import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
/*     */ import org.bouncycastle.asn1.x509.Extension;
/*     */ import org.bouncycastle.asn1.x509.Extensions;
/*     */ import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
/*     */ import org.bouncycastle.cert.ocsp.BasicOCSPResp;
/*     */ import org.bouncycastle.cert.ocsp.CertificateID;
/*     */ import org.bouncycastle.cert.ocsp.CertificateStatus;
/*     */ import org.bouncycastle.cert.ocsp.OCSPException;
/*     */ import org.bouncycastle.cert.ocsp.OCSPReq;
/*     */ import org.bouncycastle.cert.ocsp.OCSPReqBuilder;
/*     */ import org.bouncycastle.cert.ocsp.OCSPResp;
/*     */ import org.bouncycastle.cert.ocsp.SingleResp;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ import org.bouncycastle.ocsp.RevokedStatus;
/*     */ import org.bouncycastle.operator.DigestCalculatorProvider;
/*     */ import org.bouncycastle.operator.OperatorException;
/*     */ import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OcspClientBouncyCastle
/*     */   implements OcspClient
/*     */ {
/*  94 */   private static final Logger LOGGER = LoggerFactory.getLogger(OcspClientBouncyCastle.class);
/*     */   
/*     */ 
/*     */   private final OCSPVerifier verifier;
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public OcspClientBouncyCastle()
/*     */   {
/* 104 */     this.verifier = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OcspClientBouncyCastle(OCSPVerifier verifier)
/*     */   {
/* 112 */     this.verifier = verifier;
/*     */   }
/*     */   
/*     */ 
/*     */   public BasicOCSPResp getBasicOCSPResp(X509Certificate checkCert, X509Certificate rootCert, String url)
/*     */   {
/*     */     try
/*     */     {
/* 120 */       OCSPResp ocspResponse = getOcspResponse(checkCert, rootCert, url);
/* 121 */       if (ocspResponse == null) {
/* 122 */         return null;
/*     */       }
/* 124 */       if (ocspResponse.getStatus() != 0) {
/* 125 */         return null;
/*     */       }
/* 127 */       BasicOCSPResp basicResponse = (BasicOCSPResp)ocspResponse.getResponseObject();
/* 128 */       if (this.verifier != null) {
/* 129 */         this.verifier.isValidResponse(basicResponse, rootCert);
/*     */       }
/* 131 */       return basicResponse;
/*     */     } catch (Exception ex) {
/* 133 */       if (LOGGER.isLogging(Level.ERROR))
/* 134 */         LOGGER.error(ex.getMessage());
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getEncoded(X509Certificate checkCert, X509Certificate rootCert, String url)
/*     */   {
/*     */     try
/*     */     {
/* 150 */       BasicOCSPResp basicResponse = getBasicOCSPResp(checkCert, rootCert, url);
/* 151 */       if (basicResponse != null) {
/* 152 */         SingleResp[] responses = basicResponse.getResponses();
/* 153 */         if (responses.length == 1) {
/* 154 */           SingleResp resp = responses[0];
/* 155 */           Object status = resp.getCertStatus();
/* 156 */           if (status == CertificateStatus.GOOD)
/* 157 */             return basicResponse.getEncoded();
/* 158 */           if ((status instanceof RevokedStatus)) {
/* 159 */             throw new IOException(MessageLocalization.getComposedMessage("ocsp.status.is.revoked", new Object[0]));
/*     */           }
/* 161 */           throw new IOException(MessageLocalization.getComposedMessage("ocsp.status.is.unknown", new Object[0]));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 166 */       if (LOGGER.isLogging(Level.ERROR))
/* 167 */         LOGGER.error(ex.getMessage());
/*     */     }
/* 169 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OCSPReq generateOCSPRequest(X509Certificate issuerCert, BigInteger serialNumber)
/*     */     throws OCSPException, IOException, OperatorException, CertificateEncodingException
/*     */   {
/* 185 */     Security.addProvider(new BouncyCastleProvider());
/*     */     
/*     */ 
/*     */ 
/* 189 */     CertificateID id = new CertificateID(new JcaDigestCalculatorProviderBuilder().build().get(CertificateID.HASH_SHA1), new JcaX509CertificateHolder(issuerCert), serialNumber);
/*     */     
/*     */ 
/*     */ 
/* 193 */     OCSPReqBuilder gen = new OCSPReqBuilder();
/* 194 */     gen.addRequest(id);
/*     */     
/* 196 */     Extension ext = new Extension(OCSPObjectIdentifiers.id_pkix_ocsp_nonce, false, new DEROctetString(new DEROctetString(PdfEncryption.createDocumentId()).getEncoded()));
/* 197 */     gen.setRequestExtensions(new Extensions(new Extension[] { ext }));
/* 198 */     return gen.build();
/*     */   }
/*     */   
/*     */   private OCSPResp getOcspResponse(X509Certificate checkCert, X509Certificate rootCert, String url) throws GeneralSecurityException, OCSPException, IOException, OperatorException {
/* 202 */     if ((checkCert == null) || (rootCert == null))
/* 203 */       return null;
/* 204 */     if (url == null) {
/* 205 */       url = CertificateUtil.getOCSPURL(checkCert);
/*     */     }
/* 207 */     if (url == null)
/* 208 */       return null;
/* 209 */     LOGGER.info("Getting OCSP from " + url);
/* 210 */     OCSPReq request = generateOCSPRequest(rootCert, checkCert.getSerialNumber());
/* 211 */     byte[] array = request.getEncoded();
/* 212 */     URL urlt = new URL(url);
/* 213 */     HttpURLConnection con = (HttpURLConnection)urlt.openConnection();
/* 214 */     con.setRequestProperty("Content-Type", "application/ocsp-request");
/* 215 */     con.setRequestProperty("Accept", "application/ocsp-response");
/* 216 */     con.setDoOutput(true);
/* 217 */     OutputStream out = con.getOutputStream();
/* 218 */     DataOutputStream dataOut = new DataOutputStream(new BufferedOutputStream(out));
/* 219 */     dataOut.write(array);
/* 220 */     dataOut.flush();
/* 221 */     dataOut.close();
/* 222 */     if (con.getResponseCode() / 100 != 2) {
/* 223 */       throw new IOException(MessageLocalization.getComposedMessage("invalid.http.response.1", con.getResponseCode()));
/*     */     }
/*     */     
/* 226 */     InputStream in = (InputStream)con.getContent();
/* 227 */     return new OCSPResp(StreamUtil.inputStreamToArray(in));
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/OcspClientBouncyCastle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */