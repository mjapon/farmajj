/*      */ package com.itextpdf.text.pdf.parser.clipper;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DefaultClipper
/*      */   extends ClipperBase
/*      */ {
/*      */   protected final List<Path.OutRec> polyOuts;
/*      */   private Clipper.ClipType clipType;
/*      */   private ClipperBase.Scanbeam scanbeam;
/*      */   private Path.Maxima maxima;
/*      */   private Edge activeEdges;
/*      */   private Edge sortedEdges;
/*      */   private final List<IntersectNode> intersectList;
/*      */   private final Comparator<IntersectNode> intersectNodeComparer;
/*      */   private Clipper.PolyFillType clipFillType;
/*      */   private Clipper.PolyFillType subjFillType;
/*      */   private final List<Path.Join> joins;
/*      */   private final List<Path.Join> ghostJoins;
/*      */   private boolean usingPolyTree;
/*      */   public Clipper.ZFillCallback zFillFunction;
/*      */   private final boolean reverseSolution;
/*      */   private final boolean strictlySimple;
/*      */   
/*      */   private class IntersectNode
/*      */   {
/*      */     Edge edge1;
/*      */     Edge Edge2;
/*      */     private Point.LongPoint pt;
/*      */     
/*      */     private IntersectNode() {}
/*      */     
/*      */     public Point.LongPoint getPt()
/*      */     {
/*   95 */       return this.pt;
/*      */     }
/*      */     
/*      */     public void setPt(Point.LongPoint pt) {
/*   99 */       this.pt = pt;
/*      */     }
/*      */   }
/*      */   
/*      */   private static void getHorzDirection(Edge HorzEdge, Clipper.Direction[] Dir, long[] Left, long[] Right)
/*      */   {
/*  105 */     if (HorzEdge.getBot().getX() < HorzEdge.getTop().getX()) {
/*  106 */       Left[0] = HorzEdge.getBot().getX();
/*  107 */       Right[0] = HorzEdge.getTop().getX();
/*  108 */       Dir[0] = Clipper.Direction.LEFT_TO_RIGHT;
/*      */     }
/*      */     else {
/*  111 */       Left[0] = HorzEdge.getTop().getX();
/*  112 */       Right[0] = HorzEdge.getBot().getX();
/*  113 */       Dir[0] = Clipper.Direction.RIGHT_TO_LEFT;
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean getOverlap(long a1, long a2, long b1, long b2, long[] Left, long[] Right) {
/*  118 */     if (a1 < a2) {
/*  119 */       if (b1 < b2) {
/*  120 */         Left[0] = Math.max(a1, b1);
/*  121 */         Right[0] = Math.min(a2, b2);
/*      */       }
/*      */       else {
/*  124 */         Left[0] = Math.max(a1, b2);
/*  125 */         Right[0] = Math.min(a2, b1);
/*      */       }
/*      */       
/*      */     }
/*  129 */     else if (b1 < b2) {
/*  130 */       Left[0] = Math.max(a2, b1);
/*  131 */       Right[0] = Math.min(a1, b2);
/*      */     }
/*      */     else {
/*  134 */       Left[0] = Math.max(a2, b2);
/*  135 */       Right[0] = Math.min(a1, b1);
/*      */     }
/*      */     
/*  138 */     return Left[0] < Right[0];
/*      */   }
/*      */   
/*      */   private static boolean isParam1RightOfParam2(Path.OutRec outRec1, Path.OutRec outRec2) {
/*      */     do {
/*  143 */       outRec1 = outRec1.firstLeft;
/*  144 */       if (outRec1 == outRec2) {
/*  145 */         return true;
/*      */       }
/*      */       
/*  148 */     } while (outRec1 != null);
/*  149 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static int isPointInPolygon(Point.LongPoint pt, Path.OutPt op)
/*      */   {
/*  156 */     int result = 0;
/*  157 */     Path.OutPt startOp = op;
/*  158 */     long ptx = pt.getX();long pty = pt.getY();
/*  159 */     long poly0x = op.getPt().getX();long poly0y = op.getPt().getY();
/*      */     do {
/*  161 */       op = op.next;
/*  162 */       long poly1x = op.getPt().getX();long poly1y = op.getPt().getY();
/*      */       
/*  164 */       if (poly1y == pty) {
/*  165 */         if (poly1x != ptx) { if (poly0y == pty) if ((poly1x > ptx ? 1 : 0) != (poly0x < ptx ? 1 : 0)) {}
/*  166 */         } else { return -1;
/*      */         }
/*      */       }
/*  169 */       if ((poly0y < pty ? 1 : 0) != (poly1y < pty ? 1 : 0)) {
/*  170 */         if (poly0x >= ptx) {
/*  171 */           if (poly1x > ptx) {
/*  172 */             result = 1 - result;
/*      */           }
/*      */           else {
/*  175 */             double d = (poly0x - ptx) * (poly1y - pty) - (poly1x - ptx) * (poly0y - pty);
/*  176 */             if (d == 0.0D) {
/*  177 */               return -1;
/*      */             }
/*  179 */             if ((d > 0.0D ? 1 : 0) == (poly1y > poly0y ? 1 : 0)) {
/*  180 */               result = 1 - result;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*  185 */         else if (poly1x > ptx) {
/*  186 */           double d = (poly0x - ptx) * (poly1y - pty) - (poly1x - ptx) * (poly0y - pty);
/*  187 */           if (d == 0.0D) {
/*  188 */             return -1;
/*      */           }
/*  190 */           if ((d > 0.0D ? 1 : 0) == (poly1y > poly0y ? 1 : 0)) {
/*  191 */             result = 1 - result;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  196 */       poly0x = poly1x;
/*  197 */       poly0y = poly1y;
/*      */     }
/*  199 */     while (startOp != op);
/*      */     
/*  201 */     return result;
/*      */   }
/*      */   
/*      */   private static boolean joinHorz(Path.OutPt op1, Path.OutPt op1b, Path.OutPt op2, Path.OutPt op2b, Point.LongPoint Pt, boolean DiscardLeft)
/*      */   {
/*  206 */     Clipper.Direction Dir1 = op1.getPt().getX() > op1b.getPt().getX() ? Clipper.Direction.RIGHT_TO_LEFT : Clipper.Direction.LEFT_TO_RIGHT;
/*  207 */     Clipper.Direction Dir2 = op2.getPt().getX() > op2b.getPt().getX() ? Clipper.Direction.RIGHT_TO_LEFT : Clipper.Direction.LEFT_TO_RIGHT;
/*  208 */     if (Dir1 == Dir2) {
/*  209 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */     if (Dir1 == Clipper.Direction.LEFT_TO_RIGHT) {
/*  218 */       while ((op1.next.getPt().getX() <= Pt.getX()) && (op1.next.getPt().getX() >= op1.getPt().getX()) && (op1.next.getPt().getY() == Pt.getY())) {
/*  219 */         op1 = op1.next;
/*      */       }
/*  221 */       if ((DiscardLeft) && (op1.getPt().getX() != Pt.getX())) {
/*  222 */         op1 = op1.next;
/*      */       }
/*  224 */       op1b = op1.duplicate(!DiscardLeft);
/*  225 */       if (!op1b.getPt().equals(Pt)) {
/*  226 */         op1 = op1b;
/*  227 */         op1.setPt(Pt);
/*  228 */         op1b = op1.duplicate(!DiscardLeft);
/*      */       }
/*      */     }
/*      */     else {
/*  232 */       while ((op1.next.getPt().getX() >= Pt.getX()) && (op1.next.getPt().getX() <= op1.getPt().getX()) && (op1.next.getPt().getY() == Pt.getY())) {
/*  233 */         op1 = op1.next;
/*      */       }
/*  235 */       if ((!DiscardLeft) && (op1.getPt().getX() != Pt.getX())) {
/*  236 */         op1 = op1.next;
/*      */       }
/*  238 */       op1b = op1.duplicate(DiscardLeft);
/*  239 */       if (!op1b.getPt().equals(Pt)) {
/*  240 */         op1 = op1b;
/*  241 */         op1.setPt(Pt);
/*  242 */         op1b = op1.duplicate(DiscardLeft);
/*      */       }
/*      */     }
/*      */     
/*  246 */     if (Dir2 == Clipper.Direction.LEFT_TO_RIGHT) {
/*  247 */       while ((op2.next.getPt().getX() <= Pt.getX()) && (op2.next.getPt().getX() >= op2.getPt().getX()) && (op2.next.getPt().getY() == Pt.getY())) {
/*  248 */         op2 = op2.next;
/*      */       }
/*  250 */       if ((DiscardLeft) && (op2.getPt().getX() != Pt.getX())) {
/*  251 */         op2 = op2.next;
/*      */       }
/*  253 */       op2b = op2.duplicate(!DiscardLeft);
/*  254 */       if (!op2b.getPt().equals(Pt)) {
/*  255 */         op2 = op2b;
/*  256 */         op2.setPt(Pt);
/*  257 */         op2b = op2.duplicate(!DiscardLeft);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  262 */       while ((op2.next.getPt().getX() >= Pt.getX()) && (op2.next.getPt().getX() <= op2.getPt().getX()) && (op2.next.getPt().getY() == Pt.getY())) {
/*  263 */         op2 = op2.next;
/*      */       }
/*  265 */       if ((!DiscardLeft) && (op2.getPt().getX() != Pt.getX())) {
/*  266 */         op2 = op2.next;
/*      */       }
/*  268 */       op2b = op2.duplicate(DiscardLeft);
/*  269 */       if (!op2b.getPt().equals(Pt)) {
/*  270 */         op2 = op2b;
/*  271 */         op2.setPt(Pt);
/*  272 */         op2b = op2.duplicate(DiscardLeft);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  278 */     if ((Dir1 == Clipper.Direction.LEFT_TO_RIGHT) == DiscardLeft) {
/*  279 */       op1.prev = op2;
/*  280 */       op2.next = op1;
/*  281 */       op1b.next = op2b;
/*  282 */       op2b.prev = op1b;
/*      */     }
/*      */     else {
/*  285 */       op1.next = op2;
/*  286 */       op2.prev = op1;
/*  287 */       op1b.prev = op2b;
/*  288 */       op2b.next = op1b;
/*      */     }
/*  290 */     return true;
/*      */   }
/*      */   
/*      */   private boolean joinPoints(Path.Join j, Path.OutRec outRec1, Path.OutRec outRec2) {
/*  294 */     Path.OutPt op1 = j.outPt1;
/*  295 */     Path.OutPt op2 = j.outPt2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  304 */     boolean isHorizontal = j.outPt1.getPt().getY() == j.getOffPt().getY();
/*      */     
/*  306 */     if ((isHorizontal) && (j.getOffPt().equals(j.outPt1.getPt())) && (j.getOffPt().equals(j.outPt2.getPt())))
/*      */     {
/*  308 */       if (outRec1 != outRec2) {
/*  309 */         return false;
/*      */       }
/*  311 */       Path.OutPt op1b = j.outPt1.next;
/*  312 */       while ((op1b != op1) && (op1b.getPt().equals(j.getOffPt()))) {
/*  313 */         op1b = op1b.next;
/*      */       }
/*  315 */       boolean reverse1 = op1b.getPt().getY() > j.getOffPt().getY();
/*  316 */       Path.OutPt op2b = j.outPt2.next;
/*  317 */       while ((op2b != op2) && (op2b.getPt().equals(j.getOffPt()))) {
/*  318 */         op2b = op2b.next;
/*      */       }
/*  320 */       boolean reverse2 = op2b.getPt().getY() > j.getOffPt().getY();
/*  321 */       if (reverse1 == reverse2) {
/*  322 */         return false;
/*      */       }
/*  324 */       if (reverse1) {
/*  325 */         op1b = op1.duplicate(false);
/*  326 */         op2b = op2.duplicate(true);
/*  327 */         op1.prev = op2;
/*  328 */         op2.next = op1;
/*  329 */         op1b.next = op2b;
/*  330 */         op2b.prev = op1b;
/*  331 */         j.outPt1 = op1;
/*  332 */         j.outPt2 = op1b;
/*  333 */         return true;
/*      */       }
/*      */       
/*  336 */       op1b = op1.duplicate(true);
/*  337 */       op2b = op2.duplicate(false);
/*  338 */       op1.next = op2;
/*  339 */       op2.prev = op1;
/*  340 */       op1b.prev = op2b;
/*  341 */       op2b.next = op1b;
/*  342 */       j.outPt1 = op1;
/*  343 */       j.outPt2 = op1b;
/*  344 */       return true;
/*      */     }
/*      */     
/*  347 */     if (isHorizontal)
/*      */     {
/*      */ 
/*      */ 
/*  351 */       Path.OutPt op1b = op1;
/*  352 */       while ((op1.prev.getPt().getY() == op1.getPt().getY()) && (op1.prev != op1b) && (op1.prev != op2)) {
/*  353 */         op1 = op1.prev;
/*      */       }
/*  355 */       while ((op1b.next.getPt().getY() == op1b.getPt().getY()) && (op1b.next != op1) && (op1b.next != op2)) {
/*  356 */         op1b = op1b.next;
/*      */       }
/*  358 */       if ((op1b.next == op1) || (op1b.next == op2)) {
/*  359 */         return false;
/*      */       }
/*      */       
/*  362 */       Path.OutPt op2b = op2;
/*  363 */       while ((op2.prev.getPt().getY() == op2.getPt().getY()) && (op2.prev != op2b) && (op2.prev != op1b)) {
/*  364 */         op2 = op2.prev;
/*      */       }
/*  366 */       while ((op2b.next.getPt().getY() == op2b.getPt().getY()) && (op2b.next != op2) && (op2b.next != op1)) {
/*  367 */         op2b = op2b.next;
/*      */       }
/*  369 */       if ((op2b.next == op2) || (op2b.next == op1)) {
/*  370 */         return false;
/*      */       }
/*      */       
/*  373 */       long[] LeftV = new long[1];long[] RightV = new long[1];
/*      */       
/*  375 */       if (!getOverlap(op1.getPt().getX(), op1b.getPt().getX(), op2.getPt().getX(), op2b.getPt().getX(), LeftV, RightV)) {
/*  376 */         return false;
/*      */       }
/*  378 */       long Left = LeftV[0];
/*  379 */       long Right = RightV[0];
/*      */       
/*      */       boolean DiscardLeftSide;
/*      */       
/*      */       Point.LongPoint Pt;
/*      */       
/*      */       boolean DiscardLeftSide;
/*  386 */       if ((op1.getPt().getX() >= Left) && (op1.getPt().getX() <= Right)) {
/*  387 */         Point.LongPoint Pt = new Point.LongPoint(op1.getPt());
/*  388 */         DiscardLeftSide = op1.getPt().getX() > op1b.getPt().getX();
/*      */       } else { boolean DiscardLeftSide;
/*  390 */         if ((op2.getPt().getX() >= Left) && (op2.getPt().getX() <= Right)) {
/*  391 */           Point.LongPoint Pt = new Point.LongPoint(op2.getPt());
/*  392 */           DiscardLeftSide = op2.getPt().getX() > op2b.getPt().getX();
/*      */         } else { boolean DiscardLeftSide;
/*  394 */           if ((op1b.getPt().getX() >= Left) && (op1b.getPt().getX() <= Right)) {
/*  395 */             Point.LongPoint Pt = new Point.LongPoint(op1b.getPt());
/*  396 */             DiscardLeftSide = op1b.getPt().getX() > op1.getPt().getX();
/*      */           }
/*      */           else {
/*  399 */             Pt = new Point.LongPoint(op2b.getPt());
/*  400 */             DiscardLeftSide = op2b.getPt().getX() > op2.getPt().getX();
/*      */           } } }
/*  402 */       j.outPt1 = op1;
/*  403 */       j.outPt2 = op2;
/*  404 */       return joinHorz(op1, op1b, op2, op2b, Pt, DiscardLeftSide);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  412 */     Path.OutPt op1b = op1.next;
/*  413 */     while ((op1b.getPt().equals(op1.getPt())) && (op1b != op1)) {
/*  414 */       op1b = op1b.next;
/*      */     }
/*  416 */     boolean Reverse1 = (op1b.getPt().getY() > op1.getPt().getY()) || (!Point.slopesEqual(op1.getPt(), op1b.getPt(), j.getOffPt(), this.useFullRange));
/*  417 */     if (Reverse1) {
/*  418 */       op1b = op1.prev;
/*  419 */       while ((op1b.getPt().equals(op1.getPt())) && (op1b != op1)) {
/*  420 */         op1b = op1b.prev;
/*      */       }
/*  422 */       if ((op1b.getPt().getY() > op1.getPt().getY()) || (!Point.slopesEqual(op1.getPt(), op1b.getPt(), j.getOffPt(), this.useFullRange))) {
/*  423 */         return false;
/*      */       }
/*      */     }
/*      */     
/*  427 */     Path.OutPt op2b = op2.next;
/*  428 */     while ((op2b.getPt().equals(op2.getPt())) && (op2b != op2)) {
/*  429 */       op2b = op2b.next;
/*      */     }
/*  431 */     boolean Reverse2 = (op2b.getPt().getY() > op2.getPt().getY()) || (!Point.slopesEqual(op2.getPt(), op2b.getPt(), j.getOffPt(), this.useFullRange));
/*  432 */     if (Reverse2) {
/*  433 */       op2b = op2.prev;
/*  434 */       while ((op2b.getPt().equals(op2.getPt())) && (op2b != op2)) {
/*  435 */         op2b = op2b.prev;
/*      */       }
/*  437 */       if ((op2b.getPt().getY() > op2.getPt().getY()) || (!Point.slopesEqual(op2.getPt(), op2b.getPt(), j.getOffPt(), this.useFullRange))) {
/*  438 */         return false;
/*      */       }
/*      */     }
/*      */     
/*  442 */     if ((op1b == op1) || (op2b == op2) || (op1b == op2b) || ((outRec1 == outRec2) && (Reverse1 == Reverse2))) {
/*  443 */       return false;
/*      */     }
/*      */     
/*  446 */     if (Reverse1) {
/*  447 */       op1b = op1.duplicate(false);
/*  448 */       op2b = op2.duplicate(true);
/*  449 */       op1.prev = op2;
/*  450 */       op2.next = op1;
/*  451 */       op1b.next = op2b;
/*  452 */       op2b.prev = op1b;
/*  453 */       j.outPt1 = op1;
/*  454 */       j.outPt2 = op1b;
/*  455 */       return true;
/*      */     }
/*      */     
/*  458 */     op1b = op1.duplicate(true);
/*  459 */     op2b = op2.duplicate(false);
/*  460 */     op1.next = op2;
/*  461 */     op2.prev = op1;
/*  462 */     op1b.prev = op2b;
/*  463 */     op2b.next = op1b;
/*  464 */     j.outPt1 = op1;
/*  465 */     j.outPt2 = op1b;
/*  466 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   private static Paths minkowski(Path pattern, Path path, boolean IsSum, boolean IsClosed)
/*      */   {
/*  472 */     int delta = IsClosed ? 1 : 0;
/*  473 */     int polyCnt = pattern.size();
/*  474 */     int pathCnt = path.size();
/*  475 */     Paths result = new Paths(pathCnt);
/*  476 */     if (IsSum) {
/*  477 */       for (int i = 0; i < pathCnt; i++) {
/*  478 */         Path p = new Path(polyCnt);
/*  479 */         for (Point.LongPoint ip : pattern) {
/*  480 */           p.add(new Point.LongPoint(((Point.LongPoint)path.get(i)).getX() + ip.getX(), ((Point.LongPoint)path.get(i)).getY() + ip.getY(), 0L));
/*      */         }
/*  482 */         result.add(p);
/*      */       }
/*      */       
/*      */     } else {
/*  486 */       for (int i = 0; i < pathCnt; i++) {
/*  487 */         Path p = new Path(polyCnt);
/*  488 */         for (Point.LongPoint ip : pattern) {
/*  489 */           p.add(new Point.LongPoint(((Point.LongPoint)path.get(i)).getX() - ip.getX(), ((Point.LongPoint)path.get(i)).getY() - ip.getY(), 0L));
/*      */         }
/*  491 */         result.add(p);
/*      */       }
/*      */     }
/*      */     
/*  495 */     Paths quads = new Paths((pathCnt + delta) * (polyCnt + 1));
/*  496 */     for (int i = 0; i < pathCnt - 1 + delta; i++) {
/*  497 */       for (int j = 0; j < polyCnt; j++) {
/*  498 */         Path quad = new Path(4);
/*  499 */         quad.add(((Path)result.get(i % pathCnt)).get(j % polyCnt));
/*  500 */         quad.add(((Path)result.get((i + 1) % pathCnt)).get(j % polyCnt));
/*  501 */         quad.add(((Path)result.get((i + 1) % pathCnt)).get((j + 1) % polyCnt));
/*  502 */         quad.add(((Path)result.get(i % pathCnt)).get((j + 1) % polyCnt));
/*  503 */         if (!quad.orientation()) {
/*  504 */           Collections.reverse(quad);
/*      */         }
/*  506 */         quads.add(quad);
/*      */       }
/*      */     }
/*  509 */     return quads;
/*      */   }
/*      */   
/*      */   public static Paths minkowskiDiff(Path poly1, Path poly2) {
/*  513 */     Paths paths = minkowski(poly1, poly2, false, true);
/*  514 */     DefaultClipper c = new DefaultClipper();
/*  515 */     c.addPaths(paths, Clipper.PolyType.SUBJECT, true);
/*  516 */     c.execute(Clipper.ClipType.UNION, paths, Clipper.PolyFillType.NON_ZERO, Clipper.PolyFillType.NON_ZERO);
/*  517 */     return paths;
/*      */   }
/*      */   
/*      */   public static Paths minkowskiSum(Path pattern, Path path, boolean pathIsClosed) {
/*  521 */     Paths paths = minkowski(pattern, path, true, pathIsClosed);
/*  522 */     DefaultClipper c = new DefaultClipper();
/*  523 */     c.addPaths(paths, Clipper.PolyType.SUBJECT, true);
/*  524 */     c.execute(Clipper.ClipType.UNION, paths, Clipper.PolyFillType.NON_ZERO, Clipper.PolyFillType.NON_ZERO);
/*  525 */     return paths;
/*      */   }
/*      */   
/*      */   public static Paths minkowskiSum(Path pattern, Paths paths, boolean pathIsClosed) {
/*  529 */     Paths solution = new Paths();
/*  530 */     DefaultClipper c = new DefaultClipper();
/*  531 */     for (int i = 0; i < paths.size(); i++) {
/*  532 */       Paths tmp = minkowski(pattern, (Path)paths.get(i), true, pathIsClosed);
/*  533 */       c.addPaths(tmp, Clipper.PolyType.SUBJECT, true);
/*  534 */       if (pathIsClosed) {
/*  535 */         Path path = ((Path)paths.get(i)).TranslatePath((Point.LongPoint)pattern.get(0));
/*  536 */         c.addPath(path, Clipper.PolyType.CLIP, true);
/*      */       }
/*      */     }
/*  539 */     c.execute(Clipper.ClipType.UNION, solution, Clipper.PolyFillType.NON_ZERO, Clipper.PolyFillType.NON_ZERO);
/*  540 */     return solution;
/*      */   }
/*      */   
/*      */   private static boolean poly2ContainsPoly1(Path.OutPt outPt1, Path.OutPt outPt2) {
/*  544 */     Path.OutPt op = outPt1;
/*      */     do
/*      */     {
/*  547 */       int res = isPointInPolygon(op.getPt(), outPt2);
/*  548 */       if (res >= 0) {
/*  549 */         return res > 0;
/*      */       }
/*  551 */       op = op.next;
/*      */     }
/*  553 */     while (op != outPt1);
/*  554 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Paths simplifyPolygon(Path poly)
/*      */   {
/*  562 */     return simplifyPolygon(poly, Clipper.PolyFillType.EVEN_ODD);
/*      */   }
/*      */   
/*      */   public static Paths simplifyPolygon(Path poly, Clipper.PolyFillType fillType) {
/*  566 */     Paths result = new Paths();
/*  567 */     DefaultClipper c = new DefaultClipper(2);
/*      */     
/*  569 */     c.addPath(poly, Clipper.PolyType.SUBJECT, true);
/*  570 */     c.execute(Clipper.ClipType.UNION, result, fillType, fillType);
/*  571 */     return result;
/*      */   }
/*      */   
/*      */   public static Paths simplifyPolygons(Paths polys) {
/*  575 */     return simplifyPolygons(polys, Clipper.PolyFillType.EVEN_ODD);
/*      */   }
/*      */   
/*      */   public static Paths simplifyPolygons(Paths polys, Clipper.PolyFillType fillType) {
/*  579 */     Paths result = new Paths();
/*  580 */     DefaultClipper c = new DefaultClipper(2);
/*      */     
/*  582 */     c.addPaths(polys, Clipper.PolyType.SUBJECT, true);
/*  583 */     c.execute(Clipper.ClipType.UNION, result, fillType, fillType);
/*  584 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */   private static final Logger LOGGER = Logger.getLogger(DefaultClipper.class.getName());
/*      */   
/*      */   public DefaultClipper() {
/*  632 */     this(0);
/*      */   }
/*      */   
/*      */   public DefaultClipper(int InitOptions)
/*      */   {
/*  637 */     super((0x4 & InitOptions) != 0);
/*  638 */     this.scanbeam = null;
/*  639 */     this.maxima = null;
/*  640 */     this.activeEdges = null;
/*  641 */     this.sortedEdges = null;
/*  642 */     this.intersectList = new ArrayList();
/*  643 */     this.intersectNodeComparer = new Comparator() {
/*      */       public int compare(DefaultClipper.IntersectNode o1, DefaultClipper.IntersectNode o2) {
/*  645 */         long i = o2.getPt().getY() - o1.getPt().getY();
/*  646 */         if (i > 0L) {
/*  647 */           return 1;
/*      */         }
/*  649 */         if (i < 0L) {
/*  650 */           return -1;
/*      */         }
/*      */         
/*  653 */         return 0;
/*      */       }
/*      */       
/*      */ 
/*  657 */     };
/*  658 */     this.usingPolyTree = false;
/*  659 */     this.polyOuts = new ArrayList();
/*  660 */     this.joins = new ArrayList();
/*  661 */     this.ghostJoins = new ArrayList();
/*  662 */     this.reverseSolution = ((0x1 & InitOptions) != 0);
/*  663 */     this.strictlySimple = ((0x2 & InitOptions) != 0);
/*      */     
/*  665 */     this.zFillFunction = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void insertScanbeam(long Y)
/*      */   {
/*  673 */     if (this.scanbeam == null)
/*      */     {
/*  675 */       this.scanbeam = new ClipperBase.Scanbeam(this);
/*  676 */       this.scanbeam.next = null;
/*  677 */       this.scanbeam.y = Y;
/*      */     }
/*  679 */     else if (Y > this.scanbeam.y)
/*      */     {
/*  681 */       ClipperBase.Scanbeam newSb = new ClipperBase.Scanbeam(this);
/*  682 */       newSb.y = Y;
/*  683 */       newSb.next = this.scanbeam;
/*  684 */       this.scanbeam = newSb;
/*      */     }
/*      */     else
/*      */     {
/*  688 */       ClipperBase.Scanbeam sb2 = this.scanbeam;
/*  689 */       while ((sb2.next != null) && (Y <= sb2.next.y)) sb2 = sb2.next;
/*  690 */       if (Y == sb2.y) return;
/*  691 */       ClipperBase.Scanbeam newSb = new ClipperBase.Scanbeam(this);
/*  692 */       newSb.y = Y;
/*  693 */       newSb.next = sb2.next;
/*  694 */       sb2.next = newSb;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void InsertMaxima(long X)
/*      */   {
/*  702 */     Path.Maxima newMax = new Path.Maxima();
/*  703 */     newMax.X = X;
/*  704 */     if (this.maxima == null)
/*      */     {
/*  706 */       this.maxima = newMax;
/*  707 */       this.maxima.Next = null;
/*  708 */       this.maxima.Prev = null;
/*      */     }
/*  710 */     else if (X < this.maxima.X)
/*      */     {
/*  712 */       newMax.Next = this.maxima;
/*  713 */       newMax.Prev = null;
/*  714 */       this.maxima = newMax;
/*      */     }
/*      */     else
/*      */     {
/*  718 */       Path.Maxima m = this.maxima;
/*  719 */       while ((m.Next != null) && (X >= m.Next.X)) m = m.Next;
/*  720 */       if (X == m.X) { return;
/*      */       }
/*  722 */       newMax.Next = m.Next;
/*  723 */       newMax.Prev = m;
/*  724 */       if (m.Next != null) m.Next.Prev = newMax;
/*  725 */       m.Next = newMax;
/*      */     }
/*      */   }
/*      */   
/*      */   private void addEdgeToSEL(Edge edge)
/*      */   {
/*  731 */     LOGGER.entering(DefaultClipper.class.getName(), "addEdgeToSEL");
/*      */     
/*      */ 
/*      */ 
/*  735 */     if (this.sortedEdges == null) {
/*  736 */       this.sortedEdges = edge;
/*  737 */       edge.prevInSEL = null;
/*  738 */       edge.nextInSEL = null;
/*      */     }
/*      */     else {
/*  741 */       edge.nextInSEL = this.sortedEdges;
/*  742 */       edge.prevInSEL = null;
/*  743 */       this.sortedEdges.prevInSEL = edge;
/*  744 */       this.sortedEdges = edge;
/*      */     }
/*      */   }
/*      */   
/*      */   private void addGhostJoin(Path.OutPt Op, Point.LongPoint OffPt) {
/*  749 */     Path.Join j = new Path.Join();
/*  750 */     j.outPt1 = Op;
/*  751 */     j.setOffPt(OffPt);
/*  752 */     this.ghostJoins.add(j);
/*      */   }
/*      */   
/*      */ 
/*      */   private void addJoin(Path.OutPt Op1, Path.OutPt Op2, Point.LongPoint OffPt)
/*      */   {
/*  758 */     LOGGER.entering(DefaultClipper.class.getName(), "addJoin");
/*  759 */     Path.Join j = new Path.Join();
/*  760 */     j.outPt1 = Op1;
/*  761 */     j.outPt2 = Op2;
/*  762 */     j.setOffPt(OffPt);
/*  763 */     this.joins.add(j);
/*      */   }
/*      */   
/*      */ 
/*      */   private void addLocalMaxPoly(Edge e1, Edge e2, Point.LongPoint pt)
/*      */   {
/*  769 */     addOutPt(e1, pt);
/*  770 */     if (e2.windDelta == 0) {
/*  771 */       addOutPt(e2, pt);
/*      */     }
/*  773 */     if (e1.outIdx == e2.outIdx) {
/*  774 */       e1.outIdx = -1;
/*  775 */       e2.outIdx = -1;
/*      */     }
/*  777 */     else if (e1.outIdx < e2.outIdx) {
/*  778 */       appendPolygon(e1, e2);
/*      */     }
/*      */     else {
/*  781 */       appendPolygon(e2, e1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private Path.OutPt addLocalMinPoly(Edge e1, Edge e2, Point.LongPoint pt)
/*      */   {
/*  788 */     LOGGER.entering(DefaultClipper.class.getName(), "addLocalMinPoly");
/*      */     Edge prevE;
/*      */     Path.OutPt result;
/*  791 */     Edge e; Edge prevE; if ((e2.isHorizontal()) || (e1.deltaX > e2.deltaX)) {
/*  792 */       Path.OutPt result = addOutPt(e1, pt);
/*  793 */       e2.outIdx = e1.outIdx;
/*  794 */       e1.side = Edge.Side.LEFT;
/*  795 */       e2.side = Edge.Side.RIGHT;
/*  796 */       Edge e = e1;
/*  797 */       Edge prevE; if (e.prevInAEL == e2) {
/*  798 */         prevE = e2.prevInAEL;
/*      */       }
/*      */       else {
/*  801 */         prevE = e.prevInAEL;
/*      */       }
/*      */     }
/*      */     else {
/*  805 */       result = addOutPt(e2, pt);
/*  806 */       e1.outIdx = e2.outIdx;
/*  807 */       e1.side = Edge.Side.RIGHT;
/*  808 */       e2.side = Edge.Side.LEFT;
/*  809 */       e = e2;
/*  810 */       Edge prevE; if (e.prevInAEL == e1) {
/*  811 */         prevE = e1.prevInAEL;
/*      */       }
/*      */       else {
/*  814 */         prevE = e.prevInAEL;
/*      */       }
/*      */     }
/*      */     
/*  818 */     if ((prevE != null) && (prevE.outIdx >= 0) && 
/*  819 */       (Edge.topX(prevE, pt.getY()) == Edge.topX(e, pt.getY())) && 
/*  820 */       (Edge.slopesEqual(e, prevE, this.useFullRange)) && (e.windDelta != 0) && (prevE.windDelta != 0))
/*      */     {
/*  822 */       Path.OutPt outPt = addOutPt(prevE, pt);
/*  823 */       addJoin(result, outPt, e.getTop());
/*      */     }
/*  825 */     return result;
/*      */   }
/*      */   
/*      */   private Path.OutPt addOutPt(Edge e, Point.LongPoint pt) {
/*  829 */     LOGGER.entering(DefaultClipper.class.getName(), "addOutPt");
/*  830 */     if (e.outIdx < 0)
/*      */     {
/*  832 */       Path.OutRec outRec = createOutRec();
/*  833 */       outRec.isOpen = (e.windDelta == 0);
/*  834 */       Path.OutPt newOp = new Path.OutPt();
/*  835 */       outRec.pts = newOp;
/*  836 */       newOp.idx = outRec.Idx;
/*  837 */       newOp.pt = pt;
/*  838 */       newOp.next = newOp;
/*  839 */       newOp.prev = newOp;
/*  840 */       if (!outRec.isOpen)
/*  841 */         setHoleState(e, outRec);
/*  842 */       e.outIdx = outRec.Idx;
/*  843 */       return newOp;
/*      */     }
/*      */     
/*  846 */     Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(e.outIdx);
/*      */     
/*  848 */     Path.OutPt op = outRec.getPoints();
/*  849 */     boolean ToFront = e.side == Edge.Side.LEFT;
/*  850 */     LOGGER.finest("op=" + op.getPointCount());
/*  851 */     LOGGER.finest(ToFront + " " + pt + " " + op.getPt());
/*  852 */     if ((ToFront) && (pt.equals(op.getPt()))) {
/*  853 */       return op;
/*      */     }
/*  855 */     if ((!ToFront) && (pt.equals(op.prev.getPt()))) {
/*  856 */       return op.prev;
/*      */     }
/*      */     
/*  859 */     Path.OutPt newOp = new Path.OutPt();
/*  860 */     newOp.idx = outRec.Idx;
/*  861 */     newOp.setPt(new Point.LongPoint(pt));
/*  862 */     newOp.next = op;
/*  863 */     newOp.prev = op.prev;
/*  864 */     newOp.prev.next = newOp;
/*  865 */     op.prev = newOp;
/*  866 */     if (ToFront) {
/*  867 */       outRec.setPoints(newOp);
/*      */     }
/*  869 */     return newOp;
/*      */   }
/*      */   
/*      */ 
/*      */   private Path.OutPt GetLastOutPt(Edge e)
/*      */   {
/*  875 */     Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(e.outIdx);
/*  876 */     if (e.side == Edge.Side.LEFT) {
/*  877 */       return outRec.pts;
/*      */     }
/*  879 */     return outRec.pts.prev;
/*      */   }
/*      */   
/*      */   private void appendPolygon(Edge e1, Edge e2)
/*      */   {
/*  884 */     LOGGER.entering(DefaultClipper.class.getName(), "appendPolygon");
/*      */     
/*      */ 
/*  887 */     Path.OutRec outRec1 = (Path.OutRec)this.polyOuts.get(e1.outIdx);
/*  888 */     Path.OutRec outRec2 = (Path.OutRec)this.polyOuts.get(e2.outIdx);
/*  889 */     LOGGER.finest("" + e1.outIdx);
/*  890 */     LOGGER.finest("" + e2.outIdx);
/*      */     Path.OutRec holeStateRec;
/*      */     Path.OutRec holeStateRec;
/*  893 */     if (isParam1RightOfParam2(outRec1, outRec2)) {
/*  894 */       holeStateRec = outRec2;
/*      */     } else { Path.OutRec holeStateRec;
/*  896 */       if (isParam1RightOfParam2(outRec2, outRec1)) {
/*  897 */         holeStateRec = outRec1;
/*      */       }
/*      */       else {
/*  900 */         holeStateRec = Path.OutPt.getLowerMostRec(outRec1, outRec2);
/*      */       }
/*      */     }
/*  903 */     Path.OutPt p1_lft = outRec1.getPoints();
/*  904 */     Path.OutPt p1_rt = p1_lft.prev;
/*  905 */     Path.OutPt p2_lft = outRec2.getPoints();
/*  906 */     Path.OutPt p2_rt = p2_lft.prev;
/*      */     
/*  908 */     LOGGER.finest("p1_lft.getPointCount() = " + p1_lft.getPointCount());
/*  909 */     LOGGER.finest("p1_rt.getPointCount() = " + p1_rt.getPointCount());
/*  910 */     LOGGER.finest("p2_lft.getPointCount() = " + p2_lft.getPointCount());
/*  911 */     LOGGER.finest("p2_rt.getPointCount() = " + p2_rt.getPointCount());
/*      */     
/*      */     Edge.Side side;
/*      */     Edge.Side side;
/*  915 */     if (e1.side == Edge.Side.LEFT) {
/*  916 */       if (e2.side == Edge.Side.LEFT)
/*      */       {
/*  918 */         p2_lft.reversePolyPtLinks();
/*  919 */         p2_lft.next = p1_lft;
/*  920 */         p1_lft.prev = p2_lft;
/*  921 */         p1_rt.next = p2_rt;
/*  922 */         p2_rt.prev = p1_rt;
/*  923 */         outRec1.setPoints(p2_rt);
/*      */       }
/*      */       else
/*      */       {
/*  927 */         p2_rt.next = p1_lft;
/*  928 */         p1_lft.prev = p2_rt;
/*  929 */         p2_lft.prev = p1_rt;
/*  930 */         p1_rt.next = p2_lft;
/*  931 */         outRec1.setPoints(p2_lft);
/*      */       }
/*  933 */       side = Edge.Side.LEFT;
/*      */     }
/*      */     else {
/*  936 */       if (e2.side == Edge.Side.RIGHT)
/*      */       {
/*  938 */         p2_lft.reversePolyPtLinks();
/*  939 */         p1_rt.next = p2_rt;
/*  940 */         p2_rt.prev = p1_rt;
/*  941 */         p2_lft.next = p1_lft;
/*  942 */         p1_lft.prev = p2_lft;
/*      */       }
/*      */       else
/*      */       {
/*  946 */         p1_rt.next = p2_lft;
/*  947 */         p2_lft.prev = p1_rt;
/*  948 */         p1_lft.prev = p2_rt;
/*  949 */         p2_rt.next = p1_lft;
/*      */       }
/*  951 */       side = Edge.Side.RIGHT;
/*      */     }
/*  953 */     outRec1.bottomPt = null;
/*  954 */     if (holeStateRec.equals(outRec2)) {
/*  955 */       if (outRec2.firstLeft != outRec1) {
/*  956 */         outRec1.firstLeft = outRec2.firstLeft;
/*      */       }
/*  958 */       outRec1.isHole = outRec2.isHole;
/*      */     }
/*  960 */     outRec2.setPoints(null);
/*  961 */     outRec2.bottomPt = null;
/*      */     
/*  963 */     outRec2.firstLeft = outRec1;
/*      */     
/*  965 */     int OKIdx = e1.outIdx;
/*  966 */     int ObsoleteIdx = e2.outIdx;
/*      */     
/*  968 */     e1.outIdx = -1;
/*  969 */     e2.outIdx = -1;
/*      */     
/*  971 */     Edge e = this.activeEdges;
/*  972 */     while (e != null) {
/*  973 */       if (e.outIdx == ObsoleteIdx) {
/*  974 */         e.outIdx = OKIdx;
/*  975 */         e.side = side;
/*  976 */         break;
/*      */       }
/*  978 */       e = e.nextInAEL;
/*      */     }
/*  980 */     outRec2.Idx = outRec1.Idx;
/*      */   }
/*      */   
/*      */ 
/*      */   private void buildIntersectList(long topY)
/*      */   {
/*  986 */     if (this.activeEdges == null) {
/*  987 */       return;
/*      */     }
/*      */     
/*      */ 
/*  991 */     Edge e = this.activeEdges;
/*  992 */     this.sortedEdges = e;
/*  993 */     while (e != null) {
/*  994 */       e.prevInSEL = e.prevInAEL;
/*  995 */       e.nextInSEL = e.nextInAEL;
/*  996 */       e.getCurrent().setX(Long.valueOf(Edge.topX(e, topY)));
/*  997 */       e = e.nextInAEL;
/*      */     }
/*      */     
/*      */ 
/* 1001 */     boolean isModified = true;
/* 1002 */     while ((isModified) && (this.sortedEdges != null)) {
/* 1003 */       isModified = false;
/* 1004 */       e = this.sortedEdges;
/* 1005 */       while (e.nextInSEL != null) {
/* 1006 */         Edge eNext = e.nextInSEL;
/* 1007 */         Point.LongPoint[] pt = new Point.LongPoint[1];
/* 1008 */         if (e.getCurrent().getX() > eNext.getCurrent().getX()) {
/* 1009 */           intersectPoint(e, eNext, pt);
/* 1010 */           IntersectNode newNode = new IntersectNode(null);
/* 1011 */           newNode.edge1 = e;
/* 1012 */           newNode.Edge2 = eNext;
/* 1013 */           newNode.setPt(pt[0]);
/* 1014 */           this.intersectList.add(newNode);
/*      */           
/* 1016 */           swapPositionsInSEL(e, eNext);
/* 1017 */           isModified = true;
/*      */         }
/*      */         else {
/* 1020 */           e = eNext;
/*      */         }
/*      */       }
/* 1023 */       if (e.prevInSEL == null) break;
/* 1024 */       e.prevInSEL.nextInSEL = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1030 */     this.sortedEdges = null;
/*      */   }
/*      */   
/*      */ 
/*      */   private void buildResult(Paths polyg)
/*      */   {
/* 1036 */     polyg.clear();
/* 1037 */     for (int i = 0; i < this.polyOuts.size(); i++) {
/* 1038 */       Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(i);
/* 1039 */       if (outRec.getPoints() != null)
/*      */       {
/*      */ 
/* 1042 */         Path.OutPt p = outRec.getPoints().prev;
/* 1043 */         int cnt = p.getPointCount();
/* 1044 */         LOGGER.finest("cnt = " + cnt);
/* 1045 */         if (cnt >= 2)
/*      */         {
/*      */ 
/* 1048 */           Path pg = new Path(cnt);
/* 1049 */           for (int j = 0; j < cnt; j++) {
/* 1050 */             pg.add(p.getPt());
/* 1051 */             p = p.prev;
/*      */           }
/* 1053 */           polyg.add(pg);
/*      */         }
/*      */       }
/*      */     } }
/*      */   
/* 1058 */   private void buildResult2(PolyTree polytree) { polytree.Clear();
/*      */     
/*      */ 
/* 1061 */     for (int i = 0; i < this.polyOuts.size(); i++) {
/* 1062 */       Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(i);
/* 1063 */       int cnt = outRec.getPoints() != null ? outRec.getPoints().getPointCount() : 0;
/* 1064 */       if (((!outRec.isOpen) || (cnt >= 2)) && ((outRec.isOpen) || (cnt >= 3)))
/*      */       {
/*      */ 
/* 1067 */         outRec.fixHoleLinkage();
/* 1068 */         PolyNode pn = new PolyNode();
/* 1069 */         polytree.getAllPolys().add(pn);
/* 1070 */         outRec.polyNode = pn;
/* 1071 */         Path.OutPt op = outRec.getPoints().prev;
/* 1072 */         for (int j = 0; j < cnt; j++) {
/* 1073 */           pn.getPolygon().add(op.getPt());
/* 1074 */           op = op.prev;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1079 */     for (int i = 0; i < this.polyOuts.size(); i++) {
/* 1080 */       Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(i);
/* 1081 */       if (outRec.polyNode != null)
/*      */       {
/*      */ 
/* 1084 */         if (outRec.isOpen) {
/* 1085 */           outRec.polyNode.setOpen(true);
/* 1086 */           polytree.addChild(outRec.polyNode);
/*      */         }
/* 1088 */         else if ((outRec.firstLeft != null) && (outRec.firstLeft.polyNode != null)) {
/* 1089 */           outRec.firstLeft.polyNode.addChild(outRec.polyNode);
/*      */         }
/*      */         else {
/* 1092 */           polytree.addChild(outRec.polyNode);
/*      */         } }
/*      */     }
/*      */   }
/*      */   
/*      */   private void copyAELToSEL() {
/* 1098 */     Edge e = this.activeEdges;
/* 1099 */     this.sortedEdges = e;
/* 1100 */     while (e != null) {
/* 1101 */       e.prevInSEL = e.prevInAEL;
/* 1102 */       e.nextInSEL = e.nextInAEL;
/* 1103 */       e = e.nextInAEL;
/*      */     }
/*      */   }
/*      */   
/*      */   private Path.OutRec createOutRec() {
/* 1108 */     Path.OutRec result = new Path.OutRec();
/* 1109 */     result.Idx = -1;
/* 1110 */     result.isHole = false;
/* 1111 */     result.isOpen = false;
/* 1112 */     result.firstLeft = null;
/* 1113 */     result.setPoints(null);
/* 1114 */     result.bottomPt = null;
/* 1115 */     result.polyNode = null;
/* 1116 */     this.polyOuts.add(result);
/* 1117 */     result.Idx = (this.polyOuts.size() - 1);
/* 1118 */     return result;
/*      */   }
/*      */   
/*      */   private void deleteFromAEL(Edge e) {
/* 1122 */     LOGGER.entering(DefaultClipper.class.getName(), "deleteFromAEL");
/*      */     
/* 1124 */     Edge AelPrev = e.prevInAEL;
/* 1125 */     Edge AelNext = e.nextInAEL;
/* 1126 */     if ((AelPrev == null) && (AelNext == null) && (e != this.activeEdges)) {
/* 1127 */       return;
/*      */     }
/* 1129 */     if (AelPrev != null) {
/* 1130 */       AelPrev.nextInAEL = AelNext;
/*      */     }
/*      */     else {
/* 1133 */       this.activeEdges = AelNext;
/*      */     }
/* 1135 */     if (AelNext != null) {
/* 1136 */       AelNext.prevInAEL = AelPrev;
/*      */     }
/* 1138 */     e.nextInAEL = null;
/* 1139 */     e.prevInAEL = null;
/* 1140 */     LOGGER.exiting(DefaultClipper.class.getName(), "deleteFromAEL");
/*      */   }
/*      */   
/*      */   private void deleteFromSEL(Edge e) {
/* 1144 */     LOGGER.entering(DefaultClipper.class.getName(), "deleteFromSEL");
/*      */     
/* 1146 */     Edge SelPrev = e.prevInSEL;
/* 1147 */     Edge SelNext = e.nextInSEL;
/* 1148 */     if ((SelPrev == null) && (SelNext == null) && (!e.equals(this.sortedEdges))) {
/* 1149 */       return;
/*      */     }
/* 1151 */     if (SelPrev != null) {
/* 1152 */       SelPrev.nextInSEL = SelNext;
/*      */     }
/*      */     else {
/* 1155 */       this.sortedEdges = SelNext;
/*      */     }
/* 1157 */     if (SelNext != null) {
/* 1158 */       SelNext.prevInSEL = SelPrev;
/*      */     }
/* 1160 */     e.nextInSEL = null;
/* 1161 */     e.prevInSEL = null;
/*      */   }
/*      */   
/*      */   private boolean doHorzSegmentsOverlap(long seg1a, long seg1b, long seg2a, long seg2b) {
/* 1165 */     if (seg1a > seg1b) {
/* 1166 */       long tmp = seg1a;
/* 1167 */       seg1a = seg1b;
/* 1168 */       seg1b = tmp;
/*      */     }
/* 1170 */     if (seg2a > seg2b) {
/* 1171 */       long tmp = seg2a;
/* 1172 */       seg2a = seg2b;
/* 1173 */       seg2b = tmp;
/*      */     }
/* 1175 */     return (seg1a < seg2b) && (seg2a < seg1b);
/*      */   }
/*      */   
/*      */   private void doMaxima(Edge e) {
/* 1179 */     Edge eMaxPair = e.getMaximaPair();
/* 1180 */     if (eMaxPair == null) {
/* 1181 */       if (e.outIdx >= 0) {
/* 1182 */         addOutPt(e, e.getTop());
/*      */       }
/* 1184 */       deleteFromAEL(e);
/* 1185 */       return;
/*      */     }
/*      */     
/* 1188 */     Edge eNext = e.nextInAEL;
/* 1189 */     while ((eNext != null) && (eNext != eMaxPair)) {
/* 1190 */       Point.LongPoint tmp = new Point.LongPoint(e.getTop());
/* 1191 */       intersectEdges(e, eNext, tmp);
/* 1192 */       e.setTop(tmp);
/* 1193 */       swapPositionsInAEL(e, eNext);
/* 1194 */       eNext = e.nextInAEL;
/*      */     }
/*      */     
/* 1197 */     if ((e.outIdx == -1) && (eMaxPair.outIdx == -1)) {
/* 1198 */       deleteFromAEL(e);
/* 1199 */       deleteFromAEL(eMaxPair);
/*      */     }
/* 1201 */     else if ((e.outIdx >= 0) && (eMaxPair.outIdx >= 0)) {
/* 1202 */       if (e.outIdx >= 0) {
/* 1203 */         addLocalMaxPoly(e, eMaxPair, e.getTop());
/*      */       }
/* 1205 */       deleteFromAEL(e);
/* 1206 */       deleteFromAEL(eMaxPair);
/*      */ 
/*      */     }
/* 1209 */     else if (e.windDelta == 0) {
/* 1210 */       if (e.outIdx >= 0) {
/* 1211 */         addOutPt(e, e.getTop());
/* 1212 */         e.outIdx = -1;
/*      */       }
/* 1214 */       deleteFromAEL(e);
/*      */       
/* 1216 */       if (eMaxPair.outIdx >= 0) {
/* 1217 */         addOutPt(eMaxPair, e.getTop());
/* 1218 */         eMaxPair.outIdx = -1;
/*      */       }
/* 1220 */       deleteFromAEL(eMaxPair);
/*      */     }
/*      */     else {
/* 1223 */       throw new IllegalStateException("DoMaxima error");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void doSimplePolygons()
/*      */   {
/* 1230 */     int i = 0;
/* 1231 */     while (i < this.polyOuts.size()) {
/* 1232 */       Path.OutRec outrec = (Path.OutRec)this.polyOuts.get(i++);
/* 1233 */       Path.OutPt op = outrec.getPoints();
/* 1234 */       if ((op != null) && (!outrec.isOpen))
/*      */       {
/*      */         do
/*      */         {
/*      */ 
/* 1239 */           Path.OutPt op2 = op.next;
/* 1240 */           while (op2 != outrec.getPoints()) {
/* 1241 */             if ((op.getPt().equals(op2.getPt())) && (!op2.next.equals(op)) && (!op2.prev.equals(op)))
/*      */             {
/* 1243 */               Path.OutPt op3 = op.prev;
/* 1244 */               Path.OutPt op4 = op2.prev;
/* 1245 */               op.prev = op4;
/* 1246 */               op4.next = op;
/* 1247 */               op2.prev = op3;
/* 1248 */               op3.next = op2;
/*      */               
/* 1250 */               outrec.setPoints(op);
/* 1251 */               Path.OutRec outrec2 = createOutRec();
/* 1252 */               outrec2.setPoints(op2);
/* 1253 */               updateOutPtIdxs(outrec2);
/* 1254 */               if (poly2ContainsPoly1(outrec2.getPoints(), outrec.getPoints()))
/*      */               {
/* 1256 */                 outrec2.isHole = (!outrec.isHole);
/* 1257 */                 outrec2.firstLeft = outrec;
/* 1258 */                 if (this.usingPolyTree) {
/* 1259 */                   fixupFirstLefts2(outrec2, outrec);
/*      */                 }
/*      */               }
/* 1262 */               else if (poly2ContainsPoly1(outrec.getPoints(), outrec2.getPoints()))
/*      */               {
/* 1264 */                 outrec2.isHole = outrec.isHole;
/* 1265 */                 outrec.isHole = (!outrec2.isHole);
/* 1266 */                 outrec2.firstLeft = outrec.firstLeft;
/* 1267 */                 outrec.firstLeft = outrec2;
/* 1268 */                 if (this.usingPolyTree) {
/* 1269 */                   fixupFirstLefts2(outrec, outrec2);
/*      */                 }
/*      */               }
/*      */               else
/*      */               {
/* 1274 */                 outrec2.isHole = outrec.isHole;
/* 1275 */                 outrec2.firstLeft = outrec.firstLeft;
/* 1276 */                 if (this.usingPolyTree) {
/* 1277 */                   fixupFirstLefts1(outrec, outrec2);
/*      */                 }
/*      */               }
/* 1280 */               op2 = op;
/*      */             }
/* 1282 */             op2 = op2.next;
/*      */           }
/* 1284 */           op = op.next;
/*      */         }
/* 1286 */         while (op != outrec.getPoints());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean EdgesAdjacent(IntersectNode inode)
/*      */   {
/* 1293 */     return (inode.edge1.nextInSEL == inode.Edge2) || (inode.edge1.prevInSEL == inode.Edge2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(Clipper.ClipType clipType, Paths solution, Clipper.PolyFillType FillType)
/*      */   {
/* 1302 */     return execute(clipType, solution, FillType, FillType);
/*      */   }
/*      */   
/*      */   public boolean execute(Clipper.ClipType clipType, PolyTree polytree)
/*      */   {
/* 1307 */     return execute(clipType, polytree, Clipper.PolyFillType.EVEN_ODD);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean execute(Clipper.ClipType clipType, PolyTree polytree, Clipper.PolyFillType FillType)
/*      */   {
/* 1313 */     return execute(clipType, polytree, FillType, FillType);
/*      */   }
/*      */   
/*      */   public boolean execute(Clipper.ClipType clipType, Paths solution)
/*      */   {
/* 1318 */     return execute(clipType, solution, Clipper.PolyFillType.EVEN_ODD);
/*      */   }
/*      */   
/*      */   public boolean execute(Clipper.ClipType clipType, Paths solution, Clipper.PolyFillType subjFillType, Clipper.PolyFillType clipFillType)
/*      */   {
/* 1323 */     synchronized (this)
/*      */     {
/* 1325 */       if (this.hasOpenPaths) {
/* 1326 */         throw new IllegalStateException("Error: PolyTree struct is needed for open path clipping.");
/*      */       }
/*      */       
/* 1329 */       solution.clear();
/* 1330 */       this.subjFillType = subjFillType;
/* 1331 */       this.clipFillType = clipFillType;
/* 1332 */       this.clipType = clipType;
/* 1333 */       this.usingPolyTree = false;
/*      */       try
/*      */       {
/* 1336 */         boolean succeeded = executeInternal();
/*      */         
/* 1338 */         if (succeeded) {
/* 1339 */           buildResult(solution);
/*      */         }
/* 1341 */         boolean bool1 = succeeded;
/*      */         
/*      */ 
/* 1344 */         this.polyOuts.clear();return bool1; } finally { this.polyOuts.clear();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean execute(Clipper.ClipType clipType, PolyTree polytree, Clipper.PolyFillType subjFillType, Clipper.PolyFillType clipFillType)
/*      */   {
/* 1352 */     synchronized (this) {
/* 1353 */       this.subjFillType = subjFillType;
/* 1354 */       this.clipFillType = clipFillType;
/* 1355 */       this.clipType = clipType;
/* 1356 */       this.usingPolyTree = true;
/*      */       try
/*      */       {
/* 1359 */         boolean succeeded = executeInternal();
/*      */         
/* 1361 */         if (succeeded) {
/* 1362 */           buildResult2(polytree);
/*      */         }
/*      */       }
/*      */       finally {
/* 1366 */         this.polyOuts.clear(); }
/*      */       boolean succeeded;
/* 1368 */       return succeeded;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean executeInternal()
/*      */   {
/*      */     try
/*      */     {
/* 1376 */       reset();
/* 1377 */       if (this.currentLM == null) {
/* 1378 */         return false;
/*      */       }
/* 1380 */       long botY = popScanbeam();
/*      */       do {
/* 1382 */         insertLocalMinimaIntoAEL(botY);
/* 1383 */         processHorizontals();
/* 1384 */         this.ghostJoins.clear();
/* 1385 */         if (this.scanbeam == null)
/*      */           break;
/* 1387 */         long topY = popScanbeam();
/* 1388 */         if (!processIntersections(topY))
/* 1389 */           return false;
/* 1390 */         processEdgesAtTopOfScanbeam(topY);
/* 1391 */         botY = topY;
/* 1392 */       } while ((this.scanbeam != null) || (this.currentLM != null));
/*      */       
/*      */ 
/* 1395 */       for (int i = 0; i < this.polyOuts.size(); i++) {
/* 1396 */         Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(i);
/* 1397 */         if ((outRec.pts != null) && (!outRec.isOpen))
/*      */         {
/* 1399 */           if ((outRec.isHole ^ this.reverseSolution) == outRec.area() > 0.0D)
/* 1400 */             outRec.getPoints().reversePolyPtLinks();
/*      */         }
/*      */       }
/* 1403 */       joinCommonEdges();
/*      */       
/* 1405 */       for (int i = 0; i < this.polyOuts.size(); i++) {
/* 1406 */         Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(i);
/* 1407 */         if (outRec.getPoints() != null)
/*      */         {
/* 1409 */           if (outRec.isOpen) {
/* 1410 */             fixupOutPolyline(outRec);
/*      */           } else
/* 1412 */             fixupOutPolygon(outRec);
/*      */         }
/*      */       }
/* 1415 */       if (this.strictlySimple)
/* 1416 */         doSimplePolygons();
/* 1417 */       return 1;
/*      */     }
/*      */     finally
/*      */     {
/* 1421 */       this.joins.clear();
/* 1422 */       this.ghostJoins.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void fixupFirstLefts1(Path.OutRec OldOutRec, Path.OutRec NewOutRec)
/*      */   {
/* 1429 */     for (int i = 0; i < this.polyOuts.size(); i++) {
/* 1430 */       Path.OutRec outRec = (Path.OutRec)this.polyOuts.get(i);
/* 1431 */       if ((outRec.getPoints() != null) && (outRec.firstLeft != null))
/*      */       {
/*      */ 
/* 1434 */         Path.OutRec firstLeft = parseFirstLeft(outRec.firstLeft);
/* 1435 */         if ((firstLeft.equals(OldOutRec)) && 
/* 1436 */           (poly2ContainsPoly1(outRec.getPoints(), NewOutRec.getPoints()))) {
/* 1437 */           outRec.firstLeft = NewOutRec;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void fixupFirstLefts2(Path.OutRec OldOutRec, Path.OutRec NewOutRec) {
/* 1444 */     for (Path.OutRec outRec : this.polyOuts) {
/* 1445 */       if (outRec.firstLeft == OldOutRec) {
/* 1446 */         outRec.firstLeft = NewOutRec;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean fixupIntersectionOrder()
/*      */   {
/* 1455 */     Collections.sort(this.intersectList, this.intersectNodeComparer);
/*      */     
/* 1457 */     copyAELToSEL();
/* 1458 */     int cnt = this.intersectList.size();
/* 1459 */     for (int i = 0; i < cnt; i++) {
/* 1460 */       if (!EdgesAdjacent((IntersectNode)this.intersectList.get(i))) {
/* 1461 */         int j = i + 1;
/* 1462 */         while ((j < cnt) && (!EdgesAdjacent((IntersectNode)this.intersectList.get(j)))) {
/* 1463 */           j++;
/*      */         }
/* 1465 */         if (j == cnt) {
/* 1466 */           return false;
/*      */         }
/*      */         
/* 1469 */         IntersectNode tmp = (IntersectNode)this.intersectList.get(i);
/* 1470 */         this.intersectList.set(i, this.intersectList.get(j));
/* 1471 */         this.intersectList.set(j, tmp);
/*      */       }
/*      */       
/* 1474 */       swapPositionsInSEL(((IntersectNode)this.intersectList.get(i)).edge1, ((IntersectNode)this.intersectList.get(i)).Edge2);
/*      */     }
/* 1476 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void fixupOutPolyline(Path.OutRec outrec)
/*      */   {
/* 1483 */     Path.OutPt pp = outrec.pts;
/* 1484 */     Path.OutPt lastPP = pp.prev;
/* 1485 */     while (pp != lastPP)
/*      */     {
/* 1487 */       pp = pp.next;
/* 1488 */       if (pp.pt.equals(pp.prev.pt))
/*      */       {
/* 1490 */         if (pp == lastPP) lastPP = pp.prev;
/* 1491 */         Path.OutPt tmpPP = pp.prev;
/* 1492 */         tmpPP.next = pp.next;
/* 1493 */         pp.next.prev = tmpPP;
/* 1494 */         pp = tmpPP;
/*      */       }
/*      */     }
/* 1497 */     if (pp == pp.prev) { outrec.pts = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private void fixupOutPolygon(Path.OutRec outRec)
/*      */   {
/* 1503 */     Path.OutPt lastOK = null;
/* 1504 */     outRec.bottomPt = null;
/* 1505 */     Path.OutPt pp = outRec.getPoints();
/* 1506 */     boolean preserveCol = (this.preserveCollinear) || (this.strictlySimple);
/*      */     for (;;) {
/* 1508 */       if ((pp.prev == pp) || (pp.prev == pp.next)) {
/* 1509 */         outRec.setPoints(null);
/* 1510 */         return;
/*      */       }
/*      */       
/* 1513 */       if ((pp.getPt().equals(pp.next.getPt())) || (pp.getPt().equals(pp.prev.getPt())) || (
/* 1514 */         (Point.slopesEqual(pp.prev.getPt(), pp.getPt(), pp.next.getPt(), this.useFullRange)) && ((!preserveCol) || 
/* 1515 */         (!Point.isPt2BetweenPt1AndPt3(pp.prev.getPt(), pp.getPt(), pp.next.getPt()))))) {
/* 1516 */         lastOK = null;
/* 1517 */         pp.prev.next = pp.next;
/* 1518 */         pp.next.prev = pp.prev;
/* 1519 */         pp = pp.prev;
/*      */       } else {
/* 1521 */         if (pp == lastOK) {
/*      */           break;
/*      */         }
/*      */         
/* 1525 */         if (lastOK == null) {
/* 1526 */           lastOK = pp;
/*      */         }
/* 1528 */         pp = pp.next;
/*      */       }
/*      */     }
/* 1531 */     outRec.setPoints(pp);
/*      */   }
/*      */   
/*      */   private Path.OutRec getOutRec(int idx) {
/* 1535 */     Path.OutRec outrec = (Path.OutRec)this.polyOuts.get(idx);
/* 1536 */     while (outrec != this.polyOuts.get(outrec.Idx)) {
/* 1537 */       outrec = (Path.OutRec)this.polyOuts.get(outrec.Idx);
/*      */     }
/* 1539 */     return outrec;
/*      */   }
/*      */   
/*      */   private void insertEdgeIntoAEL(Edge edge, Edge startEdge) {
/* 1543 */     LOGGER.entering(DefaultClipper.class.getName(), "insertEdgeIntoAEL");
/*      */     
/* 1545 */     if (this.activeEdges == null) {
/* 1546 */       edge.prevInAEL = null;
/* 1547 */       edge.nextInAEL = null;
/* 1548 */       LOGGER.finest("Edge " + edge.outIdx + " -> " + null);
/* 1549 */       this.activeEdges = edge;
/*      */     }
/* 1551 */     else if ((startEdge == null) && (Edge.doesE2InsertBeforeE1(this.activeEdges, edge))) {
/* 1552 */       edge.prevInAEL = null;
/* 1553 */       edge.nextInAEL = this.activeEdges;
/* 1554 */       LOGGER.finest("Edge " + edge.outIdx + " -> " + edge.nextInAEL.outIdx);
/* 1555 */       this.activeEdges.prevInAEL = edge;
/* 1556 */       this.activeEdges = edge;
/*      */     }
/*      */     else {
/* 1559 */       LOGGER.finest("activeEdges unchanged");
/* 1560 */       if (startEdge == null) {
/* 1561 */         startEdge = this.activeEdges;
/*      */       }
/* 1563 */       while ((startEdge.nextInAEL != null) && 
/* 1564 */         (!Edge.doesE2InsertBeforeE1(startEdge.nextInAEL, edge))) {
/* 1565 */         startEdge = startEdge.nextInAEL;
/*      */       }
/* 1567 */       edge.nextInAEL = startEdge.nextInAEL;
/* 1568 */       if (startEdge.nextInAEL != null) {
/* 1569 */         startEdge.nextInAEL.prevInAEL = edge;
/*      */       }
/* 1571 */       edge.prevInAEL = startEdge;
/* 1572 */       startEdge.nextInAEL = edge;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void insertLocalMinimaIntoAEL(long botY)
/*      */   {
/* 1579 */     LOGGER.entering(DefaultClipper.class.getName(), "insertLocalMinimaIntoAEL");
/*      */     
/* 1581 */     while ((this.currentLM != null) && (this.currentLM.y == botY)) {
/* 1582 */       Edge lb = this.currentLM.leftBound;
/* 1583 */       Edge rb = this.currentLM.rightBound;
/* 1584 */       popLocalMinima();
/*      */       
/* 1586 */       Path.OutPt Op1 = null;
/* 1587 */       if (lb == null) {
/* 1588 */         insertEdgeIntoAEL(rb, null);
/* 1589 */         updateWindingCount(rb);
/* 1590 */         if (rb.isContributing(this.clipFillType, this.subjFillType, this.clipType)) {
/* 1591 */           Op1 = addOutPt(rb, rb.getBot());
/*      */         }
/*      */       }
/* 1594 */       else if (rb == null) {
/* 1595 */         insertEdgeIntoAEL(lb, null);
/* 1596 */         updateWindingCount(lb);
/* 1597 */         if (lb.isContributing(this.clipFillType, this.subjFillType, this.clipType)) {
/* 1598 */           Op1 = addOutPt(lb, lb.getBot());
/*      */         }
/* 1600 */         insertScanbeam(lb.getTop().getY());
/*      */       }
/*      */       else {
/* 1603 */         insertEdgeIntoAEL(lb, null);
/* 1604 */         insertEdgeIntoAEL(rb, lb);
/* 1605 */         updateWindingCount(lb);
/* 1606 */         rb.windCnt = lb.windCnt;
/* 1607 */         rb.windCnt2 = lb.windCnt2;
/* 1608 */         if (lb.isContributing(this.clipFillType, this.subjFillType, this.clipType)) {
/* 1609 */           Op1 = addLocalMinPoly(lb, rb, lb.getBot());
/*      */         }
/* 1611 */         insertScanbeam(lb.getTop().getY());
/*      */       }
/*      */       
/* 1614 */       if (rb != null) {
/* 1615 */         if (rb.isHorizontal()) {
/* 1616 */           addEdgeToSEL(rb);
/*      */         }
/*      */         else {
/* 1619 */           insertScanbeam(rb.getTop().getY());
/*      */         }
/*      */       }
/*      */       
/* 1623 */       if ((lb != null) && (rb != null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1628 */         if ((Op1 != null) && (rb.isHorizontal()) && 
/* 1629 */           (this.ghostJoins.size() > 0) && (rb.windDelta != 0)) {
/* 1630 */           for (int i = 0; i < this.ghostJoins.size(); i++)
/*      */           {
/*      */ 
/* 1633 */             Path.Join j = (Path.Join)this.ghostJoins.get(i);
/* 1634 */             if (doHorzSegmentsOverlap(j.outPt1.getPt().getX(), j.getOffPt().getX(), rb.getBot().getX(), rb.getTop().getX())) {
/* 1635 */               addJoin(j.outPt1, Op1, j.getOffPt());
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1640 */         if ((lb.outIdx >= 0) && (lb.prevInAEL != null) && 
/* 1641 */           (lb.prevInAEL.getCurrent().getX() == lb.getBot().getX()) && (lb.prevInAEL.outIdx >= 0))
/*      */         {
/* 1643 */           if ((Edge.slopesEqual(lb.prevInAEL, lb, this.useFullRange)) && (lb.windDelta != 0) && (lb.prevInAEL.windDelta != 0))
/*      */           {
/* 1645 */             Path.OutPt Op2 = addOutPt(lb.prevInAEL, lb.getBot());
/* 1646 */             addJoin(Op1, Op2, lb.getTop());
/*      */           }
/*      */         }
/* 1649 */         if (lb.nextInAEL != rb)
/*      */         {
/* 1651 */           if ((rb.outIdx >= 0) && (rb.prevInAEL.outIdx >= 0) && 
/* 1652 */             (Edge.slopesEqual(rb.prevInAEL, rb, this.useFullRange)) && (rb.windDelta != 0) && (rb.prevInAEL.windDelta != 0))
/*      */           {
/* 1654 */             Path.OutPt Op2 = addOutPt(rb.prevInAEL, rb.getBot());
/* 1655 */             addJoin(Op1, Op2, rb.getTop());
/*      */           }
/*      */           
/* 1658 */           Edge e = lb.nextInAEL;
/* 1659 */           if (e != null) {
/* 1660 */             while (e != rb)
/*      */             {
/*      */ 
/* 1663 */               intersectEdges(rb, e, lb.getCurrent());
/* 1664 */               e = e.nextInAEL;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void intersectEdges(Edge e1, Edge e2, Point.LongPoint pt)
/*      */   {
/* 1706 */     LOGGER.entering(DefaultClipper.class.getName(), "insersectEdges");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1711 */     boolean e1Contributing = e1.outIdx >= 0;
/* 1712 */     boolean e2Contributing = e2.outIdx >= 0;
/*      */     
/* 1714 */     setZ(pt, e1, e2);
/*      */     
/*      */ 
/* 1717 */     if ((e1.windDelta == 0) || (e2.windDelta == 0))
/*      */     {
/*      */ 
/* 1720 */       if ((e1.windDelta == 0) && (e2.windDelta == 0)) {
/* 1721 */         return;
/*      */       }
/* 1723 */       if ((e1.polyTyp == e2.polyTyp) && (e1.windDelta != e2.windDelta) && (this.clipType == Clipper.ClipType.UNION))
/*      */       {
/* 1725 */         if (e1.windDelta == 0) {
/* 1726 */           if (e2Contributing) {
/* 1727 */             addOutPt(e1, pt);
/* 1728 */             if (e1Contributing) {
/* 1729 */               e1.outIdx = -1;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/* 1734 */         else if (e1Contributing) {
/* 1735 */           addOutPt(e2, pt);
/* 1736 */           if (e2Contributing) {
/* 1737 */             e2.outIdx = -1;
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 1742 */       else if (e1.polyTyp != e2.polyTyp) {
/* 1743 */         if ((e1.windDelta == 0) && (Math.abs(e2.windCnt) == 1) && ((this.clipType != Clipper.ClipType.UNION) || (e2.windCnt2 == 0))) {
/* 1744 */           addOutPt(e1, pt);
/* 1745 */           if (e1Contributing) {
/* 1746 */             e1.outIdx = -1;
/*      */           }
/*      */         }
/* 1749 */         else if ((e2.windDelta == 0) && (Math.abs(e1.windCnt) == 1) && ((this.clipType != Clipper.ClipType.UNION) || (e1.windCnt2 == 0))) {
/* 1750 */           addOutPt(e2, pt);
/* 1751 */           if (e2Contributing) {
/* 1752 */             e2.outIdx = -1;
/*      */           }
/*      */         }
/*      */       }
/* 1756 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1761 */     if (e1.polyTyp == e2.polyTyp) {
/* 1762 */       if (e1.isEvenOddFillType(this.clipFillType, this.subjFillType)) {
/* 1763 */         int oldE1WindCnt = e1.windCnt;
/* 1764 */         e1.windCnt = e2.windCnt;
/* 1765 */         e2.windCnt = oldE1WindCnt;
/*      */       }
/*      */       else {
/* 1768 */         if (e1.windCnt + e2.windDelta == 0) {
/* 1769 */           e1.windCnt = (-e1.windCnt);
/*      */         }
/*      */         else {
/* 1772 */           e1.windCnt += e2.windDelta;
/*      */         }
/* 1774 */         if (e2.windCnt - e1.windDelta == 0) {
/* 1775 */           e2.windCnt = (-e2.windCnt);
/*      */         }
/*      */         else {
/* 1778 */           e2.windCnt -= e1.windDelta;
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1783 */       if (!e2.isEvenOddFillType(this.clipFillType, this.subjFillType)) {
/* 1784 */         e1.windCnt2 += e2.windDelta;
/*      */       }
/*      */       else {
/* 1787 */         e1.windCnt2 = (e1.windCnt2 == 0 ? 1 : 0);
/*      */       }
/* 1789 */       if (!e1.isEvenOddFillType(this.clipFillType, this.subjFillType)) {
/* 1790 */         e2.windCnt2 -= e1.windDelta;
/*      */       }
/*      */       else
/* 1793 */         e2.windCnt2 = (e2.windCnt2 == 0 ? 1 : 0);
/*      */     }
/*      */     Clipper.PolyFillType e1FillType2;
/*      */     Clipper.PolyFillType e1FillType;
/*      */     Clipper.PolyFillType e1FillType2;
/* 1798 */     if (e1.polyTyp == Clipper.PolyType.SUBJECT) {
/* 1799 */       Clipper.PolyFillType e1FillType = this.subjFillType;
/* 1800 */       e1FillType2 = this.clipFillType;
/*      */     }
/*      */     else {
/* 1803 */       e1FillType = this.clipFillType;
/* 1804 */       e1FillType2 = this.subjFillType; }
/*      */     Clipper.PolyFillType e2FillType2;
/* 1806 */     Clipper.PolyFillType e2FillType; Clipper.PolyFillType e2FillType2; if (e2.polyTyp == Clipper.PolyType.SUBJECT) {
/* 1807 */       Clipper.PolyFillType e2FillType = this.subjFillType;
/* 1808 */       e2FillType2 = this.clipFillType;
/*      */     }
/*      */     else {
/* 1811 */       e2FillType = this.clipFillType;
/* 1812 */       e2FillType2 = this.subjFillType; }
/*      */     int e1Wc;
/*      */     int e1Wc;
/*      */     int e1Wc;
/* 1816 */     switch (e1FillType) {
/*      */     case POSITIVE: 
/* 1818 */       e1Wc = e1.windCnt;
/* 1819 */       break;
/*      */     case NEGATIVE: 
/* 1821 */       e1Wc = -e1.windCnt;
/* 1822 */       break;
/*      */     default: 
/* 1824 */       e1Wc = Math.abs(e1.windCnt); }
/*      */     int e2Wc;
/*      */     int e2Wc;
/* 1827 */     int e2Wc; switch (e2FillType) {
/*      */     case POSITIVE: 
/* 1829 */       e2Wc = e2.windCnt;
/* 1830 */       break;
/*      */     case NEGATIVE: 
/* 1832 */       e2Wc = -e2.windCnt;
/* 1833 */       break;
/*      */     default: 
/* 1835 */       e2Wc = Math.abs(e2.windCnt);
/*      */     }
/*      */     
/*      */     
/* 1839 */     if ((e1Contributing) && (e2Contributing)) {
/* 1840 */       if (((e1Wc != 0) && (e1Wc != 1)) || ((e2Wc != 0) && (e2Wc != 1)) || ((e1.polyTyp != e2.polyTyp) && (this.clipType != Clipper.ClipType.XOR))) {
/* 1841 */         addLocalMaxPoly(e1, e2, pt);
/*      */       }
/*      */       else {
/* 1844 */         addOutPt(e1, pt);
/* 1845 */         addOutPt(e2, pt);
/* 1846 */         Edge.swapSides(e1, e2);
/* 1847 */         Edge.swapPolyIndexes(e1, e2);
/*      */       }
/*      */     }
/* 1850 */     else if (e1Contributing) {
/* 1851 */       if ((e2Wc == 0) || (e2Wc == 1)) {
/* 1852 */         addOutPt(e1, pt);
/* 1853 */         Edge.swapSides(e1, e2);
/* 1854 */         Edge.swapPolyIndexes(e1, e2);
/*      */       }
/*      */       
/*      */     }
/* 1858 */     else if (e2Contributing) {
/* 1859 */       if ((e1Wc == 0) || (e1Wc == 1)) {
/* 1860 */         addOutPt(e2, pt);
/* 1861 */         Edge.swapSides(e1, e2);
/* 1862 */         Edge.swapPolyIndexes(e1, e2);
/*      */       }
/*      */     }
/* 1865 */     else if (((e1Wc == 0) || (e1Wc == 1)) && ((e2Wc == 0) || (e2Wc == 1))) { int e1Wc2;
/*      */       int e1Wc2;
/*      */       int e1Wc2;
/* 1868 */       switch (e1FillType2) {
/*      */       case POSITIVE: 
/* 1870 */         e1Wc2 = e1.windCnt2;
/* 1871 */         break;
/*      */       case NEGATIVE: 
/* 1873 */         e1Wc2 = -e1.windCnt2;
/* 1874 */         break;
/*      */       default: 
/* 1876 */         e1Wc2 = Math.abs(e1.windCnt2); }
/*      */       int e2Wc2;
/*      */       int e2Wc2;
/* 1879 */       int e2Wc2; switch (e2FillType2) {
/*      */       case POSITIVE: 
/* 1881 */         e2Wc2 = e2.windCnt2;
/* 1882 */         break;
/*      */       case NEGATIVE: 
/* 1884 */         e2Wc2 = -e2.windCnt2;
/* 1885 */         break;
/*      */       default: 
/* 1887 */         e2Wc2 = Math.abs(e2.windCnt2);
/*      */       }
/*      */       
/*      */       
/* 1891 */       if (e1.polyTyp != e2.polyTyp) {
/* 1892 */         addLocalMinPoly(e1, e2, pt);
/*      */       }
/* 1894 */       else if ((e1Wc == 1) && (e2Wc == 1)) {
/* 1895 */         switch (this.clipType) {
/*      */         case INTERSECTION: 
/* 1897 */           if ((e1Wc2 > 0) && (e2Wc2 > 0)) {
/* 1898 */             addLocalMinPoly(e1, e2, pt);
/*      */           }
/*      */           break;
/*      */         case UNION: 
/* 1902 */           if ((e1Wc2 <= 0) && (e2Wc2 <= 0)) {
/* 1903 */             addLocalMinPoly(e1, e2, pt);
/*      */           }
/*      */           break;
/*      */         case DIFFERENCE: 
/* 1907 */           if (((e1.polyTyp == Clipper.PolyType.CLIP) && (e1Wc2 > 0) && (e2Wc2 > 0)) || ((e1.polyTyp == Clipper.PolyType.SUBJECT) && (e1Wc2 <= 0) && (e2Wc2 <= 0))) {
/* 1908 */             addLocalMinPoly(e1, e2, pt);
/*      */           }
/*      */           break;
/*      */         case XOR: 
/* 1912 */           addLocalMinPoly(e1, e2, pt);
/*      */         
/*      */         }
/*      */         
/*      */       } else {
/* 1917 */         Edge.swapSides(e1, e2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void intersectPoint(Edge edge1, Edge edge2, Point.LongPoint[] ipV) {
/* 1923 */     Point.LongPoint ip = ipV[0] = new Point.LongPoint();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1928 */     if (edge1.deltaX == edge2.deltaX) {
/* 1929 */       ip.setY(Long.valueOf(edge1.getCurrent().getY()));
/* 1930 */       ip.setX(Long.valueOf(Edge.topX(edge1, ip.getY())));
/* 1931 */       return;
/*      */     }
/*      */     
/* 1934 */     if (edge1.getDelta().getX() == 0L) {
/* 1935 */       ip.setX(Long.valueOf(edge1.getBot().getX()));
/* 1936 */       if (edge2.isHorizontal()) {
/* 1937 */         ip.setY(Long.valueOf(edge2.getBot().getY()));
/*      */       }
/*      */       else {
/* 1940 */         double b2 = edge2.getBot().getY() - edge2.getBot().getX() / edge2.deltaX;
/* 1941 */         ip.setY(Long.valueOf(Math.round(ip.getX() / edge2.deltaX + b2)));
/*      */       }
/*      */     }
/* 1944 */     else if (edge2.getDelta().getX() == 0L) {
/* 1945 */       ip.setX(Long.valueOf(edge2.getBot().getX()));
/* 1946 */       if (edge1.isHorizontal()) {
/* 1947 */         ip.setY(Long.valueOf(edge1.getBot().getY()));
/*      */       }
/*      */       else {
/* 1950 */         double b1 = edge1.getBot().getY() - edge1.getBot().getX() / edge1.deltaX;
/* 1951 */         ip.setY(Long.valueOf(Math.round(ip.getX() / edge1.deltaX + b1)));
/*      */       }
/*      */     }
/*      */     else {
/* 1955 */       double b1 = edge1.getBot().getX() - edge1.getBot().getY() * edge1.deltaX;
/* 1956 */       double b2 = edge2.getBot().getX() - edge2.getBot().getY() * edge2.deltaX;
/* 1957 */       double q = (b2 - b1) / (edge1.deltaX - edge2.deltaX);
/* 1958 */       ip.setY(Long.valueOf(Math.round(q)));
/* 1959 */       if (Math.abs(edge1.deltaX) < Math.abs(edge2.deltaX)) {
/* 1960 */         ip.setX(Long.valueOf(Math.round(edge1.deltaX * q + b1)));
/*      */       }
/*      */       else {
/* 1963 */         ip.setX(Long.valueOf(Math.round(edge2.deltaX * q + b2)));
/*      */       }
/*      */     }
/*      */     
/* 1967 */     if ((ip.getY() < edge1.getTop().getY()) || (ip.getY() < edge2.getTop().getY())) {
/* 1968 */       if (edge1.getTop().getY() > edge2.getTop().getY()) {
/* 1969 */         ip.setY(Long.valueOf(edge1.getTop().getY()));
/*      */       }
/*      */       else {
/* 1972 */         ip.setY(Long.valueOf(edge2.getTop().getY()));
/*      */       }
/* 1974 */       if (Math.abs(edge1.deltaX) < Math.abs(edge2.deltaX)) {
/* 1975 */         ip.setX(Long.valueOf(Edge.topX(edge1, ip.getY())));
/*      */       }
/*      */       else {
/* 1978 */         ip.setX(Long.valueOf(Edge.topX(edge2, ip.getY())));
/*      */       }
/*      */     }
/*      */     
/* 1982 */     if (ip.getY() > edge1.getCurrent().getY()) {
/* 1983 */       ip.setY(Long.valueOf(edge1.getCurrent().getY()));
/*      */       
/* 1985 */       if (Math.abs(edge1.deltaX) > Math.abs(edge2.deltaX)) {
/* 1986 */         ip.setX(Long.valueOf(Edge.topX(edge2, ip.getY())));
/*      */       }
/*      */       else {
/* 1989 */         ip.setX(Long.valueOf(Edge.topX(edge1, ip.getY())));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void joinCommonEdges() {
/* 1995 */     for (int i = 0; i < this.joins.size(); i++) {
/* 1996 */       Path.Join join = (Path.Join)this.joins.get(i);
/*      */       
/* 1998 */       Path.OutRec outRec1 = getOutRec(join.outPt1.idx);
/* 1999 */       Path.OutRec outRec2 = getOutRec(join.outPt2.idx);
/*      */       
/* 2001 */       if ((outRec1.getPoints() != null) && (outRec2.getPoints() != null))
/*      */       {
/*      */ 
/* 2004 */         if ((!outRec1.isOpen) && (!outRec2.isOpen))
/*      */         {
/*      */           Path.OutRec holeStateRec;
/*      */           
/*      */           Path.OutRec holeStateRec;
/* 2009 */           if (outRec1 == outRec2) {
/* 2010 */             holeStateRec = outRec1;
/*      */           } else { Path.OutRec holeStateRec;
/* 2012 */             if (isParam1RightOfParam2(outRec1, outRec2)) {
/* 2013 */               holeStateRec = outRec2;
/*      */             } else { Path.OutRec holeStateRec;
/* 2015 */               if (isParam1RightOfParam2(outRec2, outRec1)) {
/* 2016 */                 holeStateRec = outRec1;
/*      */               }
/*      */               else
/* 2019 */                 holeStateRec = Path.OutPt.getLowerMostRec(outRec1, outRec2);
/*      */             }
/*      */           }
/* 2022 */           if (joinPoints(join, outRec1, outRec2))
/*      */           {
/*      */ 
/*      */ 
/* 2026 */             if (outRec1 == outRec2)
/*      */             {
/*      */ 
/* 2029 */               outRec1.setPoints(join.outPt1);
/* 2030 */               outRec1.bottomPt = null;
/* 2031 */               outRec2 = createOutRec();
/* 2032 */               outRec2.setPoints(join.outPt2);
/*      */               
/*      */ 
/* 2035 */               updateOutPtIdxs(outRec2);
/*      */               
/*      */ 
/*      */ 
/* 2039 */               if (this.usingPolyTree) {
/* 2040 */                 for (int j = 0; j < this.polyOuts.size() - 1; j++) {
/* 2041 */                   Path.OutRec oRec = (Path.OutRec)this.polyOuts.get(j);
/* 2042 */                   if ((oRec.getPoints() != null) && (parseFirstLeft(oRec.firstLeft) == outRec1) && (oRec.isHole != outRec1.isHole))
/*      */                   {
/*      */ 
/* 2045 */                     if (poly2ContainsPoly1(oRec.getPoints(), join.outPt2)) {
/* 2046 */                       oRec.firstLeft = outRec2;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/* 2051 */               if (poly2ContainsPoly1(outRec2.getPoints(), outRec1.getPoints()))
/*      */               {
/* 2053 */                 outRec2.isHole = (!outRec1.isHole);
/* 2054 */                 outRec2.firstLeft = outRec1;
/*      */                 
/*      */ 
/* 2057 */                 if (this.usingPolyTree) {
/* 2058 */                   fixupFirstLefts2(outRec2, outRec1);
/*      */                 }
/*      */                 
/* 2061 */                 if ((outRec2.isHole ^ this.reverseSolution) == outRec2.area() > 0.0D) {
/* 2062 */                   outRec2.getPoints().reversePolyPtLinks();
/*      */                 }
/*      */                 
/*      */               }
/* 2066 */               else if (poly2ContainsPoly1(outRec1.getPoints(), outRec2.getPoints()))
/*      */               {
/* 2068 */                 outRec2.isHole = outRec1.isHole;
/* 2069 */                 outRec1.isHole = (!outRec2.isHole);
/* 2070 */                 outRec2.firstLeft = outRec1.firstLeft;
/* 2071 */                 outRec1.firstLeft = outRec2;
/*      */                 
/*      */ 
/* 2074 */                 if (this.usingPolyTree) {
/* 2075 */                   fixupFirstLefts2(outRec1, outRec2);
/*      */                 }
/*      */                 
/* 2078 */                 if ((outRec1.isHole ^ this.reverseSolution) == outRec1.area() > 0.0D) {
/* 2079 */                   outRec1.getPoints().reversePolyPtLinks();
/*      */                 }
/*      */               }
/*      */               else
/*      */               {
/* 2084 */                 outRec2.isHole = outRec1.isHole;
/* 2085 */                 outRec2.firstLeft = outRec1.firstLeft;
/*      */                 
/*      */ 
/* 2088 */                 if (this.usingPolyTree) {
/* 2089 */                   fixupFirstLefts1(outRec1, outRec2);
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/*      */             else
/*      */             {
/* 2097 */               outRec2.setPoints(null);
/* 2098 */               outRec2.bottomPt = null;
/* 2099 */               outRec2.Idx = outRec1.Idx;
/*      */               
/* 2101 */               outRec1.isHole = holeStateRec.isHole;
/* 2102 */               if (holeStateRec == outRec2) {
/* 2103 */                 outRec1.firstLeft = outRec2.firstLeft;
/*      */               }
/* 2105 */               outRec2.firstLeft = outRec1;
/*      */               
/*      */ 
/* 2108 */               if (this.usingPolyTree)
/* 2109 */                 fixupFirstLefts2(outRec2, outRec1);
/*      */             } }
/*      */         } }
/*      */     }
/*      */   }
/*      */   
/*      */   private long popScanbeam() {
/* 2116 */     LOGGER.entering(DefaultClipper.class.getName(), "popBeam");
/*      */     
/* 2118 */     long y = this.scanbeam.y;
/* 2119 */     this.scanbeam = this.scanbeam.next;
/* 2120 */     return y;
/*      */   }
/*      */   
/*      */   private void processEdgesAtTopOfScanbeam(long topY) {
/* 2124 */     LOGGER.entering(DefaultClipper.class.getName(), "processEdgesAtTopOfScanbeam");
/*      */     
/* 2126 */     Edge e = this.activeEdges;
/* 2127 */     while (e != null)
/*      */     {
/*      */ 
/* 2130 */       boolean IsMaximaEdge = e.isMaxima(topY);
/*      */       
/* 2132 */       if (IsMaximaEdge) {
/* 2133 */         Edge eMaxPair = e.getMaximaPair();
/* 2134 */         IsMaximaEdge = (eMaxPair == null) || (!eMaxPair.isHorizontal());
/*      */       }
/*      */       
/* 2137 */       if (IsMaximaEdge) {
/* 2138 */         if (this.strictlySimple) InsertMaxima(e.getTop().getX());
/* 2139 */         Edge ePrev = e.prevInAEL;
/* 2140 */         doMaxima(e);
/* 2141 */         if (ePrev == null) {
/* 2142 */           e = this.activeEdges;
/*      */         }
/*      */         else {
/* 2145 */           e = ePrev.nextInAEL;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2150 */         if ((e.isIntermediate(topY)) && (e.nextInLML.isHorizontal())) {
/* 2151 */           Edge[] t = { e };
/* 2152 */           updateEdgeIntoAEL(t);
/* 2153 */           e = t[0];
/* 2154 */           if (e.outIdx >= 0) {
/* 2155 */             addOutPt(e, e.getBot());
/*      */           }
/* 2157 */           addEdgeToSEL(e);
/*      */         }
/*      */         else {
/* 2160 */           e.getCurrent().setX(Long.valueOf(Edge.topX(e, topY)));
/* 2161 */           e.getCurrent().setY(Long.valueOf(topY));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2166 */         if (this.strictlySimple) {
/* 2167 */           Edge ePrev = e.prevInAEL;
/* 2168 */           if ((e.outIdx >= 0) && (e.windDelta != 0) && (ePrev != null) && (ePrev.outIdx >= 0) && (ePrev.getCurrent().getX() == e.getCurrent().getX()) && (ePrev.windDelta != 0))
/*      */           {
/* 2170 */             Point.LongPoint ip = new Point.LongPoint(e.getCurrent());
/*      */             
/* 2172 */             setZ(ip, ePrev, e);
/*      */             
/* 2174 */             Path.OutPt op = addOutPt(ePrev, ip);
/* 2175 */             Path.OutPt op2 = addOutPt(e, ip);
/* 2176 */             addJoin(op, op2, ip);
/*      */           }
/*      */         }
/*      */         
/* 2180 */         e = e.nextInAEL;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2185 */     processHorizontals();
/* 2186 */     this.maxima = null;
/*      */     
/*      */ 
/* 2189 */     e = this.activeEdges;
/* 2190 */     while (e != null) {
/* 2191 */       if (e.isIntermediate(topY)) {
/* 2192 */         Path.OutPt op = null;
/* 2193 */         if (e.outIdx >= 0) {
/* 2194 */           op = addOutPt(e, e.getTop());
/*      */         }
/* 2196 */         Edge[] t = { e };
/* 2197 */         updateEdgeIntoAEL(t);
/* 2198 */         e = t[0];
/*      */         
/*      */ 
/* 2201 */         Edge ePrev = e.prevInAEL;
/* 2202 */         Edge eNext = e.nextInAEL;
/* 2203 */         if ((ePrev != null) && (ePrev.getCurrent().getX() == e.getBot().getX()) && (ePrev.getCurrent().getY() == e.getBot().getY()) && (op != null) && (ePrev.outIdx >= 0) && 
/* 2204 */           (ePrev.getCurrent().getY() > ePrev.getTop().getY()) && (Edge.slopesEqual(e, ePrev, this.useFullRange)) && (e.windDelta != 0) && (ePrev.windDelta != 0))
/*      */         {
/* 2206 */           Path.OutPt op2 = addOutPt(ePrev, e.getBot());
/* 2207 */           addJoin(op, op2, e.getTop());
/*      */         }
/* 2209 */         else if ((eNext != null) && (eNext.getCurrent().getX() == e.getBot().getX()) && (eNext.getCurrent().getY() == e.getBot().getY()) && (op != null) && (eNext.outIdx >= 0) && 
/* 2210 */           (eNext.getCurrent().getY() > eNext.getTop().getY()) && (Edge.slopesEqual(e, eNext, this.useFullRange)) && (e.windDelta != 0) && (eNext.windDelta != 0))
/*      */         {
/* 2212 */           Path.OutPt op2 = addOutPt(eNext, e.getBot());
/* 2213 */           addJoin(op, op2, e.getTop());
/*      */         }
/*      */       }
/* 2216 */       e = e.nextInAEL;
/*      */     }
/* 2218 */     LOGGER.exiting(DefaultClipper.class.getName(), "processEdgesAtTopOfScanbeam");
/*      */   }
/*      */   
/*      */   private void processHorizontal(Edge horzEdge) {
/* 2222 */     LOGGER.entering(DefaultClipper.class.getName(), "isHorizontal");
/* 2223 */     Clipper.Direction[] dir = new Clipper.Direction[1];
/* 2224 */     long[] horzLeft = new long[1];long[] horzRight = new long[1];
/* 2225 */     boolean IsOpen = (horzEdge.outIdx >= 0) && (((Path.OutRec)this.polyOuts.get(horzEdge.outIdx)).isOpen);
/*      */     
/* 2227 */     getHorzDirection(horzEdge, dir, horzLeft, horzRight);
/*      */     
/* 2229 */     Edge eLastHorz = horzEdge;Edge eMaxPair = null;
/* 2230 */     while ((eLastHorz.nextInLML != null) && (eLastHorz.nextInLML.isHorizontal())) {
/* 2231 */       eLastHorz = eLastHorz.nextInLML;
/*      */     }
/* 2233 */     if (eLastHorz.nextInLML == null) {
/* 2234 */       eMaxPair = eLastHorz.getMaximaPair();
/*      */     }
/*      */     
/* 2237 */     Path.Maxima currMax = this.maxima;
/* 2238 */     if (currMax != null)
/*      */     {
/*      */ 
/* 2241 */       if (dir[0] == Clipper.Direction.LEFT_TO_RIGHT)
/*      */       {
/* 2243 */         while ((currMax != null) && (currMax.X <= horzEdge.getBot().getX()))
/* 2244 */           currMax = currMax.Next;
/* 2245 */         if ((currMax != null) && (currMax.X >= eLastHorz.getBot().getX())) {
/* 2246 */           currMax = null;
/*      */         }
/*      */       }
/*      */       else {
/* 2250 */         while ((currMax.Next != null) && (currMax.Next.X < horzEdge.getBot().getX()))
/* 2251 */           currMax = currMax.Next;
/* 2252 */         if (currMax.X <= eLastHorz.getTop().getX()) { currMax = null;
/*      */         }
/*      */       }
/*      */     }
/* 2256 */     Path.OutPt op1 = null;
/*      */     for (;;) {
/* 2258 */       boolean IsLastHorz = horzEdge == eLastHorz;
/* 2259 */       Edge e = horzEdge.getNextInAEL(dir[0]);
/* 2260 */       while (e != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2265 */         if (currMax != null)
/*      */         {
/* 2267 */           if (dir[0] == Clipper.Direction.LEFT_TO_RIGHT)
/*      */           {
/* 2269 */             while ((currMax != null) && (currMax.X < e.getCurrent().getX()))
/*      */             {
/* 2271 */               if ((horzEdge.outIdx >= 0) && (!IsOpen))
/* 2272 */                 addOutPt(horzEdge, new Point.LongPoint(currMax.X, horzEdge.getBot().getY()));
/* 2273 */               currMax = currMax.Next;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2278 */           while ((currMax != null) && (currMax.X > e.getCurrent().getX()))
/*      */           {
/* 2280 */             if ((horzEdge.outIdx >= 0) && (!IsOpen))
/* 2281 */               addOutPt(horzEdge, new Point.LongPoint(currMax.X, horzEdge.getBot().getY()));
/* 2282 */             currMax = currMax.Prev;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2288 */         if (((dir[0] == Clipper.Direction.LEFT_TO_RIGHT) && (e.getCurrent().getX() > horzRight[0])) || ((dir[0] == Clipper.Direction.RIGHT_TO_LEFT) && 
/* 2289 */           (e.getCurrent().getX() < horzLeft[0]))) {
/*      */           break;
/*      */         }
/* 2292 */         if ((e.getCurrent().getX() == horzEdge.getTop().getX()) && (horzEdge.nextInLML != null) && (e.deltaX < horzEdge.nextInLML.deltaX)) {
/*      */           break;
/*      */         }
/* 2295 */         if ((horzEdge.outIdx >= 0) && (!IsOpen))
/*      */         {
/* 2297 */           op1 = addOutPt(horzEdge, e.getCurrent());
/* 2298 */           Edge eNextHorz = this.sortedEdges;
/* 2299 */           while (eNextHorz != null)
/*      */           {
/* 2301 */             if ((eNextHorz.outIdx >= 0) && 
/* 2302 */               (doHorzSegmentsOverlap(horzEdge.getBot().getX(), horzEdge
/* 2303 */               .getTop().getX(), eNextHorz.getBot().getX(), eNextHorz.getTop().getX())))
/*      */             {
/* 2305 */               Path.OutPt op2 = GetLastOutPt(eNextHorz);
/* 2306 */               addJoin(op2, op1, eNextHorz.getTop());
/*      */             }
/* 2308 */             eNextHorz = eNextHorz.nextInSEL;
/*      */           }
/* 2310 */           addGhostJoin(op1, horzEdge.getBot());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2315 */         if ((e == eMaxPair) && (IsLastHorz))
/*      */         {
/* 2317 */           if (horzEdge.outIdx >= 0)
/* 2318 */             addLocalMaxPoly(horzEdge, eMaxPair, horzEdge.getTop());
/* 2319 */           deleteFromAEL(horzEdge);
/* 2320 */           deleteFromAEL(eMaxPair);
/* 2321 */           return;
/*      */         }
/*      */         
/* 2324 */         if (dir[0] == Clipper.Direction.LEFT_TO_RIGHT)
/*      */         {
/* 2326 */           Point.LongPoint Pt = new Point.LongPoint(e.getCurrent().getX(), horzEdge.getCurrent().getY());
/* 2327 */           intersectEdges(horzEdge, e, Pt);
/*      */         }
/*      */         else
/*      */         {
/* 2331 */           Point.LongPoint Pt = new Point.LongPoint(e.getCurrent().getX(), horzEdge.getCurrent().getY());
/* 2332 */           intersectEdges(e, horzEdge, Pt);
/*      */         }
/* 2334 */         Edge eNext = e.getNextInAEL(dir[0]);
/* 2335 */         swapPositionsInAEL(horzEdge, e);
/* 2336 */         e = eNext;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2341 */       if ((horzEdge.nextInLML == null) || (!horzEdge.nextInLML.isHorizontal()))
/*      */         break;
/* 2343 */       Edge[] temp = new Edge[1];
/* 2344 */       temp[0] = horzEdge;
/* 2345 */       updateEdgeIntoAEL(temp);
/* 2346 */       horzEdge = temp[0];
/*      */       
/* 2348 */       if (horzEdge.outIdx >= 0) addOutPt(horzEdge, horzEdge.getBot());
/* 2349 */       getHorzDirection(horzEdge, dir, horzLeft, horzRight);
/*      */     }
/*      */     
/*      */ 
/* 2353 */     if ((horzEdge.outIdx >= 0) && (op1 == null))
/*      */     {
/* 2355 */       op1 = GetLastOutPt(horzEdge);
/* 2356 */       Edge eNextHorz = this.sortedEdges;
/* 2357 */       while (eNextHorz != null)
/*      */       {
/* 2359 */         if ((eNextHorz.outIdx >= 0) && 
/* 2360 */           (doHorzSegmentsOverlap(horzEdge.getBot().getX(), horzEdge
/* 2361 */           .getTop().getX(), eNextHorz.getBot().getX(), eNextHorz.getTop().getX())))
/*      */         {
/* 2363 */           Path.OutPt op2 = GetLastOutPt(eNextHorz);
/* 2364 */           addJoin(op2, op1, eNextHorz.getTop());
/*      */         }
/* 2366 */         eNextHorz = eNextHorz.nextInSEL;
/*      */       }
/* 2368 */       addGhostJoin(op1, horzEdge.getTop());
/*      */     }
/*      */     
/* 2371 */     if (horzEdge.nextInLML != null) {
/* 2372 */       if (horzEdge.outIdx >= 0) {
/* 2373 */         op1 = addOutPt(horzEdge, horzEdge.getTop());
/*      */         
/* 2375 */         Edge[] t = { horzEdge };
/* 2376 */         updateEdgeIntoAEL(t);
/* 2377 */         horzEdge = t[0];
/*      */         
/* 2379 */         if (horzEdge.windDelta == 0) {
/* 2380 */           return;
/*      */         }
/*      */         
/* 2383 */         Edge ePrev = horzEdge.prevInAEL;
/* 2384 */         Edge eNext = horzEdge.nextInAEL;
/* 2385 */         if ((ePrev != null) && (ePrev.getCurrent().getX() == horzEdge.getBot().getX()) && (ePrev.getCurrent().getY() == horzEdge.getBot().getY()) && (ePrev.windDelta != 0) && (ePrev.outIdx >= 0) && 
/* 2386 */           (ePrev.getCurrent().getY() > ePrev.getTop().getY()) && 
/* 2387 */           (Edge.slopesEqual(horzEdge, ePrev, this.useFullRange))) {
/* 2388 */           Path.OutPt op2 = addOutPt(ePrev, horzEdge.getBot());
/* 2389 */           addJoin(op1, op2, horzEdge.getTop());
/*      */         }
/* 2391 */         else if ((eNext != null) && (eNext.getCurrent().getX() == horzEdge.getBot().getX()) && (eNext.getCurrent().getY() == horzEdge.getBot().getY()) && (eNext.windDelta != 0) && (eNext.outIdx >= 0) && 
/* 2392 */           (eNext.getCurrent().getY() > eNext.getTop().getY()) && 
/* 2393 */           (Edge.slopesEqual(horzEdge, eNext, this.useFullRange))) {
/* 2394 */           Path.OutPt op2 = addOutPt(eNext, horzEdge.getBot());
/* 2395 */           addJoin(op1, op2, horzEdge.getTop());
/*      */         }
/*      */       }
/*      */       else {
/* 2399 */         Edge[] t = { horzEdge };
/* 2400 */         updateEdgeIntoAEL(t);
/* 2401 */         horzEdge = t[0];
/*      */       }
/*      */     }
/*      */     else {
/* 2405 */       if (horzEdge.outIdx >= 0) {
/* 2406 */         addOutPt(horzEdge, horzEdge.getTop());
/*      */       }
/* 2408 */       deleteFromAEL(horzEdge);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void processHorizontals()
/*      */   {
/* 2415 */     LOGGER.entering(DefaultClipper.class.getName(), "processHorizontals");
/*      */     
/* 2417 */     Edge horzEdge = this.sortedEdges;
/* 2418 */     while (horzEdge != null) {
/* 2419 */       deleteFromSEL(horzEdge);
/* 2420 */       processHorizontal(horzEdge);
/* 2421 */       horzEdge = this.sortedEdges;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean processIntersections(long topY)
/*      */   {
/* 2428 */     LOGGER.entering(DefaultClipper.class.getName(), "processIntersections");
/*      */     
/* 2430 */     if (this.activeEdges == null) {
/* 2431 */       return true;
/*      */     }
/*      */     try {
/* 2434 */       buildIntersectList(topY);
/* 2435 */       if (this.intersectList.size() == 0) {
/* 2436 */         return true;
/*      */       }
/* 2438 */       if ((this.intersectList.size() == 1) || (fixupIntersectionOrder())) {
/* 2439 */         processIntersectList();
/*      */       }
/*      */       else {
/* 2442 */         return false;
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2446 */       this.sortedEdges = null;
/* 2447 */       this.intersectList.clear();
/* 2448 */       throw new IllegalStateException("ProcessIntersections error", e);
/*      */     }
/* 2450 */     this.sortedEdges = null;
/* 2451 */     return true;
/*      */   }
/*      */   
/*      */   private void processIntersectList() {
/* 2455 */     for (int i = 0; i < this.intersectList.size(); i++) {
/* 2456 */       IntersectNode iNode = (IntersectNode)this.intersectList.get(i);
/*      */       
/* 2458 */       intersectEdges(iNode.edge1, iNode.Edge2, iNode.getPt());
/* 2459 */       swapPositionsInAEL(iNode.edge1, iNode.Edge2);
/*      */     }
/*      */     
/* 2462 */     this.intersectList.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void reset()
/*      */   {
/* 2469 */     super.reset();
/* 2470 */     this.scanbeam = null;
/* 2471 */     this.maxima = null;
/* 2472 */     this.activeEdges = null;
/* 2473 */     this.sortedEdges = null;
/* 2474 */     ClipperBase.LocalMinima lm = this.minimaList;
/* 2475 */     while (lm != null) {
/* 2476 */       insertScanbeam(lm.y);
/* 2477 */       lm = lm.next;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setHoleState(Edge e, Path.OutRec outRec) {
/* 2482 */     boolean isHole = false;
/* 2483 */     Edge e2 = e.prevInAEL;
/* 2484 */     while (e2 != null) {
/* 2485 */       if ((e2.outIdx >= 0) && (e2.windDelta != 0)) {
/* 2486 */         isHole = !isHole;
/* 2487 */         if (outRec.firstLeft == null) {
/* 2488 */           outRec.firstLeft = ((Path.OutRec)this.polyOuts.get(e2.outIdx));
/*      */         }
/*      */       }
/* 2491 */       e2 = e2.prevInAEL;
/*      */     }
/* 2493 */     if (isHole) {
/* 2494 */       outRec.isHole = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setZ(Point.LongPoint pt, Edge e1, Edge e2) {
/* 2499 */     if ((pt.getZ() != 0L) || (this.zFillFunction == null)) {
/* 2500 */       return;
/*      */     }
/* 2502 */     if (pt.equals(e1.getBot())) {
/* 2503 */       pt.setZ(Long.valueOf(e1.getBot().getZ()));
/*      */     }
/* 2505 */     else if (pt.equals(e1.getTop())) {
/* 2506 */       pt.setZ(Long.valueOf(e1.getTop().getZ()));
/*      */     }
/* 2508 */     else if (pt.equals(e2.getBot())) {
/* 2509 */       pt.setZ(Long.valueOf(e2.getBot().getZ()));
/*      */     }
/* 2511 */     else if (pt.equals(e2.getTop())) {
/* 2512 */       pt.setZ(Long.valueOf(e2.getTop().getZ()));
/*      */     }
/*      */     else {
/* 2515 */       this.zFillFunction.zFill(e1.getBot(), e1.getTop(), e2.getBot(), e2.getTop(), pt);
/*      */     }
/*      */   }
/*      */   
/*      */   private void swapPositionsInAEL(Edge edge1, Edge edge2) {
/* 2520 */     LOGGER.entering(DefaultClipper.class.getName(), "swapPositionsInAEL");
/*      */     
/*      */ 
/* 2523 */     if ((edge1.nextInAEL == edge1.prevInAEL) || (edge2.nextInAEL == edge2.prevInAEL)) {
/* 2524 */       return;
/*      */     }
/*      */     
/* 2527 */     if (edge1.nextInAEL == edge2) {
/* 2528 */       Edge next = edge2.nextInAEL;
/* 2529 */       if (next != null) {
/* 2530 */         next.prevInAEL = edge1;
/*      */       }
/* 2532 */       Edge prev = edge1.prevInAEL;
/* 2533 */       if (prev != null) {
/* 2534 */         prev.nextInAEL = edge2;
/*      */       }
/* 2536 */       edge2.prevInAEL = prev;
/* 2537 */       edge2.nextInAEL = edge1;
/* 2538 */       edge1.prevInAEL = edge2;
/* 2539 */       edge1.nextInAEL = next;
/*      */     }
/* 2541 */     else if (edge2.nextInAEL == edge1) {
/* 2542 */       Edge next = edge1.nextInAEL;
/* 2543 */       if (next != null) {
/* 2544 */         next.prevInAEL = edge2;
/*      */       }
/* 2546 */       Edge prev = edge2.prevInAEL;
/* 2547 */       if (prev != null) {
/* 2548 */         prev.nextInAEL = edge1;
/*      */       }
/* 2550 */       edge1.prevInAEL = prev;
/* 2551 */       edge1.nextInAEL = edge2;
/* 2552 */       edge2.prevInAEL = edge1;
/* 2553 */       edge2.nextInAEL = next;
/*      */     }
/*      */     else {
/* 2556 */       Edge next = edge1.nextInAEL;
/* 2557 */       Edge prev = edge1.prevInAEL;
/* 2558 */       edge1.nextInAEL = edge2.nextInAEL;
/* 2559 */       if (edge1.nextInAEL != null) {
/* 2560 */         edge1.nextInAEL.prevInAEL = edge1;
/*      */       }
/* 2562 */       edge1.prevInAEL = edge2.prevInAEL;
/* 2563 */       if (edge1.prevInAEL != null) {
/* 2564 */         edge1.prevInAEL.nextInAEL = edge1;
/*      */       }
/* 2566 */       edge2.nextInAEL = next;
/* 2567 */       if (edge2.nextInAEL != null) {
/* 2568 */         edge2.nextInAEL.prevInAEL = edge2;
/*      */       }
/* 2570 */       edge2.prevInAEL = prev;
/* 2571 */       if (edge2.prevInAEL != null) {
/* 2572 */         edge2.prevInAEL.nextInAEL = edge2;
/*      */       }
/*      */     }
/*      */     
/* 2576 */     if (edge1.prevInAEL == null) {
/* 2577 */       this.activeEdges = edge1;
/*      */     }
/* 2579 */     else if (edge2.prevInAEL == null) {
/* 2580 */       this.activeEdges = edge2;
/*      */     }
/*      */     
/* 2583 */     LOGGER.exiting(DefaultClipper.class.getName(), "swapPositionsInAEL");
/*      */   }
/*      */   
/*      */ 
/*      */   private void swapPositionsInSEL(Edge edge1, Edge edge2)
/*      */   {
/* 2589 */     if ((edge1.nextInSEL == null) && (edge1.prevInSEL == null)) {
/* 2590 */       return;
/*      */     }
/* 2592 */     if ((edge2.nextInSEL == null) && (edge2.prevInSEL == null)) {
/* 2593 */       return;
/*      */     }
/*      */     
/* 2596 */     if (edge1.nextInSEL == edge2) {
/* 2597 */       Edge next = edge2.nextInSEL;
/* 2598 */       if (next != null) {
/* 2599 */         next.prevInSEL = edge1;
/*      */       }
/* 2601 */       Edge prev = edge1.prevInSEL;
/* 2602 */       if (prev != null) {
/* 2603 */         prev.nextInSEL = edge2;
/*      */       }
/* 2605 */       edge2.prevInSEL = prev;
/* 2606 */       edge2.nextInSEL = edge1;
/* 2607 */       edge1.prevInSEL = edge2;
/* 2608 */       edge1.nextInSEL = next;
/*      */     }
/* 2610 */     else if (edge2.nextInSEL == edge1) {
/* 2611 */       Edge next = edge1.nextInSEL;
/* 2612 */       if (next != null) {
/* 2613 */         next.prevInSEL = edge2;
/*      */       }
/* 2615 */       Edge prev = edge2.prevInSEL;
/* 2616 */       if (prev != null) {
/* 2617 */         prev.nextInSEL = edge1;
/*      */       }
/* 2619 */       edge1.prevInSEL = prev;
/* 2620 */       edge1.nextInSEL = edge2;
/* 2621 */       edge2.prevInSEL = edge1;
/* 2622 */       edge2.nextInSEL = next;
/*      */     }
/*      */     else {
/* 2625 */       Edge next = edge1.nextInSEL;
/* 2626 */       Edge prev = edge1.prevInSEL;
/* 2627 */       edge1.nextInSEL = edge2.nextInSEL;
/* 2628 */       if (edge1.nextInSEL != null) {
/* 2629 */         edge1.nextInSEL.prevInSEL = edge1;
/*      */       }
/* 2631 */       edge1.prevInSEL = edge2.prevInSEL;
/* 2632 */       if (edge1.prevInSEL != null) {
/* 2633 */         edge1.prevInSEL.nextInSEL = edge1;
/*      */       }
/* 2635 */       edge2.nextInSEL = next;
/* 2636 */       if (edge2.nextInSEL != null) {
/* 2637 */         edge2.nextInSEL.prevInSEL = edge2;
/*      */       }
/* 2639 */       edge2.prevInSEL = prev;
/* 2640 */       if (edge2.prevInSEL != null) {
/* 2641 */         edge2.prevInSEL.nextInSEL = edge2;
/*      */       }
/*      */     }
/*      */     
/* 2645 */     if (edge1.prevInSEL == null) {
/* 2646 */       this.sortedEdges = edge1;
/*      */     }
/* 2648 */     else if (edge2.prevInSEL == null) {
/* 2649 */       this.sortedEdges = edge2;
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateEdgeIntoAEL(Edge[] eV) {
/* 2654 */     Edge e = eV[0];
/* 2655 */     if (e.nextInLML == null) {
/* 2656 */       throw new IllegalStateException("UpdateEdgeIntoAEL: invalid call");
/*      */     }
/* 2658 */     Edge AelPrev = e.prevInAEL;
/* 2659 */     Edge AelNext = e.nextInAEL;
/* 2660 */     e.nextInLML.outIdx = e.outIdx;
/* 2661 */     if (AelPrev != null) {
/* 2662 */       AelPrev.nextInAEL = e.nextInLML;
/*      */     }
/*      */     else {
/* 2665 */       this.activeEdges = e.nextInLML;
/*      */     }
/* 2667 */     if (AelNext != null) {
/* 2668 */       AelNext.prevInAEL = e.nextInLML;
/*      */     }
/* 2670 */     e.nextInLML.side = e.side;
/* 2671 */     e.nextInLML.windDelta = e.windDelta;
/* 2672 */     e.nextInLML.windCnt = e.windCnt;
/* 2673 */     e.nextInLML.windCnt2 = e.windCnt2;
/* 2674 */     eV[0] = (e = e.nextInLML);
/* 2675 */     e.setCurrent(e.getBot());
/* 2676 */     e.prevInAEL = AelPrev;
/* 2677 */     e.nextInAEL = AelNext;
/* 2678 */     if (!e.isHorizontal()) {
/* 2679 */       insertScanbeam(e.getTop().getY());
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateOutPtIdxs(Path.OutRec outrec) {
/* 2684 */     Path.OutPt op = outrec.getPoints();
/*      */     do {
/* 2686 */       op.idx = outrec.Idx;
/* 2687 */       op = op.prev;
/*      */     }
/* 2689 */     while (op != outrec.getPoints());
/*      */   }
/*      */   
/*      */   private void updateWindingCount(Edge edge) {
/* 2693 */     LOGGER.entering(DefaultClipper.class.getName(), "updateWindingCount");
/*      */     
/* 2695 */     Edge e = edge.prevInAEL;
/*      */     
/* 2697 */     while ((e != null) && ((e.polyTyp != edge.polyTyp) || (e.windDelta == 0))) {
/* 2698 */       e = e.prevInAEL;
/*      */     }
/* 2700 */     if (e == null) {
/* 2701 */       edge.windCnt = (edge.windDelta == 0 ? 1 : edge.windDelta);
/* 2702 */       edge.windCnt2 = 0;
/* 2703 */       e = this.activeEdges;
/*      */     }
/* 2705 */     else if ((edge.windDelta == 0) && (this.clipType != Clipper.ClipType.UNION)) {
/* 2706 */       edge.windCnt = 1;
/* 2707 */       edge.windCnt2 = e.windCnt2;
/* 2708 */       e = e.nextInAEL;
/*      */     }
/* 2710 */     else if (edge.isEvenOddFillType(this.clipFillType, this.subjFillType))
/*      */     {
/* 2712 */       if (edge.windDelta == 0)
/*      */       {
/* 2714 */         boolean Inside = true;
/* 2715 */         Edge e2 = e.prevInAEL;
/* 2716 */         while (e2 != null) {
/* 2717 */           if ((e2.polyTyp == e.polyTyp) && (e2.windDelta != 0)) {
/* 2718 */             Inside = !Inside;
/*      */           }
/* 2720 */           e2 = e2.prevInAEL;
/*      */         }
/* 2722 */         edge.windCnt = (Inside ? 0 : 1);
/*      */       }
/*      */       else {
/* 2725 */         edge.windCnt = edge.windDelta;
/*      */       }
/* 2727 */       edge.windCnt2 = e.windCnt2;
/* 2728 */       e = e.nextInAEL;
/*      */     }
/*      */     else
/*      */     {
/* 2732 */       if (e.windCnt * e.windDelta < 0)
/*      */       {
/*      */ 
/* 2735 */         if (Math.abs(e.windCnt) > 1)
/*      */         {
/*      */ 
/* 2738 */           if (e.windDelta * edge.windDelta < 0) {
/* 2739 */             edge.windCnt = e.windCnt;
/*      */           }
/*      */           else {
/* 2742 */             e.windCnt += edge.windDelta;
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/* 2747 */           edge.windCnt = (edge.windDelta == 0 ? 1 : edge.windDelta);
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 2753 */       else if (edge.windDelta == 0) {
/* 2754 */         edge.windCnt = (e.windCnt < 0 ? e.windCnt - 1 : e.windCnt + 1);
/*      */       }
/* 2756 */       else if (e.windDelta * edge.windDelta < 0) {
/* 2757 */         edge.windCnt = e.windCnt;
/*      */       }
/*      */       else {
/* 2760 */         e.windCnt += edge.windDelta;
/*      */       }
/*      */       
/* 2763 */       edge.windCnt2 = e.windCnt2;
/* 2764 */       e = e.nextInAEL;
/*      */     }
/*      */     
/*      */ 
/* 2768 */     if (edge.isEvenOddAltFillType(this.clipFillType, this.subjFillType))
/*      */     {
/* 2770 */       while (e != edge) {
/* 2771 */         if (e.windDelta != 0) {
/* 2772 */           edge.windCnt2 = (edge.windCnt2 == 0 ? 1 : 0);
/*      */         }
/* 2774 */         e = e.nextInAEL;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2779 */     while (e != edge) {
/* 2780 */       edge.windCnt2 += e.windDelta;
/* 2781 */       e = e.nextInAEL;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/DefaultClipper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */