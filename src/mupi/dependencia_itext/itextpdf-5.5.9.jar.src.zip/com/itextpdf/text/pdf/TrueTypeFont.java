/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.Document;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class TrueTypeFont
/*      */   extends BaseFont
/*      */ {
/*   68 */   static final String[] codePages = { "1252 Latin 1", "1250 Latin 2: Eastern Europe", "1251 Cyrillic", "1253 Greek", "1254 Turkish", "1255 Hebrew", "1256 Arabic", "1257 Windows Baltic", "1258 Vietnamese", null, null, null, null, null, null, null, "874 Thai", "932 JIS/Japan", "936 Chinese: Simplified chars--PRC and Singapore", "949 Korean Wansung", "950 Chinese: Traditional chars--Taiwan and Hong Kong", "1361 Korean Johab", null, null, null, null, null, null, null, "Macintosh Character Set (US Roman)", "OEM Character Set", "Symbol Character Set", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "869 IBM Greek", "866 MS-DOS Russian", "865 MS-DOS Nordic", "864 Arabic", "863 MS-DOS Canadian French", "862 Hebrew", "861 MS-DOS Icelandic", "860 MS-DOS Portuguese", "857 IBM Turkish", "855 IBM Cyrillic; primarily Russian", "852 Latin 2", "775 MS-DOS Baltic", "737 Greek; former 437 G", "708 Arabic; ASMO 708", "850 WE/Latin 1", "437 US" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  134 */   protected boolean justNames = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HashMap<String, int[]> tables;
/*      */   
/*      */ 
/*      */ 
/*      */   protected RandomAccessFileOrArray rf;
/*      */   
/*      */ 
/*      */ 
/*      */   protected String fileName;
/*      */   
/*      */ 
/*      */ 
/*  151 */   protected boolean cff = false;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int cffOffset;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int cffLength;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int directoryOffset;
/*      */   
/*      */ 
/*      */ 
/*      */   protected String ttcIndex;
/*      */   
/*      */ 
/*  170 */   protected String style = "";
/*      */   
/*      */ 
/*      */ 
/*  174 */   protected FontHeader head = new FontHeader();
/*      */   
/*      */ 
/*      */ 
/*  178 */   protected HorizontalHeader hhea = new HorizontalHeader();
/*      */   
/*      */ 
/*      */ 
/*  182 */   protected WindowsMetrics os_2 = new WindowsMetrics();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int[] glyphWidthsByIndex;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int[][] bboxes;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HashMap<Integer, int[]> cmap10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HashMap<Integer, int[]> cmap31;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HashMap<Integer, int[]> cmapExt;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int[] glyphIdToChar;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int maxGlyphId;
/*      */   
/*      */ 
/*      */ 
/*  220 */   protected IntHashtable kerning = new IntHashtable();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String fontName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[][] subFamily;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[][] fullName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[][] allNameEntries;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[][] familyName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double italicAngle;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  262 */   protected boolean isFixedPitch = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int underlinePosition;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int underlineThickness;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected TrueTypeFont() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class WindowsMetrics
/*      */   {
/*      */     short xAvgCharWidth;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int usWeightClass;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int usWidthClass;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short fsType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySubscriptXSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySubscriptYSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySubscriptXOffset;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySubscriptYOffset;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySuperscriptXSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySuperscriptYSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySuperscriptXOffset;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short ySuperscriptYOffset;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short yStrikeoutSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short yStrikeoutPosition;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     short sFamilyClass;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */     byte[] panose = new byte[10];
/*      */     
/*      */ 
/*      */ 
/*  419 */     byte[] achVendID = new byte[4];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int fsSelection;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int usFirstCharIndex;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int usLastCharIndex;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     short sTypoAscender;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     short sTypoDescender;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     short sTypoLineGap;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int usWinAscent;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int usWinDescent;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int ulCodePageRange1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int ulCodePageRange2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int sCapHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   TrueTypeFont(String ttFile, String enc, boolean emb, byte[] ttfAfm, boolean justNames, boolean forceRead)
/*      */     throws DocumentException, IOException
/*      */   {
/*  485 */     this.justNames = justNames;
/*  486 */     String nameBase = getBaseName(ttFile);
/*  487 */     String ttcName = getTTCName(nameBase);
/*  488 */     if (nameBase.length() < ttFile.length()) {
/*  489 */       this.style = ttFile.substring(nameBase.length());
/*      */     }
/*  491 */     this.encoding = enc;
/*  492 */     this.embedded = emb;
/*  493 */     this.fileName = ttcName;
/*  494 */     this.fontType = 1;
/*  495 */     this.ttcIndex = "";
/*  496 */     if (ttcName.length() < nameBase.length())
/*  497 */       this.ttcIndex = nameBase.substring(ttcName.length() + 1);
/*  498 */     if ((this.fileName.toLowerCase().endsWith(".ttf")) || (this.fileName.toLowerCase().endsWith(".otf")) || (this.fileName.toLowerCase().endsWith(".ttc"))) {
/*  499 */       process(ttfAfm, forceRead);
/*  500 */       if ((!justNames) && (this.embedded) && (this.os_2.fsType == 2))
/*  501 */         throw new DocumentException(MessageLocalization.getComposedMessage("1.cannot.be.embedded.due.to.licensing.restrictions", new Object[] { this.fileName + this.style }));
/*      */     } else {
/*  503 */       throw new DocumentException(MessageLocalization.getComposedMessage("1.is.not.a.ttf.otf.or.ttc.font.file", new Object[] { this.fileName + this.style })); }
/*  504 */     if (!this.encoding.startsWith("#"))
/*  505 */       PdfEncodings.convertToBytes(" ", enc);
/*  506 */     createEncoding();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String getTTCName(String name)
/*      */   {
/*  518 */     int idx = name.toLowerCase().indexOf(".ttc,");
/*  519 */     if (idx < 0) {
/*  520 */       return name;
/*      */     }
/*  522 */     return name.substring(0, idx + 4);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fillTables()
/*      */     throws DocumentException, IOException
/*      */   {
/*  534 */     int[] table_location = (int[])this.tables.get("head");
/*  535 */     if (table_location == null)
/*  536 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "head", this.fileName + this.style }));
/*  537 */     this.rf.seek(table_location[0] + 16);
/*  538 */     this.head.flags = this.rf.readUnsignedShort();
/*  539 */     this.head.unitsPerEm = this.rf.readUnsignedShort();
/*  540 */     this.rf.skipBytes(16);
/*  541 */     this.head.xMin = this.rf.readShort();
/*  542 */     this.head.yMin = this.rf.readShort();
/*  543 */     this.head.xMax = this.rf.readShort();
/*  544 */     this.head.yMax = this.rf.readShort();
/*  545 */     this.head.macStyle = this.rf.readUnsignedShort();
/*      */     
/*  547 */     table_location = (int[])this.tables.get("hhea");
/*  548 */     if (table_location == null)
/*  549 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "hhea", this.fileName + this.style }));
/*  550 */     this.rf.seek(table_location[0] + 4);
/*  551 */     this.hhea.Ascender = this.rf.readShort();
/*  552 */     this.hhea.Descender = this.rf.readShort();
/*  553 */     this.hhea.LineGap = this.rf.readShort();
/*  554 */     this.hhea.advanceWidthMax = this.rf.readUnsignedShort();
/*  555 */     this.hhea.minLeftSideBearing = this.rf.readShort();
/*  556 */     this.hhea.minRightSideBearing = this.rf.readShort();
/*  557 */     this.hhea.xMaxExtent = this.rf.readShort();
/*  558 */     this.hhea.caretSlopeRise = this.rf.readShort();
/*  559 */     this.hhea.caretSlopeRun = this.rf.readShort();
/*  560 */     this.rf.skipBytes(12);
/*  561 */     this.hhea.numberOfHMetrics = this.rf.readUnsignedShort();
/*      */     
/*  563 */     table_location = (int[])this.tables.get("OS/2");
/*  564 */     if (table_location != null) {
/*  565 */       this.rf.seek(table_location[0]);
/*  566 */       int version = this.rf.readUnsignedShort();
/*  567 */       this.os_2.xAvgCharWidth = this.rf.readShort();
/*  568 */       this.os_2.usWeightClass = this.rf.readUnsignedShort();
/*  569 */       this.os_2.usWidthClass = this.rf.readUnsignedShort();
/*  570 */       this.os_2.fsType = this.rf.readShort();
/*  571 */       this.os_2.ySubscriptXSize = this.rf.readShort();
/*  572 */       this.os_2.ySubscriptYSize = this.rf.readShort();
/*  573 */       this.os_2.ySubscriptXOffset = this.rf.readShort();
/*  574 */       this.os_2.ySubscriptYOffset = this.rf.readShort();
/*  575 */       this.os_2.ySuperscriptXSize = this.rf.readShort();
/*  576 */       this.os_2.ySuperscriptYSize = this.rf.readShort();
/*  577 */       this.os_2.ySuperscriptXOffset = this.rf.readShort();
/*  578 */       this.os_2.ySuperscriptYOffset = this.rf.readShort();
/*  579 */       this.os_2.yStrikeoutSize = this.rf.readShort();
/*  580 */       this.os_2.yStrikeoutPosition = this.rf.readShort();
/*  581 */       this.os_2.sFamilyClass = this.rf.readShort();
/*  582 */       this.rf.readFully(this.os_2.panose);
/*  583 */       this.rf.skipBytes(16);
/*  584 */       this.rf.readFully(this.os_2.achVendID);
/*  585 */       this.os_2.fsSelection = this.rf.readUnsignedShort();
/*  586 */       this.os_2.usFirstCharIndex = this.rf.readUnsignedShort();
/*  587 */       this.os_2.usLastCharIndex = this.rf.readUnsignedShort();
/*  588 */       this.os_2.sTypoAscender = this.rf.readShort();
/*  589 */       this.os_2.sTypoDescender = this.rf.readShort();
/*  590 */       if (this.os_2.sTypoDescender > 0)
/*  591 */         this.os_2.sTypoDescender = ((short)-this.os_2.sTypoDescender);
/*  592 */       this.os_2.sTypoLineGap = this.rf.readShort();
/*  593 */       this.os_2.usWinAscent = this.rf.readUnsignedShort();
/*  594 */       this.os_2.usWinDescent = this.rf.readUnsignedShort();
/*  595 */       this.os_2.ulCodePageRange1 = 0;
/*  596 */       this.os_2.ulCodePageRange2 = 0;
/*  597 */       if (version > 0) {
/*  598 */         this.os_2.ulCodePageRange1 = this.rf.readInt();
/*  599 */         this.os_2.ulCodePageRange2 = this.rf.readInt();
/*      */       }
/*  601 */       if (version > 1) {
/*  602 */         this.rf.skipBytes(2);
/*  603 */         this.os_2.sCapHeight = this.rf.readShort();
/*      */       } else {
/*  605 */         this.os_2.sCapHeight = ((int)(0.7D * this.head.unitsPerEm));
/*  606 */       } } else if ((this.tables.get("hhea") != null) && (this.tables.get("head") != null))
/*      */     {
/*  608 */       if (this.head.macStyle == 0) {
/*  609 */         this.os_2.usWeightClass = 700;
/*  610 */         this.os_2.usWidthClass = 5;
/*  611 */       } else if (this.head.macStyle == 5) {
/*  612 */         this.os_2.usWeightClass = 400;
/*  613 */         this.os_2.usWidthClass = 3;
/*  614 */       } else if (this.head.macStyle == 6) {
/*  615 */         this.os_2.usWeightClass = 400;
/*  616 */         this.os_2.usWidthClass = 7;
/*      */       } else {
/*  618 */         this.os_2.usWeightClass = 400;
/*  619 */         this.os_2.usWidthClass = 5;
/*      */       }
/*  621 */       this.os_2.fsType = 0;
/*      */       
/*  623 */       this.os_2.ySubscriptYSize = 0;
/*  624 */       this.os_2.ySubscriptYOffset = 0;
/*  625 */       this.os_2.ySuperscriptYSize = 0;
/*  626 */       this.os_2.ySuperscriptYOffset = 0;
/*  627 */       this.os_2.yStrikeoutSize = 0;
/*  628 */       this.os_2.yStrikeoutPosition = 0;
/*  629 */       this.os_2.sTypoAscender = ((short)(int)(this.hhea.Ascender - 0.21D * this.hhea.Ascender));
/*  630 */       this.os_2.sTypoDescender = ((short)(int)-(Math.abs(this.hhea.Descender) - Math.abs(this.hhea.Descender) * 0.07D));
/*  631 */       this.os_2.sTypoLineGap = ((short)(this.hhea.LineGap * 2));
/*  632 */       this.os_2.usWinAscent = this.hhea.Ascender;
/*  633 */       this.os_2.usWinDescent = this.hhea.Descender;
/*  634 */       this.os_2.ulCodePageRange1 = 0;
/*  635 */       this.os_2.ulCodePageRange2 = 0;
/*  636 */       this.os_2.sCapHeight = ((int)(0.7D * this.head.unitsPerEm));
/*      */     }
/*      */     
/*  639 */     table_location = (int[])this.tables.get("post");
/*  640 */     if (table_location == null) {
/*  641 */       this.italicAngle = (-Math.atan2(this.hhea.caretSlopeRun, this.hhea.caretSlopeRise) * 180.0D / 3.141592653589793D);
/*      */     } else {
/*  643 */       this.rf.seek(table_location[0] + 4);
/*  644 */       short mantissa = this.rf.readShort();
/*  645 */       int fraction = this.rf.readUnsignedShort();
/*  646 */       this.italicAngle = (mantissa + fraction / 16384.0D);
/*  647 */       this.underlinePosition = this.rf.readShort();
/*  648 */       this.underlineThickness = this.rf.readShort();
/*  649 */       this.isFixedPitch = (this.rf.readInt() != 0);
/*      */     }
/*      */     
/*  652 */     table_location = (int[])this.tables.get("maxp");
/*  653 */     if (table_location == null) {
/*  654 */       this.maxGlyphId = 65536;
/*      */     } else {
/*  656 */       this.rf.seek(table_location[0] + 4);
/*  657 */       this.maxGlyphId = this.rf.readUnsignedShort();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getBaseFont()
/*      */     throws DocumentException, IOException
/*      */   {
/*  670 */     int[] table_location = (int[])this.tables.get("name");
/*  671 */     if (table_location == null)
/*  672 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "name", this.fileName + this.style }));
/*  673 */     this.rf.seek(table_location[0] + 2);
/*  674 */     int numRecords = this.rf.readUnsignedShort();
/*  675 */     int startOfStorage = this.rf.readUnsignedShort();
/*  676 */     for (int k = 0; k < numRecords; k++) {
/*  677 */       int platformID = this.rf.readUnsignedShort();
/*  678 */       int platformEncodingID = this.rf.readUnsignedShort();
/*  679 */       int languageID = this.rf.readUnsignedShort();
/*  680 */       int nameID = this.rf.readUnsignedShort();
/*  681 */       int length = this.rf.readUnsignedShort();
/*  682 */       int offset = this.rf.readUnsignedShort();
/*  683 */       if (nameID == 6) {
/*  684 */         this.rf.seek(table_location[0] + startOfStorage + offset);
/*  685 */         if ((platformID == 0) || (platformID == 3)) {
/*  686 */           return readUnicodeString(length);
/*      */         }
/*  688 */         return readStandardString(length);
/*      */       }
/*      */     }
/*  691 */     File file = new File(this.fileName);
/*  692 */     return file.getName().replace(' ', '-');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String[][] getNames(int id)
/*      */     throws DocumentException, IOException
/*      */   {
/*  704 */     int[] table_location = (int[])this.tables.get("name");
/*  705 */     if (table_location == null)
/*  706 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "name", this.fileName + this.style }));
/*  707 */     this.rf.seek(table_location[0] + 2);
/*  708 */     int numRecords = this.rf.readUnsignedShort();
/*  709 */     int startOfStorage = this.rf.readUnsignedShort();
/*  710 */     ArrayList<String[]> names = new ArrayList();
/*  711 */     for (int k = 0; k < numRecords; k++) {
/*  712 */       int platformID = this.rf.readUnsignedShort();
/*  713 */       int platformEncodingID = this.rf.readUnsignedShort();
/*  714 */       int languageID = this.rf.readUnsignedShort();
/*  715 */       int nameID = this.rf.readUnsignedShort();
/*  716 */       int length = this.rf.readUnsignedShort();
/*  717 */       int offset = this.rf.readUnsignedShort();
/*  718 */       if (nameID == id) {
/*  719 */         int pos = (int)this.rf.getFilePointer();
/*  720 */         this.rf.seek(table_location[0] + startOfStorage + offset);
/*      */         String name;
/*  722 */         String name; if ((platformID == 0) || (platformID == 3) || ((platformID == 2) && (platformEncodingID == 1))) {
/*  723 */           name = readUnicodeString(length);
/*      */         } else {
/*  725 */           name = readStandardString(length);
/*      */         }
/*  727 */         names.add(new String[] { String.valueOf(platformID), 
/*  728 */           String.valueOf(platformEncodingID), String.valueOf(languageID), name });
/*  729 */         this.rf.seek(pos);
/*      */       }
/*      */     }
/*  732 */     String[][] thisName = new String[names.size()][];
/*  733 */     for (int k = 0; k < names.size(); k++)
/*  734 */       thisName[k] = ((String[])names.get(k));
/*  735 */     return thisName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String[][] getAllNames()
/*      */     throws DocumentException, IOException
/*      */   {
/*  746 */     int[] table_location = (int[])this.tables.get("name");
/*  747 */     if (table_location == null)
/*  748 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "name", this.fileName + this.style }));
/*  749 */     this.rf.seek(table_location[0] + 2);
/*  750 */     int numRecords = this.rf.readUnsignedShort();
/*  751 */     int startOfStorage = this.rf.readUnsignedShort();
/*  752 */     ArrayList<String[]> names = new ArrayList();
/*  753 */     for (int k = 0; k < numRecords; k++) {
/*  754 */       int platformID = this.rf.readUnsignedShort();
/*  755 */       int platformEncodingID = this.rf.readUnsignedShort();
/*  756 */       int languageID = this.rf.readUnsignedShort();
/*  757 */       int nameID = this.rf.readUnsignedShort();
/*  758 */       int length = this.rf.readUnsignedShort();
/*  759 */       int offset = this.rf.readUnsignedShort();
/*  760 */       int pos = (int)this.rf.getFilePointer();
/*  761 */       this.rf.seek(table_location[0] + startOfStorage + offset);
/*      */       String name;
/*  763 */       String name; if ((platformID == 0) || (platformID == 3) || ((platformID == 2) && (platformEncodingID == 1))) {
/*  764 */         name = readUnicodeString(length);
/*      */       } else {
/*  766 */         name = readStandardString(length);
/*      */       }
/*  768 */       names.add(new String[] { String.valueOf(nameID), String.valueOf(platformID), 
/*  769 */         String.valueOf(platformEncodingID), String.valueOf(languageID), name });
/*  770 */       this.rf.seek(pos);
/*      */     }
/*  772 */     String[][] thisName = new String[names.size()][];
/*  773 */     for (int k = 0; k < names.size(); k++)
/*  774 */       thisName[k] = ((String[])names.get(k));
/*  775 */     return thisName;
/*      */   }
/*      */   
/*      */   void checkCff()
/*      */   {
/*  780 */     int[] table_location = (int[])this.tables.get("CFF ");
/*  781 */     if (table_location != null) {
/*  782 */       this.cff = true;
/*  783 */       this.cffOffset = table_location[0];
/*  784 */       this.cffLength = table_location[1];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void process(byte[] ttfAfm, boolean preload)
/*      */     throws DocumentException, IOException
/*      */   {
/*  797 */     this.tables = new HashMap();
/*      */     
/*  799 */     if (ttfAfm == null) {
/*  800 */       this.rf = new RandomAccessFileOrArray(this.fileName, preload, Document.plainRandomAccess);
/*      */     } else {
/*  802 */       this.rf = new RandomAccessFileOrArray(ttfAfm);
/*      */     }
/*      */     try {
/*  805 */       if (this.ttcIndex.length() > 0) {
/*  806 */         int dirIdx = Integer.parseInt(this.ttcIndex);
/*  807 */         if (dirIdx < 0)
/*  808 */           throw new DocumentException(MessageLocalization.getComposedMessage("the.font.index.for.1.must.be.positive", new Object[] { this.fileName }));
/*  809 */         String mainTag = readStandardString(4);
/*  810 */         if (!mainTag.equals("ttcf"))
/*  811 */           throw new DocumentException(MessageLocalization.getComposedMessage("1.is.not.a.valid.ttc.file", new Object[] { this.fileName }));
/*  812 */         this.rf.skipBytes(4);
/*  813 */         int dirCount = this.rf.readInt();
/*  814 */         if (dirIdx >= dirCount)
/*  815 */           throw new DocumentException(MessageLocalization.getComposedMessage("the.font.index.for.1.must.be.between.0.and.2.it.was.3", new Object[] { this.fileName, String.valueOf(dirCount - 1), String.valueOf(dirIdx) }));
/*  816 */         this.rf.skipBytes(dirIdx * 4);
/*  817 */         this.directoryOffset = this.rf.readInt();
/*      */       }
/*  819 */       this.rf.seek(this.directoryOffset);
/*  820 */       int ttId = this.rf.readInt();
/*  821 */       if ((ttId != 65536) && (ttId != 1330926671))
/*  822 */         throw new DocumentException(MessageLocalization.getComposedMessage("1.is.not.a.valid.ttf.or.otf.file", new Object[] { this.fileName }));
/*  823 */       int num_tables = this.rf.readUnsignedShort();
/*  824 */       this.rf.skipBytes(6);
/*  825 */       for (int k = 0; k < num_tables; k++) {
/*  826 */         String tag = readStandardString(4);
/*  827 */         this.rf.skipBytes(4);
/*  828 */         int[] table_location = new int[2];
/*  829 */         table_location[0] = this.rf.readInt();
/*  830 */         table_location[1] = this.rf.readInt();
/*  831 */         this.tables.put(tag, table_location);
/*      */       }
/*  833 */       checkCff();
/*  834 */       this.fontName = getBaseFont();
/*  835 */       this.fullName = getNames(4);
/*      */       
/*  837 */       String[][] otfFamilyName = getNames(16);
/*  838 */       if (otfFamilyName.length > 0) {
/*  839 */         this.familyName = otfFamilyName;
/*      */       } else {
/*  841 */         this.familyName = getNames(1);
/*      */       }
/*  843 */       String[][] otfSubFamily = getNames(17);
/*  844 */       if (otfFamilyName.length > 0) {
/*  845 */         this.subFamily = otfSubFamily;
/*      */       } else {
/*  847 */         this.subFamily = getNames(2);
/*      */       }
/*  849 */       this.allNameEntries = getAllNames();
/*  850 */       if (!this.justNames) {
/*  851 */         fillTables();
/*  852 */         readGlyphWidths();
/*  853 */         readCMaps();
/*  854 */         readKerning();
/*  855 */         readBbox();
/*      */       }
/*      */     }
/*      */     finally {
/*  859 */       if (!this.embedded) {
/*  860 */         this.rf.close();
/*  861 */         this.rf = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String readStandardString(int length)
/*      */     throws IOException
/*      */   {
/*  875 */     return this.rf.readString(length, "Cp1252");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String readUnicodeString(int length)
/*      */     throws IOException
/*      */   {
/*  888 */     StringBuffer buf = new StringBuffer();
/*  889 */     length /= 2;
/*  890 */     for (int k = 0; k < length; k++) {
/*  891 */       buf.append(this.rf.readChar());
/*      */     }
/*  893 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readGlyphWidths()
/*      */     throws DocumentException, IOException
/*      */   {
/*  905 */     int[] table_location = (int[])this.tables.get("hmtx");
/*  906 */     if (table_location == null)
/*  907 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "hmtx", this.fileName + this.style }));
/*  908 */     this.rf.seek(table_location[0]);
/*  909 */     this.glyphWidthsByIndex = new int[this.hhea.numberOfHMetrics];
/*  910 */     for (int k = 0; k < this.hhea.numberOfHMetrics; k++) {
/*  911 */       this.glyphWidthsByIndex[k] = (this.rf.readUnsignedShort() * 1000 / this.head.unitsPerEm);
/*      */       
/*  913 */       int i = this.rf.readShort() * 1000 / this.head.unitsPerEm;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getGlyphWidth(int glyph)
/*      */   {
/*  924 */     if (glyph >= this.glyphWidthsByIndex.length)
/*  925 */       glyph = this.glyphWidthsByIndex.length - 1;
/*  926 */     return this.glyphWidthsByIndex[glyph];
/*      */   }
/*      */   
/*      */   private void readBbox() throws DocumentException, IOException
/*      */   {
/*  931 */     int[] tableLocation = (int[])this.tables.get("head");
/*  932 */     if (tableLocation == null)
/*  933 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "head", this.fileName + this.style }));
/*  934 */     this.rf.seek(tableLocation[0] + 51);
/*  935 */     boolean locaShortTable = this.rf.readUnsignedShort() == 0;
/*  936 */     tableLocation = (int[])this.tables.get("loca");
/*  937 */     if (tableLocation == null)
/*  938 */       return;
/*  939 */     this.rf.seek(tableLocation[0]);
/*      */     int[] locaTable;
/*  941 */     if (locaShortTable) {
/*  942 */       int entries = tableLocation[1] / 2;
/*  943 */       int[] locaTable = new int[entries];
/*  944 */       for (int k = 0; k < entries; k++)
/*  945 */         locaTable[k] = (this.rf.readUnsignedShort() * 2);
/*      */     } else {
/*  947 */       int entries = tableLocation[1] / 4;
/*  948 */       locaTable = new int[entries];
/*  949 */       for (int k = 0; k < entries; k++)
/*  950 */         locaTable[k] = this.rf.readInt();
/*      */     }
/*  952 */     tableLocation = (int[])this.tables.get("glyf");
/*  953 */     if (tableLocation == null)
/*  954 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "glyf", this.fileName + this.style }));
/*  955 */     int tableGlyphOffset = tableLocation[0];
/*  956 */     this.bboxes = new int[locaTable.length - 1][];
/*  957 */     for (int glyph = 0; glyph < locaTable.length - 1; glyph++) {
/*  958 */       int start = locaTable[glyph];
/*  959 */       if (start != locaTable[(glyph + 1)]) {
/*  960 */         this.rf.seek(tableGlyphOffset + start + 2);
/*  961 */         this.bboxes[glyph] = {this.rf
/*  962 */           .readShort() * 1000 / this.head.unitsPerEm, this.rf
/*  963 */           .readShort() * 1000 / this.head.unitsPerEm, this.rf
/*  964 */           .readShort() * 1000 / this.head.unitsPerEm, this.rf
/*  965 */           .readShort() * 1000 / this.head.unitsPerEm };
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readCMaps()
/*      */     throws DocumentException, IOException
/*      */   {
/*  979 */     int[] table_location = (int[])this.tables.get("cmap");
/*  980 */     if (table_location == null)
/*  981 */       throw new DocumentException(MessageLocalization.getComposedMessage("table.1.does.not.exist.in.2", new Object[] { "cmap", this.fileName + this.style }));
/*  982 */     this.rf.seek(table_location[0]);
/*  983 */     this.rf.skipBytes(2);
/*  984 */     int num_tables = this.rf.readUnsignedShort();
/*  985 */     this.fontSpecific = false;
/*  986 */     int map10 = 0;
/*  987 */     int map31 = 0;
/*  988 */     int map30 = 0;
/*  989 */     int mapExt = 0;
/*  990 */     for (int k = 0; k < num_tables; k++) {
/*  991 */       int platId = this.rf.readUnsignedShort();
/*  992 */       int platSpecId = this.rf.readUnsignedShort();
/*  993 */       int offset = this.rf.readInt();
/*  994 */       if ((platId == 3) && (platSpecId == 0)) {
/*  995 */         this.fontSpecific = true;
/*  996 */         map30 = offset;
/*  997 */       } else if ((platId == 3) && (platSpecId == 1)) {
/*  998 */         map31 = offset;
/*  999 */       } else if ((platId == 3) && (platSpecId == 10)) {
/* 1000 */         mapExt = offset;
/*      */       }
/* 1002 */       if ((platId == 1) && (platSpecId == 0)) {
/* 1003 */         map10 = offset;
/*      */       }
/*      */     }
/* 1006 */     if (map10 > 0) {
/* 1007 */       this.rf.seek(table_location[0] + map10);
/* 1008 */       int format = this.rf.readUnsignedShort();
/* 1009 */       switch (format) {
/*      */       case 0: 
/* 1011 */         this.cmap10 = readFormat0();
/* 1012 */         break;
/*      */       case 4: 
/* 1014 */         this.cmap10 = readFormat4();
/* 1015 */         break;
/*      */       case 6: 
/* 1017 */         this.cmap10 = readFormat6();
/*      */       }
/*      */       
/*      */     }
/* 1021 */     if (map31 > 0) {
/* 1022 */       this.rf.seek(table_location[0] + map31);
/* 1023 */       int format = this.rf.readUnsignedShort();
/* 1024 */       if (format == 4) {
/* 1025 */         this.cmap31 = readFormat4();
/*      */       }
/*      */     }
/* 1028 */     if (map30 > 0) {
/* 1029 */       this.rf.seek(table_location[0] + map30);
/* 1030 */       int format = this.rf.readUnsignedShort();
/* 1031 */       if (format == 4) {
/* 1032 */         this.cmap10 = readFormat4();
/*      */       }
/*      */     }
/* 1035 */     if (mapExt > 0) {
/* 1036 */       this.rf.seek(table_location[0] + mapExt);
/* 1037 */       int format = this.rf.readUnsignedShort();
/* 1038 */       switch (format) {
/*      */       case 0: 
/* 1040 */         this.cmapExt = readFormat0();
/* 1041 */         break;
/*      */       case 4: 
/* 1043 */         this.cmapExt = readFormat4();
/* 1044 */         break;
/*      */       case 6: 
/* 1046 */         this.cmapExt = readFormat6();
/* 1047 */         break;
/*      */       case 12: 
/* 1049 */         this.cmapExt = readFormat12();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   HashMap<Integer, int[]> readFormat12() throws IOException
/*      */   {
/* 1056 */     HashMap<Integer, int[]> h = new HashMap();
/* 1057 */     this.rf.skipBytes(2);
/* 1058 */     int table_lenght = this.rf.readInt();
/* 1059 */     this.rf.skipBytes(4);
/* 1060 */     int nGroups = this.rf.readInt();
/* 1061 */     for (int k = 0; k < nGroups; k++) {
/* 1062 */       int startCharCode = this.rf.readInt();
/* 1063 */       int endCharCode = this.rf.readInt();
/* 1064 */       int startGlyphID = this.rf.readInt();
/* 1065 */       for (int i = startCharCode; i <= endCharCode; i++) {
/* 1066 */         int[] r = new int[2];
/* 1067 */         r[0] = startGlyphID;
/* 1068 */         r[1] = getGlyphWidth(r[0]);
/* 1069 */         h.put(Integer.valueOf(i), r);
/* 1070 */         startGlyphID++;
/*      */       }
/*      */     }
/* 1073 */     return h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap<Integer, int[]> readFormat0()
/*      */     throws IOException
/*      */   {
/* 1084 */     HashMap<Integer, int[]> h = new HashMap();
/* 1085 */     this.rf.skipBytes(4);
/* 1086 */     for (int k = 0; k < 256; k++) {
/* 1087 */       int[] r = new int[2];
/* 1088 */       r[0] = this.rf.readUnsignedByte();
/* 1089 */       r[1] = getGlyphWidth(r[0]);
/* 1090 */       h.put(Integer.valueOf(k), r);
/*      */     }
/* 1092 */     return h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap<Integer, int[]> readFormat4()
/*      */     throws IOException
/*      */   {
/* 1103 */     HashMap<Integer, int[]> h = new HashMap();
/* 1104 */     int table_lenght = this.rf.readUnsignedShort();
/* 1105 */     this.rf.skipBytes(2);
/* 1106 */     int segCount = this.rf.readUnsignedShort() / 2;
/* 1107 */     this.rf.skipBytes(6);
/* 1108 */     int[] endCount = new int[segCount];
/* 1109 */     for (int k = 0; k < segCount; k++) {
/* 1110 */       endCount[k] = this.rf.readUnsignedShort();
/*      */     }
/* 1112 */     this.rf.skipBytes(2);
/* 1113 */     int[] startCount = new int[segCount];
/* 1114 */     for (int k = 0; k < segCount; k++) {
/* 1115 */       startCount[k] = this.rf.readUnsignedShort();
/*      */     }
/* 1117 */     int[] idDelta = new int[segCount];
/* 1118 */     for (int k = 0; k < segCount; k++) {
/* 1119 */       idDelta[k] = this.rf.readUnsignedShort();
/*      */     }
/* 1121 */     int[] idRO = new int[segCount];
/* 1122 */     for (int k = 0; k < segCount; k++) {
/* 1123 */       idRO[k] = this.rf.readUnsignedShort();
/*      */     }
/* 1125 */     int[] glyphId = new int[table_lenght / 2 - 8 - segCount * 4];
/* 1126 */     for (int k = 0; k < glyphId.length; k++) {
/* 1127 */       glyphId[k] = this.rf.readUnsignedShort();
/*      */     }
/* 1129 */     for (int k = 0; k < segCount; k++)
/*      */     {
/* 1131 */       for (int j = startCount[k]; (j <= endCount[k]) && (j != 65535); j++) { int glyph;
/* 1132 */         int glyph; if (idRO[k] == 0) {
/* 1133 */           glyph = j + idDelta[k] & 0xFFFF;
/*      */         } else {
/* 1135 */           int idx = k + idRO[k] / 2 - segCount + j - startCount[k];
/* 1136 */           if (idx >= glyphId.length)
/*      */             continue;
/* 1138 */           glyph = glyphId[idx] + idDelta[k] & 0xFFFF;
/*      */         }
/* 1140 */         int[] r = new int[2];
/* 1141 */         r[0] = glyph;
/* 1142 */         r[1] = getGlyphWidth(r[0]);
/* 1143 */         h.put(Integer.valueOf(this.fontSpecific ? j : (j & 0xFF00) == 61440 ? j & 0xFF : j), r);
/*      */       }
/*      */     }
/* 1146 */     return h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   HashMap<Integer, int[]> readFormat6()
/*      */     throws IOException
/*      */   {
/* 1158 */     HashMap<Integer, int[]> h = new HashMap();
/* 1159 */     this.rf.skipBytes(4);
/* 1160 */     int start_code = this.rf.readUnsignedShort();
/* 1161 */     int code_count = this.rf.readUnsignedShort();
/* 1162 */     for (int k = 0; k < code_count; k++) {
/* 1163 */       int[] r = new int[2];
/* 1164 */       r[0] = this.rf.readUnsignedShort();
/* 1165 */       r[1] = getGlyphWidth(r[0]);
/* 1166 */       h.put(Integer.valueOf(k + start_code), r);
/*      */     }
/* 1168 */     return h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readKerning()
/*      */     throws IOException
/*      */   {
/* 1178 */     int[] table_location = (int[])this.tables.get("kern");
/* 1179 */     if (table_location == null)
/* 1180 */       return;
/* 1181 */     this.rf.seek(table_location[0] + 2);
/* 1182 */     int nTables = this.rf.readUnsignedShort();
/* 1183 */     int checkpoint = table_location[0] + 4;
/* 1184 */     int length = 0;
/* 1185 */     for (int k = 0; k < nTables; k++) {
/* 1186 */       checkpoint += length;
/* 1187 */       this.rf.seek(checkpoint);
/* 1188 */       this.rf.skipBytes(2);
/* 1189 */       length = this.rf.readUnsignedShort();
/* 1190 */       int coverage = this.rf.readUnsignedShort();
/* 1191 */       if ((coverage & 0xFFF7) == 1) {
/* 1192 */         int nPairs = this.rf.readUnsignedShort();
/* 1193 */         this.rf.skipBytes(6);
/* 1194 */         for (int j = 0; j < nPairs; j++) {
/* 1195 */           int pair = this.rf.readInt();
/* 1196 */           int value = this.rf.readShort() * 1000 / this.head.unitsPerEm;
/* 1197 */           this.kerning.put(pair, value);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getKerning(int char1, int char2)
/*      */   {
/* 1212 */     int[] metrics = getMetricsTT(char1);
/* 1213 */     if (metrics == null)
/* 1214 */       return 0;
/* 1215 */     int c1 = metrics[0];
/* 1216 */     metrics = getMetricsTT(char2);
/* 1217 */     if (metrics == null)
/* 1218 */       return 0;
/* 1219 */     int c2 = metrics[0];
/* 1220 */     return this.kerning.get((c1 << 16) + c2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getRawWidth(int c, String name)
/*      */   {
/* 1233 */     int[] metric = getMetricsTT(c);
/* 1234 */     if (metric == null)
/* 1235 */       return 0;
/* 1236 */     return metric[1];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary getFontDescriptor(PdfIndirectReference fontStream, String subsetPrefix, PdfIndirectReference cidset)
/*      */   {
/* 1247 */     PdfDictionary dic = new PdfDictionary(PdfName.FONTDESCRIPTOR);
/* 1248 */     dic.put(PdfName.ASCENT, new PdfNumber(this.os_2.sTypoAscender * 1000 / this.head.unitsPerEm));
/* 1249 */     dic.put(PdfName.CAPHEIGHT, new PdfNumber(this.os_2.sCapHeight * 1000 / this.head.unitsPerEm));
/* 1250 */     dic.put(PdfName.DESCENT, new PdfNumber(this.os_2.sTypoDescender * 1000 / this.head.unitsPerEm));
/* 1251 */     dic.put(PdfName.FONTBBOX, new PdfRectangle(this.head.xMin * 1000 / this.head.unitsPerEm, this.head.yMin * 1000 / this.head.unitsPerEm, this.head.xMax * 1000 / this.head.unitsPerEm, this.head.yMax * 1000 / this.head.unitsPerEm));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1256 */     if (cidset != null)
/* 1257 */       dic.put(PdfName.CIDSET, cidset);
/* 1258 */     if (this.cff) {
/* 1259 */       if (this.encoding.startsWith("Identity-")) {
/* 1260 */         dic.put(PdfName.FONTNAME, new PdfName(subsetPrefix + this.fontName + "-" + this.encoding));
/*      */       } else
/* 1262 */         dic.put(PdfName.FONTNAME, new PdfName(subsetPrefix + this.fontName + this.style));
/*      */     } else
/* 1264 */       dic.put(PdfName.FONTNAME, new PdfName(subsetPrefix + this.fontName + this.style));
/* 1265 */     dic.put(PdfName.ITALICANGLE, new PdfNumber(this.italicAngle));
/* 1266 */     dic.put(PdfName.STEMV, new PdfNumber(80));
/* 1267 */     if (fontStream != null) {
/* 1268 */       if (this.cff) {
/* 1269 */         dic.put(PdfName.FONTFILE3, fontStream);
/*      */       } else
/* 1271 */         dic.put(PdfName.FONTFILE2, fontStream);
/*      */     }
/* 1273 */     int flags = 0;
/* 1274 */     if (this.isFixedPitch)
/* 1275 */       flags |= 0x1;
/* 1276 */     flags |= (this.fontSpecific ? 4 : 32);
/* 1277 */     if ((this.head.macStyle & 0x2) != 0)
/* 1278 */       flags |= 0x40;
/* 1279 */     if ((this.head.macStyle & 0x1) != 0)
/* 1280 */       flags |= 0x40000;
/* 1281 */     dic.put(PdfName.FLAGS, new PdfNumber(flags));
/*      */     
/* 1283 */     return dic;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary getFontBaseType(PdfIndirectReference fontDescriptor, String subsetPrefix, int firstChar, int lastChar, byte[] shortTag)
/*      */   {
/* 1297 */     PdfDictionary dic = new PdfDictionary(PdfName.FONT);
/* 1298 */     if (this.cff) {
/* 1299 */       dic.put(PdfName.SUBTYPE, PdfName.TYPE1);
/* 1300 */       dic.put(PdfName.BASEFONT, new PdfName(this.fontName + this.style));
/*      */     } else {
/* 1302 */       dic.put(PdfName.SUBTYPE, PdfName.TRUETYPE);
/* 1303 */       dic.put(PdfName.BASEFONT, new PdfName(subsetPrefix + this.fontName + this.style));
/*      */     }
/* 1305 */     if (!this.fontSpecific) {
/* 1306 */       for (int k = firstChar; k <= lastChar; k++) {
/* 1307 */         if (!this.differences[k].equals(".notdef")) {
/* 1308 */           firstChar = k;
/* 1309 */           break;
/*      */         }
/*      */       }
/* 1312 */       if ((this.encoding.equals("Cp1252")) || (this.encoding.equals("MacRoman"))) {
/* 1313 */         dic.put(PdfName.ENCODING, this.encoding.equals("Cp1252") ? PdfName.WIN_ANSI_ENCODING : PdfName.MAC_ROMAN_ENCODING);
/*      */       } else {
/* 1315 */         PdfDictionary enc = new PdfDictionary(PdfName.ENCODING);
/* 1316 */         PdfArray dif = new PdfArray();
/* 1317 */         boolean gap = true;
/* 1318 */         for (int k = firstChar; k <= lastChar; k++)
/* 1319 */           if (shortTag[k] != 0) {
/* 1320 */             if (gap) {
/* 1321 */               dif.add(new PdfNumber(k));
/* 1322 */               gap = false;
/*      */             }
/* 1324 */             dif.add(new PdfName(this.differences[k]));
/*      */           } else {
/* 1326 */             gap = true;
/*      */           }
/* 1328 */         enc.put(PdfName.DIFFERENCES, dif);
/* 1329 */         dic.put(PdfName.ENCODING, enc);
/*      */       }
/*      */     }
/* 1332 */     dic.put(PdfName.FIRSTCHAR, new PdfNumber(firstChar));
/* 1333 */     dic.put(PdfName.LASTCHAR, new PdfNumber(lastChar));
/* 1334 */     PdfArray wd = new PdfArray();
/* 1335 */     for (int k = firstChar; k <= lastChar; k++) {
/* 1336 */       if (shortTag[k] == 0) {
/* 1337 */         wd.add(new PdfNumber(0));
/*      */       } else
/* 1339 */         wd.add(new PdfNumber(this.widths[k]));
/*      */     }
/* 1341 */     dic.put(PdfName.WIDTHS, wd);
/* 1342 */     if (fontDescriptor != null)
/* 1343 */       dic.put(PdfName.FONTDESCRIPTOR, fontDescriptor);
/* 1344 */     return dic;
/*      */   }
/*      */   
/*      */   protected byte[] getFullFont() throws IOException {
/* 1348 */     RandomAccessFileOrArray rf2 = null;
/*      */     try {
/* 1350 */       rf2 = new RandomAccessFileOrArray(this.rf);
/* 1351 */       rf2.reOpen();
/* 1352 */       byte[] b = new byte[(int)rf2.length()];
/* 1353 */       rf2.readFully(b);
/* 1354 */       return b;
/*      */     } finally {
/*      */       try {
/* 1357 */         if (rf2 != null) {
/* 1358 */           rf2.close();
/*      */         }
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */   protected synchronized byte[] getSubSet(HashSet glyphs, boolean subsetp) throws IOException, DocumentException {
/* 1366 */     TrueTypeFontSubSet sb = new TrueTypeFontSubSet(this.fileName, new RandomAccessFileOrArray(this.rf), glyphs, this.directoryOffset, true, !subsetp);
/* 1367 */     return sb.process();
/*      */   }
/*      */   
/*      */   protected static int[] compactRanges(ArrayList<int[]> ranges) {
/* 1371 */     ArrayList<int[]> simp = new ArrayList();
/* 1372 */     for (int k = 0; k < ranges.size(); k++) {
/* 1373 */       int[] r = (int[])ranges.get(k);
/* 1374 */       for (int j = 0; j < r.length; j += 2) {
/* 1375 */         simp.add(new int[] { Math.max(0, Math.min(r[j], r[(j + 1)])), Math.min(65535, Math.max(r[j], r[(j + 1)])) });
/*      */       }
/*      */     }
/* 1378 */     for (int k1 = 0; k1 < simp.size() - 1; k1++) {
/* 1379 */       for (int k2 = k1 + 1; k2 < simp.size(); k2++) {
/* 1380 */         int[] r1 = (int[])simp.get(k1);
/* 1381 */         int[] r2 = (int[])simp.get(k2);
/* 1382 */         if (((r1[0] >= r2[0]) && (r1[0] <= r2[1])) || ((r1[1] >= r2[0]) && (r1[0] <= r2[1]))) {
/* 1383 */           r1[0] = Math.min(r1[0], r2[0]);
/* 1384 */           r1[1] = Math.max(r1[1], r2[1]);
/* 1385 */           simp.remove(k2);
/* 1386 */           k2--;
/*      */         }
/*      */       }
/*      */     }
/* 1390 */     int[] s = new int[simp.size() * 2];
/* 1391 */     for (int k = 0; k < simp.size(); k++) {
/* 1392 */       int[] r = (int[])simp.get(k);
/* 1393 */       s[(k * 2)] = r[0];
/* 1394 */       s[(k * 2 + 1)] = r[1];
/*      */     }
/* 1396 */     return s;
/*      */   }
/*      */   
/*      */   protected void addRangeUni(HashMap<Integer, int[]> longTag, boolean includeMetrics, boolean subsetp) { int[] rg;
/* 1400 */     if ((!subsetp) && ((this.subsetRanges != null) || (this.directoryOffset > 0))) {
/* 1401 */       rg = (this.subsetRanges == null) && (this.directoryOffset > 0) ? new int[] { 0, 65535 } : compactRanges(this.subsetRanges);
/*      */       HashMap<Integer, int[]> usemap;
/* 1403 */       HashMap<Integer, int[]> usemap; if ((!this.fontSpecific) && (this.cmap31 != null)) {
/* 1404 */         usemap = this.cmap31; } else { HashMap<Integer, int[]> usemap;
/* 1405 */         if ((this.fontSpecific) && (this.cmap10 != null)) {
/* 1406 */           usemap = this.cmap10; } else { HashMap<Integer, int[]> usemap;
/* 1407 */           if (this.cmap31 != null) {
/* 1408 */             usemap = this.cmap31;
/*      */           } else
/* 1410 */             usemap = this.cmap10; } }
/* 1411 */       for (Map.Entry<Integer, int[]> e : usemap.entrySet()) {
/* 1412 */         int[] v = (int[])e.getValue();
/* 1413 */         Integer gi = Integer.valueOf(v[0]);
/* 1414 */         if (!longTag.containsKey(gi))
/*      */         {
/* 1416 */           int c = ((Integer)e.getKey()).intValue();
/* 1417 */           boolean skip = true;
/* 1418 */           for (int k = 0; k < rg.length; k += 2) {
/* 1419 */             if ((c >= rg[k]) && (c <= rg[(k + 1)])) {
/* 1420 */               skip = false;
/* 1421 */               break;
/*      */             }
/*      */           }
/* 1424 */           if (!skip)
/* 1425 */             longTag.put(gi, includeMetrics ? new int[] { v[0], v[1], c } : null);
/*      */         }
/*      */       }
/*      */     } }
/*      */   
/*      */   protected void addRangeUni(HashSet<Integer> longTag, boolean subsetp) { int[] rg;
/* 1431 */     if ((!subsetp) && ((this.subsetRanges != null) || (this.directoryOffset > 0))) {
/* 1432 */       rg = (this.subsetRanges == null) && (this.directoryOffset > 0) ? new int[] { 0, 65535 } : compactRanges(this.subsetRanges);
/*      */       HashMap<Integer, int[]> usemap;
/* 1434 */       HashMap<Integer, int[]> usemap; if ((!this.fontSpecific) && (this.cmap31 != null)) {
/* 1435 */         usemap = this.cmap31; } else { HashMap<Integer, int[]> usemap;
/* 1436 */         if ((this.fontSpecific) && (this.cmap10 != null)) {
/* 1437 */           usemap = this.cmap10; } else { HashMap<Integer, int[]> usemap;
/* 1438 */           if (this.cmap31 != null) {
/* 1439 */             usemap = this.cmap31;
/*      */           } else
/* 1441 */             usemap = this.cmap10; } }
/* 1442 */       for (Map.Entry<Integer, int[]> e : usemap.entrySet()) {
/* 1443 */         int[] v = (int[])e.getValue();
/* 1444 */         Integer gi = Integer.valueOf(v[0]);
/* 1445 */         if (!longTag.contains(gi))
/*      */         {
/* 1447 */           int c = ((Integer)e.getKey()).intValue();
/* 1448 */           boolean skip = true;
/* 1449 */           for (int k = 0; k < rg.length; k += 2) {
/* 1450 */             if ((c >= rg[k]) && (c <= rg[(k + 1)])) {
/* 1451 */               skip = false;
/* 1452 */               break;
/*      */             }
/*      */           }
/* 1455 */           if (!skip) {
/* 1456 */             longTag.add(gi);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void writeFont(PdfWriter writer, PdfIndirectReference ref, Object[] params)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1472 */     int firstChar = ((Integer)params[0]).intValue();
/* 1473 */     int lastChar = ((Integer)params[1]).intValue();
/* 1474 */     byte[] shortTag = (byte[])params[2];
/* 1475 */     boolean subsetp = (((Boolean)params[3]).booleanValue()) && (this.subset);
/*      */     
/* 1477 */     if (!subsetp) {
/* 1478 */       firstChar = 0;
/* 1479 */       lastChar = shortTag.length - 1;
/* 1480 */       for (int k = 0; k < shortTag.length; k++)
/* 1481 */         shortTag[k] = 1;
/*      */     }
/* 1483 */     PdfIndirectReference ind_font = null;
/* 1484 */     PdfObject pobj = null;
/* 1485 */     PdfIndirectObject obj = null;
/* 1486 */     String subsetPrefix = "";
/* 1487 */     if (this.embedded) {
/* 1488 */       if (this.cff) {
/* 1489 */         pobj = new BaseFont.StreamFont(readCffFont(), "Type1C", this.compressionLevel);
/* 1490 */         obj = writer.addToBody(pobj);
/* 1491 */         ind_font = obj.getIndirectReference();
/*      */       } else {
/* 1493 */         if (subsetp)
/* 1494 */           subsetPrefix = createSubsetPrefix();
/* 1495 */         HashSet<Integer> glyphs = new HashSet();
/* 1496 */         for (int k = firstChar; k <= lastChar; k++) {
/* 1497 */           if (shortTag[k] != 0) {
/* 1498 */             int[] metrics = null;
/* 1499 */             if (this.specialMap != null) {
/* 1500 */               int[] cd = GlyphList.nameToUnicode(this.differences[k]);
/* 1501 */               if (cd != null) {
/* 1502 */                 metrics = getMetricsTT(cd[0]);
/*      */               }
/* 1504 */             } else if (this.fontSpecific) {
/* 1505 */               metrics = getMetricsTT(k);
/*      */             } else {
/* 1507 */               metrics = getMetricsTT(this.unicodeDifferences[k]);
/*      */             }
/* 1509 */             if (metrics != null)
/* 1510 */               glyphs.add(Integer.valueOf(metrics[0]));
/*      */           }
/*      */         }
/* 1513 */         addRangeUni(glyphs, subsetp);
/* 1514 */         byte[] b = null;
/* 1515 */         if ((subsetp) || (this.directoryOffset != 0) || (this.subsetRanges != null)) {
/* 1516 */           b = getSubSet(new HashSet(glyphs), subsetp);
/*      */         } else {
/* 1518 */           b = getFullFont();
/*      */         }
/* 1520 */         int[] lengths = { b.length };
/* 1521 */         pobj = new BaseFont.StreamFont(b, lengths, this.compressionLevel);
/* 1522 */         obj = writer.addToBody(pobj);
/* 1523 */         ind_font = obj.getIndirectReference();
/*      */       }
/*      */     }
/* 1526 */     pobj = getFontDescriptor(ind_font, subsetPrefix, null);
/* 1527 */     if (pobj != null) {
/* 1528 */       obj = writer.addToBody(pobj);
/* 1529 */       ind_font = obj.getIndirectReference();
/*      */     }
/* 1531 */     pobj = getFontBaseType(ind_font, subsetPrefix, firstChar, lastChar, shortTag);
/* 1532 */     writer.addToBody(pobj, ref);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] readCffFont()
/*      */     throws IOException
/*      */   {
/* 1544 */     RandomAccessFileOrArray rf2 = new RandomAccessFileOrArray(this.rf);
/* 1545 */     b = new byte[this.cffLength];
/*      */     try {
/* 1547 */       rf2.reOpen();
/* 1548 */       rf2.seek(this.cffOffset);
/* 1549 */       rf2.readFully(b);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1557 */       return b;
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1552 */         rf2.close();
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfStream getFullFontStream()
/*      */     throws IOException, DocumentException
/*      */   {
/* 1568 */     if (this.cff) {
/* 1569 */       return new BaseFont.StreamFont(readCffFont(), "Type1C", this.compressionLevel);
/*      */     }
/* 1571 */     byte[] b = getFullFont();
/* 1572 */     int[] lengths = { b.length };
/* 1573 */     return new BaseFont.StreamFont(b, lengths, this.compressionLevel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFontDescriptor(int key, float fontSize)
/*      */   {
/* 1588 */     switch (key) {
/*      */     case 1: 
/* 1590 */       return this.os_2.sTypoAscender * fontSize / this.head.unitsPerEm;
/*      */     case 2: 
/* 1592 */       return this.os_2.sCapHeight * fontSize / this.head.unitsPerEm;
/*      */     case 3: 
/* 1594 */       return this.os_2.sTypoDescender * fontSize / this.head.unitsPerEm;
/*      */     case 4: 
/* 1596 */       return (float)this.italicAngle;
/*      */     case 5: 
/* 1598 */       return fontSize * this.head.xMin / this.head.unitsPerEm;
/*      */     case 6: 
/* 1600 */       return fontSize * this.head.yMin / this.head.unitsPerEm;
/*      */     case 7: 
/* 1602 */       return fontSize * this.head.xMax / this.head.unitsPerEm;
/*      */     case 8: 
/* 1604 */       return fontSize * this.head.yMax / this.head.unitsPerEm;
/*      */     case 9: 
/* 1606 */       return fontSize * this.hhea.Ascender / this.head.unitsPerEm;
/*      */     case 10: 
/* 1608 */       return fontSize * this.hhea.Descender / this.head.unitsPerEm;
/*      */     case 11: 
/* 1610 */       return fontSize * this.hhea.LineGap / this.head.unitsPerEm;
/*      */     case 12: 
/* 1612 */       return fontSize * this.hhea.advanceWidthMax / this.head.unitsPerEm;
/*      */     case 13: 
/* 1614 */       return (this.underlinePosition - this.underlineThickness / 2) * fontSize / this.head.unitsPerEm;
/*      */     case 14: 
/* 1616 */       return this.underlineThickness * fontSize / this.head.unitsPerEm;
/*      */     case 15: 
/* 1618 */       return this.os_2.yStrikeoutPosition * fontSize / this.head.unitsPerEm;
/*      */     case 16: 
/* 1620 */       return this.os_2.yStrikeoutSize * fontSize / this.head.unitsPerEm;
/*      */     case 17: 
/* 1622 */       return this.os_2.ySubscriptYSize * fontSize / this.head.unitsPerEm;
/*      */     case 18: 
/* 1624 */       return -this.os_2.ySubscriptYOffset * fontSize / this.head.unitsPerEm;
/*      */     case 19: 
/* 1626 */       return this.os_2.ySuperscriptYSize * fontSize / this.head.unitsPerEm;
/*      */     case 20: 
/* 1628 */       return this.os_2.ySuperscriptYOffset * fontSize / this.head.unitsPerEm;
/*      */     case 21: 
/* 1630 */       return this.os_2.usWeightClass;
/*      */     case 22: 
/* 1632 */       return this.os_2.usWidthClass;
/*      */     }
/* 1634 */     return 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getMetricsTT(int c)
/*      */   {
/* 1644 */     if (this.cmapExt != null)
/* 1645 */       return (int[])this.cmapExt.get(Integer.valueOf(c));
/* 1646 */     if ((!this.fontSpecific) && (this.cmap31 != null))
/* 1647 */       return (int[])this.cmap31.get(Integer.valueOf(c));
/* 1648 */     if ((this.fontSpecific) && (this.cmap10 != null))
/* 1649 */       return (int[])this.cmap10.get(Integer.valueOf(c));
/* 1650 */     if (this.cmap31 != null)
/* 1651 */       return (int[])this.cmap31.get(Integer.valueOf(c));
/* 1652 */     if (this.cmap10 != null)
/* 1653 */       return (int[])this.cmap10.get(Integer.valueOf(c));
/* 1654 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPostscriptFontName()
/*      */   {
/* 1664 */     return this.fontName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getCodePagesSupported()
/*      */   {
/* 1674 */     long cp = (this.os_2.ulCodePageRange2 << 32) + (this.os_2.ulCodePageRange1 & 0xFFFFFFFF);
/* 1675 */     int count = 0;
/* 1676 */     long bit = 1L;
/* 1677 */     for (int k = 0; k < 64; k++) {
/* 1678 */       if (((cp & bit) != 0L) && (codePages[k] != null))
/* 1679 */         count++;
/* 1680 */       bit <<= 1;
/*      */     }
/* 1682 */     String[] ret = new String[count];
/* 1683 */     count = 0;
/* 1684 */     bit = 1L;
/* 1685 */     for (int k = 0; k < 64; k++) {
/* 1686 */       if (((cp & bit) != 0L) && (codePages[k] != null))
/* 1687 */         ret[(count++)] = codePages[k];
/* 1688 */       bit <<= 1;
/*      */     }
/* 1690 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[][] getFullFontName()
/*      */   {
/* 1705 */     return this.fullName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSubfamily()
/*      */   {
/* 1718 */     if ((this.subFamily != null) && (this.subFamily.length > 0)) {
/* 1719 */       return this.subFamily[0][3];
/*      */     }
/* 1721 */     return super.getSubfamily();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[][] getAllNameEntries()
/*      */   {
/* 1736 */     return this.allNameEntries;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[][] getFamilyFontName()
/*      */   {
/* 1751 */     return this.familyName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasKernPairs()
/*      */   {
/* 1761 */     return this.kerning.size() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPostscriptFontName(String name)
/*      */   {
/* 1772 */     this.fontName = name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setKerning(int char1, int char2, int kern)
/*      */   {
/* 1785 */     int[] metrics = getMetricsTT(char1);
/* 1786 */     if (metrics == null)
/* 1787 */       return false;
/* 1788 */     int c1 = metrics[0];
/* 1789 */     metrics = getMetricsTT(char2);
/* 1790 */     if (metrics == null)
/* 1791 */       return false;
/* 1792 */     int c2 = metrics[0];
/* 1793 */     this.kerning.put((c1 << 16) + c2, kern);
/* 1794 */     return true;
/*      */   }
/*      */   
/*      */   protected int[] getRawCharBBox(int c, String name)
/*      */   {
/* 1799 */     HashMap<Integer, int[]> map = null;
/* 1800 */     if ((name == null) || (this.cmap31 == null)) {
/* 1801 */       map = this.cmap10;
/*      */     } else
/* 1803 */       map = this.cmap31;
/* 1804 */     if (map == null)
/* 1805 */       return null;
/* 1806 */     int[] metric = (int[])map.get(Integer.valueOf(c));
/* 1807 */     if ((metric == null) || (this.bboxes == null))
/* 1808 */       return null;
/* 1809 */     return this.bboxes[metric[0]];
/*      */   }
/*      */   
/*      */   protected static class HorizontalHeader
/*      */   {
/*      */     short Ascender;
/*      */     short Descender;
/*      */     short LineGap;
/*      */     int advanceWidthMax;
/*      */     short minLeftSideBearing;
/*      */     short minRightSideBearing;
/*      */     short xMaxExtent;
/*      */     short caretSlopeRise;
/*      */     short caretSlopeRun;
/*      */     int numberOfHMetrics;
/*      */   }
/*      */   
/*      */   protected static class FontHeader
/*      */   {
/*      */     int flags;
/*      */     int unitsPerEm;
/*      */     short xMin;
/*      */     short yMin;
/*      */     short xMax;
/*      */     short yMax;
/*      */     int macStyle;
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/TrueTypeFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */