/*    */ package com.itextpdf.text.pdf.hyphenation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HyphenationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 4721513606846982325L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HyphenationException(String msg)
/*    */   {
/* 27 */     super(msg);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/hyphenation/HyphenationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */