/*    */ package com.itextpdf.text.pdf.fonts.otf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableHeader
/*    */ {
/*    */   public int version;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int scriptListOffset;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int featureListOffset;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int lookupListOffset;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableHeader(int version, int scriptListOffset, int featureListOffset, int lookupListOffset)
/*    */   {
/* 59 */     this.version = version;
/* 60 */     this.scriptListOffset = scriptListOffset;
/* 61 */     this.featureListOffset = featureListOffset;
/* 62 */     this.lookupListOffset = lookupListOffset;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/fonts/otf/TableHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */