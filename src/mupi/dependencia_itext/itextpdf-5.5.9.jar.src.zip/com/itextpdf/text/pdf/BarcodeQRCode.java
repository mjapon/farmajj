/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.BadElementException;
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.pdf.codec.CCITTG4Encoder;
/*     */ import com.itextpdf.text.pdf.qrcode.ByteMatrix;
/*     */ import com.itextpdf.text.pdf.qrcode.EncodeHintType;
/*     */ import com.itextpdf.text.pdf.qrcode.QRCodeWriter;
/*     */ import com.itextpdf.text.pdf.qrcode.WriterException;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BarcodeQRCode
/*     */ {
/*     */   ByteMatrix bm;
/*     */   
/*     */   public BarcodeQRCode(String content, int width, int height, Map<EncodeHintType, Object> hints)
/*     */   {
/*     */     try
/*     */     {
/*  78 */       QRCodeWriter qc = new QRCodeWriter();
/*  79 */       this.bm = qc.encode(content, width, height, hints);
/*     */     }
/*     */     catch (WriterException ex) {
/*  82 */       throw new ExceptionConverter(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private byte[] getBitMatrix() {
/*  87 */     int width = this.bm.getWidth();
/*  88 */     int height = this.bm.getHeight();
/*  89 */     int stride = (width + 7) / 8;
/*  90 */     byte[] b = new byte[stride * height];
/*  91 */     byte[][] mt = this.bm.getArray();
/*  92 */     for (int y = 0; y < height; y++) {
/*  93 */       byte[] line = mt[y];
/*  94 */       for (int x = 0; x < width; x++) {
/*  95 */         if (line[x] != 0) {
/*  96 */           int offset = stride * y + x / 8; int 
/*  97 */             tmp89_87 = offset; byte[] tmp89_85 = b;tmp89_85[tmp89_87] = ((byte)(tmp89_85[tmp89_87] | (byte)(128 >> x % 8)));
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public com.itextpdf.text.Image getImage()
/*     */     throws BadElementException
/*     */   {
/* 109 */     byte[] b = getBitMatrix();
/* 110 */     byte[] g4 = CCITTG4Encoder.compress(b, this.bm.getWidth(), this.bm.getHeight());
/* 111 */     return com.itextpdf.text.Image.getInstance(this.bm.getWidth(), this.bm.getHeight(), false, 256, 1, g4, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public java.awt.Image createAwtImage(Color foreground, Color background)
/*     */   {
/* 122 */     int f = foreground.getRGB();
/* 123 */     int g = background.getRGB();
/* 124 */     Canvas canvas = new Canvas();
/*     */     
/* 126 */     int width = this.bm.getWidth();
/* 127 */     int height = this.bm.getHeight();
/* 128 */     int[] pix = new int[width * height];
/* 129 */     byte[][] mt = this.bm.getArray();
/* 130 */     for (int y = 0; y < height; y++) {
/* 131 */       byte[] line = mt[y];
/* 132 */       for (int x = 0; x < width; x++) {
/* 133 */         pix[(y * width + x)] = (line[x] == 0 ? f : g);
/*     */       }
/*     */     }
/*     */     
/* 137 */     java.awt.Image img = canvas.createImage(new MemoryImageSource(width, height, pix, 0, width));
/* 138 */     return img;
/*     */   }
/*     */   
/*     */   public void placeBarcode(PdfContentByte cb, BaseColor foreground, float moduleSide) {
/* 142 */     int width = this.bm.getWidth();
/* 143 */     int height = this.bm.getHeight();
/* 144 */     byte[][] mt = this.bm.getArray();
/*     */     
/* 146 */     cb.setColorFill(foreground);
/*     */     
/* 148 */     for (int y = 0; y < height; y++) {
/* 149 */       byte[] line = mt[y];
/* 150 */       for (int x = 0; x < width; x++) {
/* 151 */         if (line[x] == 0) {
/* 152 */           cb.rectangle(x * moduleSide, (height - y - 1) * moduleSide, moduleSide, moduleSide);
/*     */         }
/*     */       }
/*     */     }
/* 156 */     cb.fill();
/*     */   }
/*     */   
/*     */   public Rectangle getBarcodeSize()
/*     */   {
/* 161 */     return new Rectangle(0.0F, 0.0F, this.bm.getWidth(), this.bm.getHeight());
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/BarcodeQRCode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */