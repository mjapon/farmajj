/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import com.itextpdf.text.BaseColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotColor
/*    */   extends ExtendedColor
/*    */ {
/*    */   private static final long serialVersionUID = -6257004582113248079L;
/*    */   PdfSpotColor spot;
/*    */   float tint;
/*    */   
/*    */   public SpotColor(PdfSpotColor spot, float tint)
/*    */   {
/* 58 */     super(3, 
/* 59 */       (spot.getAlternativeCS().getRed() / 255.0F - 1.0F) * tint + 1.0F, 
/* 60 */       (spot.getAlternativeCS().getGreen() / 255.0F - 1.0F) * tint + 1.0F, 
/* 61 */       (spot.getAlternativeCS().getBlue() / 255.0F - 1.0F) * tint + 1.0F);
/* 62 */     this.spot = spot;
/* 63 */     this.tint = tint;
/*    */   }
/*    */   
/*    */   public PdfSpotColor getPdfSpotColor() {
/* 67 */     return this.spot;
/*    */   }
/*    */   
/*    */   public float getTint() {
/* 71 */     return this.tint;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 75 */     return ((obj instanceof SpotColor)) && (((SpotColor)obj).spot.equals(this.spot)) && (((SpotColor)obj).tint == this.tint);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 79 */     return this.spot.hashCode() ^ Float.floatToIntBits(this.tint);
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/SpotColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */