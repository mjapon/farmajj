/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ import com.itextpdf.text.error_messages.MessageLocalization;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeviceNColor
/*    */   extends ExtendedColor
/*    */ {
/*    */   PdfDeviceNColor pdfDeviceNColor;
/*    */   float[] tints;
/*    */   
/*    */   public DeviceNColor(PdfDeviceNColor pdfDeviceNColor, float[] tints)
/*    */   {
/* 53 */     super(6);
/* 54 */     if (pdfDeviceNColor.getSpotColors().length != tints.length)
/* 55 */       throw new RuntimeException(MessageLocalization.getComposedMessage("devicen.color.shall.have.the.same.number.of.colorants.as.the.destination.DeviceN.color.space", new Object[0]));
/* 56 */     this.pdfDeviceNColor = pdfDeviceNColor;
/* 57 */     this.tints = tints;
/*    */   }
/*    */   
/*    */   public PdfDeviceNColor getPdfDeviceNColor() {
/* 61 */     return this.pdfDeviceNColor;
/*    */   }
/*    */   
/*    */ 
/* 65 */   public float[] getTints() { return this.tints; }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 68 */     if (((obj instanceof DeviceNColor)) && (((DeviceNColor)obj).tints.length == this.tints.length)) {
/* 69 */       int i = 0;
/* 70 */       for (float tint : this.tints) {
/* 71 */         if (tint != ((DeviceNColor)obj).tints[i])
/* 72 */           return false;
/* 73 */         i++;
/*    */       }
/* 75 */       return true;
/*    */     }
/* 77 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 81 */     int hashCode = this.pdfDeviceNColor.hashCode();
/* 82 */     float[] arrayOfFloat = this.tints;int i = arrayOfFloat.length; for (int j = 0; j < i; j++) { Float tint = Float.valueOf(arrayOfFloat[j]);
/* 83 */       hashCode ^= tint.hashCode();
/*    */     }
/* 85 */     return hashCode;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/DeviceNColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */