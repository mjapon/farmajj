/*     */ package com.itextpdf.text.pdf.security;
/*     */ 
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.io.RASInputStream;
/*     */ import com.itextpdf.text.io.RandomAccessSource;
/*     */ import com.itextpdf.text.io.RandomAccessSourceFactory;
/*     */ import com.itextpdf.text.io.StreamUtil;
/*     */ import com.itextpdf.text.log.Logger;
/*     */ import com.itextpdf.text.log.LoggerFactory;
/*     */ import com.itextpdf.text.pdf.AcroFields;
/*     */ import com.itextpdf.text.pdf.ByteBuffer;
/*     */ import com.itextpdf.text.pdf.PdfArray;
/*     */ import com.itextpdf.text.pdf.PdfDate;
/*     */ import com.itextpdf.text.pdf.PdfDeveloperExtension;
/*     */ import com.itextpdf.text.pdf.PdfDictionary;
/*     */ import com.itextpdf.text.pdf.PdfName;
/*     */ import com.itextpdf.text.pdf.PdfReader;
/*     */ import com.itextpdf.text.pdf.PdfSignature;
/*     */ import com.itextpdf.text.pdf.PdfSignatureAppearance;
/*     */ import com.itextpdf.text.pdf.PdfString;
/*     */ import com.itextpdf.text.pdf.RandomAccessFileOrArray;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MakeSignature
/*     */ {
/*  85 */   private static final Logger LOGGER = LoggerFactory.getLogger(MakeSignature.class);
/*     */   
/*     */   public static enum CryptoStandard {
/*  88 */     CMS,  CADES;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private CryptoStandard() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void signDetached(PdfSignatureAppearance sap, ExternalDigest externalDigest, ExternalSignature externalSignature, Certificate[] chain, Collection<CrlClient> crlList, OcspClient ocspClient, TSAClient tsaClient, int estimatedSize, CryptoStandard sigtype)
/*     */     throws IOException, DocumentException, GeneralSecurityException
/*     */   {
/* 110 */     Collection<byte[]> crlBytes = null;
/* 111 */     int i = 0;
/* 112 */     while ((crlBytes == null) && (i < chain.length))
/* 113 */       crlBytes = processCrl(chain[(i++)], crlList);
/* 114 */     if (estimatedSize == 0) {
/* 115 */       estimatedSize = 8192;
/* 116 */       if (crlBytes != null) {
/* 117 */         for (byte[] element : crlBytes) {
/* 118 */           estimatedSize += element.length + 10;
/*     */         }
/*     */       }
/* 121 */       if (ocspClient != null)
/* 122 */         estimatedSize += 4192;
/* 123 */       if (tsaClient != null)
/* 124 */         estimatedSize += 4192;
/*     */     }
/* 126 */     sap.setCertificate(chain[0]);
/* 127 */     if (sigtype == CryptoStandard.CADES) {
/* 128 */       sap.addDeveloperExtension(PdfDeveloperExtension.ESIC_1_7_EXTENSIONLEVEL2);
/*     */     }
/* 130 */     PdfSignature dic = new PdfSignature(PdfName.ADOBE_PPKLITE, sigtype == CryptoStandard.CADES ? PdfName.ETSI_CADES_DETACHED : PdfName.ADBE_PKCS7_DETACHED);
/* 131 */     dic.setReason(sap.getReason());
/* 132 */     dic.setLocation(sap.getLocation());
/* 133 */     dic.setSignatureCreator(sap.getSignatureCreator());
/* 134 */     dic.setContact(sap.getContact());
/* 135 */     dic.setDate(new PdfDate(sap.getSignDate()));
/* 136 */     sap.setCryptoDictionary(dic);
/*     */     
/* 138 */     HashMap<PdfName, Integer> exc = new HashMap();
/* 139 */     exc.put(PdfName.CONTENTS, new Integer(estimatedSize * 2 + 2));
/* 140 */     sap.preClose(exc);
/*     */     
/* 142 */     String hashAlgorithm = externalSignature.getHashAlgorithm();
/* 143 */     PdfPKCS7 sgn = new PdfPKCS7(null, chain, hashAlgorithm, null, externalDigest, false);
/* 144 */     InputStream data = sap.getRangeStream();
/* 145 */     byte[] hash = DigestAlgorithms.digest(data, externalDigest.getMessageDigest(hashAlgorithm));
/* 146 */     byte[] ocsp = null;
/* 147 */     if ((chain.length >= 2) && (ocspClient != null)) {
/* 148 */       ocsp = ocspClient.getEncoded((X509Certificate)chain[0], (X509Certificate)chain[1], null);
/*     */     }
/* 150 */     byte[] sh = sgn.getAuthenticatedAttributeBytes(hash, ocsp, crlBytes, sigtype);
/* 151 */     byte[] extSignature = externalSignature.sign(sh);
/* 152 */     sgn.setExternalDigest(extSignature, null, externalSignature.getEncryptionAlgorithm());
/*     */     
/* 154 */     byte[] encodedSig = sgn.getEncodedPKCS7(hash, tsaClient, ocsp, crlBytes, sigtype);
/*     */     
/* 156 */     if (estimatedSize < encodedSig.length) {
/* 157 */       throw new IOException("Not enough space");
/*     */     }
/* 159 */     byte[] paddedSig = new byte[estimatedSize];
/* 160 */     System.arraycopy(encodedSig, 0, paddedSig, 0, encodedSig.length);
/*     */     
/* 162 */     PdfDictionary dic2 = new PdfDictionary();
/* 163 */     dic2.put(PdfName.CONTENTS, new PdfString(paddedSig).setHexWriting(true));
/* 164 */     sap.close(dic2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Collection<byte[]> processCrl(Certificate cert, Collection<CrlClient> crlList)
/*     */   {
/* 174 */     if (crlList == null)
/* 175 */       return null;
/* 176 */     ArrayList<byte[]> crlBytes = new ArrayList();
/* 177 */     for (CrlClient cc : crlList)
/* 178 */       if (cc != null)
/*     */       {
/* 180 */         LOGGER.info("Processing " + cc.getClass().getName());
/* 181 */         Collection<byte[]> b = cc.getEncoded((X509Certificate)cert, null);
/* 182 */         if (b != null)
/*     */         {
/* 184 */           crlBytes.addAll(b); }
/*     */       }
/* 186 */     if (crlBytes.isEmpty()) {
/* 187 */       return null;
/*     */     }
/* 189 */     return crlBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void signExternalContainer(PdfSignatureAppearance sap, ExternalSignatureContainer externalSignatureContainer, int estimatedSize)
/*     */     throws GeneralSecurityException, IOException, DocumentException
/*     */   {
/* 203 */     PdfSignature dic = new PdfSignature(null, null);
/* 204 */     dic.setReason(sap.getReason());
/* 205 */     dic.setLocation(sap.getLocation());
/* 206 */     dic.setSignatureCreator(sap.getSignatureCreator());
/* 207 */     dic.setContact(sap.getContact());
/* 208 */     dic.setDate(new PdfDate(sap.getSignDate()));
/* 209 */     externalSignatureContainer.modifySigningDictionary(dic);
/* 210 */     sap.setCryptoDictionary(dic);
/*     */     
/* 212 */     HashMap<PdfName, Integer> exc = new HashMap();
/* 213 */     exc.put(PdfName.CONTENTS, new Integer(estimatedSize * 2 + 2));
/* 214 */     sap.preClose(exc);
/*     */     
/* 216 */     InputStream data = sap.getRangeStream();
/* 217 */     byte[] encodedSig = externalSignatureContainer.sign(data);
/*     */     
/* 219 */     if (estimatedSize < encodedSig.length) {
/* 220 */       throw new IOException("Not enough space");
/*     */     }
/* 222 */     byte[] paddedSig = new byte[estimatedSize];
/* 223 */     System.arraycopy(encodedSig, 0, paddedSig, 0, encodedSig.length);
/*     */     
/* 225 */     PdfDictionary dic2 = new PdfDictionary();
/* 226 */     dic2.put(PdfName.CONTENTS, new PdfString(paddedSig).setHexWriting(true));
/* 227 */     sap.close(dic2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void signDeferred(PdfReader reader, String fieldName, OutputStream outs, ExternalSignatureContainer externalSignatureContainer)
/*     */     throws DocumentException, IOException, GeneralSecurityException
/*     */   {
/* 242 */     AcroFields af = reader.getAcroFields();
/* 243 */     PdfDictionary v = af.getSignatureDictionary(fieldName);
/* 244 */     if (v == null)
/* 245 */       throw new DocumentException("No field");
/* 246 */     if (!af.signatureCoversWholeDocument(fieldName))
/* 247 */       throw new DocumentException("Not the last signature");
/* 248 */     PdfArray b = v.getAsArray(PdfName.BYTERANGE);
/* 249 */     long[] gaps = b.asLongArray();
/* 250 */     if ((b.size() != 4) || (gaps[0] != 0L))
/* 251 */       throw new DocumentException("Single exclusion space supported");
/* 252 */     RandomAccessSource readerSource = reader.getSafeFile().createSourceView();
/* 253 */     InputStream rg = new RASInputStream(new RandomAccessSourceFactory().createRanged(readerSource, gaps));
/* 254 */     byte[] signedContent = externalSignatureContainer.sign(rg);
/* 255 */     int spaceAvailable = (int)(gaps[2] - gaps[1]) - 2;
/* 256 */     if ((spaceAvailable & 0x1) != 0)
/* 257 */       throw new DocumentException("Gap is not a multiple of 2");
/* 258 */     spaceAvailable /= 2;
/* 259 */     if (spaceAvailable < signedContent.length)
/* 260 */       throw new DocumentException("Not enough space");
/* 261 */     StreamUtil.CopyBytes(readerSource, 0L, gaps[1] + 1L, outs);
/* 262 */     ByteBuffer bb = new ByteBuffer(spaceAvailable * 2);
/* 263 */     for (byte bi : signedContent) {
/* 264 */       bb.appendHex(bi);
/*     */     }
/* 266 */     int remain = (spaceAvailable - signedContent.length) * 2;
/* 267 */     for (int k = 0; k < remain; k++) {
/* 268 */       bb.append((byte)48);
/*     */     }
/* 270 */     bb.writeTo(outs);
/* 271 */     StreamUtil.CopyBytes(readerSource, gaps[2] - 1L, gaps[3] + 1L, outs);
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/security/MakeSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */