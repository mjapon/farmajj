/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.awt.geom.AffineTransform;
/*     */ import com.itextpdf.text.AccessibleElementId;
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.Chunk;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Element;
/*     */ import com.itextpdf.text.ElementListener;
/*     */ import com.itextpdf.text.Image;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.api.Spaceable;
/*     */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfDiv
/*     */   implements Element, Spaceable, IAccessibleElement
/*     */ {
/*     */   private ArrayList<Element> content;
/*     */   
/*     */   public static enum FloatType
/*     */   {
/*  60 */     NONE,  LEFT,  RIGHT;
/*     */     private FloatType() {} }
/*  62 */   public static enum PositionType { STATIC,  ABSOLUTE,  FIXED,  RELATIVE;
/*     */     private PositionType() {} }
/*  64 */   public static enum DisplayType { NONE,  BLOCK,  INLINE,  INLINE_BLOCK,  INLINE_TABLE,  LIST_ITEM,  RUN_IN,  TABLE,  TABLE_CAPTION,  TABLE_CELL,  TABLE_COLUMN_GROUP,  TABLE_COLUMN,  TABLE_FOOTER_GROUP, 
/*  65 */     TABLE_HEADER_GROUP,  TABLE_ROW,  TABLE_ROW_GROUP;
/*     */     private DisplayType() {} }
/*  67 */   public static enum BorderTopStyle { DOTTED,  DASHED,  SOLID,  DOUBLE,  GROOVE,  RIDGE,  INSET,  OUTSET;
/*     */     
/*     */     private BorderTopStyle() {} }
/*     */   
/*  71 */   private Float left = null;
/*     */   
/*  73 */   private Float top = null;
/*     */   
/*  75 */   private Float right = null;
/*     */   
/*  77 */   private Float bottom = null;
/*     */   
/*  79 */   private Float width = null;
/*     */   
/*  81 */   private Float height = null;
/*     */   
/*  83 */   private Float percentageHeight = null;
/*     */   
/*  85 */   private Float percentageWidth = null;
/*     */   
/*  87 */   private float contentWidth = 0.0F;
/*     */   
/*  89 */   private float contentHeight = 0.0F;
/*     */   
/*  91 */   private int textAlignment = -1;
/*     */   
/*  93 */   private float paddingLeft = 0.0F;
/*     */   
/*  95 */   private float paddingRight = 0.0F;
/*     */   
/*  97 */   private float paddingTop = 0.0F;
/*     */   
/*  99 */   private float paddingBottom = 0.0F;
/*     */   
/* 101 */   private FloatType floatType = FloatType.NONE;
/*     */   
/* 103 */   private PositionType position = PositionType.STATIC;
/*     */   
/*     */   private DisplayType display;
/*     */   
/* 107 */   private FloatLayout floatLayout = null;
/*     */   
/*     */   private BorderTopStyle borderTopStyle;
/*     */   
/*     */   private float yLine;
/*     */   
/* 113 */   protected int runDirection = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean keepTogether;
/*     */   
/*     */ 
/* 120 */   protected PdfName role = PdfName.DIV;
/* 121 */   protected HashMap<PdfName, PdfObject> accessibleAttributes = null;
/* 122 */   protected AccessibleElementId id = new AccessibleElementId();
/*     */   
/*     */   public float getContentWidth() {
/* 125 */     return this.contentWidth;
/*     */   }
/*     */   
/*     */   public void setContentWidth(float contentWidth) {
/* 129 */     this.contentWidth = contentWidth;
/*     */   }
/*     */   
/*     */   public float getContentHeight() {
/* 133 */     return this.contentHeight;
/*     */   }
/*     */   
/*     */   public void setContentHeight(float contentHeight) {
/* 137 */     this.contentHeight = contentHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getActualHeight()
/*     */   {
/* 148 */     return (this.height != null) && (this.height.floatValue() >= this.contentHeight) ? this.height.floatValue() : this.contentHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getActualWidth()
/*     */   {
/* 158 */     return (this.width != null) && (this.width.floatValue() >= this.contentWidth) ? this.width.floatValue() : this.contentWidth;
/*     */   }
/*     */   
/*     */   public Float getPercentageHeight() {
/* 162 */     return this.percentageHeight;
/*     */   }
/*     */   
/*     */   public void setPercentageHeight(Float percentageHeight) {
/* 166 */     this.percentageHeight = percentageHeight;
/*     */   }
/*     */   
/*     */   public Float getPercentageWidth() {
/* 170 */     return this.percentageWidth;
/*     */   }
/*     */   
/*     */   public void setPercentageWidth(Float percentageWidth) {
/* 174 */     this.percentageWidth = percentageWidth;
/*     */   }
/*     */   
/*     */   public DisplayType getDisplay()
/*     */   {
/* 179 */     return this.display;
/*     */   }
/*     */   
/*     */   public void setDisplay(DisplayType display) {
/* 183 */     this.display = display;
/*     */   }
/*     */   
/*     */   public BaseColor getBackgroundColor()
/*     */   {
/* 188 */     return this.backgroundColor;
/*     */   }
/*     */   
/*     */   public void setBackgroundColor(BaseColor backgroundColor) {
/* 192 */     this.backgroundColor = backgroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBackgroundImage(Image image)
/*     */   {
/* 199 */     this.backgroundImage = image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBackgroundImage(Image image, float width, float height)
/*     */   {
/* 206 */     this.backgroundImage = image;
/* 207 */     this.backgroundImageWidth = Float.valueOf(width);
/* 208 */     this.backgroundImageHeight = Float.valueOf(height);
/*     */   }
/*     */   
/*     */   public float getYLine() {
/* 212 */     return this.yLine;
/*     */   }
/*     */   
/*     */   public int getRunDirection() {
/* 216 */     return this.runDirection;
/*     */   }
/*     */   
/*     */   public void setRunDirection(int runDirection) {
/* 220 */     this.runDirection = runDirection;
/*     */   }
/*     */   
/*     */   public boolean getKeepTogether() {
/* 224 */     return this.keepTogether;
/*     */   }
/*     */   
/*     */   public void setKeepTogether(boolean keepTogether) {
/* 228 */     this.keepTogether = keepTogether;
/*     */   }
/*     */   
/* 231 */   private BaseColor backgroundColor = null;
/*     */   
/*     */ 
/*     */   private Image backgroundImage;
/*     */   
/*     */ 
/*     */   private Float backgroundImageWidth;
/*     */   
/*     */   private Float backgroundImageHeight;
/*     */   
/*     */   protected float spacingBefore;
/*     */   
/*     */   protected float spacingAfter;
/*     */   
/*     */ 
/*     */   public PdfDiv()
/*     */   {
/* 248 */     this.content = new ArrayList();
/* 249 */     this.keepTogether = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Chunk> getChunks()
/*     */   {
/* 258 */     return new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int type()
/*     */   {
/* 267 */     return 37;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isContent()
/*     */   {
/* 275 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNestable()
/*     */   {
/* 283 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean process(ElementListener listener)
/*     */   {
/*     */     try
/*     */     {
/* 295 */       return listener.add(this);
/*     */     }
/*     */     catch (DocumentException de) {}
/* 298 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSpacingBefore(float spacing)
/*     */   {
/* 308 */     this.spacingBefore = spacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSpacingAfter(float spacing)
/*     */   {
/* 317 */     this.spacingAfter = spacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getSpacingBefore()
/*     */   {
/* 326 */     return this.spacingBefore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getSpacingAfter()
/*     */   {
/* 335 */     return this.spacingAfter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTextAlignment()
/*     */   {
/* 344 */     return this.textAlignment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTextAlignment(int textAlignment)
/*     */   {
/* 354 */     this.textAlignment = textAlignment;
/*     */   }
/*     */   
/*     */   public void addElement(Element element) {
/* 358 */     this.content.add(element);
/*     */   }
/*     */   
/*     */   public Float getLeft() {
/* 362 */     return this.left;
/*     */   }
/*     */   
/*     */   public void setLeft(Float left) {
/* 366 */     this.left = left;
/*     */   }
/*     */   
/*     */   public Float getRight() {
/* 370 */     return this.right;
/*     */   }
/*     */   
/*     */   public void setRight(Float right) {
/* 374 */     this.right = right;
/*     */   }
/*     */   
/*     */   public Float getTop() {
/* 378 */     return this.top;
/*     */   }
/*     */   
/*     */   public void setTop(Float top) {
/* 382 */     this.top = top;
/*     */   }
/*     */   
/*     */   public Float getBottom() {
/* 386 */     return this.bottom;
/*     */   }
/*     */   
/*     */   public void setBottom(Float bottom) {
/* 390 */     this.bottom = bottom;
/*     */   }
/*     */   
/*     */   public Float getWidth() {
/* 394 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(Float width) {
/* 398 */     this.width = width;
/*     */   }
/*     */   
/*     */   public Float getHeight() {
/* 402 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(Float height) {
/* 406 */     this.height = height;
/*     */   }
/*     */   
/*     */   public float getPaddingLeft() {
/* 410 */     return this.paddingLeft;
/*     */   }
/*     */   
/*     */   public void setPaddingLeft(float paddingLeft) {
/* 414 */     this.paddingLeft = paddingLeft;
/*     */   }
/*     */   
/*     */   public float getPaddingRight() {
/* 418 */     return this.paddingRight;
/*     */   }
/*     */   
/*     */   public void setPaddingRight(float paddingRight) {
/* 422 */     this.paddingRight = paddingRight;
/*     */   }
/*     */   
/*     */   public float getPaddingTop() {
/* 426 */     return this.paddingTop;
/*     */   }
/*     */   
/*     */   public void setPaddingTop(float paddingTop) {
/* 430 */     this.paddingTop = paddingTop;
/*     */   }
/*     */   
/*     */   public float getPaddingBottom() {
/* 434 */     return this.paddingBottom;
/*     */   }
/*     */   
/*     */   public void setPaddingBottom(float paddingBottom) {
/* 438 */     this.paddingBottom = paddingBottom;
/*     */   }
/*     */   
/*     */   public FloatType getFloatType() {
/* 442 */     return this.floatType;
/*     */   }
/*     */   
/*     */   public void setFloatType(FloatType floatType) {
/* 446 */     this.floatType = floatType;
/*     */   }
/*     */   
/*     */   public PositionType getPosition() {
/* 450 */     return this.position;
/*     */   }
/*     */   
/*     */   public void setPosition(PositionType position) {
/* 454 */     this.position = position;
/*     */   }
/*     */   
/*     */   public ArrayList<Element> getContent() {
/* 458 */     return this.content;
/*     */   }
/*     */   
/*     */   public void setContent(ArrayList<Element> content) {
/* 462 */     this.content = content;
/*     */   }
/*     */   
/*     */   public BorderTopStyle getBorderTopStyle() {
/* 466 */     return this.borderTopStyle;
/*     */   }
/*     */   
/*     */   public void setBorderTopStyle(BorderTopStyle borderTopStyle) {
/* 470 */     this.borderTopStyle = borderTopStyle;
/*     */   }
/*     */   
/*     */   public int layout(PdfContentByte canvas, boolean useAscender, boolean simulate, float llx, float lly, float urx, float ury) throws DocumentException
/*     */   {
/* 475 */     float leftX = Math.min(llx, urx);
/* 476 */     float maxY = Math.max(lly, ury);
/* 477 */     float minY = Math.min(lly, ury);
/* 478 */     float rightX = Math.max(llx, urx);
/* 479 */     this.yLine = maxY;
/* 480 */     boolean contentCutByFixedHeight = false;
/*     */     
/* 482 */     if ((this.width != null) && (this.width.floatValue() > 0.0F)) {
/* 483 */       if (this.width.floatValue() < rightX - leftX) {
/* 484 */         rightX = leftX + this.width.floatValue();
/* 485 */       } else if (this.width.floatValue() > rightX - leftX) {
/* 486 */         return 2;
/*     */       }
/* 488 */     } else if (this.percentageWidth != null) {
/* 489 */       this.contentWidth = ((rightX - leftX) * this.percentageWidth.floatValue());
/* 490 */       rightX = leftX + this.contentWidth;
/* 491 */     } else if ((this.percentageWidth == null) && 
/* 492 */       (this.floatType == FloatType.NONE) && ((this.display == null) || (this.display == DisplayType.BLOCK) || (this.display == DisplayType.LIST_ITEM) || (this.display == DisplayType.RUN_IN)))
/*     */     {
/*     */ 
/* 495 */       this.contentWidth = (rightX - leftX);
/*     */     }
/*     */     
/*     */ 
/* 499 */     if ((this.height != null) && (this.height.floatValue() > 0.0F)) {
/* 500 */       if (this.height.floatValue() < maxY - minY) {
/* 501 */         minY = maxY - this.height.floatValue();
/* 502 */         contentCutByFixedHeight = true;
/* 503 */       } else if (this.height.floatValue() > maxY - minY) {
/* 504 */         return 2;
/*     */       }
/* 506 */     } else if (this.percentageHeight != null) {
/* 507 */       if (this.percentageHeight.floatValue() < 1.0D) {
/* 508 */         contentCutByFixedHeight = true;
/*     */       }
/* 510 */       this.contentHeight = ((maxY - minY) * this.percentageHeight.floatValue());
/* 511 */       minY = maxY - this.contentHeight;
/*     */     }
/*     */     
/* 514 */     if ((!simulate) && (this.position == PositionType.RELATIVE)) {
/* 515 */       Float translationX = null;
/* 516 */       if (this.left != null) {
/* 517 */         translationX = this.left;
/* 518 */       } else if (this.right != null) {
/* 519 */         translationX = Float.valueOf(-this.right.floatValue());
/*     */       } else {
/* 521 */         translationX = Float.valueOf(0.0F);
/*     */       }
/*     */       
/* 524 */       Float translationY = null;
/* 525 */       if (this.top != null) {
/* 526 */         translationY = Float.valueOf(-this.top.floatValue());
/* 527 */       } else if (this.bottom != null) {
/* 528 */         translationY = this.bottom;
/*     */       } else {
/* 530 */         translationY = Float.valueOf(0.0F);
/*     */       }
/* 532 */       canvas.saveState();
/* 533 */       canvas.transform(new AffineTransform(1.0F, 0.0F, 0.0F, 1.0F, translationX.floatValue(), translationY.floatValue()));
/*     */     }
/*     */     
/* 536 */     if ((!simulate) && 
/* 537 */       ((this.backgroundColor != null) || (this.backgroundImage != null)) && (getActualWidth() > 0.0F) && (getActualHeight() > 0.0F)) {
/* 538 */       float backgroundWidth = getActualWidth();
/* 539 */       float backgroundHeight = getActualHeight();
/* 540 */       if (this.width != null) {
/* 541 */         backgroundWidth = this.width.floatValue() > 0.0F ? this.width.floatValue() : 0.0F;
/*     */       }
/*     */       
/* 544 */       if (this.height != null) {
/* 545 */         backgroundHeight = this.height.floatValue() > 0.0F ? this.height.floatValue() : 0.0F;
/*     */       }
/* 547 */       if ((backgroundWidth > 0.0F) && (backgroundHeight > 0.0F)) {
/* 548 */         Rectangle background = new Rectangle(leftX, maxY - backgroundHeight, backgroundWidth + leftX, maxY);
/* 549 */         if (this.backgroundColor != null) {
/* 550 */           background.setBackgroundColor(this.backgroundColor);
/* 551 */           PdfArtifact artifact = new PdfArtifact();
/* 552 */           canvas.openMCBlock(artifact);
/* 553 */           canvas.rectangle(background);
/* 554 */           canvas.closeMCBlock(artifact);
/*     */         }
/* 556 */         if (this.backgroundImage != null) {
/* 557 */           if (this.backgroundImageWidth == null) {
/* 558 */             this.backgroundImage.scaleToFit(background);
/*     */           } else {
/* 560 */             this.backgroundImage.scaleAbsolute(this.backgroundImageWidth.floatValue(), this.backgroundImageHeight.floatValue());
/*     */           }
/* 562 */           this.backgroundImage.setAbsolutePosition(background.getLeft(), background.getBottom());
/* 563 */           canvas.openMCBlock(this.backgroundImage);
/* 564 */           canvas.addImage(this.backgroundImage);
/* 565 */           canvas.closeMCBlock(this.backgroundImage);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 571 */     if (this.percentageWidth == null) {
/* 572 */       this.contentWidth = 0.0F;
/*     */     }
/* 574 */     if (this.percentageHeight == null) {
/* 575 */       this.contentHeight = 0.0F;
/*     */     }
/*     */     
/* 578 */     minY += this.paddingBottom;
/* 579 */     leftX += this.paddingLeft;
/* 580 */     rightX -= this.paddingRight;
/*     */     
/* 582 */     this.yLine -= this.paddingTop;
/*     */     
/* 584 */     int status = 1;
/*     */     
/* 586 */     if (!this.content.isEmpty()) {
/* 587 */       if (this.floatLayout == null) {
/* 588 */         ArrayList<Element> floatingElements = new ArrayList(this.content);
/* 589 */         this.floatLayout = new FloatLayout(floatingElements, useAscender);
/* 590 */         this.floatLayout.setRunDirection(this.runDirection);
/*     */       }
/*     */       
/* 593 */       this.floatLayout.setSimpleColumn(leftX, minY, rightX, this.yLine);
/* 594 */       if (getBorderTopStyle() != null) {
/* 595 */         this.floatLayout.compositeColumn.setIgnoreSpacingBefore(false);
/*     */       }
/*     */       
/* 598 */       status = this.floatLayout.layout(canvas, simulate);
/* 599 */       this.yLine = this.floatLayout.getYLine();
/* 600 */       if ((this.percentageWidth == null) && (this.contentWidth < this.floatLayout.getFilledWidth())) {
/* 601 */         this.contentWidth = this.floatLayout.getFilledWidth();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 606 */     if ((!simulate) && (this.position == PositionType.RELATIVE)) {
/* 607 */       canvas.restoreState();
/*     */     }
/*     */     
/* 610 */     this.yLine -= this.paddingBottom;
/* 611 */     if (this.percentageHeight == null) {
/* 612 */       this.contentHeight = (maxY - this.yLine);
/*     */     }
/*     */     
/* 615 */     if (this.percentageWidth == null) {
/* 616 */       this.contentWidth += this.paddingLeft + this.paddingRight;
/*     */     }
/*     */     
/* 619 */     return contentCutByFixedHeight ? 1 : status;
/*     */   }
/*     */   
/*     */   public PdfObject getAccessibleAttribute(PdfName key) {
/* 623 */     if (this.accessibleAttributes != null) {
/* 624 */       return (PdfObject)this.accessibleAttributes.get(key);
/*     */     }
/* 626 */     return null;
/*     */   }
/*     */   
/*     */   public void setAccessibleAttribute(PdfName key, PdfObject value) {
/* 630 */     if (this.accessibleAttributes == null)
/* 631 */       this.accessibleAttributes = new HashMap();
/* 632 */     this.accessibleAttributes.put(key, value);
/*     */   }
/*     */   
/*     */   public HashMap<PdfName, PdfObject> getAccessibleAttributes() {
/* 636 */     return this.accessibleAttributes;
/*     */   }
/*     */   
/*     */   public PdfName getRole() {
/* 640 */     return this.role;
/*     */   }
/*     */   
/*     */   public void setRole(PdfName role) {
/* 644 */     this.role = role;
/*     */   }
/*     */   
/*     */   public AccessibleElementId getId() {
/* 648 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(AccessibleElementId id) {
/* 652 */     this.id = id;
/*     */   }
/*     */   
/*     */   public boolean isInline() {
/* 656 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfDiv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */