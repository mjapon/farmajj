/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.exceptions.InvalidPdfException;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BaseFont
/*      */ {
/*      */   public static final String COURIER = "Courier";
/*      */   public static final String COURIER_BOLD = "Courier-Bold";
/*      */   public static final String COURIER_OBLIQUE = "Courier-Oblique";
/*      */   public static final String COURIER_BOLDOBLIQUE = "Courier-BoldOblique";
/*      */   public static final String HELVETICA = "Helvetica";
/*      */   public static final String HELVETICA_BOLD = "Helvetica-Bold";
/*      */   public static final String HELVETICA_OBLIQUE = "Helvetica-Oblique";
/*      */   public static final String HELVETICA_BOLDOBLIQUE = "Helvetica-BoldOblique";
/*      */   public static final String SYMBOL = "Symbol";
/*      */   public static final String TIMES_ROMAN = "Times-Roman";
/*      */   public static final String TIMES_BOLD = "Times-Bold";
/*      */   public static final String TIMES_ITALIC = "Times-Italic";
/*      */   public static final String TIMES_BOLDITALIC = "Times-BoldItalic";
/*      */   public static final String ZAPFDINGBATS = "ZapfDingbats";
/*      */   public static final int ASCENT = 1;
/*      */   public static final int CAPHEIGHT = 2;
/*      */   public static final int DESCENT = 3;
/*      */   public static final int ITALICANGLE = 4;
/*      */   public static final int BBOXLLX = 5;
/*      */   public static final int BBOXLLY = 6;
/*      */   public static final int BBOXURX = 7;
/*      */   public static final int BBOXURY = 8;
/*      */   public static final int AWT_ASCENT = 9;
/*      */   public static final int AWT_DESCENT = 10;
/*      */   public static final int AWT_LEADING = 11;
/*      */   public static final int AWT_MAXADVANCE = 12;
/*      */   public static final int UNDERLINE_POSITION = 13;
/*      */   public static final int UNDERLINE_THICKNESS = 14;
/*      */   public static final int STRIKETHROUGH_POSITION = 15;
/*      */   public static final int STRIKETHROUGH_THICKNESS = 16;
/*      */   public static final int SUBSCRIPT_SIZE = 17;
/*      */   public static final int SUBSCRIPT_OFFSET = 18;
/*      */   public static final int SUPERSCRIPT_SIZE = 19;
/*      */   public static final int SUPERSCRIPT_OFFSET = 20;
/*      */   public static final int WEIGHT_CLASS = 21;
/*      */   public static final int WIDTH_CLASS = 22;
/*      */   public static final int FONT_WEIGHT = 23;
/*      */   public static final int FONT_TYPE_T1 = 0;
/*      */   public static final int FONT_TYPE_TT = 1;
/*      */   public static final int FONT_TYPE_CJK = 2;
/*      */   public static final int FONT_TYPE_TTUNI = 3;
/*      */   public static final int FONT_TYPE_DOCUMENT = 4;
/*      */   public static final int FONT_TYPE_T3 = 5;
/*      */   public static final String IDENTITY_H = "Identity-H";
/*      */   public static final String IDENTITY_V = "Identity-V";
/*      */   public static final String CP1250 = "Cp1250";
/*      */   public static final String CP1252 = "Cp1252";
/*      */   public static final String CP1257 = "Cp1257";
/*      */   public static final String WINANSI = "Cp1252";
/*      */   public static final String MACROMAN = "MacRoman";
/*  232 */   public static final int[] CHAR_RANGE_LATIN = { 0, 383, 8192, 8303, 8352, 8399, 64256, 64262 };
/*  233 */   public static final int[] CHAR_RANGE_ARABIC = { 0, 127, 1536, 1663, 8352, 8399, 64336, 64511, 65136, 65279 };
/*  234 */   public static final int[] CHAR_RANGE_HEBREW = { 0, 127, 1424, 1535, 8352, 8399, 64285, 64335 };
/*  235 */   public static final int[] CHAR_RANGE_CYRILLIC = { 0, 127, 1024, 1327, 8192, 8303, 8352, 8399 };
/*      */   
/*      */ 
/*  238 */   public static final double[] DEFAULT_FONT_MATRIX = { 0.001D, 0.0D, 0.0D, 0.001D, 0.0D, 0.0D };
/*      */   
/*      */ 
/*      */   public static final boolean EMBEDDED = true;
/*      */   
/*      */ 
/*      */   public static final boolean NOT_EMBEDDED = false;
/*      */   
/*      */ 
/*      */   public static final boolean CACHED = true;
/*      */   
/*      */ 
/*      */   public static final boolean NOT_CACHED = false;
/*      */   
/*      */ 
/*      */   public static final String RESOURCE_PATH = "com/itextpdf/text/pdf/fonts/";
/*      */   
/*      */ 
/*      */   public static final char CID_NEWLINE = '翿';
/*      */   
/*      */ 
/*      */   public static final char PARAGRAPH_SEPARATOR = ' ';
/*      */   
/*      */ 
/*      */   protected ArrayList<int[]> subsetRanges;
/*      */   
/*      */ 
/*      */   int fontType;
/*      */   
/*      */ 
/*      */   public static final String notdef = ".notdef";
/*      */   
/*  270 */   protected int[] widths = new int['Ā'];
/*      */   
/*      */ 
/*  273 */   protected String[] differences = new String['Ā'];
/*      */   
/*  275 */   protected char[] unicodeDifferences = new char['Ā'];
/*      */   
/*  277 */   protected int[][] charBBoxes = new int['Ā'][];
/*      */   
/*      */ 
/*      */ 
/*      */   protected String encoding;
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean embedded;
/*      */   
/*      */ 
/*  288 */   protected int compressionLevel = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */   protected boolean fontSpecific = true;
/*      */   
/*      */ 
/*  298 */   protected static ConcurrentHashMap<String, BaseFont> fontCache = new ConcurrentHashMap();
/*      */   
/*      */ 
/*  301 */   protected static final HashMap<String, PdfName> BuiltinFonts14 = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  306 */   protected boolean forceWidthsOutput = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  311 */   protected boolean directTextToByte = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  316 */   protected boolean subset = true;
/*      */   
/*  318 */   protected boolean fastWinansi = false;
/*      */   
/*      */ 
/*      */ 
/*      */   protected IntHashtable specialMap;
/*      */   
/*      */ 
/*      */ 
/*  326 */   protected boolean vertical = false;
/*      */   
/*      */   static {
/*  329 */     BuiltinFonts14.put("Courier", PdfName.COURIER);
/*  330 */     BuiltinFonts14.put("Courier-Bold", PdfName.COURIER_BOLD);
/*  331 */     BuiltinFonts14.put("Courier-BoldOblique", PdfName.COURIER_BOLDOBLIQUE);
/*  332 */     BuiltinFonts14.put("Courier-Oblique", PdfName.COURIER_OBLIQUE);
/*  333 */     BuiltinFonts14.put("Helvetica", PdfName.HELVETICA);
/*  334 */     BuiltinFonts14.put("Helvetica-Bold", PdfName.HELVETICA_BOLD);
/*  335 */     BuiltinFonts14.put("Helvetica-BoldOblique", PdfName.HELVETICA_BOLDOBLIQUE);
/*  336 */     BuiltinFonts14.put("Helvetica-Oblique", PdfName.HELVETICA_OBLIQUE);
/*  337 */     BuiltinFonts14.put("Symbol", PdfName.SYMBOL);
/*  338 */     BuiltinFonts14.put("Times-Roman", PdfName.TIMES_ROMAN);
/*  339 */     BuiltinFonts14.put("Times-Bold", PdfName.TIMES_BOLD);
/*  340 */     BuiltinFonts14.put("Times-BoldItalic", PdfName.TIMES_BOLDITALIC);
/*  341 */     BuiltinFonts14.put("Times-Italic", PdfName.TIMES_ITALIC);
/*  342 */     BuiltinFonts14.put("ZapfDingbats", PdfName.ZAPFDINGBATS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static class StreamFont
/*      */     extends PdfStream
/*      */   {
/*      */     public StreamFont(byte[] contents, int[] lengths, int compressionLevel)
/*      */       throws DocumentException
/*      */     {
/*      */       try
/*      */       {
/*  360 */         this.bytes = contents;
/*  361 */         put(PdfName.LENGTH, new PdfNumber(this.bytes.length));
/*  362 */         for (int k = 0; k < lengths.length; k++) {
/*  363 */           put(new PdfName("Length" + (k + 1)), new PdfNumber(lengths[k]));
/*      */         }
/*  365 */         flateCompress(compressionLevel);
/*      */       }
/*      */       catch (Exception e) {
/*  368 */         throw new DocumentException(e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public StreamFont(byte[] contents, String subType, int compressionLevel)
/*      */       throws DocumentException
/*      */     {
/*      */       try
/*      */       {
/*  382 */         this.bytes = contents;
/*  383 */         put(PdfName.LENGTH, new PdfNumber(this.bytes.length));
/*  384 */         if (subType != null)
/*  385 */           put(PdfName.SUBTYPE, new PdfName(subType));
/*  386 */         flateCompress(compressionLevel);
/*      */       }
/*      */       catch (Exception e) {
/*  389 */         throw new DocumentException(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont()
/*      */     throws DocumentException, IOException
/*      */   {
/*  409 */     return createFont("Helvetica", "Cp1252", false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont(String name, String encoding, boolean embedded)
/*      */     throws DocumentException, IOException
/*      */   {
/*  461 */     return createFont(name, encoding, embedded, true, null, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont(String name, String encoding, boolean embedded, boolean forceRead)
/*      */     throws DocumentException, IOException
/*      */   {
/*  515 */     return createFont(name, encoding, embedded, true, null, null, forceRead);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont(String name, String encoding, boolean embedded, boolean cached, byte[] ttfAfm, byte[] pfb)
/*      */     throws DocumentException, IOException
/*      */   {
/*  569 */     return createFont(name, encoding, embedded, cached, ttfAfm, pfb, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont(String name, String encoding, boolean embedded, boolean cached, byte[] ttfAfm, byte[] pfb, boolean noThrow)
/*      */     throws DocumentException, IOException
/*      */   {
/*  626 */     return createFont(name, encoding, embedded, cached, ttfAfm, pfb, noThrow, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont(String name, String encoding, boolean embedded, boolean cached, byte[] ttfAfm, byte[] pfb, boolean noThrow, boolean forceRead)
/*      */     throws DocumentException, IOException
/*      */   {
/*  684 */     String nameBase = getBaseName(name);
/*  685 */     encoding = normalizeEncoding(encoding);
/*  686 */     boolean isBuiltinFonts14 = BuiltinFonts14.containsKey(name);
/*  687 */     boolean isCJKFont = isBuiltinFonts14 ? false : CJKFont.isCJKFont(nameBase, encoding);
/*  688 */     if ((isBuiltinFonts14) || (isCJKFont)) {
/*  689 */       embedded = false;
/*  690 */     } else if ((encoding.equals("Identity-H")) || (encoding.equals("Identity-V")))
/*  691 */       embedded = true;
/*  692 */     BaseFont fontFound = null;
/*  693 */     BaseFont fontBuilt = null;
/*  694 */     String key = name + "\n" + encoding + "\n" + embedded;
/*  695 */     if (cached) {
/*  696 */       fontFound = (BaseFont)fontCache.get(key);
/*  697 */       if (fontFound != null)
/*  698 */         return fontFound;
/*      */     }
/*  700 */     if ((isBuiltinFonts14) || (name.toLowerCase().endsWith(".afm")) || (name.toLowerCase().endsWith(".pfm"))) {
/*  701 */       fontBuilt = new Type1Font(name, encoding, embedded, ttfAfm, pfb, forceRead);
/*  702 */       fontBuilt.fastWinansi = encoding.equals("Cp1252");
/*      */     }
/*  704 */     else if ((nameBase.toLowerCase().endsWith(".ttf")) || (nameBase.toLowerCase().endsWith(".otf")) || (nameBase.toLowerCase().indexOf(".ttc,") > 0)) {
/*  705 */       if ((encoding.equals("Identity-H")) || (encoding.equals("Identity-V"))) {
/*  706 */         fontBuilt = new TrueTypeFontUnicode(name, encoding, embedded, ttfAfm, forceRead);
/*      */       } else {
/*  708 */         fontBuilt = new TrueTypeFont(name, encoding, embedded, ttfAfm, false, forceRead);
/*  709 */         fontBuilt.fastWinansi = encoding.equals("Cp1252");
/*      */       }
/*      */     }
/*  712 */     else if (isCJKFont) {
/*  713 */       fontBuilt = new CJKFont(name, encoding, embedded);
/*  714 */     } else { if (noThrow) {
/*  715 */         return null;
/*      */       }
/*  717 */       throw new DocumentException(MessageLocalization.getComposedMessage("font.1.with.2.is.not.recognized", new Object[] { name, encoding })); }
/*  718 */     if (cached) {
/*  719 */       fontFound = (BaseFont)fontCache.get(key);
/*  720 */       if (fontFound != null)
/*  721 */         return fontFound;
/*  722 */       fontCache.putIfAbsent(key, fontBuilt);
/*      */     }
/*  724 */     return fontBuilt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BaseFont createFont(PRIndirectReference fontRef)
/*      */   {
/*  734 */     return new DocumentFont(fontRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isVertical()
/*      */   {
/*  742 */     return this.vertical;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String getBaseName(String name)
/*      */   {
/*  751 */     if (name.endsWith(",Bold"))
/*  752 */       return name.substring(0, name.length() - 5);
/*  753 */     if (name.endsWith(",Italic"))
/*  754 */       return name.substring(0, name.length() - 7);
/*  755 */     if (name.endsWith(",BoldItalic")) {
/*  756 */       return name.substring(0, name.length() - 11);
/*      */     }
/*  758 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String normalizeEncoding(String enc)
/*      */   {
/*  768 */     if ((enc.equals("winansi")) || (enc.equals("")))
/*  769 */       return "Cp1252";
/*  770 */     if (enc.equals("macroman")) {
/*  771 */       return "MacRoman";
/*      */     }
/*  773 */     return enc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void createEncoding()
/*      */   {
/*  780 */     if (this.encoding.startsWith("#")) {
/*  781 */       this.specialMap = new IntHashtable();
/*  782 */       StringTokenizer tok = new StringTokenizer(this.encoding.substring(1), " ,\t\n\r\f");
/*  783 */       if (tok.nextToken().equals("full")) {
/*  784 */         while (tok.hasMoreTokens()) {
/*  785 */           String order = tok.nextToken();
/*  786 */           String name = tok.nextToken();
/*  787 */           char uni = (char)Integer.parseInt(tok.nextToken(), 16);
/*      */           int orderK;
/*  789 */           int orderK; if (order.startsWith("'")) {
/*  790 */             orderK = order.charAt(1);
/*      */           } else
/*  792 */             orderK = Integer.parseInt(order);
/*  793 */           orderK %= 256;
/*  794 */           this.specialMap.put(uni, orderK);
/*  795 */           this.differences[orderK] = name;
/*  796 */           this.unicodeDifferences[orderK] = uni;
/*  797 */           this.widths[orderK] = getRawWidth(uni, name);
/*  798 */           this.charBBoxes[orderK] = getRawCharBBox(uni, name);
/*      */         }
/*      */       }
/*      */       
/*  802 */       int k = 0;
/*  803 */       if (tok.hasMoreTokens())
/*  804 */         k = Integer.parseInt(tok.nextToken());
/*  805 */       while ((tok.hasMoreTokens()) && (k < 256)) {
/*  806 */         String hex = tok.nextToken();
/*  807 */         int uni = Integer.parseInt(hex, 16) % 65536;
/*  808 */         String name = GlyphList.unicodeToName(uni);
/*  809 */         if (name != null) {
/*  810 */           this.specialMap.put(uni, k);
/*  811 */           this.differences[k] = name;
/*  812 */           this.unicodeDifferences[k] = ((char)uni);
/*  813 */           this.widths[k] = getRawWidth(uni, name);
/*  814 */           this.charBBoxes[k] = getRawCharBBox(uni, name);
/*  815 */           k++;
/*      */         }
/*      */       }
/*      */       
/*  819 */       for (int k = 0; k < 256; k++) {
/*  820 */         if (this.differences[k] == null) {
/*  821 */           this.differences[k] = ".notdef";
/*      */         }
/*      */       }
/*      */     }
/*  825 */     else if (this.fontSpecific) {
/*  826 */       for (int k = 0; k < 256; k++) {
/*  827 */         this.widths[k] = getRawWidth(k, null);
/*  828 */         this.charBBoxes[k] = getRawCharBBox(k, null);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  835 */       byte[] b = new byte[1];
/*  836 */       for (int k = 0; k < 256; k++) {
/*  837 */         b[0] = ((byte)k);
/*  838 */         String s = PdfEncodings.convertToString(b, this.encoding);
/*  839 */         char c; char c; if (s.length() > 0) {
/*  840 */           c = s.charAt(0);
/*      */         }
/*      */         else {
/*  843 */           c = '?';
/*      */         }
/*  845 */         String name = GlyphList.unicodeToName(c);
/*  846 */         if (name == null)
/*  847 */           name = ".notdef";
/*  848 */         this.differences[k] = name;
/*  849 */         this.unicodeDifferences[k] = c;
/*  850 */         this.widths[k] = getRawWidth(c, name);
/*  851 */         this.charBBoxes[k] = getRawCharBBox(c, name);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWidth(int char1)
/*      */   {
/*  888 */     if (this.fastWinansi) {
/*  889 */       if ((char1 < 128) || ((char1 >= 160) && (char1 <= 255))) {
/*  890 */         return this.widths[char1];
/*      */       }
/*  892 */       return this.widths[PdfEncodings.winansi.get(char1)];
/*      */     }
/*      */     
/*  895 */     int total = 0;
/*  896 */     byte[] mbytes = convertToBytes(char1);
/*  897 */     for (int k = 0; k < mbytes.length; k++)
/*  898 */       total += this.widths[(0xFF & mbytes[k])];
/*  899 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWidth(String text)
/*      */   {
/*  909 */     int total = 0;
/*  910 */     if (this.fastWinansi) {
/*  911 */       int len = text.length();
/*  912 */       for (int k = 0; k < len; k++) {
/*  913 */         char char1 = text.charAt(k);
/*  914 */         if ((char1 < '') || ((char1 >= ' ') && (char1 <= 'ÿ'))) {
/*  915 */           total += this.widths[char1];
/*      */         } else
/*  917 */           total += this.widths[PdfEncodings.winansi.get(char1)];
/*      */       }
/*  919 */       return total;
/*      */     }
/*      */     
/*  922 */     byte[] mbytes = convertToBytes(text);
/*  923 */     for (int k = 0; k < mbytes.length; k++) {
/*  924 */       total += this.widths[(0xFF & mbytes[k])];
/*      */     }
/*  926 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDescent(String text)
/*      */   {
/*  936 */     int min = 0;
/*  937 */     char[] chars = text.toCharArray();
/*  938 */     for (int k = 0; k < chars.length; k++) {
/*  939 */       int[] bbox = getCharBBox(chars[k]);
/*  940 */       if ((bbox != null) && (bbox[1] < min))
/*  941 */         min = bbox[1];
/*      */     }
/*  943 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAscent(String text)
/*      */   {
/*  953 */     int max = 0;
/*  954 */     char[] chars = text.toCharArray();
/*  955 */     for (int k = 0; k < chars.length; k++) {
/*  956 */       int[] bbox = getCharBBox(chars[k]);
/*  957 */       if ((bbox != null) && (bbox[3] > max))
/*  958 */         max = bbox[3];
/*      */     }
/*  960 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getDescentPoint(String text, float fontSize)
/*      */   {
/*  972 */     return getDescent(text) * 0.001F * fontSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getAscentPoint(String text, float fontSize)
/*      */   {
/*  984 */     return getAscent(text) * 0.001F * fontSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWidthPointKerned(String text, float fontSize)
/*      */   {
/*  996 */     float size = getWidth(text) * 0.001F * fontSize;
/*  997 */     if (!hasKernPairs())
/*  998 */       return size;
/*  999 */     int len = text.length() - 1;
/* 1000 */     int kern = 0;
/* 1001 */     char[] c = text.toCharArray();
/* 1002 */     for (int k = 0; k < len; k++) {
/* 1003 */       kern += getKerning(c[k], c[(k + 1)]);
/*      */     }
/* 1005 */     return size + kern * 0.001F * fontSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWidthPoint(String text, float fontSize)
/*      */   {
/* 1015 */     return getWidth(text) * 0.001F * fontSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWidthPoint(int char1, float fontSize)
/*      */   {
/* 1025 */     return getWidth(char1) * 0.001F * fontSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] convertToBytes(String text)
/*      */   {
/* 1035 */     if (this.directTextToByte)
/* 1036 */       return PdfEncodings.convertToBytes(text, null);
/* 1037 */     if (this.specialMap != null) {
/* 1038 */       byte[] b = new byte[text.length()];
/* 1039 */       int ptr = 0;
/* 1040 */       int length = text.length();
/* 1041 */       for (int k = 0; k < length; k++) {
/* 1042 */         char c = text.charAt(k);
/* 1043 */         if (this.specialMap.containsKey(c))
/* 1044 */           b[(ptr++)] = ((byte)this.specialMap.get(c));
/*      */       }
/* 1046 */       if (ptr < length) {
/* 1047 */         byte[] b2 = new byte[ptr];
/* 1048 */         System.arraycopy(b, 0, b2, 0, ptr);
/* 1049 */         return b2;
/*      */       }
/*      */       
/* 1052 */       return b;
/*      */     }
/* 1054 */     return PdfEncodings.convertToBytes(text, this.encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] convertToBytes(int char1)
/*      */   {
/* 1064 */     if (this.directTextToByte)
/* 1065 */       return PdfEncodings.convertToBytes((char)char1, null);
/* 1066 */     if (this.specialMap != null) {
/* 1067 */       if (this.specialMap.containsKey(char1)) {
/* 1068 */         return new byte[] { (byte)this.specialMap.get(char1) };
/*      */       }
/* 1070 */       return new byte[0];
/*      */     }
/* 1072 */     return PdfEncodings.convertToBytes((char)char1, this.encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/* 1097 */     return this.encoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFontType()
/*      */   {
/* 1126 */     return this.fontType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEmbedded()
/*      */   {
/* 1133 */     return this.embedded;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFontSpecific()
/*      */   {
/* 1140 */     return this.fontSpecific;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static String createSubsetPrefix()
/*      */   {
/* 1147 */     StringBuilder s = new StringBuilder("");
/* 1148 */     for (int k = 0; k < 6; k++)
/* 1149 */       s.append((char)(int)(Math.random() * 26.0D + 65.0D));
/* 1150 */     return s + "+";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   char getUnicodeDifferences(int index)
/*      */   {
/* 1158 */     return this.unicodeDifferences[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSubfamily()
/*      */   {
/* 1174 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[][] getFullFontName(String name, String encoding, byte[] ttfAfm)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1212 */     String nameBase = getBaseName(name);
/* 1213 */     BaseFont fontBuilt = null;
/* 1214 */     if ((nameBase.toLowerCase().endsWith(".ttf")) || (nameBase.toLowerCase().endsWith(".otf")) || (nameBase.toLowerCase().indexOf(".ttc,") > 0)) {
/* 1215 */       fontBuilt = new TrueTypeFont(name, "Cp1252", false, ttfAfm, true, false);
/*      */     } else
/* 1217 */       fontBuilt = createFont(name, encoding, false, false, ttfAfm, null);
/* 1218 */     return fontBuilt.getFullFontName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object[] getAllFontNames(String name, String encoding, byte[] ttfAfm)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1230 */     String nameBase = getBaseName(name);
/* 1231 */     BaseFont fontBuilt = null;
/* 1232 */     if ((nameBase.toLowerCase().endsWith(".ttf")) || (nameBase.toLowerCase().endsWith(".otf")) || (nameBase.toLowerCase().indexOf(".ttc,") > 0)) {
/* 1233 */       fontBuilt = new TrueTypeFont(name, "Cp1252", false, ttfAfm, true, false);
/*      */     } else
/* 1235 */       fontBuilt = createFont(name, encoding, false, false, ttfAfm, null);
/* 1236 */     return new Object[] { fontBuilt.getPostscriptFontName(), fontBuilt.getFamilyFontName(), fontBuilt.getFullFontName() };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[][] getAllNameEntries(String name, String encoding, byte[] ttfAfm)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1249 */     String nameBase = getBaseName(name);
/* 1250 */     BaseFont fontBuilt = null;
/* 1251 */     if ((nameBase.toLowerCase().endsWith(".ttf")) || (nameBase.toLowerCase().endsWith(".otf")) || (nameBase.toLowerCase().indexOf(".ttc,") > 0)) {
/* 1252 */       fontBuilt = new TrueTypeFont(name, "Cp1252", false, ttfAfm, true, false);
/*      */     } else
/* 1254 */       fontBuilt = createFont(name, encoding, false, false, ttfAfm, null);
/* 1255 */     return fontBuilt.getAllNameEntries();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getCodePagesSupported()
/*      */   {
/* 1273 */     return new String[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] enumerateTTCNames(String ttcFile)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1284 */     return new EnumerateTTC(ttcFile).getNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] enumerateTTCNames(byte[] ttcArray)
/*      */     throws DocumentException, IOException
/*      */   {
/* 1295 */     return new EnumerateTTC(ttcArray).getNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int[] getWidths()
/*      */   {
/* 1302 */     return this.widths;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String[] getDifferences()
/*      */   {
/* 1309 */     return this.differences;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public char[] getUnicodeDifferences()
/*      */   {
/* 1316 */     return this.unicodeDifferences;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isForceWidthsOutput()
/*      */   {
/* 1323 */     return this.forceWidthsOutput;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForceWidthsOutput(boolean forceWidthsOutput)
/*      */   {
/* 1332 */     this.forceWidthsOutput = forceWidthsOutput;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDirectTextToByte()
/*      */   {
/* 1340 */     return this.directTextToByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDirectTextToByte(boolean directTextToByte)
/*      */   {
/* 1349 */     this.directTextToByte = directTextToByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSubset()
/*      */   {
/* 1357 */     return this.subset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSubset(boolean subset)
/*      */   {
/* 1368 */     this.subset = subset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getUnicodeEquivalent(int c)
/*      */   {
/* 1378 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCidCode(int c)
/*      */   {
/* 1387 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean charExists(int c)
/*      */   {
/* 1402 */     byte[] b = convertToBytes(c);
/* 1403 */     return b.length > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setCharAdvance(int c, int advance)
/*      */   {
/* 1414 */     byte[] b = convertToBytes(c);
/* 1415 */     if (b.length == 0)
/* 1416 */       return false;
/* 1417 */     this.widths[(0xFF & b[0])] = advance;
/* 1418 */     return true;
/*      */   }
/*      */   
/*      */   private static void addFont(PRIndirectReference fontRef, IntHashtable hits, ArrayList<Object[]> fonts) {
/* 1422 */     PdfObject obj = PdfReader.getPdfObject(fontRef);
/* 1423 */     if ((obj == null) || (!obj.isDictionary()))
/* 1424 */       return;
/* 1425 */     PdfDictionary font = (PdfDictionary)obj;
/* 1426 */     PdfName subtype = font.getAsName(PdfName.SUBTYPE);
/* 1427 */     if ((!PdfName.TYPE1.equals(subtype)) && (!PdfName.TRUETYPE.equals(subtype)) && (!PdfName.TYPE0.equals(subtype)))
/* 1428 */       return;
/* 1429 */     PdfName name = font.getAsName(PdfName.BASEFONT);
/* 1430 */     fonts.add(new Object[] { PdfName.decodeName(name.toString()), fontRef });
/* 1431 */     hits.put(fontRef.getNumber(), 1);
/*      */   }
/*      */   
/*      */   private static void recourseFonts(PdfDictionary page, IntHashtable hits, ArrayList<Object[]> fonts, int level, HashSet<PdfDictionary> visitedResources) {
/*      */     
/* 1436 */     if (level > 50)
/* 1437 */       return;
/* 1438 */     if (page == null)
/* 1439 */       return;
/* 1440 */     PdfDictionary resources = page.getAsDict(PdfName.RESOURCES);
/* 1441 */     if (resources == null)
/* 1442 */       return;
/* 1443 */     PdfDictionary font = resources.getAsDict(PdfName.FONT);
/* 1444 */     Iterator localIterator; if (font != null)
/* 1445 */       for (localIterator = font.getKeys().iterator(); localIterator.hasNext();) { key = (PdfName)localIterator.next();
/* 1446 */         PdfObject ft = font.get(key);
/* 1447 */         if ((ft != null) && (ft.isIndirect()))
/*      */         {
/* 1449 */           int hit = ((PRIndirectReference)ft).getNumber();
/* 1450 */           if (!hits.containsKey(hit))
/*      */           {
/* 1452 */             addFont((PRIndirectReference)ft, hits, fonts); }
/*      */         } }
/*      */     PdfName key;
/* 1455 */     PdfDictionary xobj = resources.getAsDict(PdfName.XOBJECT);
/* 1456 */     if (xobj != null) {
/* 1457 */       if (visitedResources.add(xobj)) {
/* 1458 */         for (PdfName key : xobj.getKeys()) {
/* 1459 */           PdfObject po = xobj.getDirectObject(key);
/* 1460 */           if ((po instanceof PdfDictionary))
/* 1461 */             recourseFonts((PdfDictionary)po, hits, fonts, level, visitedResources);
/*      */         }
/* 1463 */         visitedResources.remove(xobj);
/*      */       } else {
/* 1465 */         throw new ExceptionConverter(new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.resources.tree", new Object[0])));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Object[]> getDocumentFonts(PdfReader reader)
/*      */   {
/* 1477 */     IntHashtable hits = new IntHashtable();
/* 1478 */     ArrayList<Object[]> fonts = new ArrayList();
/* 1479 */     int npages = reader.getNumberOfPages();
/* 1480 */     for (int k = 1; k <= npages; k++)
/* 1481 */       recourseFonts(reader.getPageN(k), hits, fonts, 1, new HashSet());
/* 1482 */     return fonts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Object[]> getDocumentFonts(PdfReader reader, int page)
/*      */   {
/* 1494 */     IntHashtable hits = new IntHashtable();
/* 1495 */     ArrayList<Object[]> fonts = new ArrayList();
/* 1496 */     recourseFonts(reader.getPageN(page), hits, fonts, 1, new HashSet());
/* 1497 */     return fonts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getCharBBox(int c)
/*      */   {
/* 1510 */     byte[] b = convertToBytes(c);
/* 1511 */     if (b.length == 0) {
/* 1512 */       return null;
/*      */     }
/* 1514 */     return this.charBBoxes[(b[0] & 0xFF)];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double[] getFontMatrix()
/*      */   {
/* 1523 */     return DEFAULT_FONT_MATRIX;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void correctArabicAdvance()
/*      */   {
/* 1536 */     for (char c = 'ً'; c <= '٘'; c = (char)(c + '\001'))
/* 1537 */       setCharAdvance(c, 0);
/* 1538 */     setCharAdvance(1648, 0);
/* 1539 */     for (char c = 'ۖ'; c <= 'ۜ'; c = (char)(c + '\001'))
/* 1540 */       setCharAdvance(c, 0);
/* 1541 */     for (char c = '۟'; c <= 'ۤ'; c = (char)(c + '\001'))
/* 1542 */       setCharAdvance(c, 0);
/* 1543 */     for (char c = 'ۧ'; c <= 'ۨ'; c = (char)(c + '\001'))
/* 1544 */       setCharAdvance(c, 0);
/* 1545 */     for (char c = '۪'; c <= 'ۭ'; c = (char)(c + '\001')) {
/* 1546 */       setCharAdvance(c, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSubsetRange(int[] range)
/*      */   {
/* 1556 */     if (this.subsetRanges == null)
/* 1557 */       this.subsetRanges = new ArrayList();
/* 1558 */     this.subsetRanges.add(range);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCompressionLevel()
/*      */   {
/* 1567 */     return this.compressionLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCompressionLevel(int compressionLevel)
/*      */   {
/* 1576 */     if ((compressionLevel < 0) || (compressionLevel > 9)) {
/* 1577 */       this.compressionLevel = -1;
/*      */     } else {
/* 1579 */       this.compressionLevel = compressionLevel;
/*      */     }
/*      */   }
/*      */   
/*      */   abstract int getRawWidth(int paramInt, String paramString);
/*      */   
/*      */   public abstract int getKerning(int paramInt1, int paramInt2);
/*      */   
/*      */   public abstract boolean setKerning(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   abstract void writeFont(PdfWriter paramPdfWriter, PdfIndirectReference paramPdfIndirectReference, Object[] paramArrayOfObject)
/*      */     throws DocumentException, IOException;
/*      */   
/*      */   abstract PdfStream getFullFontStream()
/*      */     throws IOException, DocumentException;
/*      */   
/*      */   public abstract float getFontDescriptor(int paramInt, float paramFloat);
/*      */   
/*      */   public void setFontDescriptor(int key, float value) {}
/*      */   
/*      */   public abstract String getPostscriptFontName();
/*      */   
/*      */   public abstract void setPostscriptFontName(String paramString);
/*      */   
/*      */   public abstract String[][] getFullFontName();
/*      */   
/*      */   public abstract String[][] getAllNameEntries();
/*      */   
/*      */   public abstract String[][] getFamilyFontName();
/*      */   
/*      */   public abstract boolean hasKernPairs();
/*      */   
/*      */   protected abstract int[] getRawCharBBox(int paramInt, String paramString);
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/BaseFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */