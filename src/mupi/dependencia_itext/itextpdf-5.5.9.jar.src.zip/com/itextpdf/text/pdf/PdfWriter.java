/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.AccessibleElementId;
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.DocListener;
/*      */ import com.itextpdf.text.DocWriter;
/*      */ import com.itextpdf.text.Document;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.ImgJBIG2;
/*      */ import com.itextpdf.text.ImgWMF;
/*      */ import com.itextpdf.text.Version;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.io.TempFileCache;
/*      */ import com.itextpdf.text.log.Counter;
/*      */ import com.itextpdf.text.log.CounterFactory;
/*      */ import com.itextpdf.text.pdf.collection.PdfCollection;
/*      */ import com.itextpdf.text.pdf.events.PdfPageEventForwarder;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfAnnotations;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfDocumentActions;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfEncryptionSettings;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfIsoConformance;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfPageActions;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfRunDirection;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfVersion;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfViewerPreferences;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfXConformance;
/*      */ import com.itextpdf.text.pdf.internal.PdfVersionImp;
/*      */ import com.itextpdf.text.pdf.internal.PdfXConformanceImp;
/*      */ import com.itextpdf.text.xml.xmp.XmpWriter;
/*      */ import com.itextpdf.xmp.XMPException;
/*      */ import com.itextpdf.xmp.XMPMeta;
/*      */ import com.itextpdf.xmp.options.PropertyOptions;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.security.cert.Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfWriter
/*      */   extends DocWriter
/*      */   implements PdfViewerPreferences, PdfEncryptionSettings, PdfVersion, PdfDocumentActions, PdfPageActions, PdfRunDirection, PdfAnnotations
/*      */ {
/*      */   public static final int GENERATION_MAX = 65535;
/*      */   
/*      */   public static class PdfBody
/*      */   {
/*      */     private static final int OBJSINSTREAM = 200;
/*      */     protected final TreeSet<PdfCrossReference> xrefs;
/*      */     protected int refnum;
/*      */     protected long position;
/*      */     protected final PdfWriter writer;
/*      */     protected ByteBuffer index;
/*      */     protected ByteBuffer streamObjects;
/*      */     protected int currentObjNum;
/*      */     
/*      */     public static class PdfCrossReference
/*      */       implements Comparable<PdfCrossReference>
/*      */     {
/*      */       private final int type;
/*      */       private final long offset;
/*      */       private final int refnum;
/*      */       private final int generation;
/*      */       
/*      */       public PdfCrossReference(int refnum, long offset, int generation)
/*      */       {
/*  137 */         this.type = 0;
/*  138 */         this.offset = offset;
/*  139 */         this.refnum = refnum;
/*  140 */         this.generation = generation;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public PdfCrossReference(int refnum, long offset)
/*      */       {
/*  150 */         this.type = 1;
/*  151 */         this.offset = offset;
/*  152 */         this.refnum = refnum;
/*  153 */         this.generation = 0;
/*      */       }
/*      */       
/*      */       public PdfCrossReference(int type, int refnum, long offset, int generation) {
/*  157 */         this.type = type;
/*  158 */         this.offset = offset;
/*  159 */         this.refnum = refnum;
/*  160 */         this.generation = generation;
/*      */       }
/*      */       
/*      */       public int getRefnum() {
/*  164 */         return this.refnum;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void toPdf(OutputStream os)
/*      */         throws IOException
/*      */       {
/*  174 */         StringBuffer off = new StringBuffer("0000000000").append(this.offset);
/*  175 */         off.delete(0, off.length() - 10);
/*  176 */         StringBuffer gen = new StringBuffer("00000").append(this.generation);
/*  177 */         gen.delete(0, gen.length() - 5);
/*      */         
/*  179 */         off.append(' ').append(gen).append(this.generation == 65535 ? " f \n" : " n \n");
/*  180 */         os.write(DocWriter.getISOBytes(off.toString()));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void toPdf(int midSize, OutputStream os)
/*      */         throws IOException
/*      */       {
/*  190 */         os.write((byte)this.type);
/*  191 */         for (;;) { midSize--; if (midSize < 0) break;
/*  192 */           os.write((byte)(int)(this.offset >>> 8 * midSize & 0xFF)); }
/*  193 */         os.write((byte)(this.generation >>> 8 & 0xFF));
/*  194 */         os.write((byte)(this.generation & 0xFF));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public int compareTo(PdfCrossReference other)
/*      */       {
/*  201 */         return this.refnum == other.refnum ? 0 : this.refnum < other.refnum ? -1 : 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public boolean equals(Object obj)
/*      */       {
/*  209 */         if ((obj instanceof PdfCrossReference)) {
/*  210 */           PdfCrossReference other = (PdfCrossReference)obj;
/*  211 */           return this.refnum == other.refnum;
/*      */         }
/*      */         
/*  214 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public int hashCode()
/*      */       {
/*  222 */         return this.refnum;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  240 */     protected int numObj = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected PdfBody(PdfWriter writer)
/*      */     {
/*  249 */       this.xrefs = new TreeSet();
/*  250 */       this.xrefs.add(new PdfCrossReference(0, 0L, 65535));
/*  251 */       this.position = writer.getOs().getCounter();
/*  252 */       this.refnum = 1;
/*  253 */       this.writer = writer;
/*      */     }
/*      */     
/*      */ 
/*      */     void setRefnum(int refnum)
/*      */     {
/*  259 */       this.refnum = refnum;
/*      */     }
/*      */     
/*      */     protected PdfCrossReference addToObjStm(PdfObject obj, int nObj) throws IOException {
/*  263 */       if (this.numObj >= 200)
/*  264 */         flushObjStm();
/*  265 */       if (this.index == null) {
/*  266 */         this.index = new ByteBuffer();
/*  267 */         this.streamObjects = new ByteBuffer();
/*  268 */         this.currentObjNum = getIndirectReferenceNumber();
/*  269 */         this.numObj = 0;
/*      */       }
/*  271 */       int p = this.streamObjects.size();
/*  272 */       int idx = this.numObj++;
/*  273 */       PdfEncryption enc = this.writer.crypto;
/*  274 */       this.writer.crypto = null;
/*  275 */       obj.toPdf(this.writer, this.streamObjects);
/*  276 */       this.writer.crypto = enc;
/*  277 */       this.streamObjects.append(' ');
/*  278 */       this.index.append(nObj).append(' ').append(p).append(' ');
/*  279 */       return new PdfCrossReference(2, nObj, this.currentObjNum, idx);
/*      */     }
/*      */     
/*      */     public void flushObjStm() throws IOException {
/*  283 */       if (this.numObj == 0)
/*  284 */         return;
/*  285 */       int first = this.index.size();
/*  286 */       this.index.append(this.streamObjects);
/*  287 */       PdfStream stream = new PdfStream(this.index.toByteArray());
/*  288 */       stream.flateCompress(this.writer.getCompressionLevel());
/*  289 */       stream.put(PdfName.TYPE, PdfName.OBJSTM);
/*  290 */       stream.put(PdfName.N, new PdfNumber(this.numObj));
/*  291 */       stream.put(PdfName.FIRST, new PdfNumber(first));
/*  292 */       add(stream, this.currentObjNum);
/*  293 */       this.index = null;
/*  294 */       this.streamObjects = null;
/*  295 */       this.numObj = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     PdfIndirectObject add(PdfObject object)
/*      */       throws IOException
/*      */     {
/*  313 */       return add(object, getIndirectReferenceNumber());
/*      */     }
/*      */     
/*      */     PdfIndirectObject add(PdfObject object, boolean inObjStm) throws IOException {
/*  317 */       return add(object, getIndirectReferenceNumber(), 0, inObjStm);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfIndirectReference getPdfIndirectReference()
/*      */     {
/*  326 */       return new PdfIndirectReference(0, getIndirectReferenceNumber());
/*      */     }
/*      */     
/*      */     protected int getIndirectReferenceNumber() {
/*  330 */       int n = this.refnum++;
/*  331 */       this.xrefs.add(new PdfCrossReference(n, 0L, 65535));
/*  332 */       return n;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     PdfIndirectObject add(PdfObject object, PdfIndirectReference ref)
/*      */       throws IOException
/*      */     {
/*  352 */       return add(object, ref, true);
/*      */     }
/*      */     
/*      */     PdfIndirectObject add(PdfObject object, PdfIndirectReference ref, boolean inObjStm) throws IOException {
/*  356 */       return add(object, ref.getNumber(), ref.getGeneration(), inObjStm);
/*      */     }
/*      */     
/*      */     PdfIndirectObject add(PdfObject object, int refNumber) throws IOException {
/*  360 */       return add(object, refNumber, 0, true);
/*      */     }
/*      */     
/*      */     protected PdfIndirectObject add(PdfObject object, int refNumber, int generation, boolean inObjStm) throws IOException {
/*  364 */       if ((inObjStm) && (object.canBeInObjStm()) && (this.writer.isFullCompression())) {
/*  365 */         PdfCrossReference pxref = addToObjStm(object, refNumber);
/*  366 */         PdfIndirectObject indirect = new PdfIndirectObject(refNumber, object, this.writer);
/*  367 */         if (!this.xrefs.add(pxref)) {
/*  368 */           this.xrefs.remove(pxref);
/*  369 */           this.xrefs.add(pxref);
/*      */         }
/*  371 */         return indirect;
/*      */       }
/*      */       
/*      */       PdfIndirectObject indirect;
/*  375 */       if (this.writer.isFullCompression()) {
/*  376 */         PdfIndirectObject indirect = new PdfIndirectObject(refNumber, object, this.writer);
/*  377 */         write(indirect, refNumber);
/*      */       }
/*      */       else {
/*  380 */         indirect = new PdfIndirectObject(refNumber, generation, object, this.writer);
/*  381 */         write(indirect, refNumber, generation);
/*      */       }
/*  383 */       return indirect;
/*      */     }
/*      */     
/*      */     protected void write(PdfIndirectObject indirect, int refNumber) throws IOException
/*      */     {
/*  388 */       PdfCrossReference pxref = new PdfCrossReference(refNumber, this.position);
/*  389 */       if (!this.xrefs.add(pxref)) {
/*  390 */         this.xrefs.remove(pxref);
/*  391 */         this.xrefs.add(pxref);
/*      */       }
/*  393 */       indirect.writeTo(this.writer.getOs());
/*  394 */       this.position = this.writer.getOs().getCounter();
/*      */     }
/*      */     
/*      */     protected void write(PdfIndirectObject indirect, int refNumber, int generation) throws IOException {
/*  398 */       PdfCrossReference pxref = new PdfCrossReference(refNumber, this.position, generation);
/*  399 */       if (!this.xrefs.add(pxref)) {
/*  400 */         this.xrefs.remove(pxref);
/*  401 */         this.xrefs.add(pxref);
/*      */       }
/*  403 */       indirect.writeTo(this.writer.getOs());
/*  404 */       this.position = this.writer.getOs().getCounter();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public long offset()
/*      */     {
/*  414 */       return this.position;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int size()
/*      */     {
/*  424 */       return Math.max(((PdfCrossReference)this.xrefs.last()).getRefnum() + 1, this.refnum);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void writeCrossReferenceTable(OutputStream os, PdfIndirectReference root, PdfIndirectReference info, PdfIndirectReference encryption, PdfObject fileID, long prevxref)
/*      */       throws IOException
/*      */     {
/*  439 */       int refNumber = 0;
/*  440 */       if (this.writer.isFullCompression()) {
/*  441 */         flushObjStm();
/*  442 */         refNumber = getIndirectReferenceNumber();
/*  443 */         this.xrefs.add(new PdfCrossReference(refNumber, this.position));
/*      */       }
/*  445 */       PdfCrossReference entry = (PdfCrossReference)this.xrefs.first();
/*  446 */       int first = entry.getRefnum();
/*  447 */       int len = 0;
/*  448 */       ArrayList<Integer> sections = new ArrayList();
/*  449 */       for (PdfCrossReference pdfCrossReference : this.xrefs) {
/*  450 */         entry = pdfCrossReference;
/*  451 */         if (first + len == entry.getRefnum()) {
/*  452 */           len++;
/*      */         } else {
/*  454 */           sections.add(Integer.valueOf(first));
/*  455 */           sections.add(Integer.valueOf(len));
/*  456 */           first = entry.getRefnum();
/*  457 */           len = 1;
/*      */         }
/*      */       }
/*  460 */       sections.add(Integer.valueOf(first));
/*  461 */       sections.add(Integer.valueOf(len));
/*  462 */       if (this.writer.isFullCompression()) {
/*  463 */         int mid = 5;
/*  464 */         long mask = 1095216660480L;
/*  465 */         for (; mid > 1; mid--) {
/*  466 */           if ((mask & this.position) != 0L)
/*      */             break;
/*  468 */           mask >>>= 8;
/*      */         }
/*  470 */         ByteBuffer buf = new ByteBuffer();
/*      */         
/*  472 */         for (Object element : this.xrefs) {
/*  473 */           entry = (PdfCrossReference)element;
/*  474 */           entry.toPdf(mid, buf);
/*      */         }
/*  476 */         PdfStream xr = new PdfStream(buf.toByteArray());
/*  477 */         buf = null;
/*  478 */         xr.flateCompress(this.writer.getCompressionLevel());
/*  479 */         xr.put(PdfName.SIZE, new PdfNumber(size()));
/*  480 */         xr.put(PdfName.ROOT, root);
/*  481 */         if (info != null) {
/*  482 */           xr.put(PdfName.INFO, info);
/*      */         }
/*  484 */         if (encryption != null)
/*  485 */           xr.put(PdfName.ENCRYPT, encryption);
/*  486 */         if (fileID != null)
/*  487 */           xr.put(PdfName.ID, fileID);
/*  488 */         xr.put(PdfName.W, new PdfArray(new int[] { 1, mid, 2 }));
/*  489 */         xr.put(PdfName.TYPE, PdfName.XREF);
/*  490 */         PdfArray idx = new PdfArray();
/*  491 */         for (int k = 0; k < sections.size(); k++)
/*  492 */           idx.add(new PdfNumber(((Integer)sections.get(k)).intValue()));
/*  493 */         xr.put(PdfName.INDEX, idx);
/*  494 */         if (prevxref > 0L)
/*  495 */           xr.put(PdfName.PREV, new PdfNumber(prevxref));
/*  496 */         PdfEncryption enc = this.writer.crypto;
/*  497 */         this.writer.crypto = null;
/*  498 */         PdfIndirectObject indirect = new PdfIndirectObject(refNumber, xr, this.writer);
/*  499 */         indirect.writeTo(this.writer.getOs());
/*  500 */         this.writer.crypto = enc;
/*      */       }
/*      */       else {
/*  503 */         os.write(DocWriter.getISOBytes("xref\n"));
/*  504 */         Object i = this.xrefs.iterator();
/*  505 */         for (int k = 0; k < sections.size(); k += 2) {
/*  506 */           first = ((Integer)sections.get(k)).intValue();
/*  507 */           len = ((Integer)sections.get(k + 1)).intValue();
/*  508 */           os.write(DocWriter.getISOBytes(String.valueOf(first)));
/*  509 */           os.write(DocWriter.getISOBytes(" "));
/*  510 */           os.write(DocWriter.getISOBytes(String.valueOf(len)));
/*  511 */           os.write(10);
/*  512 */           while (len-- > 0) {
/*  513 */             entry = (PdfCrossReference)((Iterator)i).next();
/*  514 */             entry.toPdf(os);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class PdfTrailer
/*      */     extends PdfDictionary
/*      */   {
/*      */     long offset;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfTrailer(int size, long offset, PdfIndirectReference root, PdfIndirectReference info, PdfIndirectReference encryption, PdfObject fileID, long prevxref)
/*      */     {
/*  549 */       this.offset = offset;
/*  550 */       put(PdfName.SIZE, new PdfNumber(size));
/*  551 */       put(PdfName.ROOT, root);
/*  552 */       if (info != null) {
/*  553 */         put(PdfName.INFO, info);
/*      */       }
/*  555 */       if (encryption != null)
/*  556 */         put(PdfName.ENCRYPT, encryption);
/*  557 */       if (fileID != null)
/*  558 */         put(PdfName.ID, fileID);
/*  559 */       if (prevxref > 0L) {
/*  560 */         put(PdfName.PREV, new PdfNumber(prevxref));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void toPdf(PdfWriter writer, OutputStream os)
/*      */       throws IOException
/*      */     {
/*  571 */       PdfWriter.checkPdfIsoConformance(writer, 8, this);
/*  572 */       os.write(DocWriter.getISOBytes("trailer\n"));
/*  573 */       super.toPdf(null, os);
/*  574 */       os.write(10);
/*  575 */       PdfWriter.writeKeyInfo(os);
/*  576 */       os.write(DocWriter.getISOBytes("startxref\n"));
/*  577 */       os.write(DocWriter.getISOBytes(String.valueOf(this.offset)));
/*  578 */       os.write(DocWriter.getISOBytes("\n%%EOF\n"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  583 */   protected static Counter COUNTER = CounterFactory.getCounter(PdfWriter.class);
/*      */   
/*  585 */   protected Counter getCounter() { return COUNTER; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDocument pdf;
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfContentByte directContent;
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfContentByte directContentUnder;
/*      */   
/*      */ 
/*      */   protected PdfWriter() {}
/*      */   
/*      */ 
/*      */ 
/*      */   protected PdfWriter(PdfDocument document, OutputStream os)
/*      */   {
/*  607 */     super(document, os);
/*  608 */     this.pdf = document;
/*  609 */     this.directContentUnder = new PdfContentByte(this);
/*  610 */     this.directContent = this.directContentUnder.getDuplicate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfWriter getInstance(Document document, OutputStream os)
/*      */     throws DocumentException
/*      */   {
/*  625 */     PdfDocument pdf = new PdfDocument();
/*  626 */     document.addDocListener(pdf);
/*  627 */     PdfWriter writer = new PdfWriter(pdf, os);
/*  628 */     pdf.addWriter(writer);
/*  629 */     return writer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfWriter getInstance(Document document, OutputStream os, DocListener listener)
/*      */     throws DocumentException
/*      */   {
/*  644 */     PdfDocument pdf = new PdfDocument();
/*  645 */     pdf.addDocListener(listener);
/*  646 */     document.addDocListener(pdf);
/*  647 */     PdfWriter writer = new PdfWriter(pdf, os);
/*  648 */     pdf.addWriter(writer);
/*  649 */     return writer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfDocument getPdfDocument()
/*      */   {
/*  663 */     return this.pdf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getInfo()
/*      */   {
/*  672 */     return this.pdf.getInfo();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getVerticalPosition(boolean ensureNewLine)
/*      */   {
/*  683 */     return this.pdf.getVerticalPosition(ensureNewLine);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInitialLeading(float leading)
/*      */     throws DocumentException
/*      */   {
/*  694 */     if (this.open)
/*  695 */       throw new DocumentException(MessageLocalization.getComposedMessage("you.can.t.set.the.initial.leading.if.the.document.is.already.open", new Object[0]));
/*  696 */     this.pdf.setLeading(leading);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfBody body;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ICC_Profile colorProfile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary extraCatalog;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfContentByte getDirectContent()
/*      */   {
/*  724 */     if (!this.open)
/*  725 */       throw new RuntimeException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[0]));
/*  726 */     return this.directContent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfContentByte getDirectContentUnder()
/*      */   {
/*  737 */     if (!this.open)
/*  738 */       throw new RuntimeException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[0]));
/*  739 */     return this.directContentUnder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetContent()
/*      */   {
/*  747 */     this.directContent.reset();
/*  748 */     this.directContentUnder.reset();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ICC_Profile getColorProfile()
/*      */   {
/*  767 */     return this.colorProfile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addLocalDestinations(TreeMap<String, PdfDocument.Destination> desto)
/*      */     throws IOException
/*      */   {
/*  777 */     for (Map.Entry<String, PdfDocument.Destination> entry : desto.entrySet()) {
/*  778 */       String name = (String)entry.getKey();
/*  779 */       PdfDocument.Destination dest = (PdfDocument.Destination)entry.getValue();
/*  780 */       PdfDestination destination = dest.destination;
/*  781 */       if (dest.reference == null)
/*  782 */         dest.reference = getPdfIndirectReference();
/*  783 */       if (destination == null) {
/*  784 */         addToBody(new PdfString("invalid_" + name), dest.reference);
/*      */       } else {
/*  786 */         addToBody(destination, dest.reference);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectObject addToBody(PdfObject object)
/*      */     throws IOException
/*      */   {
/*  798 */     PdfIndirectObject iobj = this.body.add(object);
/*  799 */     cacheObject(iobj);
/*  800 */     return iobj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectObject addToBody(PdfObject object, boolean inObjStm)
/*      */     throws IOException
/*      */   {
/*  812 */     PdfIndirectObject iobj = this.body.add(object, inObjStm);
/*  813 */     cacheObject(iobj);
/*  814 */     return iobj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectObject addToBody(PdfObject object, PdfIndirectReference ref)
/*      */     throws IOException
/*      */   {
/*  826 */     PdfIndirectObject iobj = this.body.add(object, ref);
/*  827 */     cacheObject(iobj);
/*  828 */     return iobj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectObject addToBody(PdfObject object, PdfIndirectReference ref, boolean inObjStm)
/*      */     throws IOException
/*      */   {
/*  841 */     PdfIndirectObject iobj = this.body.add(object, ref, inObjStm);
/*  842 */     cacheObject(iobj);
/*  843 */     return iobj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectObject addToBody(PdfObject object, int refNumber)
/*      */     throws IOException
/*      */   {
/*  855 */     PdfIndirectObject iobj = this.body.add(object, refNumber);
/*  856 */     cacheObject(iobj);
/*  857 */     return iobj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectObject addToBody(PdfObject object, int refNumber, boolean inObjStm)
/*      */     throws IOException
/*      */   {
/*  870 */     PdfIndirectObject iobj = this.body.add(object, refNumber, 0, inObjStm);
/*  871 */     cacheObject(iobj);
/*  872 */     return iobj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void cacheObject(PdfIndirectObject iobj) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectReference getPdfIndirectReference()
/*      */   {
/*  889 */     return this.body.getPdfIndirectReference();
/*      */   }
/*      */   
/*      */   protected int getIndirectReferenceNumber() {
/*  893 */     return this.body.getIndirectReferenceNumber();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStreamCounter getOs()
/*      */   {
/*  901 */     return this.os;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfDictionary getCatalog(PdfIndirectReference rootObj)
/*      */   {
/*  916 */     PdfDictionary catalog = this.pdf.getCatalog(rootObj);
/*      */     
/*  918 */     buildStructTreeRootForTagged(catalog);
/*      */     
/*  920 */     if (!this.documentOCG.isEmpty()) {
/*  921 */       fillOCProperties(false);
/*  922 */       catalog.put(PdfName.OCPROPERTIES, this.OCProperties);
/*      */     }
/*  924 */     return catalog;
/*      */   }
/*      */   
/*      */   protected void buildStructTreeRootForTagged(PdfDictionary catalog) {
/*  928 */     if (this.tagged) {
/*      */       try {
/*  930 */         getStructureTreeRoot().buildTree();
/*  931 */         for (AccessibleElementId elementId : this.pdf.getStructElements()) {
/*  932 */           PdfStructureElement element = this.pdf.getStructElement(elementId, false);
/*  933 */           addToBody(element, element.getReference());
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  938 */         throw new ExceptionConverter(e);
/*      */       }
/*  940 */       catalog.put(PdfName.STRUCTTREEROOT, this.structureTreeRoot.getReference());
/*  941 */       PdfDictionary mi = new PdfDictionary();
/*  942 */       mi.put(PdfName.MARKED, PdfBoolean.PDFTRUE);
/*  943 */       if (this.userProperties)
/*  944 */         mi.put(PdfName.USERPROPERTIES, PdfBoolean.PDFTRUE);
/*  945 */       catalog.put(PdfName.MARKINFO, mi);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getExtraCatalog()
/*      */   {
/*  957 */     if (this.extraCatalog == null)
/*  958 */       this.extraCatalog = new PdfDictionary();
/*  959 */     return this.extraCatalog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  972 */   protected PdfPages root = new PdfPages(this);
/*      */   
/*  974 */   protected ArrayList<PdfIndirectReference> pageReferences = new ArrayList();
/*      */   
/*  976 */   protected int currentPageNumber = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  981 */   protected PdfName tabs = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  987 */   protected PdfDictionary pageDictEntries = new PdfDictionary();
/*      */   
/*      */ 
/*      */   private PdfPageEvent pageEvent;
/*      */   
/*      */ 
/*      */ 
/*      */   public void addPageDictEntry(PdfName key, PdfObject object)
/*      */   {
/*  996 */     this.pageDictEntries.put(key, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getPageDictEntries()
/*      */   {
/* 1005 */     return this.pageDictEntries;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetPageDictEntries()
/*      */   {
/* 1013 */     this.pageDictEntries = new PdfDictionary();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLinearPageMode()
/*      */   {
/* 1022 */     this.root.setLinearMode(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int reorderPages(int[] order)
/*      */     throws DocumentException
/*      */   {
/* 1035 */     return this.root.reorderPages(order);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectReference getPageReference(int page)
/*      */   {
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1049 */     if (page < 0)
/* 1050 */       throw new IndexOutOfBoundsException(MessageLocalization.getComposedMessage("the.page.number.must.be.gt.eq.1", new Object[0]));
/*      */     PdfIndirectReference ref;
/* 1052 */     if (page < this.pageReferences.size()) {
/* 1053 */       PdfIndirectReference ref = (PdfIndirectReference)this.pageReferences.get(page);
/* 1054 */       if (ref == null) {
/* 1055 */         ref = this.body.getPdfIndirectReference();
/* 1056 */         this.pageReferences.set(page, ref);
/*      */       }
/*      */     }
/*      */     else {
/* 1060 */       int empty = page - this.pageReferences.size();
/* 1061 */       for (int k = 0; k < empty; k++)
/* 1062 */         this.pageReferences.add(null);
/* 1063 */       ref = this.body.getPdfIndirectReference();
/* 1064 */       this.pageReferences.add(ref);
/*      */     }
/* 1066 */     return ref;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPageNumber()
/*      */   {
/* 1077 */     return this.pdf.getPageNumber();
/*      */   }
/*      */   
/*      */   PdfIndirectReference getCurrentPage() {
/* 1081 */     return getPageReference(this.currentPageNumber);
/*      */   }
/*      */   
/*      */   public int getCurrentPageNumber() {
/* 1085 */     return this.currentPageNumber;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageViewport(PdfArray vp)
/*      */   {
/* 1094 */     addPageDictEntry(PdfName.VP, vp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTabs(PdfName tabs)
/*      */   {
/* 1105 */     this.tabs = tabs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName getTabs()
/*      */   {
/* 1114 */     return this.tabs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfIndirectReference add(PdfPage page, PdfContents contents)
/*      */     throws PdfException
/*      */   {
/* 1130 */     if (!this.open) {
/* 1131 */       throw new PdfException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[0]));
/*      */     }
/*      */     try
/*      */     {
/* 1135 */       object = addToBody(contents);
/*      */     } catch (IOException ioe) {
/*      */       PdfIndirectObject object;
/* 1138 */       throw new ExceptionConverter(ioe); }
/*      */     PdfIndirectObject object;
/* 1140 */     page.add(object.getIndirectReference());
/*      */     
/* 1142 */     if (this.group != null) {
/* 1143 */       page.put(PdfName.GROUP, this.group);
/* 1144 */       this.group = null;
/*      */     }
/* 1146 */     else if (this.rgbTransparencyBlending) {
/* 1147 */       PdfDictionary pp = new PdfDictionary();
/* 1148 */       pp.put(PdfName.TYPE, PdfName.GROUP);
/* 1149 */       pp.put(PdfName.S, PdfName.TRANSPARENCY);
/* 1150 */       pp.put(PdfName.CS, PdfName.DEVICERGB);
/* 1151 */       page.put(PdfName.GROUP, pp);
/*      */     }
/* 1153 */     this.root.addPage(page);
/* 1154 */     this.currentPageNumber += 1;
/* 1155 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageEvent(PdfPageEvent event)
/*      */   {
/* 1176 */     if (event == null) { this.pageEvent = null;
/* 1177 */     } else if (this.pageEvent == null) { this.pageEvent = event;
/* 1178 */     } else if ((this.pageEvent instanceof PdfPageEventForwarder)) { ((PdfPageEventForwarder)this.pageEvent).addPageEvent(event);
/*      */     } else {
/* 1180 */       PdfPageEventForwarder forward = new PdfPageEventForwarder();
/* 1181 */       forward.addPageEvent(this.pageEvent);
/* 1182 */       forward.addPageEvent(event);
/* 1183 */       this.pageEvent = forward;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPageEvent getPageEvent()
/*      */   {
/* 1195 */     return this.pageEvent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1201 */   protected long prevxref = 0L;
/*      */   
/* 1203 */   protected byte[] originalFileID = null;
/*      */   
/*      */   protected List<HashMap<String, Object>> newBookmarks;
/*      */   public static final char VERSION_1_2 = '2';
/*      */   public static final char VERSION_1_3 = '3';
/*      */   public static final char VERSION_1_4 = '4';
/*      */   public static final char VERSION_1_5 = '5';
/*      */   public static final char VERSION_1_6 = '6';
/*      */   public static final char VERSION_1_7 = '7';
/*      */   
/*      */   public void open()
/*      */   {
/* 1215 */     super.open();
/*      */     try {
/* 1217 */       this.pdf_version.writeHeader(this.os);
/* 1218 */       this.body = new PdfBody(this);
/* 1219 */       if ((isPdfX()) && (((PdfXConformanceImp)this.pdfIsoConformance).isPdfX32002())) {
/* 1220 */         PdfDictionary sec = new PdfDictionary();
/* 1221 */         sec.put(PdfName.GAMMA, new PdfArray(new float[] { 2.2F, 2.2F, 2.2F }));
/* 1222 */         sec.put(PdfName.MATRIX, new PdfArray(new float[] { 0.4124F, 0.2126F, 0.0193F, 0.3576F, 0.7152F, 0.1192F, 0.1805F, 0.0722F, 0.9505F }));
/* 1223 */         sec.put(PdfName.WHITEPOINT, new PdfArray(new float[] { 0.9505F, 1.0F, 1.089F }));
/* 1224 */         PdfArray arr = new PdfArray(PdfName.CALRGB);
/* 1225 */         arr.add(sec);
/* 1226 */         setDefaultColorspace(PdfName.DEFAULTRGB, addToBody(arr).getIndirectReference());
/*      */       }
/*      */     }
/*      */     catch (IOException ioe) {
/* 1230 */       throw new ExceptionConverter(ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/* 1246 */     if (this.open) {
/* 1247 */       if (this.currentPageNumber - 1 != this.pageReferences.size()) {
/* 1248 */         throw new RuntimeException("The page " + this.pageReferences.size() + " was requested but the document has only " + (this.currentPageNumber - 1) + " pages.");
/*      */       }
/* 1250 */       this.pdf.close();
/*      */       try {
/* 1252 */         addSharedObjectsToBody();
/* 1253 */         for (PdfOCG layer : this.documentOCG) {
/* 1254 */           addToBody(layer.getPdfObject(), layer.getRef());
/*      */         }
/*      */         
/* 1257 */         PdfIndirectReference rootRef = this.root.writePageTree();
/*      */         
/* 1259 */         PdfDictionary catalog = getCatalog(rootRef);
/* 1260 */         if (!this.documentOCG.isEmpty()) {
/* 1261 */           checkPdfIsoConformance(this, 7, this.OCProperties);
/*      */         }
/* 1263 */         if ((this.xmpMetadata == null) && (this.xmpWriter != null)) {
/*      */           try {
/* 1265 */             ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1266 */             this.xmpWriter.serialize(baos);
/* 1267 */             this.xmpWriter.close();
/* 1268 */             this.xmpMetadata = baos.toByteArray();
/*      */           } catch (IOException exc) {
/* 1270 */             this.xmpWriter = null;
/*      */           } catch (XMPException exc) {
/* 1272 */             this.xmpWriter = null;
/*      */           }
/*      */         }
/* 1275 */         if (this.xmpMetadata != null) {
/* 1276 */           PdfStream xmp = new PdfStream(this.xmpMetadata);
/* 1277 */           xmp.put(PdfName.TYPE, PdfName.METADATA);
/* 1278 */           xmp.put(PdfName.SUBTYPE, PdfName.XML);
/* 1279 */           if ((this.crypto != null) && (!this.crypto.isMetadataEncrypted())) {
/* 1280 */             PdfArray ar = new PdfArray();
/* 1281 */             ar.add(PdfName.CRYPT);
/* 1282 */             xmp.put(PdfName.FILTER, ar);
/*      */           }
/* 1284 */           catalog.put(PdfName.METADATA, this.body.add(xmp).getIndirectReference());
/*      */         }
/*      */         
/* 1287 */         if (isPdfX()) {
/* 1288 */           completeInfoDictionary(getInfo());
/* 1289 */           completeExtraCatalog(getExtraCatalog());
/*      */         }
/*      */         
/* 1292 */         if (this.extraCatalog != null) {
/* 1293 */           catalog.mergeDifferent(this.extraCatalog);
/*      */         }
/*      */         
/* 1296 */         writeOutlines(catalog, false);
/*      */         
/*      */ 
/* 1299 */         PdfIndirectObject indirectCatalog = addToBody(catalog, false);
/*      */         
/* 1301 */         PdfIndirectObject infoObj = addToBody(getInfo(), false);
/*      */         
/*      */ 
/* 1304 */         PdfIndirectReference encryption = null;
/* 1305 */         PdfObject fileID = null;
/* 1306 */         this.body.flushObjStm();
/* 1307 */         boolean isModified = this.originalFileID != null;
/* 1308 */         if (this.crypto != null) {
/* 1309 */           PdfIndirectObject encryptionObject = addToBody(this.crypto.getEncryptionDictionary(), false);
/* 1310 */           encryption = encryptionObject.getIndirectReference();
/* 1311 */           fileID = this.crypto.getFileID(isModified);
/*      */         }
/*      */         else {
/* 1314 */           fileID = PdfEncryption.createInfoId(isModified ? this.originalFileID : PdfEncryption.createDocumentId(), isModified);
/*      */         }
/*      */         
/*      */ 
/* 1318 */         this.body.writeCrossReferenceTable(this.os, indirectCatalog.getIndirectReference(), infoObj
/* 1319 */           .getIndirectReference(), encryption, fileID, this.prevxref);
/*      */         
/*      */ 
/*      */ 
/* 1323 */         if (this.fullCompression) {
/* 1324 */           writeKeyInfo(this.os);
/* 1325 */           this.os.write(getISOBytes("startxref\n"));
/* 1326 */           this.os.write(getISOBytes(String.valueOf(this.body.offset())));
/* 1327 */           this.os.write(getISOBytes("\n%%EOF\n"));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1333 */           PdfTrailer trailer = new PdfTrailer(this.body.size(), this.body.offset(), indirectCatalog.getIndirectReference(), infoObj.getIndirectReference(), encryption, fileID, this.prevxref);
/*      */           
/*      */ 
/* 1336 */           trailer.toPdf(this, this.os);
/*      */         }
/*      */       } catch (IOException ioe) {
/* 1339 */         throw new ExceptionConverter(ioe);
/*      */       } finally {
/* 1341 */         super.close();
/*      */       }
/*      */     }
/* 1344 */     getCounter().written(this.os.getCounter());
/*      */   }
/*      */   
/*      */   protected void addXFormsToBody() throws IOException {
/* 1348 */     for (Object[] objs : this.formXObjects.values()) {
/* 1349 */       PdfTemplate template = (PdfTemplate)objs[1];
/* 1350 */       if ((template == null) || (!(template.getIndirectReference() instanceof PRIndirectReference)))
/*      */       {
/* 1352 */         if ((template != null) && (template.getType() == 1)) {
/* 1353 */           addToBody(template.getFormXObject(this.compressionLevel), template.getIndirectReference());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void addSharedObjectsToBody() throws IOException {
/* 1360 */     for (FontDetails details : this.documentFonts.values()) {
/* 1361 */       details.writeFont(this);
/*      */     }
/*      */     
/* 1364 */     addXFormsToBody();
/*      */     
/* 1366 */     for (PdfReaderInstance element : this.readerInstances.values()) {
/* 1367 */       this.currentPdfReaderInstance = element;
/* 1368 */       this.currentPdfReaderInstance.writeAllPages();
/*      */     }
/* 1370 */     this.currentPdfReaderInstance = null;
/*      */     
/* 1372 */     for (ColorDetails color : this.documentColors.values()) {
/* 1373 */       addToBody(color.getPdfObject(this), color.getIndirectReference());
/*      */     }
/*      */     
/* 1376 */     for (PdfPatternPainter pat : this.documentPatterns.keySet()) {
/* 1377 */       addToBody(pat.getPattern(this.compressionLevel), pat.getIndirectReference());
/*      */     }
/*      */     
/* 1380 */     for (PdfShadingPattern shadingPattern : this.documentShadingPatterns) {
/* 1381 */       shadingPattern.addToBody();
/*      */     }
/*      */     
/* 1384 */     for (PdfShading shading : this.documentShadings) {
/* 1385 */       shading.addToBody();
/*      */     }
/*      */     
/* 1388 */     for (Map.Entry<PdfDictionary, PdfObject[]> entry : this.documentExtGState.entrySet()) {
/* 1389 */       PdfDictionary gstate = (PdfDictionary)entry.getKey();
/* 1390 */       PdfObject[] obj = (PdfObject[])entry.getValue();
/* 1391 */       addToBody(gstate, (PdfIndirectReference)obj[1]);
/*      */     }
/*      */     
/* 1394 */     for (Map.Entry<Object, PdfObject[]> entry : this.documentProperties.entrySet()) {
/* 1395 */       Object prop = entry.getKey();
/* 1396 */       PdfObject[] obj = (PdfObject[])entry.getValue();
/* 1397 */       if ((prop instanceof PdfLayerMembership)) {
/* 1398 */         PdfLayerMembership layer = (PdfLayerMembership)prop;
/* 1399 */         addToBody(layer.getPdfObject(), layer.getRef());
/*      */       }
/* 1401 */       else if (((prop instanceof PdfDictionary)) && (!(prop instanceof PdfLayer))) {
/* 1402 */         addToBody((PdfDictionary)prop, (PdfIndirectReference)obj[1]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfOutline getRootOutline()
/*      */   {
/* 1418 */     return this.directContent.getRootOutline();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOutlines(List<HashMap<String, Object>> outlines)
/*      */   {
/* 1429 */     this.newBookmarks = outlines;
/*      */   }
/*      */   
/*      */   protected void writeOutlines(PdfDictionary catalog, boolean namedAsNames) throws IOException {
/* 1433 */     if ((this.newBookmarks == null) || (this.newBookmarks.isEmpty()))
/* 1434 */       return;
/* 1435 */     PdfDictionary top = new PdfDictionary();
/* 1436 */     PdfIndirectReference topRef = getPdfIndirectReference();
/* 1437 */     Object[] kids = SimpleBookmark.iterateOutlines(this, topRef, this.newBookmarks, namedAsNames);
/* 1438 */     top.put(PdfName.FIRST, (PdfIndirectReference)kids[0]);
/* 1439 */     top.put(PdfName.LAST, (PdfIndirectReference)kids[1]);
/* 1440 */     top.put(PdfName.COUNT, new PdfNumber(((Integer)kids[2]).intValue()));
/* 1441 */     addToBody(top, topRef);
/* 1442 */     catalog.put(PdfName.OUTLINES, topRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1460 */   public static final PdfName PDF_VERSION_1_2 = new PdfName("1.2");
/*      */   
/* 1462 */   public static final PdfName PDF_VERSION_1_3 = new PdfName("1.3");
/*      */   
/* 1464 */   public static final PdfName PDF_VERSION_1_4 = new PdfName("1.4");
/*      */   
/* 1466 */   public static final PdfName PDF_VERSION_1_5 = new PdfName("1.5");
/*      */   
/* 1468 */   public static final PdfName PDF_VERSION_1_6 = new PdfName("1.6");
/*      */   
/* 1470 */   public static final PdfName PDF_VERSION_1_7 = new PdfName("1.7");
/*      */   
/*      */ 
/* 1473 */   protected PdfVersionImp pdf_version = new PdfVersionImp();
/*      */   public static final int PageLayoutSinglePage = 1;
/*      */   
/*      */   public void setPdfVersion(char version) {
/* 1477 */     this.pdf_version.setPdfVersion(version);
/*      */   }
/*      */   
/*      */   public void setAtLeastPdfVersion(char version)
/*      */   {
/* 1482 */     this.pdf_version.setAtLeastPdfVersion(version);
/*      */   }
/*      */   
/*      */   public void setPdfVersion(PdfName version)
/*      */   {
/* 1487 */     this.pdf_version.setPdfVersion(version);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addDeveloperExtension(PdfDeveloperExtension de)
/*      */   {
/* 1495 */     this.pdf_version.addDeveloperExtension(de);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfVersionImp getPdfVersion()
/*      */   {
/* 1503 */     return this.pdf_version;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int PageLayoutOneColumn = 2;
/*      */   
/*      */ 
/*      */   public static final int PageLayoutTwoColumnLeft = 4;
/*      */   
/*      */ 
/*      */   public static final int PageLayoutTwoColumnRight = 8;
/*      */   
/*      */ 
/*      */   public static final int PageLayoutTwoPageLeft = 16;
/*      */   
/*      */ 
/*      */   public static final int PageLayoutTwoPageRight = 32;
/*      */   
/*      */ 
/*      */   public static final int PageModeUseNone = 64;
/*      */   
/*      */ 
/*      */   public static final int PageModeUseOutlines = 128;
/*      */   
/*      */ 
/*      */   public static final int PageModeUseThumbs = 256;
/*      */   
/*      */ 
/*      */   public static final int PageModeFullScreen = 512;
/*      */   
/*      */ 
/*      */   public static final int PageModeUseOC = 1024;
/*      */   
/*      */ 
/*      */   public static final int PageModeUseAttachments = 2048;
/*      */   
/*      */ 
/*      */   public static final int HideToolbar = 4096;
/*      */   
/*      */ 
/*      */   public static final int HideMenubar = 8192;
/*      */   
/*      */ 
/*      */   public static final int HideWindowUI = 16384;
/*      */   
/*      */ 
/*      */   public static final int FitWindow = 32768;
/*      */   
/*      */   public static final int CenterWindow = 65536;
/*      */   
/*      */   public static final int DisplayDocTitle = 131072;
/*      */   
/*      */   public static final int NonFullScreenPageModeUseNone = 262144;
/*      */   
/*      */   public static final int NonFullScreenPageModeUseOutlines = 524288;
/*      */   
/*      */   public static final int NonFullScreenPageModeUseThumbs = 1048576;
/*      */   
/*      */   public static final int NonFullScreenPageModeUseOC = 2097152;
/*      */   
/*      */   public static final int DirectionL2R = 4194304;
/*      */   
/*      */   public static final int DirectionR2L = 8388608;
/*      */   
/*      */   public static final int PrintScalingNone = 16777216;
/*      */   
/*      */   public void setViewerPreferences(int preferences)
/*      */   {
/* 1572 */     this.pdf.setViewerPreferences(preferences);
/*      */   }
/*      */   
/*      */   public void addViewerPreference(PdfName key, PdfObject value)
/*      */   {
/* 1577 */     this.pdf.addViewerPreference(key, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageLabels(PdfPageLabels pageLabels)
/*      */   {
/* 1587 */     this.pdf.setPageLabels(pageLabels);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNamedDestinations(Map<String, String> map, int page_offset)
/*      */   {
/* 1607 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/* 1608 */       String dest = (String)entry.getValue();
/* 1609 */       int page = Integer.parseInt(dest.substring(0, dest.indexOf(" ")));
/* 1610 */       PdfDestination destination = new PdfDestination(dest.substring(dest.indexOf(" ") + 1));
/* 1611 */       addNamedDestination((String)entry.getKey(), page + page_offset, destination);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNamedDestination(String name, int page, PdfDestination dest)
/*      */   {
/* 1623 */     PdfDestination d = new PdfDestination(dest);
/* 1624 */     d.addPage(getPageReference(page));
/* 1625 */     this.pdf.localDestination(name, d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJavaScript(PdfAction js)
/*      */   {
/* 1634 */     this.pdf.addJavaScript(js);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJavaScript(String code, boolean unicode)
/*      */   {
/* 1646 */     addJavaScript(PdfAction.javaScript(code, this, unicode));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJavaScript(String code)
/*      */   {
/* 1655 */     addJavaScript(code, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJavaScript(String name, PdfAction js)
/*      */   {
/* 1664 */     this.pdf.addJavaScript(name, js);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJavaScript(String name, String code, boolean unicode)
/*      */   {
/* 1677 */     addJavaScript(name, PdfAction.javaScript(code, this, unicode));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJavaScript(String name, String code)
/*      */   {
/* 1687 */     addJavaScript(name, code, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFileAttachment(String description, byte[] fileStore, String file, String fileDisplay)
/*      */     throws IOException
/*      */   {
/* 1701 */     addFileAttachment(description, PdfFileSpecification.fileEmbedded(this, file, fileDisplay, fileStore));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFileAttachment(String description, PdfFileSpecification fs)
/*      */     throws IOException
/*      */   {
/* 1711 */     this.pdf.addFileAttachment(description, fs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFileAttachment(PdfFileSpecification fs)
/*      */     throws IOException
/*      */   {
/* 1720 */     addFileAttachment(null, fs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1726 */   public static final PdfName DOCUMENT_CLOSE = PdfName.WC;
/*      */   
/* 1728 */   public static final PdfName WILL_SAVE = PdfName.WS;
/*      */   
/* 1730 */   public static final PdfName DID_SAVE = PdfName.DS;
/*      */   
/* 1732 */   public static final PdfName WILL_PRINT = PdfName.WP;
/*      */   
/* 1734 */   public static final PdfName DID_PRINT = PdfName.DP;
/*      */   public static final int SIGNATURE_EXISTS = 1;
/*      */   public static final int SIGNATURE_APPEND_ONLY = 2;
/*      */   
/* 1738 */   public void setOpenAction(String name) { this.pdf.setOpenAction(name); }
/*      */   
/*      */ 
/*      */   public void setOpenAction(PdfAction action)
/*      */   {
/* 1743 */     this.pdf.setOpenAction(action);
/*      */   }
/*      */   
/*      */   public void setAdditionalAction(PdfName actionType, PdfAction action) throws DocumentException
/*      */   {
/* 1748 */     if ((!actionType.equals(DOCUMENT_CLOSE)) && 
/* 1749 */       (!actionType.equals(WILL_SAVE)) && 
/* 1750 */       (!actionType.equals(DID_SAVE)) && 
/* 1751 */       (!actionType.equals(WILL_PRINT)) && 
/* 1752 */       (!actionType.equals(DID_PRINT))) {
/* 1753 */       throw new DocumentException(MessageLocalization.getComposedMessage("invalid.additional.action.type.1", new Object[] { actionType.toString() }));
/*      */     }
/* 1755 */     this.pdf.addAdditionalAction(actionType, action);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCollection(PdfCollection collection)
/*      */   {
/* 1765 */     setAtLeastPdfVersion('7');
/* 1766 */     this.pdf.setCollection(collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAcroForm getAcroForm()
/*      */   {
/* 1778 */     return this.pdf.getAcroForm();
/*      */   }
/*      */   
/*      */   public void addAnnotation(PdfAnnotation annot)
/*      */   {
/* 1783 */     this.pdf.addAnnotation(annot);
/*      */   }
/*      */   
/*      */   void addAnnotation(PdfAnnotation annot, int page) {
/* 1787 */     addAnnotation(annot);
/*      */   }
/*      */   
/*      */   public void addCalculationOrder(PdfFormField annot)
/*      */   {
/* 1792 */     this.pdf.addCalculationOrder(annot);
/*      */   }
/*      */   
/*      */   public void setSigFlags(int f)
/*      */   {
/* 1797 */     this.pdf.setSigFlags(f);
/*      */   }
/*      */   
/*      */   public void setLanguage(String language) {
/* 1801 */     this.pdf.setLanguage(language);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1807 */   protected byte[] xmpMetadata = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXmpMetadata(byte[] xmpMetadata)
/*      */   {
/* 1814 */     this.xmpMetadata = xmpMetadata;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageXmpMetadata(byte[] xmpMetadata)
/*      */     throws IOException
/*      */   {
/* 1823 */     this.pdf.setXmpMetadata(xmpMetadata);
/*      */   }
/*      */   
/* 1826 */   protected XmpWriter xmpWriter = null;
/*      */   public static final int PDFXNONE = 0;
/*      */   
/* 1829 */   public XmpWriter getXmpWriter() { return this.xmpWriter; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createXmpMetadata()
/*      */   {
/*      */     try
/*      */     {
/* 1839 */       this.xmpWriter = createXmpWriter(null, this.pdf.getInfo());
/* 1840 */       if (isTagged()) {
/*      */         try {
/* 1842 */           this.xmpWriter.getXmpMeta().setPropertyInteger("http://www.aiim.org/pdfua/ns/id/", "part", 1, new PropertyOptions(1073741824));
/*      */         } catch (XMPException e) {
/* 1844 */           throw new ExceptionConverter(e);
/*      */         }
/*      */       }
/* 1847 */       this.xmpMetadata = null;
/*      */     } catch (IOException ioe) {
/* 1849 */       ioe.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int PDFX1A2001 = 1;
/*      */   
/*      */ 
/*      */   public static final int PDFX32002 = 2;
/*      */   
/*      */ 
/* 1862 */   protected PdfIsoConformance pdfIsoConformance = initPdfIsoConformance();
/*      */   public static final int STANDARD_ENCRYPTION_40 = 0;
/*      */   
/* 1865 */   protected PdfIsoConformance initPdfIsoConformance() { return new PdfXConformanceImp(this); }
/*      */   
/*      */ 
/*      */   public void setPDFXConformance(int pdfx)
/*      */   {
/* 1870 */     if (!(this.pdfIsoConformance instanceof PdfXConformanceImp))
/* 1871 */       return;
/* 1872 */     if (((PdfXConformance)this.pdfIsoConformance).getPDFXConformance() == pdfx)
/* 1873 */       return;
/* 1874 */     if (this.pdf.isOpen())
/* 1875 */       throw new PdfXConformanceException(MessageLocalization.getComposedMessage("pdfx.conformance.can.only.be.set.before.opening.the.document", new Object[0]));
/* 1876 */     if (this.crypto != null)
/* 1877 */       throw new PdfXConformanceException(MessageLocalization.getComposedMessage("a.pdfx.conforming.document.cannot.be.encrypted", new Object[0]));
/* 1878 */     if (pdfx != 0)
/* 1879 */       setPdfVersion('3');
/* 1880 */     ((PdfXConformance)this.pdfIsoConformance).setPDFXConformance(pdfx);
/*      */   }
/*      */   
/*      */   public int getPDFXConformance()
/*      */   {
/* 1885 */     if ((this.pdfIsoConformance instanceof PdfXConformanceImp)) {
/* 1886 */       return ((PdfXConformance)this.pdfIsoConformance).getPDFXConformance();
/*      */     }
/* 1888 */     return 0;
/*      */   }
/*      */   
/*      */   public boolean isPdfX()
/*      */   {
/* 1893 */     if ((this.pdfIsoConformance instanceof PdfXConformanceImp)) {
/* 1894 */       return ((PdfXConformance)this.pdfIsoConformance).isPdfX();
/*      */     }
/* 1896 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPdfIso()
/*      */   {
/* 1904 */     return this.pdfIsoConformance.isPdfIso();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOutputIntents(String outputConditionIdentifier, String outputCondition, String registryName, String info, ICC_Profile colorProfile)
/*      */     throws IOException
/*      */   {
/* 1921 */     checkPdfIsoConformance(this, 19, colorProfile);
/* 1922 */     getExtraCatalog();
/* 1923 */     PdfDictionary out = new PdfDictionary(PdfName.OUTPUTINTENT);
/* 1924 */     if (outputCondition != null)
/* 1925 */       out.put(PdfName.OUTPUTCONDITION, new PdfString(outputCondition, "UnicodeBig"));
/* 1926 */     if (outputConditionIdentifier != null)
/* 1927 */       out.put(PdfName.OUTPUTCONDITIONIDENTIFIER, new PdfString(outputConditionIdentifier, "UnicodeBig"));
/* 1928 */     if (registryName != null)
/* 1929 */       out.put(PdfName.REGISTRYNAME, new PdfString(registryName, "UnicodeBig"));
/* 1930 */     if (info != null)
/* 1931 */       out.put(PdfName.INFO, new PdfString(info, "UnicodeBig"));
/* 1932 */     if (colorProfile != null) {
/* 1933 */       PdfStream stream = new PdfICCBased(colorProfile, this.compressionLevel);
/* 1934 */       out.put(PdfName.DESTOUTPUTPROFILE, addToBody(stream).getIndirectReference());
/*      */     }
/*      */     
/* 1937 */     out.put(PdfName.S, PdfName.GTS_PDFX);
/*      */     
/* 1939 */     this.extraCatalog.put(PdfName.OUTPUTINTENTS, new PdfArray(out));
/* 1940 */     this.colorProfile = colorProfile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOutputIntents(String outputConditionIdentifier, String outputCondition, String registryName, String info, byte[] destOutputProfile)
/*      */     throws IOException
/*      */   {
/* 1958 */     ICC_Profile colorProfile = destOutputProfile == null ? null : ICC_Profile.getInstance(destOutputProfile);
/* 1959 */     setOutputIntents(outputConditionIdentifier, outputCondition, registryName, info, colorProfile);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setOutputIntents(PdfReader reader, boolean checkExistence)
/*      */     throws IOException
/*      */   {
/* 1974 */     PdfDictionary catalog = reader.getCatalog();
/* 1975 */     PdfArray outs = catalog.getAsArray(PdfName.OUTPUTINTENTS);
/* 1976 */     if (outs == null)
/* 1977 */       return false;
/* 1978 */     if (outs.isEmpty())
/* 1979 */       return false;
/* 1980 */     PdfDictionary out = outs.getAsDict(0);
/* 1981 */     PdfObject obj = PdfReader.getPdfObject(out.get(PdfName.S));
/* 1982 */     if ((obj == null) || (!PdfName.GTS_PDFX.equals(obj)))
/* 1983 */       return false;
/* 1984 */     if (checkExistence)
/* 1985 */       return true;
/* 1986 */     PRStream stream = (PRStream)PdfReader.getPdfObject(out.get(PdfName.DESTOUTPUTPROFILE));
/* 1987 */     byte[] destProfile = null;
/* 1988 */     if (stream != null) {
/* 1989 */       destProfile = PdfReader.getStreamBytes(stream);
/*      */     }
/* 1991 */     setOutputIntents(getNameString(out, PdfName.OUTPUTCONDITIONIDENTIFIER), getNameString(out, PdfName.OUTPUTCONDITION), 
/* 1992 */       getNameString(out, PdfName.REGISTRYNAME), getNameString(out, PdfName.INFO), destProfile);
/* 1993 */     return true;
/*      */   }
/*      */   
/*      */   protected static String getNameString(PdfDictionary dic, PdfName key) {
/* 1997 */     PdfObject obj = PdfReader.getPdfObject(dic.get(key));
/* 1998 */     if ((obj == null) || (!obj.isString()))
/* 1999 */       return null;
/* 2000 */     return ((PdfString)obj).toUnicodeString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int STANDARD_ENCRYPTION_128 = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ENCRYPTION_AES_128 = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ENCRYPTION_AES_256 = 3;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int ENCRYPTION_MASK = 7;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int DO_NOT_ENCRYPT_METADATA = 8;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int EMBEDDED_FILES_ONLY = 24;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_PRINTING = 2052;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_MODIFY_CONTENTS = 8;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_COPY = 16;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_MODIFY_ANNOTATIONS = 32;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_FILL_IN = 256;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_SCREENREADERS = 512;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_ASSEMBLY = 1024;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int ALLOW_DEGRADED_PRINTING = 4;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowPrinting = 2052;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowModifyContents = 8;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowCopy = 16;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowModifyAnnotations = 32;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowFillIn = 256;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowScreenReaders = 512;
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowAssembly = 1024;
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AllowDegradedPrinting = 4;
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public static final boolean STRENGTH40BITS = false;
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public static final boolean STRENGTH128BITS = true;
/*      */   
/*      */ 
/*      */   protected PdfEncryption crypto;
/*      */   
/*      */ 
/*      */   PdfEncryption getEncryption()
/*      */   {
/* 2113 */     return this.crypto;
/*      */   }
/*      */   
/*      */   public void setEncryption(byte[] userPassword, byte[] ownerPassword, int permissions, int encryptionType) throws DocumentException
/*      */   {
/* 2118 */     if (this.pdf.isOpen())
/* 2119 */       throw new DocumentException(MessageLocalization.getComposedMessage("encryption.can.only.be.added.before.opening.the.document", new Object[0]));
/* 2120 */     this.crypto = new PdfEncryption();
/* 2121 */     this.crypto.setCryptoMode(encryptionType, 0);
/* 2122 */     this.crypto.setupAllKeys(userPassword, ownerPassword, permissions);
/*      */   }
/*      */   
/*      */   public void setEncryption(Certificate[] certs, int[] permissions, int encryptionType) throws DocumentException
/*      */   {
/* 2127 */     if (this.pdf.isOpen())
/* 2128 */       throw new DocumentException(MessageLocalization.getComposedMessage("encryption.can.only.be.added.before.opening.the.document", new Object[0]));
/* 2129 */     this.crypto = new PdfEncryption();
/* 2130 */     if (certs != null) {
/* 2131 */       for (int i = 0; i < certs.length; i++) {
/* 2132 */         this.crypto.addRecipient(certs[i], permissions[i]);
/*      */       }
/*      */     }
/* 2135 */     this.crypto.setCryptoMode(encryptionType, 0);
/* 2136 */     this.crypto.getEncryptionDictionary();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setEncryption(byte[] userPassword, byte[] ownerPassword, int permissions, boolean strength128Bits)
/*      */     throws DocumentException
/*      */   {
/* 2155 */     setEncryption(userPassword, ownerPassword, permissions, strength128Bits ? 1 : 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setEncryption(boolean strength, String userPassword, String ownerPassword, int permissions)
/*      */     throws DocumentException
/*      */   {
/* 2174 */     setEncryption(getISOBytes(userPassword), getISOBytes(ownerPassword), permissions, strength ? 1 : 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setEncryption(int encryptionType, String userPassword, String ownerPassword, int permissions)
/*      */     throws DocumentException
/*      */   {
/* 2194 */     setEncryption(getISOBytes(userPassword), getISOBytes(ownerPassword), permissions, encryptionType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2200 */   protected boolean fullCompression = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFullCompression()
/*      */   {
/* 2207 */     return this.fullCompression;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFullCompression()
/*      */     throws DocumentException
/*      */   {
/* 2216 */     if (this.open)
/* 2217 */       throw new DocumentException(MessageLocalization.getComposedMessage("you.can.t.set.the.full.compression.if.the.document.is.already.open", new Object[0]));
/* 2218 */     this.fullCompression = true;
/* 2219 */     setAtLeastPdfVersion('5');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2226 */   protected int compressionLevel = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCompressionLevel()
/*      */   {
/* 2234 */     return this.compressionLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCompressionLevel(int compressionLevel)
/*      */   {
/* 2243 */     if ((compressionLevel < 0) || (compressionLevel > 9)) {
/* 2244 */       this.compressionLevel = -1;
/*      */     } else {
/* 2246 */       this.compressionLevel = compressionLevel;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2252 */   protected LinkedHashMap<BaseFont, FontDetails> documentFonts = new LinkedHashMap();
/*      */   
/*      */ 
/* 2255 */   protected int fontNumber = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   FontDetails addSimple(BaseFont bf)
/*      */   {
/* 2266 */     FontDetails ret = (FontDetails)this.documentFonts.get(bf);
/* 2267 */     if (ret == null) {
/* 2268 */       checkPdfIsoConformance(this, 4, bf);
/* 2269 */       if (bf.getFontType() == 4) {
/* 2270 */         ret = new FontDetails(new PdfName("F" + this.fontNumber++), ((DocumentFont)bf).getIndirectReference(), bf);
/*      */       } else {
/* 2272 */         ret = new FontDetails(new PdfName("F" + this.fontNumber++), this.body.getPdfIndirectReference(), bf);
/*      */       }
/* 2274 */       this.documentFonts.put(bf, ret);
/*      */     }
/* 2276 */     return ret;
/*      */   }
/*      */   
/*      */   void eliminateFontSubset(PdfDictionary fonts) {
/* 2280 */     for (Object element : this.documentFonts.values()) {
/* 2281 */       FontDetails ft = (FontDetails)element;
/* 2282 */       if (fonts.get(ft.getFontName()) != null) {
/* 2283 */         ft.setSubset(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2291 */   protected HashMap<PdfIndirectReference, Object[]> formXObjects = new HashMap();
/*      */   
/*      */ 
/* 2294 */   protected int formXObjectsCounter = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfName addDirectTemplateSimple(PdfTemplate template, PdfName forcedName)
/*      */   {
/* 2304 */     PdfIndirectReference ref = template.getIndirectReference();
/* 2305 */     Object[] obj = (Object[])this.formXObjects.get(ref);
/* 2306 */     PdfName name = null;
/*      */     try {
/* 2308 */       if (obj == null) {
/* 2309 */         if (forcedName == null) {
/* 2310 */           name = new PdfName("Xf" + this.formXObjectsCounter);
/* 2311 */           this.formXObjectsCounter += 1;
/*      */         }
/*      */         else {
/* 2314 */           name = forcedName; }
/* 2315 */         if (template.getType() == 2)
/*      */         {
/* 2317 */           PdfImportedPage ip = (PdfImportedPage)template;
/* 2318 */           PdfReader r = ip.getPdfReaderInstance().getReader();
/* 2319 */           if (!this.readerInstances.containsKey(r)) {
/* 2320 */             this.readerInstances.put(r, ip.getPdfReaderInstance());
/*      */           }
/* 2322 */           template = null;
/*      */         }
/* 2324 */         this.formXObjects.put(ref, new Object[] { name, template });
/*      */       }
/*      */       else {
/* 2327 */         name = (PdfName)obj[0];
/*      */       }
/*      */     } catch (Exception e) {
/* 2330 */       throw new ExceptionConverter(e);
/*      */     }
/* 2332 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void releaseTemplate(PdfTemplate tp)
/*      */     throws IOException
/*      */   {
/* 2344 */     PdfIndirectReference ref = tp.getIndirectReference();
/* 2345 */     Object[] objs = (Object[])this.formXObjects.get(ref);
/* 2346 */     if ((objs == null) || (objs[1] == null))
/* 2347 */       return;
/* 2348 */     PdfTemplate template = (PdfTemplate)objs[1];
/* 2349 */     if ((template.getIndirectReference() instanceof PRIndirectReference))
/* 2350 */       return;
/* 2351 */     if (template.getType() == 1) {
/* 2352 */       addToBody(template.getFormXObject(this.compressionLevel), template.getIndirectReference());
/* 2353 */       objs[1] = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2363 */   protected HashMap<PdfReader, PdfReaderInstance> readerInstances = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfReaderInstance currentPdfReaderInstance;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfImportedPage getImportedPage(PdfReader reader, int pageNumber)
/*      */   {
/* 2375 */     return getPdfReaderInstance(reader).getImportedPage(pageNumber);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PdfReaderInstance getPdfReaderInstance(PdfReader reader)
/*      */   {
/* 2387 */     PdfReaderInstance inst = (PdfReaderInstance)this.readerInstances.get(reader);
/* 2388 */     if (inst == null) {
/* 2389 */       inst = reader.getPdfReaderInstance(this);
/* 2390 */       this.readerInstances.put(reader, inst);
/*      */     }
/* 2392 */     return inst;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void freeReader(PdfReader reader)
/*      */     throws IOException
/*      */   {
/* 2405 */     this.currentPdfReaderInstance = ((PdfReaderInstance)this.readerInstances.get(reader));
/* 2406 */     if (this.currentPdfReaderInstance == null)
/* 2407 */       return;
/* 2408 */     this.currentPdfReaderInstance.writeAllPages();
/* 2409 */     this.currentPdfReaderInstance = null;
/* 2410 */     this.readerInstances.remove(reader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getCurrentDocumentSize()
/*      */   {
/* 2423 */     return this.body.offset() + this.body.size() * 20 + 72L;
/*      */   }
/*      */   
/*      */ 
/*      */   protected int getNewObjectNumber(PdfReader reader, int number, int generation)
/*      */   {
/* 2429 */     if ((this.currentPdfReaderInstance == null) || (this.currentPdfReaderInstance.getReader() != reader)) {
/* 2430 */       this.currentPdfReaderInstance = getPdfReaderInstance(reader);
/*      */     }
/* 2432 */     return this.currentPdfReaderInstance.getNewObjectNumber(number, generation);
/*      */   }
/*      */   
/*      */   RandomAccessFileOrArray getReaderFile(PdfReader reader) {
/* 2436 */     return this.currentPdfReaderInstance.getReaderFile();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2442 */   protected HashMap<ICachedColorSpace, ColorDetails> documentColors = new HashMap();
/*      */   
/*      */ 
/* 2445 */   protected int colorNumber = 1;
/*      */   
/*      */   PdfName getColorspaceName() {
/* 2448 */     return new PdfName("CS" + this.colorNumber++);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ColorDetails addSimple(ICachedColorSpace spc)
/*      */   {
/* 2458 */     ColorDetails ret = (ColorDetails)this.documentColors.get(spc);
/* 2459 */     if (ret == null) {
/* 2460 */       ret = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), spc);
/* 2461 */       if ((spc instanceof IPdfSpecialColorSpace)) {
/* 2462 */         ((IPdfSpecialColorSpace)spc).getColorantDetails(this);
/*      */       }
/* 2464 */       this.documentColors.put(spc, ret);
/*      */     }
/* 2466 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2472 */   protected HashMap<PdfPatternPainter, PdfName> documentPatterns = new HashMap();
/*      */   
/*      */ 
/* 2475 */   protected int patternNumber = 1;
/*      */   
/*      */   PdfName addSimplePattern(PdfPatternPainter painter) {
/* 2478 */     PdfName name = (PdfName)this.documentPatterns.get(painter);
/*      */     try {
/* 2480 */       if (name == null) {
/* 2481 */         name = new PdfName("P" + this.patternNumber);
/* 2482 */         this.patternNumber += 1;
/* 2483 */         this.documentPatterns.put(painter, name);
/*      */       }
/*      */     } catch (Exception e) {
/* 2486 */       throw new ExceptionConverter(e);
/*      */     }
/* 2488 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2493 */   protected HashSet<PdfShadingPattern> documentShadingPatterns = new HashSet();
/*      */   
/*      */   void addSimpleShadingPattern(PdfShadingPattern shading) {
/* 2496 */     if (!this.documentShadingPatterns.contains(shading)) {
/* 2497 */       shading.setName(this.patternNumber);
/* 2498 */       this.patternNumber += 1;
/* 2499 */       this.documentShadingPatterns.add(shading);
/* 2500 */       addSimpleShading(shading.getShading());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2506 */   protected HashSet<PdfShading> documentShadings = new HashSet();
/*      */   
/*      */   void addSimpleShading(PdfShading shading) {
/* 2509 */     if (!this.documentShadings.contains(shading)) {
/* 2510 */       this.documentShadings.add(shading);
/* 2511 */       shading.setName(this.documentShadings.size());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2517 */   protected HashMap<PdfDictionary, PdfObject[]> documentExtGState = new HashMap();
/*      */   
/*      */   PdfObject[] addSimpleExtGState(PdfDictionary gstate) {
/* 2520 */     if (!this.documentExtGState.containsKey(gstate)) {
/* 2521 */       this.documentExtGState.put(gstate, new PdfObject[] { new PdfName("GS" + (this.documentExtGState.size() + 1)), getPdfIndirectReference() });
/*      */     }
/* 2523 */     return (PdfObject[])this.documentExtGState.get(gstate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2528 */   protected HashMap<Object, PdfObject[]> documentProperties = new HashMap();
/*      */   
/* 2530 */   PdfObject[] addSimpleProperty(Object prop, PdfIndirectReference refi) { if (!this.documentProperties.containsKey(prop)) {
/* 2531 */       if ((prop instanceof PdfOCG))
/* 2532 */         checkPdfIsoConformance(this, 7, prop);
/* 2533 */       this.documentProperties.put(prop, new PdfObject[] { new PdfName("Pr" + (this.documentProperties.size() + 1)), refi });
/*      */     }
/* 2535 */     return (PdfObject[])this.documentProperties.get(prop);
/*      */   }
/*      */   
/*      */   boolean propertyExists(Object prop) {
/* 2539 */     return this.documentProperties.containsKey(prop);
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int markAll = 0;
/*      */   
/*      */   public static final int markInlineElementsOnly = 1;
/*      */   
/* 2547 */   protected boolean tagged = false;
/* 2548 */   protected int taggingMode = 1;
/*      */   
/*      */   protected PdfStructureTreeRoot structureTreeRoot;
/*      */   
/*      */ 
/*      */   public void setTagged()
/*      */   {
/* 2555 */     setTagged(1);
/*      */   }
/*      */   
/*      */   public void setTagged(int taggingMode) {
/* 2559 */     if (this.open)
/* 2560 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("tagging.must.be.set.before.opening.the.document", new Object[0]));
/* 2561 */     this.tagged = true;
/* 2562 */     this.taggingMode = taggingMode;
/*      */   }
/*      */   
/*      */   public boolean needToBeMarkedInContent(IAccessibleElement element) {
/* 2566 */     if ((this.taggingMode & 0x1) != 0) {
/* 2567 */       if ((element.isInline()) || (PdfName.ARTIFACT.equals(element.getRole()))) {
/* 2568 */         return true;
/*      */       }
/* 2570 */       return false;
/*      */     }
/* 2572 */     return true;
/*      */   }
/*      */   
/*      */   public void checkElementRole(IAccessibleElement element, IAccessibleElement parent) {
/* 2576 */     if ((parent != null) && ((parent.getRole() == null) || (PdfName.ARTIFACT.equals(parent.getRole())))) {
/* 2577 */       element.setRole(null);
/* 2578 */     } else if (((this.taggingMode & 0x1) != 0) && 
/* 2579 */       (element.isInline()) && (element.getRole() == null) && ((parent == null) || (!parent.isInline()))) {
/* 2580 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("inline.elements.with.role.null.are.not.allowed", new Object[0]));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTagged()
/*      */   {
/* 2589 */     return this.tagged;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void flushTaggedObjects()
/*      */     throws IOException
/*      */   {}
/*      */   
/*      */ 
/*      */   protected void flushAcroFields()
/*      */     throws IOException, BadPdfFormatException
/*      */   {}
/*      */   
/*      */ 
/*      */   public PdfStructureTreeRoot getStructureTreeRoot()
/*      */   {
/* 2605 */     if ((this.tagged) && (this.structureTreeRoot == null))
/* 2606 */       this.structureTreeRoot = new PdfStructureTreeRoot(this);
/* 2607 */     return this.structureTreeRoot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2612 */   protected LinkedHashSet<PdfOCG> documentOCG = new LinkedHashSet();
/*      */   
/* 2614 */   protected ArrayList<PdfOCG> documentOCGorder = new ArrayList();
/*      */   
/*      */   protected PdfOCProperties OCProperties;
/*      */   
/* 2618 */   protected PdfArray OCGRadioGroup = new PdfArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2623 */   protected PdfArray OCGLocked = new PdfArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfOCProperties getOCProperties()
/*      */   {
/* 2633 */     fillOCProperties(true);
/* 2634 */     return this.OCProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addOCGRadioGroup(ArrayList<PdfLayer> group)
/*      */   {
/* 2646 */     PdfArray ar = new PdfArray();
/* 2647 */     for (int k = 0; k < group.size(); k++) {
/* 2648 */       PdfLayer layer = (PdfLayer)group.get(k);
/* 2649 */       if (layer.getTitle() == null)
/* 2650 */         ar.add(layer.getRef());
/*      */     }
/* 2652 */     if (ar.size() == 0)
/* 2653 */       return;
/* 2654 */     this.OCGRadioGroup.add(ar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lockLayer(PdfLayer layer)
/*      */   {
/* 2666 */     this.OCGLocked.add(layer.getRef());
/*      */   }
/*      */   
/*      */   private static void getOCGOrder(PdfArray order, PdfLayer layer) {
/* 2670 */     if (!layer.isOnPanel())
/* 2671 */       return;
/* 2672 */     if (layer.getTitle() == null)
/* 2673 */       order.add(layer.getRef());
/* 2674 */     ArrayList<PdfLayer> children = layer.getChildren();
/* 2675 */     if (children == null)
/* 2676 */       return;
/* 2677 */     PdfArray kids = new PdfArray();
/* 2678 */     if (layer.getTitle() != null)
/* 2679 */       kids.add(new PdfString(layer.getTitle(), "UnicodeBig"));
/* 2680 */     for (int k = 0; k < children.size(); k++) {
/* 2681 */       getOCGOrder(kids, (PdfLayer)children.get(k));
/*      */     }
/* 2683 */     if (kids.size() > 0)
/* 2684 */       order.add(kids);
/*      */   }
/*      */   
/*      */   private void addASEvent(PdfName event, PdfName category) {
/* 2688 */     PdfArray arr = new PdfArray();
/* 2689 */     for (Object element : this.documentOCG) {
/* 2690 */       PdfLayer layer = (PdfLayer)element;
/* 2691 */       PdfDictionary usage = layer.getAsDict(PdfName.USAGE);
/* 2692 */       if ((usage != null) && (usage.get(category) != null))
/* 2693 */         arr.add(layer.getRef());
/*      */     }
/* 2695 */     if (arr.size() == 0)
/* 2696 */       return;
/* 2697 */     PdfDictionary d = this.OCProperties.getAsDict(PdfName.D);
/* 2698 */     PdfArray arras = d.getAsArray(PdfName.AS);
/* 2699 */     if (arras == null) {
/* 2700 */       arras = new PdfArray();
/* 2701 */       d.put(PdfName.AS, arras);
/*      */     }
/* 2703 */     PdfDictionary as = new PdfDictionary();
/* 2704 */     as.put(PdfName.EVENT, event);
/* 2705 */     as.put(PdfName.CATEGORY, new PdfArray(category));
/* 2706 */     as.put(PdfName.OCGS, arr);
/* 2707 */     arras.add(as);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void fillOCProperties(boolean erase)
/*      */   {
/* 2715 */     if (this.OCProperties == null)
/* 2716 */       this.OCProperties = new PdfOCProperties();
/* 2717 */     if (erase) {
/* 2718 */       this.OCProperties.remove(PdfName.OCGS);
/* 2719 */       this.OCProperties.remove(PdfName.D);
/*      */     }
/* 2721 */     if (this.OCProperties.get(PdfName.OCGS) == null) {
/* 2722 */       PdfArray gr = new PdfArray();
/* 2723 */       for (Object element : this.documentOCG) {
/* 2724 */         PdfLayer layer = (PdfLayer)element;
/* 2725 */         gr.add(layer.getRef());
/*      */       }
/* 2727 */       this.OCProperties.put(PdfName.OCGS, gr);
/*      */     }
/* 2729 */     if (this.OCProperties.get(PdfName.D) != null)
/* 2730 */       return;
/* 2731 */     ArrayList<PdfOCG> docOrder = new ArrayList(this.documentOCGorder);
/* 2732 */     for (Object it = docOrder.iterator(); ((Iterator)it).hasNext();) {
/* 2733 */       layer = (PdfLayer)((Iterator)it).next();
/* 2734 */       if (layer.getParent() != null)
/* 2735 */         ((Iterator)it).remove(); }
/*      */     PdfLayer layer;
/* 2737 */     PdfArray order = new PdfArray();
/* 2738 */     for (Object element : docOrder) {
/* 2739 */       PdfLayer layer = (PdfLayer)element;
/* 2740 */       getOCGOrder(order, layer);
/*      */     }
/* 2742 */     PdfDictionary d = new PdfDictionary();
/* 2743 */     this.OCProperties.put(PdfName.D, d);
/* 2744 */     d.put(PdfName.ORDER, order);
/* 2745 */     PdfString name; if ((docOrder.size() > 0) && ((docOrder.get(0) instanceof PdfLayer))) {
/* 2746 */       PdfLayer l = (PdfLayer)docOrder.get(0);
/* 2747 */       name = l.getAsString(PdfName.NAME);
/* 2748 */       if (name != null) {
/* 2749 */         d.put(PdfName.NAME, name);
/*      */       }
/*      */     }
/* 2752 */     PdfArray gr = new PdfArray();
/* 2753 */     for (Object element : this.documentOCG) {
/* 2754 */       PdfLayer layer = (PdfLayer)element;
/* 2755 */       if (!layer.isOn())
/* 2756 */         gr.add(layer.getRef());
/*      */     }
/* 2758 */     if (gr.size() > 0)
/* 2759 */       d.put(PdfName.OFF, gr);
/* 2760 */     if (this.OCGRadioGroup.size() > 0)
/* 2761 */       d.put(PdfName.RBGROUPS, this.OCGRadioGroup);
/* 2762 */     if (this.OCGLocked.size() > 0)
/* 2763 */       d.put(PdfName.LOCKED, this.OCGLocked);
/* 2764 */     addASEvent(PdfName.VIEW, PdfName.ZOOM);
/* 2765 */     addASEvent(PdfName.VIEW, PdfName.VIEW);
/* 2766 */     addASEvent(PdfName.PRINT, PdfName.PRINT);
/* 2767 */     addASEvent(PdfName.EXPORT, PdfName.EXPORT);
/* 2768 */     d.put(PdfName.LISTMODE, PdfName.VISIBLEPAGES);
/*      */   }
/*      */   
/*      */   void registerLayer(PdfOCG layer) {
/* 2772 */     checkPdfIsoConformance(this, 7, layer);
/* 2773 */     if ((layer instanceof PdfLayer)) {
/* 2774 */       PdfLayer la = (PdfLayer)layer;
/* 2775 */       if (la.getTitle() == null) {
/* 2776 */         if (!this.documentOCG.contains(layer)) {
/* 2777 */           this.documentOCG.add(layer);
/* 2778 */           this.documentOCGorder.add(layer);
/*      */         }
/*      */       }
/*      */       else {
/* 2782 */         this.documentOCGorder.add(layer);
/*      */       }
/*      */     }
/*      */     else {
/* 2786 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("only.pdflayer.is.accepted", new Object[0]));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public com.itextpdf.text.Rectangle getPageSize()
/*      */   {
/* 2798 */     return this.pdf.getPageSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCropBoxSize(com.itextpdf.text.Rectangle crop)
/*      */   {
/* 2808 */     this.pdf.setCropBoxSize(crop);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoxSize(String boxName, com.itextpdf.text.Rectangle size)
/*      */   {
/* 2818 */     this.pdf.setBoxSize(boxName, size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public com.itextpdf.text.Rectangle getBoxSize(String boxName)
/*      */   {
/* 2827 */     return this.pdf.getBoxSize(boxName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public com.itextpdf.text.Rectangle getBoxSize(String boxName, com.itextpdf.text.Rectangle intersectingRectangle)
/*      */   {
/* 2842 */     com.itextpdf.text.Rectangle pdfRectangle = this.pdf.getBoxSize(boxName);
/*      */     
/* 2844 */     if ((pdfRectangle == null) || (intersectingRectangle == null)) {
/* 2845 */       return null;
/*      */     }
/*      */     
/* 2848 */     com.itextpdf.awt.geom.Rectangle boxRect = new com.itextpdf.awt.geom.Rectangle(pdfRectangle);
/* 2849 */     com.itextpdf.awt.geom.Rectangle intRect = new com.itextpdf.awt.geom.Rectangle(intersectingRectangle);
/* 2850 */     com.itextpdf.awt.geom.Rectangle outRect = boxRect.intersection(intRect);
/*      */     
/* 2852 */     if (outRect.isEmpty()) {
/* 2853 */       return null;
/*      */     }
/*      */     
/* 2856 */     com.itextpdf.text.Rectangle output = new com.itextpdf.text.Rectangle((float)outRect.getX(), (float)outRect.getY(), (float)(outRect.getX() + outRect.getWidth()), (float)(outRect.getY() + outRect.getHeight()));
/* 2857 */     output.normalize();
/* 2858 */     return output;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageEmpty(boolean pageEmpty)
/*      */   {
/* 2871 */     if (pageEmpty)
/* 2872 */       return;
/* 2873 */     this.pdf.setPageEmpty(pageEmpty);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPageEmpty()
/*      */   {
/* 2882 */     return this.pdf.isPageEmpty();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2888 */   public static final PdfName PAGE_OPEN = PdfName.O;
/*      */   
/* 2890 */   public static final PdfName PAGE_CLOSE = PdfName.C;
/*      */   protected PdfDictionary group;
/*      */   
/*      */   public void setPageAction(PdfName actionType, PdfAction action) throws DocumentException {
/* 2894 */     if ((!actionType.equals(PAGE_OPEN)) && (!actionType.equals(PAGE_CLOSE)))
/* 2895 */       throw new DocumentException(MessageLocalization.getComposedMessage("invalid.page.additional.action.type.1", new Object[] { actionType.toString() }));
/* 2896 */     this.pdf.setPageAction(actionType, action);
/*      */   }
/*      */   
/*      */   public void setDuration(int seconds)
/*      */   {
/* 2901 */     this.pdf.setDuration(seconds);
/*      */   }
/*      */   
/*      */   public void setTransition(PdfTransition transition)
/*      */   {
/* 2906 */     this.pdf.setTransition(transition);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setThumbnail(Image image)
/*      */     throws PdfException, DocumentException
/*      */   {
/* 2918 */     this.pdf.setThumbnail(image);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final float SPACE_CHAR_RATIO_DEFAULT = 2.5F;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final float NO_SPACE_CHAR_RATIO = 1.0E7F;
/*      */   
/*      */ 
/*      */ 
/*      */   public PdfDictionary getGroup()
/*      */   {
/* 2935 */     return this.group;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGroup(PdfDictionary group)
/*      */   {
/* 2943 */     this.group = group;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2957 */   private float spaceCharRatio = 2.5F;
/*      */   public static final int RUN_DIRECTION_DEFAULT = 0;
/*      */   public static final int RUN_DIRECTION_NO_BIDI = 1;
/*      */   public static final int RUN_DIRECTION_LTR = 2;
/*      */   public static final int RUN_DIRECTION_RTL = 3;
/*      */   
/*      */   public float getSpaceCharRatio()
/*      */   {
/* 2965 */     return this.spaceCharRatio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpaceCharRatio(float spaceCharRatio)
/*      */   {
/* 2977 */     if (spaceCharRatio < 0.001F) {
/* 2978 */       this.spaceCharRatio = 0.001F;
/*      */     } else {
/* 2980 */       this.spaceCharRatio = spaceCharRatio;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2998 */   protected int runDirection = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunDirection(int runDirection)
/*      */   {
/* 3006 */     if ((runDirection < 1) || (runDirection > 3))
/* 3007 */       throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.run.direction.1", runDirection));
/* 3008 */     this.runDirection = runDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRunDirection()
/*      */   {
/* 3016 */     return this.runDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserunit(float userunit)
/*      */     throws DocumentException
/*      */   {
/* 3030 */     if ((userunit < 1.0F) || (userunit > 75000.0F)) throw new DocumentException(MessageLocalization.getComposedMessage("userunit.should.be.a.value.between.1.and.75000", new Object[0]));
/* 3031 */     addPageDictEntry(PdfName.USERUNIT, new PdfNumber(userunit));
/* 3032 */     setAtLeastPdfVersion('6');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3039 */   protected PdfDictionary defaultColorspace = new PdfDictionary();
/*      */   
/*      */ 
/*      */ 
/*      */   public PdfDictionary getDefaultColorspace()
/*      */   {
/* 3045 */     return this.defaultColorspace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultColorspace(PdfName key, PdfObject cs)
/*      */   {
/* 3060 */     if ((cs == null) || (cs.isNull()))
/* 3061 */       this.defaultColorspace.remove(key);
/* 3062 */     this.defaultColorspace.put(key, cs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 3067 */   protected HashMap<ColorDetails, ColorDetails> documentSpotPatterns = new HashMap();
/*      */   protected ColorDetails patternColorspaceRGB;
/*      */   protected ColorDetails patternColorspaceGRAY;
/*      */   protected ColorDetails patternColorspaceCMYK;
/*      */   
/*      */   ColorDetails addSimplePatternColorspace(BaseColor color) {
/* 3073 */     int type = ExtendedColor.getType(color);
/* 3074 */     if ((type == 4) || (type == 5))
/* 3075 */       throw new RuntimeException(MessageLocalization.getComposedMessage("an.uncolored.tile.pattern.can.not.have.another.pattern.or.shading.as.color", new Object[0]));
/*      */     try {
/* 3077 */       switch (type) {
/*      */       case 0: 
/* 3079 */         if (this.patternColorspaceRGB == null) {
/* 3080 */           this.patternColorspaceRGB = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
/* 3081 */           PdfArray array = new PdfArray(PdfName.PATTERN);
/* 3082 */           array.add(PdfName.DEVICERGB);
/* 3083 */           addToBody(array, this.patternColorspaceRGB.getIndirectReference());
/*      */         }
/* 3085 */         return this.patternColorspaceRGB;
/*      */       case 2: 
/* 3087 */         if (this.patternColorspaceCMYK == null) {
/* 3088 */           this.patternColorspaceCMYK = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
/* 3089 */           PdfArray array = new PdfArray(PdfName.PATTERN);
/* 3090 */           array.add(PdfName.DEVICECMYK);
/* 3091 */           addToBody(array, this.patternColorspaceCMYK.getIndirectReference());
/*      */         }
/* 3093 */         return this.patternColorspaceCMYK;
/*      */       case 1: 
/* 3095 */         if (this.patternColorspaceGRAY == null) {
/* 3096 */           this.patternColorspaceGRAY = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
/* 3097 */           PdfArray array = new PdfArray(PdfName.PATTERN);
/* 3098 */           array.add(PdfName.DEVICEGRAY);
/* 3099 */           addToBody(array, this.patternColorspaceGRAY.getIndirectReference());
/*      */         }
/* 3101 */         return this.patternColorspaceGRAY;
/*      */       case 3: 
/* 3103 */         ColorDetails details = addSimple(((SpotColor)color).getPdfSpotColor());
/* 3104 */         ColorDetails patternDetails = (ColorDetails)this.documentSpotPatterns.get(details);
/* 3105 */         if (patternDetails == null) {
/* 3106 */           patternDetails = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
/* 3107 */           PdfArray array = new PdfArray(PdfName.PATTERN);
/* 3108 */           array.add(details.getIndirectReference());
/* 3109 */           addToBody(array, patternDetails.getIndirectReference());
/* 3110 */           this.documentSpotPatterns.put(details, patternDetails);
/*      */         }
/* 3112 */         return patternDetails;
/*      */       }
/*      */       
/* 3115 */       throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.color.type", new Object[0]));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 3119 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isStrictImageSequence()
/*      */   {
/* 3130 */     return this.pdf.isStrictImageSequence();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStrictImageSequence(boolean strictImageSequence)
/*      */   {
/* 3140 */     this.pdf.setStrictImageSequence(strictImageSequence);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void clearTextWrap()
/*      */     throws DocumentException
/*      */   {
/* 3148 */     this.pdf.clearTextWrap();
/*      */   }
/*      */   
/*      */ 
/* 3152 */   protected PdfDictionary imageDictionary = new PdfDictionary();
/*      */   
/*      */ 
/* 3155 */   private final HashMap<Long, PdfName> images = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName addDirectImageSimple(Image image)
/*      */     throws PdfException, DocumentException
/*      */   {
/* 3168 */     return addDirectImageSimple(image, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName addDirectImageSimple(Image image, PdfIndirectReference fixedRef)
/*      */     throws PdfException, DocumentException
/*      */   {
/*      */     PdfName name;
/*      */     
/*      */ 
/*      */ 
/*      */     PdfName name;
/*      */     
/*      */ 
/*      */ 
/* 3185 */     if (this.images.containsKey(image.getMySerialId())) {
/* 3186 */       name = (PdfName)this.images.get(image.getMySerialId());
/*      */     }
/*      */     else
/*      */     {
/* 3190 */       if (image.isImgTemplate()) {
/* 3191 */         PdfName name = new PdfName("img" + this.images.size());
/* 3192 */         if ((image instanceof ImgWMF)) {
/*      */           try {
/* 3194 */             ImgWMF wmf = (ImgWMF)image;
/* 3195 */             wmf.readWMF(PdfTemplate.createTemplate(this, 0.0F, 0.0F));
/*      */           }
/*      */           catch (Exception e) {
/* 3198 */             throw new DocumentException(e);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 3203 */         PdfIndirectReference dref = image.getDirectReference();
/* 3204 */         if (dref != null) {
/* 3205 */           PdfName rname = new PdfName("img" + this.images.size());
/* 3206 */           this.images.put(image.getMySerialId(), rname);
/* 3207 */           this.imageDictionary.put(rname, dref);
/* 3208 */           return rname;
/*      */         }
/* 3210 */         Image maskImage = image.getImageMask();
/* 3211 */         PdfIndirectReference maskRef = null;
/* 3212 */         if (maskImage != null) {
/* 3213 */           PdfName mname = (PdfName)this.images.get(maskImage.getMySerialId());
/* 3214 */           maskRef = getImageReference(mname);
/*      */         }
/* 3216 */         PdfImage i = new PdfImage(image, "img" + this.images.size(), maskRef);
/* 3217 */         if ((image instanceof ImgJBIG2)) {
/* 3218 */           byte[] globals = ((ImgJBIG2)image).getGlobalBytes();
/* 3219 */           if (globals != null) {
/* 3220 */             PdfDictionary decodeparms = new PdfDictionary();
/* 3221 */             decodeparms.put(PdfName.JBIG2GLOBALS, getReferenceJBIG2Globals(globals));
/* 3222 */             i.put(PdfName.DECODEPARMS, decodeparms);
/*      */           }
/*      */         }
/* 3225 */         if (image.hasICCProfile()) {
/* 3226 */           PdfICCBased icc = new PdfICCBased(image.getICCProfile(), image.getCompressionLevel());
/* 3227 */           PdfIndirectReference iccRef = add(icc);
/* 3228 */           PdfArray iccArray = new PdfArray();
/* 3229 */           iccArray.add(PdfName.ICCBASED);
/* 3230 */           iccArray.add(iccRef);
/* 3231 */           PdfArray colorspace = i.getAsArray(PdfName.COLORSPACE);
/* 3232 */           if (colorspace != null) {
/* 3233 */             if ((colorspace.size() > 1) && (PdfName.INDEXED.equals(colorspace.getPdfObject(0)))) {
/* 3234 */               colorspace.set(1, iccArray);
/*      */             } else {
/* 3236 */               i.put(PdfName.COLORSPACE, iccArray);
/*      */             }
/*      */           } else
/* 3239 */             i.put(PdfName.COLORSPACE, iccArray);
/*      */         }
/* 3241 */         add(i, fixedRef);
/* 3242 */         name = i.name();
/*      */       }
/* 3244 */       this.images.put(image.getMySerialId(), name);
/*      */     }
/* 3246 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfIndirectReference add(PdfImage pdfImage, PdfIndirectReference fixedRef)
/*      */     throws PdfException
/*      */   {
/* 3259 */     if (!this.imageDictionary.contains(pdfImage.name())) {
/* 3260 */       checkPdfIsoConformance(this, 5, pdfImage);
/* 3261 */       if ((fixedRef instanceof PRIndirectReference)) {
/* 3262 */         PRIndirectReference r2 = (PRIndirectReference)fixedRef;
/* 3263 */         fixedRef = new PdfIndirectReference(0, getNewObjectNumber(r2.getReader(), r2.getNumber(), r2.getGeneration()));
/*      */       }
/*      */       try {
/* 3266 */         if (fixedRef == null) {
/* 3267 */           fixedRef = addToBody(pdfImage).getIndirectReference();
/*      */         } else {
/* 3269 */           addToBody(pdfImage, fixedRef);
/*      */         }
/*      */       } catch (IOException ioe) {
/* 3272 */         throw new ExceptionConverter(ioe);
/*      */       }
/* 3274 */       this.imageDictionary.put(pdfImage.name(), fixedRef);
/* 3275 */       return fixedRef;
/*      */     }
/* 3277 */     return (PdfIndirectReference)this.imageDictionary.get(pdfImage.name());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PdfIndirectReference getImageReference(PdfName name)
/*      */   {
/* 3288 */     return (PdfIndirectReference)this.imageDictionary.get(name);
/*      */   }
/*      */   
/*      */   protected PdfIndirectReference add(PdfICCBased icc)
/*      */   {
/*      */     try {
/* 3294 */       object = addToBody(icc);
/*      */     } catch (IOException ioe) {
/*      */       PdfIndirectObject object;
/* 3297 */       throw new ExceptionConverter(ioe); }
/*      */     PdfIndirectObject object;
/* 3299 */     return object.getIndirectReference();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3306 */   protected HashMap<PdfStream, PdfIndirectReference> JBIG2Globals = new HashMap();
/*      */   
/*      */   private boolean userProperties;
/*      */   
/*      */   private boolean rgbTransparencyBlending;
/*      */   
/*      */ 
/*      */   protected PdfIndirectReference getReferenceJBIG2Globals(byte[] content)
/*      */   {
/* 3315 */     if (content == null) return null;
/* 3316 */     for (PdfStream stream : this.JBIG2Globals.keySet()) {
/* 3317 */       if (Arrays.equals(content, stream.getBytes())) {
/* 3318 */         return (PdfIndirectReference)this.JBIG2Globals.get(stream);
/*      */       }
/*      */     }
/* 3321 */     PdfStream stream = new PdfStream(content);
/*      */     try
/*      */     {
/* 3324 */       ref = addToBody(stream);
/*      */     } catch (IOException e) { PdfIndirectObject ref;
/* 3326 */       return null; }
/*      */     PdfIndirectObject ref;
/* 3328 */     this.JBIG2Globals.put(stream, ref.getIndirectReference());
/* 3329 */     return ref.getIndirectReference();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUserProperties()
/*      */   {
/* 3343 */     return this.userProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserProperties(boolean userProperties)
/*      */   {
/* 3351 */     this.userProperties = userProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRgbTransparencyBlending()
/*      */   {
/* 3366 */     return this.rgbTransparencyBlending;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRgbTransparencyBlending(boolean rgbTransparencyBlending)
/*      */   {
/* 3380 */     this.rgbTransparencyBlending = rgbTransparencyBlending;
/*      */   }
/*      */   
/*      */   protected static void writeKeyInfo(OutputStream os) throws IOException {
/* 3384 */     Version version = Version.getInstance();
/* 3385 */     String k = version.getKey();
/* 3386 */     if (k == null) {
/* 3387 */       k = "iText";
/*      */     }
/* 3389 */     os.write(getISOBytes(String.format("%%%s-%s\n", new Object[] { k, version.getRelease() })));
/*      */   }
/*      */   
/*      */ 
/* 3393 */   protected TtfUnicodeWriter ttfUnicodeWriter = null;
/*      */   
/*      */   protected TtfUnicodeWriter getTtfUnicodeWriter() {
/* 3396 */     if (this.ttfUnicodeWriter == null)
/* 3397 */       this.ttfUnicodeWriter = new TtfUnicodeWriter(this);
/* 3398 */     return this.ttfUnicodeWriter;
/*      */   }
/*      */   
/*      */   protected XmpWriter createXmpWriter(ByteArrayOutputStream baos, PdfDictionary info) throws IOException {
/* 3402 */     return new XmpWriter(baos, info);
/*      */   }
/*      */   
/*      */   protected XmpWriter createXmpWriter(ByteArrayOutputStream baos, HashMap<String, String> info) throws IOException {
/* 3406 */     return new XmpWriter(baos, info);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAnnotation createAnnotation(com.itextpdf.text.Rectangle rect, PdfName subtype)
/*      */   {
/* 3418 */     PdfAnnotation a = new PdfAnnotation(this, rect);
/* 3419 */     if (subtype != null)
/* 3420 */       a.put(PdfName.SUBTYPE, subtype);
/* 3421 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAnnotation createAnnotation(float llx, float lly, float urx, float ury, PdfString title, PdfString content, PdfName subtype)
/*      */   {
/* 3438 */     PdfAnnotation a = new PdfAnnotation(this, llx, lly, urx, ury, title, content);
/* 3439 */     if (subtype != null)
/* 3440 */       a.put(PdfName.SUBTYPE, subtype);
/* 3441 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAnnotation createAnnotation(float llx, float lly, float urx, float ury, PdfAction action, PdfName subtype)
/*      */   {
/* 3457 */     PdfAnnotation a = new PdfAnnotation(this, llx, lly, urx, ury, action);
/* 3458 */     if (subtype != null)
/* 3459 */       a.put(PdfName.SUBTYPE, subtype);
/* 3460 */     return a;
/*      */   }
/*      */   
/*      */   public static void checkPdfIsoConformance(PdfWriter writer, int key, Object obj1) {
/* 3464 */     if (writer != null)
/* 3465 */       writer.checkPdfIsoConformance(key, obj1);
/*      */   }
/*      */   
/*      */   public void checkPdfIsoConformance(int key, Object obj1) {
/* 3469 */     this.pdfIsoConformance.checkPdfIsoConformance(key, obj1);
/*      */   }
/*      */   
/*      */   private void completeInfoDictionary(PdfDictionary info) {
/* 3473 */     if (isPdfX()) {
/* 3474 */       if (info.get(PdfName.GTS_PDFXVERSION) == null)
/* 3475 */         if (((PdfXConformanceImp)this.pdfIsoConformance).isPdfX1A2001()) {
/* 3476 */           info.put(PdfName.GTS_PDFXVERSION, new PdfString("PDF/X-1:2001"));
/* 3477 */           info.put(new PdfName("GTS_PDFXConformance"), new PdfString("PDF/X-1a:2001"));
/*      */         }
/* 3479 */         else if (((PdfXConformanceImp)this.pdfIsoConformance).isPdfX32002()) {
/* 3480 */           info.put(PdfName.GTS_PDFXVERSION, new PdfString("PDF/X-3:2002"));
/*      */         }
/* 3482 */       if (info.get(PdfName.TITLE) == null) {
/* 3483 */         info.put(PdfName.TITLE, new PdfString("Pdf document"));
/*      */       }
/* 3485 */       if (info.get(PdfName.CREATOR) == null) {
/* 3486 */         info.put(PdfName.CREATOR, new PdfString("Unknown"));
/*      */       }
/* 3488 */       if (info.get(PdfName.TRAPPED) == null) {
/* 3489 */         info.put(PdfName.TRAPPED, new PdfName("False"));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void completeExtraCatalog(PdfDictionary extraCatalog) {
/* 3495 */     if ((isPdfX()) && 
/* 3496 */       (extraCatalog.get(PdfName.OUTPUTINTENTS) == null)) {
/* 3497 */       PdfDictionary out = new PdfDictionary(PdfName.OUTPUTINTENT);
/* 3498 */       out.put(PdfName.OUTPUTCONDITION, new PdfString("SWOP CGATS TR 001-1995"));
/* 3499 */       out.put(PdfName.OUTPUTCONDITIONIDENTIFIER, new PdfString("CGATS TR 001"));
/* 3500 */       out.put(PdfName.REGISTRYNAME, new PdfString("http://www.color.org"));
/* 3501 */       out.put(PdfName.INFO, new PdfString(""));
/* 3502 */       out.put(PdfName.S, PdfName.GTS_PDFX);
/* 3503 */       extraCatalog.put(PdfName.OUTPUTINTENTS, new PdfArray(out));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 3508 */   private static final List<PdfName> standardStructElems_1_4 = Arrays.asList(new PdfName[] { PdfName.DOCUMENT, PdfName.PART, PdfName.ART, PdfName.SECT, PdfName.DIV, PdfName.BLOCKQUOTE, PdfName.CAPTION, PdfName.TOC, PdfName.TOCI, PdfName.INDEX, PdfName.NONSTRUCT, PdfName.PRIVATE, PdfName.P, PdfName.H, PdfName.H1, PdfName.H2, PdfName.H3, PdfName.H4, PdfName.H5, PdfName.H6, PdfName.L, PdfName.LBL, PdfName.LI, PdfName.LBODY, PdfName.TABLE, PdfName.TR, PdfName.TH, PdfName.TD, PdfName.SPAN, PdfName.QUOTE, PdfName.NOTE, PdfName.REFERENCE, PdfName.BIBENTRY, PdfName.CODE, PdfName.LINK, PdfName.FIGURE, PdfName.FORMULA, PdfName.FORM });
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3515 */   private static final List<PdfName> standardStructElems_1_7 = Arrays.asList(new PdfName[] { PdfName.DOCUMENT, PdfName.PART, PdfName.ART, PdfName.SECT, PdfName.DIV, PdfName.BLOCKQUOTE, PdfName.CAPTION, PdfName.TOC, PdfName.TOCI, PdfName.INDEX, PdfName.NONSTRUCT, PdfName.PRIVATE, PdfName.P, PdfName.H, PdfName.H1, PdfName.H2, PdfName.H3, PdfName.H4, PdfName.H5, PdfName.H6, PdfName.L, PdfName.LBL, PdfName.LI, PdfName.LBODY, PdfName.TABLE, PdfName.TR, PdfName.TH, PdfName.TD, PdfName.THEAD, PdfName.TBODY, PdfName.TFOOT, PdfName.SPAN, PdfName.QUOTE, PdfName.NOTE, PdfName.REFERENCE, PdfName.BIBENTRY, PdfName.CODE, PdfName.LINK, PdfName.ANNOT, PdfName.RUBY, PdfName.RB, PdfName.RT, PdfName.RP, PdfName.WARICHU, PdfName.WT, PdfName.WP, PdfName.FIGURE, PdfName.FORMULA, PdfName.FORM });
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<PdfName> getStandardStructElems()
/*      */   {
/* 3529 */     if (this.pdf_version.getVersion() < '7') {
/* 3530 */       return standardStructElems_1_4;
/*      */     }
/* 3532 */     return standardStructElems_1_7;
/*      */   }
/*      */   
/*      */   public void useExternalCacheForTagStructure(TempFileCache fileCache)
/*      */   {
/* 3537 */     this.pdf.useExternalCache(fileCache);
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */