/*    */ package com.itextpdf.text.pdf.parser;
/*    */ 
/*    */ import com.itextpdf.awt.geom.Point2D;
/*    */ import com.itextpdf.awt.geom.Point2D.Float;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Line
/*    */   implements Shape
/*    */ {
/*    */   private final Point2D p1;
/*    */   private final Point2D p2;
/*    */   
/*    */   public Line()
/*    */   {
/* 66 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Line(float x1, float y1, float x2, float y2)
/*    */   {
/* 73 */     this.p1 = new Point2D.Float(x1, y1);
/* 74 */     this.p2 = new Point2D.Float(x2, y2);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Line(Point2D p1, Point2D p2)
/*    */   {
/* 81 */     this((float)p1.getX(), (float)p1.getY(), (float)p2.getX(), (float)p2.getY());
/*    */   }
/*    */   
/*    */   public List<Point2D> getBasePoints() {
/* 85 */     List<Point2D> basePoints = new ArrayList(2);
/* 86 */     basePoints.add(this.p1);
/* 87 */     basePoints.add(this.p2);
/*    */     
/* 89 */     return basePoints;
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/Line.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */