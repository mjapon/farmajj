/*    */ package com.itextpdf.text.pdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PdfTransparencyGroup
/*    */   extends PdfDictionary
/*    */ {
/*    */   public PdfTransparencyGroup()
/*    */   {
/* 58 */     put(PdfName.S, PdfName.TRANSPARENCY);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setIsolated(boolean isolated)
/*    */   {
/* 66 */     if (isolated) {
/* 67 */       put(PdfName.I, PdfBoolean.PDFTRUE);
/*    */     } else {
/* 69 */       remove(PdfName.I);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setKnockout(boolean knockout)
/*    */   {
/* 77 */     if (knockout) {
/* 78 */       put(PdfName.K, PdfBoolean.PDFTRUE);
/*    */     } else {
/* 80 */       remove(PdfName.K);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfTransparencyGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */