/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.awt.geom.AffineTransform;
/*      */ import com.itextpdf.text.AccessibleElementId;
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfAnnotation
/*      */   extends PdfDictionary
/*      */   implements IAccessibleElement
/*      */ {
/*   69 */   public static final PdfName HIGHLIGHT_NONE = PdfName.N;
/*      */   
/*   71 */   public static final PdfName HIGHLIGHT_INVERT = PdfName.I;
/*      */   
/*   73 */   public static final PdfName HIGHLIGHT_OUTLINE = PdfName.O;
/*      */   
/*   75 */   public static final PdfName HIGHLIGHT_PUSH = PdfName.P;
/*      */   
/*   77 */   public static final PdfName HIGHLIGHT_TOGGLE = PdfName.T;
/*      */   
/*      */   public static final int FLAGS_INVISIBLE = 1;
/*      */   
/*      */   public static final int FLAGS_HIDDEN = 2;
/*      */   
/*      */   public static final int FLAGS_PRINT = 4;
/*      */   
/*      */   public static final int FLAGS_NOZOOM = 8;
/*      */   
/*      */   public static final int FLAGS_NOROTATE = 16;
/*      */   
/*      */   public static final int FLAGS_NOVIEW = 32;
/*      */   
/*      */   public static final int FLAGS_READONLY = 64;
/*      */   
/*      */   public static final int FLAGS_LOCKED = 128;
/*      */   
/*      */   public static final int FLAGS_TOGGLENOVIEW = 256;
/*      */   
/*      */   public static final int FLAGS_LOCKEDCONTENTS = 512;
/*      */   
/*   99 */   public static final PdfName APPEARANCE_NORMAL = PdfName.N;
/*      */   
/*  101 */   public static final PdfName APPEARANCE_ROLLOVER = PdfName.R;
/*      */   
/*  103 */   public static final PdfName APPEARANCE_DOWN = PdfName.D;
/*      */   
/*  105 */   public static final PdfName AA_ENTER = PdfName.E;
/*      */   
/*  107 */   public static final PdfName AA_EXIT = PdfName.X;
/*      */   
/*  109 */   public static final PdfName AA_DOWN = PdfName.D;
/*      */   
/*  111 */   public static final PdfName AA_UP = PdfName.U;
/*      */   
/*  113 */   public static final PdfName AA_FOCUS = PdfName.FO;
/*      */   
/*  115 */   public static final PdfName AA_BLUR = PdfName.BL;
/*      */   
/*  117 */   public static final PdfName AA_JS_KEY = PdfName.K;
/*      */   
/*  119 */   public static final PdfName AA_JS_FORMAT = PdfName.F;
/*      */   
/*  121 */   public static final PdfName AA_JS_CHANGE = PdfName.V;
/*      */   
/*  123 */   public static final PdfName AA_JS_OTHER_CHANGE = PdfName.C;
/*      */   
/*      */ 
/*      */   public static final int MARKUP_HIGHLIGHT = 0;
/*      */   
/*      */ 
/*      */   public static final int MARKUP_UNDERLINE = 1;
/*      */   
/*      */ 
/*      */   public static final int MARKUP_STRIKEOUT = 2;
/*      */   
/*      */ 
/*      */   public static final int MARKUP_SQUIGGLY = 3;
/*      */   
/*      */   protected PdfWriter writer;
/*      */   
/*      */   protected PdfIndirectReference reference;
/*      */   
/*      */   protected HashSet<PdfTemplate> templates;
/*      */   
/*  143 */   protected boolean form = false;
/*  144 */   protected boolean annotation = true;
/*      */   
/*      */ 
/*  147 */   protected boolean used = false;
/*      */   
/*      */ 
/*  150 */   private int placeInPage = -1;
/*      */   
/*  152 */   protected PdfName role = null;
/*  153 */   protected HashMap<PdfName, PdfObject> accessibleAttributes = null;
/*  154 */   private AccessibleElementId id = null;
/*      */   
/*      */   public PdfAnnotation(PdfWriter writer, Rectangle rect)
/*      */   {
/*  158 */     this.writer = writer;
/*  159 */     if (rect != null) {
/*  160 */       put(PdfName.RECT, new PdfRectangle(rect));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAnnotation(PdfWriter writer, float llx, float lly, float urx, float ury, PdfString title, PdfString content)
/*      */   {
/*  175 */     this.writer = writer;
/*  176 */     put(PdfName.SUBTYPE, PdfName.TEXT);
/*  177 */     put(PdfName.T, title);
/*  178 */     put(PdfName.RECT, new PdfRectangle(llx, lly, urx, ury));
/*  179 */     put(PdfName.CONTENTS, content);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAnnotation(PdfWriter writer, float llx, float lly, float urx, float ury, PdfAction action)
/*      */   {
/*  193 */     this.writer = writer;
/*  194 */     put(PdfName.SUBTYPE, PdfName.LINK);
/*  195 */     put(PdfName.RECT, new PdfRectangle(llx, lly, urx, ury));
/*  196 */     put(PdfName.A, action);
/*  197 */     put(PdfName.BORDER, new PdfBorderArray(0.0F, 0.0F, 0.0F));
/*  198 */     put(PdfName.C, new PdfColor(0, 0, 255));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createScreen(PdfWriter writer, Rectangle rect, String clipTitle, PdfFileSpecification fs, String mimeType, boolean playOnDisplay)
/*      */     throws IOException
/*      */   {
/*  214 */     PdfAnnotation ann = writer.createAnnotation(rect, PdfName.SCREEN);
/*  215 */     ann.put(PdfName.F, new PdfNumber(4));
/*  216 */     ann.put(PdfName.TYPE, PdfName.ANNOT);
/*  217 */     ann.setPage();
/*  218 */     PdfIndirectReference ref = ann.getIndirectReference();
/*  219 */     PdfAction action = PdfAction.rendition(clipTitle, fs, mimeType, ref);
/*  220 */     PdfIndirectReference actionRef = writer.addToBody(action).getIndirectReference();
/*      */     
/*  222 */     if (playOnDisplay)
/*      */     {
/*  224 */       PdfDictionary aa = new PdfDictionary();
/*  225 */       aa.put(new PdfName("PV"), actionRef);
/*  226 */       ann.put(PdfName.AA, aa);
/*      */     }
/*  228 */     ann.put(PdfName.A, actionRef);
/*  229 */     return ann;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfIndirectReference getIndirectReference()
/*      */   {
/*  237 */     if (this.reference == null) {
/*  238 */       this.reference = this.writer.getPdfIndirectReference();
/*      */     }
/*  240 */     return this.reference;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createText(PdfWriter writer, Rectangle rect, String title, String contents, boolean open, String icon)
/*      */   {
/*  253 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.TEXT);
/*  254 */     if (title != null)
/*  255 */       annot.put(PdfName.T, new PdfString(title, "UnicodeBig"));
/*  256 */     if (contents != null)
/*  257 */       annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  258 */     if (open)
/*  259 */       annot.put(PdfName.OPEN, PdfBoolean.PDFTRUE);
/*  260 */     if (icon != null) {
/*  261 */       annot.put(PdfName.NAME, new PdfName(icon));
/*      */     }
/*  263 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight)
/*      */   {
/*  274 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.LINK);
/*  275 */     if (!highlight.equals(HIGHLIGHT_INVERT))
/*  276 */       annot.put(PdfName.H, highlight);
/*  277 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight, PdfAction action)
/*      */   {
/*  289 */     PdfAnnotation annot = createLink(writer, rect, highlight);
/*  290 */     annot.putEx(PdfName.A, action);
/*  291 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight, String namedDestination)
/*      */   {
/*  303 */     PdfAnnotation annot = createLink(writer, rect, highlight);
/*  304 */     annot.put(PdfName.DEST, new PdfString(namedDestination, "UnicodeBig"));
/*  305 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight, int page, PdfDestination dest)
/*      */   {
/*  318 */     PdfAnnotation annot = createLink(writer, rect, highlight);
/*  319 */     PdfIndirectReference ref = writer.getPageReference(page);
/*  320 */     PdfDestination d = new PdfDestination(dest);
/*  321 */     d.addPage(ref);
/*  322 */     annot.put(PdfName.DEST, d);
/*  323 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createFreeText(PdfWriter writer, Rectangle rect, String contents, PdfContentByte defaultAppearance)
/*      */   {
/*  335 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.FREETEXT);
/*  336 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  337 */     annot.setDefaultAppearanceString(defaultAppearance);
/*  338 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createLine(PdfWriter writer, Rectangle rect, String contents, float x1, float y1, float x2, float y2)
/*      */   {
/*  353 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.LINE);
/*  354 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  355 */     PdfArray array = new PdfArray(new PdfNumber(x1));
/*  356 */     array.add(new PdfNumber(y1));
/*  357 */     array.add(new PdfNumber(x2));
/*  358 */     array.add(new PdfNumber(y2));
/*  359 */     annot.put(PdfName.L, array);
/*  360 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createSquareCircle(PdfWriter writer, Rectangle rect, String contents, boolean square)
/*      */   {
/*      */     PdfAnnotation annot;
/*      */     
/*      */ 
/*      */     PdfAnnotation annot;
/*      */     
/*      */ 
/*  373 */     if (square) {
/*  374 */       annot = writer.createAnnotation(rect, PdfName.SQUARE);
/*      */     } else
/*  376 */       annot = writer.createAnnotation(rect, PdfName.CIRCLE);
/*  377 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  378 */     return annot;
/*      */   }
/*      */   
/*      */   public static PdfAnnotation createMarkup(PdfWriter writer, Rectangle rect, String contents, int type, float[] quadPoints) {
/*  382 */     PdfName name = PdfName.HIGHLIGHT;
/*  383 */     switch (type) {
/*      */     case 1: 
/*  385 */       name = PdfName.UNDERLINE;
/*  386 */       break;
/*      */     case 2: 
/*  388 */       name = PdfName.STRIKEOUT;
/*  389 */       break;
/*      */     case 3: 
/*  391 */       name = PdfName.SQUIGGLY;
/*      */     }
/*      */     
/*  394 */     PdfAnnotation annot = writer.createAnnotation(rect, name);
/*  395 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  396 */     PdfArray array = new PdfArray();
/*  397 */     for (int k = 0; k < quadPoints.length; k++)
/*  398 */       array.add(new PdfNumber(quadPoints[k]));
/*  399 */     annot.put(PdfName.QUADPOINTS, array);
/*  400 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createStamp(PdfWriter writer, Rectangle rect, String contents, String name)
/*      */   {
/*  412 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.STAMP);
/*  413 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  414 */     annot.put(PdfName.NAME, new PdfName(name));
/*  415 */     return annot;
/*      */   }
/*      */   
/*      */   public static PdfAnnotation createInk(PdfWriter writer, Rectangle rect, String contents, float[][] inkList) {
/*  419 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.INK);
/*  420 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  421 */     PdfArray outer = new PdfArray();
/*  422 */     for (int k = 0; k < inkList.length; k++) {
/*  423 */       PdfArray inner = new PdfArray();
/*  424 */       float[] deep = inkList[k];
/*  425 */       for (int j = 0; j < deep.length; j++)
/*  426 */         inner.add(new PdfNumber(deep[j]));
/*  427 */       outer.add(inner);
/*      */     }
/*  429 */     annot.put(PdfName.INKLIST, outer);
/*  430 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createFileAttachment(PdfWriter writer, Rectangle rect, String contents, byte[] fileStore, String file, String fileDisplay)
/*      */     throws IOException
/*      */   {
/*  446 */     return createFileAttachment(writer, rect, contents, PdfFileSpecification.fileEmbedded(writer, file, fileDisplay, fileStore));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createFileAttachment(PdfWriter writer, Rectangle rect, String contents, PdfFileSpecification fs)
/*      */     throws IOException
/*      */   {
/*  458 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.FILEATTACHMENT);
/*  459 */     if (contents != null)
/*  460 */       annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  461 */     annot.put(PdfName.FS, fs.getReference());
/*  462 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createPopup(PdfWriter writer, Rectangle rect, String contents, boolean open)
/*      */   {
/*  474 */     PdfAnnotation annot = writer.createAnnotation(rect, PdfName.POPUP);
/*  475 */     if (contents != null)
/*  476 */       annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  477 */     if (open)
/*  478 */       annot.put(PdfName.OPEN, PdfBoolean.PDFTRUE);
/*  479 */     return annot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfAnnotation createPolygonPolyline(PdfWriter writer, Rectangle rect, String contents, boolean polygon, PdfArray vertices)
/*      */   {
/*  493 */     PdfAnnotation annot = null;
/*  494 */     if (polygon) {
/*  495 */       annot = writer.createAnnotation(rect, PdfName.POLYGON);
/*      */     } else
/*  497 */       annot = writer.createAnnotation(rect, PdfName.POLYLINE);
/*  498 */     annot.put(PdfName.CONTENTS, new PdfString(contents, "UnicodeBig"));
/*  499 */     annot.put(PdfName.VERTICES, new PdfArray(vertices));
/*  500 */     return annot;
/*      */   }
/*      */   
/*      */   public void setDefaultAppearanceString(PdfContentByte cb) {
/*  504 */     byte[] b = cb.getInternalBuffer().toByteArray();
/*  505 */     int len = b.length;
/*  506 */     for (int k = 0; k < len; k++) {
/*  507 */       if (b[k] == 10)
/*  508 */         b[k] = 32;
/*      */     }
/*  510 */     put(PdfName.DA, new PdfString(b));
/*      */   }
/*      */   
/*      */   public void setFlags(int flags) {
/*  514 */     if (flags == 0) {
/*  515 */       remove(PdfName.F);
/*      */     } else
/*  517 */       put(PdfName.F, new PdfNumber(flags));
/*      */   }
/*      */   
/*      */   public void setBorder(PdfBorderArray border) {
/*  521 */     put(PdfName.BORDER, border);
/*      */   }
/*      */   
/*      */   public void setBorderStyle(PdfBorderDictionary border) {
/*  525 */     put(PdfName.BS, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHighlighting(PdfName highlight)
/*      */   {
/*  535 */     if (highlight.equals(HIGHLIGHT_INVERT)) {
/*  536 */       remove(PdfName.H);
/*      */     } else
/*  538 */       put(PdfName.H, highlight);
/*      */   }
/*      */   
/*      */   public void setAppearance(PdfName ap, PdfTemplate template) {
/*  542 */     PdfDictionary dic = (PdfDictionary)get(PdfName.AP);
/*  543 */     if (dic == null)
/*  544 */       dic = new PdfDictionary();
/*  545 */     dic.put(ap, template.getIndirectReference());
/*  546 */     put(PdfName.AP, dic);
/*  547 */     if (!this.form)
/*  548 */       return;
/*  549 */     if (this.templates == null)
/*  550 */       this.templates = new HashSet();
/*  551 */     this.templates.add(template);
/*      */   }
/*      */   
/*      */   public void setAppearance(PdfName ap, String state, PdfTemplate template) {
/*  555 */     PdfDictionary dicAp = (PdfDictionary)get(PdfName.AP);
/*  556 */     if (dicAp == null) {
/*  557 */       dicAp = new PdfDictionary();
/*      */     }
/*      */     
/*  560 */     PdfObject obj = dicAp.get(ap);
/*  561 */     PdfDictionary dic; PdfDictionary dic; if ((obj != null) && (obj.isDictionary())) {
/*  562 */       dic = (PdfDictionary)obj;
/*      */     } else
/*  564 */       dic = new PdfDictionary();
/*  565 */     dic.put(new PdfName(state), template.getIndirectReference());
/*  566 */     dicAp.put(ap, dic);
/*  567 */     put(PdfName.AP, dicAp);
/*  568 */     if (!this.form)
/*  569 */       return;
/*  570 */     if (this.templates == null)
/*  571 */       this.templates = new HashSet();
/*  572 */     this.templates.add(template);
/*      */   }
/*      */   
/*      */   public void setAppearanceState(String state) {
/*  576 */     if (state == null) {
/*  577 */       remove(PdfName.AS);
/*  578 */       return;
/*      */     }
/*  580 */     put(PdfName.AS, new PdfName(state));
/*      */   }
/*      */   
/*      */   public void setColor(BaseColor color) {
/*  584 */     put(PdfName.C, new PdfColor(color));
/*      */   }
/*      */   
/*      */   public void setTitle(String title) {
/*  588 */     if (title == null) {
/*  589 */       remove(PdfName.T);
/*  590 */       return;
/*      */     }
/*  592 */     put(PdfName.T, new PdfString(title, "UnicodeBig"));
/*      */   }
/*      */   
/*      */   public void setPopup(PdfAnnotation popup) {
/*  596 */     put(PdfName.POPUP, popup.getIndirectReference());
/*  597 */     popup.put(PdfName.PARENT, getIndirectReference());
/*      */   }
/*      */   
/*      */   public void setAction(PdfAction action) {
/*  601 */     put(PdfName.A, action);
/*      */   }
/*      */   
/*      */   public void setAdditionalActions(PdfName key, PdfAction action)
/*      */   {
/*  606 */     PdfObject obj = get(PdfName.AA);
/*  607 */     PdfDictionary dic; PdfDictionary dic; if ((obj != null) && (obj.isDictionary())) {
/*  608 */       dic = (PdfDictionary)obj;
/*      */     } else
/*  610 */       dic = new PdfDictionary();
/*  611 */     dic.put(key, action);
/*  612 */     put(PdfName.AA, dic);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isUsed()
/*      */   {
/*  619 */     return this.used;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUsed()
/*      */   {
/*  625 */     this.used = true;
/*      */   }
/*      */   
/*      */   public HashSet<PdfTemplate> getTemplates() {
/*  629 */     return this.templates;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isForm()
/*      */   {
/*  636 */     return this.form;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isAnnotation()
/*      */   {
/*  643 */     return this.annotation;
/*      */   }
/*      */   
/*      */   public void setPage(int page) {
/*  647 */     put(PdfName.P, this.writer.getPageReference(page));
/*      */   }
/*      */   
/*      */   public void setPage() {
/*  651 */     put(PdfName.P, this.writer.getCurrentPage());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPlaceInPage()
/*      */   {
/*  658 */     return this.placeInPage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPlaceInPage(int placeInPage)
/*      */   {
/*  667 */     this.placeInPage = placeInPage;
/*      */   }
/*      */   
/*      */   public void setRotate(int v) {
/*  671 */     put(PdfName.ROTATE, new PdfNumber(v));
/*      */   }
/*      */   
/*      */   PdfDictionary getMK() {
/*  675 */     PdfDictionary mk = (PdfDictionary)get(PdfName.MK);
/*  676 */     if (mk == null) {
/*  677 */       mk = new PdfDictionary();
/*  678 */       put(PdfName.MK, mk);
/*      */     }
/*  680 */     return mk;
/*      */   }
/*      */   
/*      */   public void setMKRotation(int rotation) {
/*  684 */     getMK().put(PdfName.R, new PdfNumber(rotation));
/*      */   }
/*      */   
/*      */   public static PdfArray getMKColor(BaseColor color) {
/*  688 */     PdfArray array = new PdfArray();
/*  689 */     int type = ExtendedColor.getType(color);
/*  690 */     switch (type) {
/*      */     case 1: 
/*  692 */       array.add(new PdfNumber(((GrayColor)color).getGray()));
/*  693 */       break;
/*      */     
/*      */     case 2: 
/*  696 */       CMYKColor cmyk = (CMYKColor)color;
/*  697 */       array.add(new PdfNumber(cmyk.getCyan()));
/*  698 */       array.add(new PdfNumber(cmyk.getMagenta()));
/*  699 */       array.add(new PdfNumber(cmyk.getYellow()));
/*  700 */       array.add(new PdfNumber(cmyk.getBlack()));
/*  701 */       break;
/*      */     
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*  706 */       throw new RuntimeException(MessageLocalization.getComposedMessage("separations.patterns.and.shadings.are.not.allowed.in.mk.dictionary", new Object[0]));
/*      */     default: 
/*  708 */       array.add(new PdfNumber(color.getRed() / 255.0F));
/*  709 */       array.add(new PdfNumber(color.getGreen() / 255.0F));
/*  710 */       array.add(new PdfNumber(color.getBlue() / 255.0F));
/*      */     }
/*  712 */     return array;
/*      */   }
/*      */   
/*      */   public void setMKBorderColor(BaseColor color) {
/*  716 */     if (color == null) {
/*  717 */       getMK().remove(PdfName.BC);
/*      */     } else
/*  719 */       getMK().put(PdfName.BC, getMKColor(color));
/*      */   }
/*      */   
/*      */   public void setMKBackgroundColor(BaseColor color) {
/*  723 */     if (color == null) {
/*  724 */       getMK().remove(PdfName.BG);
/*      */     } else
/*  726 */       getMK().put(PdfName.BG, getMKColor(color));
/*      */   }
/*      */   
/*      */   public void setMKNormalCaption(String caption) {
/*  730 */     getMK().put(PdfName.CA, new PdfString(caption, "UnicodeBig"));
/*      */   }
/*      */   
/*      */   public void setMKRolloverCaption(String caption) {
/*  734 */     getMK().put(PdfName.RC, new PdfString(caption, "UnicodeBig"));
/*      */   }
/*      */   
/*      */   public void setMKAlternateCaption(String caption) {
/*  738 */     getMK().put(PdfName.AC, new PdfString(caption, "UnicodeBig"));
/*      */   }
/*      */   
/*      */   public void setMKNormalIcon(PdfTemplate template) {
/*  742 */     getMK().put(PdfName.I, template.getIndirectReference());
/*      */   }
/*      */   
/*      */   public void setMKRolloverIcon(PdfTemplate template) {
/*  746 */     getMK().put(PdfName.RI, template.getIndirectReference());
/*      */   }
/*      */   
/*      */   public void setMKAlternateIcon(PdfTemplate template) {
/*  750 */     getMK().put(PdfName.IX, template.getIndirectReference());
/*      */   }
/*      */   
/*      */   public void setMKIconFit(PdfName scale, PdfName scalingType, float leftoverLeft, float leftoverBottom, boolean fitInBounds) {
/*  754 */     PdfDictionary dic = new PdfDictionary();
/*  755 */     if (!scale.equals(PdfName.A))
/*  756 */       dic.put(PdfName.SW, scale);
/*  757 */     if (!scalingType.equals(PdfName.P))
/*  758 */       dic.put(PdfName.S, scalingType);
/*  759 */     if ((leftoverLeft != 0.5F) || (leftoverBottom != 0.5F)) {
/*  760 */       PdfArray array = new PdfArray(new PdfNumber(leftoverLeft));
/*  761 */       array.add(new PdfNumber(leftoverBottom));
/*  762 */       dic.put(PdfName.A, array);
/*      */     }
/*  764 */     if (fitInBounds)
/*  765 */       dic.put(PdfName.FB, PdfBoolean.PDFTRUE);
/*  766 */     getMK().put(PdfName.IF, dic);
/*      */   }
/*      */   
/*      */   public void setMKTextPosition(int tp) {
/*  770 */     getMK().put(PdfName.TP, new PdfNumber(tp));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLayer(PdfOCG layer)
/*      */   {
/*  778 */     put(PdfName.OC, layer.getRef());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  787 */     put(PdfName.NM, new PdfString(name));
/*      */   }
/*      */   
/*      */   public void applyCTM(AffineTransform ctm)
/*      */   {
/*  792 */     PdfArray origRect = getAsArray(PdfName.RECT);
/*  793 */     if (origRect != null) { PdfRectangle rect;
/*      */       PdfRectangle rect;
/*  795 */       if (origRect.size() == 4) {
/*  796 */         rect = new PdfRectangle(origRect.getAsNumber(0).floatValue(), origRect.getAsNumber(1).floatValue(), origRect.getAsNumber(2).floatValue(), origRect.getAsNumber(3).floatValue());
/*      */       }
/*      */       else {
/*  799 */         rect = new PdfRectangle(origRect.getAsNumber(0).floatValue(), origRect.getAsNumber(1).floatValue());
/*      */       }
/*  801 */       put(PdfName.RECT, rect.transform(ctm));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class PdfImportedLink
/*      */   {
/*      */     float llx;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     float lly;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     float urx;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     float ury;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  854 */     HashMap<PdfName, PdfObject> parameters = new HashMap();
/*  855 */     PdfArray destination = null;
/*  856 */     int newPage = 0;
/*      */     PdfArray rect;
/*      */     
/*      */     PdfImportedLink(PdfDictionary annotation) {
/*  860 */       this.parameters.putAll(annotation.hashMap);
/*      */       try {
/*  862 */         this.destination = ((PdfArray)this.parameters.remove(PdfName.DEST));
/*      */       } catch (ClassCastException ex) {
/*  864 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("you.have.to.consolidate.the.named.destinations.of.your.reader", new Object[0]));
/*      */       }
/*  866 */       if (this.destination != null) {
/*  867 */         this.destination = new PdfArray(this.destination);
/*      */       }
/*  869 */       PdfArray rc = (PdfArray)this.parameters.remove(PdfName.RECT);
/*  870 */       this.llx = rc.getAsNumber(0).floatValue();
/*  871 */       this.lly = rc.getAsNumber(1).floatValue();
/*  872 */       this.urx = rc.getAsNumber(2).floatValue();
/*  873 */       this.ury = rc.getAsNumber(3).floatValue();
/*      */       
/*  875 */       this.rect = new PdfArray(rc);
/*      */     }
/*      */     
/*      */     public Map<PdfName, PdfObject> getParameters() {
/*  879 */       return new HashMap(this.parameters);
/*      */     }
/*      */     
/*      */     public PdfArray getRect() {
/*  883 */       return new PdfArray(this.rect);
/*      */     }
/*      */     
/*      */     public boolean isInternal() {
/*  887 */       return this.destination != null;
/*      */     }
/*      */     
/*      */     public int getDestinationPage() {
/*  891 */       if (!isInternal()) { return 0;
/*      */       }
/*      */       
/*      */ 
/*  895 */       PdfIndirectReference ref = this.destination.getAsIndirectObject(0);
/*      */       
/*  897 */       PRIndirectReference pr = (PRIndirectReference)ref;
/*  898 */       PdfReader r = pr.getReader();
/*  899 */       for (int i = 1; i <= r.getNumberOfPages(); i++) {
/*  900 */         PRIndirectReference pp = r.getPageOrigRef(i);
/*  901 */         if ((pp.getGeneration() == pr.getGeneration()) && (pp.getNumber() == pr.getNumber())) return i;
/*      */       }
/*  903 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("page.not.found", new Object[0]));
/*      */     }
/*      */     
/*      */     public void setDestinationPage(int newPage) {
/*  907 */       if (!isInternal()) throw new IllegalArgumentException(MessageLocalization.getComposedMessage("cannot.change.destination.of.external.link", new Object[0]));
/*  908 */       this.newPage = newPage;
/*      */     }
/*      */     
/*      */     public void transformDestination(float a, float b, float c, float d, float e, float f) {
/*  912 */       if (!isInternal()) throw new IllegalArgumentException(MessageLocalization.getComposedMessage("cannot.change.destination.of.external.link", new Object[0]));
/*  913 */       if (this.destination.getAsName(1).equals(PdfName.XYZ)) {
/*  914 */         float x = this.destination.getAsNumber(2).floatValue();
/*  915 */         float y = this.destination.getAsNumber(3).floatValue();
/*  916 */         float xx = x * a + y * c + e;
/*  917 */         float yy = x * b + y * d + f;
/*  918 */         this.destination.set(2, new PdfNumber(xx));
/*  919 */         this.destination.set(3, new PdfNumber(yy));
/*      */       }
/*      */     }
/*      */     
/*      */     public void transformRect(float a, float b, float c, float d, float e, float f) {
/*  924 */       float x = this.llx * a + this.lly * c + e;
/*  925 */       float y = this.llx * b + this.lly * d + f;
/*  926 */       this.llx = x;
/*  927 */       this.lly = y;
/*  928 */       x = this.urx * a + this.ury * c + e;
/*  929 */       y = this.urx * b + this.ury * d + f;
/*  930 */       this.urx = x;
/*  931 */       this.ury = y;
/*      */     }
/*      */     
/*      */     public PdfAnnotation createAnnotation(PdfWriter writer) {
/*  935 */       PdfAnnotation annotation = writer.createAnnotation(new Rectangle(this.llx, this.lly, this.urx, this.ury), null);
/*  936 */       if (this.newPage != 0) {
/*  937 */         PdfIndirectReference ref = writer.getPageReference(this.newPage);
/*  938 */         this.destination.set(0, ref);
/*      */       }
/*  940 */       if (this.destination != null) annotation.put(PdfName.DEST, this.destination);
/*  941 */       annotation.hashMap.putAll(this.parameters);
/*  942 */       return annotation;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/*  952 */       StringBuffer buf = new StringBuffer("Imported link: location [");
/*  953 */       buf.append(this.llx);
/*  954 */       buf.append(' ');
/*  955 */       buf.append(this.lly);
/*  956 */       buf.append(' ');
/*  957 */       buf.append(this.urx);
/*  958 */       buf.append(' ');
/*  959 */       buf.append(this.ury);
/*  960 */       buf.append("] destination ");
/*  961 */       buf.append(this.destination);
/*  962 */       buf.append(" parameters ");
/*  963 */       buf.append(this.parameters);
/*  964 */       if (this.parameters != null) {
/*  965 */         appendDictionary(buf, this.parameters);
/*      */       }
/*      */       
/*  968 */       return buf.toString();
/*      */     }
/*      */     
/*      */     private void appendDictionary(StringBuffer buf, HashMap<PdfName, PdfObject> dict) {
/*  972 */       buf.append(" <<");
/*  973 */       for (Map.Entry<PdfName, PdfObject> entry : dict.entrySet()) {
/*  974 */         buf.append(entry.getKey());
/*  975 */         buf.append(":");
/*  976 */         if ((entry.getValue() instanceof PdfDictionary)) {
/*  977 */           appendDictionary(buf, ((PdfDictionary)entry.getValue()).hashMap);
/*      */         } else
/*  979 */           buf.append(entry.getValue());
/*  980 */         buf.append(" ");
/*      */       }
/*      */       
/*  983 */       buf.append(">> ");
/*      */     }
/*      */   }
/*      */   
/*      */   public void toPdf(PdfWriter writer, OutputStream os)
/*      */     throws IOException
/*      */   {
/*  990 */     PdfWriter.checkPdfIsoConformance(writer, 13, this);
/*  991 */     super.toPdf(writer, os);
/*      */   }
/*      */   
/*      */   public PdfObject getAccessibleAttribute(PdfName key) {
/*  995 */     if (this.accessibleAttributes != null) {
/*  996 */       return (PdfObject)this.accessibleAttributes.get(key);
/*      */     }
/*  998 */     return null;
/*      */   }
/*      */   
/*      */   public void setAccessibleAttribute(PdfName key, PdfObject value) {
/* 1002 */     if (this.accessibleAttributes == null)
/* 1003 */       this.accessibleAttributes = new HashMap();
/* 1004 */     this.accessibleAttributes.put(key, value);
/*      */   }
/*      */   
/*      */   public HashMap<PdfName, PdfObject> getAccessibleAttributes() {
/* 1008 */     return this.accessibleAttributes;
/*      */   }
/*      */   
/*      */   public PdfName getRole() {
/* 1012 */     return this.role;
/*      */   }
/*      */   
/*      */   public void setRole(PdfName role) {
/* 1016 */     this.role = role;
/*      */   }
/*      */   
/*      */   public AccessibleElementId getId() {
/* 1020 */     if (this.id == null)
/* 1021 */       this.id = new AccessibleElementId();
/* 1022 */     return this.id;
/*      */   }
/*      */   
/*      */   public void setId(AccessibleElementId id) {
/* 1026 */     this.id = id;
/*      */   }
/*      */   
/*      */   public boolean isInline() {
/* 1030 */     return false;
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfAnnotation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */