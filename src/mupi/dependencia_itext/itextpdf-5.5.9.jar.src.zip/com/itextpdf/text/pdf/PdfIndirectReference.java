/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfIndirectReference
/*     */   extends PdfObject
/*     */ {
/*     */   protected int number;
/*  72 */   protected int generation = 0;
/*     */   
/*     */ 
/*     */   protected PdfIndirectReference()
/*     */   {
/*  77 */     super(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PdfIndirectReference(int type, int number, int generation)
/*     */   {
/*  89 */     super(0, number + " " + generation + " R");
/*  90 */     this.number = number;
/*  91 */     this.generation = generation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PdfIndirectReference(int type, int number)
/*     */   {
/* 102 */     this(type, number, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumber()
/*     */   {
/* 114 */     return this.number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getGeneration()
/*     */   {
/* 124 */     return this.generation;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 128 */     return this.number + " " + this.generation + " R";
/*     */   }
/*     */   
/*     */   public void toPdf(PdfWriter writer, OutputStream os) throws IOException
/*     */   {
/* 133 */     os.write(PdfEncodings.convertToBytes(toString(), null));
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfIndirectReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */