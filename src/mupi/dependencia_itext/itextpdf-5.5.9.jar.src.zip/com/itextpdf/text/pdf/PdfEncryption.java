/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocWriter;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.exceptions.BadPasswordException;
/*     */ import com.itextpdf.text.pdf.crypto.AESCipherCBCnoPad;
/*     */ import com.itextpdf.text.pdf.crypto.ARCFOUREncryption;
/*     */ import com.itextpdf.text.pdf.crypto.IVGenerator;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.cert.Certificate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfEncryption
/*     */ {
/*     */   public static final int STANDARD_ENCRYPTION_40 = 2;
/*     */   public static final int STANDARD_ENCRYPTION_128 = 3;
/*     */   public static final int AES_128 = 4;
/*     */   public static final int AES_256 = 5;
/*  75 */   private static final byte[] pad = { 40, -65, 78, 94, 78, 117, -118, 65, 100, 0, 78, 86, -1, -6, 1, 8, 46, 46, 0, -74, -48, 104, 62, Byte.MIN_VALUE, 47, 12, -87, -2, 100, 83, 105, 122 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private static final byte[] salt = { 115, 65, 108, 84 };
/*     */   
/*     */ 
/*  86 */   private static final byte[] metadataPad = { -1, -1, -1, -1 };
/*     */   
/*     */ 
/*     */ 
/*     */   byte[] key;
/*     */   
/*     */ 
/*     */   int keySize;
/*     */   
/*     */ 
/*  96 */   byte[] mkey = new byte[0];
/*     */   
/*     */ 
/*  99 */   byte[] ownerKey = new byte[32];
/*     */   
/*     */ 
/* 102 */   byte[] userKey = new byte[32];
/*     */   
/*     */ 
/*     */   byte[] oeKey;
/*     */   
/*     */ 
/*     */   byte[] ueKey;
/*     */   
/*     */   byte[] perms;
/*     */   
/*     */   long permissions;
/*     */   
/*     */   byte[] documentID;
/*     */   
/*     */   private int revision;
/*     */   
/*     */   private int keyLength;
/*     */   
/* 120 */   protected PdfPublicKeySecurityHandler publicKeyHandler = null;
/*     */   
/*     */ 
/* 123 */   byte[] extra = new byte[5];
/*     */   
/*     */ 
/*     */   MessageDigest md5;
/*     */   
/* 128 */   private ARCFOUREncryption arcfour = new ARCFOUREncryption();
/*     */   
/*     */   private boolean encryptMetadata;
/*     */   
/* 132 */   static long seq = System.currentTimeMillis();
/*     */   private boolean embeddedFilesOnly;
/*     */   private int cryptoMode;
/*     */   private static final int VALIDATION_SALT_OFFSET = 32;
/*     */   private static final int KEY_SALT_OFFSET = 40;
/*     */   private static final int SALT_LENGHT = 8;
/*     */   private static final int OU_LENGHT = 48;
/*     */   
/*     */   public PdfEncryption()
/*     */   {
/*     */     try
/*     */     {
/* 144 */       this.md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (Exception e) {
/* 146 */       throw new ExceptionConverter(e);
/*     */     }
/* 148 */     this.publicKeyHandler = new PdfPublicKeySecurityHandler();
/*     */   }
/*     */   
/*     */   public PdfEncryption(PdfEncryption enc) {
/* 152 */     this();
/* 153 */     if (enc.key != null)
/* 154 */       this.key = ((byte[])enc.key.clone());
/* 155 */     this.keySize = enc.keySize;
/*     */     
/*     */ 
/*     */ 
/* 159 */     this.permissions = enc.permissions;
/* 160 */     if (enc.documentID != null)
/* 161 */       this.documentID = ((byte[])enc.documentID.clone());
/* 162 */     this.revision = enc.revision;
/* 163 */     this.keyLength = enc.keyLength;
/* 164 */     this.encryptMetadata = enc.encryptMetadata;
/* 165 */     this.embeddedFilesOnly = enc.embeddedFilesOnly;
/*     */     
/*     */ 
/* 168 */     if (enc.ueKey != null) {
/* 169 */       this.ueKey = ((byte[])enc.ueKey.clone());
/*     */     }
/* 171 */     if (enc.oeKey != null) {
/* 172 */       this.oeKey = ((byte[])enc.oeKey.clone());
/*     */     }
/* 174 */     if (enc.perms != null) {
/* 175 */       this.perms = ((byte[])enc.perms.clone());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCryptoMode(int mode, int kl) {
/* 180 */     this.cryptoMode = mode;
/* 181 */     this.encryptMetadata = ((mode & 0x8) != 8);
/* 182 */     this.embeddedFilesOnly = ((mode & 0x18) == 24);
/* 183 */     mode &= 0x7;
/* 184 */     switch (mode) {
/*     */     case 0: 
/* 186 */       this.encryptMetadata = true;
/* 187 */       this.embeddedFilesOnly = false;
/* 188 */       this.keyLength = 40;
/* 189 */       this.revision = 2;
/* 190 */       break;
/*     */     case 1: 
/* 192 */       this.embeddedFilesOnly = false;
/* 193 */       if (kl > 0) {
/* 194 */         this.keyLength = kl;
/*     */       } else
/* 196 */         this.keyLength = 128;
/* 197 */       this.revision = 3;
/* 198 */       break;
/*     */     case 2: 
/* 200 */       this.keyLength = 128;
/* 201 */       this.revision = 4;
/* 202 */       break;
/*     */     case 3: 
/* 204 */       this.keyLength = 256;
/* 205 */       this.keySize = 32;
/* 206 */       this.revision = 5;
/* 207 */       break;
/*     */     default: 
/* 209 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("no.valid.encryption.mode", new Object[0]));
/*     */     }
/*     */   }
/*     */   
/*     */   public int getCryptoMode() {
/* 214 */     return this.cryptoMode;
/*     */   }
/*     */   
/*     */   public boolean isMetadataEncrypted() {
/* 218 */     return this.encryptMetadata;
/*     */   }
/*     */   
/*     */   public long getPermissions() {
/* 222 */     return this.permissions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmbeddedFilesOnly()
/*     */   {
/* 231 */     return this.embeddedFilesOnly;
/*     */   }
/*     */   
/*     */ 
/*     */   private byte[] padPassword(byte[] userPassword)
/*     */   {
/* 237 */     byte[] userPad = new byte[32];
/* 238 */     if (userPassword == null) {
/* 239 */       System.arraycopy(pad, 0, userPad, 0, 32);
/*     */     } else {
/* 241 */       System.arraycopy(userPassword, 0, userPad, 0, Math.min(userPassword.length, 32));
/*     */       
/* 243 */       if (userPassword.length < 32) {
/* 244 */         System.arraycopy(pad, 0, userPad, userPassword.length, 32 - userPassword.length);
/*     */       }
/*     */     }
/*     */     
/* 248 */     return userPad;
/*     */   }
/*     */   
/*     */ 
/*     */   private byte[] computeOwnerKey(byte[] userPad, byte[] ownerPad)
/*     */   {
/* 254 */     byte[] ownerKey = new byte[32];
/* 255 */     byte[] digest = this.md5.digest(ownerPad);
/* 256 */     if ((this.revision == 3) || (this.revision == 4)) {
/* 257 */       byte[] mkey = new byte[this.keyLength / 8];
/*     */       
/* 259 */       for (int k = 0; k < 50; k++) {
/* 260 */         this.md5.update(digest, 0, mkey.length);
/* 261 */         System.arraycopy(this.md5.digest(), 0, digest, 0, mkey.length);
/*     */       }
/* 263 */       System.arraycopy(userPad, 0, ownerKey, 0, 32);
/* 264 */       for (int i = 0; i < 20; i++) {
/* 265 */         for (int j = 0; j < mkey.length; j++)
/* 266 */           mkey[j] = ((byte)(digest[j] ^ i));
/* 267 */         this.arcfour.prepareARCFOURKey(mkey);
/* 268 */         this.arcfour.encryptARCFOUR(ownerKey);
/*     */       }
/*     */     } else {
/* 271 */       this.arcfour.prepareARCFOURKey(digest, 0, 5);
/* 272 */       this.arcfour.encryptARCFOUR(userPad, ownerKey);
/*     */     }
/* 274 */     return ownerKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupGlobalEncryptionKey(byte[] documentID, byte[] userPad, byte[] ownerKey, long permissions)
/*     */   {
/* 283 */     this.documentID = documentID;
/* 284 */     this.ownerKey = ownerKey;
/* 285 */     this.permissions = permissions;
/*     */     
/* 287 */     this.mkey = new byte[this.keyLength / 8];
/*     */     
/*     */ 
/* 290 */     this.md5.reset();
/* 291 */     this.md5.update(userPad);
/* 292 */     this.md5.update(ownerKey);
/*     */     
/* 294 */     byte[] ext = new byte[4];
/* 295 */     ext[0] = ((byte)(int)permissions);
/* 296 */     ext[1] = ((byte)(int)(permissions >> 8));
/* 297 */     ext[2] = ((byte)(int)(permissions >> 16));
/* 298 */     ext[3] = ((byte)(int)(permissions >> 24));
/* 299 */     this.md5.update(ext, 0, 4);
/* 300 */     if (documentID != null)
/* 301 */       this.md5.update(documentID);
/* 302 */     if (!this.encryptMetadata) {
/* 303 */       this.md5.update(metadataPad);
/*     */     }
/* 305 */     byte[] digest = new byte[this.mkey.length];
/* 306 */     System.arraycopy(this.md5.digest(), 0, digest, 0, this.mkey.length);
/*     */     
/*     */ 
/* 309 */     if ((this.revision == 3) || (this.revision == 4)) {
/* 310 */       for (int k = 0; k < 50; k++) {
/* 311 */         System.arraycopy(this.md5.digest(digest), 0, digest, 0, this.mkey.length);
/*     */       }
/*     */     }
/* 314 */     System.arraycopy(digest, 0, this.mkey, 0, this.mkey.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupUserKey()
/*     */   {
/* 323 */     if ((this.revision == 3) || (this.revision == 4)) {
/* 324 */       this.md5.update(pad);
/* 325 */       byte[] digest = this.md5.digest(this.documentID);
/* 326 */       System.arraycopy(digest, 0, this.userKey, 0, 16);
/* 327 */       for (int k = 16; k < 32; k++)
/* 328 */         this.userKey[k] = 0;
/* 329 */       for (int i = 0; i < 20; i++) {
/* 330 */         for (int j = 0; j < this.mkey.length; j++)
/* 331 */           digest[j] = ((byte)(this.mkey[j] ^ i));
/* 332 */         this.arcfour.prepareARCFOURKey(digest, 0, this.mkey.length);
/* 333 */         this.arcfour.encryptARCFOUR(this.userKey, 0, 16);
/*     */       }
/*     */     } else {
/* 336 */       this.arcfour.prepareARCFOURKey(this.mkey);
/* 337 */       this.arcfour.encryptARCFOUR(pad, this.userKey);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setupAllKeys(byte[] userPassword, byte[] ownerPassword, int permissions)
/*     */   {
/* 345 */     if ((ownerPassword == null) || (ownerPassword.length == 0))
/* 346 */       ownerPassword = this.md5.digest(createDocumentId());
/* 347 */     permissions |= ((this.revision == 3) || (this.revision == 4) || (this.revision == 5) ? 61632 : -64);
/*     */     
/* 349 */     permissions &= 0xFFFFFFFC;
/* 350 */     this.permissions = permissions;
/* 351 */     if (this.revision == 5) {
/*     */       try {
/* 353 */         if (userPassword == null)
/* 354 */           userPassword = new byte[0];
/* 355 */         this.documentID = createDocumentId();
/* 356 */         byte[] uvs = IVGenerator.getIV(8);
/* 357 */         byte[] uks = IVGenerator.getIV(8);
/* 358 */         this.key = IVGenerator.getIV(32);
/*     */         
/* 360 */         MessageDigest md = MessageDigest.getInstance("SHA-256");
/* 361 */         md.update(userPassword, 0, Math.min(userPassword.length, 127));
/* 362 */         md.update(uvs);
/* 363 */         this.userKey = new byte[48];
/* 364 */         md.digest(this.userKey, 0, 32);
/* 365 */         System.arraycopy(uvs, 0, this.userKey, 32, 8);
/* 366 */         System.arraycopy(uks, 0, this.userKey, 40, 8);
/*     */         
/* 368 */         md.update(userPassword, 0, Math.min(userPassword.length, 127));
/* 369 */         md.update(uks);
/* 370 */         AESCipherCBCnoPad ac = new AESCipherCBCnoPad(true, md.digest());
/* 371 */         this.ueKey = ac.processBlock(this.key, 0, this.key.length);
/*     */         
/* 373 */         byte[] ovs = IVGenerator.getIV(8);
/* 374 */         byte[] oks = IVGenerator.getIV(8);
/* 375 */         md.update(ownerPassword, 0, Math.min(ownerPassword.length, 127));
/* 376 */         md.update(ovs);
/* 377 */         md.update(this.userKey);
/* 378 */         this.ownerKey = new byte[48];
/* 379 */         md.digest(this.ownerKey, 0, 32);
/* 380 */         System.arraycopy(ovs, 0, this.ownerKey, 32, 8);
/* 381 */         System.arraycopy(oks, 0, this.ownerKey, 40, 8);
/*     */         
/* 383 */         md.update(ownerPassword, 0, Math.min(ownerPassword.length, 127));
/* 384 */         md.update(oks);
/* 385 */         md.update(this.userKey);
/* 386 */         ac = new AESCipherCBCnoPad(true, md.digest());
/* 387 */         this.oeKey = ac.processBlock(this.key, 0, this.key.length);
/*     */         
/* 389 */         byte[] permsp = IVGenerator.getIV(16);
/* 390 */         permsp[0] = ((byte)permissions);
/* 391 */         permsp[1] = ((byte)(permissions >> 8));
/* 392 */         permsp[2] = ((byte)(permissions >> 16));
/* 393 */         permsp[3] = ((byte)(permissions >> 24));
/* 394 */         permsp[4] = -1;
/* 395 */         permsp[5] = -1;
/* 396 */         permsp[6] = -1;
/* 397 */         permsp[7] = -1;
/* 398 */         permsp[8] = (this.encryptMetadata ? 84 : 70);
/* 399 */         permsp[9] = 97;
/* 400 */         permsp[10] = 100;
/* 401 */         permsp[11] = 98;
/* 402 */         ac = new AESCipherCBCnoPad(true, this.key);
/* 403 */         this.perms = ac.processBlock(permsp, 0, permsp.length);
/*     */       }
/*     */       catch (Exception ex) {
/* 406 */         throw new ExceptionConverter(ex);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 412 */       byte[] userPad = padPassword(userPassword);
/* 413 */       byte[] ownerPad = padPassword(ownerPassword);
/*     */       
/* 415 */       this.ownerKey = computeOwnerKey(userPad, ownerPad);
/* 416 */       this.documentID = createDocumentId();
/* 417 */       setupByUserPad(this.documentID, userPad, this.ownerKey, permissions);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean readKey(PdfDictionary enc, byte[] password)
/*     */     throws BadPasswordException
/*     */   {
/*     */     try
/*     */     {
/* 428 */       if (password == null)
/* 429 */         password = new byte[0];
/* 430 */       byte[] oValue = DocWriter.getISOBytes(enc.get(PdfName.O).toString());
/* 431 */       byte[] uValue = DocWriter.getISOBytes(enc.get(PdfName.U).toString());
/* 432 */       byte[] oeValue = DocWriter.getISOBytes(enc.get(PdfName.OE).toString());
/* 433 */       byte[] ueValue = DocWriter.getISOBytes(enc.get(PdfName.UE).toString());
/* 434 */       byte[] perms = DocWriter.getISOBytes(enc.get(PdfName.PERMS).toString());
/* 435 */       PdfNumber pValue = (PdfNumber)enc.get(PdfName.P);
/*     */       
/* 437 */       this.oeKey = oeValue;
/* 438 */       this.ueKey = ueValue;
/* 439 */       this.perms = perms;
/*     */       
/* 441 */       this.ownerKey = oValue;
/* 442 */       this.userKey = uValue;
/*     */       
/* 444 */       this.permissions = pValue.longValue();
/*     */       
/* 446 */       boolean isUserPass = false;
/* 447 */       MessageDigest md = MessageDigest.getInstance("SHA-256");
/* 448 */       md.update(password, 0, Math.min(password.length, 127));
/* 449 */       md.update(oValue, 32, 8);
/* 450 */       md.update(uValue, 0, 48);
/* 451 */       byte[] hash = md.digest();
/* 452 */       boolean isOwnerPass = compareArray(hash, oValue, 32);
/* 453 */       if (isOwnerPass) {
/* 454 */         md.update(password, 0, Math.min(password.length, 127));
/* 455 */         md.update(oValue, 40, 8);
/* 456 */         md.update(uValue, 0, 48);
/* 457 */         hash = md.digest();
/* 458 */         AESCipherCBCnoPad ac = new AESCipherCBCnoPad(false, hash);
/* 459 */         this.key = ac.processBlock(oeValue, 0, oeValue.length);
/*     */       }
/*     */       else {
/* 462 */         md.update(password, 0, Math.min(password.length, 127));
/* 463 */         md.update(uValue, 32, 8);
/* 464 */         hash = md.digest();
/* 465 */         isUserPass = compareArray(hash, uValue, 32);
/* 466 */         if (!isUserPass)
/* 467 */           throw new BadPasswordException(MessageLocalization.getComposedMessage("bad.user.password", new Object[0]));
/* 468 */         md.update(password, 0, Math.min(password.length, 127));
/* 469 */         md.update(uValue, 40, 8);
/* 470 */         hash = md.digest();
/* 471 */         AESCipherCBCnoPad ac = new AESCipherCBCnoPad(false, hash);
/* 472 */         this.key = ac.processBlock(ueValue, 0, ueValue.length);
/*     */       }
/* 474 */       AESCipherCBCnoPad ac = new AESCipherCBCnoPad(false, this.key);
/* 475 */       byte[] decPerms = ac.processBlock(perms, 0, perms.length);
/* 476 */       if ((decPerms[9] != 97) || (decPerms[10] != 100) || (decPerms[11] != 98))
/* 477 */         throw new BadPasswordException(MessageLocalization.getComposedMessage("bad.user.password", new Object[0]));
/* 478 */       this.permissions = (decPerms[0] & 0xFF | (decPerms[1] & 0xFF) << 8 | (decPerms[2] & 0xFF) << 16 | (decPerms[2] & 0xFF) << 24);
/*     */       
/* 480 */       this.encryptMetadata = (decPerms[8] == 84);
/* 481 */       return isOwnerPass;
/*     */     }
/*     */     catch (BadPasswordException ex) {
/* 484 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 487 */       throw new ExceptionConverter(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean compareArray(byte[] a, byte[] b, int len) {
/* 492 */     for (int k = 0; k < len; k++) {
/* 493 */       if (a[k] != b[k]) {
/* 494 */         return false;
/*     */       }
/*     */     }
/* 497 */     return true;
/*     */   }
/*     */   
/*     */   public static byte[] createDocumentId()
/*     */   {
/*     */     try {
/* 503 */       md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (Exception e) { MessageDigest md5;
/* 505 */       throw new ExceptionConverter(e); }
/*     */     MessageDigest md5;
/* 507 */     long time = System.currentTimeMillis();
/* 508 */     long mem = Runtime.getRuntime().freeMemory();
/* 509 */     String s = time + "+" + mem + "+" + seq++;
/* 510 */     return md5.digest(s.getBytes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setupByUserPassword(byte[] documentID, byte[] userPassword, byte[] ownerKey, long permissions)
/*     */   {
/* 517 */     setupByUserPad(documentID, padPassword(userPassword), ownerKey, permissions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupByUserPad(byte[] documentID, byte[] userPad, byte[] ownerKey, long permissions)
/*     */   {
/* 525 */     setupGlobalEncryptionKey(documentID, userPad, ownerKey, permissions);
/* 526 */     setupUserKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setupByOwnerPassword(byte[] documentID, byte[] ownerPassword, byte[] userKey, byte[] ownerKey, long permissions)
/*     */   {
/* 533 */     setupByOwnerPad(documentID, padPassword(ownerPassword), userKey, ownerKey, permissions);
/*     */   }
/*     */   
/*     */ 
/*     */   private void setupByOwnerPad(byte[] documentID, byte[] ownerPad, byte[] userKey, byte[] ownerKey, long permissions)
/*     */   {
/* 539 */     byte[] userPad = computeOwnerKey(ownerKey, ownerPad);
/*     */     
/*     */ 
/* 542 */     setupGlobalEncryptionKey(documentID, userPad, ownerKey, permissions);
/*     */     
/* 544 */     setupUserKey();
/*     */   }
/*     */   
/*     */   public void setKey(byte[] key) {
/* 548 */     this.key = key;
/*     */   }
/*     */   
/*     */   public void setupByEncryptionKey(byte[] key, int keylength) {
/* 552 */     this.mkey = new byte[keylength / 8];
/* 553 */     System.arraycopy(key, 0, this.mkey, 0, this.mkey.length);
/*     */   }
/*     */   
/*     */   public void setHashKey(int number, int generation) {
/* 557 */     if (this.revision == 5)
/* 558 */       return;
/* 559 */     this.md5.reset();
/* 560 */     this.extra[0] = ((byte)number);
/* 561 */     this.extra[1] = ((byte)(number >> 8));
/* 562 */     this.extra[2] = ((byte)(number >> 16));
/* 563 */     this.extra[3] = ((byte)generation);
/* 564 */     this.extra[4] = ((byte)(generation >> 8));
/* 565 */     this.md5.update(this.mkey);
/* 566 */     this.md5.update(this.extra);
/* 567 */     if (this.revision == 4)
/* 568 */       this.md5.update(salt);
/* 569 */     this.key = this.md5.digest();
/* 570 */     this.keySize = (this.mkey.length + 5);
/* 571 */     if (this.keySize > 16)
/* 572 */       this.keySize = 16;
/*     */   }
/*     */   
/*     */   public static PdfObject createInfoId(byte[] id, boolean modified) throws IOException {
/* 576 */     ByteBuffer buf = new ByteBuffer(90);
/* 577 */     if (id.length == 0)
/* 578 */       id = createDocumentId();
/* 579 */     buf.append('[').append('<');
/* 580 */     for (int k = 0; k < id.length; k++)
/* 581 */       buf.appendHex(id[k]);
/* 582 */     buf.append('>').append('<');
/* 583 */     if (modified)
/* 584 */       id = createDocumentId();
/* 585 */     for (int k = 0; k < id.length; k++)
/* 586 */       buf.appendHex(id[k]);
/* 587 */     buf.append('>').append(']');
/* 588 */     buf.close();
/* 589 */     return new PdfLiteral(buf.toByteArray());
/*     */   }
/*     */   
/*     */   public PdfDictionary getEncryptionDictionary() {
/* 593 */     PdfDictionary dic = new PdfDictionary();
/*     */     
/* 595 */     if (this.publicKeyHandler.getRecipientsSize() > 0) {
/* 596 */       PdfArray recipients = null;
/*     */       
/* 598 */       dic.put(PdfName.FILTER, PdfName.PUBSEC);
/* 599 */       dic.put(PdfName.R, new PdfNumber(this.revision));
/*     */       try
/*     */       {
/* 602 */         recipients = this.publicKeyHandler.getEncodedRecipients();
/*     */       } catch (Exception f) {
/* 604 */         throw new ExceptionConverter(f);
/*     */       }
/*     */       
/* 607 */       if (this.revision == 2) {
/* 608 */         dic.put(PdfName.V, new PdfNumber(1));
/* 609 */         dic.put(PdfName.SUBFILTER, PdfName.ADBE_PKCS7_S4);
/* 610 */         dic.put(PdfName.RECIPIENTS, recipients);
/* 611 */       } else if ((this.revision == 3) && (this.encryptMetadata)) {
/* 612 */         dic.put(PdfName.V, new PdfNumber(2));
/* 613 */         dic.put(PdfName.LENGTH, new PdfNumber(128));
/* 614 */         dic.put(PdfName.SUBFILTER, PdfName.ADBE_PKCS7_S4);
/* 615 */         dic.put(PdfName.RECIPIENTS, recipients);
/*     */       } else {
/* 617 */         if (this.revision == 5) {
/* 618 */           dic.put(PdfName.R, new PdfNumber(5));
/* 619 */           dic.put(PdfName.V, new PdfNumber(5));
/*     */         }
/*     */         else {
/* 622 */           dic.put(PdfName.R, new PdfNumber(4));
/* 623 */           dic.put(PdfName.V, new PdfNumber(4));
/*     */         }
/* 625 */         dic.put(PdfName.SUBFILTER, PdfName.ADBE_PKCS7_S5);
/*     */         
/* 627 */         PdfDictionary stdcf = new PdfDictionary();
/* 628 */         stdcf.put(PdfName.RECIPIENTS, recipients);
/* 629 */         if (!this.encryptMetadata)
/* 630 */           stdcf.put(PdfName.ENCRYPTMETADATA, PdfBoolean.PDFFALSE);
/* 631 */         if (this.revision == 4) {
/* 632 */           stdcf.put(PdfName.CFM, PdfName.AESV2);
/* 633 */           stdcf.put(PdfName.LENGTH, new PdfNumber(128));
/*     */         }
/* 635 */         else if (this.revision == 5) {
/* 636 */           stdcf.put(PdfName.CFM, PdfName.AESV3);
/* 637 */           stdcf.put(PdfName.LENGTH, new PdfNumber(256));
/*     */         }
/*     */         else {
/* 640 */           stdcf.put(PdfName.CFM, PdfName.V2); }
/* 641 */         PdfDictionary cf = new PdfDictionary();
/* 642 */         cf.put(PdfName.DEFAULTCRYPTFILTER, stdcf);
/* 643 */         dic.put(PdfName.CF, cf);
/* 644 */         if (this.embeddedFilesOnly) {
/* 645 */           dic.put(PdfName.EFF, PdfName.DEFAULTCRYPTFILTER);
/* 646 */           dic.put(PdfName.STRF, PdfName.IDENTITY);
/* 647 */           dic.put(PdfName.STMF, PdfName.IDENTITY);
/*     */         }
/*     */         else {
/* 650 */           dic.put(PdfName.STRF, PdfName.DEFAULTCRYPTFILTER);
/* 651 */           dic.put(PdfName.STMF, PdfName.DEFAULTCRYPTFILTER);
/*     */         }
/*     */       }
/*     */       
/* 655 */       MessageDigest md = null;
/* 656 */       byte[] encodedRecipient = null;
/*     */       try
/*     */       {
/* 659 */         if (this.revision == 5) {
/* 660 */           md = MessageDigest.getInstance("SHA-256");
/*     */         } else
/* 662 */           md = MessageDigest.getInstance("SHA-1");
/* 663 */         md.update(this.publicKeyHandler.getSeed());
/* 664 */         for (int i = 0; i < this.publicKeyHandler.getRecipientsSize(); i++) {
/* 665 */           encodedRecipient = this.publicKeyHandler.getEncodedRecipient(i);
/* 666 */           md.update(encodedRecipient);
/*     */         }
/* 668 */         if (!this.encryptMetadata) {
/* 669 */           md.update(new byte[] { -1, -1, -1, -1 });
/*     */         }
/*     */       } catch (Exception f) {
/* 672 */         throw new ExceptionConverter(f);
/*     */       }
/*     */       
/* 675 */       byte[] mdResult = md.digest();
/*     */       
/* 677 */       if (this.revision == 5) {
/* 678 */         this.key = mdResult;
/*     */       } else
/* 680 */         setupByEncryptionKey(mdResult, this.keyLength);
/*     */     } else {
/* 682 */       dic.put(PdfName.FILTER, PdfName.STANDARD);
/* 683 */       dic.put(PdfName.O, new PdfLiteral(
/* 684 */         StringUtils.escapeString(this.ownerKey)));
/* 685 */       dic.put(PdfName.U, new PdfLiteral(
/* 686 */         StringUtils.escapeString(this.userKey)));
/* 687 */       dic.put(PdfName.P, new PdfNumber(this.permissions));
/* 688 */       dic.put(PdfName.R, new PdfNumber(this.revision));
/*     */       
/* 690 */       if (this.revision == 2) {
/* 691 */         dic.put(PdfName.V, new PdfNumber(1));
/* 692 */       } else if ((this.revision == 3) && (this.encryptMetadata)) {
/* 693 */         dic.put(PdfName.V, new PdfNumber(2));
/* 694 */         dic.put(PdfName.LENGTH, new PdfNumber(128));
/*     */ 
/*     */       }
/* 697 */       else if (this.revision == 5) {
/* 698 */         if (!this.encryptMetadata)
/* 699 */           dic.put(PdfName.ENCRYPTMETADATA, PdfBoolean.PDFFALSE);
/* 700 */         dic.put(PdfName.OE, new PdfLiteral(
/* 701 */           StringUtils.escapeString(this.oeKey)));
/* 702 */         dic.put(PdfName.UE, new PdfLiteral(
/* 703 */           StringUtils.escapeString(this.ueKey)));
/* 704 */         dic.put(PdfName.PERMS, new PdfLiteral(
/* 705 */           StringUtils.escapeString(this.perms)));
/* 706 */         dic.put(PdfName.V, new PdfNumber(this.revision));
/* 707 */         dic.put(PdfName.LENGTH, new PdfNumber(256));
/* 708 */         PdfDictionary stdcf = new PdfDictionary();
/* 709 */         stdcf.put(PdfName.LENGTH, new PdfNumber(32));
/* 710 */         if (this.embeddedFilesOnly) {
/* 711 */           stdcf.put(PdfName.AUTHEVENT, PdfName.EFOPEN);
/* 712 */           dic.put(PdfName.EFF, PdfName.STDCF);
/* 713 */           dic.put(PdfName.STRF, PdfName.IDENTITY);
/* 714 */           dic.put(PdfName.STMF, PdfName.IDENTITY);
/*     */         }
/*     */         else {
/* 717 */           stdcf.put(PdfName.AUTHEVENT, PdfName.DOCOPEN);
/* 718 */           dic.put(PdfName.STRF, PdfName.STDCF);
/* 719 */           dic.put(PdfName.STMF, PdfName.STDCF);
/*     */         }
/* 721 */         stdcf.put(PdfName.CFM, PdfName.AESV3);
/* 722 */         PdfDictionary cf = new PdfDictionary();
/* 723 */         cf.put(PdfName.STDCF, stdcf);
/* 724 */         dic.put(PdfName.CF, cf);
/*     */       }
/*     */       else {
/* 727 */         if (!this.encryptMetadata)
/* 728 */           dic.put(PdfName.ENCRYPTMETADATA, PdfBoolean.PDFFALSE);
/* 729 */         dic.put(PdfName.R, new PdfNumber(4));
/* 730 */         dic.put(PdfName.V, new PdfNumber(4));
/* 731 */         dic.put(PdfName.LENGTH, new PdfNumber(128));
/* 732 */         PdfDictionary stdcf = new PdfDictionary();
/* 733 */         stdcf.put(PdfName.LENGTH, new PdfNumber(16));
/* 734 */         if (this.embeddedFilesOnly) {
/* 735 */           stdcf.put(PdfName.AUTHEVENT, PdfName.EFOPEN);
/* 736 */           dic.put(PdfName.EFF, PdfName.STDCF);
/* 737 */           dic.put(PdfName.STRF, PdfName.IDENTITY);
/* 738 */           dic.put(PdfName.STMF, PdfName.IDENTITY);
/*     */         }
/*     */         else {
/* 741 */           stdcf.put(PdfName.AUTHEVENT, PdfName.DOCOPEN);
/* 742 */           dic.put(PdfName.STRF, PdfName.STDCF);
/* 743 */           dic.put(PdfName.STMF, PdfName.STDCF);
/*     */         }
/* 745 */         if (this.revision == 4) {
/* 746 */           stdcf.put(PdfName.CFM, PdfName.AESV2);
/*     */         } else
/* 748 */           stdcf.put(PdfName.CFM, PdfName.V2);
/* 749 */         PdfDictionary cf = new PdfDictionary();
/* 750 */         cf.put(PdfName.STDCF, stdcf);
/* 751 */         dic.put(PdfName.CF, cf);
/*     */       }
/*     */     }
/*     */     
/* 755 */     return dic;
/*     */   }
/*     */   
/*     */   public PdfObject getFileID(boolean modified) throws IOException {
/* 759 */     return createInfoId(this.documentID, modified);
/*     */   }
/*     */   
/*     */   public OutputStreamEncryption getEncryptionStream(OutputStream os) {
/* 763 */     return new OutputStreamEncryption(os, this.key, 0, this.keySize, this.revision);
/*     */   }
/*     */   
/*     */   public int calculateStreamSize(int n) {
/* 767 */     if ((this.revision == 4) || (this.revision == 5)) {
/* 768 */       return (n & 0x7FFFFFF0) + 32;
/*     */     }
/* 770 */     return n;
/*     */   }
/*     */   
/*     */   public byte[] encryptByteArray(byte[] b) {
/*     */     try {
/* 775 */       ByteArrayOutputStream ba = new ByteArrayOutputStream();
/* 776 */       OutputStreamEncryption os2 = getEncryptionStream(ba);
/* 777 */       os2.write(b);
/* 778 */       os2.finish();
/* 779 */       return ba.toByteArray();
/*     */     } catch (IOException ex) {
/* 781 */       throw new ExceptionConverter(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public StandardDecryption getDecryptor() {
/* 786 */     return new StandardDecryption(this.key, 0, this.keySize, this.revision);
/*     */   }
/*     */   
/*     */   public byte[] decryptByteArray(byte[] b) {
/*     */     try {
/* 791 */       ByteArrayOutputStream ba = new ByteArrayOutputStream();
/* 792 */       StandardDecryption dec = getDecryptor();
/* 793 */       byte[] b2 = dec.update(b, 0, b.length);
/* 794 */       if (b2 != null)
/* 795 */         ba.write(b2);
/* 796 */       b2 = dec.finish();
/* 797 */       if (b2 != null)
/* 798 */         ba.write(b2);
/* 799 */       return ba.toByteArray();
/*     */     } catch (IOException ex) {
/* 801 */       throw new ExceptionConverter(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addRecipient(Certificate cert, int permission) {
/* 806 */     this.documentID = createDocumentId();
/* 807 */     this.publicKeyHandler.addRecipient(new PdfPublicKeyRecipient(cert, permission));
/*     */   }
/*     */   
/*     */   public byte[] computeUserPassword(byte[] ownerPassword)
/*     */   {
/* 812 */     byte[] userPad = computeOwnerKey(this.ownerKey, padPassword(ownerPassword));
/* 813 */     for (int i = 0; i < userPad.length; i++) {
/* 814 */       boolean match = true;
/* 815 */       for (int j = 0; j < userPad.length - i; j++) {
/* 816 */         if (userPad[(i + j)] != pad[j]) {
/* 817 */           match = false;
/* 818 */           break;
/*     */         }
/*     */       }
/* 821 */       if (match) {
/* 822 */         byte[] userPassword = new byte[i];
/* 823 */         System.arraycopy(userPad, 0, userPassword, 0, i);
/* 824 */         return userPassword;
/*     */       } }
/* 826 */     return userPad;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfEncryption.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */