/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.awt.FontMapper;
/*      */ import com.itextpdf.awt.PdfGraphics2D;
/*      */ import com.itextpdf.awt.PdfPrinterGraphics2D;
/*      */ import com.itextpdf.awt.geom.Point2D;
/*      */ import com.itextpdf.awt.geom.Point2D.Float;
/*      */ import com.itextpdf.text.Annotation;
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.ImgJBIG2;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.exceptions.IllegalPdfSyntaxException;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import com.itextpdf.text.pdf.internal.PdfAnnotationsImp;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.print.PrinterJob;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfContentByte
/*      */ {
/*      */   public static final int ALIGN_CENTER = 1;
/*      */   public static final int ALIGN_LEFT = 0;
/*      */   public static final int ALIGN_RIGHT = 2;
/*      */   public static final int LINE_CAP_BUTT = 0;
/*      */   public static final int LINE_CAP_ROUND = 1;
/*      */   public static final int LINE_CAP_PROJECTING_SQUARE = 2;
/*      */   public static final int LINE_JOIN_MITER = 0;
/*      */   public static final int LINE_JOIN_ROUND = 1;
/*      */   public static final int LINE_JOIN_BEVEL = 2;
/*      */   public static final int TEXT_RENDER_MODE_FILL = 0;
/*      */   public static final int TEXT_RENDER_MODE_STROKE = 1;
/*      */   public static final int TEXT_RENDER_MODE_FILL_STROKE = 2;
/*      */   public static final int TEXT_RENDER_MODE_INVISIBLE = 3;
/*      */   public static final int TEXT_RENDER_MODE_FILL_CLIP = 4;
/*      */   public static final int TEXT_RENDER_MODE_STROKE_CLIP = 5;
/*      */   public static final int TEXT_RENDER_MODE_FILL_STROKE_CLIP = 6;
/*      */   public static final int TEXT_RENDER_MODE_CLIP = 7;
/*      */   
/*      */   public static class GraphicState
/*      */   {
/*      */     FontDetails fontDetails;
/*      */     ColorDetails colorDetails;
/*      */     float size;
/*   96 */     protected float xTLM = 0.0F;
/*      */     
/*   98 */     protected float yTLM = 0.0F;
/*      */     
/*  100 */     protected float aTLM = 1.0F;
/*  101 */     protected float bTLM = 0.0F;
/*  102 */     protected float cTLM = 0.0F;
/*  103 */     protected float dTLM = 1.0F;
/*      */     
/*  105 */     protected float tx = 0.0F;
/*      */     
/*      */ 
/*  108 */     protected float leading = 0.0F;
/*      */     
/*      */ 
/*  111 */     protected float scale = 100.0F;
/*      */     
/*      */ 
/*  114 */     protected float charSpace = 0.0F;
/*      */     
/*      */ 
/*  117 */     protected float wordSpace = 0.0F;
/*      */     
/*  119 */     protected BaseColor colorFill = new GrayColor(0);
/*  120 */     protected BaseColor colorStroke = new GrayColor(0);
/*  121 */     protected int textRenderMode = 0;
/*  122 */     protected com.itextpdf.awt.geom.AffineTransform CTM = new com.itextpdf.awt.geom.AffineTransform();
/*  123 */     protected PdfObject extGState = null;
/*      */     
/*      */     GraphicState() {}
/*      */     
/*      */     GraphicState(GraphicState cp)
/*      */     {
/*  129 */       copyParameters(cp);
/*      */     }
/*      */     
/*      */     void copyParameters(GraphicState cp) {
/*  133 */       this.fontDetails = cp.fontDetails;
/*  134 */       this.colorDetails = cp.colorDetails;
/*  135 */       this.size = cp.size;
/*  136 */       this.xTLM = cp.xTLM;
/*  137 */       this.yTLM = cp.yTLM;
/*  138 */       this.aTLM = cp.aTLM;
/*  139 */       this.bTLM = cp.bTLM;
/*  140 */       this.cTLM = cp.cTLM;
/*  141 */       this.dTLM = cp.dTLM;
/*  142 */       this.tx = cp.tx;
/*  143 */       this.leading = cp.leading;
/*  144 */       this.scale = cp.scale;
/*  145 */       this.charSpace = cp.charSpace;
/*  146 */       this.wordSpace = cp.wordSpace;
/*  147 */       this.colorFill = cp.colorFill;
/*  148 */       this.colorStroke = cp.colorStroke;
/*  149 */       this.CTM = new com.itextpdf.awt.geom.AffineTransform(cp.CTM);
/*  150 */       this.textRenderMode = cp.textRenderMode;
/*  151 */       this.extGState = cp.extGState;
/*      */     }
/*      */     
/*      */     void restore(GraphicState restore) {
/*  155 */       copyParameters(restore);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  199 */   private static final float[] unitRect = { 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F };
/*      */   
/*      */ 
/*      */ 
/*  203 */   protected ByteBuffer content = new ByteBuffer();
/*      */   
/*  205 */   protected int markedContentSize = 0;
/*      */   
/*      */ 
/*      */   protected PdfWriter writer;
/*      */   
/*      */ 
/*      */   protected PdfDocument pdf;
/*      */   
/*      */ 
/*  214 */   protected GraphicState state = new GraphicState();
/*      */   
/*      */ 
/*  217 */   protected ArrayList<GraphicState> stateList = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */   protected ArrayList<Integer> layerDepth;
/*      */   
/*      */ 
/*  224 */   protected int separator = 10;
/*      */   
/*  226 */   private int mcDepth = 0;
/*  227 */   private boolean inText = false;
/*      */   
/*  229 */   private static HashMap<PdfName, String> abrev = new HashMap();
/*      */   
/*  231 */   private ArrayList<IAccessibleElement> mcElements = new ArrayList();
/*      */   
/*  233 */   protected PdfContentByte duplicatedFrom = null;
/*      */   
/*      */   static {
/*  236 */     abrev.put(PdfName.BITSPERCOMPONENT, "/BPC ");
/*  237 */     abrev.put(PdfName.COLORSPACE, "/CS ");
/*  238 */     abrev.put(PdfName.DECODE, "/D ");
/*  239 */     abrev.put(PdfName.DECODEPARMS, "/DP ");
/*  240 */     abrev.put(PdfName.FILTER, "/F ");
/*  241 */     abrev.put(PdfName.HEIGHT, "/H ");
/*  242 */     abrev.put(PdfName.IMAGEMASK, "/IM ");
/*  243 */     abrev.put(PdfName.INTENT, "/Intent ");
/*  244 */     abrev.put(PdfName.INTERPOLATE, "/I ");
/*  245 */     abrev.put(PdfName.WIDTH, "/W ");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfContentByte(PdfWriter wr)
/*      */   {
/*  257 */     if (wr != null) {
/*  258 */       this.writer = wr;
/*  259 */       this.pdf = this.writer.getPdfDocument();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  273 */     return this.content.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTagged()
/*      */   {
/*  281 */     return (this.writer != null) && (this.writer.isTagged());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ByteBuffer getInternalBuffer()
/*      */   {
/*  289 */     return this.content;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] toPdf(PdfWriter writer)
/*      */   {
/*  299 */     sanityCheck();
/*  300 */     return this.content.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(PdfContentByte other)
/*      */   {
/*  312 */     if ((other.writer != null) && (this.writer != other.writer))
/*  313 */       throw new RuntimeException(MessageLocalization.getComposedMessage("inconsistent.writers.are.you.mixing.two.documents", new Object[0]));
/*  314 */     this.content.append(other.content);
/*  315 */     this.markedContentSize += other.markedContentSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getXTLM()
/*      */   {
/*  324 */     return this.state.xTLM;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getYTLM()
/*      */   {
/*  333 */     return this.state.yTLM;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getLeading()
/*      */   {
/*  342 */     return this.state.leading;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getCharacterSpacing()
/*      */   {
/*  351 */     return this.state.charSpace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getWordSpacing()
/*      */   {
/*  360 */     return this.state.wordSpace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getHorizontalScaling()
/*      */   {
/*  369 */     return this.state.scale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFlatness(float flatness)
/*      */   {
/*  382 */     setFlatness(flatness);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFlatness(double flatness)
/*      */   {
/*  395 */     if ((flatness >= 0.0D) && (flatness <= 100.0D)) {
/*  396 */       this.content.append(flatness).append(" i").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineCap(int style)
/*      */   {
/*  411 */     if ((style >= 0) && (style <= 2)) {
/*  412 */       this.content.append(style).append(" J").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRenderingIntent(PdfName ri)
/*      */   {
/*  422 */     this.content.append(ri.getBytes()).append(" ri").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(float phase)
/*      */   {
/*  437 */     setLineDash(phase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(double phase)
/*      */   {
/*  452 */     this.content.append("[] ").append(phase).append(" d").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(float unitsOn, float phase)
/*      */   {
/*  468 */     setLineDash(unitsOn, phase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(double unitsOn, double phase)
/*      */   {
/*  484 */     this.content.append("[").append(unitsOn).append("] ").append(phase).append(" d").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(float unitsOn, float unitsOff, float phase)
/*      */   {
/*  501 */     setLineDash(unitsOn, unitsOff, phase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(double unitsOn, double unitsOff, double phase)
/*      */   {
/*  518 */     this.content.append("[").append(unitsOn).append(' ').append(unitsOff).append("] ").append(phase).append(" d").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setLineDash(float[] array, float phase)
/*      */   {
/*  534 */     this.content.append("[");
/*  535 */     for (int i = 0; i < array.length; i++) {
/*  536 */       this.content.append(array[i]);
/*  537 */       if (i < array.length - 1) this.content.append(' ');
/*      */     }
/*  539 */     this.content.append("] ").append(phase).append(" d").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setLineDash(double[] array, double phase)
/*      */   {
/*  555 */     this.content.append("[");
/*  556 */     for (int i = 0; i < array.length; i++) {
/*  557 */       this.content.append(array[i]);
/*  558 */       if (i < array.length - 1) this.content.append(' ');
/*      */     }
/*  560 */     this.content.append("] ").append(phase).append(" d").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineJoin(int style)
/*      */   {
/*  574 */     if ((style >= 0) && (style <= 2)) {
/*  575 */       this.content.append(style).append(" j").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineWidth(float w)
/*      */   {
/*  589 */     setLineWidth(w);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineWidth(double w)
/*      */   {
/*  602 */     this.content.append(w).append(" w").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMiterLimit(float miterLimit)
/*      */   {
/*  617 */     setMiterLimit(miterLimit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMiterLimit(double miterLimit)
/*      */   {
/*  632 */     if (miterLimit > 1.0D) {
/*  633 */       this.content.append(miterLimit).append(" M").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clip()
/*      */   {
/*  644 */     if ((this.inText) && (isTagged())) {
/*  645 */       endText();
/*      */     }
/*  647 */     this.content.append("W").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void eoClip()
/*      */   {
/*  656 */     if ((this.inText) && (isTagged())) {
/*  657 */       endText();
/*      */     }
/*  659 */     this.content.append("W*").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGrayFill(float gray)
/*      */   {
/*  672 */     saveColor(new GrayColor(gray), true);
/*  673 */     this.content.append(gray).append(" g").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetGrayFill()
/*      */   {
/*  681 */     saveColor(new GrayColor(0), true);
/*  682 */     this.content.append("0 g").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGrayStroke(float gray)
/*      */   {
/*  695 */     saveColor(new GrayColor(gray), false);
/*  696 */     this.content.append(gray).append(" G").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetGrayStroke()
/*      */   {
/*  704 */     saveColor(new GrayColor(0), false);
/*  705 */     this.content.append("0 G").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void HelperRGB(float red, float green, float blue)
/*      */   {
/*  715 */     if (red < 0.0F) {
/*  716 */       red = 0.0F;
/*  717 */     } else if (red > 1.0F)
/*  718 */       red = 1.0F;
/*  719 */     if (green < 0.0F) {
/*  720 */       green = 0.0F;
/*  721 */     } else if (green > 1.0F)
/*  722 */       green = 1.0F;
/*  723 */     if (blue < 0.0F) {
/*  724 */       blue = 0.0F;
/*  725 */     } else if (blue > 1.0F)
/*  726 */       blue = 1.0F;
/*  727 */     this.content.append(red).append(' ').append(green).append(' ').append(blue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRGBColorFillF(float red, float green, float blue)
/*      */   {
/*  745 */     saveColor(new BaseColor(red, green, blue), true);
/*  746 */     HelperRGB(red, green, blue);
/*  747 */     this.content.append(" rg").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetRGBColorFill()
/*      */   {
/*  755 */     resetGrayFill();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRGBColorStrokeF(float red, float green, float blue)
/*      */   {
/*  773 */     saveColor(new BaseColor(red, green, blue), false);
/*  774 */     HelperRGB(red, green, blue);
/*  775 */     this.content.append(" RG").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetRGBColorStroke()
/*      */   {
/*  784 */     resetGrayStroke();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void HelperCMYK(float cyan, float magenta, float yellow, float black)
/*      */   {
/*  796 */     if (cyan < 0.0F) {
/*  797 */       cyan = 0.0F;
/*  798 */     } else if (cyan > 1.0F)
/*  799 */       cyan = 1.0F;
/*  800 */     if (magenta < 0.0F) {
/*  801 */       magenta = 0.0F;
/*  802 */     } else if (magenta > 1.0F)
/*  803 */       magenta = 1.0F;
/*  804 */     if (yellow < 0.0F) {
/*  805 */       yellow = 0.0F;
/*  806 */     } else if (yellow > 1.0F)
/*  807 */       yellow = 1.0F;
/*  808 */     if (black < 0.0F) {
/*  809 */       black = 0.0F;
/*  810 */     } else if (black > 1.0F)
/*  811 */       black = 1.0F;
/*  812 */     this.content.append(cyan).append(' ').append(magenta).append(' ').append(yellow).append(' ').append(black);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCMYKColorFillF(float cyan, float magenta, float yellow, float black)
/*      */   {
/*  831 */     saveColor(new CMYKColor(cyan, magenta, yellow, black), true);
/*  832 */     HelperCMYK(cyan, magenta, yellow, black);
/*  833 */     this.content.append(" k").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetCMYKColorFill()
/*      */   {
/*  842 */     saveColor(new CMYKColor(0, 0, 0, 1), true);
/*  843 */     this.content.append("0 0 0 1 k").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCMYKColorStrokeF(float cyan, float magenta, float yellow, float black)
/*      */   {
/*  862 */     saveColor(new CMYKColor(cyan, magenta, yellow, black), false);
/*  863 */     HelperCMYK(cyan, magenta, yellow, black);
/*  864 */     this.content.append(" K").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetCMYKColorStroke()
/*      */   {
/*  873 */     saveColor(new CMYKColor(0, 0, 0, 1), false);
/*  874 */     this.content.append("0 0 0 1 K").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveTo(float x, float y)
/*      */   {
/*  885 */     moveTo(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveTo(double x, double y)
/*      */   {
/*  896 */     if (this.inText) {
/*  897 */       if (isTagged()) {
/*  898 */         endText();
/*      */       } else {
/*  900 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/*  903 */     this.content.append(x).append(' ').append(y).append(" m").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lineTo(float x, float y)
/*      */   {
/*  915 */     lineTo(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lineTo(double x, double y)
/*      */   {
/*  927 */     if (this.inText) {
/*  928 */       if (isTagged()) {
/*  929 */         endText();
/*      */       } else {
/*  931 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/*  934 */     this.content.append(x).append(' ').append(y).append(" l").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void curveTo(float x1, float y1, float x2, float y2, float x3, float y3)
/*      */   {
/*  949 */     curveTo(x1, y1, x2, y2, x3, y3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void curveTo(double x1, double y1, double x2, double y2, double x3, double y3)
/*      */   {
/*  964 */     if (this.inText) {
/*  965 */       if (isTagged()) {
/*  966 */         endText();
/*      */       } else {
/*  968 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/*  971 */     this.content.append(x1).append(' ').append(y1).append(' ').append(x2).append(' ').append(y2).append(' ').append(x3).append(' ').append(y3).append(" c").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void curveTo(float x2, float y2, float x3, float y3)
/*      */   {
/*  984 */     curveTo(x2, y2, x3, y3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void curveTo(double x2, double y2, double x3, double y3)
/*      */   {
/*  996 */     if (this.inText) {
/*  997 */       if (isTagged()) {
/*  998 */         endText();
/*      */       } else {
/* 1000 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1003 */     this.content.append(x2).append(' ').append(y2).append(' ').append(x3).append(' ').append(y3).append(" v").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void curveFromTo(float x1, float y1, float x3, float y3)
/*      */   {
/* 1016 */     curveFromTo(x1, y1, x3, y3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void curveFromTo(double x1, double y1, double x3, double y3)
/*      */   {
/* 1029 */     if (this.inText) {
/* 1030 */       if (isTagged()) {
/* 1031 */         endText();
/*      */       } else {
/* 1033 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1036 */     this.content.append(x1).append(' ').append(y1).append(' ').append(x3).append(' ').append(y3).append(" y").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void circle(float x, float y, float r)
/*      */   {
/* 1046 */     circle(x, y, r);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void circle(double x, double y, double r)
/*      */   {
/* 1056 */     float b = 0.5523F;
/* 1057 */     moveTo(x + r, y);
/* 1058 */     curveTo(x + r, y + r * b, x + r * b, y + r, x, y + r);
/* 1059 */     curveTo(x - r * b, y + r, x - r, y + r * b, x - r, y);
/* 1060 */     curveTo(x - r, y - r * b, x - r * b, y - r, x, y - r);
/* 1061 */     curveTo(x + r * b, y - r, x + r, y - r * b, x + r, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rectangle(float x, float y, float w, float h)
/*      */   {
/* 1074 */     rectangle(x, y, w, h);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rectangle(double x, double y, double w, double h)
/*      */   {
/* 1087 */     if (this.inText) {
/* 1088 */       if (isTagged()) {
/* 1089 */         endText();
/*      */       } else {
/* 1091 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1094 */     this.content.append(x).append(' ').append(y).append(' ').append(w).append(' ').append(h).append(" re").append_i(this.separator);
/*      */   }
/*      */   
/*      */   private boolean compareColors(BaseColor c1, BaseColor c2) {
/* 1098 */     if ((c1 == null) && (c2 == null))
/* 1099 */       return true;
/* 1100 */     if ((c1 == null) || (c2 == null))
/* 1101 */       return false;
/* 1102 */     if ((c1 instanceof ExtendedColor))
/* 1103 */       return c1.equals(c2);
/* 1104 */     return c2.equals(c1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void variableRectangle(Rectangle rect)
/*      */   {
/* 1114 */     float t = rect.getTop();
/* 1115 */     float b = rect.getBottom();
/* 1116 */     float r = rect.getRight();
/* 1117 */     float l = rect.getLeft();
/* 1118 */     float wt = rect.getBorderWidthTop();
/* 1119 */     float wb = rect.getBorderWidthBottom();
/* 1120 */     float wr = rect.getBorderWidthRight();
/* 1121 */     float wl = rect.getBorderWidthLeft();
/* 1122 */     BaseColor ct = rect.getBorderColorTop();
/* 1123 */     BaseColor cb = rect.getBorderColorBottom();
/* 1124 */     BaseColor cr = rect.getBorderColorRight();
/* 1125 */     BaseColor cl = rect.getBorderColorLeft();
/* 1126 */     saveState();
/* 1127 */     setLineCap(0);
/* 1128 */     setLineJoin(0);
/* 1129 */     float clw = 0.0F;
/* 1130 */     boolean cdef = false;
/* 1131 */     BaseColor ccol = null;
/* 1132 */     boolean cdefi = false;
/* 1133 */     BaseColor cfil = null;
/*      */     
/* 1135 */     if (wt > 0.0F) {
/* 1136 */       setLineWidth(clw = wt);
/* 1137 */       cdef = true;
/* 1138 */       if (ct == null) {
/* 1139 */         resetRGBColorStroke();
/*      */       } else
/* 1141 */         setColorStroke(ct);
/* 1142 */       ccol = ct;
/* 1143 */       moveTo(l, t - wt / 2.0F);
/* 1144 */       lineTo(r, t - wt / 2.0F);
/* 1145 */       stroke();
/*      */     }
/*      */     
/*      */ 
/* 1149 */     if (wb > 0.0F) {
/* 1150 */       if (wb != clw)
/* 1151 */         setLineWidth(clw = wb);
/* 1152 */       if ((!cdef) || (!compareColors(ccol, cb))) {
/* 1153 */         cdef = true;
/* 1154 */         if (cb == null) {
/* 1155 */           resetRGBColorStroke();
/*      */         } else
/* 1157 */           setColorStroke(cb);
/* 1158 */         ccol = cb;
/*      */       }
/* 1160 */       moveTo(r, b + wb / 2.0F);
/* 1161 */       lineTo(l, b + wb / 2.0F);
/* 1162 */       stroke();
/*      */     }
/*      */     
/*      */ 
/* 1166 */     if (wr > 0.0F) {
/* 1167 */       if (wr != clw)
/* 1168 */         setLineWidth(clw = wr);
/* 1169 */       if ((!cdef) || (!compareColors(ccol, cr))) {
/* 1170 */         cdef = true;
/* 1171 */         if (cr == null) {
/* 1172 */           resetRGBColorStroke();
/*      */         } else
/* 1174 */           setColorStroke(cr);
/* 1175 */         ccol = cr;
/*      */       }
/* 1177 */       boolean bt = compareColors(ct, cr);
/* 1178 */       boolean bb = compareColors(cb, cr);
/* 1179 */       moveTo(r - wr / 2.0F, bt ? t : t - wt);
/* 1180 */       lineTo(r - wr / 2.0F, bb ? b : b + wb);
/* 1181 */       stroke();
/* 1182 */       if ((!bt) || (!bb)) {
/* 1183 */         cdefi = true;
/* 1184 */         if (cr == null) {
/* 1185 */           resetRGBColorFill();
/*      */         } else
/* 1187 */           setColorFill(cr);
/* 1188 */         cfil = cr;
/* 1189 */         if (!bt) {
/* 1190 */           moveTo(r, t);
/* 1191 */           lineTo(r, t - wt);
/* 1192 */           lineTo(r - wr, t - wt);
/* 1193 */           fill();
/*      */         }
/* 1195 */         if (!bb) {
/* 1196 */           moveTo(r, b);
/* 1197 */           lineTo(r, b + wb);
/* 1198 */           lineTo(r - wr, b + wb);
/* 1199 */           fill();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1205 */     if (wl > 0.0F) {
/* 1206 */       if (wl != clw)
/* 1207 */         setLineWidth(wl);
/* 1208 */       if ((!cdef) || (!compareColors(ccol, cl))) {
/* 1209 */         if (cl == null) {
/* 1210 */           resetRGBColorStroke();
/*      */         } else
/* 1212 */           setColorStroke(cl);
/*      */       }
/* 1214 */       boolean bt = compareColors(ct, cl);
/* 1215 */       boolean bb = compareColors(cb, cl);
/* 1216 */       moveTo(l + wl / 2.0F, bt ? t : t - wt);
/* 1217 */       lineTo(l + wl / 2.0F, bb ? b : b + wb);
/* 1218 */       stroke();
/* 1219 */       if ((!bt) || (!bb)) {
/* 1220 */         if ((!cdefi) || (!compareColors(cfil, cl))) {
/* 1221 */           if (cl == null) {
/* 1222 */             resetRGBColorFill();
/*      */           } else
/* 1224 */             setColorFill(cl);
/*      */         }
/* 1226 */         if (!bt) {
/* 1227 */           moveTo(l, t);
/* 1228 */           lineTo(l, t - wt);
/* 1229 */           lineTo(l + wl, t - wt);
/* 1230 */           fill();
/*      */         }
/* 1232 */         if (!bb) {
/* 1233 */           moveTo(l, b);
/* 1234 */           lineTo(l, b + wb);
/* 1235 */           lineTo(l + wl, b + wb);
/* 1236 */           fill();
/*      */         }
/*      */       }
/*      */     }
/* 1240 */     restoreState();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rectangle(Rectangle rectangle)
/*      */   {
/* 1251 */     float x1 = rectangle.getLeft();
/* 1252 */     float y1 = rectangle.getBottom();
/* 1253 */     float x2 = rectangle.getRight();
/* 1254 */     float y2 = rectangle.getTop();
/*      */     
/*      */ 
/* 1257 */     BaseColor background = rectangle.getBackgroundColor();
/* 1258 */     if (background != null) {
/* 1259 */       saveState();
/* 1260 */       setColorFill(background);
/* 1261 */       rectangle(x1, y1, x2 - x1, y2 - y1);
/* 1262 */       fill();
/* 1263 */       restoreState();
/*      */     }
/*      */     
/*      */ 
/* 1267 */     if (!rectangle.hasBorders()) {
/* 1268 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1274 */     if (rectangle.isUseVariableBorders()) {
/* 1275 */       variableRectangle(rectangle);
/*      */     }
/*      */     else
/*      */     {
/* 1279 */       if (rectangle.getBorderWidth() != -1.0F) {
/* 1280 */         setLineWidth(rectangle.getBorderWidth());
/*      */       }
/*      */       
/*      */ 
/* 1284 */       BaseColor color = rectangle.getBorderColor();
/* 1285 */       if (color != null) {
/* 1286 */         setColorStroke(color);
/*      */       }
/*      */       
/*      */ 
/* 1290 */       if (rectangle.hasBorder(15)) {
/* 1291 */         rectangle(x1, y1, x2 - x1, y2 - y1);
/*      */       }
/*      */       else
/*      */       {
/* 1295 */         if (rectangle.hasBorder(8)) {
/* 1296 */           moveTo(x2, y1);
/* 1297 */           lineTo(x2, y2);
/*      */         }
/* 1299 */         if (rectangle.hasBorder(4)) {
/* 1300 */           moveTo(x1, y1);
/* 1301 */           lineTo(x1, y2);
/*      */         }
/* 1303 */         if (rectangle.hasBorder(2)) {
/* 1304 */           moveTo(x1, y1);
/* 1305 */           lineTo(x2, y1);
/*      */         }
/* 1307 */         if (rectangle.hasBorder(1)) {
/* 1308 */           moveTo(x1, y2);
/* 1309 */           lineTo(x2, y2);
/*      */         }
/*      */       }
/*      */       
/* 1313 */       stroke();
/*      */       
/* 1315 */       if (color != null) {
/* 1316 */         resetRGBColorStroke();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closePath()
/*      */   {
/* 1327 */     if (this.inText) {
/* 1328 */       if (isTagged()) {
/* 1329 */         endText();
/*      */       } else {
/* 1331 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1334 */     this.content.append("h").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void newPath()
/*      */   {
/* 1342 */     if (this.inText) {
/* 1343 */       if (isTagged()) {
/* 1344 */         endText();
/*      */       } else {
/* 1346 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1349 */     this.content.append("n").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stroke()
/*      */   {
/* 1357 */     if (this.inText) {
/* 1358 */       if (isTagged()) {
/* 1359 */         endText();
/*      */       } else {
/* 1361 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1364 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/* 1365 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1366 */     this.content.append("S").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closePathStroke()
/*      */   {
/* 1374 */     if (this.inText) {
/* 1375 */       if (isTagged()) {
/* 1376 */         endText();
/*      */       } else {
/* 1378 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1381 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/* 1382 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1383 */     this.content.append("s").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fill()
/*      */   {
/* 1391 */     if (this.inText) {
/* 1392 */       if (isTagged()) {
/* 1393 */         endText();
/*      */       } else {
/* 1395 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1398 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/* 1399 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1400 */     this.content.append("f").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void eoFill()
/*      */   {
/* 1408 */     if (this.inText) {
/* 1409 */       if (isTagged()) {
/* 1410 */         endText();
/*      */       } else {
/* 1412 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1415 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/* 1416 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1417 */     this.content.append("f*").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillStroke()
/*      */   {
/* 1425 */     if (this.inText) {
/* 1426 */       if (isTagged()) {
/* 1427 */         endText();
/*      */       } else {
/* 1429 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1432 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/* 1433 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/* 1434 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1435 */     this.content.append("B").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closePathFillStroke()
/*      */   {
/* 1443 */     if (this.inText) {
/* 1444 */       if (isTagged()) {
/* 1445 */         endText();
/*      */       } else {
/* 1447 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1450 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/* 1451 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/* 1452 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1453 */     this.content.append("b").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void eoFillStroke()
/*      */   {
/* 1461 */     if (this.inText) {
/* 1462 */       if (isTagged()) {
/* 1463 */         endText();
/*      */       } else {
/* 1465 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1468 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/* 1469 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/* 1470 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1471 */     this.content.append("B*").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closePathEoFillStroke()
/*      */   {
/* 1479 */     if (this.inText) {
/* 1480 */       if (isTagged()) {
/* 1481 */         endText();
/*      */       } else {
/* 1483 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("path.construction.operator.inside.text.object", new Object[0]));
/*      */       }
/*      */     }
/* 1486 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/* 1487 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/* 1488 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/* 1489 */     this.content.append("b*").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image)
/*      */     throws DocumentException
/*      */   {
/* 1499 */     addImage(image, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image, boolean inlineImage)
/*      */     throws DocumentException
/*      */   {
/* 1510 */     if (!image.hasAbsoluteY())
/* 1511 */       throw new DocumentException(MessageLocalization.getComposedMessage("the.image.must.have.absolute.positioning", new Object[0]));
/* 1512 */     float[] matrix = image.matrix();
/* 1513 */     matrix[4] = (image.getAbsoluteX() - matrix[4]);
/* 1514 */     matrix[5] = (image.getAbsoluteY() - matrix[5]);
/* 1515 */     addImage(image, matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5], inlineImage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image, float a, float b, float c, float d, float e, float f)
/*      */     throws DocumentException
/*      */   {
/* 1532 */     addImage(image, a, b, c, d, e, f, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image, double a, double b, double c, double d, double e, double f)
/*      */     throws DocumentException
/*      */   {
/* 1549 */     addImage(image, a, b, c, d, e, f, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image, com.itextpdf.awt.geom.AffineTransform transform)
/*      */     throws DocumentException
/*      */   {
/* 1558 */     double[] matrix = new double[6];
/* 1559 */     transform.getMatrix(matrix);
/* 1560 */     addImage(image, matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5], false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image, float a, float b, float c, float d, float e, float f, boolean inlineImage)
/*      */     throws DocumentException
/*      */   {
/* 1579 */     addImage(image, a, b, c, d, e, f, inlineImage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(Image image, double a, double b, double c, double d, double e, double f, boolean inlineImage)
/*      */     throws DocumentException
/*      */   {
/* 1597 */     addImage(image, a, b, c, d, e, f, inlineImage, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addImage(Image image, double a, double b, double c, double d, double e, double f, boolean inlineImage, boolean isMCBlockOpened)
/*      */     throws DocumentException
/*      */   {
/*      */     try
/*      */     {
/* 1618 */       com.itextpdf.awt.geom.AffineTransform transform = new com.itextpdf.awt.geom.AffineTransform(a, b, c, d, e, f);
/*      */       
/* 1620 */       if (image.getLayer() != null)
/* 1621 */         beginLayer(image.getLayer());
/* 1622 */       Point2D[] dst; if (isTagged()) {
/* 1623 */         if (this.inText)
/* 1624 */           endText();
/* 1625 */         Point2D[] src = { new Point2D.Float(0.0F, 0.0F), new Point2D.Float(1.0F, 0.0F), new Point2D.Float(1.0F, 1.0F), new Point2D.Float(0.0F, 1.0F) };
/* 1626 */         dst = new Point2D.Float[4];
/* 1627 */         transform.transform(src, 0, dst, 0, 4);
/* 1628 */         float left = Float.MAX_VALUE;
/* 1629 */         float right = -3.4028235E38F;
/* 1630 */         float bottom = Float.MAX_VALUE;
/* 1631 */         float top = -3.4028235E38F;
/* 1632 */         for (int i = 0; i < 4; i++) {
/* 1633 */           if (dst[i].getX() < left)
/* 1634 */             left = (float)dst[i].getX();
/* 1635 */           if (dst[i].getX() > right)
/* 1636 */             right = (float)dst[i].getX();
/* 1637 */           if (dst[i].getY() < bottom)
/* 1638 */             bottom = (float)dst[i].getY();
/* 1639 */           if (dst[i].getY() > top)
/* 1640 */             top = (float)dst[i].getY();
/*      */         }
/* 1642 */         image.setAccessibleAttribute(PdfName.BBOX, new PdfArray(new float[] { left, bottom, right, top }));
/*      */       }
/* 1644 */       if ((this.writer != null) && (image.isImgTemplate())) {
/* 1645 */         this.writer.addDirectImageSimple(image);
/* 1646 */         PdfTemplate template = image.getTemplateData();
/* 1647 */         if (image.getAccessibleAttributes() != null) {
/* 1648 */           for (PdfName key : image.getAccessibleAttributes().keySet()) {
/* 1649 */             template.setAccessibleAttribute(key, image.getAccessibleAttribute(key));
/*      */           }
/*      */         }
/* 1652 */         float w = template.getWidth();
/* 1653 */         float h = template.getHeight();
/* 1654 */         addTemplate(template, a / w, b / w, c / h, d / h, e, f, false, false);
/*      */       }
/*      */       else {
/* 1657 */         this.content.append("q ");
/*      */         
/* 1659 */         if (!transform.isIdentity()) {
/* 1660 */           this.content.append(a).append(' ');
/* 1661 */           this.content.append(b).append(' ');
/* 1662 */           this.content.append(c).append(' ');
/* 1663 */           this.content.append(d).append(' ');
/* 1664 */           this.content.append(e).append(' ');
/* 1665 */           this.content.append(f).append(" cm");
/*      */         }
/*      */         
/* 1668 */         if (inlineImage) {
/* 1669 */           this.content.append("\nBI\n");
/* 1670 */           PdfImage pimage = new PdfImage(image, "", null);
/* 1671 */           byte[] globals; if ((image instanceof ImgJBIG2)) {
/* 1672 */             globals = ((ImgJBIG2)image).getGlobalBytes();
/* 1673 */             if (globals != null) {
/* 1674 */               PdfDictionary decodeparms = new PdfDictionary();
/* 1675 */               decodeparms.put(PdfName.JBIG2GLOBALS, this.writer.getReferenceJBIG2Globals(globals));
/* 1676 */               pimage.put(PdfName.DECODEPARMS, decodeparms);
/*      */             }
/*      */           }
/* 1679 */           PdfWriter.checkPdfIsoConformance(this.writer, 17, pimage);
/* 1680 */           for (Object element : pimage.getKeys()) {
/* 1681 */             PdfName key = (PdfName)element;
/* 1682 */             PdfObject value = pimage.get(key);
/* 1683 */             String s = (String)abrev.get(key);
/* 1684 */             if (s != null)
/*      */             {
/* 1686 */               this.content.append(s);
/* 1687 */               boolean check = true;
/* 1688 */               if ((key.equals(PdfName.COLORSPACE)) && (value.isArray())) {
/* 1689 */                 PdfArray ar = (PdfArray)value;
/* 1690 */                 if ((ar.size() == 4) && 
/* 1691 */                   (PdfName.INDEXED.equals(ar.getAsName(0))) && 
/* 1692 */                   (ar.getPdfObject(1).isName()) && 
/* 1693 */                   (ar.getPdfObject(2).isNumber()) && 
/* 1694 */                   (ar.getPdfObject(3).isString()))
/*      */                 {
/* 1696 */                   check = false;
/*      */                 }
/*      */               }
/*      */               
/* 1700 */               if ((check) && (key.equals(PdfName.COLORSPACE)) && (!value.isName())) {
/* 1701 */                 PdfName cs = this.writer.getColorspaceName();
/* 1702 */                 PageResources prs = getPageResources();
/* 1703 */                 prs.addColor(cs, this.writer.addToBody(value).getIndirectReference());
/* 1704 */                 value = cs;
/*      */               }
/* 1706 */               value.toPdf(null, this.content);
/* 1707 */               this.content.append('\n');
/*      */             } }
/* 1709 */           ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1710 */           pimage.writeContent(baos);
/* 1711 */           byte[] imageBytes = baos.toByteArray();
/* 1712 */           this.content.append(String.format("/L %s\n", new Object[] { Integer.valueOf(imageBytes.length) }));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1718 */           this.content.append("ID\n");
/* 1719 */           this.content.append(imageBytes);
/* 1720 */           this.content.append("\nEI\nQ").append_i(this.separator);
/*      */         }
/*      */         else
/*      */         {
/* 1724 */           PageResources prs = getPageResources();
/* 1725 */           Image maskImage = image.getImageMask();
/* 1726 */           if (maskImage != null) {
/* 1727 */             PdfName name = this.writer.addDirectImageSimple(maskImage);
/* 1728 */             prs.addXObject(name, this.writer.getImageReference(name));
/*      */           }
/* 1730 */           PdfName name = this.writer.addDirectImageSimple(image);
/* 1731 */           name = prs.addXObject(name, this.writer.getImageReference(name));
/* 1732 */           this.content.append(' ').append(name.getBytes()).append(" Do Q").append_i(this.separator);
/*      */         }
/*      */       }
/* 1735 */       if (image.hasBorders()) {
/* 1736 */         saveState();
/* 1737 */         float w = image.getWidth();
/* 1738 */         float h = image.getHeight();
/* 1739 */         concatCTM(a / w, b / w, c / h, d / h, e, f);
/* 1740 */         rectangle(image);
/* 1741 */         restoreState();
/*      */       }
/* 1743 */       if (image.getLayer() != null)
/* 1744 */         endLayer();
/* 1745 */       Annotation annot = image.getAnnotation();
/* 1746 */       if (annot == null)
/* 1747 */         return;
/* 1748 */       double[] r = new double[unitRect.length];
/* 1749 */       for (int k = 0; k < unitRect.length; k += 2) {
/* 1750 */         r[k] = (a * unitRect[k] + c * unitRect[(k + 1)] + e);
/* 1751 */         r[(k + 1)] = (b * unitRect[k] + d * unitRect[(k + 1)] + f);
/*      */       }
/* 1753 */       double llx = r[0];
/* 1754 */       double lly = r[1];
/* 1755 */       double urx = llx;
/* 1756 */       double ury = lly;
/* 1757 */       for (int k = 2; k < r.length; k += 2) {
/* 1758 */         llx = Math.min(llx, r[k]);
/* 1759 */         lly = Math.min(lly, r[(k + 1)]);
/* 1760 */         urx = Math.max(urx, r[k]);
/* 1761 */         ury = Math.max(ury, r[(k + 1)]);
/*      */       }
/* 1763 */       annot = new Annotation(annot);
/* 1764 */       annot.setDimensions((float)llx, (float)lly, (float)urx, (float)ury);
/* 1765 */       PdfAnnotation an = PdfAnnotationsImp.convertAnnotation(this.writer, annot, new Rectangle((float)llx, (float)lly, (float)urx, (float)ury));
/* 1766 */       if (an == null)
/* 1767 */         return;
/* 1768 */       addAnnotation(an);
/*      */     }
/*      */     catch (IOException ioe)
/*      */     {
/* 1772 */       String path = (image != null) && (image.getUrl() != null) ? image.getUrl().getPath() : MessageLocalization.getComposedMessage("unknown", new Object[0]);
/* 1773 */       throw new DocumentException(MessageLocalization.getComposedMessage("add.image.exception", new Object[] { path }), ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reset()
/*      */   {
/* 1782 */     reset(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reset(boolean validateContent)
/*      */   {
/* 1791 */     this.content.reset();
/* 1792 */     this.markedContentSize = 0;
/* 1793 */     if (validateContent) {
/* 1794 */       sanityCheck();
/*      */     }
/* 1796 */     this.state = new GraphicState();
/* 1797 */     this.stateList = new ArrayList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void beginText(boolean restoreTM)
/*      */   {
/* 1806 */     if (this.inText) {
/* 1807 */       if (!isTagged())
/*      */       {
/*      */ 
/* 1810 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.begin.end.text.operators", new Object[0]));
/*      */       }
/*      */     } else {
/* 1813 */       this.inText = true;
/* 1814 */       this.content.append("BT").append_i(this.separator);
/* 1815 */       if (restoreTM) {
/* 1816 */         float xTLM = this.state.xTLM;
/* 1817 */         float tx = this.state.tx;
/* 1818 */         setTextMatrix(this.state.aTLM, this.state.bTLM, this.state.cTLM, this.state.dTLM, this.state.tx, this.state.yTLM);
/* 1819 */         this.state.xTLM = xTLM;
/* 1820 */         this.state.tx = tx;
/*      */       } else {
/* 1822 */         this.state.xTLM = 0.0F;
/* 1823 */         this.state.yTLM = 0.0F;
/* 1824 */         this.state.tx = 0.0F;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void beginText()
/*      */   {
/* 1833 */     beginText(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void endText()
/*      */   {
/* 1840 */     if (!this.inText) {
/* 1841 */       if (!isTagged())
/*      */       {
/*      */ 
/* 1844 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.begin.end.text.operators", new Object[0]));
/*      */       }
/*      */     } else {
/* 1847 */       this.inText = false;
/* 1848 */       this.content.append("ET").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void saveState()
/*      */   {
/* 1857 */     PdfWriter.checkPdfIsoConformance(this.writer, 12, "q");
/* 1858 */     if ((this.inText) && (isTagged())) {
/* 1859 */       endText();
/*      */     }
/* 1861 */     this.content.append("q").append_i(this.separator);
/* 1862 */     this.stateList.add(new GraphicState(this.state));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void restoreState()
/*      */   {
/* 1870 */     PdfWriter.checkPdfIsoConformance(this.writer, 12, "Q");
/* 1871 */     if ((this.inText) && (isTagged())) {
/* 1872 */       endText();
/*      */     }
/* 1874 */     this.content.append("Q").append_i(this.separator);
/* 1875 */     int idx = this.stateList.size() - 1;
/* 1876 */     if (idx < 0)
/* 1877 */       throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.save.restore.state.operators", new Object[0]));
/* 1878 */     this.state.restore((GraphicState)this.stateList.get(idx));
/* 1879 */     this.stateList.remove(idx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterSpacing(float charSpace)
/*      */   {
/* 1888 */     if ((!this.inText) && (isTagged())) {
/* 1889 */       beginText(true);
/*      */     }
/* 1891 */     this.state.charSpace = charSpace;
/* 1892 */     this.content.append(charSpace).append(" Tc").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWordSpacing(float wordSpace)
/*      */   {
/* 1901 */     if ((!this.inText) && (isTagged())) {
/* 1902 */       beginText(true);
/*      */     }
/* 1904 */     this.state.wordSpace = wordSpace;
/* 1905 */     this.content.append(wordSpace).append(" Tw").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHorizontalScaling(float scale)
/*      */   {
/* 1914 */     if ((!this.inText) && (isTagged())) {
/* 1915 */       beginText(true);
/*      */     }
/* 1917 */     this.state.scale = scale;
/* 1918 */     this.content.append(scale).append(" Tz").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeading(float leading)
/*      */   {
/* 1930 */     if ((!this.inText) && (isTagged())) {
/* 1931 */       beginText(true);
/*      */     }
/* 1933 */     this.state.leading = leading;
/* 1934 */     this.content.append(leading).append(" TL").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFontAndSize(BaseFont bf, float size)
/*      */   {
/* 1944 */     if ((!this.inText) && (isTagged())) {
/* 1945 */       beginText(true);
/*      */     }
/* 1947 */     checkWriter();
/* 1948 */     if ((size < 1.0E-4F) && (size > -1.0E-4F))
/* 1949 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("font.size.too.small.1", new Object[] { String.valueOf(size) }));
/* 1950 */     this.state.size = size;
/* 1951 */     this.state.fontDetails = this.writer.addSimple(bf);
/* 1952 */     PageResources prs = getPageResources();
/* 1953 */     PdfName name = this.state.fontDetails.getFontName();
/* 1954 */     name = prs.addFont(name, this.state.fontDetails.getIndirectReference());
/* 1955 */     this.content.append(name.getBytes()).append(' ').append(size).append(" Tf").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextRenderingMode(int rendering)
/*      */   {
/* 1964 */     if ((!this.inText) && (isTagged())) {
/* 1965 */       beginText(true);
/*      */     }
/* 1967 */     this.state.textRenderMode = rendering;
/* 1968 */     this.content.append(rendering).append(" Tr").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextRise(float rise)
/*      */   {
/* 1979 */     setTextRise(rise);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextRise(double rise)
/*      */   {
/* 1990 */     if ((!this.inText) && (isTagged())) {
/* 1991 */       beginText(true);
/*      */     }
/* 1993 */     this.content.append(rise).append(" Ts").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void showText2(String text)
/*      */   {
/* 2003 */     if (this.state.fontDetails == null)
/* 2004 */       throw new NullPointerException(MessageLocalization.getComposedMessage("font.and.size.must.be.set.before.writing.any.text", new Object[0]));
/* 2005 */     byte[] b = this.state.fontDetails.convertToBytes(text);
/* 2006 */     StringUtils.escapeString(b, this.content);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showText(String text)
/*      */   {
/* 2015 */     checkState();
/* 2016 */     if ((!this.inText) && (isTagged())) {
/* 2017 */       beginText(true);
/*      */     }
/* 2019 */     showText2(text);
/* 2020 */     updateTx(text, 0.0F);
/* 2021 */     this.content.append("Tj").append_i(this.separator);
/*      */   }
/*      */   
/*      */   public void showTextGid(String gids) {
/* 2025 */     checkState();
/* 2026 */     if ((!this.inText) && (isTagged())) {
/* 2027 */       beginText(true);
/*      */     }
/* 2029 */     if (this.state.fontDetails == null)
/* 2030 */       throw new NullPointerException(MessageLocalization.getComposedMessage("font.and.size.must.be.set.before.writing.any.text", new Object[0]));
/* 2031 */     Object[] objs = this.state.fontDetails.convertToBytesGid(gids);
/* 2032 */     StringUtils.escapeString((byte[])objs[0], this.content);
/* 2033 */     this.state.tx += ((Integer)objs[2]).intValue() * 0.001F * this.state.size;
/* 2034 */     this.content.append("Tj").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfTextArray getKernArray(String text, BaseFont font)
/*      */   {
/* 2044 */     PdfTextArray pa = new PdfTextArray();
/* 2045 */     StringBuffer acc = new StringBuffer();
/* 2046 */     int len = text.length() - 1;
/* 2047 */     char[] c = text.toCharArray();
/* 2048 */     if (len >= 0)
/* 2049 */       acc.append(c, 0, 1);
/* 2050 */     for (int k = 0; k < len; k++) {
/* 2051 */       char c2 = c[(k + 1)];
/* 2052 */       int kern = font.getKerning(c[k], c2);
/* 2053 */       if (kern == 0) {
/* 2054 */         acc.append(c2);
/*      */       }
/*      */       else {
/* 2057 */         pa.add(acc.toString());
/* 2058 */         acc.setLength(0);
/* 2059 */         acc.append(c, k + 1, 1);
/* 2060 */         pa.add(-kern);
/*      */       }
/*      */     }
/* 2063 */     pa.add(acc.toString());
/* 2064 */     return pa;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showTextKerned(String text)
/*      */   {
/* 2073 */     if (this.state.fontDetails == null)
/* 2074 */       throw new NullPointerException(MessageLocalization.getComposedMessage("font.and.size.must.be.set.before.writing.any.text", new Object[0]));
/* 2075 */     BaseFont bf = this.state.fontDetails.getBaseFont();
/* 2076 */     if (bf.hasKernPairs()) {
/* 2077 */       showText(getKernArray(text, bf));
/*      */     } else {
/* 2079 */       showText(text);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void newlineShowText(String text)
/*      */   {
/* 2089 */     checkState();
/* 2090 */     if ((!this.inText) && (isTagged())) {
/* 2091 */       beginText(true);
/*      */     }
/* 2093 */     this.state.yTLM -= this.state.leading;
/* 2094 */     showText2(text);
/* 2095 */     this.content.append("'").append_i(this.separator);
/* 2096 */     this.state.tx = this.state.xTLM;
/* 2097 */     updateTx(text, 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void newlineShowText(float wordSpacing, float charSpacing, String text)
/*      */   {
/* 2108 */     checkState();
/* 2109 */     if ((!this.inText) && (isTagged())) {
/* 2110 */       beginText(true);
/*      */     }
/* 2112 */     this.state.yTLM -= this.state.leading;
/* 2113 */     this.content.append(wordSpacing).append(' ').append(charSpacing);
/* 2114 */     showText2(text);
/* 2115 */     this.content.append("\"").append_i(this.separator);
/*      */     
/*      */ 
/* 2118 */     this.state.charSpace = charSpacing;
/* 2119 */     this.state.wordSpace = wordSpacing;
/* 2120 */     this.state.tx = this.state.xTLM;
/* 2121 */     updateTx(text, 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextMatrix(float a, float b, float c, float d, float x, float y)
/*      */   {
/* 2137 */     if ((!this.inText) && (isTagged())) {
/* 2138 */       beginText(true);
/*      */     }
/* 2140 */     this.state.xTLM = x;
/* 2141 */     this.state.yTLM = y;
/* 2142 */     this.state.aTLM = a;
/* 2143 */     this.state.bTLM = b;
/* 2144 */     this.state.cTLM = c;
/* 2145 */     this.state.dTLM = d;
/* 2146 */     this.state.tx = this.state.xTLM;
/* 2147 */     this.content.append(a).append(' ').append(b).append_i(32)
/* 2148 */       .append(c).append_i(32).append(d).append_i(32)
/* 2149 */       .append(x).append_i(32).append(y).append(" Tm").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextMatrix(com.itextpdf.awt.geom.AffineTransform transform)
/*      */   {
/* 2158 */     double[] matrix = new double[6];
/* 2159 */     transform.getMatrix(matrix);
/* 2160 */     setTextMatrix((float)matrix[0], (float)matrix[1], (float)matrix[2], (float)matrix[3], (float)matrix[4], (float)matrix[5]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextMatrix(float x, float y)
/*      */   {
/* 2173 */     setTextMatrix(1.0F, 0.0F, 0.0F, 1.0F, x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveText(float x, float y)
/*      */   {
/* 2183 */     if ((!this.inText) && (isTagged())) {
/* 2184 */       beginText(true);
/*      */     }
/* 2186 */     this.state.xTLM += x;
/* 2187 */     this.state.yTLM += y;
/* 2188 */     if ((isTagged()) && (this.state.xTLM != this.state.tx)) {
/* 2189 */       setTextMatrix(this.state.aTLM, this.state.bTLM, this.state.cTLM, this.state.dTLM, this.state.xTLM, this.state.yTLM);
/*      */     } else {
/* 2191 */       this.content.append(x).append(' ').append(y).append(" Td").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveTextWithLeading(float x, float y)
/*      */   {
/* 2204 */     if ((!this.inText) && (isTagged())) {
/* 2205 */       beginText(true);
/*      */     }
/* 2207 */     this.state.xTLM += x;
/* 2208 */     this.state.yTLM += y;
/* 2209 */     this.state.leading = (-y);
/* 2210 */     if ((isTagged()) && (this.state.xTLM != this.state.tx)) {
/* 2211 */       setTextMatrix(this.state.aTLM, this.state.bTLM, this.state.cTLM, this.state.dTLM, this.state.xTLM, this.state.yTLM);
/*      */     } else {
/* 2213 */       this.content.append(x).append(' ').append(y).append(" TD").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void newlineText()
/*      */   {
/* 2221 */     if ((!this.inText) && (isTagged())) {
/* 2222 */       beginText(true);
/*      */     }
/* 2224 */     if ((isTagged()) && (this.state.xTLM != this.state.tx)) {
/* 2225 */       setTextMatrix(this.state.aTLM, this.state.bTLM, this.state.cTLM, this.state.dTLM, this.state.xTLM, this.state.yTLM);
/*      */     }
/* 2227 */     this.state.yTLM -= this.state.leading;
/* 2228 */     this.content.append("T*").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int size()
/*      */   {
/* 2237 */     return size(true);
/*      */   }
/*      */   
/*      */   int size(boolean includeMarkedContentSize) {
/* 2241 */     if (includeMarkedContentSize) {
/* 2242 */       return this.content.size();
/*      */     }
/* 2244 */     return this.content.size() - this.markedContentSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addOutline(PdfOutline outline, String name)
/*      */   {
/* 2254 */     checkWriter();
/* 2255 */     this.pdf.addOutline(outline, name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfOutline getRootOutline()
/*      */   {
/* 2263 */     checkWriter();
/* 2264 */     return this.pdf.getRootOutline();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getEffectiveStringWidth(String text, boolean kerned)
/*      */   {
/* 2278 */     BaseFont bf = this.state.fontDetails.getBaseFont();
/*      */     float w;
/*      */     float w;
/* 2281 */     if (kerned) {
/* 2282 */       w = bf.getWidthPointKerned(text, this.state.size);
/*      */     } else {
/* 2284 */       w = bf.getWidthPoint(text, this.state.size);
/*      */     }
/* 2286 */     if ((this.state.charSpace != 0.0F) && (text.length() > 1)) {
/* 2287 */       w += this.state.charSpace * (text.length() - 1);
/*      */     }
/*      */     
/* 2290 */     if ((this.state.wordSpace != 0.0F) && (!bf.isVertical())) {
/* 2291 */       for (int i = 0; i < text.length() - 1; i++) {
/* 2292 */         if (text.charAt(i) == ' ')
/* 2293 */           w += this.state.wordSpace;
/*      */       }
/*      */     }
/* 2296 */     if (this.state.scale != 100.0D) {
/* 2297 */       w = w * this.state.scale / 100.0F;
/*      */     }
/*      */     
/* 2300 */     return w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private float getEffectiveStringWidth(String text, boolean kerned, float kerning)
/*      */   {
/* 2315 */     BaseFont bf = this.state.fontDetails.getBaseFont();
/*      */     float w;
/* 2317 */     float w; if (kerned) {
/* 2318 */       w = bf.getWidthPointKerned(text, this.state.size);
/*      */     } else
/* 2320 */       w = bf.getWidthPoint(text, this.state.size);
/* 2321 */     if ((this.state.charSpace != 0.0F) && (text.length() > 0)) {
/* 2322 */       w += this.state.charSpace * text.length();
/*      */     }
/* 2324 */     if ((this.state.wordSpace != 0.0F) && (!bf.isVertical())) {
/* 2325 */       for (int i = 0; i < text.length(); i++) {
/* 2326 */         if (text.charAt(i) == ' ')
/* 2327 */           w += this.state.wordSpace;
/*      */       }
/*      */     }
/* 2330 */     w -= kerning / 1000.0F * this.state.size;
/* 2331 */     if (this.state.scale != 100.0D)
/* 2332 */       w = w * this.state.scale / 100.0F;
/* 2333 */     return w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showTextAligned(int alignment, String text, float x, float y, float rotation)
/*      */   {
/* 2345 */     showTextAligned(alignment, text, x, y, rotation, false);
/*      */   }
/*      */   
/*      */   private void showTextAligned(int alignment, String text, float x, float y, float rotation, boolean kerned) {
/* 2349 */     if (this.state.fontDetails == null)
/* 2350 */       throw new NullPointerException(MessageLocalization.getComposedMessage("font.and.size.must.be.set.before.writing.any.text", new Object[0]));
/* 2351 */     if (rotation == 0.0F) {
/* 2352 */       switch (alignment) {
/*      */       case 1: 
/* 2354 */         x -= getEffectiveStringWidth(text, kerned) / 2.0F;
/* 2355 */         break;
/*      */       case 2: 
/* 2357 */         x -= getEffectiveStringWidth(text, kerned);
/*      */       }
/*      */       
/* 2360 */       setTextMatrix(x, y);
/* 2361 */       if (kerned) {
/* 2362 */         showTextKerned(text);
/*      */       } else {
/* 2364 */         showText(text);
/*      */       }
/*      */     } else {
/* 2367 */       double alpha = rotation * 3.141592653589793D / 180.0D;
/* 2368 */       float cos = (float)Math.cos(alpha);
/* 2369 */       float sin = (float)Math.sin(alpha);
/*      */       
/* 2371 */       switch (alignment) {
/*      */       case 1: 
/* 2373 */         float len = getEffectiveStringWidth(text, kerned) / 2.0F;
/* 2374 */         x -= len * cos;
/* 2375 */         y -= len * sin;
/* 2376 */         break;
/*      */       case 2: 
/* 2378 */         float len = getEffectiveStringWidth(text, kerned);
/* 2379 */         x -= len * cos;
/* 2380 */         y -= len * sin;
/*      */       }
/*      */       
/* 2383 */       setTextMatrix(cos, sin, -sin, cos, x, y);
/* 2384 */       if (kerned) {
/* 2385 */         showTextKerned(text);
/*      */       } else
/* 2387 */         showText(text);
/* 2388 */       setTextMatrix(0.0F, 0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showTextAlignedKerned(int alignment, String text, float x, float y, float rotation)
/*      */   {
/* 2401 */     showTextAligned(alignment, text, x, y, rotation, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void concatCTM(float a, float b, float c, float d, float e, float f)
/*      */   {
/* 2429 */     concatCTM(a, b, c, d, e, f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void concatCTM(double a, double b, double c, double d, double e, double f)
/*      */   {
/* 2457 */     if ((this.inText) && (isTagged())) {
/* 2458 */       endText();
/*      */     }
/* 2460 */     this.state.CTM.concatenate(new com.itextpdf.awt.geom.AffineTransform(a, b, c, d, e, f));
/* 2461 */     this.content.append(a).append(' ').append(b).append(' ').append(c).append(' ');
/* 2462 */     this.content.append(d).append(' ').append(e).append(' ').append(f).append(" cm").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void concatCTM(com.itextpdf.awt.geom.AffineTransform transform)
/*      */   {
/* 2470 */     double[] matrix = new double[6];
/* 2471 */     transform.getMatrix(matrix);
/* 2472 */     concatCTM(matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<double[]> bezierArc(float x1, float y1, float x2, float y2, float startAng, float extent)
/*      */   {
/* 2501 */     return bezierArc(x1, y1, x2, y2, startAng, extent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<double[]> bezierArc(double x1, double y1, double x2, double y2, double startAng, double extent)
/*      */   {
/* 2530 */     if (x1 > x2) {
/* 2531 */       double tmp = x1;
/* 2532 */       x1 = x2;
/* 2533 */       x2 = tmp;
/*      */     }
/* 2535 */     if (y2 > y1) {
/* 2536 */       double tmp = y1;
/* 2537 */       y1 = y2;
/* 2538 */       y2 = tmp;
/*      */     }
/*      */     int Nfrag;
/*      */     int Nfrag;
/*      */     double fragAngle;
/* 2543 */     if (Math.abs(extent) <= 90.0D) {
/* 2544 */       double fragAngle = extent;
/* 2545 */       Nfrag = 1;
/*      */     }
/*      */     else {
/* 2548 */       Nfrag = (int)Math.ceil(Math.abs(extent) / 90.0D);
/* 2549 */       fragAngle = extent / Nfrag;
/*      */     }
/* 2551 */     double x_cen = (x1 + x2) / 2.0D;
/* 2552 */     double y_cen = (y1 + y2) / 2.0D;
/* 2553 */     double rx = (x2 - x1) / 2.0D;
/* 2554 */     double ry = (y2 - y1) / 2.0D;
/* 2555 */     double halfAng = fragAngle * 3.141592653589793D / 360.0D;
/* 2556 */     double kappa = Math.abs(1.3333333333333333D * (1.0D - Math.cos(halfAng)) / Math.sin(halfAng));
/* 2557 */     ArrayList<double[]> pointList = new ArrayList();
/* 2558 */     for (int i = 0; i < Nfrag; i++) {
/* 2559 */       double theta0 = (startAng + i * fragAngle) * 3.141592653589793D / 180.0D;
/* 2560 */       double theta1 = (startAng + (i + 1) * fragAngle) * 3.141592653589793D / 180.0D;
/* 2561 */       double cos0 = Math.cos(theta0);
/* 2562 */       double cos1 = Math.cos(theta1);
/* 2563 */       double sin0 = Math.sin(theta0);
/* 2564 */       double sin1 = Math.sin(theta1);
/* 2565 */       if (fragAngle > 0.0D) {
/* 2566 */         pointList.add(new double[] { x_cen + rx * cos0, y_cen - ry * sin0, x_cen + rx * (cos0 - kappa * sin0), y_cen - ry * (sin0 + kappa * cos0), x_cen + rx * (cos1 + kappa * sin1), y_cen - ry * (sin1 - kappa * cos1), x_cen + rx * cos1, y_cen - ry * sin1 });
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2576 */         pointList.add(new double[] { x_cen + rx * cos0, y_cen - ry * sin0, x_cen + rx * (cos0 + kappa * sin0), y_cen - ry * (sin0 - kappa * cos0), x_cen + rx * (cos1 - kappa * sin1), y_cen - ry * (sin1 + kappa * cos1), x_cen + rx * cos1, y_cen - ry * sin1 });
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2586 */     return pointList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void arc(float x1, float y1, float x2, float y2, float startAng, float extent)
/*      */   {
/* 2602 */     arc(x1, y1, x2, y2, startAng, extent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void arc(double x1, double y1, double x2, double y2, double startAng, double extent)
/*      */   {
/* 2618 */     ArrayList<double[]> ar = bezierArc(x1, y1, x2, y2, startAng, extent);
/* 2619 */     if (ar.isEmpty())
/* 2620 */       return;
/* 2621 */     double[] pt = (double[])ar.get(0);
/* 2622 */     moveTo(pt[0], pt[1]);
/* 2623 */     for (int k = 0; k < ar.size(); k++) {
/* 2624 */       pt = (double[])ar.get(k);
/* 2625 */       curveTo(pt[2], pt[3], pt[4], pt[5], pt[6], pt[7]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ellipse(float x1, float y1, float x2, float y2)
/*      */   {
/* 2638 */     ellipse(x1, y1, x2, y2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ellipse(double x1, double y1, double x2, double y2)
/*      */   {
/* 2650 */     arc(x1, y1, x2, y2, 0.0D, 360.0D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPatternPainter createPattern(float width, float height, float xstep, float ystep)
/*      */   {
/* 2665 */     checkWriter();
/* 2666 */     if ((xstep == 0.0F) || (ystep == 0.0F))
/* 2667 */       throw new RuntimeException(MessageLocalization.getComposedMessage("xstep.or.ystep.can.not.be.zero", new Object[0]));
/* 2668 */     PdfPatternPainter painter = new PdfPatternPainter(this.writer);
/* 2669 */     painter.setWidth(width);
/* 2670 */     painter.setHeight(height);
/* 2671 */     painter.setXStep(xstep);
/* 2672 */     painter.setYStep(ystep);
/* 2673 */     this.writer.addSimplePattern(painter);
/* 2674 */     return painter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPatternPainter createPattern(float width, float height)
/*      */   {
/* 2685 */     return createPattern(width, height, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPatternPainter createPattern(float width, float height, float xstep, float ystep, BaseColor color)
/*      */   {
/* 2701 */     checkWriter();
/* 2702 */     if ((xstep == 0.0F) || (ystep == 0.0F))
/* 2703 */       throw new RuntimeException(MessageLocalization.getComposedMessage("xstep.or.ystep.can.not.be.zero", new Object[0]));
/* 2704 */     PdfPatternPainter painter = new PdfPatternPainter(this.writer, color);
/* 2705 */     painter.setWidth(width);
/* 2706 */     painter.setHeight(height);
/* 2707 */     painter.setXStep(xstep);
/* 2708 */     painter.setYStep(ystep);
/* 2709 */     this.writer.addSimplePattern(painter);
/* 2710 */     return painter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPatternPainter createPattern(float width, float height, BaseColor color)
/*      */   {
/* 2723 */     return createPattern(width, height, width, height, color);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfTemplate createTemplate(float width, float height)
/*      */   {
/* 2739 */     return createTemplate(width, height, null);
/*      */   }
/*      */   
/*      */   PdfTemplate createTemplate(float width, float height, PdfName forcedName) {
/* 2743 */     checkWriter();
/* 2744 */     PdfTemplate template = new PdfTemplate(this.writer);
/* 2745 */     template.setWidth(width);
/* 2746 */     template.setHeight(height);
/* 2747 */     this.writer.addDirectTemplateSimple(template, forcedName);
/* 2748 */     return template;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfAppearance createAppearance(float width, float height)
/*      */   {
/* 2759 */     return createAppearance(width, height, null);
/*      */   }
/*      */   
/*      */   PdfAppearance createAppearance(float width, float height, PdfName forcedName) {
/* 2763 */     checkWriter();
/* 2764 */     PdfAppearance template = new PdfAppearance(this.writer);
/* 2765 */     template.setWidth(width);
/* 2766 */     template.setHeight(height);
/* 2767 */     this.writer.addDirectTemplateSimple(template, forcedName);
/* 2768 */     return template;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPSXObject(PdfPSXObject psobject)
/*      */   {
/* 2777 */     if ((this.inText) && (isTagged())) {
/* 2778 */       endText();
/*      */     }
/* 2780 */     checkWriter();
/* 2781 */     PdfName name = this.writer.addDirectTemplateSimple(psobject, null);
/* 2782 */     PageResources prs = getPageResources();
/* 2783 */     name = prs.addXObject(name, psobject.getIndirectReference());
/* 2784 */     this.content.append(name.getBytes()).append(" Do").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, float a, float b, float c, float d, float e, float f)
/*      */   {
/* 2799 */     addTemplate(template, a, b, c, d, e, f, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, double a, double b, double c, double d, double e, double f)
/*      */   {
/* 2814 */     addTemplate(template, a, b, c, d, e, f, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, float a, float b, float c, float d, float e, float f, boolean tagContent)
/*      */   {
/* 2831 */     addTemplate(template, a, b, c, d, e, f, tagContent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, double a, double b, double c, double d, double e, double f, boolean tagContent)
/*      */   {
/* 2848 */     addTemplate(template, a, b, c, d, e, f, true, tagContent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addTemplate(PdfTemplate template, double a, double b, double c, double d, double e, double f, boolean tagTemplate, boolean tagContent)
/*      */   {
/* 2866 */     checkWriter();
/* 2867 */     checkNoPattern(template);
/* 2868 */     PdfWriter.checkPdfIsoConformance(this.writer, 20, template);
/* 2869 */     PdfName name = this.writer.addDirectTemplateSimple(template, null);
/* 2870 */     PageResources prs = getPageResources();
/* 2871 */     name = prs.addXObject(name, template.getIndirectReference());
/* 2872 */     if ((isTagged()) && (tagTemplate)) {
/* 2873 */       if (this.inText)
/* 2874 */         endText();
/* 2875 */       if ((template.isContentTagged()) || ((template.getPageReference() != null) && (tagContent))) {
/* 2876 */         throw new RuntimeException(MessageLocalization.getComposedMessage("template.with.tagged.could.not.be.used.more.than.once", new Object[0]));
/*      */       }
/*      */       
/* 2879 */       template.setPageReference(this.writer.getCurrentPage());
/*      */       
/* 2881 */       if (tagContent) {
/* 2882 */         template.setContentTagged(true);
/* 2883 */         ensureDocumentTagIsOpen();
/* 2884 */         ArrayList<IAccessibleElement> allMcElements = getMcElements();
/* 2885 */         if ((allMcElements != null) && (allMcElements.size() > 0))
/* 2886 */           template.getMcElements().add(allMcElements.get(allMcElements.size() - 1));
/*      */       } else {
/* 2888 */         openMCBlock(template);
/*      */       }
/*      */     }
/*      */     
/* 2892 */     this.content.append("q ");
/* 2893 */     this.content.append(a).append(' ');
/* 2894 */     this.content.append(b).append(' ');
/* 2895 */     this.content.append(c).append(' ');
/* 2896 */     this.content.append(d).append(' ');
/* 2897 */     this.content.append(e).append(' ');
/* 2898 */     this.content.append(f).append(" cm ");
/* 2899 */     this.content.append(name.getBytes()).append(" Do Q").append_i(this.separator);
/*      */     
/* 2901 */     if ((isTagged()) && (tagTemplate) && (!tagContent)) {
/* 2902 */       closeMCBlock(template);
/* 2903 */       template.setId(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName addFormXObj(PdfStream formXObj, PdfName name, float a, float b, float c, float d, float e, float f)
/*      */     throws IOException
/*      */   {
/* 2922 */     return addFormXObj(formXObj, name, a, b, c, d, e, f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfName addFormXObj(PdfStream formXObj, PdfName name, double a, double b, double c, double d, double e, double f)
/*      */     throws IOException
/*      */   {
/* 2940 */     checkWriter();
/* 2941 */     PdfWriter.checkPdfIsoConformance(this.writer, 9, formXObj);
/* 2942 */     PageResources prs = getPageResources();
/* 2943 */     PdfName translatedName = prs.addXObject(name, this.writer.addToBody(formXObj).getIndirectReference());
/* 2944 */     PdfArtifact artifact = null;
/* 2945 */     if (isTagged()) {
/* 2946 */       if (this.inText)
/* 2947 */         endText();
/* 2948 */       artifact = new PdfArtifact();
/* 2949 */       openMCBlock(artifact);
/*      */     }
/*      */     
/* 2952 */     this.content.append("q ");
/* 2953 */     this.content.append(a).append(' ');
/* 2954 */     this.content.append(b).append(' ');
/* 2955 */     this.content.append(c).append(' ');
/* 2956 */     this.content.append(d).append(' ');
/* 2957 */     this.content.append(e).append(' ');
/* 2958 */     this.content.append(f).append(" cm ");
/* 2959 */     this.content.append(translatedName.getBytes()).append(" Do Q").append_i(this.separator);
/*      */     
/* 2961 */     if (isTagged()) {
/* 2962 */       closeMCBlock(artifact);
/*      */     }
/*      */     
/* 2965 */     return translatedName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, com.itextpdf.awt.geom.AffineTransform transform)
/*      */   {
/* 2974 */     addTemplate(template, transform, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, com.itextpdf.awt.geom.AffineTransform transform, boolean tagContent)
/*      */   {
/* 2985 */     double[] matrix = new double[6];
/* 2986 */     transform.getMatrix(matrix);
/* 2987 */     addTemplate(template, matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5], tagContent);
/*      */   }
/*      */   
/*      */   void addTemplateReference(PdfIndirectReference template, PdfName name, float a, float b, float c, float d, float e, float f)
/*      */   {
/* 2992 */     addTemplateReference(template, name, a, b, c, d, e, f);
/*      */   }
/*      */   
/*      */   void addTemplateReference(PdfIndirectReference template, PdfName name, double a, double b, double c, double d, double e, double f) {
/* 2996 */     if ((this.inText) && (isTagged())) {
/* 2997 */       endText();
/*      */     }
/* 2999 */     checkWriter();
/* 3000 */     PageResources prs = getPageResources();
/* 3001 */     name = prs.addXObject(name, template);
/* 3002 */     this.content.append("q ");
/* 3003 */     this.content.append(a).append(' ');
/* 3004 */     this.content.append(b).append(' ');
/* 3005 */     this.content.append(c).append(' ');
/* 3006 */     this.content.append(d).append(' ');
/* 3007 */     this.content.append(e).append(' ');
/* 3008 */     this.content.append(f).append(" cm ");
/* 3009 */     this.content.append(name.getBytes()).append(" Do Q").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, float x, float y)
/*      */   {
/* 3020 */     addTemplate(template, 1.0F, 0.0F, 0.0F, 1.0F, x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplate(PdfTemplate template, double x, double y)
/*      */   {
/* 3031 */     addTemplate(template, 1.0D, 0.0D, 0.0D, 1.0D, x, y);
/*      */   }
/*      */   
/*      */   public void addTemplate(PdfTemplate template, float x, float y, boolean tagContent) {
/* 3035 */     addTemplate(template, 1.0F, 0.0F, 0.0F, 1.0F, x, y, tagContent);
/*      */   }
/*      */   
/*      */   public void addTemplate(PdfTemplate template, double x, double y, boolean tagContent) {
/* 3039 */     addTemplate(template, 1.0D, 0.0D, 0.0D, 1.0D, x, y, tagContent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCMYKColorFill(int cyan, int magenta, int yellow, int black)
/*      */   {
/* 3061 */     saveColor(new CMYKColor(cyan, magenta, yellow, black), true);
/* 3062 */     this.content.append((cyan & 0xFF) / 255.0F);
/* 3063 */     this.content.append(' ');
/* 3064 */     this.content.append((magenta & 0xFF) / 255.0F);
/* 3065 */     this.content.append(' ');
/* 3066 */     this.content.append((yellow & 0xFF) / 255.0F);
/* 3067 */     this.content.append(' ');
/* 3068 */     this.content.append((black & 0xFF) / 255.0F);
/* 3069 */     this.content.append(" k").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCMYKColorStroke(int cyan, int magenta, int yellow, int black)
/*      */   {
/* 3089 */     saveColor(new CMYKColor(cyan, magenta, yellow, black), false);
/* 3090 */     this.content.append((cyan & 0xFF) / 255.0F);
/* 3091 */     this.content.append(' ');
/* 3092 */     this.content.append((magenta & 0xFF) / 255.0F);
/* 3093 */     this.content.append(' ');
/* 3094 */     this.content.append((yellow & 0xFF) / 255.0F);
/* 3095 */     this.content.append(' ');
/* 3096 */     this.content.append((black & 0xFF) / 255.0F);
/* 3097 */     this.content.append(" K").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRGBColorFill(int red, int green, int blue)
/*      */   {
/* 3118 */     saveColor(new BaseColor(red, green, blue), true);
/* 3119 */     HelperRGB((red & 0xFF) / 255.0F, (green & 0xFF) / 255.0F, (blue & 0xFF) / 255.0F);
/* 3120 */     this.content.append(" rg").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRGBColorStroke(int red, int green, int blue)
/*      */   {
/* 3140 */     saveColor(new BaseColor(red, green, blue), false);
/* 3141 */     HelperRGB((red & 0xFF) / 255.0F, (green & 0xFF) / 255.0F, (blue & 0xFF) / 255.0F);
/* 3142 */     this.content.append(" RG").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColorStroke(BaseColor color)
/*      */   {
/* 3150 */     int type = ExtendedColor.getType(color);
/* 3151 */     switch (type) {
/*      */     case 1: 
/* 3153 */       setGrayStroke(((GrayColor)color).getGray());
/* 3154 */       break;
/*      */     
/*      */     case 2: 
/* 3157 */       CMYKColor cmyk = (CMYKColor)color;
/* 3158 */       setCMYKColorStrokeF(cmyk.getCyan(), cmyk.getMagenta(), cmyk.getYellow(), cmyk.getBlack());
/* 3159 */       break;
/*      */     
/*      */     case 3: 
/* 3162 */       SpotColor spot = (SpotColor)color;
/* 3163 */       setColorStroke(spot.getPdfSpotColor(), spot.getTint());
/* 3164 */       break;
/*      */     
/*      */     case 4: 
/* 3167 */       PatternColor pat = (PatternColor)color;
/* 3168 */       setPatternStroke(pat.getPainter());
/* 3169 */       break;
/*      */     
/*      */     case 5: 
/* 3172 */       ShadingColor shading = (ShadingColor)color;
/* 3173 */       setShadingStroke(shading.getPdfShadingPattern());
/* 3174 */       break;
/*      */     
/*      */     case 6: 
/* 3177 */       DeviceNColor devicen = (DeviceNColor)color;
/* 3178 */       setColorStroke(devicen.getPdfDeviceNColor(), devicen.getTints());
/* 3179 */       break;
/*      */     
/*      */     case 7: 
/* 3182 */       LabColor lab = (LabColor)color;
/* 3183 */       setColorStroke(lab.getLabColorSpace(), lab.getL(), lab.getA(), lab.getB());
/* 3184 */       break;
/*      */     
/*      */     default: 
/* 3187 */       setRGBColorStroke(color.getRed(), color.getGreen(), color.getBlue());
/*      */     }
/*      */     
/* 3190 */     int alpha = color.getAlpha();
/* 3191 */     if (alpha < 255) {
/* 3192 */       PdfGState gState = new PdfGState();
/* 3193 */       gState.setStrokeOpacity(alpha / 255.0F);
/* 3194 */       setGState(gState);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColorFill(BaseColor color)
/*      */   {
/* 3203 */     int type = ExtendedColor.getType(color);
/* 3204 */     switch (type) {
/*      */     case 1: 
/* 3206 */       setGrayFill(((GrayColor)color).getGray());
/* 3207 */       break;
/*      */     
/*      */     case 2: 
/* 3210 */       CMYKColor cmyk = (CMYKColor)color;
/* 3211 */       setCMYKColorFillF(cmyk.getCyan(), cmyk.getMagenta(), cmyk.getYellow(), cmyk.getBlack());
/* 3212 */       break;
/*      */     
/*      */     case 3: 
/* 3215 */       SpotColor spot = (SpotColor)color;
/* 3216 */       setColorFill(spot.getPdfSpotColor(), spot.getTint());
/* 3217 */       break;
/*      */     
/*      */     case 4: 
/* 3220 */       PatternColor pat = (PatternColor)color;
/* 3221 */       setPatternFill(pat.getPainter());
/* 3222 */       break;
/*      */     
/*      */     case 5: 
/* 3225 */       ShadingColor shading = (ShadingColor)color;
/* 3226 */       setShadingFill(shading.getPdfShadingPattern());
/* 3227 */       break;
/*      */     
/*      */     case 6: 
/* 3230 */       DeviceNColor devicen = (DeviceNColor)color;
/* 3231 */       setColorFill(devicen.getPdfDeviceNColor(), devicen.getTints());
/* 3232 */       break;
/*      */     
/*      */     case 7: 
/* 3235 */       LabColor lab = (LabColor)color;
/* 3236 */       setColorFill(lab.getLabColorSpace(), lab.getL(), lab.getA(), lab.getB());
/* 3237 */       break;
/*      */     
/*      */     default: 
/* 3240 */       setRGBColorFill(color.getRed(), color.getGreen(), color.getBlue());
/*      */     }
/*      */     
/* 3243 */     int alpha = color.getAlpha();
/* 3244 */     if (alpha < 255) {
/* 3245 */       PdfGState gState = new PdfGState();
/* 3246 */       gState.setFillOpacity(alpha / 255.0F);
/* 3247 */       setGState(gState);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColorFill(PdfSpotColor sp, float tint)
/*      */   {
/* 3257 */     checkWriter();
/* 3258 */     this.state.colorDetails = this.writer.addSimple(sp);
/* 3259 */     PageResources prs = getPageResources();
/* 3260 */     PdfName name = this.state.colorDetails.getColorSpaceName();
/* 3261 */     name = prs.addColor(name, this.state.colorDetails.getIndirectReference());
/* 3262 */     saveColor(new SpotColor(sp, tint), true);
/* 3263 */     this.content.append(name.getBytes()).append(" cs ").append(tint).append(" scn").append_i(this.separator);
/*      */   }
/*      */   
/*      */   public void setColorFill(PdfDeviceNColor dn, float[] tints) {
/* 3267 */     checkWriter();
/* 3268 */     this.state.colorDetails = this.writer.addSimple(dn);
/* 3269 */     PageResources prs = getPageResources();
/* 3270 */     PdfName name = this.state.colorDetails.getColorSpaceName();
/* 3271 */     name = prs.addColor(name, this.state.colorDetails.getIndirectReference());
/* 3272 */     saveColor(new DeviceNColor(dn, tints), true);
/* 3273 */     this.content.append(name.getBytes()).append(" cs ");
/* 3274 */     for (float tint : tints)
/* 3275 */       this.content.append(tint + " ");
/* 3276 */     this.content.append("scn").append_i(this.separator);
/*      */   }
/*      */   
/*      */   public void setColorFill(PdfLabColor lab, float l, float a, float b) {
/* 3280 */     checkWriter();
/* 3281 */     this.state.colorDetails = this.writer.addSimple(lab);
/* 3282 */     PageResources prs = getPageResources();
/* 3283 */     PdfName name = this.state.colorDetails.getColorSpaceName();
/* 3284 */     name = prs.addColor(name, this.state.colorDetails.getIndirectReference());
/* 3285 */     saveColor(new LabColor(lab, l, a, b), true);
/* 3286 */     this.content.append(name.getBytes()).append(" cs ");
/* 3287 */     this.content.append(l + " " + a + " " + b + " ");
/* 3288 */     this.content.append("scn").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColorStroke(PdfSpotColor sp, float tint)
/*      */   {
/* 3297 */     checkWriter();
/* 3298 */     this.state.colorDetails = this.writer.addSimple(sp);
/* 3299 */     PageResources prs = getPageResources();
/* 3300 */     PdfName name = this.state.colorDetails.getColorSpaceName();
/* 3301 */     name = prs.addColor(name, this.state.colorDetails.getIndirectReference());
/* 3302 */     saveColor(new SpotColor(sp, tint), false);
/* 3303 */     this.content.append(name.getBytes()).append(" CS ").append(tint).append(" SCN").append_i(this.separator);
/*      */   }
/*      */   
/*      */   public void setColorStroke(PdfDeviceNColor sp, float[] tints) {
/* 3307 */     checkWriter();
/* 3308 */     this.state.colorDetails = this.writer.addSimple(sp);
/* 3309 */     PageResources prs = getPageResources();
/* 3310 */     PdfName name = this.state.colorDetails.getColorSpaceName();
/* 3311 */     name = prs.addColor(name, this.state.colorDetails.getIndirectReference());
/* 3312 */     saveColor(new DeviceNColor(sp, tints), true);
/* 3313 */     this.content.append(name.getBytes()).append(" CS ");
/* 3314 */     for (float tint : tints)
/* 3315 */       this.content.append(tint + " ");
/* 3316 */     this.content.append("SCN").append_i(this.separator);
/*      */   }
/*      */   
/*      */   public void setColorStroke(PdfLabColor lab, float l, float a, float b) {
/* 3320 */     checkWriter();
/* 3321 */     this.state.colorDetails = this.writer.addSimple(lab);
/* 3322 */     PageResources prs = getPageResources();
/* 3323 */     PdfName name = this.state.colorDetails.getColorSpaceName();
/* 3324 */     name = prs.addColor(name, this.state.colorDetails.getIndirectReference());
/* 3325 */     saveColor(new LabColor(lab, l, a, b), true);
/* 3326 */     this.content.append(name.getBytes()).append(" CS ");
/* 3327 */     this.content.append(l + " " + a + " " + b + " ");
/* 3328 */     this.content.append("SCN").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPatternFill(PdfPatternPainter p)
/*      */   {
/* 3336 */     if (p.isStencil()) {
/* 3337 */       setPatternFill(p, p.getDefaultColor());
/* 3338 */       return;
/*      */     }
/* 3340 */     checkWriter();
/* 3341 */     PageResources prs = getPageResources();
/* 3342 */     PdfName name = this.writer.addSimplePattern(p);
/* 3343 */     name = prs.addPattern(name, p.getIndirectReference());
/* 3344 */     saveColor(new PatternColor(p), true);
/* 3345 */     this.content.append(PdfName.PATTERN.getBytes()).append(" cs ").append(name.getBytes()).append(" scn").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void outputColorNumbers(BaseColor color, float tint)
/*      */   {
/* 3353 */     PdfWriter.checkPdfIsoConformance(this.writer, 1, color);
/* 3354 */     int type = ExtendedColor.getType(color);
/* 3355 */     switch (type) {
/*      */     case 0: 
/* 3357 */       this.content.append(color.getRed() / 255.0F);
/* 3358 */       this.content.append(' ');
/* 3359 */       this.content.append(color.getGreen() / 255.0F);
/* 3360 */       this.content.append(' ');
/* 3361 */       this.content.append(color.getBlue() / 255.0F);
/* 3362 */       break;
/*      */     case 1: 
/* 3364 */       this.content.append(((GrayColor)color).getGray());
/* 3365 */       break;
/*      */     case 2: 
/* 3367 */       CMYKColor cmyk = (CMYKColor)color;
/* 3368 */       this.content.append(cmyk.getCyan()).append(' ').append(cmyk.getMagenta());
/* 3369 */       this.content.append(' ').append(cmyk.getYellow()).append(' ').append(cmyk.getBlack());
/* 3370 */       break;
/*      */     
/*      */     case 3: 
/* 3373 */       this.content.append(tint);
/* 3374 */       break;
/*      */     default: 
/* 3376 */       throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.color.type", new Object[0]));
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPatternFill(PdfPatternPainter p, BaseColor color)
/*      */   {
/* 3385 */     if (ExtendedColor.getType(color) == 3) {
/* 3386 */       setPatternFill(p, color, ((SpotColor)color).getTint());
/*      */     } else {
/* 3388 */       setPatternFill(p, color, 0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPatternFill(PdfPatternPainter p, BaseColor color, float tint)
/*      */   {
/* 3397 */     checkWriter();
/* 3398 */     if (!p.isStencil())
/* 3399 */       throw new RuntimeException(MessageLocalization.getComposedMessage("an.uncolored.pattern.was.expected", new Object[0]));
/* 3400 */     PageResources prs = getPageResources();
/* 3401 */     PdfName name = this.writer.addSimplePattern(p);
/* 3402 */     name = prs.addPattern(name, p.getIndirectReference());
/* 3403 */     ColorDetails csDetail = this.writer.addSimplePatternColorspace(color);
/* 3404 */     PdfName cName = prs.addColor(csDetail.getColorSpaceName(), csDetail.getIndirectReference());
/* 3405 */     saveColor(new UncoloredPattern(p, color, tint), true);
/* 3406 */     this.content.append(cName.getBytes()).append(" cs").append_i(this.separator);
/* 3407 */     outputColorNumbers(color, tint);
/* 3408 */     this.content.append(' ').append(name.getBytes()).append(" scn").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPatternStroke(PdfPatternPainter p, BaseColor color)
/*      */   {
/* 3416 */     if (ExtendedColor.getType(color) == 3) {
/* 3417 */       setPatternStroke(p, color, ((SpotColor)color).getTint());
/*      */     } else {
/* 3419 */       setPatternStroke(p, color, 0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPatternStroke(PdfPatternPainter p, BaseColor color, float tint)
/*      */   {
/* 3428 */     checkWriter();
/* 3429 */     if (!p.isStencil())
/* 3430 */       throw new RuntimeException(MessageLocalization.getComposedMessage("an.uncolored.pattern.was.expected", new Object[0]));
/* 3431 */     PageResources prs = getPageResources();
/* 3432 */     PdfName name = this.writer.addSimplePattern(p);
/* 3433 */     name = prs.addPattern(name, p.getIndirectReference());
/* 3434 */     ColorDetails csDetail = this.writer.addSimplePatternColorspace(color);
/* 3435 */     PdfName cName = prs.addColor(csDetail.getColorSpaceName(), csDetail.getIndirectReference());
/* 3436 */     saveColor(new UncoloredPattern(p, color, tint), false);
/* 3437 */     this.content.append(cName.getBytes()).append(" CS").append_i(this.separator);
/* 3438 */     outputColorNumbers(color, tint);
/* 3439 */     this.content.append(' ').append(name.getBytes()).append(" SCN").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPatternStroke(PdfPatternPainter p)
/*      */   {
/* 3447 */     if (p.isStencil()) {
/* 3448 */       setPatternStroke(p, p.getDefaultColor());
/* 3449 */       return;
/*      */     }
/* 3451 */     checkWriter();
/* 3452 */     PageResources prs = getPageResources();
/* 3453 */     PdfName name = this.writer.addSimplePattern(p);
/* 3454 */     name = prs.addPattern(name, p.getIndirectReference());
/* 3455 */     saveColor(new PatternColor(p), false);
/* 3456 */     this.content.append(PdfName.PATTERN.getBytes()).append(" CS ").append(name.getBytes()).append(" SCN").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void paintShading(PdfShading shading)
/*      */   {
/* 3464 */     this.writer.addSimpleShading(shading);
/* 3465 */     PageResources prs = getPageResources();
/* 3466 */     PdfName name = prs.addShading(shading.getShadingName(), shading.getShadingReference());
/* 3467 */     this.content.append(name.getBytes()).append(" sh").append_i(this.separator);
/* 3468 */     ColorDetails details = shading.getColorDetails();
/* 3469 */     if (details != null) {
/* 3470 */       prs.addColor(details.getColorSpaceName(), details.getIndirectReference());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void paintShading(PdfShadingPattern shading)
/*      */   {
/* 3478 */     paintShading(shading.getShading());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShadingFill(PdfShadingPattern shading)
/*      */   {
/* 3486 */     this.writer.addSimpleShadingPattern(shading);
/* 3487 */     PageResources prs = getPageResources();
/* 3488 */     PdfName name = prs.addPattern(shading.getPatternName(), shading.getPatternReference());
/* 3489 */     saveColor(new ShadingColor(shading), true);
/* 3490 */     this.content.append(PdfName.PATTERN.getBytes()).append(" cs ").append(name.getBytes()).append(" scn").append_i(this.separator);
/* 3491 */     ColorDetails details = shading.getColorDetails();
/* 3492 */     if (details != null) {
/* 3493 */       prs.addColor(details.getColorSpaceName(), details.getIndirectReference());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setShadingStroke(PdfShadingPattern shading)
/*      */   {
/* 3501 */     this.writer.addSimpleShadingPattern(shading);
/* 3502 */     PageResources prs = getPageResources();
/* 3503 */     PdfName name = prs.addPattern(shading.getPatternName(), shading.getPatternReference());
/* 3504 */     saveColor(new ShadingColor(shading), false);
/* 3505 */     this.content.append(PdfName.PATTERN.getBytes()).append(" CS ").append(name.getBytes()).append(" SCN").append_i(this.separator);
/* 3506 */     ColorDetails details = shading.getColorDetails();
/* 3507 */     if (details != null) {
/* 3508 */       prs.addColor(details.getColorSpaceName(), details.getIndirectReference());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void checkWriter()
/*      */   {
/* 3515 */     if (this.writer == null) {
/* 3516 */       throw new NullPointerException(MessageLocalization.getComposedMessage("the.writer.in.pdfcontentbyte.is.null", new Object[0]));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void showText(PdfTextArray text)
/*      */   {
/* 3524 */     checkState();
/* 3525 */     if ((!this.inText) && (isTagged())) {
/* 3526 */       beginText(true);
/*      */     }
/* 3528 */     if (this.state.fontDetails == null)
/* 3529 */       throw new NullPointerException(MessageLocalization.getComposedMessage("font.and.size.must.be.set.before.writing.any.text", new Object[0]));
/* 3530 */     this.content.append("[");
/* 3531 */     ArrayList<Object> arrayList = text.getArrayList();
/* 3532 */     boolean lastWasNumber = false;
/* 3533 */     for (Object obj : arrayList) {
/* 3534 */       if ((obj instanceof String)) {
/* 3535 */         showText2((String)obj);
/* 3536 */         updateTx((String)obj, 0.0F);
/* 3537 */         lastWasNumber = false;
/*      */       }
/*      */       else {
/* 3540 */         if (lastWasNumber) {
/* 3541 */           this.content.append(' ');
/*      */         } else
/* 3543 */           lastWasNumber = true;
/* 3544 */         this.content.append(((Float)obj).floatValue());
/* 3545 */         updateTx("", ((Float)obj).floatValue());
/*      */       }
/*      */     }
/* 3548 */     this.content.append("]TJ").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfWriter getPdfWriter()
/*      */   {
/* 3556 */     return this.writer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDocument getPdfDocument()
/*      */   {
/* 3564 */     return this.pdf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void localGoto(String name, float llx, float lly, float urx, float ury)
/*      */   {
/* 3577 */     this.pdf.localGoto(name, llx, lly, urx, ury);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean localDestination(String name, PdfDestination destination)
/*      */   {
/* 3590 */     return this.pdf.localDestination(name, destination);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfContentByte getDuplicate()
/*      */   {
/* 3600 */     PdfContentByte cb = new PdfContentByte(this.writer);
/* 3601 */     cb.duplicatedFrom = this;
/* 3602 */     return cb;
/*      */   }
/*      */   
/*      */   public PdfContentByte getDuplicate(boolean inheritGraphicState) {
/* 3606 */     PdfContentByte cb = getDuplicate();
/* 3607 */     if (inheritGraphicState) {
/* 3608 */       cb.state = this.state;
/* 3609 */       cb.stateList = this.stateList;
/*      */     }
/* 3611 */     return cb;
/*      */   }
/*      */   
/*      */   public void inheritGraphicState(PdfContentByte parentCanvas) {
/* 3615 */     this.state = parentCanvas.state;
/* 3616 */     this.stateList = parentCanvas.stateList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remoteGoto(String filename, String name, float llx, float lly, float urx, float ury)
/*      */   {
/* 3629 */     this.pdf.remoteGoto(filename, name, llx, lly, urx, ury);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remoteGoto(String filename, int page, float llx, float lly, float urx, float ury)
/*      */   {
/* 3642 */     this.pdf.remoteGoto(filename, page, llx, lly, urx, ury);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void roundRectangle(float x, float y, float w, float h, float r)
/*      */   {
/* 3655 */     roundRectangle(x, y, w, h, r);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void roundRectangle(double x, double y, double w, double h, double r)
/*      */   {
/* 3668 */     if (w < 0.0D) {
/* 3669 */       x += w;
/* 3670 */       w = -w;
/*      */     }
/* 3672 */     if (h < 0.0D) {
/* 3673 */       y += h;
/* 3674 */       h = -h;
/*      */     }
/* 3676 */     if (r < 0.0D)
/* 3677 */       r = -r;
/* 3678 */     float b = 0.4477F;
/* 3679 */     moveTo(x + r, y);
/* 3680 */     lineTo(x + w - r, y);
/* 3681 */     curveTo(x + w - r * b, y, x + w, y + r * b, x + w, y + r);
/* 3682 */     lineTo(x + w, y + h - r);
/* 3683 */     curveTo(x + w, y + h - r * b, x + w - r * b, y + h, x + w - r, y + h);
/* 3684 */     lineTo(x + r, y + h);
/* 3685 */     curveTo(x + r * b, y + h, x, y + h - r * b, x, y + h - r);
/* 3686 */     lineTo(x, y + r);
/* 3687 */     curveTo(x, y + r * b, x + r * b, y, x + r, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAction(PdfAction action, float llx, float lly, float urx, float ury)
/*      */   {
/* 3698 */     this.pdf.setAction(action, llx, lly, urx, ury);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLiteral(String s)
/*      */   {
/* 3705 */     this.content.append(s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLiteral(char c)
/*      */   {
/* 3712 */     this.content.append(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLiteral(float n)
/*      */   {
/* 3719 */     this.content.append(n);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void checkNoPattern(PdfTemplate t)
/*      */   {
/* 3726 */     if (t.getType() == 3) {
/* 3727 */       throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.use.of.a.pattern.a.template.was.expected", new Object[0]));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawRadioField(float llx, float lly, float urx, float ury, boolean on)
/*      */   {
/* 3739 */     drawRadioField(llx, lly, urx, ury, on);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawRadioField(double llx, double lly, double urx, double ury, boolean on)
/*      */   {
/* 3751 */     if (llx > urx) { double x = llx;llx = urx;urx = x; }
/* 3752 */     if (lly > ury) { double y = lly;lly = ury;ury = y; }
/* 3753 */     saveState();
/*      */     
/* 3755 */     setLineWidth(1.0F);
/* 3756 */     setLineCap(1);
/* 3757 */     setColorStroke(new BaseColor(192, 192, 192));
/* 3758 */     arc(llx + 1.0D, lly + 1.0D, urx - 1.0D, ury - 1.0D, 0.0D, 360.0D);
/* 3759 */     stroke();
/*      */     
/* 3761 */     setLineWidth(1.0F);
/* 3762 */     setLineCap(1);
/* 3763 */     setColorStroke(new BaseColor(160, 160, 160));
/* 3764 */     arc(llx + 0.5D, lly + 0.5D, urx - 0.5D, ury - 0.5D, 45.0D, 180.0D);
/* 3765 */     stroke();
/*      */     
/* 3767 */     setLineWidth(1.0F);
/* 3768 */     setLineCap(1);
/* 3769 */     setColorStroke(new BaseColor(0, 0, 0));
/* 3770 */     arc(llx + 1.5D, lly + 1.5D, urx - 1.5D, ury - 1.5D, 45.0D, 180.0D);
/* 3771 */     stroke();
/* 3772 */     if (on)
/*      */     {
/* 3774 */       setLineWidth(1.0F);
/* 3775 */       setLineCap(1);
/* 3776 */       setColorFill(new BaseColor(0, 0, 0));
/* 3777 */       arc(llx + 4.0D, lly + 4.0D, urx - 4.0D, ury - 4.0D, 0.0D, 360.0D);
/* 3778 */       fill();
/*      */     }
/* 3780 */     restoreState();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawTextField(float llx, float lly, float urx, float ury)
/*      */   {
/* 3791 */     drawTextField(llx, lly, urx, ury);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawTextField(double llx, double lly, double urx, double ury)
/*      */   {
/* 3802 */     if (llx > urx) { double x = llx;llx = urx;urx = x; }
/* 3803 */     if (lly > ury) { double y = lly;lly = ury;ury = y;
/*      */     }
/* 3805 */     saveState();
/* 3806 */     setColorStroke(new BaseColor(192, 192, 192));
/* 3807 */     setLineWidth(1.0F);
/* 3808 */     setLineCap(0);
/* 3809 */     rectangle(llx, lly, urx - llx, ury - lly);
/* 3810 */     stroke();
/*      */     
/* 3812 */     setLineWidth(1.0F);
/* 3813 */     setLineCap(0);
/* 3814 */     setColorFill(new BaseColor(255, 255, 255));
/* 3815 */     rectangle(llx + 0.5D, lly + 0.5D, urx - llx - 1.0D, ury - lly - 1.0D);
/* 3816 */     fill();
/*      */     
/* 3818 */     setColorStroke(new BaseColor(192, 192, 192));
/* 3819 */     setLineWidth(1.0F);
/* 3820 */     setLineCap(0);
/* 3821 */     moveTo(llx + 1.0D, lly + 1.5D);
/* 3822 */     lineTo(urx - 1.5D, lly + 1.5D);
/* 3823 */     lineTo(urx - 1.5D, ury - 1.0D);
/* 3824 */     stroke();
/*      */     
/* 3826 */     setColorStroke(new BaseColor(160, 160, 160));
/* 3827 */     setLineWidth(1.0F);
/* 3828 */     setLineCap(0);
/* 3829 */     moveTo(llx + 1.0D, lly + 1.0D);
/* 3830 */     lineTo(llx + 1.0D, ury - 1.0D);
/* 3831 */     lineTo(urx - 1.0D, ury - 1.0D);
/* 3832 */     stroke();
/*      */     
/* 3834 */     setColorStroke(new BaseColor(0, 0, 0));
/* 3835 */     setLineWidth(1.0F);
/* 3836 */     setLineCap(0);
/* 3837 */     moveTo(llx + 2.0D, lly + 2.0D);
/* 3838 */     lineTo(llx + 2.0D, ury - 2.0D);
/* 3839 */     lineTo(urx - 2.0D, ury - 2.0D);
/* 3840 */     stroke();
/* 3841 */     restoreState();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawButton(float llx, float lly, float urx, float ury, String text, BaseFont bf, float size)
/*      */   {
/* 3855 */     drawButton(llx, lly, urx, ury, text, bf, size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawButton(double llx, double lly, double urx, double ury, String text, BaseFont bf, float size)
/*      */   {
/* 3869 */     if (llx > urx) { double x = llx;llx = urx;urx = x; }
/* 3870 */     if (lly > ury) { double y = lly;lly = ury;ury = y;
/*      */     }
/* 3872 */     saveState();
/* 3873 */     setColorStroke(new BaseColor(0, 0, 0));
/* 3874 */     setLineWidth(1.0F);
/* 3875 */     setLineCap(0);
/* 3876 */     rectangle(llx, lly, urx - llx, ury - lly);
/* 3877 */     stroke();
/*      */     
/* 3879 */     setLineWidth(1.0F);
/* 3880 */     setLineCap(0);
/* 3881 */     setColorFill(new BaseColor(192, 192, 192));
/* 3882 */     rectangle(llx + 0.5D, lly + 0.5D, urx - llx - 1.0D, ury - lly - 1.0D);
/* 3883 */     fill();
/*      */     
/* 3885 */     setColorStroke(new BaseColor(255, 255, 255));
/* 3886 */     setLineWidth(1.0F);
/* 3887 */     setLineCap(0);
/* 3888 */     moveTo(llx + 1.0D, lly + 1.0D);
/* 3889 */     lineTo(llx + 1.0D, ury - 1.0D);
/* 3890 */     lineTo(urx - 1.0D, ury - 1.0D);
/* 3891 */     stroke();
/*      */     
/* 3893 */     setColorStroke(new BaseColor(160, 160, 160));
/* 3894 */     setLineWidth(1.0F);
/* 3895 */     setLineCap(0);
/* 3896 */     moveTo(llx + 1.0D, lly + 1.0D);
/* 3897 */     lineTo(urx - 1.0D, lly + 1.0D);
/* 3898 */     lineTo(urx - 1.0D, ury - 1.0D);
/* 3899 */     stroke();
/*      */     
/* 3901 */     resetRGBColorFill();
/* 3902 */     beginText();
/* 3903 */     setFontAndSize(bf, size);
/* 3904 */     showTextAligned(1, text, (float)(llx + (urx - llx) / 2.0D), (float)(lly + (ury - lly - size) / 2.0D), 0.0F);
/* 3905 */     endText();
/* 3906 */     restoreState();
/*      */   }
/*      */   
/*      */   PageResources getPageResources() {
/* 3910 */     return this.pdf.getPageResources();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGState(PdfGState gstate)
/*      */   {
/* 3917 */     PdfObject[] obj = this.writer.addSimpleExtGState(gstate);
/* 3918 */     PageResources prs = getPageResources();
/* 3919 */     PdfName name = prs.addExtGState((PdfName)obj[0], (PdfIndirectReference)obj[1]);
/* 3920 */     this.state.extGState = gstate;
/* 3921 */     this.content.append(name.getBytes()).append(" gs").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void beginLayer(PdfOCG layer)
/*      */   {
/* 3933 */     if (((layer instanceof PdfLayer)) && (((PdfLayer)layer).getTitle() != null))
/* 3934 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("a.title.is.not.a.layer", new Object[0]));
/* 3935 */     if (this.layerDepth == null)
/* 3936 */       this.layerDepth = new ArrayList();
/* 3937 */     if ((layer instanceof PdfLayerMembership)) {
/* 3938 */       this.layerDepth.add(Integer.valueOf(1));
/* 3939 */       beginLayer2(layer);
/* 3940 */       return;
/*      */     }
/* 3942 */     int n = 0;
/* 3943 */     PdfLayer la = (PdfLayer)layer;
/* 3944 */     while (la != null) {
/* 3945 */       if (la.getTitle() == null) {
/* 3946 */         beginLayer2(la);
/* 3947 */         n++;
/*      */       }
/* 3949 */       la = la.getParent();
/*      */     }
/* 3951 */     this.layerDepth.add(Integer.valueOf(n));
/*      */   }
/*      */   
/*      */   private void beginLayer2(PdfOCG layer) {
/* 3955 */     PdfName name = (PdfName)this.writer.addSimpleProperty(layer, layer.getRef())[0];
/* 3956 */     PageResources prs = getPageResources();
/* 3957 */     name = prs.addProperty(name, layer.getRef());
/* 3958 */     this.content.append("/OC ").append(name.getBytes()).append(" BDC").append_i(this.separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void endLayer()
/*      */   {
/* 3965 */     int n = 1;
/* 3966 */     if ((this.layerDepth != null) && (!this.layerDepth.isEmpty())) {
/* 3967 */       n = ((Integer)this.layerDepth.get(this.layerDepth.size() - 1)).intValue();
/* 3968 */       this.layerDepth.remove(this.layerDepth.size() - 1);
/*      */     } else {
/* 3970 */       throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.layer.operators", new Object[0]));
/*      */     }
/* 3972 */     while (n-- > 0) {
/* 3973 */       this.content.append("EMC").append_i(this.separator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void transform(com.itextpdf.awt.geom.AffineTransform af)
/*      */   {
/* 3981 */     if ((this.inText) && (isTagged())) {
/* 3982 */       endText();
/*      */     }
/* 3984 */     double[] matrix = new double[6];
/* 3985 */     af.getMatrix(matrix);
/* 3986 */     this.state.CTM.concatenate(af);
/* 3987 */     this.content.append(matrix[0]).append(' ').append(matrix[1]).append(' ').append(matrix[2]).append(' ');
/* 3988 */     this.content.append(matrix[3]).append(' ').append(matrix[4]).append(' ').append(matrix[5]).append(" cm").append_i(this.separator);
/*      */   }
/*      */   
/*      */   void addAnnotation(PdfAnnotation annot) {
/* 3992 */     boolean needToTag = (isTagged()) && (annot.getRole() != null) && ((!(annot instanceof PdfFormField)) || (((PdfFormField)annot).getKids() == null));
/* 3993 */     if (needToTag) {
/* 3994 */       openMCBlock(annot);
/*      */     }
/* 3996 */     this.writer.addAnnotation(annot);
/* 3997 */     if (needToTag) {
/* 3998 */       PdfStructureElement strucElem = this.pdf.getStructElement(annot.getId());
/* 3999 */       if (strucElem != null) {
/* 4000 */         int structParent = this.pdf.getStructParentIndex(annot);
/* 4001 */         annot.put(PdfName.STRUCTPARENT, new PdfNumber(structParent));
/* 4002 */         strucElem.setAnnotation(annot, getCurrentPage());
/* 4003 */         this.writer.getStructureTreeRoot().setAnnotationMark(structParent, strucElem.getReference());
/*      */       }
/* 4005 */       closeMCBlock(annot);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addAnnotation(PdfAnnotation annot, boolean applyCTM) {
/* 4010 */     if ((applyCTM) && (this.state.CTM.getType() != 0)) {
/* 4011 */       annot.applyCTM(this.state.CTM);
/*      */     }
/* 4013 */     addAnnotation(annot);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultColorspace(PdfName name, PdfObject obj)
/*      */   {
/* 4023 */     PageResources prs = getPageResources();
/* 4024 */     prs.addDefaultColor(name, obj);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void beginMarkedContentSequence(PdfStructureElement struc)
/*      */   {
/* 4034 */     beginMarkedContentSequence(struc, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void beginMarkedContentSequence(PdfStructureElement struc, String expansion)
/*      */   {
/* 4046 */     PdfObject obj = struc.get(PdfName.K);
/* 4047 */     int[] structParentMarkPoint = this.pdf.getStructParentIndexAndNextMarkPoint(getCurrentPage());
/* 4048 */     int structParent = structParentMarkPoint[0];
/* 4049 */     int mark = structParentMarkPoint[1];
/* 4050 */     if (obj != null) {
/* 4051 */       PdfArray ar = null;
/* 4052 */       if (obj.isNumber()) {
/* 4053 */         ar = new PdfArray();
/* 4054 */         ar.add(obj);
/* 4055 */         struc.put(PdfName.K, ar);
/*      */       }
/* 4057 */       else if (obj.isArray()) {
/* 4058 */         ar = (PdfArray)obj;
/*      */       }
/*      */       else {
/* 4061 */         throw new IllegalArgumentException(MessageLocalization.getComposedMessage("unknown.object.at.k.1", new Object[] { obj.getClass().toString() })); }
/* 4062 */       if (ar.getAsNumber(0) != null) {
/* 4063 */         PdfDictionary dic = new PdfDictionary(PdfName.MCR);
/* 4064 */         dic.put(PdfName.PG, getCurrentPage());
/* 4065 */         dic.put(PdfName.MCID, new PdfNumber(mark));
/* 4066 */         ar.add(dic);
/*      */       }
/* 4068 */       struc.setPageMark(this.pdf.getStructParentIndex(getCurrentPage()), -1);
/*      */     }
/*      */     else {
/* 4071 */       struc.setPageMark(structParent, mark);
/* 4072 */       struc.put(PdfName.PG, getCurrentPage());
/*      */     }
/* 4074 */     setMcDepth(getMcDepth() + 1);
/* 4075 */     int contentSize = this.content.size();
/* 4076 */     this.content.append(struc.get(PdfName.S).getBytes()).append(" <</MCID ").append(mark);
/* 4077 */     if (null != expansion) {
/* 4078 */       this.content.append("/E (").append(expansion).append(")");
/*      */     }
/* 4080 */     this.content.append(">> BDC").append_i(this.separator);
/* 4081 */     this.markedContentSize += this.content.size() - contentSize;
/*      */   }
/*      */   
/*      */   protected PdfIndirectReference getCurrentPage() {
/* 4085 */     return this.writer.getCurrentPage();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void endMarkedContentSequence()
/*      */   {
/* 4092 */     if (getMcDepth() == 0) {
/* 4093 */       throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.begin.end.marked.content.operators", new Object[0]));
/*      */     }
/* 4095 */     int contentSize = this.content.size();
/* 4096 */     setMcDepth(getMcDepth() - 1);
/* 4097 */     this.content.append("EMC").append_i(this.separator);
/* 4098 */     this.markedContentSize += this.content.size() - contentSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void beginMarkedContentSequence(PdfName tag, PdfDictionary property, boolean inline)
/*      */   {
/* 4110 */     int contentSize = this.content.size();
/* 4111 */     if (property == null) {
/* 4112 */       this.content.append(tag.getBytes()).append(" BMC").append_i(this.separator);
/* 4113 */       setMcDepth(getMcDepth() + 1);
/*      */     } else {
/* 4115 */       this.content.append(tag.getBytes()).append(' ');
/* 4116 */       if (inline) {
/*      */         try {
/* 4118 */           property.toPdf(this.writer, this.content);
/*      */         }
/*      */         catch (Exception e) {
/* 4121 */           throw new ExceptionConverter(e);
/*      */         }
/*      */       } else { PdfObject[] objs;
/*      */         PdfObject[] objs;
/* 4125 */         if (this.writer.propertyExists(property)) {
/* 4126 */           objs = this.writer.addSimpleProperty(property, null);
/*      */         } else
/* 4128 */           objs = this.writer.addSimpleProperty(property, this.writer.getPdfIndirectReference());
/* 4129 */         PdfName name = (PdfName)objs[0];
/* 4130 */         PageResources prs = getPageResources();
/* 4131 */         name = prs.addProperty(name, (PdfIndirectReference)objs[1]);
/* 4132 */         this.content.append(name.getBytes());
/*      */       }
/* 4134 */       this.content.append(" BDC").append_i(this.separator);
/* 4135 */       setMcDepth(getMcDepth() + 1);
/*      */     }
/* 4137 */     this.markedContentSize += this.content.size() - contentSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void beginMarkedContentSequence(PdfName tag)
/*      */   {
/* 4145 */     beginMarkedContentSequence(tag, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sanityCheck()
/*      */   {
/* 4160 */     if (getMcDepth() != 0) {
/* 4161 */       throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.marked.content.operators", new Object[0]));
/*      */     }
/* 4163 */     if (this.inText) {
/* 4164 */       if (isTagged()) {
/* 4165 */         endText();
/*      */       } else {
/* 4167 */         throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.begin.end.text.operators", new Object[0]));
/*      */       }
/*      */     }
/* 4170 */     if ((this.layerDepth != null) && (!this.layerDepth.isEmpty())) {
/* 4171 */       throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.layer.operators", new Object[0]));
/*      */     }
/* 4173 */     if (!this.stateList.isEmpty()) {
/* 4174 */       throw new IllegalPdfSyntaxException(MessageLocalization.getComposedMessage("unbalanced.save.restore.state.operators", new Object[0]));
/*      */     }
/*      */   }
/*      */   
/*      */   public void openMCBlock(IAccessibleElement element) {
/* 4179 */     if (isTagged()) {
/* 4180 */       ensureDocumentTagIsOpen();
/* 4181 */       if ((element != null) && 
/* 4182 */         (!getMcElements().contains(element))) {
/* 4183 */         PdfStructureElement structureElement = openMCBlockInt(element);
/* 4184 */         getMcElements().add(element);
/* 4185 */         if (structureElement != null) {
/* 4186 */           this.pdf.saveStructElement(element.getId(), structureElement);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private PdfDictionary getParentStructureElement()
/*      */   {
/* 4194 */     PdfDictionary parent = null;
/* 4195 */     if (getMcElements().size() > 0)
/* 4196 */       parent = this.pdf.getStructElement(((IAccessibleElement)getMcElements().get(getMcElements().size() - 1)).getId());
/* 4197 */     if (parent == null) {
/* 4198 */       parent = this.writer.getStructureTreeRoot();
/*      */     }
/* 4200 */     return parent;
/*      */   }
/*      */   
/*      */   private PdfStructureElement openMCBlockInt(IAccessibleElement element) {
/* 4204 */     PdfStructureElement structureElement = null;
/* 4205 */     if (isTagged()) {
/* 4206 */       IAccessibleElement parent = null;
/* 4207 */       if (getMcElements().size() > 0)
/* 4208 */         parent = (IAccessibleElement)getMcElements().get(getMcElements().size() - 1);
/* 4209 */       this.writer.checkElementRole(element, parent);
/* 4210 */       if (element.getRole() != null) {
/* 4211 */         if (!PdfName.ARTIFACT.equals(element.getRole())) {
/* 4212 */           structureElement = this.pdf.getStructElement(element.getId());
/* 4213 */           if (structureElement == null) {
/* 4214 */             structureElement = new PdfStructureElement(getParentStructureElement(), element.getRole(), element.getId());
/*      */           }
/*      */         }
/* 4217 */         if (PdfName.ARTIFACT.equals(element.getRole())) {
/* 4218 */           HashMap<PdfName, PdfObject> properties = element.getAccessibleAttributes();
/* 4219 */           PdfDictionary propertiesDict = null;
/* 4220 */           if ((properties != null) && (!properties.isEmpty())) {
/* 4221 */             propertiesDict = new PdfDictionary();
/* 4222 */             for (Map.Entry<PdfName, PdfObject> entry : properties.entrySet()) {
/* 4223 */               propertiesDict.put((PdfName)entry.getKey(), (PdfObject)entry.getValue());
/*      */             }
/*      */           }
/* 4226 */           boolean inTextLocal = this.inText;
/* 4227 */           if (this.inText)
/* 4228 */             endText();
/* 4229 */           beginMarkedContentSequence(element.getRole(), propertiesDict, true);
/* 4230 */           if (inTextLocal) {
/* 4231 */             beginText(true);
/*      */           }
/* 4233 */         } else if (this.writer.needToBeMarkedInContent(element)) {
/* 4234 */           boolean inTextLocal = this.inText;
/* 4235 */           if (this.inText)
/* 4236 */             endText();
/* 4237 */           if ((null != element.getAccessibleAttributes()) && (null != element.getAccessibleAttribute(PdfName.E))) {
/* 4238 */             beginMarkedContentSequence(structureElement, element.getAccessibleAttribute(PdfName.E).toString());
/* 4239 */             element.setAccessibleAttribute(PdfName.E, null);
/*      */           } else {
/* 4241 */             beginMarkedContentSequence(structureElement);
/*      */           }
/* 4243 */           if (inTextLocal) {
/* 4244 */             beginText(true);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4249 */     return structureElement;
/*      */   }
/*      */   
/*      */   public void closeMCBlock(IAccessibleElement element) {
/* 4253 */     if ((isTagged()) && (element != null) && 
/* 4254 */       (getMcElements().contains(element))) {
/* 4255 */       closeMCBlockInt(element);
/* 4256 */       getMcElements().remove(element);
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeMCBlockInt(IAccessibleElement element)
/*      */   {
/* 4262 */     if ((isTagged()) && (element.getRole() != null)) {
/* 4263 */       PdfStructureElement structureElement = this.pdf.getStructElement(element.getId());
/* 4264 */       if (structureElement != null) {
/* 4265 */         structureElement.writeAttributes(element);
/*      */       }
/* 4267 */       if (this.writer.needToBeMarkedInContent(element)) {
/* 4268 */         boolean inTextLocal = this.inText;
/* 4269 */         if (this.inText)
/* 4270 */           endText();
/* 4271 */         endMarkedContentSequence();
/* 4272 */         if (inTextLocal)
/* 4273 */           beginText(true);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void ensureDocumentTagIsOpen() {
/* 4279 */     if (this.pdf.openMCDocument) {
/* 4280 */       this.pdf.openMCDocument = false;
/* 4281 */       this.writer.getDirectContentUnder().openMCBlock(this.pdf);
/*      */     }
/*      */   }
/*      */   
/*      */   protected ArrayList<IAccessibleElement> saveMCBlocks() {
/* 4286 */     ArrayList<IAccessibleElement> mc = new ArrayList();
/* 4287 */     if (isTagged()) {
/* 4288 */       mc = getMcElements();
/* 4289 */       for (int i = 0; i < mc.size(); i++) {
/* 4290 */         closeMCBlockInt((IAccessibleElement)mc.get(i));
/*      */       }
/* 4292 */       setMcElements(new ArrayList());
/*      */     }
/* 4294 */     return mc;
/*      */   }
/*      */   
/*      */   protected void restoreMCBlocks(ArrayList<IAccessibleElement> mcElements) {
/* 4298 */     if ((isTagged()) && (mcElements != null)) {
/* 4299 */       setMcElements(mcElements);
/* 4300 */       for (int i = 0; i < getMcElements().size(); i++) {
/* 4301 */         openMCBlockInt((IAccessibleElement)getMcElements().get(i));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected int getMcDepth() {
/* 4307 */     if (this.duplicatedFrom != null) {
/* 4308 */       return this.duplicatedFrom.getMcDepth();
/*      */     }
/* 4310 */     return this.mcDepth;
/*      */   }
/*      */   
/*      */   protected void setMcDepth(int value) {
/* 4314 */     if (this.duplicatedFrom != null) {
/* 4315 */       this.duplicatedFrom.setMcDepth(value);
/*      */     } else
/* 4317 */       this.mcDepth = value;
/*      */   }
/*      */   
/*      */   protected ArrayList<IAccessibleElement> getMcElements() {
/* 4321 */     if (this.duplicatedFrom != null) {
/* 4322 */       return this.duplicatedFrom.getMcElements();
/*      */     }
/* 4324 */     return this.mcElements;
/*      */   }
/*      */   
/*      */   protected void setMcElements(ArrayList<IAccessibleElement> value) {
/* 4328 */     if (this.duplicatedFrom != null) {
/* 4329 */       this.duplicatedFrom.setMcElements(value);
/*      */     } else
/* 4331 */       this.mcElements = value;
/*      */   }
/*      */   
/*      */   protected void updateTx(String text, float Tj) {
/* 4335 */     this.state.tx += getEffectiveStringWidth(text, false, Tj);
/*      */   }
/*      */   
/*      */   private void saveColor(BaseColor color, boolean fill) {
/* 4339 */     if (fill) {
/* 4340 */       this.state.colorFill = color;
/*      */     } else {
/* 4342 */       this.state.colorStroke = color;
/*      */     }
/*      */   }
/*      */   
/*      */   static class UncoloredPattern extends PatternColor {
/*      */     protected BaseColor color;
/*      */     protected float tint;
/*      */     
/*      */     protected UncoloredPattern(PdfPatternPainter p, BaseColor color, float tint) {
/* 4351 */       super();
/* 4352 */       this.color = color;
/* 4353 */       this.tint = tint;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj)
/*      */     {
/* 4358 */       return ((obj instanceof UncoloredPattern)) && (((UncoloredPattern)obj).painter.equals(this.painter)) && (((UncoloredPattern)obj).color.equals(this.color)) && (((UncoloredPattern)obj).tint == this.tint);
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean getInText()
/*      */   {
/* 4364 */     return this.inText;
/*      */   }
/*      */   
/*      */   protected void checkState() {
/* 4368 */     boolean stroke = false;
/* 4369 */     boolean fill = false;
/* 4370 */     if (this.state.textRenderMode == 0) {
/* 4371 */       fill = true;
/* 4372 */     } else if (this.state.textRenderMode == 1) {
/* 4373 */       stroke = true;
/* 4374 */     } else if (this.state.textRenderMode == 2) {
/* 4375 */       fill = true;
/* 4376 */       stroke = true;
/*      */     }
/* 4378 */     if (fill) {
/* 4379 */       PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorFill);
/*      */     }
/* 4381 */     if (stroke) {
/* 4382 */       PdfWriter.checkPdfIsoConformance(this.writer, 1, this.state.colorStroke);
/*      */     }
/* 4384 */     PdfWriter.checkPdfIsoConformance(this.writer, 6, this.state.extGState);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createGraphicsShapes(float width, float height)
/*      */   {
/* 4397 */     return new PdfGraphics2D(this, width, height, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createPrinterGraphicsShapes(float width, float height, PrinterJob printerJob)
/*      */   {
/* 4409 */     return new PdfPrinterGraphics2D(this, width, height, true, printerJob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createGraphics(float width, float height)
/*      */   {
/* 4420 */     return new PdfGraphics2D(this, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createPrinterGraphics(float width, float height, PrinterJob printerJob)
/*      */   {
/* 4432 */     return new PdfPrinterGraphics2D(this, width, height, printerJob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createGraphics(float width, float height, boolean convertImagesToJPEG, float quality)
/*      */   {
/* 4445 */     return new PdfGraphics2D(this, width, height, null, false, convertImagesToJPEG, quality);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createPrinterGraphics(float width, float height, boolean convertImagesToJPEG, float quality, PrinterJob printerJob)
/*      */   {
/* 4459 */     return new PdfPrinterGraphics2D(this, width, height, null, false, convertImagesToJPEG, quality, printerJob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createGraphicsShapes(float width, float height, boolean convertImagesToJPEG, float quality)
/*      */   {
/* 4472 */     return new PdfGraphics2D(this, width, height, null, true, convertImagesToJPEG, quality);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createPrinterGraphicsShapes(float width, float height, boolean convertImagesToJPEG, float quality, PrinterJob printerJob)
/*      */   {
/* 4486 */     return new PdfPrinterGraphics2D(this, width, height, null, true, convertImagesToJPEG, quality, printerJob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createGraphics(float width, float height, FontMapper fontMapper)
/*      */   {
/* 4498 */     return new PdfGraphics2D(this, width, height, fontMapper);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createPrinterGraphics(float width, float height, FontMapper fontMapper, PrinterJob printerJob)
/*      */   {
/* 4511 */     return new PdfPrinterGraphics2D(this, width, height, fontMapper, printerJob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createGraphics(float width, float height, FontMapper fontMapper, boolean convertImagesToJPEG, float quality)
/*      */   {
/* 4525 */     return new PdfGraphics2D(this, width, height, fontMapper, false, convertImagesToJPEG, quality);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Graphics2D createPrinterGraphics(float width, float height, FontMapper fontMapper, boolean convertImagesToJPEG, float quality, PrinterJob printerJob)
/*      */   {
/* 4540 */     return new PdfPrinterGraphics2D(this, width, height, fontMapper, false, convertImagesToJPEG, quality, printerJob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void addImage(Image image, java.awt.geom.AffineTransform transform)
/*      */     throws DocumentException
/*      */   {
/* 4551 */     double[] matrix = new double[6];
/* 4552 */     transform.getMatrix(matrix);
/* 4553 */     addImage(image, new com.itextpdf.awt.geom.AffineTransform(matrix));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void addTemplate(PdfTemplate template, java.awt.geom.AffineTransform transform)
/*      */   {
/* 4563 */     double[] matrix = new double[6];
/* 4564 */     transform.getMatrix(matrix);
/* 4565 */     addTemplate(template, new com.itextpdf.awt.geom.AffineTransform(matrix));
/*      */   }
/*      */   
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void concatCTM(java.awt.geom.AffineTransform transform)
/*      */   {
/* 4574 */     double[] matrix = new double[6];
/* 4575 */     transform.getMatrix(matrix);
/* 4576 */     concatCTM(new com.itextpdf.awt.geom.AffineTransform(matrix));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setTextMatrix(java.awt.geom.AffineTransform transform)
/*      */   {
/* 4586 */     double[] matrix = new double[6];
/* 4587 */     transform.getMatrix(matrix);
/* 4588 */     setTextMatrix(new com.itextpdf.awt.geom.AffineTransform(matrix));
/*      */   }
/*      */   
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void transform(java.awt.geom.AffineTransform af)
/*      */   {
/* 4597 */     double[] matrix = new double[6];
/* 4598 */     af.getMatrix(matrix);
/* 4599 */     transform(new com.itextpdf.awt.geom.AffineTransform(matrix));
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfContentByte.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */