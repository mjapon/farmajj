/*     */ package com.itextpdf.text.pdf.parser;
/*     */ 
/*     */ import com.itextpdf.text.pdf.PdfArray;
/*     */ import com.itextpdf.text.pdf.PdfNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineDashPattern
/*     */ {
/*     */   private PdfArray dashArray;
/*     */   private float dashPhase;
/*     */   private int currentIndex;
/*  60 */   private int elemOrdinalNumber = 1;
/*     */   
/*     */ 
/*     */   private DashArrayElem currentElem;
/*     */   
/*     */ 
/*     */ 
/*     */   public LineDashPattern(PdfArray dashArray, float dashPhase)
/*     */   {
/*  69 */     this.dashArray = new PdfArray(dashArray);
/*  70 */     this.dashPhase = dashPhase;
/*  71 */     initFirst(dashPhase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray getDashArray()
/*     */   {
/*  84 */     return this.dashArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDashArray(PdfArray dashArray)
/*     */   {
/*  92 */     this.dashArray = dashArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getDashPhase()
/*     */   {
/* 104 */     return this.dashPhase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDashPhase(float dashPhase)
/*     */   {
/* 112 */     this.dashPhase = dashPhase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DashArrayElem next()
/*     */   {
/* 120 */     DashArrayElem ret = this.currentElem;
/*     */     
/* 122 */     if (this.dashArray.size() > 0) {
/* 123 */       this.currentIndex = ((this.currentIndex + 1) % this.dashArray.size());
/*     */       
/* 125 */       this.currentElem = new DashArrayElem(this.dashArray.getAsNumber(this.currentIndex).floatValue(), isEven(++this.elemOrdinalNumber));
/*     */     }
/*     */     
/* 128 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 136 */     this.currentIndex = 0;
/* 137 */     this.elemOrdinalNumber = 1;
/* 138 */     initFirst(this.dashPhase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSolid()
/*     */   {
/* 148 */     if (this.dashArray.size() % 2 != 0) {
/* 149 */       return false;
/*     */     }
/*     */     
/* 152 */     float unitsOffSum = 0.0F;
/*     */     
/* 154 */     for (int i = 1; i < this.dashArray.size(); i += 2) {
/* 155 */       unitsOffSum += this.dashArray.getAsNumber(i).floatValue();
/*     */     }
/*     */     
/* 158 */     return Float.compare(unitsOffSum, 0.0F) == 0;
/*     */   }
/*     */   
/*     */   private void initFirst(float phase) {
/* 162 */     if (this.dashArray.size() > 0) {
/* 163 */       while (phase > 0.0F) {
/* 164 */         phase -= this.dashArray.getAsNumber(this.currentIndex).floatValue();
/* 165 */         this.currentIndex = ((this.currentIndex + 1) % this.dashArray.size());
/* 166 */         this.elemOrdinalNumber += 1;
/*     */       }
/*     */       
/* 169 */       if (phase < 0.0F) {
/* 170 */         this.elemOrdinalNumber -= 1;
/* 171 */         this.currentIndex -= 1;
/* 172 */         this.currentElem = new DashArrayElem(-phase, isEven(this.elemOrdinalNumber));
/*     */       }
/*     */       else {
/* 175 */         this.currentElem = new DashArrayElem(this.dashArray.getAsNumber(this.currentIndex).floatValue(), isEven(this.elemOrdinalNumber));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isEven(int num) {
/* 181 */     return num % 2 == 0;
/*     */   }
/*     */   
/*     */   public class DashArrayElem
/*     */   {
/*     */     private float val;
/*     */     private boolean isGap;
/*     */     
/*     */     public DashArrayElem(float val, boolean isGap) {
/* 190 */       this.val = val;
/* 191 */       this.isGap = isGap;
/*     */     }
/*     */     
/*     */     public float getVal() {
/* 195 */       return this.val;
/*     */     }
/*     */     
/*     */     public void setVal(float val) {
/* 199 */       this.val = val;
/*     */     }
/*     */     
/*     */     public boolean isGap() {
/* 203 */       return this.isGap;
/*     */     }
/*     */     
/*     */     public void setGap(boolean isGap) {
/* 207 */       this.isGap = isGap;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/LineDashPattern.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */