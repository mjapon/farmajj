/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Edge
/*     */ {
/*     */   private final Point.LongPoint bot;
/*     */   private final Point.LongPoint current;
/*     */   private final Point.LongPoint top;
/*     */   private final Point.LongPoint delta;
/*     */   double deltaX;
/*     */   Clipper.PolyType polyTyp;
/*     */   Side side;
/*     */   int windDelta;
/*     */   int windCnt;
/*     */   int windCnt2;
/*     */   int outIdx;
/*     */   Edge next;
/*     */   Edge prev;
/*     */   Edge nextInLML;
/*     */   Edge nextInAEL;
/*     */   Edge prevInAEL;
/*     */   Edge nextInSEL;
/*     */   Edge prevInSEL;
/*     */   protected static final int SKIP = -2;
/*     */   protected static final int UNASSIGNED = -1;
/*     */   protected static final double HORIZONTAL = -3.4E38D;
/*     */   
/*     */   static enum Side
/*     */   {
/*  89 */     LEFT,  RIGHT;
/*     */     
/*     */     private Side() {} }
/*     */   
/*  93 */   static boolean doesE2InsertBeforeE1(Edge e1, Edge e2) { if (e2.current.getX() == e1.current.getX()) {
/*  94 */       if (e2.top.getY() > e1.top.getY()) {
/*  95 */         return e2.top.getX() < topX(e1, e2.top.getY());
/*     */       }
/*     */       
/*  98 */       return e1.top.getX() > topX(e2, e1.top.getY());
/*     */     }
/*     */     
/*     */ 
/* 102 */     return e2.current.getX() < e1.current.getX();
/*     */   }
/*     */   
/*     */   static boolean slopesEqual(Edge e1, Edge e2, boolean useFullRange)
/*     */   {
/* 107 */     if (useFullRange) {
/* 108 */       return BigInteger.valueOf(e1.getDelta().getY()).multiply(BigInteger.valueOf(e2.getDelta().getX())).equals(
/* 109 */         BigInteger.valueOf(e1.getDelta().getX()).multiply(BigInteger.valueOf(e2.getDelta().getY())));
/*     */     }
/* 111 */     return e1.getDelta().getY() * e2.getDelta().getX() == e1.getDelta().getX() * e2.getDelta().getY();
/*     */   }
/*     */   
/*     */   static void swapPolyIndexes(Edge edge1, Edge edge2)
/*     */   {
/* 116 */     int outIdx = edge1.outIdx;
/* 117 */     edge1.outIdx = edge2.outIdx;
/* 118 */     edge2.outIdx = outIdx;
/*     */   }
/*     */   
/*     */   static void swapSides(Edge edge1, Edge edge2) {
/* 122 */     Side side = edge1.side;
/* 123 */     edge1.side = edge2.side;
/* 124 */     edge2.side = side;
/*     */   }
/*     */   
/*     */   static long topX(Edge edge, long currentY) {
/* 128 */     if (currentY == edge.getTop().getY()) {
/* 129 */       return edge.getTop().getX();
/*     */     }
/* 131 */     return edge.getBot().getX() + Math.round(edge.deltaX * (currentY - edge.getBot().getY()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */   private static final Logger LOGGER = Logger.getLogger(Edge.class.getName());
/*     */   
/*     */   public Edge() {
/* 169 */     this.delta = new Point.LongPoint();
/* 170 */     this.top = new Point.LongPoint();
/* 171 */     this.bot = new Point.LongPoint();
/* 172 */     this.current = new Point.LongPoint();
/*     */   }
/*     */   
/*     */   public Edge findNextLocMin() {
/* 176 */     Edge e = this;
/*     */     Edge e2;
/*     */     do {
/* 179 */       while ((!e.bot.equals(e.prev.bot)) || (e.current.equals(e.top))) {
/* 180 */         e = e.next;
/*     */       }
/* 182 */       if ((e.deltaX != -3.4E38D) && (e.prev.deltaX != -3.4E38D)) {
/*     */         break;
/*     */       }
/* 185 */       while (e.prev.deltaX == -3.4E38D) {
/* 186 */         e = e.prev;
/*     */       }
/* 188 */       e2 = e;
/* 189 */       while (e.deltaX == -3.4E38D) {
/* 190 */         e = e.next;
/*     */       }
/* 192 */     } while (e.top.getY() == e.prev.bot.getY());
/*     */     
/*     */ 
/* 195 */     if (e2.prev.bot.getX() < e.bot.getX()) {
/* 196 */       e = e2;
/*     */     }
/*     */     
/*     */ 
/* 200 */     return e;
/*     */   }
/*     */   
/*     */   public Point.LongPoint getBot() {
/* 204 */     return this.bot;
/*     */   }
/*     */   
/*     */   public Point.LongPoint getCurrent() {
/* 208 */     return this.current;
/*     */   }
/*     */   
/*     */   public Point.LongPoint getDelta() {
/* 212 */     return this.delta;
/*     */   }
/*     */   
/*     */   public Edge getMaximaPair() {
/* 216 */     Edge result = null;
/* 217 */     if ((this.next.top.equals(this.top)) && (this.next.nextInLML == null)) {
/* 218 */       result = this.next;
/*     */     }
/* 220 */     else if ((this.prev.top.equals(this.top)) && (this.prev.nextInLML == null)) {
/* 221 */       result = this.prev;
/*     */     }
/* 223 */     if ((result != null) && ((result.outIdx == -2) || ((result.nextInAEL == result.prevInAEL) && (!result.isHorizontal())))) {
/* 224 */       return null;
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */   
/*     */   public Edge getNextInAEL(Clipper.Direction direction) {
/* 230 */     return direction == Clipper.Direction.LEFT_TO_RIGHT ? this.nextInAEL : this.prevInAEL;
/*     */   }
/*     */   
/*     */   public Point.LongPoint getTop() {
/* 234 */     return this.top;
/*     */   }
/*     */   
/*     */   public boolean isContributing(Clipper.PolyFillType clipFillType, Clipper.PolyFillType subjFillType, Clipper.ClipType clipType) {
/* 238 */     LOGGER.entering(Edge.class.getName(), "isContributing");
/*     */     Clipper.PolyFillType pft2;
/*     */     Clipper.PolyFillType pft;
/* 241 */     Clipper.PolyFillType pft2; if (this.polyTyp == Clipper.PolyType.SUBJECT) {
/* 242 */       Clipper.PolyFillType pft = subjFillType;
/* 243 */       pft2 = clipFillType;
/*     */     }
/*     */     else {
/* 246 */       pft = clipFillType;
/* 247 */       pft2 = subjFillType;
/*     */     }
/*     */     
/* 250 */     switch (pft)
/*     */     {
/*     */     case EVEN_ODD: 
/* 253 */       if ((this.windDelta == 0) && (this.windCnt != 1)) {
/* 254 */         return false;
/*     */       }
/*     */       break;
/*     */     case NON_ZERO: 
/* 258 */       if (Math.abs(this.windCnt) != 1) {
/* 259 */         return false;
/*     */       }
/*     */       break;
/*     */     case POSITIVE: 
/* 263 */       if (this.windCnt != 1) {
/* 264 */         return false;
/*     */       }
/*     */       break;
/*     */     default: 
/* 268 */       if (this.windCnt != -1) {
/* 269 */         return false;
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/* 274 */     switch (clipType) {
/*     */     case INTERSECTION: 
/* 276 */       switch (pft2) {
/*     */       case EVEN_ODD: 
/*     */       case NON_ZERO: 
/* 279 */         return this.windCnt2 != 0;
/*     */       case POSITIVE: 
/* 281 */         return this.windCnt2 > 0;
/*     */       }
/* 283 */       return this.windCnt2 < 0;
/*     */     
/*     */     case UNION: 
/* 286 */       switch (pft2) {
/*     */       case EVEN_ODD: 
/*     */       case NON_ZERO: 
/* 289 */         return this.windCnt2 == 0;
/*     */       case POSITIVE: 
/* 291 */         return this.windCnt2 <= 0;
/*     */       }
/* 293 */       return this.windCnt2 >= 0;
/*     */     
/*     */     case DIFFERENCE: 
/* 296 */       if (this.polyTyp == Clipper.PolyType.SUBJECT) {
/* 297 */         switch (pft2) {
/*     */         case EVEN_ODD: 
/*     */         case NON_ZERO: 
/* 300 */           return this.windCnt2 == 0;
/*     */         case POSITIVE: 
/* 302 */           return this.windCnt2 <= 0;
/*     */         }
/* 304 */         return this.windCnt2 >= 0;
/*     */       }
/*     */       
/*     */ 
/* 308 */       switch (pft2) {
/*     */       case EVEN_ODD: 
/*     */       case NON_ZERO: 
/* 311 */         return this.windCnt2 != 0;
/*     */       case POSITIVE: 
/* 313 */         return this.windCnt2 > 0;
/*     */       }
/* 315 */       return this.windCnt2 < 0;
/*     */     
/*     */ 
/*     */     case XOR: 
/* 319 */       if (this.windDelta == 0) {
/* 320 */         switch (pft2) {
/*     */         case EVEN_ODD: 
/*     */         case NON_ZERO: 
/* 323 */           return this.windCnt2 == 0;
/*     */         case POSITIVE: 
/* 325 */           return this.windCnt2 <= 0;
/*     */         }
/* 327 */         return this.windCnt2 >= 0;
/*     */       }
/*     */       
/*     */ 
/* 331 */       return true;
/*     */     }
/*     */     
/* 334 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isEvenOddAltFillType(Clipper.PolyFillType clipFillType, Clipper.PolyFillType subjFillType) {
/* 338 */     if (this.polyTyp == Clipper.PolyType.SUBJECT) {
/* 339 */       return clipFillType == Clipper.PolyFillType.EVEN_ODD;
/*     */     }
/*     */     
/* 342 */     return subjFillType == Clipper.PolyFillType.EVEN_ODD;
/*     */   }
/*     */   
/*     */   public boolean isEvenOddFillType(Clipper.PolyFillType clipFillType, Clipper.PolyFillType subjFillType)
/*     */   {
/* 347 */     if (this.polyTyp == Clipper.PolyType.SUBJECT) {
/* 348 */       return subjFillType == Clipper.PolyFillType.EVEN_ODD;
/*     */     }
/*     */     
/* 351 */     return clipFillType == Clipper.PolyFillType.EVEN_ODD;
/*     */   }
/*     */   
/*     */   public boolean isHorizontal()
/*     */   {
/* 356 */     return this.delta.getY() == 0L;
/*     */   }
/*     */   
/*     */   public boolean isIntermediate(double y) {
/* 360 */     return (this.top.getY() == y) && (this.nextInLML != null);
/*     */   }
/*     */   
/*     */   public boolean isMaxima(double Y) {
/* 364 */     return (this.top.getY() == Y) && (this.nextInLML == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reverseHorizontal()
/*     */   {
/* 371 */     long temp = this.top.getX();
/* 372 */     this.top.setX(Long.valueOf(this.bot.getX()));
/* 373 */     this.bot.setX(Long.valueOf(temp));
/*     */     
/* 375 */     temp = this.top.getZ();
/* 376 */     this.top.setZ(Long.valueOf(this.bot.getZ()));
/* 377 */     this.bot.setZ(Long.valueOf(temp));
/*     */   }
/*     */   
/*     */   public void setBot(Point.LongPoint bot)
/*     */   {
/* 382 */     this.bot.set(bot);
/*     */   }
/*     */   
/*     */   public void setCurrent(Point.LongPoint current) {
/* 386 */     this.current.set(current);
/*     */   }
/*     */   
/*     */   public void setTop(Point.LongPoint top) {
/* 390 */     this.top.set(top);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 395 */     return "TEdge [Bot=" + this.bot + ", Curr=" + this.current + ", Top=" + this.top + ", Delta=" + this.delta + ", Dx=" + this.deltaX + ", PolyTyp=" + this.polyTyp + ", Side=" + this.side + ", WindDelta=" + this.windDelta + ", WindCnt=" + this.windCnt + ", WindCnt2=" + this.windCnt2 + ", OutIdx=" + this.outIdx + ", Next=" + this.next + ", Prev=" + this.prev + ", NextInLML=" + this.nextInLML + ", NextInAEL=" + this.nextInAEL + ", PrevInAEL=" + this.prevInAEL + ", NextInSEL=" + this.nextInSEL + ", PrevInSEL=" + this.prevInSEL + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateDeltaX()
/*     */   {
/* 403 */     this.delta.setX(Long.valueOf(this.top.getX() - this.bot.getX()));
/* 404 */     this.delta.setY(Long.valueOf(this.top.getY() - this.bot.getY()));
/* 405 */     if (this.delta.getY() == 0L) {
/* 406 */       this.deltaX = -3.4E38D;
/*     */     }
/*     */     else {
/* 409 */       this.deltaX = (this.delta.getX() / this.delta.getY());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/Edge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */