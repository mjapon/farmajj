/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.AccessibleElementId;
/*      */ import com.itextpdf.text.Chunk;
/*      */ import com.itextpdf.text.DocumentException;
/*      */ import com.itextpdf.text.Element;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.Image;
/*      */ import com.itextpdf.text.Phrase;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.pdf.events.PdfPCellEventForwarder;
/*      */ import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfPCell
/*      */   extends Rectangle
/*      */   implements IAccessibleElement
/*      */ {
/*   61 */   private ColumnText column = new ColumnText(null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   66 */   private int verticalAlignment = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   71 */   private float paddingLeft = 2.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   76 */   private float paddingRight = 2.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   81 */   private float paddingTop = 2.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   86 */   private float paddingBottom = 2.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   91 */   private float fixedHeight = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   96 */   private float calculatedHeight = 0.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private float minimumHeight;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private float cachedMaxHeight;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  112 */   private boolean noWrap = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PdfPTable table;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  122 */   private int colspan = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  129 */   private int rowspan = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Image image;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PdfPCellEvent cellEvent;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  144 */   private boolean useDescender = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  149 */   private boolean useBorderPadding = false;
/*      */   
/*      */ 
/*      */ 
/*      */   protected Phrase phrase;
/*      */   
/*      */ 
/*      */ 
/*      */   private int rotation;
/*      */   
/*      */ 
/*      */ 
/*  161 */   protected PdfName role = PdfName.TD;
/*  162 */   protected HashMap<PdfName, PdfObject> accessibleAttributes = null;
/*  163 */   protected AccessibleElementId id = new AccessibleElementId();
/*      */   
/*  165 */   protected ArrayList<PdfPHeaderCell> headers = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public PdfPCell()
/*      */   {
/*  171 */     super(0.0F, 0.0F, 0.0F, 0.0F);
/*  172 */     this.borderWidth = 0.5F;
/*  173 */     this.border = 15;
/*  174 */     this.column.setLeading(0.0F, 1.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell(Phrase phrase)
/*      */   {
/*  184 */     super(0.0F, 0.0F, 0.0F, 0.0F);
/*  185 */     this.borderWidth = 0.5F;
/*  186 */     this.border = 15;
/*  187 */     this.column.addText(this.phrase = phrase);
/*  188 */     this.column.setLeading(0.0F, 1.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell(Image image)
/*      */   {
/*  198 */     this(image, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell(Image image, boolean fit)
/*      */   {
/*  209 */     super(0.0F, 0.0F, 0.0F, 0.0F);
/*  210 */     this.borderWidth = 0.5F;
/*  211 */     this.border = 15;
/*  212 */     this.column.setLeading(0.0F, 1.0F);
/*  213 */     if (fit) {
/*  214 */       this.image = image;
/*  215 */       setPadding(this.borderWidth / 2.0F);
/*      */     } else {
/*  217 */       image.setScaleToFitLineWhenOverflow(false);
/*  218 */       this.column.addText(this.phrase = new Phrase(new Chunk(image, 0.0F, 0.0F, true)));
/*  219 */       setPadding(0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell(PdfPTable table)
/*      */   {
/*  230 */     this(table, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell(PdfPTable table, PdfPCell style)
/*      */   {
/*  243 */     super(0.0F, 0.0F, 0.0F, 0.0F);
/*  244 */     this.borderWidth = 0.5F;
/*  245 */     this.border = 15;
/*  246 */     this.column.setLeading(0.0F, 1.0F);
/*  247 */     this.table = table;
/*  248 */     table.setWidthPercentage(100.0F);
/*  249 */     table.setExtendLastRow(true);
/*  250 */     this.column.addElement(table);
/*  251 */     if (style != null) {
/*  252 */       cloneNonPositionParameters(style);
/*  253 */       this.verticalAlignment = style.verticalAlignment;
/*  254 */       this.paddingLeft = style.paddingLeft;
/*  255 */       this.paddingRight = style.paddingRight;
/*  256 */       this.paddingTop = style.paddingTop;
/*  257 */       this.paddingBottom = style.paddingBottom;
/*  258 */       this.colspan = style.colspan;
/*  259 */       this.rowspan = style.rowspan;
/*  260 */       this.cellEvent = style.cellEvent;
/*  261 */       this.useDescender = style.useDescender;
/*  262 */       this.useBorderPadding = style.useBorderPadding;
/*  263 */       this.rotation = style.rotation;
/*      */     } else {
/*  265 */       setPadding(0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCell(PdfPCell cell)
/*      */   {
/*  275 */     super(cell.llx, cell.lly, cell.urx, cell.ury);
/*  276 */     cloneNonPositionParameters(cell);
/*  277 */     this.verticalAlignment = cell.verticalAlignment;
/*  278 */     this.paddingLeft = cell.paddingLeft;
/*  279 */     this.paddingRight = cell.paddingRight;
/*  280 */     this.paddingTop = cell.paddingTop;
/*  281 */     this.paddingBottom = cell.paddingBottom;
/*  282 */     this.phrase = cell.phrase;
/*  283 */     this.fixedHeight = cell.fixedHeight;
/*  284 */     this.minimumHeight = cell.minimumHeight;
/*  285 */     this.noWrap = cell.noWrap;
/*  286 */     this.colspan = cell.colspan;
/*  287 */     this.rowspan = cell.rowspan;
/*  288 */     if (cell.table != null) {
/*  289 */       this.table = new PdfPTable(cell.table);
/*      */     }
/*  291 */     this.image = Image.getInstance(cell.image);
/*  292 */     this.cellEvent = cell.cellEvent;
/*  293 */     this.useDescender = cell.useDescender;
/*  294 */     this.column = ColumnText.duplicate(cell.column);
/*  295 */     this.useBorderPadding = cell.useBorderPadding;
/*  296 */     this.rotation = cell.rotation;
/*  297 */     this.id = cell.id;
/*  298 */     this.role = cell.role;
/*  299 */     if (cell.accessibleAttributes != null) {
/*  300 */       this.accessibleAttributes = new HashMap(cell.accessibleAttributes);
/*      */     }
/*  302 */     this.headers = cell.headers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addElement(Element element)
/*      */   {
/*  311 */     if (this.table != null) {
/*  312 */       this.table = null;
/*  313 */       this.column.setText(null);
/*      */     }
/*  315 */     if ((element instanceof PdfPTable)) {
/*  316 */       ((PdfPTable)element).setSplitLate(false);
/*  317 */     } else if ((element instanceof PdfDiv)) {
/*  318 */       for (Element divChildElement : ((PdfDiv)element).getContent()) {
/*  319 */         if ((divChildElement instanceof PdfPTable)) {
/*  320 */           ((PdfPTable)divChildElement).setSplitLate(false);
/*      */         }
/*      */       }
/*      */     }
/*  324 */     this.column.addElement(element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Phrase getPhrase()
/*      */   {
/*  333 */     return this.phrase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPhrase(Phrase phrase)
/*      */   {
/*  342 */     this.table = null;
/*  343 */     this.image = null;
/*  344 */     this.column.setText(this.phrase = phrase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHorizontalAlignment()
/*      */   {
/*  353 */     return this.column.getAlignment();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHorizontalAlignment(int horizontalAlignment)
/*      */   {
/*  363 */     this.column.setAlignment(horizontalAlignment);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getVerticalAlignment()
/*      */   {
/*  372 */     return this.verticalAlignment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVerticalAlignment(int verticalAlignment)
/*      */   {
/*  382 */     if (this.table != null) {
/*  383 */       this.table.setExtendLastRow(verticalAlignment == 4);
/*      */     }
/*  385 */     this.verticalAlignment = verticalAlignment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getEffectivePaddingLeft()
/*      */   {
/*  395 */     if (isUseBorderPadding()) {
/*  396 */       float border = getBorderWidthLeft() / (isUseVariableBorders() ? 1.0F : 2.0F);
/*  397 */       return this.paddingLeft + border;
/*      */     }
/*  399 */     return this.paddingLeft;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public float getPaddingLeft()
/*      */   {
/*  406 */     return this.paddingLeft;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPaddingLeft(float paddingLeft)
/*      */   {
/*  415 */     this.paddingLeft = paddingLeft;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getEffectivePaddingRight()
/*      */   {
/*  425 */     if (isUseBorderPadding()) {
/*  426 */       float border = getBorderWidthRight() / (isUseVariableBorders() ? 1.0F : 2.0F);
/*  427 */       return this.paddingRight + border;
/*      */     }
/*  429 */     return this.paddingRight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getPaddingRight()
/*      */   {
/*  438 */     return this.paddingRight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPaddingRight(float paddingRight)
/*      */   {
/*  447 */     this.paddingRight = paddingRight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getEffectivePaddingTop()
/*      */   {
/*  457 */     if (isUseBorderPadding()) {
/*  458 */       float border = getBorderWidthTop() / (isUseVariableBorders() ? 1.0F : 2.0F);
/*  459 */       return this.paddingTop + border;
/*      */     }
/*  461 */     return this.paddingTop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getPaddingTop()
/*      */   {
/*  470 */     return this.paddingTop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPaddingTop(float paddingTop)
/*      */   {
/*  479 */     this.paddingTop = paddingTop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getEffectivePaddingBottom()
/*      */   {
/*  489 */     if (isUseBorderPadding()) {
/*  490 */       float border = getBorderWidthBottom() / (isUseVariableBorders() ? 1.0F : 2.0F);
/*  491 */       return this.paddingBottom + border;
/*      */     }
/*  493 */     return this.paddingBottom;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getPaddingBottom()
/*      */   {
/*  502 */     return this.paddingBottom;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPaddingBottom(float paddingBottom)
/*      */   {
/*  511 */     this.paddingBottom = paddingBottom;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPadding(float padding)
/*      */   {
/*  521 */     this.paddingBottom = padding;
/*  522 */     this.paddingTop = padding;
/*  523 */     this.paddingLeft = padding;
/*  524 */     this.paddingRight = padding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseBorderPadding()
/*      */   {
/*  533 */     return this.useBorderPadding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseBorderPadding(boolean use)
/*      */   {
/*  542 */     this.useBorderPadding = use;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeading(float fixedLeading, float multipliedLeading)
/*      */   {
/*  554 */     this.column.setLeading(fixedLeading, multipliedLeading);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getLeading()
/*      */   {
/*  563 */     return this.column.getLeading();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getMultipliedLeading()
/*      */   {
/*  572 */     return this.column.getMultipliedLeading();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndent(float indent)
/*      */   {
/*  581 */     this.column.setIndent(indent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getIndent()
/*      */   {
/*  590 */     return this.column.getIndent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getExtraParagraphSpace()
/*      */   {
/*  599 */     return this.column.getExtraParagraphSpace();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExtraParagraphSpace(float extraParagraphSpace)
/*      */   {
/*  608 */     this.column.setExtraParagraphSpace(extraParagraphSpace);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCalculatedHeight(float calculatedHeight)
/*      */   {
/*  617 */     this.calculatedHeight = calculatedHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getCalculatedHeight()
/*      */   {
/*  626 */     return this.calculatedHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasCalculatedHeight()
/*      */   {
/*  635 */     return getCalculatedHeight() > 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFixedHeight(float fixedHeight)
/*      */   {
/*  645 */     this.fixedHeight = fixedHeight;
/*  646 */     this.minimumHeight = 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFixedHeight()
/*      */   {
/*  655 */     return this.fixedHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasFixedHeight()
/*      */   {
/*  665 */     return getFixedHeight() > 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getCachedMaxHeight()
/*      */   {
/*  674 */     return this.cachedMaxHeight;
/*      */   }
/*      */   
/*      */   public boolean hasCachedMaxHeight() {
/*  678 */     return this.cachedMaxHeight > 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMinimumHeight(float minimumHeight)
/*      */   {
/*  688 */     this.minimumHeight = minimumHeight;
/*  689 */     this.fixedHeight = 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getMinimumHeight()
/*      */   {
/*  698 */     return this.minimumHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasMinimumHeight()
/*      */   {
/*  708 */     return getMinimumHeight() > 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNoWrap()
/*      */   {
/*  717 */     return this.noWrap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoWrap(boolean noWrap)
/*      */   {
/*  726 */     this.noWrap = noWrap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPTable getTable()
/*      */   {
/*  736 */     return this.table;
/*      */   }
/*      */   
/*      */   void setTable(PdfPTable table) {
/*  740 */     this.table = table;
/*  741 */     this.column.setText(null);
/*  742 */     this.image = null;
/*  743 */     if (table != null) {
/*  744 */       table.setExtendLastRow(this.verticalAlignment == 4);
/*  745 */       this.column.addElement(table);
/*  746 */       table.setWidthPercentage(100.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColspan()
/*      */   {
/*  756 */     return this.colspan;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColspan(int colspan)
/*      */   {
/*  765 */     this.colspan = colspan;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRowspan()
/*      */   {
/*  775 */     return this.rowspan;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRowspan(int rowspan)
/*      */   {
/*  785 */     this.rowspan = rowspan;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFollowingIndent(float indent)
/*      */   {
/*  794 */     this.column.setFollowingIndent(indent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFollowingIndent()
/*      */   {
/*  803 */     return this.column.getFollowingIndent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRightIndent(float indent)
/*      */   {
/*  812 */     this.column.setRightIndent(indent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getRightIndent()
/*      */   {
/*  821 */     return this.column.getRightIndent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getSpaceCharRatio()
/*      */   {
/*  830 */     return this.column.getSpaceCharRatio();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpaceCharRatio(float spaceCharRatio)
/*      */   {
/*  844 */     this.column.setSpaceCharRatio(spaceCharRatio);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunDirection(int runDirection)
/*      */   {
/*  855 */     this.column.setRunDirection(runDirection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRunDirection()
/*      */   {
/*  866 */     return this.column.getRunDirection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getImage()
/*      */   {
/*  875 */     return this.image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(Image image)
/*      */   {
/*  884 */     this.column.setText(null);
/*  885 */     this.table = null;
/*  886 */     this.image = image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfPCellEvent getCellEvent()
/*      */   {
/*  895 */     return this.cellEvent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCellEvent(PdfPCellEvent cellEvent)
/*      */   {
/*  904 */     if (cellEvent == null) {
/*  905 */       this.cellEvent = null;
/*  906 */     } else if (this.cellEvent == null) {
/*  907 */       this.cellEvent = cellEvent;
/*  908 */     } else if ((this.cellEvent instanceof PdfPCellEventForwarder)) {
/*  909 */       ((PdfPCellEventForwarder)this.cellEvent).addCellEvent(cellEvent);
/*      */     } else {
/*  911 */       PdfPCellEventForwarder forward = new PdfPCellEventForwarder();
/*  912 */       forward.addCellEvent(this.cellEvent);
/*  913 */       forward.addCellEvent(cellEvent);
/*  914 */       this.cellEvent = forward;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getArabicOptions()
/*      */   {
/*  924 */     return this.column.getArabicOptions();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArabicOptions(int arabicOptions)
/*      */   {
/*  934 */     this.column.setArabicOptions(arabicOptions);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseAscender()
/*      */   {
/*  943 */     return this.column.isUseAscender();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseAscender(boolean useAscender)
/*      */   {
/*  952 */     this.column.setUseAscender(useAscender);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseDescender()
/*      */   {
/*  961 */     return this.useDescender;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseDescender(boolean useDescender)
/*      */   {
/*  970 */     this.useDescender = useDescender;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ColumnText getColumn()
/*      */   {
/*  979 */     return this.column;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<Element> getCompositeElements()
/*      */   {
/*  989 */     return getColumn().compositeElements;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumn(ColumnText column)
/*      */   {
/*  998 */     this.column = column;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRotation()
/*      */   {
/* 1008 */     return this.rotation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRotation(int rotation)
/*      */   {
/* 1017 */     rotation %= 360;
/* 1018 */     if (rotation < 0) {
/* 1019 */       rotation += 360;
/*      */     }
/* 1021 */     if (rotation % 90 != 0) {
/* 1022 */       throw new IllegalArgumentException(MessageLocalization.getComposedMessage("rotation.must.be.a.multiple.of.90", new Object[0]));
/*      */     }
/* 1024 */     this.rotation = rotation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getMaxHeight()
/*      */   {
/* 1034 */     boolean pivoted = (getRotation() == 90) || (getRotation() == 270);
/* 1035 */     Image img = getImage();
/* 1036 */     if (img != null) {
/* 1037 */       img.scalePercent(100.0F);
/* 1038 */       float refWidth = pivoted ? img.getScaledHeight() : img.getScaledWidth();
/*      */       
/* 1040 */       float scale = (getRight() - getEffectivePaddingRight() - getEffectivePaddingLeft() - getLeft()) / refWidth;
/* 1041 */       img.scalePercent(scale * 100.0F);
/* 1042 */       float refHeight = pivoted ? img.getScaledWidth() : img.getScaledHeight();
/* 1043 */       setBottom(getTop() - getEffectivePaddingTop() - getEffectivePaddingBottom() - refHeight);
/*      */     }
/* 1045 */     else if (((pivoted) && (hasFixedHeight())) || (getColumn() == null)) {
/* 1046 */       setBottom(getTop() - getFixedHeight());
/*      */     } else {
/* 1048 */       ColumnText ct = ColumnText.duplicate(getColumn());
/*      */       float bottom;
/* 1050 */       float right; float top; float left; float bottom; if (pivoted) {
/* 1051 */         float right = 20000.0F;
/* 1052 */         float top = getRight() - getEffectivePaddingRight();
/* 1053 */         float left = 0.0F;
/* 1054 */         bottom = getLeft() + getEffectivePaddingLeft();
/*      */       } else {
/* 1056 */         right = isNoWrap() ? 20000.0F : getRight() - getEffectivePaddingRight();
/* 1057 */         top = getTop() - getEffectivePaddingTop();
/* 1058 */         left = getLeft() + getEffectivePaddingLeft();
/* 1059 */         bottom = hasCalculatedHeight() ? getTop() + getEffectivePaddingBottom() - getCalculatedHeight() : -1.07374182E9F;
/*      */       }
/* 1061 */       PdfPRow.setColumn(ct, left, bottom, right, top);
/*      */       try {
/* 1063 */         ct.go(true);
/*      */       } catch (DocumentException e) {
/* 1065 */         throw new ExceptionConverter(e);
/*      */       }
/* 1067 */       if (pivoted) {
/* 1068 */         setBottom(getTop() - getEffectivePaddingTop() - getEffectivePaddingBottom() - ct.getFilledWidth());
/*      */       } else {
/* 1070 */         float yLine = ct.getYLine();
/* 1071 */         if (isUseDescender()) {
/* 1072 */           yLine += ct.getDescender();
/*      */         }
/* 1074 */         setBottom(yLine - getEffectivePaddingBottom());
/*      */       }
/*      */     }
/*      */     
/* 1078 */     float height = getHeight();
/* 1079 */     if (height == getEffectivePaddingTop() + getEffectivePaddingBottom()) {
/* 1080 */       height = 0.0F;
/*      */     }
/* 1082 */     if (hasFixedHeight()) {
/* 1083 */       height = getFixedHeight();
/* 1084 */     } else if ((hasMinimumHeight()) && (height < getMinimumHeight())) {
/* 1085 */       height = getMinimumHeight();
/*      */     }
/* 1087 */     this.cachedMaxHeight = height;
/* 1088 */     return height;
/*      */   }
/*      */   
/*      */   public PdfObject getAccessibleAttribute(PdfName key) {
/* 1092 */     if (this.accessibleAttributes != null) {
/* 1093 */       return (PdfObject)this.accessibleAttributes.get(key);
/*      */     }
/* 1095 */     return null;
/*      */   }
/*      */   
/*      */   public void setAccessibleAttribute(PdfName key, PdfObject value)
/*      */   {
/* 1100 */     if (this.accessibleAttributes == null) {
/* 1101 */       this.accessibleAttributes = new HashMap();
/*      */     }
/* 1103 */     this.accessibleAttributes.put(key, value);
/*      */   }
/*      */   
/*      */   public HashMap<PdfName, PdfObject> getAccessibleAttributes() {
/* 1107 */     return this.accessibleAttributes;
/*      */   }
/*      */   
/*      */   public PdfName getRole() {
/* 1111 */     return this.role;
/*      */   }
/*      */   
/*      */   public void setRole(PdfName role) {
/* 1115 */     this.role = role;
/*      */   }
/*      */   
/*      */   public AccessibleElementId getId() {
/* 1119 */     return this.id;
/*      */   }
/*      */   
/*      */   public void setId(AccessibleElementId id) {
/* 1123 */     this.id = id;
/*      */   }
/*      */   
/*      */   public boolean isInline() {
/* 1127 */     return false;
/*      */   }
/*      */   
/*      */   public void addHeader(PdfPHeaderCell header) {
/* 1131 */     if (this.headers == null) {
/* 1132 */       this.headers = new ArrayList();
/*      */     }
/* 1134 */     this.headers.add(header);
/*      */   }
/*      */   
/*      */   public ArrayList<PdfPHeaderCell> getHeaders() {
/* 1138 */     return this.headers;
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfPCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */