/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import com.itextpdf.text.DocWriter;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.ExceptionConverter;
/*     */ import com.itextpdf.text.Image;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.error_messages.MessageLocalization;
/*     */ import com.itextpdf.text.pdf.collection.PdfCollection;
/*     */ import com.itextpdf.text.pdf.interfaces.PdfEncryptionSettings;
/*     */ import com.itextpdf.text.pdf.interfaces.PdfViewerPreferences;
/*     */ import com.itextpdf.text.pdf.security.LtvVerification;
/*     */ import com.itextpdf.text.xml.xmp.XmpWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfStamper
/*     */   implements PdfViewerPreferences, PdfEncryptionSettings
/*     */ {
/*     */   protected PdfStamperImp stamper;
/*     */   private Map<String, String> moreInfo;
/*     */   protected boolean hasSignature;
/*     */   protected PdfSignatureAppearance sigApp;
/*     */   protected XmlSignatureAppearance sigXmlApp;
/*     */   private LtvVerification verification;
/*     */   
/*     */   public PdfStamper(PdfReader reader, OutputStream os)
/*     */     throws DocumentException, IOException
/*     */   {
/*  99 */     this.stamper = new PdfStamperImp(reader, os, '\000', false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStamper(PdfReader reader, OutputStream os, char pdfVersion)
/*     */     throws DocumentException, IOException
/*     */   {
/* 115 */     this.stamper = new PdfStamperImp(reader, os, pdfVersion, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStamper(PdfReader reader, OutputStream os, char pdfVersion, boolean append)
/*     */     throws DocumentException, IOException
/*     */   {
/* 133 */     this.stamper = new PdfStamperImp(reader, os, pdfVersion, append);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getMoreInfo()
/*     */   {
/* 142 */     return this.moreInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMoreInfo(Map<String, String> moreInfo)
/*     */   {
/* 152 */     this.moreInfo = moreInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replacePage(PdfReader r, int pageImported, int pageReplaced)
/*     */   {
/* 165 */     this.stamper.replacePage(r, pageImported, pageReplaced);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertPage(int pageNumber, Rectangle mediabox)
/*     */   {
/* 176 */     this.stamper.insertPage(pageNumber, mediabox);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfSignatureAppearance getSignatureAppearance()
/*     */   {
/* 184 */     return this.sigApp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XmlSignatureAppearance getXmlSignatureAppearance()
/*     */   {
/* 192 */     return this.sigXmlApp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */     try
/*     */     {
/* 208 */       this.stamper.alterContents();
/* 209 */       this.stamper.pagesToContent.clear();
/*     */     } catch (IOException e) {
/* 211 */       throw new ExceptionConverter(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws DocumentException, IOException
/*     */   {
/* 227 */     if (this.stamper.closed)
/* 228 */       return;
/* 229 */     if (!this.hasSignature) {
/* 230 */       mergeVerification();
/* 231 */       this.stamper.close(this.moreInfo);
/*     */     }
/*     */     else {
/* 234 */       throw new DocumentException("Signature defined. Must be closed in PdfSignatureAppearance.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfContentByte getUnderContent(int pageNum)
/*     */   {
/* 245 */     return this.stamper.getUnderContent(pageNum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfContentByte getOverContent(int pageNum)
/*     */   {
/* 255 */     return this.stamper.getOverContent(pageNum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRotateContents()
/*     */   {
/* 263 */     return this.stamper.isRotateContents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRotateContents(boolean rotateContents)
/*     */   {
/* 272 */     this.stamper.setRotateContents(rotateContents);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncryption(byte[] userPassword, byte[] ownerPassword, int permissions, boolean strength128Bits)
/*     */     throws DocumentException
/*     */   {
/* 288 */     if (this.stamper.isAppend())
/* 289 */       throw new DocumentException(MessageLocalization.getComposedMessage("append.mode.does.not.support.changing.the.encryption.status", new Object[0]));
/* 290 */     if (this.stamper.isContentWritten())
/* 291 */       throw new DocumentException(MessageLocalization.getComposedMessage("content.was.already.written.to.the.output", new Object[0]));
/* 292 */     this.stamper.setEncryption(userPassword, ownerPassword, permissions, strength128Bits ? 1 : 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncryption(byte[] userPassword, byte[] ownerPassword, int permissions, int encryptionType)
/*     */     throws DocumentException
/*     */   {
/* 309 */     if (this.stamper.isAppend())
/* 310 */       throw new DocumentException(MessageLocalization.getComposedMessage("append.mode.does.not.support.changing.the.encryption.status", new Object[0]));
/* 311 */     if (this.stamper.isContentWritten())
/* 312 */       throw new DocumentException(MessageLocalization.getComposedMessage("content.was.already.written.to.the.output", new Object[0]));
/* 313 */     this.stamper.setEncryption(userPassword, ownerPassword, permissions, encryptionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncryption(boolean strength, String userPassword, String ownerPassword, int permissions)
/*     */     throws DocumentException
/*     */   {
/* 330 */     setEncryption(DocWriter.getISOBytes(userPassword), DocWriter.getISOBytes(ownerPassword), permissions, strength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncryption(int encryptionType, String userPassword, String ownerPassword, int permissions)
/*     */     throws DocumentException
/*     */   {
/* 348 */     setEncryption(DocWriter.getISOBytes(userPassword), DocWriter.getISOBytes(ownerPassword), permissions, encryptionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncryption(Certificate[] certs, int[] permissions, int encryptionType)
/*     */     throws DocumentException
/*     */   {
/* 365 */     if (this.stamper.isAppend())
/* 366 */       throw new DocumentException(MessageLocalization.getComposedMessage("append.mode.does.not.support.changing.the.encryption.status", new Object[0]));
/* 367 */     if (this.stamper.isContentWritten())
/* 368 */       throw new DocumentException(MessageLocalization.getComposedMessage("content.was.already.written.to.the.output", new Object[0]));
/* 369 */     this.stamper.setEncryption(certs, permissions, encryptionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfImportedPage getImportedPage(PdfReader reader, int pageNumber)
/*     */   {
/* 379 */     return this.stamper.getImportedPage(reader, pageNumber);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PdfWriter getWriter()
/*     */   {
/* 386 */     return this.stamper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PdfReader getReader()
/*     */   {
/* 393 */     return this.stamper.reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AcroFields getAcroFields()
/*     */   {
/* 401 */     return this.stamper.getAcroFields();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormFlattening(boolean flat)
/*     */   {
/* 410 */     this.stamper.setFormFlattening(flat);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFreeTextFlattening(boolean flat)
/*     */   {
/* 418 */     this.stamper.setFreeTextFlattening(flat);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAnnotationFlattening(boolean flat)
/*     */   {
/* 427 */     this.stamper.setFlatAnnotations(flat);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAnnotation(PdfAnnotation annot, int page)
/*     */   {
/* 437 */     this.stamper.addAnnotation(annot, page);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfFormField addSignature(String name, int page, float llx, float lly, float urx, float ury)
/*     */   {
/* 452 */     PdfAcroForm acroForm = this.stamper.getAcroForm();
/* 453 */     PdfFormField signature = PdfFormField.createSignature(this.stamper);
/* 454 */     acroForm.setSignatureParams(signature, name, llx, lly, urx, ury);
/* 455 */     acroForm.drawSignatureAppearences(signature, llx, lly, urx, ury);
/* 456 */     addAnnotation(signature, page);
/* 457 */     return signature;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addComments(FdfReader fdf)
/*     */     throws IOException
/*     */   {
/* 466 */     this.stamper.addComments(fdf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutlines(List<HashMap<String, Object>> outlines)
/*     */   {
/* 475 */     this.stamper.setOutlines(outlines);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThumbnail(Image image, int page)
/*     */     throws PdfException, DocumentException
/*     */   {
/* 486 */     this.stamper.setThumbnail(image, page);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean partialFormFlattening(String name)
/*     */   {
/* 500 */     return this.stamper.partialFormFlattening(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addJavaScript(String js)
/*     */   {
/* 508 */     this.stamper.addJavaScript(js, !PdfEncodings.isPdfDocEncoding(js));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addJavaScript(String name, String js)
/*     */   {
/* 517 */     this.stamper.addJavaScript(name, PdfAction.javaScript(js, this.stamper, !PdfEncodings.isPdfDocEncoding(js)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFileAttachment(String description, byte[] fileStore, String file, String fileDisplay)
/*     */     throws IOException
/*     */   {
/* 530 */     addFileAttachment(description, PdfFileSpecification.fileEmbedded(this.stamper, file, fileDisplay, fileStore));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFileAttachment(String description, PdfFileSpecification fs)
/*     */     throws IOException
/*     */   {
/* 539 */     this.stamper.addFileAttachment(description, fs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void makePackage(PdfName initialView)
/*     */   {
/* 556 */     PdfCollection collection = new PdfCollection(0);
/* 557 */     collection.put(PdfName.VIEW, initialView);
/* 558 */     this.stamper.makePackage(collection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void makePackage(PdfCollection collection)
/*     */   {
/* 566 */     this.stamper.makePackage(collection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewerPreferences(int preferences)
/*     */   {
/* 575 */     this.stamper.setViewerPreferences(preferences);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addViewerPreference(PdfName key, PdfObject value)
/*     */   {
/* 585 */     this.stamper.addViewerPreference(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXmpMetadata(byte[] xmp)
/*     */   {
/* 594 */     this.stamper.setXmpMetadata(xmp);
/*     */   }
/*     */   
/*     */   public void createXmpMetadata() {
/* 598 */     this.stamper.createXmpMetadata();
/*     */   }
/*     */   
/*     */   public XmpWriter getXmpWriter() {
/* 602 */     return this.stamper.getXmpWriter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFullCompression()
/*     */   {
/* 610 */     return this.stamper.isFullCompression();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFullCompression()
/*     */     throws DocumentException
/*     */   {
/* 619 */     if (this.stamper.isAppend())
/* 620 */       return;
/* 621 */     this.stamper.fullCompression = true;
/* 622 */     this.stamper.setAtLeastPdfVersion('5');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPageAction(PdfName actionType, PdfAction action, int page)
/*     */     throws PdfException
/*     */   {
/* 634 */     this.stamper.setPageAction(actionType, action, page);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDuration(int seconds, int page)
/*     */   {
/* 643 */     this.stamper.setDuration(seconds, page);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransition(PdfTransition transition, int page)
/*     */   {
/* 652 */     this.stamper.setTransition(transition, page);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PdfStamper createSignature(PdfReader reader, OutputStream os, char pdfVersion, File tempFile, boolean append)
/*     */     throws DocumentException, IOException
/*     */   {
/*     */     PdfStamper stp;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 696 */     if (tempFile == null) {
/* 697 */       ByteBuffer bout = new ByteBuffer();
/* 698 */       PdfStamper stp = new PdfStamper(reader, bout, pdfVersion, append);
/* 699 */       stp.sigApp = new PdfSignatureAppearance(stp.stamper);
/* 700 */       stp.sigApp.setSigout(bout);
/*     */     }
/*     */     else {
/* 703 */       if (tempFile.isDirectory())
/* 704 */         tempFile = File.createTempFile("pdf", ".pdf", tempFile);
/* 705 */       FileOutputStream fout = new FileOutputStream(tempFile);
/* 706 */       stp = new PdfStamper(reader, fout, pdfVersion, append);
/* 707 */       stp.sigApp = new PdfSignatureAppearance(stp.stamper);
/* 708 */       stp.sigApp.setTempFile(tempFile);
/*     */     }
/* 710 */     stp.sigApp.setOriginalout(os);
/* 711 */     stp.sigApp.setStamper(stp);
/* 712 */     stp.hasSignature = true;
/* 713 */     PdfDictionary catalog = reader.getCatalog();
/* 714 */     PdfDictionary acroForm = (PdfDictionary)PdfReader.getPdfObject(catalog.get(PdfName.ACROFORM), catalog);
/* 715 */     if (acroForm != null) {
/* 716 */       acroForm.remove(PdfName.NEEDAPPEARANCES);
/* 717 */       stp.stamper.markUsed(acroForm);
/*     */     }
/* 719 */     return stp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PdfStamper createSignature(PdfReader reader, OutputStream os, char pdfVersion)
/*     */     throws DocumentException, IOException
/*     */   {
/* 756 */     return createSignature(reader, os, pdfVersion, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PdfStamper createSignature(PdfReader reader, OutputStream os, char pdfVersion, File tempFile)
/*     */     throws DocumentException, IOException
/*     */   {
/* 795 */     return createSignature(reader, os, pdfVersion, tempFile, false);
/*     */   }
/*     */   
/*     */   public static PdfStamper createXmlSignature(PdfReader reader, OutputStream os) throws IOException, DocumentException {
/* 799 */     PdfStamper stp = new PdfStamper(reader, os);
/* 800 */     stp.sigXmlApp = new XmlSignatureAppearance(stp.stamper);
/*     */     
/*     */ 
/* 803 */     stp.sigXmlApp.setStamper(stp);
/*     */     
/* 805 */     return stp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, PdfLayer> getPdfLayers()
/*     */   {
/* 815 */     return this.stamper.getPdfLayers();
/*     */   }
/*     */   
/*     */   public void markUsed(PdfObject obj) {
/* 819 */     this.stamper.markUsed(obj);
/*     */   }
/*     */   
/*     */   public LtvVerification getLtvVerification() {
/* 823 */     if (this.verification == null)
/* 824 */       this.verification = new LtvVerification(this);
/* 825 */     return this.verification;
/*     */   }
/*     */   
/*     */   public boolean addNamedDestination(String name, int page, PdfDestination dest) throws IOException {
/* 829 */     HashMap<Object, PdfObject> namedDestinations = this.stamper.getNamedDestinations();
/*     */     
/* 831 */     if (getReader().getNamedDestination().containsKey(name)) {
/* 832 */       return false;
/*     */     }
/* 834 */     PdfDestination d = new PdfDestination(dest);
/* 835 */     d.addPage(getReader().getPageOrigRef(page));
/* 836 */     namedDestinations.put(name, new PdfArray(d));
/* 837 */     return true;
/*     */   }
/*     */   
/*     */   void mergeVerification() throws IOException {
/* 841 */     if (this.verification == null)
/* 842 */       return;
/* 843 */     this.verification.merge();
/*     */   }
/*     */   
/*     */   protected PdfStamper() {}
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfStamper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */