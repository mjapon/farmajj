/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.BadElementException;
/*      */ import com.itextpdf.text.BaseColor;
/*      */ import com.itextpdf.text.pdf.codec.CCITTG4Encoder;
/*      */ import java.awt.Canvas;
/*      */ import java.awt.Color;
/*      */ import java.awt.image.MemoryImageSource;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BarcodeDatamatrix
/*      */ {
/*      */   public static final int DM_NO_ERROR = 0;
/*      */   public static final int DM_ERROR_TEXT_TOO_BIG = 1;
/*      */   public static final int DM_ERROR_INVALID_SQUARE = 3;
/*      */   public static final int DM_ERROR_EXTENSION = 5;
/*      */   public static final int DM_AUTO = 0;
/*      */   public static final int DM_ASCII = 1;
/*      */   public static final int DM_C40 = 2;
/*      */   public static final int DM_TEXT = 3;
/*      */   public static final int DM_B256 = 4;
/*      */   public static final int DM_X21 = 5;
/*      */   public static final int DM_EDIFACT = 6;
/*      */   public static final int DM_RAW = 7;
/*      */   public static final int DM_EXTENSION = 32;
/*      */   public static final int DM_TEST = 64;
/*  119 */   private static final DmParams[] dmSizes = { new DmParams(10, 10, 10, 10, 3, 3, 5), new DmParams(12, 12, 12, 12, 5, 5, 7), new DmParams(8, 18, 8, 18, 5, 5, 7), new DmParams(14, 14, 14, 14, 8, 8, 10), new DmParams(8, 32, 8, 16, 10, 10, 11), new DmParams(16, 16, 16, 16, 12, 12, 12), new DmParams(12, 26, 12, 26, 16, 16, 14), new DmParams(18, 18, 18, 18, 18, 18, 14), new DmParams(20, 20, 20, 20, 22, 22, 18), new DmParams(12, 36, 12, 18, 22, 22, 18), new DmParams(22, 22, 22, 22, 30, 30, 20), new DmParams(16, 36, 16, 18, 32, 32, 24), new DmParams(24, 24, 24, 24, 36, 36, 24), new DmParams(26, 26, 26, 26, 44, 44, 28), new DmParams(16, 48, 16, 24, 49, 49, 28), new DmParams(32, 32, 16, 16, 62, 62, 36), new DmParams(36, 36, 18, 18, 86, 86, 42), new DmParams(40, 40, 20, 20, 114, 114, 48), new DmParams(44, 44, 22, 22, 144, 144, 56), new DmParams(48, 48, 24, 24, 174, 174, 68), new DmParams(52, 52, 26, 26, 204, 102, 42), new DmParams(64, 64, 16, 16, 280, 140, 56), new DmParams(72, 72, 18, 18, 368, 92, 36), new DmParams(80, 80, 20, 20, 456, 114, 48), new DmParams(88, 88, 22, 22, 576, 144, 56), new DmParams(96, 96, 24, 24, 696, 174, 68), new DmParams(104, 104, 26, 26, 816, 136, 56), new DmParams(120, 120, 20, 20, 1050, 175, 68), new DmParams(132, 132, 22, 22, 1304, 163, 62), new DmParams(144, 144, 24, 24, 1558, 156, 62) };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String x12 = "\r*> 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int extOut;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private short[] place;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] image;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int height;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int width;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int ws;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int options;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setBit(int x, int y, int xByte)
/*      */   {
/*  167 */     int tmp12_11 = (y * xByte + x / 8); byte[] tmp12_1 = this.image;tmp12_1[tmp12_11] = ((byte)(tmp12_1[tmp12_11] | (byte)(128 >> (x & 0x7))));
/*      */   }
/*      */   
/*      */   private void draw(byte[] data, int dataSize, DmParams dm)
/*      */   {
/*  172 */     int xByte = (dm.width + this.ws * 2 + 7) / 8;
/*  173 */     Arrays.fill(this.image, (byte)0);
/*      */     
/*      */ 
/*  176 */     for (int i = this.ws; i < dm.height + this.ws; i += dm.heightSection) {
/*  177 */       for (int j = this.ws; j < dm.width + this.ws; j += 2) {
/*  178 */         setBit(j, i, xByte);
/*      */       }
/*      */     }
/*      */     
/*  182 */     for (i = dm.heightSection - 1 + this.ws; i < dm.height + this.ws; i += dm.heightSection) {
/*  183 */       for (int j = this.ws; j < dm.width + this.ws; j++) {
/*  184 */         setBit(j, i, xByte);
/*      */       }
/*      */     }
/*      */     
/*  188 */     for (i = this.ws; i < dm.width + this.ws; i += dm.widthSection) {
/*  189 */       for (int j = this.ws; j < dm.height + this.ws; j++) {
/*  190 */         setBit(i, j, xByte);
/*      */       }
/*      */     }
/*      */     
/*  194 */     for (i = dm.widthSection - 1 + this.ws; i < dm.width + this.ws; i += dm.widthSection) {
/*  195 */       for (int j = 1 + this.ws; j < dm.height + this.ws; j += 2) {
/*  196 */         setBit(i, j, xByte);
/*      */       }
/*      */     }
/*  199 */     int p = 0;
/*  200 */     for (int ys = 0; ys < dm.height; ys += dm.heightSection) {
/*  201 */       for (int y = 1; y < dm.heightSection - 1; y++) {
/*  202 */         for (int xs = 0; xs < dm.width; xs += dm.widthSection) {
/*  203 */           for (int x = 1; x < dm.widthSection - 1; x++) {
/*  204 */             int z = this.place[(p++)];
/*  205 */             if ((z == 1) || ((z > 1) && ((data[(z / 8 - 1)] & 0xFF & 128 >> z % 8) != 0))) {
/*  206 */               setBit(x + xs + this.ws, y + ys + this.ws, xByte);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static void makePadding(byte[] data, int position, int count) {
/*  215 */     if (count <= 0)
/*  216 */       return;
/*  217 */     data[(position++)] = -127;
/*  218 */     for (;;) { count--; if (count <= 0) break;
/*  219 */       int t = 129 + (position + 1) * 149 % 253 + 1;
/*  220 */       if (t > 254)
/*  221 */         t -= 254;
/*  222 */       data[(position++)] = ((byte)t);
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean isDigit(int c) {
/*  227 */     return (c >= 48) && (c <= 57);
/*      */   }
/*      */   
/*      */   private static int asciiEncodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength)
/*      */   {
/*  232 */     int ptrIn = textOffset;
/*  233 */     int ptrOut = dataOffset;
/*  234 */     textLength += textOffset;
/*  235 */     dataLength += dataOffset;
/*  236 */     while (ptrIn < textLength) {
/*  237 */       if (ptrOut >= dataLength)
/*  238 */         return -1;
/*  239 */       int c = text[(ptrIn++)] & 0xFF;
/*  240 */       if ((isDigit(c)) && (ptrIn < textLength) && (isDigit(text[ptrIn] & 0xFF))) {
/*  241 */         data[(ptrOut++)] = ((byte)((c - 48) * 10 + (text[(ptrIn++)] & 0xFF) - 48 + 130));
/*      */       }
/*  243 */       else if (c > 127) {
/*  244 */         if (ptrOut + 1 >= dataLength)
/*  245 */           return -1;
/*  246 */         data[(ptrOut++)] = -21;
/*  247 */         data[(ptrOut++)] = ((byte)(c - 128 + 1));
/*      */       }
/*      */       else {
/*  250 */         data[(ptrOut++)] = ((byte)(c + 1));
/*      */       }
/*      */     }
/*  253 */     return ptrOut - dataOffset;
/*      */   }
/*      */   
/*      */   private static int b256Encodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength)
/*      */   {
/*  258 */     if (textLength == 0)
/*  259 */       return 0;
/*  260 */     if ((textLength < 250) && (textLength + 2 > dataLength))
/*  261 */       return -1;
/*  262 */     if ((textLength >= 250) && (textLength + 3 > dataLength))
/*  263 */       return -1;
/*  264 */     data[dataOffset] = -25;
/*  265 */     int k; int k; if (textLength < 250) {
/*  266 */       data[(dataOffset + 1)] = ((byte)textLength);
/*  267 */       k = 2;
/*      */     }
/*      */     else {
/*  270 */       data[(dataOffset + 1)] = ((byte)(textLength / 250 + 249));
/*  271 */       data[(dataOffset + 2)] = ((byte)(textLength % 250));
/*  272 */       k = 3;
/*      */     }
/*  274 */     System.arraycopy(text, textOffset, data, k + dataOffset, textLength);
/*  275 */     k += textLength + dataOffset;
/*  276 */     for (int j = dataOffset + 1; j < k; j++) {
/*  277 */       int c = data[j] & 0xFF;
/*  278 */       int prn = 149 * (j + 1) % 255 + 1;
/*  279 */       int tv = c + prn;
/*  280 */       if (tv > 255)
/*  281 */         tv -= 256;
/*  282 */       data[j] = ((byte)tv);
/*      */     }
/*      */     
/*  285 */     return k - dataOffset;
/*      */   }
/*      */   
/*      */ 
/*      */   private static int X12Encodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength)
/*      */   {
/*  291 */     if (textLength == 0)
/*  292 */       return 0;
/*  293 */     int ptrIn = 0;
/*  294 */     int ptrOut = 0;
/*  295 */     byte[] x = new byte[textLength];
/*  296 */     int count = 0;
/*  297 */     for (; ptrIn < textLength; ptrIn++) {
/*  298 */       int i = "\r*> 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf((char)text[(ptrIn + textOffset)]);
/*  299 */       if (i >= 0) {
/*  300 */         x[ptrIn] = ((byte)i);
/*  301 */         count++;
/*      */       }
/*      */       else {
/*  304 */         x[ptrIn] = 100;
/*  305 */         if (count >= 6)
/*  306 */           count -= count / 3 * 3;
/*  307 */         for (int k = 0; k < count; k++)
/*  308 */           x[(ptrIn - k - 1)] = 100;
/*  309 */         count = 0;
/*      */       }
/*      */     }
/*  312 */     if (count >= 6)
/*  313 */       count -= count / 3 * 3;
/*  314 */     for (int k = 0; k < count; k++)
/*  315 */       x[(ptrIn - k - 1)] = 100;
/*  316 */     ptrIn = 0;
/*  317 */     byte c = 0;
/*  318 */     for (; ptrIn < textLength; ptrIn++) {
/*  319 */       c = x[ptrIn];
/*  320 */       if (ptrOut >= dataLength)
/*      */         break;
/*  322 */       if (c < 40) {
/*  323 */         if ((ptrIn == 0) || ((ptrIn > 0) && (x[(ptrIn - 1)] > 40)))
/*  324 */           data[(dataOffset + ptrOut++)] = -18;
/*  325 */         if (ptrOut + 2 > dataLength)
/*      */           break;
/*  327 */         int n = 1600 * x[ptrIn] + 40 * x[(ptrIn + 1)] + x[(ptrIn + 2)] + 1;
/*  328 */         data[(dataOffset + ptrOut++)] = ((byte)(n / 256));
/*  329 */         data[(dataOffset + ptrOut++)] = ((byte)n);
/*  330 */         ptrIn += 2;
/*      */       }
/*      */       else {
/*  333 */         if ((ptrIn > 0) && (x[(ptrIn - 1)] < 40))
/*  334 */           data[(dataOffset + ptrOut++)] = -2;
/*  335 */         int ci = text[(ptrIn + textOffset)] & 0xFF;
/*  336 */         if (ci > 127) {
/*  337 */           data[(dataOffset + ptrOut++)] = -21;
/*  338 */           ci -= 128;
/*      */         }
/*  340 */         if (ptrOut >= dataLength)
/*      */           break;
/*  342 */         data[(dataOffset + ptrOut++)] = ((byte)(ci + 1));
/*      */       }
/*      */     }
/*  345 */     c = 100;
/*  346 */     if (textLength > 0)
/*  347 */       c = x[(textLength - 1)];
/*  348 */     if ((ptrIn != textLength) || ((c < 40) && (ptrOut >= dataLength)))
/*  349 */       return -1;
/*  350 */     if (c < 40)
/*  351 */       data[(dataOffset + ptrOut++)] = -2;
/*  352 */     return ptrOut;
/*      */   }
/*      */   
/*      */   private static int EdifactEncodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength)
/*      */   {
/*  357 */     if (textLength == 0)
/*  358 */       return 0;
/*  359 */     int ptrIn = 0;
/*  360 */     int ptrOut = 0;
/*  361 */     int edi = 0;
/*  362 */     int pedi = 18;
/*  363 */     boolean ascii = true;
/*  364 */     for (; ptrIn < textLength; ptrIn++) {
/*  365 */       int c = text[(ptrIn + textOffset)] & 0xFF;
/*  366 */       if ((((c & 0xE0) == 64) || ((c & 0xE0) == 32)) && (c != 95)) {
/*  367 */         if (ascii) {
/*  368 */           if (ptrOut + 1 > dataLength)
/*      */             break;
/*  370 */           data[(dataOffset + ptrOut++)] = -16;
/*  371 */           ascii = false;
/*      */         }
/*  373 */         c &= 0x3F;
/*  374 */         edi |= c << pedi;
/*  375 */         if (pedi == 0) {
/*  376 */           if (ptrOut + 3 > dataLength)
/*      */             break;
/*  378 */           data[(dataOffset + ptrOut++)] = ((byte)(edi >> 16));
/*  379 */           data[(dataOffset + ptrOut++)] = ((byte)(edi >> 8));
/*  380 */           data[(dataOffset + ptrOut++)] = ((byte)edi);
/*  381 */           edi = 0;
/*  382 */           pedi = 18;
/*      */         }
/*      */         else {
/*  385 */           pedi -= 6;
/*      */         }
/*  387 */       } else { if (!ascii) {
/*  388 */           edi |= 31 << pedi;
/*  389 */           if (ptrOut + 3 - pedi / 8 > dataLength)
/*      */             break;
/*  391 */           data[(dataOffset + ptrOut++)] = ((byte)(edi >> 16));
/*  392 */           if (pedi <= 12)
/*  393 */             data[(dataOffset + ptrOut++)] = ((byte)(edi >> 8));
/*  394 */           if (pedi <= 6)
/*  395 */             data[(dataOffset + ptrOut++)] = ((byte)edi);
/*  396 */           ascii = true;
/*  397 */           pedi = 18;
/*  398 */           edi = 0;
/*      */         }
/*  400 */         if (c > 127) {
/*  401 */           if (ptrOut >= dataLength)
/*      */             break;
/*  403 */           data[(dataOffset + ptrOut++)] = -21;
/*  404 */           c -= 128;
/*      */         }
/*  406 */         if (ptrOut >= dataLength)
/*      */           break;
/*  408 */         data[(dataOffset + ptrOut++)] = ((byte)(c + 1));
/*      */       }
/*      */     }
/*  411 */     if (ptrIn != textLength)
/*  412 */       return -1;
/*  413 */     int dataSize = Integer.MAX_VALUE;
/*  414 */     for (int i = 0; i < dmSizes.length; i++) {
/*  415 */       if (dmSizes[i].dataSize >= dataOffset + ptrOut + (3 - pedi / 6)) {
/*  416 */         dataSize = dmSizes[i].dataSize;
/*  417 */         break;
/*      */       }
/*      */     }
/*      */     
/*  421 */     if ((dataSize - dataOffset - ptrOut <= 2) && (pedi >= 6))
/*      */     {
/*  423 */       if (pedi <= 12) {
/*  424 */         byte val = (byte)(edi >> 18 & 0x3F);
/*  425 */         if ((val & 0x20) == 0)
/*  426 */           val = (byte)(val | 0x40);
/*  427 */         data[(dataOffset + ptrOut++)] = ((byte)(val + 1));
/*      */       }
/*  429 */       if (pedi <= 6) {
/*  430 */         byte val = (byte)(edi >> 12 & 0x3F);
/*  431 */         if ((val & 0x20) == 0)
/*  432 */           val = (byte)(val | 0x40);
/*  433 */         data[(dataOffset + ptrOut++)] = ((byte)(val + 1));
/*      */       }
/*  435 */     } else if (!ascii) {
/*  436 */       edi |= 31 << pedi;
/*  437 */       if (ptrOut + 3 - pedi / 8 > dataLength)
/*  438 */         return -1;
/*  439 */       data[(dataOffset + ptrOut++)] = ((byte)(edi >> 16));
/*  440 */       if (pedi <= 12)
/*  441 */         data[(dataOffset + ptrOut++)] = ((byte)(edi >> 8));
/*  442 */       if (pedi <= 6)
/*  443 */         data[(dataOffset + ptrOut++)] = ((byte)edi);
/*      */     }
/*  445 */     return ptrOut;
/*      */   }
/*      */   
/*      */ 
/*      */   private static int C40OrTextEncodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength, boolean c40)
/*      */   {
/*  451 */     if (textLength == 0)
/*  452 */       return 0;
/*  453 */     int ptrIn = 0;
/*  454 */     int ptrOut = 0;
/*  455 */     if (c40) {
/*  456 */       data[(dataOffset + ptrOut++)] = -26;
/*      */     } else
/*  458 */       data[(dataOffset + ptrOut++)] = -17;
/*  459 */     String shift2 = "!\"#$%&'()*+,-./:;<=>?@[\\]^_";
/*  460 */     String shift3; String basic; String shift3; if (c40) {
/*  461 */       String basic = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
/*  462 */       shift3 = "`abcdefghijklmnopqrstuvwxyz{|}~";
/*      */     }
/*      */     else {
/*  465 */       basic = " 0123456789abcdefghijklmnopqrstuvwxyz";
/*  466 */       shift3 = "`ABCDEFGHIJKLMNOPQRSTUVWXYZ{|}~";
/*      */     }
/*  468 */     int[] enc = new int[textLength * 4 + 10];
/*  469 */     int encPtr = 0;
/*  470 */     int last0 = 0;
/*  471 */     int last1 = 0;
/*  472 */     while (ptrIn < textLength) {
/*  473 */       if (encPtr % 3 == 0) {
/*  474 */         last0 = ptrIn;
/*  475 */         last1 = encPtr;
/*      */       }
/*  477 */       int c = text[(textOffset + ptrIn++)] & 0xFF;
/*  478 */       if (c > 127) {
/*  479 */         c -= 128;
/*  480 */         enc[(encPtr++)] = 1;
/*  481 */         enc[(encPtr++)] = 30;
/*      */       }
/*  483 */       int idx = basic.indexOf((char)c);
/*  484 */       if (idx >= 0) {
/*  485 */         enc[(encPtr++)] = (idx + 3);
/*      */       }
/*  487 */       else if (c < 32) {
/*  488 */         enc[(encPtr++)] = 0;
/*  489 */         enc[(encPtr++)] = c;
/*      */       }
/*  491 */       else if ((idx = shift2.indexOf((char)c)) >= 0) {
/*  492 */         enc[(encPtr++)] = 1;
/*  493 */         enc[(encPtr++)] = idx;
/*      */       }
/*  495 */       else if ((idx = shift3.indexOf((char)c)) >= 0) {
/*  496 */         enc[(encPtr++)] = 2;
/*  497 */         enc[(encPtr++)] = idx;
/*      */       }
/*      */     }
/*  500 */     if (encPtr % 3 != 0) {
/*  501 */       ptrIn = last0;
/*  502 */       encPtr = last1;
/*      */     }
/*  504 */     if (encPtr / 3 * 2 > dataLength - 2) {
/*  505 */       return -1;
/*      */     }
/*  507 */     for (int i = 0; 
/*  508 */         i < encPtr; i += 3) {
/*  509 */       int a = 1600 * enc[i] + 40 * enc[(i + 1)] + enc[(i + 2)] + 1;
/*  510 */       data[(dataOffset + ptrOut++)] = ((byte)(a / 256));
/*  511 */       data[(dataOffset + ptrOut++)] = ((byte)a);
/*      */     }
/*  513 */     data[(ptrOut++)] = -2;
/*  514 */     i = asciiEncodation(text, ptrIn, textLength - ptrIn, data, ptrOut, dataLength - ptrOut);
/*  515 */     if (i < 0)
/*  516 */       return i;
/*  517 */     return ptrOut + i;
/*      */   }
/*      */   
/*      */   private static int getEncodation(byte[] text, int textOffset, int textSize, byte[] data, int dataOffset, int dataSize, int options, boolean firstMatch)
/*      */   {
/*  522 */     int[] e1 = new int[6];
/*  523 */     if (dataSize < 0)
/*  524 */       return -1;
/*  525 */     int e = -1;
/*  526 */     options &= 0x7;
/*  527 */     if (options == 0) {
/*  528 */       e1[0] = asciiEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  529 */       if ((firstMatch) && (e1[0] >= 0))
/*  530 */         return e1[0];
/*  531 */       e1[1] = C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, false);
/*  532 */       if ((firstMatch) && (e1[1] >= 0))
/*  533 */         return e1[1];
/*  534 */       e1[2] = C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, true);
/*  535 */       if ((firstMatch) && (e1[2] >= 0))
/*  536 */         return e1[2];
/*  537 */       e1[3] = b256Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  538 */       if ((firstMatch) && (e1[3] >= 0))
/*  539 */         return e1[3];
/*  540 */       e1[4] = X12Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  541 */       if ((firstMatch) && (e1[4] >= 0))
/*  542 */         return e1[4];
/*  543 */       e1[5] = EdifactEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  544 */       if ((firstMatch) && (e1[5] >= 0))
/*  545 */         return e1[5];
/*  546 */       if ((e1[0] < 0) && (e1[1] < 0) && (e1[2] < 0) && (e1[3] < 0) && (e1[4] < 0) && (e1[5] < 0)) {
/*  547 */         return -1;
/*      */       }
/*  549 */       int j = 0;
/*  550 */       e = 99999;
/*  551 */       for (int k = 0; k < 6; k++) {
/*  552 */         if ((e1[k] >= 0) && (e1[k] < e)) {
/*  553 */           e = e1[k];
/*  554 */           j = k;
/*      */         }
/*      */       }
/*  557 */       if (j == 0) {
/*  558 */         e = asciiEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  559 */       } else if (j == 1) {
/*  560 */         e = C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, false);
/*  561 */       } else if (j == 2) {
/*  562 */         e = C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, true);
/*  563 */       } else if (j == 3) {
/*  564 */         e = b256Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  565 */       } else if (j == 4)
/*  566 */         e = X12Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*  567 */       return e;
/*      */     }
/*  569 */     switch (options) {
/*      */     case 1: 
/*  571 */       return asciiEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*      */     case 2: 
/*  573 */       return C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, true);
/*      */     case 3: 
/*  575 */       return C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, false);
/*      */     case 4: 
/*  577 */       return b256Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*      */     case 5: 
/*  579 */       return X12Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*      */     case 6: 
/*  581 */       return EdifactEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
/*      */     case 7: 
/*  583 */       if (textSize > dataSize)
/*  584 */         return -1;
/*  585 */       System.arraycopy(text, textOffset, data, dataOffset, textSize);
/*  586 */       return textSize;
/*      */     }
/*  588 */     return -1;
/*      */   }
/*      */   
/*      */   private static int getNumber(byte[] text, int ptrIn, int n)
/*      */   {
/*  593 */     int v = 0;
/*  594 */     for (int j = 0; j < n; j++) {
/*  595 */       int c = text[(ptrIn++)] & 0xFF;
/*  596 */       if ((c < 48) || (c > 57))
/*  597 */         return -1;
/*  598 */       v = v * 10 + c - 48;
/*      */     }
/*  600 */     return v;
/*      */   }
/*      */   
/*      */   private int processExtensions(byte[] text, int textOffset, int textSize, byte[] data)
/*      */   {
/*  605 */     if ((this.options & 0x20) == 0)
/*  606 */       return 0;
/*  607 */     int order = 0;
/*  608 */     int ptrIn = 0;
/*  609 */     int ptrOut = 0;
/*  610 */     while (ptrIn < textSize) {
/*  611 */       if (order > 20)
/*  612 */         return -1;
/*  613 */       int c = text[(textOffset + ptrIn++)] & 0xFF;
/*  614 */       order++;
/*  615 */       switch (c) {
/*      */       case 46: 
/*  617 */         this.extOut = ptrIn;
/*  618 */         return ptrOut;
/*      */       case 101: 
/*  620 */         if (ptrIn + 6 > textSize)
/*  621 */           return -1;
/*  622 */         int eci = getNumber(text, textOffset + ptrIn, 6);
/*  623 */         if (eci < 0)
/*  624 */           return -1;
/*  625 */         ptrIn += 6;
/*  626 */         data[(ptrOut++)] = -15;
/*  627 */         if (eci < 127) {
/*  628 */           data[(ptrOut++)] = ((byte)(eci + 1));
/*  629 */         } else if (eci < 16383) {
/*  630 */           data[(ptrOut++)] = ((byte)((eci - 127) / 254 + 128));
/*  631 */           data[(ptrOut++)] = ((byte)((eci - 127) % 254 + 1));
/*      */         }
/*      */         else {
/*  634 */           data[(ptrOut++)] = ((byte)((eci - 16383) / 64516 + 192));
/*  635 */           data[(ptrOut++)] = ((byte)((eci - 16383) / 254 % 254 + 1));
/*  636 */           data[(ptrOut++)] = ((byte)((eci - 16383) % 254 + 1));
/*      */         }
/*  638 */         break;
/*      */       case 115: 
/*  640 */         if (order != 1)
/*  641 */           return -1;
/*  642 */         if (ptrIn + 9 > textSize)
/*  643 */           return -1;
/*  644 */         int fn = getNumber(text, textOffset + ptrIn, 2);
/*  645 */         if ((fn <= 0) || (fn > 16))
/*  646 */           return -1;
/*  647 */         ptrIn += 2;
/*  648 */         int ft = getNumber(text, textOffset + ptrIn, 2);
/*  649 */         if ((ft <= 1) || (ft > 16))
/*  650 */           return -1;
/*  651 */         ptrIn += 2;
/*  652 */         int fi = getNumber(text, textOffset + ptrIn, 5);
/*  653 */         if ((fi < 0) || (fn >= 64516))
/*  654 */           return -1;
/*  655 */         ptrIn += 5;
/*  656 */         data[(ptrOut++)] = -23;
/*  657 */         data[(ptrOut++)] = ((byte)(fn - 1 << 4 | 17 - ft));
/*  658 */         data[(ptrOut++)] = ((byte)(fi / 254 + 1));
/*  659 */         data[(ptrOut++)] = ((byte)(fi % 254 + 1));
/*  660 */         break;
/*      */       case 112: 
/*  662 */         if (order != 1)
/*  663 */           return -1;
/*  664 */         data[(ptrOut++)] = -22;
/*  665 */         break;
/*      */       case 109: 
/*  667 */         if (order != 1)
/*  668 */           return -1;
/*  669 */         if (ptrIn + 1 > textSize)
/*  670 */           return -1;
/*  671 */         c = text[(textOffset + ptrIn++)] & 0xFF;
/*  672 */         if ((c != 53) && (c != 53))
/*  673 */           return -1;
/*  674 */         data[(ptrOut++)] = -22;
/*  675 */         data[(ptrOut++)] = ((byte)(c == 53 ? 'ì' : 'í'));
/*  676 */         break;
/*      */       case 102: 
/*  678 */         if ((order != 1) && ((order != 2) || ((text[textOffset] != 115) && (text[textOffset] != 109))))
/*  679 */           return -1;
/*  680 */         data[(ptrOut++)] = -24;
/*      */       }
/*      */     }
/*  683 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int generate(String text)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  698 */     byte[] t = text.getBytes("iso-8859-1");
/*  699 */     return generate(t, 0, t.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int generate(byte[] text, int textOffset, int textSize)
/*      */   {
/*  717 */     byte[] data = new byte['ৄ'];
/*  718 */     this.extOut = 0;
/*  719 */     int extCount = processExtensions(text, textOffset, textSize, data);
/*  720 */     if (extCount < 0) {
/*  721 */       return 5;
/*      */     }
/*  723 */     int e = -1;
/*  724 */     DmParams dm; if ((this.height == 0) || (this.width == 0)) {
/*  725 */       DmParams last = dmSizes[(dmSizes.length - 1)];
/*  726 */       e = getEncodation(text, textOffset + this.extOut, textSize - this.extOut, data, extCount, last.dataSize - extCount, this.options, false);
/*  727 */       if (e < 0) {
/*  728 */         return 1;
/*      */       }
/*  730 */       e += extCount;
/*  731 */       for (int k = 0; k < dmSizes.length; k++) {
/*  732 */         if (dmSizes[k].dataSize >= e)
/*      */           break;
/*      */       }
/*  735 */       DmParams dm = dmSizes[k];
/*  736 */       this.height = dm.height;
/*  737 */       this.width = dm.width;
/*      */     }
/*      */     else {
/*  740 */       for (int k = 0; k < dmSizes.length; k++) {
/*  741 */         if ((this.height == dmSizes[k].height) && (this.width == dmSizes[k].width))
/*      */           break;
/*      */       }
/*  744 */       if (k == dmSizes.length) {
/*  745 */         return 3;
/*      */       }
/*  747 */       dm = dmSizes[k];
/*  748 */       e = getEncodation(text, textOffset + this.extOut, textSize - this.extOut, data, extCount, dm.dataSize - extCount, this.options, true);
/*  749 */       if (e < 0) {
/*  750 */         return 1;
/*      */       }
/*  752 */       e += extCount;
/*      */     }
/*  754 */     if ((this.options & 0x40) != 0) {
/*  755 */       return 0;
/*      */     }
/*  757 */     this.image = new byte[(dm.width + 2 * this.ws + 7) / 8 * (dm.height + 2 * this.ws)];
/*  758 */     makePadding(data, e, dm.dataSize - e);
/*  759 */     this.place = Placement.doPlacement(dm.height - dm.height / dm.heightSection * 2, dm.width - dm.width / dm.widthSection * 2);
/*  760 */     int full = dm.dataSize + (dm.dataSize + 2) / dm.dataBlock * dm.errorBlock;
/*  761 */     ReedSolomon.generateECC(data, dm.dataSize, dm.dataBlock, dm.errorBlock);
/*  762 */     draw(data, full, dm);
/*  763 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public com.itextpdf.text.Image createImage()
/*      */     throws BadElementException
/*      */   {
/*  772 */     if (this.image == null)
/*  773 */       return null;
/*  774 */     byte[] g4 = CCITTG4Encoder.compress(this.image, this.width + 2 * this.ws, this.height + 2 * this.ws);
/*  775 */     return com.itextpdf.text.Image.getInstance(this.width + 2 * this.ws, this.height + 2 * this.ws, false, 256, 0, g4, null);
/*      */   }
/*      */   
/*      */   private static class DmParams { int height;
/*      */     
/*  780 */     DmParams(int height, int width, int heightSection, int widthSection, int dataSize, int dataBlock, int errorBlock) { this.height = height;
/*  781 */       this.width = width;
/*  782 */       this.heightSection = heightSection;
/*  783 */       this.widthSection = widthSection;
/*  784 */       this.dataSize = dataSize;
/*  785 */       this.dataBlock = dataBlock;
/*  786 */       this.errorBlock = errorBlock;
/*      */     }
/*      */     
/*      */ 
/*      */     int width;
/*      */     
/*      */     int heightSection;
/*      */     
/*      */     int widthSection;
/*      */     
/*      */     int dataSize;
/*      */     
/*      */     int dataBlock;
/*      */     
/*      */     int errorBlock;
/*      */   }
/*      */   
/*      */ 
/*      */   public byte[] getImage()
/*      */   {
/*  806 */     return this.image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHeight()
/*      */   {
/*  815 */     return this.height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeight(int height)
/*      */   {
/*  855 */     this.height = height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWidth()
/*      */   {
/*  864 */     return this.width;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidth(int width)
/*      */   {
/*  904 */     this.width = width;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWs()
/*      */   {
/*  912 */     return this.ws;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWs(int ws)
/*      */   {
/*  920 */     this.ws = ws;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOptions()
/*      */   {
/*  928 */     return this.options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOptions(int options)
/*      */   {
/*  959 */     this.options = options;
/*      */   }
/*      */   
/*      */   static class Placement {
/*      */     private int nrow;
/*      */     private int ncol;
/*      */     private short[] array;
/*  966 */     private static final Hashtable<Integer, short[]> cache = new Hashtable();
/*      */     
/*      */ 
/*      */ 
/*      */     static short[] doPlacement(int nrow, int ncol)
/*      */     {
/*  972 */       Integer key = Integer.valueOf(nrow * 1000 + ncol);
/*  973 */       short[] pc = (short[])cache.get(key);
/*  974 */       if (pc != null)
/*  975 */         return pc;
/*  976 */       Placement p = new Placement();
/*  977 */       p.nrow = nrow;
/*  978 */       p.ncol = ncol;
/*  979 */       p.array = new short[nrow * ncol];
/*  980 */       p.ecc200();
/*  981 */       cache.put(key, p.array);
/*  982 */       return p.array;
/*      */     }
/*      */     
/*      */     private void module(int row, int col, int chr, int bit)
/*      */     {
/*  987 */       if (row < 0) { row += this.nrow;col += 4 - (this.nrow + 4) % 8; }
/*  988 */       if (col < 0) { col += this.ncol;row += 4 - (this.ncol + 4) % 8; }
/*  989 */       this.array[(row * this.ncol + col)] = ((short)(8 * chr + bit));
/*      */     }
/*      */     
/*      */     private void utah(int row, int col, int chr) {
/*  993 */       module(row - 2, col - 2, chr, 0);
/*  994 */       module(row - 2, col - 1, chr, 1);
/*  995 */       module(row - 1, col - 2, chr, 2);
/*  996 */       module(row - 1, col - 1, chr, 3);
/*  997 */       module(row - 1, col, chr, 4);
/*  998 */       module(row, col - 2, chr, 5);
/*  999 */       module(row, col - 1, chr, 6);
/* 1000 */       module(row, col, chr, 7);
/*      */     }
/*      */     
/*      */     private void corner1(int chr) {
/* 1004 */       module(this.nrow - 1, 0, chr, 0);
/* 1005 */       module(this.nrow - 1, 1, chr, 1);
/* 1006 */       module(this.nrow - 1, 2, chr, 2);
/* 1007 */       module(0, this.ncol - 2, chr, 3);
/* 1008 */       module(0, this.ncol - 1, chr, 4);
/* 1009 */       module(1, this.ncol - 1, chr, 5);
/* 1010 */       module(2, this.ncol - 1, chr, 6);
/* 1011 */       module(3, this.ncol - 1, chr, 7);
/*      */     }
/*      */     
/* 1014 */     private void corner2(int chr) { module(this.nrow - 3, 0, chr, 0);
/* 1015 */       module(this.nrow - 2, 0, chr, 1);
/* 1016 */       module(this.nrow - 1, 0, chr, 2);
/* 1017 */       module(0, this.ncol - 4, chr, 3);
/* 1018 */       module(0, this.ncol - 3, chr, 4);
/* 1019 */       module(0, this.ncol - 2, chr, 5);
/* 1020 */       module(0, this.ncol - 1, chr, 6);
/* 1021 */       module(1, this.ncol - 1, chr, 7);
/*      */     }
/*      */     
/* 1024 */     private void corner3(int chr) { module(this.nrow - 3, 0, chr, 0);
/* 1025 */       module(this.nrow - 2, 0, chr, 1);
/* 1026 */       module(this.nrow - 1, 0, chr, 2);
/* 1027 */       module(0, this.ncol - 2, chr, 3);
/* 1028 */       module(0, this.ncol - 1, chr, 4);
/* 1029 */       module(1, this.ncol - 1, chr, 5);
/* 1030 */       module(2, this.ncol - 1, chr, 6);
/* 1031 */       module(3, this.ncol - 1, chr, 7);
/*      */     }
/*      */     
/* 1034 */     private void corner4(int chr) { module(this.nrow - 1, 0, chr, 0);
/* 1035 */       module(this.nrow - 1, this.ncol - 1, chr, 1);
/* 1036 */       module(0, this.ncol - 3, chr, 2);
/* 1037 */       module(0, this.ncol - 2, chr, 3);
/* 1038 */       module(0, this.ncol - 1, chr, 4);
/* 1039 */       module(1, this.ncol - 3, chr, 5);
/* 1040 */       module(1, this.ncol - 2, chr, 6);
/* 1041 */       module(1, this.ncol - 1, chr, 7);
/*      */     }
/*      */     
/*      */ 
/*      */     private void ecc200()
/*      */     {
/* 1047 */       Arrays.fill(this.array, (short)0);
/*      */       
/* 1049 */       int chr = 1;int row = 4;int col = 0;
/*      */       do
/*      */       {
/* 1052 */         if ((row == this.nrow) && (col == 0)) corner1(chr++);
/* 1053 */         if ((row == this.nrow - 2) && (col == 0) && (this.ncol % 4 != 0)) corner2(chr++);
/* 1054 */         if ((row == this.nrow - 2) && (col == 0) && (this.ncol % 8 == 4)) corner3(chr++);
/* 1055 */         if ((row == this.nrow + 4) && (col == 2) && (this.ncol % 8 == 0)) corner4(chr++);
/*      */         do
/*      */         {
/* 1058 */           if ((row < this.nrow) && (col >= 0) && (this.array[(row * this.ncol + col)] == 0))
/* 1059 */             utah(row, col, chr++);
/* 1060 */           row -= 2;col += 2;
/* 1061 */         } while ((row >= 0) && (col < this.ncol));
/* 1062 */         row++;col += 3;
/*      */         
/*      */         do
/*      */         {
/* 1066 */           if ((row >= 0) && (col < this.ncol) && (this.array[(row * this.ncol + col)] == 0))
/* 1067 */             utah(row, col, chr++);
/* 1068 */           row += 2;col -= 2;
/* 1069 */         } while ((row < this.nrow) && (col >= 0));
/* 1070 */         row += 3;col++;
/*      */       }
/* 1072 */       while ((row < this.nrow) || (col < this.ncol));
/*      */       
/* 1074 */       if (this.array[(this.nrow * this.ncol - 1)] == 0) {
/* 1075 */         this.array[(this.nrow * this.ncol - 1)] = (this.array[(this.nrow * this.ncol - this.ncol - 2)] = 1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static class ReedSolomon
/*      */   {
/* 1082 */     private static final int[] log = { 0, 255, 1, 240, 2, 225, 241, 53, 3, 38, 226, 133, 242, 43, 54, 210, 4, 195, 39, 114, 227, 106, 134, 28, 243, 140, 44, 23, 55, 118, 211, 234, 5, 219, 196, 96, 40, 222, 115, 103, 228, 78, 107, 125, 135, 8, 29, 162, 244, 186, 141, 180, 45, 99, 24, 49, 56, 13, 119, 153, 212, 199, 235, 91, 6, 76, 220, 217, 197, 11, 97, 184, 41, 36, 223, 253, 116, 138, 104, 193, 229, 86, 79, 171, 108, 165, 126, 145, 136, 34, 9, 74, 30, 32, 163, 84, 245, 173, 187, 204, 142, 81, 181, 190, 46, 88, 100, 159, 25, 231, 50, 207, 57, 147, 14, 67, 120, 128, 154, 248, 213, 167, 200, 63, 236, 110, 92, 176, 7, 161, 77, 124, 221, 102, 218, 95, 198, 90, 12, 152, 98, 48, 185, 179, 42, 209, 37, 132, 224, 52, 254, 239, 117, 233, 139, 22, 105, 27, 194, 113, 230, 206, 87, 158, 80, 189, 172, 203, 109, 175, 166, 62, 127, 247, 146, 66, 137, 192, 35, 252, 10, 183, 75, 216, 31, 83, 33, 73, 164, 144, 85, 170, 246, 65, 174, 61, 188, 202, 205, 157, 143, 169, 82, 72, 182, 215, 191, 251, 47, 178, 89, 151, 101, 94, 160, 123, 26, 112, 232, 21, 51, 238, 208, 131, 58, 69, 148, 18, 15, 16, 68, 17, 121, 149, 129, 19, 155, 59, 249, 70, 214, 250, 168, 71, 201, 156, 64, 60, 237, 130, 111, 20, 93, 122, 177, 150 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1101 */     private static final int[] alog = { 1, 2, 4, 8, 16, 32, 64, 128, 45, 90, 180, 69, 138, 57, 114, 228, 229, 231, 227, 235, 251, 219, 155, 27, 54, 108, 216, 157, 23, 46, 92, 184, 93, 186, 89, 178, 73, 146, 9, 18, 36, 72, 144, 13, 26, 52, 104, 208, 141, 55, 110, 220, 149, 7, 14, 28, 56, 112, 224, 237, 247, 195, 171, 123, 246, 193, 175, 115, 230, 225, 239, 243, 203, 187, 91, 182, 65, 130, 41, 82, 164, 101, 202, 185, 95, 190, 81, 162, 105, 210, 137, 63, 126, 252, 213, 135, 35, 70, 140, 53, 106, 212, 133, 39, 78, 156, 21, 42, 84, 168, 125, 250, 217, 159, 19, 38, 76, 152, 29, 58, 116, 232, 253, 215, 131, 43, 86, 172, 117, 234, 249, 223, 147, 11, 22, 44, 88, 176, 77, 154, 25, 50, 100, 200, 189, 87, 174, 113, 226, 233, 255, 211, 139, 59, 118, 236, 245, 199, 163, 107, 214, 129, 47, 94, 188, 85, 170, 121, 242, 201, 191, 83, 166, 97, 194, 169, 127, 254, 209, 143, 51, 102, 204, 181, 71, 142, 49, 98, 196, 165, 103, 206, 177, 79, 158, 17, 34, 68, 136, 61, 122, 244, 197, 167, 99, 198, 161, 111, 222, 145, 15, 30, 60, 120, 240, 205, 183, 67, 134, 33, 66, 132, 37, 74, 148, 5, 10, 20, 40, 80, 160, 109, 218, 153, 31, 62, 124, 248, 221, 151, 3, 6, 12, 24, 48, 96, 192, 173, 119, 238, 241, 207, 179, 75, 150, 1 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1120 */     private static final int[] poly5 = { 228, 48, 15, 111, 62 };
/*      */     
/*      */ 
/*      */ 
/* 1124 */     private static final int[] poly7 = { 23, 68, 144, 134, 240, 92, 254 };
/*      */     
/*      */ 
/*      */ 
/* 1128 */     private static final int[] poly10 = { 28, 24, 185, 166, 223, 248, 116, 255, 110, 61 };
/*      */     
/*      */ 
/*      */ 
/* 1132 */     private static final int[] poly11 = { 175, 138, 205, 12, 194, 168, 39, 245, 60, 97, 120 };
/*      */     
/*      */ 
/*      */ 
/* 1136 */     private static final int[] poly12 = { 41, 153, 158, 91, 61, 42, 142, 213, 97, 178, 100, 242 };
/*      */     
/*      */ 
/*      */ 
/* 1140 */     private static final int[] poly14 = { 156, 97, 192, 252, 95, 9, 157, 119, 138, 45, 18, 186, 83, 185 };
/*      */     
/*      */ 
/*      */ 
/* 1144 */     private static final int[] poly18 = { 83, 195, 100, 39, 188, 75, 66, 61, 241, 213, 109, 129, 94, 254, 225, 48, 90, 188 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1149 */     private static final int[] poly20 = { 15, 195, 244, 9, 233, 71, 168, 2, 188, 160, 153, 145, 253, 79, 108, 82, 27, 174, 186, 172 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1154 */     private static final int[] poly24 = { 52, 190, 88, 205, 109, 39, 176, 21, 155, 197, 251, 223, 155, 21, 5, 172, 254, 124, 12, 181, 184, 96, 50, 193 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1159 */     private static final int[] poly28 = { 211, 231, 43, 97, 71, 96, 103, 174, 37, 151, 170, 53, 75, 34, 249, 121, 17, 138, 110, 213, 141, 136, 120, 151, 233, 168, 93, 255 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1164 */     private static final int[] poly36 = { 245, 127, 242, 218, 130, 250, 162, 181, 102, 120, 84, 179, 220, 251, 80, 182, 229, 18, 2, 4, 68, 33, 101, 137, 95, 119, 115, 44, 175, 184, 59, 25, 225, 98, 81, 112 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1170 */     private static final int[] poly42 = { 77, 193, 137, 31, 19, 38, 22, 153, 247, 105, 122, 2, 245, 133, 242, 8, 175, 95, 100, 9, 167, 105, 214, 111, 57, 121, 21, 1, 253, 57, 54, 101, 248, 202, 69, 50, 150, 177, 226, 5, 9, 5 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1176 */     private static final int[] poly48 = { 245, 132, 172, 223, 96, 32, 117, 22, 238, 133, 238, 231, 205, 188, 237, 87, 191, 106, 16, 147, 118, 23, 37, 90, 170, 205, 131, 88, 120, 100, 66, 138, 186, 240, 82, 44, 176, 87, 187, 147, 160, 175, 69, 213, 92, 253, 225, 19 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1182 */     private static final int[] poly56 = { 175, 9, 223, 238, 12, 17, 220, 208, 100, 29, 175, 170, 230, 192, 215, 235, 150, 159, 36, 223, 38, 200, 132, 54, 228, 146, 218, 234, 117, 203, 29, 232, 144, 238, 22, 150, 201, 117, 62, 207, 164, 13, 137, 245, 127, 67, 247, 28, 155, 43, 203, 107, 233, 53, 143, 46 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1189 */     private static final int[] poly62 = { 242, 93, 169, 50, 144, 210, 39, 118, 202, 188, 201, 189, 143, 108, 196, 37, 185, 112, 134, 230, 245, 63, 197, 190, 250, 106, 185, 221, 175, 64, 114, 71, 161, 44, 147, 6, 27, 218, 51, 63, 87, 10, 40, 130, 188, 17, 163, 31, 176, 170, 4, 107, 232, 7, 94, 166, 224, 124, 86, 47, 11, 204 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1196 */     private static final int[] poly68 = { 220, 228, 173, 89, 251, 149, 159, 56, 89, 33, 147, 244, 154, 36, 73, 127, 213, 136, 248, 180, 234, 197, 158, 177, 68, 122, 93, 213, 15, 160, 227, 236, 66, 139, 153, 185, 202, 167, 179, 25, 220, 232, 96, 210, 231, 136, 223, 239, 181, 241, 59, 52, 172, 25, 49, 232, 211, 189, 64, 54, 108, 153, 132, 63, 96, 103, 82, 186 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private static int[] getPoly(int nc)
/*      */     {
/* 1205 */       switch (nc) {
/*      */       case 5: 
/* 1207 */         return poly5;
/*      */       case 7: 
/* 1209 */         return poly7;
/*      */       case 10: 
/* 1211 */         return poly10;
/*      */       case 11: 
/* 1213 */         return poly11;
/*      */       case 12: 
/* 1215 */         return poly12;
/*      */       case 14: 
/* 1217 */         return poly14;
/*      */       case 18: 
/* 1219 */         return poly18;
/*      */       case 20: 
/* 1221 */         return poly20;
/*      */       case 24: 
/* 1223 */         return poly24;
/*      */       case 28: 
/* 1225 */         return poly28;
/*      */       case 36: 
/* 1227 */         return poly36;
/*      */       case 42: 
/* 1229 */         return poly42;
/*      */       case 48: 
/* 1231 */         return poly48;
/*      */       case 56: 
/* 1233 */         return poly56;
/*      */       case 62: 
/* 1235 */         return poly62;
/*      */       case 68: 
/* 1237 */         return poly68;
/*      */       }
/* 1239 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */     private static void reedSolomonBlock(byte[] wd, int nd, byte[] ncout, int nc, int[] c)
/*      */     {
/* 1245 */       for (int i = 0; i <= nc; i++) ncout[i] = 0;
/* 1246 */       for (i = 0; i < nd; i++) {
/* 1247 */         int k = (ncout[0] ^ wd[i]) & 0xFF;
/* 1248 */         for (int j = 0; j < nc; j++) {
/* 1249 */           ncout[j] = ((byte)(ncout[(j + 1)] ^ (k == 0 ? 0 : (byte)alog[((log[k] + log[c[(nc - j - 1)]]) % 255)])));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     static void generateECC(byte[] wd, int nd, int datablock, int nc) {
/* 1255 */       int blocks = (nd + 2) / datablock;
/*      */       
/* 1257 */       byte[] buf = new byte['Ā'];
/* 1258 */       byte[] ecc = new byte['Ā'];
/* 1259 */       int[] c = getPoly(nc);
/* 1260 */       for (int b = 0; b < blocks; b++)
/*      */       {
/* 1262 */         int p = 0;
/* 1263 */         for (int n = b; n < nd; n += blocks)
/* 1264 */           buf[(p++)] = wd[n];
/* 1265 */         reedSolomonBlock(buf, p, ecc, nc, c);
/* 1266 */         p = 0;
/* 1267 */         for (n = b; n < nc * blocks; n += blocks) {
/* 1268 */           wd[(nd + n)] = ecc[(p++)];
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void placeBarcode(PdfContentByte cb, BaseColor foreground, float moduleHeight, float moduleWidth) {
/* 1275 */     int w = this.width + 2 * this.ws;
/* 1276 */     int h = this.height + 2 * this.ws;
/* 1277 */     int stride = (w + 7) / 8;
/* 1278 */     int ptr = 0;
/* 1279 */     cb.setColorFill(foreground);
/* 1280 */     for (int k = 0; k < h; k++) {
/* 1281 */       int p = k * stride;
/* 1282 */       for (int j = 0; j < w; j++) {
/* 1283 */         int b = this.image[(p + j / 8)] & 0xFF;
/* 1284 */         b <<= j % 8;
/* 1285 */         if ((b & 0x80) != 0) {
/* 1286 */           cb.rectangle(j * moduleWidth, (h - k - 1) * moduleHeight, moduleWidth, moduleHeight);
/*      */         }
/*      */       }
/*      */     }
/* 1290 */     cb.fill();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.awt.Image createAwtImage(Color foreground, Color background)
/*      */   {
/* 1303 */     if (this.image == null)
/* 1304 */       return null;
/* 1305 */     int f = foreground.getRGB();
/* 1306 */     int g = background.getRGB();
/* 1307 */     Canvas canvas = new Canvas();
/*      */     
/* 1309 */     int w = this.width + 2 * this.ws;
/* 1310 */     int h = this.height + 2 * this.ws;
/* 1311 */     int[] pix = new int[w * h];
/* 1312 */     int stride = (w + 7) / 8;
/* 1313 */     int ptr = 0;
/* 1314 */     for (int k = 0; k < h; k++) {
/* 1315 */       int p = k * stride;
/* 1316 */       for (int j = 0; j < w; j++) {
/* 1317 */         int b = this.image[(p + j / 8)] & 0xFF;
/* 1318 */         b <<= j % 8;
/* 1319 */         pix[(ptr++)] = ((b & 0x80) == 0 ? g : f);
/*      */       }
/*      */     }
/* 1322 */     java.awt.Image img = canvas.createImage(new MemoryImageSource(w, h, pix, 0, w));
/* 1323 */     return img;
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/BarcodeDatamatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */