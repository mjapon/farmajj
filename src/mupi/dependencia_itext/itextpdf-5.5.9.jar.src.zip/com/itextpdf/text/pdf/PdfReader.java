/*      */ package com.itextpdf.text.pdf;
/*      */ 
/*      */ import com.itextpdf.text.DocWriter;
/*      */ import com.itextpdf.text.Document;
/*      */ import com.itextpdf.text.ExceptionConverter;
/*      */ import com.itextpdf.text.PageSize;
/*      */ import com.itextpdf.text.Rectangle;
/*      */ import com.itextpdf.text.error_messages.MessageLocalization;
/*      */ import com.itextpdf.text.exceptions.BadPasswordException;
/*      */ import com.itextpdf.text.exceptions.InvalidPdfException;
/*      */ import com.itextpdf.text.exceptions.UnsupportedPdfException;
/*      */ import com.itextpdf.text.io.RandomAccessSource;
/*      */ import com.itextpdf.text.io.RandomAccessSourceFactory;
/*      */ import com.itextpdf.text.io.WindowRandomAccessSource;
/*      */ import com.itextpdf.text.log.Counter;
/*      */ import com.itextpdf.text.log.CounterFactory;
/*      */ import com.itextpdf.text.log.Level;
/*      */ import com.itextpdf.text.log.Logger;
/*      */ import com.itextpdf.text.log.LoggerFactory;
/*      */ import com.itextpdf.text.pdf.interfaces.PdfViewerPreferences;
/*      */ import com.itextpdf.text.pdf.internal.PdfViewerPreferencesImp;
/*      */ import com.itextpdf.text.pdf.security.ExternalDecryptionProcess;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URL;
/*      */ import java.security.Key;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.cert.Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.zip.InflaterInputStream;
/*      */ import org.bouncycastle.cert.X509CertificateHolder;
/*      */ import org.bouncycastle.cms.CMSEnvelopedData;
/*      */ import org.bouncycastle.cms.RecipientId;
/*      */ import org.bouncycastle.cms.RecipientInformation;
/*      */ import org.bouncycastle.cms.RecipientInformationStore;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PdfReader
/*      */   implements PdfViewerPreferences
/*      */ {
/*   88 */   public static boolean unethicalreading = false;
/*      */   
/*   90 */   public static boolean debugmode = false;
/*   91 */   private static final Logger LOGGER = LoggerFactory.getLogger(PdfReader.class);
/*      */   
/*   93 */   static final PdfName[] pageInhCandidates = { PdfName.MEDIABOX, PdfName.ROTATE, PdfName.RESOURCES, PdfName.CROPBOX };
/*      */   
/*      */ 
/*      */ 
/*   97 */   static final byte[] endstream = PdfEncodings.convertToBytes("endstream", null);
/*   98 */   static final byte[] endobj = PdfEncodings.convertToBytes("endobj", null);
/*      */   
/*      */   protected PRTokeniser tokens;
/*      */   
/*      */   protected long[] xref;
/*      */   
/*      */   protected HashMap<Integer, IntHashtable> objStmMark;
/*      */   
/*      */   protected LongHashtable objStmToOffset;
/*      */   protected boolean newXrefType;
/*      */   protected ArrayList<PdfObject> xrefObj;
/*      */   PdfDictionary rootPages;
/*      */   protected PdfDictionary trailer;
/*      */   protected PdfDictionary catalog;
/*      */   protected PageRefs pageRefs;
/*  113 */   protected PRAcroForm acroForm = null;
/*  114 */   protected boolean acroFormParsed = false;
/*  115 */   protected boolean encrypted = false;
/*  116 */   protected boolean rebuilt = false;
/*      */   protected int freeXref;
/*  118 */   protected boolean tampered = false;
/*      */   protected long lastXref;
/*      */   protected long eofPos;
/*      */   protected char pdfVersion;
/*      */   protected PdfEncryption decrypt;
/*  123 */   protected byte[] password = null;
/*  124 */   protected Key certificateKey = null;
/*  125 */   protected Certificate certificate = null;
/*  126 */   protected String certificateKeyProvider = null;
/*  127 */   protected ExternalDecryptionProcess externalDecryptionProcess = null;
/*      */   private boolean ownerPasswordUsed;
/*  129 */   protected ArrayList<PdfString> strings = new ArrayList();
/*  130 */   protected boolean sharedStreams = true;
/*  131 */   protected boolean consolidateNamedDestinations = false;
/*  132 */   protected boolean remoteToLocalNamedDestinations = false;
/*      */   protected int rValue;
/*      */   protected long pValue;
/*      */   private int objNum;
/*      */   private int objGen;
/*      */   private long fileLength;
/*      */   private boolean hybridXref;
/*  139 */   private int lastXrefPartial = -1;
/*      */   
/*      */   private boolean partial;
/*      */   private PRIndirectReference cryptoRef;
/*  143 */   private final PdfViewerPreferencesImp viewerPreferences = new PdfViewerPreferencesImp();
/*      */   
/*      */ 
/*      */   private boolean encryptionError;
/*      */   
/*      */ 
/*      */   private boolean appendable;
/*      */   
/*  151 */   protected static Counter COUNTER = CounterFactory.getCounter(PdfReader.class);
/*      */   
/*  153 */   protected Counter getCounter() { return COUNTER; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PdfReader(RandomAccessSource byteSource, boolean partialRead, byte[] ownerPassword, Certificate certificate, Key certificateKey, String certificateKeyProvider, ExternalDecryptionProcess externalDecryptionProcess, boolean closeSourceOnConstructorError)
/*      */     throws IOException
/*      */   {
/*  168 */     this.certificate = certificate;
/*  169 */     this.certificateKey = certificateKey;
/*  170 */     this.certificateKeyProvider = certificateKeyProvider;
/*  171 */     this.externalDecryptionProcess = externalDecryptionProcess;
/*  172 */     this.password = ownerPassword;
/*  173 */     this.partial = partialRead;
/*      */     try
/*      */     {
/*  176 */       this.tokens = getOffsetTokeniser(byteSource);
/*      */       
/*  178 */       if (partialRead) {
/*  179 */         readPdfPartial();
/*      */       } else {
/*  181 */         readPdf();
/*      */       }
/*      */     } catch (IOException e) {
/*  184 */       if (closeSourceOnConstructorError)
/*  185 */         byteSource.close();
/*  186 */       throw e;
/*      */     }
/*  188 */     getCounter().read(this.fileLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(String filename)
/*      */     throws IOException
/*      */   {
/*  197 */     this(filename, (byte[])null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(String filename, byte[] ownerPassword)
/*      */     throws IOException
/*      */   {
/*  207 */     this(filename, ownerPassword, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(String filename, byte[] ownerPassword, boolean partial)
/*      */     throws IOException
/*      */   {
/*  219 */     this(new RandomAccessSourceFactory()
/*      */     
/*  221 */       .setForceRead(false)
/*  222 */       .setUsePlainRandomAccess(Document.plainRandomAccess)
/*  223 */       .createBestSource(filename), partial, ownerPassword, null, null, null, null, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(byte[] pdfIn)
/*      */     throws IOException
/*      */   {
/*  240 */     this(pdfIn, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(byte[] pdfIn, byte[] ownerPassword)
/*      */     throws IOException
/*      */   {
/*  250 */     this(new RandomAccessSourceFactory()
/*  251 */       .createSource(pdfIn), false, ownerPassword, null, null, null, null, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(String filename, Certificate certificate, Key certificateKey, String certificateKeyProvider)
/*      */     throws IOException
/*      */   {
/*  272 */     this(new RandomAccessSourceFactory()
/*      */     
/*  274 */       .setForceRead(false)
/*  275 */       .setUsePlainRandomAccess(Document.plainRandomAccess)
/*  276 */       .createBestSource(filename), false, null, certificate, certificateKey, certificateKeyProvider, null, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(String filename, Certificate certificate, ExternalDecryptionProcess externalDecryptionProcess)
/*      */     throws IOException
/*      */   {
/*  298 */     this(new RandomAccessSourceFactory()
/*      */     
/*  300 */       .setForceRead(false)
/*  301 */       .setUsePlainRandomAccess(Document.plainRandomAccess)
/*  302 */       .createBestSource(filename), false, null, certificate, null, null, externalDecryptionProcess, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(byte[] pdfIn, Certificate certificate, ExternalDecryptionProcess externalDecryptionProcess)
/*      */     throws IOException
/*      */   {
/*  323 */     this(new RandomAccessSourceFactory()
/*      */     
/*  325 */       .setForceRead(false)
/*  326 */       .setUsePlainRandomAccess(Document.plainRandomAccess)
/*  327 */       .createSource(pdfIn), false, null, certificate, null, null, externalDecryptionProcess, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(InputStream inputStream, Certificate certificate, ExternalDecryptionProcess externalDecryptionProcess)
/*      */     throws IOException
/*      */   {
/*  348 */     this(new RandomAccessSourceFactory().setForceRead(false).setUsePlainRandomAccess(Document.plainRandomAccess).createSource(inputStream), false, null, certificate, null, null, externalDecryptionProcess, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(URL url)
/*      */     throws IOException
/*      */   {
/*  364 */     this(url, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(URL url, byte[] ownerPassword)
/*      */     throws IOException
/*      */   {
/*  374 */     this(new RandomAccessSourceFactory()
/*  375 */       .createSource(url), false, ownerPassword, null, null, null, null, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(InputStream is, byte[] ownerPassword)
/*      */     throws IOException
/*      */   {
/*  395 */     this(new RandomAccessSourceFactory()
/*  396 */       .createSource(is), false, ownerPassword, null, null, null, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(InputStream is)
/*      */     throws IOException
/*      */   {
/*  415 */     this(is, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(RandomAccessFileOrArray raf, byte[] ownerPassword)
/*      */     throws IOException
/*      */   {
/*  427 */     this(raf, ownerPassword, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(RandomAccessFileOrArray raf, byte[] ownerPassword, boolean partial)
/*      */     throws IOException
/*      */   {
/*  438 */     this(raf
/*  439 */       .getByteSource(), partial, ownerPassword, null, null, null, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfReader(PdfReader reader)
/*      */   {
/*  454 */     this.appendable = reader.appendable;
/*  455 */     this.consolidateNamedDestinations = reader.consolidateNamedDestinations;
/*  456 */     this.encrypted = reader.encrypted;
/*  457 */     this.rebuilt = reader.rebuilt;
/*  458 */     this.sharedStreams = reader.sharedStreams;
/*  459 */     this.tampered = reader.tampered;
/*  460 */     this.password = reader.password;
/*  461 */     this.pdfVersion = reader.pdfVersion;
/*  462 */     this.eofPos = reader.eofPos;
/*  463 */     this.freeXref = reader.freeXref;
/*  464 */     this.lastXref = reader.lastXref;
/*  465 */     this.newXrefType = reader.newXrefType;
/*  466 */     this.tokens = new PRTokeniser(reader.tokens.getSafeFile());
/*  467 */     if (reader.decrypt != null)
/*  468 */       this.decrypt = new PdfEncryption(reader.decrypt);
/*  469 */     this.pValue = reader.pValue;
/*  470 */     this.rValue = reader.rValue;
/*  471 */     this.xrefObj = new ArrayList(reader.xrefObj);
/*  472 */     for (int k = 0; k < reader.xrefObj.size(); k++) {
/*  473 */       this.xrefObj.set(k, duplicatePdfObject((PdfObject)reader.xrefObj.get(k), this));
/*      */     }
/*  475 */     this.pageRefs = new PageRefs(reader.pageRefs, this);
/*  476 */     this.trailer = ((PdfDictionary)duplicatePdfObject(reader.trailer, this));
/*  477 */     this.catalog = this.trailer.getAsDict(PdfName.ROOT);
/*  478 */     this.rootPages = this.catalog.getAsDict(PdfName.PAGES);
/*  479 */     this.fileLength = reader.fileLength;
/*  480 */     this.partial = reader.partial;
/*  481 */     this.hybridXref = reader.hybridXref;
/*  482 */     this.objStmToOffset = reader.objStmToOffset;
/*  483 */     this.xref = reader.xref;
/*  484 */     this.cryptoRef = ((PRIndirectReference)duplicatePdfObject(reader.cryptoRef, this));
/*  485 */     this.ownerPasswordUsed = reader.ownerPasswordUsed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static PRTokeniser getOffsetTokeniser(RandomAccessSource byteSource)
/*      */     throws IOException
/*      */   {
/*  496 */     PRTokeniser tok = new PRTokeniser(new RandomAccessFileOrArray(byteSource));
/*  497 */     int offset = tok.getHeaderOffset();
/*  498 */     if (offset != 0) {
/*  499 */       RandomAccessSource offsetSource = new WindowRandomAccessSource(byteSource, offset);
/*  500 */       tok = new PRTokeniser(new RandomAccessFileOrArray(offsetSource));
/*      */     }
/*  502 */     return tok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RandomAccessFileOrArray getSafeFile()
/*      */   {
/*  510 */     return this.tokens.getSafeFile();
/*      */   }
/*      */   
/*      */   protected PdfReaderInstance getPdfReaderInstance(PdfWriter writer) {
/*  514 */     return new PdfReaderInstance(this, writer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getNumberOfPages()
/*      */   {
/*  521 */     return this.pageRefs.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getCatalog()
/*      */   {
/*  530 */     return this.catalog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PRAcroForm getAcroForm()
/*      */   {
/*  538 */     if (!this.acroFormParsed) {
/*  539 */       this.acroFormParsed = true;
/*  540 */       PdfObject form = this.catalog.get(PdfName.ACROFORM);
/*  541 */       if (form != null) {
/*      */         try {
/*  543 */           this.acroForm = new PRAcroForm(this);
/*  544 */           this.acroForm.readAcroForm((PdfDictionary)getPdfObject(form));
/*      */         }
/*      */         catch (Exception e) {
/*  547 */           this.acroForm = null;
/*      */         }
/*      */       }
/*      */     }
/*  551 */     return this.acroForm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPageRotation(int index)
/*      */   {
/*  559 */     return getPageRotation(this.pageRefs.getPageNRelease(index));
/*      */   }
/*      */   
/*      */   int getPageRotation(PdfDictionary page) {
/*  563 */     PdfNumber rotate = page.getAsNumber(PdfName.ROTATE);
/*  564 */     if (rotate == null) {
/*  565 */       return 0;
/*      */     }
/*  567 */     int n = rotate.intValue();
/*  568 */     n %= 360;
/*  569 */     return n < 0 ? n + 360 : n;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getPageSizeWithRotation(int index)
/*      */   {
/*  578 */     return getPageSizeWithRotation(this.pageRefs.getPageNRelease(index));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getPageSizeWithRotation(PdfDictionary page)
/*      */   {
/*  587 */     Rectangle rect = getPageSize(page);
/*  588 */     int rotation = getPageRotation(page);
/*  589 */     while (rotation > 0) {
/*  590 */       rect = rect.rotate();
/*  591 */       rotation -= 90;
/*      */     }
/*  593 */     return rect;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getPageSize(int index)
/*      */   {
/*  602 */     return getPageSize(this.pageRefs.getPageNRelease(index));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getPageSize(PdfDictionary page)
/*      */   {
/*  611 */     PdfArray mediaBox = page.getAsArray(PdfName.MEDIABOX);
/*  612 */     return getNormalizedRectangle(mediaBox);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getCropBox(int index)
/*      */   {
/*  624 */     PdfDictionary page = this.pageRefs.getPageNRelease(index);
/*  625 */     PdfArray cropBox = (PdfArray)getPdfObjectRelease(page.get(PdfName.CROPBOX));
/*  626 */     if (cropBox == null)
/*  627 */       return getPageSize(page);
/*  628 */     return getNormalizedRectangle(cropBox);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBoxSize(int index, String boxName)
/*      */   {
/*  637 */     PdfDictionary page = this.pageRefs.getPageNRelease(index);
/*  638 */     PdfArray box = null;
/*  639 */     if (boxName.equals("trim")) {
/*  640 */       box = (PdfArray)getPdfObjectRelease(page.get(PdfName.TRIMBOX));
/*  641 */     } else if (boxName.equals("art")) {
/*  642 */       box = (PdfArray)getPdfObjectRelease(page.get(PdfName.ARTBOX));
/*  643 */     } else if (boxName.equals("bleed")) {
/*  644 */       box = (PdfArray)getPdfObjectRelease(page.get(PdfName.BLEEDBOX));
/*  645 */     } else if (boxName.equals("crop")) {
/*  646 */       box = (PdfArray)getPdfObjectRelease(page.get(PdfName.CROPBOX));
/*  647 */     } else if (boxName.equals("media"))
/*  648 */       box = (PdfArray)getPdfObjectRelease(page.get(PdfName.MEDIABOX));
/*  649 */     if (box == null)
/*  650 */       return null;
/*  651 */     return getNormalizedRectangle(box);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<String, String> getInfo()
/*      */   {
/*  660 */     HashMap<String, String> map = new HashMap();
/*  661 */     PdfDictionary info = this.trailer.getAsDict(PdfName.INFO);
/*  662 */     if (info == null)
/*  663 */       return map;
/*  664 */     for (Object element : info.getKeys()) {
/*  665 */       PdfName key = (PdfName)element;
/*  666 */       PdfObject obj = getPdfObject(info.get(key));
/*  667 */       if (obj != null)
/*      */       {
/*  669 */         String value = obj.toString();
/*  670 */         switch (obj.type()) {
/*      */         case 3: 
/*  672 */           value = ((PdfString)obj).toUnicodeString();
/*  673 */           break;
/*      */         
/*      */         case 4: 
/*  676 */           value = PdfName.decodeName(value);
/*      */         }
/*      */         
/*      */         
/*  680 */         map.put(PdfName.decodeName(key.toString()), value);
/*      */       } }
/*  682 */     return map;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Rectangle getNormalizedRectangle(PdfArray box)
/*      */   {
/*  690 */     float llx = ((PdfNumber)getPdfObjectRelease(box.getPdfObject(0))).floatValue();
/*  691 */     float lly = ((PdfNumber)getPdfObjectRelease(box.getPdfObject(1))).floatValue();
/*  692 */     float urx = ((PdfNumber)getPdfObjectRelease(box.getPdfObject(2))).floatValue();
/*  693 */     float ury = ((PdfNumber)getPdfObjectRelease(box.getPdfObject(3))).floatValue();
/*      */     
/*  695 */     return new Rectangle(Math.min(llx, urx), Math.min(lly, ury), Math.max(llx, urx), Math.max(lly, ury));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isTagged()
/*      */   {
/*  702 */     PdfDictionary markInfo = this.catalog.getAsDict(PdfName.MARKINFO);
/*  703 */     if (markInfo == null)
/*  704 */       return false;
/*  705 */     if (PdfBoolean.PDFTRUE.equals(markInfo.getAsBoolean(PdfName.MARKED))) {
/*  706 */       return this.catalog.getAsDict(PdfName.STRUCTTREEROOT) != null;
/*      */     }
/*  708 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void readPdf()
/*      */     throws IOException
/*      */   {
/*  716 */     this.fileLength = this.tokens.getFile().length();
/*  717 */     this.pdfVersion = this.tokens.checkPdfHeader();
/*      */     try {
/*  719 */       readXref();
/*      */     }
/*      */     catch (Exception e) {
/*      */       try {
/*  723 */         this.rebuilt = true;
/*  724 */         rebuildXref();
/*  725 */         this.lastXref = -1L;
/*      */       }
/*      */       catch (Exception ne) {
/*  728 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("rebuild.failed.1.original.message.2", new Object[] { ne.getMessage(), e.getMessage() }));
/*      */       }
/*      */     }
/*      */     try {
/*  732 */       readDocObj();
/*      */     }
/*      */     catch (Exception e) {
/*  735 */       if ((e instanceof BadPasswordException))
/*  736 */         throw new BadPasswordException(e.getMessage());
/*  737 */       if ((this.rebuilt) || (this.encryptionError))
/*  738 */         throw new InvalidPdfException(e.getMessage());
/*  739 */       this.rebuilt = true;
/*  740 */       this.encrypted = false;
/*      */       try {
/*  742 */         rebuildXref();
/*  743 */         this.lastXref = -1L;
/*  744 */         readDocObj();
/*      */       } catch (Exception ne) {
/*  746 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("rebuild.failed.1.original.message.2", new Object[] { ne.getMessage(), e.getMessage() }));
/*      */       }
/*      */     }
/*  749 */     this.strings.clear();
/*  750 */     readPages();
/*      */     
/*  752 */     removeUnusedObjects();
/*      */   }
/*      */   
/*      */   protected void readPdfPartial() throws IOException
/*      */   {
/*  757 */     this.fileLength = this.tokens.getFile().length();
/*  758 */     this.pdfVersion = this.tokens.checkPdfHeader();
/*      */     try {
/*  760 */       readXref();
/*      */     }
/*      */     catch (Exception e) {
/*      */       try {
/*  764 */         this.rebuilt = true;
/*  765 */         rebuildXref();
/*  766 */         this.lastXref = -1L;
/*      */       }
/*      */       catch (Exception ne) {
/*  769 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("rebuild.failed.1.original.message.2", new Object[] {ne
/*      */         
/*  771 */           .getMessage(), e.getMessage() }), ne);
/*      */       }
/*      */     }
/*  774 */     readDocObjPartial();
/*  775 */     readPages();
/*      */   }
/*      */   
/*      */   private boolean equalsArray(byte[] ar1, byte[] ar2, int size) {
/*  779 */     for (int k = 0; k < size; k++) {
/*  780 */       if (ar1[k] != ar2[k])
/*  781 */         return false;
/*      */     }
/*  783 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void readDecryptedDocObj()
/*      */     throws IOException
/*      */   {
/*  791 */     if (this.encrypted)
/*  792 */       return;
/*  793 */     PdfObject encDic = this.trailer.get(PdfName.ENCRYPT);
/*  794 */     if ((encDic == null) || (encDic.toString().equals("null")))
/*  795 */       return;
/*  796 */     this.encryptionError = true;
/*  797 */     byte[] encryptionKey = null;
/*  798 */     this.encrypted = true;
/*  799 */     PdfDictionary enc = (PdfDictionary)getPdfObject(encDic);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  804 */     PdfArray documentIDs = this.trailer.getAsArray(PdfName.ID);
/*  805 */     byte[] documentID = null;
/*  806 */     if (documentIDs != null) {
/*  807 */       PdfObject o = documentIDs.getPdfObject(0);
/*  808 */       this.strings.remove(o);
/*  809 */       String s = o.toString();
/*  810 */       documentID = DocWriter.getISOBytes(s);
/*  811 */       if (documentIDs.size() > 1) {
/*  812 */         this.strings.remove(documentIDs.getPdfObject(1));
/*      */       }
/*      */     }
/*  815 */     if (documentID == null)
/*  816 */       documentID = new byte[0];
/*  817 */     byte[] uValue = null;
/*  818 */     byte[] oValue = null;
/*  819 */     int cryptoMode = 0;
/*  820 */     int lengthValue = 0;
/*      */     
/*  822 */     PdfObject filter = getPdfObjectRelease(enc.get(PdfName.FILTER));
/*      */     
/*  824 */     if (filter.equals(PdfName.STANDARD)) {
/*  825 */       String s = enc.get(PdfName.U).toString();
/*  826 */       this.strings.remove(enc.get(PdfName.U));
/*  827 */       uValue = DocWriter.getISOBytes(s);
/*  828 */       s = enc.get(PdfName.O).toString();
/*  829 */       this.strings.remove(enc.get(PdfName.O));
/*  830 */       oValue = DocWriter.getISOBytes(s);
/*  831 */       if (enc.contains(PdfName.OE))
/*  832 */         this.strings.remove(enc.get(PdfName.OE));
/*  833 */       if (enc.contains(PdfName.UE))
/*  834 */         this.strings.remove(enc.get(PdfName.UE));
/*  835 */       if (enc.contains(PdfName.PERMS)) {
/*  836 */         this.strings.remove(enc.get(PdfName.PERMS));
/*      */       }
/*  838 */       PdfObject o = enc.get(PdfName.P);
/*  839 */       if (!o.isNumber())
/*  840 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.p.value", new Object[0]));
/*  841 */       this.pValue = ((PdfNumber)o).longValue();
/*      */       
/*  843 */       o = enc.get(PdfName.R);
/*  844 */       if (!o.isNumber())
/*  845 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.r.value", new Object[0]));
/*  846 */       this.rValue = ((PdfNumber)o).intValue();
/*      */       
/*  848 */       switch (this.rValue) {
/*      */       case 2: 
/*  850 */         cryptoMode = 0;
/*  851 */         break;
/*      */       case 3: 
/*  853 */         o = enc.get(PdfName.LENGTH);
/*  854 */         if (!o.isNumber())
/*  855 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.length.value", new Object[0]));
/*  856 */         lengthValue = ((PdfNumber)o).intValue();
/*  857 */         if ((lengthValue > 128) || (lengthValue < 40) || (lengthValue % 8 != 0))
/*  858 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.length.value", new Object[0]));
/*  859 */         cryptoMode = 1;
/*  860 */         break;
/*      */       case 4: 
/*  862 */         PdfDictionary dic = (PdfDictionary)enc.get(PdfName.CF);
/*  863 */         if (dic == null)
/*  864 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("cf.not.found.encryption", new Object[0]));
/*  865 */         dic = (PdfDictionary)dic.get(PdfName.STDCF);
/*  866 */         if (dic == null)
/*  867 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("stdcf.not.found.encryption", new Object[0]));
/*  868 */         if (PdfName.V2.equals(dic.get(PdfName.CFM))) {
/*  869 */           cryptoMode = 1;
/*  870 */         } else if (PdfName.AESV2.equals(dic.get(PdfName.CFM))) {
/*  871 */           cryptoMode = 2;
/*      */         } else
/*  873 */           throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("no.compatible.encryption.found", new Object[0]));
/*  874 */         PdfObject em = enc.get(PdfName.ENCRYPTMETADATA);
/*  875 */         if ((em == null) || (!em.toString().equals("false"))) break;
/*  876 */         cryptoMode |= 0x8; break;
/*      */       
/*      */       case 5: 
/*  879 */         cryptoMode = 3;
/*  880 */         PdfObject em5 = enc.get(PdfName.ENCRYPTMETADATA);
/*  881 */         if ((em5 == null) || (!em5.toString().equals("false"))) break;
/*  882 */         cryptoMode |= 0x8; break;
/*      */       
/*      */       default: 
/*  885 */         throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("unknown.encryption.type.r.eq.1", this.rValue));
/*      */       }
/*      */     }
/*  888 */     else if (filter.equals(PdfName.PUBSEC)) {
/*  889 */       boolean foundRecipient = false;
/*  890 */       byte[] envelopedData = null;
/*  891 */       PdfArray recipients = null;
/*      */       
/*  893 */       PdfObject o = enc.get(PdfName.V);
/*  894 */       if (!o.isNumber())
/*  895 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.v.value", new Object[0]));
/*  896 */       int vValue = ((PdfNumber)o).intValue();
/*  897 */       switch (vValue) {
/*      */       case 1: 
/*  899 */         cryptoMode = 0;
/*  900 */         lengthValue = 40;
/*  901 */         recipients = (PdfArray)enc.get(PdfName.RECIPIENTS);
/*  902 */         break;
/*      */       case 2: 
/*  904 */         o = enc.get(PdfName.LENGTH);
/*  905 */         if (!o.isNumber())
/*  906 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.length.value", new Object[0]));
/*  907 */         lengthValue = ((PdfNumber)o).intValue();
/*  908 */         if ((lengthValue > 128) || (lengthValue < 40) || (lengthValue % 8 != 0))
/*  909 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.length.value", new Object[0]));
/*  910 */         cryptoMode = 1;
/*  911 */         recipients = (PdfArray)enc.get(PdfName.RECIPIENTS);
/*  912 */         break;
/*      */       case 4: 
/*      */       case 5: 
/*  915 */         PdfDictionary dic = (PdfDictionary)enc.get(PdfName.CF);
/*  916 */         if (dic == null)
/*  917 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("cf.not.found.encryption", new Object[0]));
/*  918 */         dic = (PdfDictionary)dic.get(PdfName.DEFAULTCRYPTFILTER);
/*  919 */         if (dic == null)
/*  920 */           throw new InvalidPdfException(MessageLocalization.getComposedMessage("defaultcryptfilter.not.found.encryption", new Object[0]));
/*  921 */         if (PdfName.V2.equals(dic.get(PdfName.CFM))) {
/*  922 */           cryptoMode = 1;
/*  923 */           lengthValue = 128;
/*      */         }
/*  925 */         else if (PdfName.AESV2.equals(dic.get(PdfName.CFM))) {
/*  926 */           cryptoMode = 2;
/*  927 */           lengthValue = 128;
/*      */         }
/*  929 */         else if (PdfName.AESV3.equals(dic.get(PdfName.CFM))) {
/*  930 */           cryptoMode = 3;
/*  931 */           lengthValue = 256;
/*      */         }
/*      */         else {
/*  934 */           throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("no.compatible.encryption.found", new Object[0])); }
/*  935 */         PdfObject em = dic.get(PdfName.ENCRYPTMETADATA);
/*  936 */         if ((em != null) && (em.toString().equals("false"))) {
/*  937 */           cryptoMode |= 0x8;
/*      */         }
/*  939 */         recipients = (PdfArray)dic.get(PdfName.RECIPIENTS);
/*  940 */         break;
/*      */       case 3: default: 
/*  942 */         throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("unknown.encryption.type.v.eq.1", vValue));
/*      */       }
/*      */       try
/*      */       {
/*  946 */         certHolder = new X509CertificateHolder(this.certificate.getEncoded());
/*      */       } catch (Exception f) {
/*      */         X509CertificateHolder certHolder;
/*  949 */         throw new ExceptionConverter(f); }
/*      */       X509CertificateHolder certHolder;
/*  951 */       if (this.externalDecryptionProcess == null) {
/*  952 */         for (int i = 0; i < recipients.size(); i++) {
/*  953 */           PdfObject recipient = recipients.getPdfObject(i);
/*  954 */           this.strings.remove(recipient);
/*      */           
/*  956 */           CMSEnvelopedData data = null;
/*      */           try {
/*  958 */             data = new CMSEnvelopedData(recipient.getBytes());
/*      */             
/*  960 */             Iterator<RecipientInformation> recipientCertificatesIt = data.getRecipientInfos().getRecipients().iterator();
/*      */             
/*  962 */             while (recipientCertificatesIt.hasNext()) {
/*  963 */               RecipientInformation recipientInfo = (RecipientInformation)recipientCertificatesIt.next();
/*      */               
/*  965 */               if ((recipientInfo.getRID().match(certHolder)) && (!foundRecipient)) {
/*  966 */                 envelopedData = PdfEncryptor.getContent(recipientInfo, (PrivateKey)this.certificateKey, this.certificateKeyProvider);
/*  967 */                 foundRecipient = true;
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception f) {
/*  972 */             throw new ExceptionConverter(f);
/*      */           }
/*      */         }
/*      */       } else {
/*  976 */         for (int i = 0; i < recipients.size(); i++) {
/*  977 */           PdfObject recipient = recipients.getPdfObject(i);
/*  978 */           this.strings.remove(recipient);
/*      */           
/*  980 */           CMSEnvelopedData data = null;
/*      */           try {
/*  982 */             data = new CMSEnvelopedData(recipient.getBytes());
/*      */             
/*      */ 
/*  985 */             RecipientInformation recipientInfo = data.getRecipientInfos().get(this.externalDecryptionProcess.getCmsRecipientId());
/*      */             
/*  987 */             if (recipientInfo != null)
/*      */             {
/*  989 */               envelopedData = recipientInfo.getContent(this.externalDecryptionProcess.getCmsRecipient());
/*  990 */               foundRecipient = true;
/*      */             }
/*      */           } catch (Exception f) {
/*  993 */             throw new ExceptionConverter(f);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  998 */       if ((!foundRecipient) || (envelopedData == null)) {
/*  999 */         throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("bad.certificate.and.key", new Object[0]));
/*      */       }
/*      */       
/* 1002 */       MessageDigest md = null;
/*      */       try
/*      */       {
/* 1005 */         if ((cryptoMode & 0x7) == 3) {
/* 1006 */           md = MessageDigest.getInstance("SHA-256");
/*      */         } else
/* 1008 */           md = MessageDigest.getInstance("SHA-1");
/* 1009 */         md.update(envelopedData, 0, 20);
/* 1010 */         for (int i = 0; i < recipients.size(); i++) {
/* 1011 */           byte[] encodedRecipient = recipients.getPdfObject(i).getBytes();
/* 1012 */           md.update(encodedRecipient);
/*      */         }
/* 1014 */         if ((cryptoMode & 0x8) != 0)
/* 1015 */           md.update(new byte[] { -1, -1, -1, -1 });
/* 1016 */         encryptionKey = md.digest();
/*      */       }
/*      */       catch (Exception f) {
/* 1019 */         throw new ExceptionConverter(f);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1024 */     this.decrypt = new PdfEncryption();
/* 1025 */     this.decrypt.setCryptoMode(cryptoMode, lengthValue);
/*      */     
/* 1027 */     if (filter.equals(PdfName.STANDARD)) {
/* 1028 */       if (this.rValue == 5) {
/* 1029 */         this.ownerPasswordUsed = this.decrypt.readKey(enc, this.password);
/* 1030 */         this.decrypt.documentID = documentID;
/* 1031 */         this.pValue = this.decrypt.getPermissions();
/*      */       }
/*      */       else
/*      */       {
/* 1035 */         this.decrypt.setupByOwnerPassword(documentID, this.password, uValue, oValue, this.pValue);
/* 1036 */         if (!equalsArray(uValue, this.decrypt.userKey, (this.rValue == 3) || (this.rValue == 4) ? 16 : 32))
/*      */         {
/* 1038 */           this.decrypt.setupByUserPassword(documentID, this.password, oValue, this.pValue);
/* 1039 */           if (!equalsArray(uValue, this.decrypt.userKey, (this.rValue == 3) || (this.rValue == 4) ? 16 : 32)) {
/* 1040 */             throw new BadPasswordException(MessageLocalization.getComposedMessage("bad.user.password", new Object[0]));
/*      */           }
/*      */         }
/*      */         else {
/* 1044 */           this.ownerPasswordUsed = true;
/*      */         }
/*      */       }
/* 1047 */     } else if (filter.equals(PdfName.PUBSEC)) {
/* 1048 */       if ((cryptoMode & 0x7) == 3) {
/* 1049 */         this.decrypt.setKey(encryptionKey);
/*      */       } else
/* 1051 */         this.decrypt.setupByEncryptionKey(encryptionKey, lengthValue);
/* 1052 */       this.ownerPasswordUsed = true;
/*      */     }
/*      */     
/* 1055 */     for (int k = 0; k < this.strings.size(); k++) {
/* 1056 */       PdfString str = (PdfString)this.strings.get(k);
/* 1057 */       str.decrypt(this);
/*      */     }
/*      */     
/* 1060 */     if (encDic.isIndirect()) {
/* 1061 */       this.cryptoRef = ((PRIndirectReference)encDic);
/* 1062 */       this.xrefObj.set(this.cryptoRef.getNumber(), null);
/*      */     }
/* 1064 */     this.encryptionError = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfObject getPdfObjectRelease(PdfObject obj)
/*      */   {
/* 1072 */     PdfObject obj2 = getPdfObject(obj);
/* 1073 */     releaseLastXrefPartial(obj);
/* 1074 */     return obj2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfObject getPdfObject(PdfObject obj)
/*      */   {
/* 1085 */     if (obj == null)
/* 1086 */       return null;
/* 1087 */     if (!obj.isIndirect())
/* 1088 */       return obj;
/*      */     try {
/* 1090 */       PRIndirectReference ref = (PRIndirectReference)obj;
/* 1091 */       int idx = ref.getNumber();
/* 1092 */       boolean appendable = ref.getReader().appendable;
/* 1093 */       obj = ref.getReader().getPdfObject(idx);
/* 1094 */       if (obj == null) {
/* 1095 */         return null;
/*      */       }
/*      */       
/* 1098 */       if (appendable) {
/* 1099 */         switch (obj.type()) {
/*      */         case 8: 
/* 1101 */           obj = new PdfNull();
/* 1102 */           break;
/*      */         case 1: 
/* 1104 */           obj = new PdfBoolean(((PdfBoolean)obj).booleanValue());
/* 1105 */           break;
/*      */         case 4: 
/* 1107 */           obj = new PdfName(obj.getBytes());
/*      */         }
/*      */         
/* 1110 */         obj.setIndRef(ref);
/*      */       }
/* 1112 */       return obj;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1116 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfObject getPdfObjectRelease(PdfObject obj, PdfObject parent)
/*      */   {
/* 1129 */     PdfObject obj2 = getPdfObject(obj, parent);
/* 1130 */     releaseLastXrefPartial(obj);
/* 1131 */     return obj2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfObject getPdfObject(PdfObject obj, PdfObject parent)
/*      */   {
/* 1140 */     if (obj == null)
/* 1141 */       return null;
/* 1142 */     if (!obj.isIndirect()) {
/* 1143 */       PRIndirectReference ref = null;
/* 1144 */       if ((parent != null) && ((ref = parent.getIndRef()) != null) && (ref.getReader().isAppendable())) {
/* 1145 */         switch (obj.type()) {
/*      */         case 8: 
/* 1147 */           obj = new PdfNull();
/* 1148 */           break;
/*      */         case 1: 
/* 1150 */           obj = new PdfBoolean(((PdfBoolean)obj).booleanValue());
/* 1151 */           break;
/*      */         case 4: 
/* 1153 */           obj = new PdfName(obj.getBytes());
/*      */         }
/*      */         
/* 1156 */         obj.setIndRef(ref);
/*      */       }
/* 1158 */       return obj;
/*      */     }
/* 1160 */     return getPdfObject(obj);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfObject getPdfObjectRelease(int idx)
/*      */   {
/* 1168 */     PdfObject obj = getPdfObject(idx);
/* 1169 */     releaseLastXrefPartial();
/* 1170 */     return obj;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public PdfObject getPdfObject(int idx)
/*      */   {
/*      */     try
/*      */     {
/* 1179 */       this.lastXrefPartial = -1;
/* 1180 */       if ((idx < 0) || (idx >= this.xrefObj.size()))
/* 1181 */         return null;
/* 1182 */       PdfObject obj = (PdfObject)this.xrefObj.get(idx);
/* 1183 */       if ((!this.partial) || (obj != null))
/* 1184 */         return obj;
/* 1185 */       if (idx * 2 >= this.xref.length)
/* 1186 */         return null;
/* 1187 */       obj = readSingleObject(idx);
/* 1188 */       this.lastXrefPartial = -1;
/* 1189 */       if (obj != null)
/* 1190 */         this.lastXrefPartial = idx;
/* 1191 */       return obj;
/*      */     }
/*      */     catch (Exception e) {
/* 1194 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void resetLastXrefPartial()
/*      */   {
/* 1202 */     this.lastXrefPartial = -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void releaseLastXrefPartial()
/*      */   {
/* 1209 */     if ((this.partial) && (this.lastXrefPartial != -1)) {
/* 1210 */       this.xrefObj.set(this.lastXrefPartial, null);
/* 1211 */       this.lastXrefPartial = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void releaseLastXrefPartial(PdfObject obj)
/*      */   {
/* 1219 */     if (obj == null)
/* 1220 */       return;
/* 1221 */     if (!obj.isIndirect())
/* 1222 */       return;
/* 1223 */     if (!(obj instanceof PRIndirectReference)) {
/* 1224 */       return;
/*      */     }
/* 1226 */     PRIndirectReference ref = (PRIndirectReference)obj;
/* 1227 */     PdfReader reader = ref.getReader();
/* 1228 */     if ((reader.partial) && (reader.lastXrefPartial != -1) && (reader.lastXrefPartial == ref.getNumber())) {
/* 1229 */       reader.xrefObj.set(reader.lastXrefPartial, null);
/*      */     }
/* 1231 */     reader.lastXrefPartial = -1;
/*      */   }
/*      */   
/*      */   private void setXrefPartialObject(int idx, PdfObject obj) {
/* 1235 */     if ((!this.partial) || (idx < 0))
/* 1236 */       return;
/* 1237 */     this.xrefObj.set(idx, obj);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PRIndirectReference addPdfObject(PdfObject obj)
/*      */   {
/* 1245 */     this.xrefObj.add(obj);
/* 1246 */     return new PRIndirectReference(this, this.xrefObj.size() - 1);
/*      */   }
/*      */   
/*      */   protected void readPages() throws IOException {
/* 1250 */     this.catalog = this.trailer.getAsDict(PdfName.ROOT);
/* 1251 */     if (this.catalog == null) {
/* 1252 */       throw new InvalidPdfException(MessageLocalization.getComposedMessage("the.document.has.no.catalog.object", new Object[0]));
/*      */     }
/* 1254 */     this.rootPages = this.catalog.getAsDict(PdfName.PAGES);
/* 1255 */     if ((this.rootPages == null) || (!PdfName.PAGES.equals(this.rootPages.get(PdfName.TYPE)))) {
/* 1256 */       if (debugmode) {
/* 1257 */         if (LOGGER.isLogging(Level.ERROR)) {
/* 1258 */           LOGGER.error(MessageLocalization.getComposedMessage("the.document.has.no.page.root", new Object[0]));
/*      */         }
/*      */       }
/*      */       else {
/* 1262 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("the.document.has.no.page.root", new Object[0]));
/*      */       }
/*      */     }
/* 1265 */     this.pageRefs = new PageRefs(this, null);
/*      */   }
/*      */   
/*      */   protected void readDocObjPartial() throws IOException {
/* 1269 */     this.xrefObj = new ArrayList(this.xref.length / 2);
/* 1270 */     this.xrefObj.addAll(Collections.nCopies(this.xref.length / 2, null));
/* 1271 */     readDecryptedDocObj();
/* 1272 */     if (this.objStmToOffset != null) {
/* 1273 */       long[] keys = this.objStmToOffset.getKeys();
/* 1274 */       for (int k = 0; k < keys.length; k++) {
/* 1275 */         long n = keys[k];
/* 1276 */         this.objStmToOffset.put(n, this.xref[((int)(n * 2L))]);
/* 1277 */         this.xref[((int)(n * 2L))] = -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected PdfObject readSingleObject(int k) throws IOException {
/* 1283 */     this.strings.clear();
/* 1284 */     int k2 = k * 2;
/* 1285 */     long pos = this.xref[k2];
/* 1286 */     if (pos < 0L)
/* 1287 */       return null;
/* 1288 */     if (this.xref[(k2 + 1)] > 0L)
/* 1289 */       pos = this.objStmToOffset.get(this.xref[(k2 + 1)]);
/* 1290 */     if (pos == 0L)
/* 1291 */       return null;
/* 1292 */     this.tokens.seek(pos);
/* 1293 */     this.tokens.nextValidToken();
/* 1294 */     if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1295 */       this.tokens.throwError(MessageLocalization.getComposedMessage("invalid.object.number", new Object[0]));
/* 1296 */     this.objNum = this.tokens.intValue();
/* 1297 */     this.tokens.nextValidToken();
/* 1298 */     if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1299 */       this.tokens.throwError(MessageLocalization.getComposedMessage("invalid.generation.number", new Object[0]));
/* 1300 */     this.objGen = this.tokens.intValue();
/* 1301 */     this.tokens.nextValidToken();
/* 1302 */     if (!this.tokens.getStringValue().equals("obj")) {
/* 1303 */       this.tokens.throwError(MessageLocalization.getComposedMessage("token.obj.expected", new Object[0]));
/*      */     }
/*      */     try {
/* 1306 */       PdfObject obj = readPRObject();
/* 1307 */       for (int j = 0; j < this.strings.size(); j++) {
/* 1308 */         PdfString str = (PdfString)this.strings.get(j);
/* 1309 */         str.decrypt(this);
/*      */       }
/* 1311 */       if (obj.isStream()) {
/* 1312 */         checkPRStreamLength((PRStream)obj);
/*      */       }
/*      */     } catch (IOException e) {
/*      */       PdfObject obj;
/* 1316 */       if (debugmode) {
/* 1317 */         if (LOGGER.isLogging(Level.ERROR))
/* 1318 */           LOGGER.error(e.getMessage(), e);
/* 1319 */         obj = null;
/*      */       }
/*      */       else {
/* 1322 */         throw e; } }
/*      */     PdfObject obj;
/* 1324 */     if (this.xref[(k2 + 1)] > 0L) {
/* 1325 */       obj = readOneObjStm((PRStream)obj, (int)this.xref[k2]);
/*      */     }
/* 1327 */     this.xrefObj.set(k, obj);
/* 1328 */     return obj;
/*      */   }
/*      */   
/*      */   protected PdfObject readOneObjStm(PRStream stream, int idx) throws IOException {
/* 1332 */     int first = stream.getAsNumber(PdfName.FIRST).intValue();
/* 1333 */     byte[] b = getStreamBytes(stream, this.tokens.getFile());
/* 1334 */     PRTokeniser saveTokens = this.tokens;
/* 1335 */     this.tokens = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(b)));
/*      */     try {
/* 1337 */       int address = 0;
/* 1338 */       boolean ok = true;
/* 1339 */       idx++;
/* 1340 */       for (int k = 0; k < idx; k++) {
/* 1341 */         ok = this.tokens.nextToken();
/* 1342 */         if (!ok)
/*      */           break;
/* 1344 */         if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER) {
/* 1345 */           ok = false;
/* 1346 */           break;
/*      */         }
/* 1348 */         ok = this.tokens.nextToken();
/* 1349 */         if (!ok)
/*      */           break;
/* 1351 */         if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER) {
/* 1352 */           ok = false;
/* 1353 */           break;
/*      */         }
/* 1355 */         address = this.tokens.intValue() + first;
/*      */       }
/* 1357 */       if (!ok)
/* 1358 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("error.reading.objstm", new Object[0]));
/* 1359 */       this.tokens.seek(address);
/* 1360 */       this.tokens.nextToken();
/*      */       PdfObject obj;
/* 1362 */       PdfObject obj; if (this.tokens.getTokenType() == PRTokeniser.TokenType.NUMBER) {
/* 1363 */         obj = new PdfNumber(this.tokens.getStringValue());
/*      */       }
/*      */       else {
/* 1366 */         this.tokens.seek(address);
/* 1367 */         obj = readPRObject();
/*      */       }
/* 1369 */       return obj;
/*      */     }
/*      */     finally
/*      */     {
/* 1373 */       this.tokens = saveTokens;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public double dumpPerc()
/*      */   {
/* 1381 */     int total = 0;
/* 1382 */     for (int k = 0; k < this.xrefObj.size(); k++) {
/* 1383 */       if (this.xrefObj.get(k) != null)
/* 1384 */         total++;
/*      */     }
/* 1386 */     return total * 100.0D / this.xrefObj.size();
/*      */   }
/*      */   
/*      */   protected void readDocObj() throws IOException {
/* 1390 */     ArrayList<PRStream> streams = new ArrayList();
/* 1391 */     this.xrefObj = new ArrayList(this.xref.length / 2);
/* 1392 */     this.xrefObj.addAll(Collections.nCopies(this.xref.length / 2, null));
/* 1393 */     for (int k = 2; k < this.xref.length; k += 2) {
/* 1394 */       long pos = this.xref[k];
/* 1395 */       if ((pos > 0L) && (this.xref[(k + 1)] <= 0L))
/*      */       {
/* 1397 */         this.tokens.seek(pos);
/* 1398 */         this.tokens.nextValidToken();
/* 1399 */         if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1400 */           this.tokens.throwError(MessageLocalization.getComposedMessage("invalid.object.number", new Object[0]));
/* 1401 */         this.objNum = this.tokens.intValue();
/* 1402 */         this.tokens.nextValidToken();
/* 1403 */         if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1404 */           this.tokens.throwError(MessageLocalization.getComposedMessage("invalid.generation.number", new Object[0]));
/* 1405 */         this.objGen = this.tokens.intValue();
/* 1406 */         this.tokens.nextValidToken();
/* 1407 */         if (!this.tokens.getStringValue().equals("obj")) {
/* 1408 */           this.tokens.throwError(MessageLocalization.getComposedMessage("token.obj.expected", new Object[0]));
/*      */         }
/*      */         try {
/* 1411 */           PdfObject obj = readPRObject();
/* 1412 */           if (obj.isStream()) {
/* 1413 */             streams.add((PRStream)obj);
/*      */           }
/*      */         } catch (IOException e) {
/*      */           PdfObject obj;
/* 1417 */           if (debugmode) {
/* 1418 */             if (LOGGER.isLogging(Level.ERROR))
/* 1419 */               LOGGER.error(e.getMessage(), e);
/* 1420 */             obj = null;
/*      */           }
/*      */           else {
/* 1423 */             throw e; } }
/*      */         PdfObject obj;
/* 1425 */         this.xrefObj.set(k / 2, obj);
/*      */       } }
/* 1427 */     for (int k = 0; k < streams.size(); k++) {
/* 1428 */       checkPRStreamLength((PRStream)streams.get(k));
/*      */     }
/* 1430 */     readDecryptedDocObj();
/* 1431 */     if (this.objStmMark != null) {
/* 1432 */       for (Map.Entry<Integer, IntHashtable> entry : this.objStmMark.entrySet()) {
/* 1433 */         int n = ((Integer)entry.getKey()).intValue();
/* 1434 */         IntHashtable h = (IntHashtable)entry.getValue();
/* 1435 */         readObjStm((PRStream)this.xrefObj.get(n), h);
/* 1436 */         this.xrefObj.set(n, null);
/*      */       }
/* 1438 */       this.objStmMark = null;
/*      */     }
/* 1440 */     this.xref = null;
/*      */   }
/*      */   
/*      */   private void checkPRStreamLength(PRStream stream) throws IOException {
/* 1444 */     long fileLength = this.tokens.length();
/* 1445 */     long start = stream.getOffset();
/* 1446 */     boolean calc = false;
/* 1447 */     long streamLength = 0L;
/* 1448 */     PdfObject obj = getPdfObjectRelease(stream.get(PdfName.LENGTH));
/* 1449 */     if ((obj != null) && (obj.type() == 2)) {
/* 1450 */       streamLength = ((PdfNumber)obj).intValue();
/* 1451 */       if (streamLength + start > fileLength - 20L) {
/* 1452 */         calc = true;
/*      */       } else {
/* 1454 */         this.tokens.seek(start + streamLength);
/* 1455 */         String line = this.tokens.readString(20);
/* 1456 */         if ((!line.startsWith("\nendstream")) && 
/* 1457 */           (!line.startsWith("\r\nendstream")) && 
/* 1458 */           (!line.startsWith("\rendstream")) && 
/* 1459 */           (!line.startsWith("endstream"))) {
/* 1460 */           calc = true;
/*      */         }
/*      */       }
/*      */     } else {
/* 1464 */       calc = true; }
/* 1465 */     if (calc) {
/* 1466 */       byte[] tline = new byte[16];
/* 1467 */       this.tokens.seek(start);
/*      */       long pos;
/*      */       do {
/* 1470 */         pos = this.tokens.getFilePointer();
/* 1471 */         if (!this.tokens.readLineSegment(tline, false))
/*      */           break;
/* 1473 */         if (equalsn(tline, endstream)) {
/* 1474 */           streamLength = pos - start;
/* 1475 */           break;
/*      */         }
/* 1477 */       } while (!equalsn(tline, endobj));
/* 1478 */       this.tokens.seek(pos - 16L);
/* 1479 */       String s = this.tokens.readString(16);
/* 1480 */       int index = s.indexOf("endstream");
/* 1481 */       if (index >= 0)
/* 1482 */         pos = pos - 16L + index;
/* 1483 */       streamLength = pos - start;
/*      */       
/*      */ 
/*      */ 
/* 1487 */       this.tokens.seek(pos - 2L);
/* 1488 */       if (this.tokens.read() == 13)
/* 1489 */         streamLength -= 1L;
/* 1490 */       this.tokens.seek(pos - 1L);
/* 1491 */       if (this.tokens.read() == 10) {
/* 1492 */         streamLength -= 1L;
/*      */       }
/* 1494 */       if (streamLength < 0L) {
/* 1495 */         streamLength = 0L;
/*      */       }
/*      */     }
/* 1498 */     stream.setLength((int)streamLength);
/*      */   }
/*      */   
/*      */   protected void readObjStm(PRStream stream, IntHashtable map) throws IOException {
/* 1502 */     if (stream == null) return;
/* 1503 */     int first = stream.getAsNumber(PdfName.FIRST).intValue();
/* 1504 */     int n = stream.getAsNumber(PdfName.N).intValue();
/* 1505 */     byte[] b = getStreamBytes(stream, this.tokens.getFile());
/* 1506 */     PRTokeniser saveTokens = this.tokens;
/* 1507 */     this.tokens = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(b)));
/*      */     try {
/* 1509 */       int[] address = new int[n];
/* 1510 */       int[] objNumber = new int[n];
/* 1511 */       boolean ok = true;
/* 1512 */       for (int k = 0; k < n; k++) {
/* 1513 */         ok = this.tokens.nextToken();
/* 1514 */         if (!ok)
/*      */           break;
/* 1516 */         if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER) {
/* 1517 */           ok = false;
/* 1518 */           break;
/*      */         }
/* 1520 */         objNumber[k] = this.tokens.intValue();
/* 1521 */         ok = this.tokens.nextToken();
/* 1522 */         if (!ok)
/*      */           break;
/* 1524 */         if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER) {
/* 1525 */           ok = false;
/* 1526 */           break;
/*      */         }
/* 1528 */         address[k] = (this.tokens.intValue() + first);
/*      */       }
/* 1530 */       if (!ok)
/* 1531 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("error.reading.objstm", new Object[0]));
/* 1532 */       for (int k = 0; k < n; k++) {
/* 1533 */         if (map.containsKey(k)) {
/* 1534 */           this.tokens.seek(address[k]);
/* 1535 */           this.tokens.nextToken();
/*      */           PdfObject obj;
/* 1537 */           PdfObject obj; if (this.tokens.getTokenType() == PRTokeniser.TokenType.NUMBER) {
/* 1538 */             obj = new PdfNumber(this.tokens.getStringValue());
/*      */           }
/*      */           else {
/* 1541 */             this.tokens.seek(address[k]);
/* 1542 */             obj = readPRObject();
/*      */           }
/* 1544 */           this.xrefObj.set(objNumber[k], obj);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/* 1549 */       this.tokens = saveTokens;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static PdfObject killIndirect(PdfObject obj)
/*      */   {
/* 1560 */     if ((obj == null) || (obj.isNull()))
/* 1561 */       return null;
/* 1562 */     PdfObject ret = getPdfObjectRelease(obj);
/* 1563 */     if (obj.isIndirect()) {
/* 1564 */       PRIndirectReference ref = (PRIndirectReference)obj;
/* 1565 */       PdfReader reader = ref.getReader();
/* 1566 */       int n = ref.getNumber();
/* 1567 */       reader.xrefObj.set(n, null);
/* 1568 */       if (reader.partial)
/* 1569 */         reader.xref[(n * 2)] = -1L;
/*      */     }
/* 1571 */     return ret;
/*      */   }
/*      */   
/*      */   private void ensureXrefSize(int size) {
/* 1575 */     if (size == 0)
/* 1576 */       return;
/* 1577 */     if (this.xref == null) {
/* 1578 */       this.xref = new long[size];
/*      */     }
/* 1580 */     else if (this.xref.length < size) {
/* 1581 */       long[] xref2 = new long[size];
/* 1582 */       System.arraycopy(this.xref, 0, xref2, 0, this.xref.length);
/* 1583 */       this.xref = xref2;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void readXref() throws IOException
/*      */   {
/* 1589 */     this.hybridXref = false;
/* 1590 */     this.newXrefType = false;
/* 1591 */     this.tokens.seek(this.tokens.getStartxref());
/* 1592 */     this.tokens.nextToken();
/* 1593 */     if (!this.tokens.getStringValue().equals("startxref"))
/* 1594 */       throw new InvalidPdfException(MessageLocalization.getComposedMessage("startxref.not.found", new Object[0]));
/* 1595 */     this.tokens.nextToken();
/* 1596 */     if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1597 */       throw new InvalidPdfException(MessageLocalization.getComposedMessage("startxref.is.not.followed.by.a.number", new Object[0]));
/* 1598 */     long startxref = this.tokens.longValue();
/* 1599 */     this.lastXref = startxref;
/* 1600 */     this.eofPos = this.tokens.getFilePointer();
/*      */     try {
/* 1602 */       if (readXRefStream(startxref)) {
/* 1603 */         this.newXrefType = true;
/* 1604 */         return;
/*      */       }
/*      */     }
/*      */     catch (Exception localException) {}
/* 1608 */     this.xref = null;
/* 1609 */     this.tokens.seek(startxref);
/* 1610 */     this.trailer = readXrefSection();
/* 1611 */     PdfDictionary trailer2 = this.trailer;
/*      */     for (;;) {
/* 1613 */       PdfNumber prev = (PdfNumber)trailer2.get(PdfName.PREV);
/* 1614 */       if (prev == null)
/*      */         break;
/* 1616 */       if (prev.longValue() == startxref)
/* 1617 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("trailer.prev.entry.points.to.its.own.cross.reference.section", new Object[0]));
/* 1618 */       startxref = prev.longValue();
/* 1619 */       this.tokens.seek(startxref);
/* 1620 */       trailer2 = readXrefSection();
/*      */     }
/*      */   }
/*      */   
/*      */   protected PdfDictionary readXrefSection() throws IOException {
/* 1625 */     this.tokens.nextValidToken();
/* 1626 */     if (!this.tokens.getStringValue().equals("xref"))
/* 1627 */       this.tokens.throwError(MessageLocalization.getComposedMessage("xref.subsection.not.found", new Object[0]));
/* 1628 */     int start = 0;
/* 1629 */     int end = 0;
/* 1630 */     long pos = 0L;
/* 1631 */     int gen = 0;
/*      */     for (;;) {
/* 1633 */       this.tokens.nextValidToken();
/* 1634 */       if (this.tokens.getStringValue().equals("trailer"))
/*      */         break;
/* 1636 */       if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1637 */         this.tokens.throwError(MessageLocalization.getComposedMessage("object.number.of.the.first.object.in.this.xref.subsection.not.found", new Object[0]));
/* 1638 */       start = this.tokens.intValue();
/* 1639 */       this.tokens.nextValidToken();
/* 1640 */       if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1641 */         this.tokens.throwError(MessageLocalization.getComposedMessage("number.of.entries.in.this.xref.subsection.not.found", new Object[0]));
/* 1642 */       end = this.tokens.intValue() + start;
/* 1643 */       if (start == 1) {
/* 1644 */         long back = this.tokens.getFilePointer();
/* 1645 */         this.tokens.nextValidToken();
/* 1646 */         pos = this.tokens.longValue();
/* 1647 */         this.tokens.nextValidToken();
/* 1648 */         gen = this.tokens.intValue();
/* 1649 */         if ((pos == 0L) && (gen == 65535)) {
/* 1650 */           start--;
/* 1651 */           end--;
/*      */         }
/* 1653 */         this.tokens.seek(back);
/*      */       }
/* 1655 */       ensureXrefSize(end * 2);
/* 1656 */       for (int k = start; k < end; k++) {
/* 1657 */         this.tokens.nextValidToken();
/* 1658 */         pos = this.tokens.longValue();
/* 1659 */         this.tokens.nextValidToken();
/* 1660 */         gen = this.tokens.intValue();
/* 1661 */         this.tokens.nextValidToken();
/* 1662 */         int p = k * 2;
/* 1663 */         if (this.tokens.getStringValue().equals("n")) {
/* 1664 */           if ((this.xref[p] == 0L) && (this.xref[(p + 1)] == 0L))
/*      */           {
/*      */ 
/* 1667 */             this.xref[p] = pos;
/*      */           }
/*      */         }
/* 1670 */         else if (this.tokens.getStringValue().equals("f")) {
/* 1671 */           if ((this.xref[p] == 0L) && (this.xref[(p + 1)] == 0L)) {
/* 1672 */             this.xref[p] = -1L;
/*      */           }
/*      */         } else
/* 1675 */           this.tokens.throwError(MessageLocalization.getComposedMessage("invalid.cross.reference.entry.in.this.xref.subsection", new Object[0]));
/*      */       }
/*      */     }
/* 1678 */     PdfDictionary trailer = (PdfDictionary)readPRObject();
/* 1679 */     PdfNumber xrefSize = (PdfNumber)trailer.get(PdfName.SIZE);
/* 1680 */     ensureXrefSize(xrefSize.intValue() * 2);
/* 1681 */     PdfObject xrs = trailer.get(PdfName.XREFSTM);
/* 1682 */     if ((xrs != null) && (xrs.isNumber())) {
/* 1683 */       int loc = ((PdfNumber)xrs).intValue();
/*      */       try {
/* 1685 */         readXRefStream(loc);
/* 1686 */         this.newXrefType = true;
/* 1687 */         this.hybridXref = true;
/*      */       }
/*      */       catch (IOException e) {
/* 1690 */         this.xref = null;
/* 1691 */         throw e;
/*      */       }
/*      */     }
/* 1694 */     return trailer;
/*      */   }
/*      */   
/*      */   protected boolean readXRefStream(long ptr) throws IOException {
/* 1698 */     this.tokens.seek(ptr);
/* 1699 */     int thisStream = 0;
/* 1700 */     if (!this.tokens.nextToken())
/* 1701 */       return false;
/* 1702 */     if (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER)
/* 1703 */       return false;
/* 1704 */     thisStream = this.tokens.intValue();
/* 1705 */     if ((!this.tokens.nextToken()) || (this.tokens.getTokenType() != PRTokeniser.TokenType.NUMBER))
/* 1706 */       return false;
/* 1707 */     if ((!this.tokens.nextToken()) || (!this.tokens.getStringValue().equals("obj")))
/* 1708 */       return false;
/* 1709 */     PdfObject object = readPRObject();
/* 1710 */     PRStream stm = null;
/* 1711 */     if (object.isStream()) {
/* 1712 */       stm = (PRStream)object;
/* 1713 */       if (!PdfName.XREF.equals(stm.get(PdfName.TYPE))) {
/* 1714 */         return false;
/*      */       }
/*      */     } else {
/* 1717 */       return false; }
/* 1718 */     if (this.trailer == null) {
/* 1719 */       this.trailer = new PdfDictionary();
/* 1720 */       this.trailer.putAll(stm);
/*      */     }
/* 1722 */     stm.setLength(((PdfNumber)stm.get(PdfName.LENGTH)).intValue());
/* 1723 */     int size = ((PdfNumber)stm.get(PdfName.SIZE)).intValue();
/*      */     
/* 1725 */     PdfObject obj = stm.get(PdfName.INDEX);
/* 1726 */     PdfArray index; if (obj == null) {
/* 1727 */       PdfArray index = new PdfArray();
/* 1728 */       index.add(new int[] { 0, size });
/*      */     }
/*      */     else {
/* 1731 */       index = (PdfArray)obj; }
/* 1732 */     PdfArray w = (PdfArray)stm.get(PdfName.W);
/* 1733 */     long prev = -1L;
/* 1734 */     obj = stm.get(PdfName.PREV);
/* 1735 */     if (obj != null) {
/* 1736 */       prev = ((PdfNumber)obj).longValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1741 */     ensureXrefSize(size * 2);
/* 1742 */     if ((this.objStmMark == null) && (!this.partial))
/* 1743 */       this.objStmMark = new HashMap();
/* 1744 */     if ((this.objStmToOffset == null) && (this.partial))
/* 1745 */       this.objStmToOffset = new LongHashtable();
/* 1746 */     byte[] b = getStreamBytes(stm, this.tokens.getFile());
/* 1747 */     int bptr = 0;
/* 1748 */     int[] wc = new int[3];
/* 1749 */     for (int k = 0; k < 3; k++)
/* 1750 */       wc[k] = w.getAsNumber(k).intValue();
/* 1751 */     for (int idx = 0; idx < index.size(); idx += 2) {
/* 1752 */       int start = index.getAsNumber(idx).intValue();
/* 1753 */       int length = index.getAsNumber(idx + 1).intValue();
/* 1754 */       ensureXrefSize((start + length) * 2);
/* 1755 */       while (length-- > 0) {
/* 1756 */         int type = 1;
/* 1757 */         if (wc[0] > 0) {
/* 1758 */           type = 0;
/* 1759 */           for (int k = 0; k < wc[0]; k++)
/* 1760 */             type = (type << 8) + (b[(bptr++)] & 0xFF);
/*      */         }
/* 1762 */         long field2 = 0L;
/* 1763 */         for (int k = 0; k < wc[1]; k++)
/* 1764 */           field2 = (field2 << 8) + (b[(bptr++)] & 0xFF);
/* 1765 */         int field3 = 0;
/* 1766 */         for (int k = 0; k < wc[2]; k++)
/* 1767 */           field3 = (field3 << 8) + (b[(bptr++)] & 0xFF);
/* 1768 */         int base = start * 2;
/* 1769 */         if ((this.xref[base] == 0L) && (this.xref[(base + 1)] == 0L))
/* 1770 */           switch (type) {
/*      */           case 0: 
/* 1772 */             this.xref[base] = -1L;
/* 1773 */             break;
/*      */           case 1: 
/* 1775 */             this.xref[base] = field2;
/* 1776 */             break;
/*      */           case 2: 
/* 1778 */             this.xref[base] = field3;
/* 1779 */             this.xref[(base + 1)] = field2;
/* 1780 */             if (this.partial) {
/* 1781 */               this.objStmToOffset.put(field2, 0L);
/*      */             }
/*      */             else {
/* 1784 */               Integer on = Integer.valueOf((int)field2);
/* 1785 */               IntHashtable seq = (IntHashtable)this.objStmMark.get(on);
/* 1786 */               if (seq == null) {
/* 1787 */                 seq = new IntHashtable();
/* 1788 */                 seq.put(field3, 1);
/* 1789 */                 this.objStmMark.put(on, seq);
/*      */               }
/*      */               else {
/* 1792 */                 seq.put(field3, 1);
/*      */               }
/*      */             }
/*      */             break;
/*      */           }
/* 1797 */         start++;
/*      */       }
/*      */     }
/* 1800 */     thisStream *= 2;
/* 1801 */     if ((thisStream + 1 < this.xref.length) && (this.xref[thisStream] == 0L) && (this.xref[(thisStream + 1)] == 0L)) {
/* 1802 */       this.xref[thisStream] = -1L;
/*      */     }
/* 1804 */     if (prev == -1L)
/* 1805 */       return true;
/* 1806 */     return readXRefStream(prev);
/*      */   }
/*      */   
/*      */   protected void rebuildXref() throws IOException {
/* 1810 */     this.hybridXref = false;
/* 1811 */     this.newXrefType = false;
/* 1812 */     this.tokens.seek(0L);
/* 1813 */     long[][] xr = new long['Ѐ'][];
/* 1814 */     long top = 0L;
/* 1815 */     this.trailer = null;
/* 1816 */     byte[] line = new byte[64];
/*      */     for (;;) {
/* 1818 */       long pos = this.tokens.getFilePointer();
/* 1819 */       if (!this.tokens.readLineSegment(line, true))
/*      */         break;
/* 1821 */       if (line[0] == 116) {
/* 1822 */         if (PdfEncodings.convertToString(line, null).startsWith("trailer"))
/*      */         {
/* 1824 */           this.tokens.seek(pos);
/* 1825 */           this.tokens.nextToken();
/* 1826 */           pos = this.tokens.getFilePointer();
/*      */           try {
/* 1828 */             PdfDictionary dic = (PdfDictionary)readPRObject();
/* 1829 */             if (dic.get(PdfName.ROOT) != null) {
/* 1830 */               this.trailer = dic;
/*      */             } else {
/* 1832 */               this.tokens.seek(pos);
/*      */             }
/*      */           } catch (Exception e) {
/* 1835 */             this.tokens.seek(pos);
/*      */           }
/*      */         }
/* 1838 */       } else if ((line[0] >= 48) && (line[0] <= 57)) {
/* 1839 */         long[] obj = PRTokeniser.checkObjectStart(line);
/* 1840 */         if (obj != null)
/*      */         {
/* 1842 */           long num = obj[0];
/* 1843 */           long gen = obj[1];
/* 1844 */           if (num >= xr.length) {
/* 1845 */             long newLength = num * 2L;
/* 1846 */             long[][] xr2 = new long[(int)newLength][];
/* 1847 */             System.arraycopy(xr, 0, xr2, 0, (int)top);
/* 1848 */             xr = xr2;
/*      */           }
/* 1850 */           if (num >= top)
/* 1851 */             top = num + 1L;
/* 1852 */           if ((xr[((int)num)] == null) || (gen >= xr[((int)num)][1])) {
/* 1853 */             obj[0] = pos;
/* 1854 */             xr[((int)num)] = obj;
/*      */           }
/*      */         }
/*      */       } }
/* 1858 */     if (this.trailer == null)
/* 1859 */       throw new InvalidPdfException(MessageLocalization.getComposedMessage("trailer.not.found", new Object[0]));
/* 1860 */     this.xref = new long[(int)(top * 2L)];
/* 1861 */     for (int k = 0; k < top; k++) {
/* 1862 */       long[] obj = xr[k];
/* 1863 */       if (obj != null)
/* 1864 */         this.xref[(k * 2)] = obj[0];
/*      */     }
/*      */   }
/*      */   
/*      */   protected PdfDictionary readDictionary() throws IOException {
/* 1869 */     PdfDictionary dic = new PdfDictionary();
/*      */     for (;;) {
/* 1871 */       this.tokens.nextValidToken();
/* 1872 */       if (this.tokens.getTokenType() == PRTokeniser.TokenType.END_DIC)
/*      */         break;
/* 1874 */       if (this.tokens.getTokenType() != PRTokeniser.TokenType.NAME)
/* 1875 */         this.tokens.throwError(MessageLocalization.getComposedMessage("dictionary.key.1.is.not.a.name", new Object[] { this.tokens.getStringValue() }));
/* 1876 */       PdfName name = new PdfName(this.tokens.getStringValue(), false);
/* 1877 */       PdfObject obj = readPRObject();
/* 1878 */       int type = obj.type();
/* 1879 */       if (-type == PRTokeniser.TokenType.END_DIC.ordinal())
/* 1880 */         this.tokens.throwError(MessageLocalization.getComposedMessage("unexpected.gt.gt", new Object[0]));
/* 1881 */       if (-type == PRTokeniser.TokenType.END_ARRAY.ordinal())
/* 1882 */         this.tokens.throwError(MessageLocalization.getComposedMessage("unexpected.close.bracket", new Object[0]));
/* 1883 */       dic.put(name, obj);
/*      */     }
/* 1885 */     return dic;
/*      */   }
/*      */   
/*      */   protected PdfArray readArray() throws IOException {
/* 1889 */     PdfArray array = new PdfArray();
/*      */     for (;;) {
/* 1891 */       PdfObject obj = readPRObject();
/* 1892 */       int type = obj.type();
/* 1893 */       if (-type == PRTokeniser.TokenType.END_ARRAY.ordinal())
/*      */         break;
/* 1895 */       if (-type == PRTokeniser.TokenType.END_DIC.ordinal())
/* 1896 */         this.tokens.throwError(MessageLocalization.getComposedMessage("unexpected.gt.gt", new Object[0]));
/* 1897 */       array.add(obj);
/*      */     }
/* 1899 */     return array;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1905 */   private int readDepth = 0;
/*      */   
/*      */   protected PdfObject readPRObject() throws IOException {
/* 1908 */     this.tokens.nextValidToken();
/* 1909 */     PRTokeniser.TokenType type = this.tokens.getTokenType();
/* 1910 */     switch (type) {
/*      */     case START_DIC: 
/* 1912 */       this.readDepth += 1;
/* 1913 */       PdfDictionary dic = readDictionary();
/* 1914 */       this.readDepth -= 1;
/* 1915 */       long pos = this.tokens.getFilePointer();
/*      */       boolean hasNext;
/*      */       do
/*      */       {
/* 1919 */         hasNext = this.tokens.nextToken();
/* 1920 */       } while ((hasNext) && (this.tokens.getTokenType() == PRTokeniser.TokenType.COMMENT));
/*      */       
/* 1922 */       if ((hasNext) && (this.tokens.getStringValue().equals("stream")))
/*      */       {
/*      */         int ch;
/*      */         do {
/* 1926 */           ch = this.tokens.read();
/* 1927 */         } while ((ch == 32) || (ch == 9) || (ch == 0) || (ch == 12));
/* 1928 */         if (ch != 10)
/* 1929 */           ch = this.tokens.read();
/* 1930 */         if (ch != 10)
/* 1931 */           this.tokens.backOnePosition(ch);
/* 1932 */         PRStream stream = new PRStream(this, this.tokens.getFilePointer());
/* 1933 */         stream.putAll(dic);
/*      */         
/* 1935 */         stream.setObjNum(this.objNum, this.objGen);
/*      */         
/* 1937 */         return stream;
/*      */       }
/*      */       
/* 1940 */       this.tokens.seek(pos);
/* 1941 */       return dic;
/*      */     
/*      */ 
/*      */     case START_ARRAY: 
/* 1945 */       this.readDepth += 1;
/* 1946 */       PdfArray arr = readArray();
/* 1947 */       this.readDepth -= 1;
/* 1948 */       return arr;
/*      */     
/*      */     case NUMBER: 
/* 1951 */       return new PdfNumber(this.tokens.getStringValue());
/*      */     case STRING: 
/* 1953 */       PdfString str = new PdfString(this.tokens.getStringValue(), null).setHexWriting(this.tokens.isHexString());
/*      */       
/* 1955 */       str.setObjNum(this.objNum, this.objGen);
/* 1956 */       if (this.strings != null) {
/* 1957 */         this.strings.add(str);
/*      */       }
/* 1959 */       return str;
/*      */     case NAME: 
/* 1961 */       PdfName cachedName = (PdfName)PdfName.staticNames.get(this.tokens.getStringValue());
/* 1962 */       if ((this.readDepth > 0) && (cachedName != null)) {
/* 1963 */         return cachedName;
/*      */       }
/*      */       
/* 1966 */       return new PdfName(this.tokens.getStringValue(), false);
/*      */     
/*      */ 
/*      */     case REF: 
/* 1970 */       int num = this.tokens.getReference();
/* 1971 */       PRIndirectReference ref = new PRIndirectReference(this, num, this.tokens.getGeneration());
/* 1972 */       return ref;
/*      */     case ENDOFFILE: 
/* 1974 */       throw new IOException(MessageLocalization.getComposedMessage("unexpected.end.of.file", new Object[0]));
/*      */     }
/* 1976 */     String sv = this.tokens.getStringValue();
/* 1977 */     if ("null".equals(sv)) {
/* 1978 */       if (this.readDepth == 0) {
/* 1979 */         return new PdfNull();
/*      */       }
/* 1981 */       return PdfNull.PDFNULL;
/*      */     }
/* 1983 */     if ("true".equals(sv)) {
/* 1984 */       if (this.readDepth == 0) {
/* 1985 */         return new PdfBoolean(true);
/*      */       }
/* 1987 */       return PdfBoolean.PDFTRUE;
/*      */     }
/* 1989 */     if ("false".equals(sv)) {
/* 1990 */       if (this.readDepth == 0) {
/* 1991 */         return new PdfBoolean(false);
/*      */       }
/* 1993 */       return PdfBoolean.PDFFALSE;
/*      */     }
/* 1995 */     return new PdfLiteral(-type.ordinal(), this.tokens.getStringValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] FlateDecode(byte[] in)
/*      */   {
/* 2004 */     byte[] b = FlateDecode(in, true);
/* 2005 */     if (b == null)
/* 2006 */       return FlateDecode(in, false);
/* 2007 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] decodePredictor(byte[] in, PdfObject dicPar)
/*      */   {
/* 2016 */     if ((dicPar == null) || (!dicPar.isDictionary()))
/* 2017 */       return in;
/* 2018 */     PdfDictionary dic = (PdfDictionary)dicPar;
/* 2019 */     PdfObject obj = getPdfObject(dic.get(PdfName.PREDICTOR));
/* 2020 */     if ((obj == null) || (!obj.isNumber()))
/* 2021 */       return in;
/* 2022 */     int predictor = ((PdfNumber)obj).intValue();
/* 2023 */     if ((predictor < 10) && (predictor != 2))
/* 2024 */       return in;
/* 2025 */     int width = 1;
/* 2026 */     obj = getPdfObject(dic.get(PdfName.COLUMNS));
/* 2027 */     if ((obj != null) && (obj.isNumber()))
/* 2028 */       width = ((PdfNumber)obj).intValue();
/* 2029 */     int colors = 1;
/* 2030 */     obj = getPdfObject(dic.get(PdfName.COLORS));
/* 2031 */     if ((obj != null) && (obj.isNumber()))
/* 2032 */       colors = ((PdfNumber)obj).intValue();
/* 2033 */     int bpc = 8;
/* 2034 */     obj = getPdfObject(dic.get(PdfName.BITSPERCOMPONENT));
/* 2035 */     if ((obj != null) && (obj.isNumber()))
/* 2036 */       bpc = ((PdfNumber)obj).intValue();
/* 2037 */     DataInputStream dataStream = new DataInputStream(new ByteArrayInputStream(in));
/* 2038 */     ByteArrayOutputStream fout = new ByteArrayOutputStream(in.length);
/* 2039 */     int bytesPerPixel = colors * bpc / 8;
/* 2040 */     int bytesPerRow = (colors * width * bpc + 7) / 8;
/* 2041 */     byte[] curr = new byte[bytesPerRow];
/* 2042 */     byte[] prior = new byte[bytesPerRow];
/* 2043 */     if (predictor == 2) {
/* 2044 */       if (bpc == 8) {
/* 2045 */         int numRows = in.length / bytesPerRow;
/* 2046 */         for (int row = 0; row < numRows; row++) {
/* 2047 */           int rowStart = row * bytesPerRow;
/* 2048 */           for (int col = 0 + bytesPerPixel; col < bytesPerRow; col++) {
/* 2049 */             in[(rowStart + col)] = ((byte)(in[(rowStart + col)] + in[(rowStart + col - bytesPerPixel)]));
/*      */           }
/*      */         }
/*      */       }
/* 2053 */       return in;
/*      */     }
/*      */     
/*      */     for (;;)
/*      */     {
/* 2058 */       int filter = 0;
/*      */       try {
/* 2060 */         filter = dataStream.read();
/* 2061 */         if (filter < 0) {
/* 2062 */           return fout.toByteArray();
/*      */         }
/* 2064 */         dataStream.readFully(curr, 0, bytesPerRow);
/*      */       } catch (Exception e) {
/* 2066 */         return fout.toByteArray();
/*      */       }
/*      */       
/* 2069 */       switch (filter) {
/*      */       case 0: 
/*      */         break;
/*      */       case 1: 
/* 2073 */         for (int i = bytesPerPixel; i < bytesPerRow; i++) {
/* 2074 */           int tmp422_420 = i; byte[] tmp422_418 = curr;tmp422_418[tmp422_420] = ((byte)(tmp422_418[tmp422_420] + curr[(i - bytesPerPixel)]));
/*      */         }
/* 2076 */         break;
/*      */       case 2: 
/* 2078 */         for (int i = 0; i < bytesPerRow; i++) {
/* 2079 */           int tmp458_456 = i; byte[] tmp458_454 = curr;tmp458_454[tmp458_456] = ((byte)(tmp458_454[tmp458_456] + prior[i]));
/*      */         }
/* 2081 */         break;
/*      */       case 3: 
/* 2083 */         for (int i = 0; i < bytesPerPixel; i++) {
/* 2084 */           int tmp491_489 = i; byte[] tmp491_487 = curr;tmp491_487[tmp491_489] = ((byte)(tmp491_487[tmp491_489] + prior[i] / 2));
/*      */         }
/* 2086 */         for (int i = bytesPerPixel; i < bytesPerRow; i++) {
/* 2087 */           int tmp524_522 = i; byte[] tmp524_520 = curr;tmp524_520[tmp524_522] = ((byte)(tmp524_520[tmp524_522] + ((curr[(i - bytesPerPixel)] & 0xFF) + (prior[i] & 0xFF)) / 2));
/*      */         }
/* 2089 */         break;
/*      */       case 4: 
/* 2091 */         for (int i = 0; i < bytesPerPixel; i++) {
/* 2092 */           int tmp576_574 = i; byte[] tmp576_572 = curr;tmp576_572[tmp576_574] = ((byte)(tmp576_572[tmp576_574] + prior[i]));
/*      */         }
/*      */         
/* 2095 */         for (int i = bytesPerPixel; i < bytesPerRow; i++) {
/* 2096 */           int a = curr[(i - bytesPerPixel)] & 0xFF;
/* 2097 */           int b = prior[i] & 0xFF;
/* 2098 */           int c = prior[(i - bytesPerPixel)] & 0xFF;
/*      */           
/* 2100 */           int p = a + b - c;
/* 2101 */           int pa = Math.abs(p - a);
/* 2102 */           int pb = Math.abs(p - b);
/* 2103 */           int pc = Math.abs(p - c);
/*      */           
/*      */           int ret;
/*      */           int ret;
/* 2107 */           if ((pa <= pb) && (pa <= pc)) {
/* 2108 */             ret = a; } else { int ret;
/* 2109 */             if (pb <= pc) {
/* 2110 */               ret = b;
/*      */             } else
/* 2112 */               ret = c;
/*      */           }
/* 2114 */           int tmp725_723 = i; byte[] tmp725_721 = curr;tmp725_721[tmp725_723] = ((byte)(tmp725_721[tmp725_723] + (byte)ret));
/*      */         }
/* 2116 */         break;
/*      */       
/*      */       default: 
/* 2119 */         throw new RuntimeException(MessageLocalization.getComposedMessage("png.filter.unknown", new Object[0]));
/*      */       }
/*      */       try {
/* 2122 */         fout.write(curr);
/*      */       }
/*      */       catch (IOException localIOException) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2129 */       byte[] tmp = prior;
/* 2130 */       prior = curr;
/* 2131 */       curr = tmp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] FlateDecode(byte[] in, boolean strict)
/*      */   {
/* 2142 */     ByteArrayInputStream stream = new ByteArrayInputStream(in);
/* 2143 */     InflaterInputStream zip = new InflaterInputStream(stream);
/* 2144 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 2145 */     byte[] b = new byte[strict ? 4092 : 1];
/*      */     try {
/*      */       int n;
/* 2148 */       while ((n = zip.read(b)) >= 0) {
/* 2149 */         out.write(b, 0, n);
/*      */       }
/* 2151 */       zip.close();
/* 2152 */       out.close();
/* 2153 */       return out.toByteArray();
/*      */     }
/*      */     catch (Exception e) {
/* 2156 */       if (strict)
/* 2157 */         return null; }
/* 2158 */     return out.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] ASCIIHexDecode(byte[] in)
/*      */   {
/* 2167 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 2168 */     boolean first = true;
/* 2169 */     int n1 = 0;
/* 2170 */     for (int k = 0; k < in.length; k++) {
/* 2171 */       int ch = in[k] & 0xFF;
/* 2172 */       if (ch == 62)
/*      */         break;
/* 2174 */       if (!PRTokeniser.isWhitespace(ch))
/*      */       {
/* 2176 */         int n = PRTokeniser.getHex(ch);
/* 2177 */         if (n == -1)
/* 2178 */           throw new RuntimeException(MessageLocalization.getComposedMessage("illegal.character.in.asciihexdecode", new Object[0]));
/* 2179 */         if (first) {
/* 2180 */           n1 = n;
/*      */         } else
/* 2182 */           out.write((byte)((n1 << 4) + n));
/* 2183 */         first = !first;
/*      */       } }
/* 2185 */     if (!first)
/* 2186 */       out.write((byte)(n1 << 4));
/* 2187 */     return out.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] ASCII85Decode(byte[] in)
/*      */   {
/* 2195 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 2196 */     int state = 0;
/* 2197 */     int[] chn = new int[5];
/* 2198 */     for (int k = 0; k < in.length; k++) {
/* 2199 */       int ch = in[k] & 0xFF;
/* 2200 */       if (ch == 126)
/*      */         break;
/* 2202 */       if (!PRTokeniser.isWhitespace(ch))
/*      */       {
/* 2204 */         if ((ch == 122) && (state == 0)) {
/* 2205 */           out.write(0);
/* 2206 */           out.write(0);
/* 2207 */           out.write(0);
/* 2208 */           out.write(0);
/*      */         }
/*      */         else {
/* 2211 */           if ((ch < 33) || (ch > 117))
/* 2212 */             throw new RuntimeException(MessageLocalization.getComposedMessage("illegal.character.in.ascii85decode", new Object[0]));
/* 2213 */           chn[state] = (ch - 33);
/* 2214 */           state++;
/* 2215 */           if (state == 5) {
/* 2216 */             state = 0;
/* 2217 */             int r = 0;
/* 2218 */             for (int j = 0; j < 5; j++)
/* 2219 */               r = r * 85 + chn[j];
/* 2220 */             out.write((byte)(r >> 24));
/* 2221 */             out.write((byte)(r >> 16));
/* 2222 */             out.write((byte)(r >> 8));
/* 2223 */             out.write((byte)r);
/*      */           }
/*      */         } } }
/* 2226 */     int r = 0;
/*      */     
/*      */ 
/*      */ 
/* 2230 */     if (state == 2) {
/* 2231 */       r = chn[0] * 85 * 85 * 85 * 85 + chn[1] * 85 * 85 * 85 + 614125 + 7225 + 85;
/* 2232 */       out.write((byte)(r >> 24));
/*      */     }
/* 2234 */     else if (state == 3) {
/* 2235 */       r = chn[0] * 85 * 85 * 85 * 85 + chn[1] * 85 * 85 * 85 + chn[2] * 85 * 85 + 7225 + 85;
/* 2236 */       out.write((byte)(r >> 24));
/* 2237 */       out.write((byte)(r >> 16));
/*      */     }
/* 2239 */     else if (state == 4) {
/* 2240 */       r = chn[0] * 85 * 85 * 85 * 85 + chn[1] * 85 * 85 * 85 + chn[2] * 85 * 85 + chn[3] * 85 + 85;
/* 2241 */       out.write((byte)(r >> 24));
/* 2242 */       out.write((byte)(r >> 16));
/* 2243 */       out.write((byte)(r >> 8));
/*      */     }
/* 2245 */     return out.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] LZWDecode(byte[] in)
/*      */   {
/* 2253 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 2254 */     LZWDecoder lzw = new LZWDecoder();
/* 2255 */     lzw.decode(in, out);
/* 2256 */     return out.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRebuilt()
/*      */   {
/* 2264 */     return this.rebuilt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getPageN(int pageNum)
/*      */   {
/* 2272 */     PdfDictionary dic = this.pageRefs.getPageN(pageNum);
/* 2273 */     if (dic == null)
/* 2274 */       return null;
/* 2275 */     if (this.appendable)
/* 2276 */       dic.setIndRef(this.pageRefs.getPageOrigRef(pageNum));
/* 2277 */     return dic;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getPageNRelease(int pageNum)
/*      */   {
/* 2285 */     PdfDictionary dic = getPageN(pageNum);
/* 2286 */     this.pageRefs.releasePage(pageNum);
/* 2287 */     return dic;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void releasePage(int pageNum)
/*      */   {
/* 2294 */     this.pageRefs.releasePage(pageNum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void resetReleasePage()
/*      */   {
/* 2301 */     this.pageRefs.resetReleasePage();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PRIndirectReference getPageOrigRef(int pageNum)
/*      */   {
/* 2309 */     return this.pageRefs.getPageOrigRef(pageNum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getPageContent(int pageNum, RandomAccessFileOrArray file)
/*      */     throws IOException
/*      */   {
/* 2319 */     PdfDictionary page = getPageNRelease(pageNum);
/* 2320 */     if (page == null)
/* 2321 */       return null;
/* 2322 */     PdfObject contents = getPdfObjectRelease(page.get(PdfName.CONTENTS));
/* 2323 */     if (contents == null)
/* 2324 */       return new byte[0];
/* 2325 */     ByteArrayOutputStream bout = null;
/* 2326 */     if (contents.isStream()) {
/* 2327 */       return getStreamBytes((PRStream)contents, file);
/*      */     }
/* 2329 */     if (contents.isArray()) {
/* 2330 */       PdfArray array = (PdfArray)contents;
/* 2331 */       bout = new ByteArrayOutputStream();
/* 2332 */       for (int k = 0; k < array.size(); k++) {
/* 2333 */         PdfObject item = getPdfObjectRelease(array.getPdfObject(k));
/* 2334 */         if ((item != null) && (item.isStream()))
/*      */         {
/* 2336 */           byte[] b = getStreamBytes((PRStream)item, file);
/* 2337 */           bout.write(b);
/* 2338 */           if (k != array.size() - 1)
/* 2339 */             bout.write(10);
/*      */         } }
/* 2341 */       return bout.toByteArray();
/*      */     }
/*      */     
/* 2344 */     return new byte[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getPageContent(PdfDictionary page)
/*      */     throws IOException
/*      */   {
/* 2354 */     if (page == null)
/* 2355 */       return null;
/* 2356 */     RandomAccessFileOrArray rf = null;
/*      */     try {
/* 2358 */       PdfObject contents = getPdfObjectRelease(page.get(PdfName.CONTENTS));
/* 2359 */       byte[] arrayOfByte1; if (contents == null)
/* 2360 */         return new byte[0];
/* 2361 */       if (contents.isStream()) {
/* 2362 */         if (rf == null) {
/* 2363 */           rf = ((PRStream)contents).getReader().getSafeFile();
/* 2364 */           rf.reOpen();
/*      */         }
/* 2366 */         return getStreamBytes((PRStream)contents, rf); }
/*      */       Object array;
/* 2368 */       if (contents.isArray()) {
/* 2369 */         array = (PdfArray)contents;
/* 2370 */         ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 2371 */         for (int k = 0; k < ((PdfArray)array).size(); k++) {
/* 2372 */           PdfObject item = getPdfObjectRelease(((PdfArray)array).getPdfObject(k));
/* 2373 */           if ((item != null) && (item.isStream()))
/*      */           {
/* 2375 */             if (rf == null) {
/* 2376 */               rf = ((PRStream)item).getReader().getSafeFile();
/* 2377 */               rf.reOpen();
/*      */             }
/* 2379 */             byte[] b = getStreamBytes((PRStream)item, rf);
/* 2380 */             bout.write(b);
/* 2381 */             if (k != ((PdfArray)array).size() - 1)
/* 2382 */               bout.write(10);
/*      */           } }
/* 2384 */         return bout.toByteArray();
/*      */       }
/*      */       
/* 2387 */       return new byte[0];
/*      */     }
/*      */     finally {
/*      */       try {
/* 2391 */         if (rf != null) {
/* 2392 */           rf.close();
/*      */         }
/*      */       }
/*      */       catch (Exception localException4) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getPageResources(int pageNum)
/*      */   {
/* 2404 */     return getPageResources(getPageN(pageNum));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getPageResources(PdfDictionary pageDict)
/*      */   {
/* 2414 */     return pageDict.getAsDict(PdfName.RESOURCES);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getPageContent(int pageNum)
/*      */     throws IOException
/*      */   {
/* 2423 */     RandomAccessFileOrArray rf = getSafeFile();
/*      */     try {
/* 2425 */       rf.reOpen();
/* 2426 */       return getPageContent(pageNum, rf);
/*      */     } finally {
/*      */       try {
/* 2429 */         rf.close();
/*      */       } catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/* 2434 */   protected void killXref(PdfObject obj) { if (obj == null)
/* 2435 */       return;
/* 2436 */     if (((obj instanceof PdfIndirectReference)) && (!obj.isIndirect())) return;
/*      */     int i;
/* 2438 */     PdfDictionary dic; switch (obj.type()) {
/*      */     case 10: 
/* 2440 */       int xr = ((PRIndirectReference)obj).getNumber();
/* 2441 */       obj = (PdfObject)this.xrefObj.get(xr);
/* 2442 */       this.xrefObj.set(xr, null);
/* 2443 */       this.freeXref = xr;
/* 2444 */       killXref(obj);
/* 2445 */       break;
/*      */     
/*      */     case 5: 
/* 2448 */       PdfArray t = (PdfArray)obj;
/* 2449 */       for (i = 0; i < t.size(); i++)
/* 2450 */         killXref(t.getPdfObject(i));
/* 2451 */       break;
/*      */     
/*      */     case 6: 
/*      */     case 7: 
/* 2455 */       dic = (PdfDictionary)obj;
/* 2456 */       for (Object element : dic.getKeys()) {
/* 2457 */         killXref(dic.get((PdfName)element));
/*      */       }
/* 2459 */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageContent(int pageNum, byte[] content)
/*      */   {
/* 2469 */     setPageContent(pageNum, content, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageContent(int pageNum, byte[] content, int compressionLevel)
/*      */   {
/* 2479 */     setPageContent(pageNum, content, compressionLevel, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageContent(int pageNum, byte[] content, int compressionLevel, boolean killOldXRefRecursively)
/*      */   {
/* 2492 */     PdfDictionary page = getPageN(pageNum);
/* 2493 */     if (page == null)
/* 2494 */       return;
/* 2495 */     PdfObject contents = page.get(PdfName.CONTENTS);
/* 2496 */     this.freeXref = -1;
/* 2497 */     if (killOldXRefRecursively) {
/* 2498 */       killXref(contents);
/*      */     }
/* 2500 */     if (this.freeXref == -1) {
/* 2501 */       this.xrefObj.add(null);
/* 2502 */       this.freeXref = (this.xrefObj.size() - 1);
/*      */     }
/* 2504 */     page.put(PdfName.CONTENTS, new PRIndirectReference(this, this.freeXref));
/* 2505 */     this.xrefObj.set(this.freeXref, new PRStream(this, content, compressionLevel));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] decodeBytes(byte[] b, PdfDictionary streamDictionary)
/*      */     throws IOException
/*      */   {
/* 2517 */     return decodeBytes(b, streamDictionary, FilterHandlers.getDefaultFilterHandlers());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] decodeBytes(byte[] b, PdfDictionary streamDictionary, Map<PdfName, FilterHandlers.FilterHandler> filterHandlers)
/*      */     throws IOException
/*      */   {
/* 2530 */     PdfObject filter = getPdfObjectRelease(streamDictionary.get(PdfName.FILTER));
/*      */     
/* 2532 */     ArrayList<PdfObject> filters = new ArrayList();
/* 2533 */     if (filter != null) {
/* 2534 */       if (filter.isName()) {
/* 2535 */         filters.add(filter);
/* 2536 */       } else if (filter.isArray())
/* 2537 */         filters = ((PdfArray)filter).getArrayList();
/*      */     }
/* 2539 */     ArrayList<PdfObject> dp = new ArrayList();
/* 2540 */     PdfObject dpo = getPdfObjectRelease(streamDictionary.get(PdfName.DECODEPARMS));
/* 2541 */     if ((dpo == null) || ((!dpo.isDictionary()) && (!dpo.isArray())))
/* 2542 */       dpo = getPdfObjectRelease(streamDictionary.get(PdfName.DP));
/* 2543 */     if (dpo != null) {
/* 2544 */       if (dpo.isDictionary()) {
/* 2545 */         dp.add(dpo);
/* 2546 */       } else if (dpo.isArray())
/* 2547 */         dp = ((PdfArray)dpo).getArrayList();
/*      */     }
/* 2549 */     for (int j = 0; j < filters.size(); j++) {
/* 2550 */       PdfName filterName = (PdfName)filters.get(j);
/* 2551 */       FilterHandlers.FilterHandler filterHandler = (FilterHandlers.FilterHandler)filterHandlers.get(filterName);
/* 2552 */       if (filterHandler == null)
/* 2553 */         throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("the.filter.1.is.not.supported", new Object[] { filterName }));
/*      */       PdfDictionary decodeParams;
/*      */       PdfDictionary decodeParams;
/* 2556 */       if (j < dp.size()) {
/* 2557 */         PdfObject dpEntry = getPdfObject((PdfObject)dp.get(j));
/* 2558 */         PdfDictionary decodeParams; if ((dpEntry instanceof PdfDictionary)) {
/* 2559 */           decodeParams = (PdfDictionary)dpEntry; } else { PdfDictionary decodeParams;
/* 2560 */           if ((dpEntry == null) || ((dpEntry instanceof PdfNull)) || (((dpEntry instanceof PdfLiteral)) && 
/* 2561 */             (Arrays.equals("null".getBytes(), ((PdfLiteral)dpEntry).getBytes())))) {
/* 2562 */             decodeParams = null;
/*      */           } else {
/* 2564 */             throw new UnsupportedPdfException(MessageLocalization.getComposedMessage("the.decode.parameter.type.1.is.not.supported", new Object[] { dpEntry.getClass().toString() }));
/*      */           }
/*      */         }
/*      */       } else {
/* 2568 */         decodeParams = null;
/*      */       }
/* 2570 */       b = filterHandler.decode(b, filterName, decodeParams, streamDictionary);
/*      */     }
/* 2572 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getStreamBytes(PRStream stream, RandomAccessFileOrArray file)
/*      */     throws IOException
/*      */   {
/* 2582 */     byte[] b = getStreamBytesRaw(stream, file);
/* 2583 */     return decodeBytes(b, stream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getStreamBytes(PRStream stream)
/*      */     throws IOException
/*      */   {
/* 2592 */     RandomAccessFileOrArray rf = stream.getReader().getSafeFile();
/*      */     try {
/* 2594 */       rf.reOpen();
/* 2595 */       return getStreamBytes(stream, rf);
/*      */     } finally {
/*      */       try {
/* 2598 */         rf.close();
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static byte[] getStreamBytesRaw(PRStream stream, RandomAccessFileOrArray file)
/*      */     throws IOException
/*      */   {
/* 2609 */     PdfReader reader = stream.getReader();
/*      */     byte[] b;
/* 2611 */     byte[] b; if (stream.getOffset() < 0L) {
/* 2612 */       b = stream.getBytes();
/*      */     } else {
/* 2614 */       b = new byte[stream.getLength()];
/* 2615 */       file.seek(stream.getOffset());
/* 2616 */       file.readFully(b);
/* 2617 */       PdfEncryption decrypt = reader.getDecrypt();
/* 2618 */       if (decrypt != null) {
/* 2619 */         PdfObject filter = getPdfObjectRelease(stream.get(PdfName.FILTER));
/* 2620 */         ArrayList<PdfObject> filters = new ArrayList();
/* 2621 */         if (filter != null) {
/* 2622 */           if (filter.isName()) {
/* 2623 */             filters.add(filter);
/* 2624 */           } else if (filter.isArray())
/* 2625 */             filters = ((PdfArray)filter).getArrayList();
/*      */         }
/* 2627 */         boolean skip = false;
/* 2628 */         for (int k = 0; k < filters.size(); k++) {
/* 2629 */           PdfObject obj = getPdfObjectRelease((PdfObject)filters.get(k));
/* 2630 */           if ((obj != null) && (obj.toString().equals("/Crypt"))) {
/* 2631 */             skip = true;
/* 2632 */             break;
/*      */           }
/*      */         }
/* 2635 */         if (!skip) {
/* 2636 */           decrypt.setHashKey(stream.getObjNum(), stream.getObjGen());
/* 2637 */           b = decrypt.decryptByteArray(b);
/*      */         }
/*      */       }
/*      */     }
/* 2641 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getStreamBytesRaw(PRStream stream)
/*      */     throws IOException
/*      */   {
/* 2650 */     RandomAccessFileOrArray rf = stream.getReader().getSafeFile();
/*      */     try {
/* 2652 */       rf.reOpen();
/* 2653 */       return getStreamBytesRaw(stream, rf);
/*      */     } finally {
/*      */       try {
/* 2656 */         rf.close();
/*      */       } catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */   public void eliminateSharedStreams() {
/* 2662 */     if (!this.sharedStreams)
/* 2663 */       return;
/* 2664 */     this.sharedStreams = false;
/* 2665 */     if (this.pageRefs.size() == 1)
/* 2666 */       return;
/* 2667 */     ArrayList<PRIndirectReference> newRefs = new ArrayList();
/* 2668 */     ArrayList<PRStream> newStreams = new ArrayList();
/* 2669 */     IntHashtable visited = new IntHashtable();
/* 2670 */     for (int k = 1; k <= this.pageRefs.size(); k++) {
/* 2671 */       PdfDictionary page = this.pageRefs.getPageN(k);
/* 2672 */       if (page != null)
/*      */       {
/* 2674 */         PdfObject contents = getPdfObject(page.get(PdfName.CONTENTS));
/* 2675 */         if (contents != null)
/*      */         {
/* 2677 */           if (contents.isStream()) {
/* 2678 */             PRIndirectReference ref = (PRIndirectReference)page.get(PdfName.CONTENTS);
/* 2679 */             if (visited.containsKey(ref.getNumber()))
/*      */             {
/* 2681 */               newRefs.add(ref);
/* 2682 */               newStreams.add(new PRStream((PRStream)contents, null));
/*      */             }
/*      */             else {
/* 2685 */               visited.put(ref.getNumber(), 1);
/*      */             }
/* 2687 */           } else if (contents.isArray()) {
/* 2688 */             PdfArray array = (PdfArray)contents;
/* 2689 */             for (int j = 0; j < array.size(); j++) {
/* 2690 */               PRIndirectReference ref = (PRIndirectReference)array.getPdfObject(j);
/* 2691 */               if (visited.containsKey(ref.getNumber()))
/*      */               {
/* 2693 */                 newRefs.add(ref);
/* 2694 */                 newStreams.add(new PRStream((PRStream)getPdfObject(ref), null));
/*      */               }
/*      */               else {
/* 2697 */                 visited.put(ref.getNumber(), 1);
/*      */               }
/*      */             }
/*      */           } } } }
/* 2701 */     if (newStreams.isEmpty())
/* 2702 */       return;
/* 2703 */     for (int k = 0; k < newStreams.size(); k++) {
/* 2704 */       this.xrefObj.add(newStreams.get(k));
/* 2705 */       PRIndirectReference ref = (PRIndirectReference)newRefs.get(k);
/* 2706 */       ref.setNumber(this.xrefObj.size() - 1, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTampered()
/*      */   {
/* 2715 */     return this.tampered;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTampered(boolean tampered)
/*      */   {
/* 2723 */     this.tampered = tampered;
/* 2724 */     this.pageRefs.keepPages();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public byte[] getMetadata()
/*      */     throws IOException
/*      */   {
/* 2732 */     PdfObject obj = getPdfObject(this.catalog.get(PdfName.METADATA));
/* 2733 */     if (!(obj instanceof PRStream))
/* 2734 */       return null;
/* 2735 */     RandomAccessFileOrArray rf = getSafeFile();
/* 2736 */     b = null;
/*      */     try {
/* 2738 */       rf.reOpen();
/* 2739 */       return getStreamBytes((PRStream)obj, rf);
/*      */     }
/*      */     finally {
/*      */       try {
/* 2743 */         rf.close();
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLastXref()
/*      */   {
/* 2757 */     return this.lastXref;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getXrefSize()
/*      */   {
/* 2765 */     return this.xrefObj.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getEofPos()
/*      */   {
/* 2773 */     return this.eofPos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char getPdfVersion()
/*      */   {
/* 2782 */     return this.pdfVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEncrypted()
/*      */   {
/* 2790 */     return this.encrypted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getPermissions()
/*      */   {
/* 2799 */     return this.pValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean is128Key()
/*      */   {
/* 2807 */     return this.rValue == 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PdfDictionary getTrailer()
/*      */   {
/* 2815 */     return this.trailer;
/*      */   }
/*      */   
/*      */   PdfEncryption getDecrypt() {
/* 2819 */     return this.decrypt;
/*      */   }
/*      */   
/*      */   static boolean equalsn(byte[] a1, byte[] a2) {
/* 2823 */     int length = a2.length;
/* 2824 */     for (int k = 0; k < length; k++) {
/* 2825 */       if (a1[k] != a2[k])
/* 2826 */         return false;
/*      */     }
/* 2828 */     return true;
/*      */   }
/*      */   
/*      */   static boolean existsName(PdfDictionary dic, PdfName key, PdfName value) {
/* 2832 */     PdfObject type = getPdfObjectRelease(dic.get(key));
/* 2833 */     if ((type == null) || (!type.isName()))
/* 2834 */       return false;
/* 2835 */     PdfName name = (PdfName)type;
/* 2836 */     return name.equals(value);
/*      */   }
/*      */   
/*      */   static String getFontName(PdfDictionary dic) {
/* 2840 */     if (dic == null)
/* 2841 */       return null;
/* 2842 */     PdfObject type = getPdfObjectRelease(dic.get(PdfName.BASEFONT));
/* 2843 */     if ((type == null) || (!type.isName()))
/* 2844 */       return null;
/* 2845 */     return PdfName.decodeName(type.toString());
/*      */   }
/*      */   
/*      */   static String getSubsetPrefix(PdfDictionary dic) {
/* 2849 */     if (dic == null)
/* 2850 */       return null;
/* 2851 */     String s = getFontName(dic);
/* 2852 */     if (s == null)
/* 2853 */       return null;
/* 2854 */     if ((s.length() < 8) || (s.charAt(6) != '+'))
/* 2855 */       return null;
/* 2856 */     for (int k = 0; k < 6; k++) {
/* 2857 */       char c = s.charAt(k);
/* 2858 */       if ((c < 'A') || (c > 'Z'))
/* 2859 */         return null;
/*      */     }
/* 2861 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int shuffleSubsetNames()
/*      */   {
/* 2869 */     int total = 0;
/* 2870 */     for (int k = 1; k < this.xrefObj.size(); k++) {
/* 2871 */       PdfObject obj = getPdfObjectRelease(k);
/* 2872 */       if ((obj != null) && (obj.isDictionary()))
/*      */       {
/* 2874 */         PdfDictionary dic = (PdfDictionary)obj;
/* 2875 */         if (existsName(dic, PdfName.TYPE, PdfName.FONT))
/*      */         {
/* 2877 */           if ((existsName(dic, PdfName.SUBTYPE, PdfName.TYPE1)) || 
/* 2878 */             (existsName(dic, PdfName.SUBTYPE, PdfName.MMTYPE1)) || 
/* 2879 */             (existsName(dic, PdfName.SUBTYPE, PdfName.TRUETYPE))) {
/* 2880 */             String s = getSubsetPrefix(dic);
/* 2881 */             if (s != null)
/*      */             {
/* 2883 */               String ns = BaseFont.createSubsetPrefix() + s.substring(7);
/* 2884 */               PdfName newName = new PdfName(ns);
/* 2885 */               dic.put(PdfName.BASEFONT, newName);
/* 2886 */               setXrefPartialObject(k, dic);
/* 2887 */               total++;
/* 2888 */               PdfDictionary fd = dic.getAsDict(PdfName.FONTDESCRIPTOR);
/* 2889 */               if (fd != null)
/*      */               {
/* 2891 */                 fd.put(PdfName.FONTNAME, newName); }
/*      */             }
/* 2893 */           } else if (existsName(dic, PdfName.SUBTYPE, PdfName.TYPE0)) {
/* 2894 */             String s = getSubsetPrefix(dic);
/* 2895 */             PdfArray arr = dic.getAsArray(PdfName.DESCENDANTFONTS);
/* 2896 */             if (arr != null)
/*      */             {
/* 2898 */               if (!arr.isEmpty())
/*      */               {
/* 2900 */                 PdfDictionary desc = arr.getAsDict(0);
/* 2901 */                 String sde = getSubsetPrefix(desc);
/* 2902 */                 if (sde != null)
/*      */                 {
/* 2904 */                   String ns = BaseFont.createSubsetPrefix();
/* 2905 */                   if (s != null)
/* 2906 */                     dic.put(PdfName.BASEFONT, new PdfName(ns + s.substring(7)));
/* 2907 */                   setXrefPartialObject(k, dic);
/* 2908 */                   PdfName newName = new PdfName(ns + sde.substring(7));
/* 2909 */                   desc.put(PdfName.BASEFONT, newName);
/* 2910 */                   total++;
/* 2911 */                   PdfDictionary fd = desc.getAsDict(PdfName.FONTDESCRIPTOR);
/* 2912 */                   if (fd != null)
/*      */                   {
/* 2914 */                     fd.put(PdfName.FONTNAME, newName); }
/*      */                 }
/*      */               } } } } } }
/* 2917 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int createFakeFontSubsets()
/*      */   {
/* 2924 */     int total = 0;
/* 2925 */     for (int k = 1; k < this.xrefObj.size(); k++) {
/* 2926 */       PdfObject obj = getPdfObjectRelease(k);
/* 2927 */       if ((obj != null) && (obj.isDictionary()))
/*      */       {
/* 2929 */         PdfDictionary dic = (PdfDictionary)obj;
/* 2930 */         if (existsName(dic, PdfName.TYPE, PdfName.FONT))
/*      */         {
/* 2932 */           if ((existsName(dic, PdfName.SUBTYPE, PdfName.TYPE1)) || 
/* 2933 */             (existsName(dic, PdfName.SUBTYPE, PdfName.MMTYPE1)) || 
/* 2934 */             (existsName(dic, PdfName.SUBTYPE, PdfName.TRUETYPE))) {
/* 2935 */             String s = getSubsetPrefix(dic);
/* 2936 */             if (s == null)
/*      */             {
/* 2938 */               s = getFontName(dic);
/* 2939 */               if (s != null)
/*      */               {
/* 2941 */                 String ns = BaseFont.createSubsetPrefix() + s;
/* 2942 */                 PdfDictionary fd = (PdfDictionary)getPdfObjectRelease(dic.get(PdfName.FONTDESCRIPTOR));
/* 2943 */                 if (fd != null)
/*      */                 {
/* 2945 */                   if ((fd.get(PdfName.FONTFILE) != null) || (fd.get(PdfName.FONTFILE2) != null) || 
/* 2946 */                     (fd.get(PdfName.FONTFILE3) != null))
/*      */                   {
/* 2948 */                     fd = dic.getAsDict(PdfName.FONTDESCRIPTOR);
/* 2949 */                     PdfName newName = new PdfName(ns);
/* 2950 */                     dic.put(PdfName.BASEFONT, newName);
/* 2951 */                     fd.put(PdfName.FONTNAME, newName);
/* 2952 */                     setXrefPartialObject(k, dic);
/* 2953 */                     total++;
/*      */                   } }
/*      */               } } } } } }
/* 2956 */     return total;
/*      */   }
/*      */   
/*      */   private static PdfArray getNameArray(PdfObject obj) {
/* 2960 */     if (obj == null)
/* 2961 */       return null;
/* 2962 */     obj = getPdfObjectRelease(obj);
/* 2963 */     if (obj == null)
/* 2964 */       return null;
/* 2965 */     if (obj.isArray())
/* 2966 */       return (PdfArray)obj;
/* 2967 */     if (obj.isDictionary()) {
/* 2968 */       PdfObject arr2 = getPdfObjectRelease(((PdfDictionary)obj).get(PdfName.D));
/* 2969 */       if ((arr2 != null) && (arr2.isArray()))
/* 2970 */         return (PdfArray)arr2;
/*      */     }
/* 2972 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<Object, PdfObject> getNamedDestination()
/*      */   {
/* 2981 */     return getNamedDestination(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<Object, PdfObject> getNamedDestination(boolean keepNames)
/*      */   {
/* 2992 */     HashMap<Object, PdfObject> names = getNamedDestinationFromNames(keepNames);
/* 2993 */     names.putAll(getNamedDestinationFromStrings());
/* 2994 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<String, PdfObject> getNamedDestinationFromNames()
/*      */   {
/* 3005 */     return new HashMap(getNamedDestinationFromNames(false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<Object, PdfObject> getNamedDestinationFromNames(boolean keepNames)
/*      */   {
/* 3016 */     HashMap<Object, PdfObject> names = new HashMap();
/* 3017 */     PdfDictionary dic; if (this.catalog.get(PdfName.DESTS) != null) {
/* 3018 */       dic = (PdfDictionary)getPdfObjectRelease(this.catalog.get(PdfName.DESTS));
/* 3019 */       if (dic == null)
/* 3020 */         return names;
/* 3021 */       Set<PdfName> keys = dic.getKeys();
/* 3022 */       for (PdfName key : keys) {
/* 3023 */         PdfArray arr = getNameArray(dic.get(key));
/* 3024 */         if (arr != null)
/*      */         {
/* 3026 */           if (keepNames) {
/* 3027 */             names.put(key, arr);
/*      */           }
/*      */           else {
/* 3030 */             String name = PdfName.decodeName(key.toString());
/* 3031 */             names.put(name, arr);
/*      */           } }
/*      */       }
/*      */     }
/* 3035 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<String, PdfObject> getNamedDestinationFromStrings()
/*      */   {
/* 3044 */     if (this.catalog.get(PdfName.NAMES) != null) {
/* 3045 */       PdfDictionary dic = (PdfDictionary)getPdfObjectRelease(this.catalog.get(PdfName.NAMES));
/* 3046 */       if (dic != null) {
/* 3047 */         dic = (PdfDictionary)getPdfObjectRelease(dic.get(PdfName.DESTS));
/* 3048 */         if (dic != null) {
/* 3049 */           HashMap<String, PdfObject> names = PdfNameTree.readTree(dic);
/* 3050 */           for (Iterator<Map.Entry<String, PdfObject>> it = names.entrySet().iterator(); it.hasNext();) {
/* 3051 */             Map.Entry<String, PdfObject> entry = (Map.Entry)it.next();
/* 3052 */             PdfArray arr = getNameArray((PdfObject)entry.getValue());
/* 3053 */             if (arr != null) {
/* 3054 */               entry.setValue(arr);
/*      */             } else
/* 3056 */               it.remove();
/*      */           }
/* 3058 */           return names;
/*      */         }
/*      */       }
/*      */     }
/* 3062 */     return new HashMap();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeFields()
/*      */   {
/* 3069 */     this.pageRefs.resetReleasePage();
/* 3070 */     for (int k = 1; k <= this.pageRefs.size(); k++) {
/* 3071 */       PdfDictionary page = this.pageRefs.getPageN(k);
/* 3072 */       PdfArray annots = page.getAsArray(PdfName.ANNOTS);
/* 3073 */       if (annots == null) {
/* 3074 */         this.pageRefs.releasePage(k);
/*      */       }
/*      */       else {
/* 3077 */         for (int j = 0; j < annots.size(); j++) {
/* 3078 */           PdfObject obj = getPdfObjectRelease(annots.getPdfObject(j));
/* 3079 */           if ((obj != null) && (obj.isDictionary()))
/*      */           {
/* 3081 */             PdfDictionary annot = (PdfDictionary)obj;
/* 3082 */             if (PdfName.WIDGET.equals(annot.get(PdfName.SUBTYPE)))
/* 3083 */               annots.remove(j--);
/*      */           } }
/* 3085 */         if (annots.isEmpty()) {
/* 3086 */           page.remove(PdfName.ANNOTS);
/*      */         } else
/* 3088 */           this.pageRefs.releasePage(k);
/*      */       } }
/* 3090 */     this.catalog.remove(PdfName.ACROFORM);
/* 3091 */     this.pageRefs.resetReleasePage();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeAnnotations()
/*      */   {
/* 3098 */     this.pageRefs.resetReleasePage();
/* 3099 */     for (int k = 1; k <= this.pageRefs.size(); k++) {
/* 3100 */       PdfDictionary page = this.pageRefs.getPageN(k);
/* 3101 */       if (page.get(PdfName.ANNOTS) == null) {
/* 3102 */         this.pageRefs.releasePage(k);
/*      */       } else
/* 3104 */         page.remove(PdfName.ANNOTS);
/*      */     }
/* 3106 */     this.catalog.remove(PdfName.ACROFORM);
/* 3107 */     this.pageRefs.resetReleasePage();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<PdfAnnotation.PdfImportedLink> getLinks(int page)
/*      */   {
/* 3116 */     this.pageRefs.resetReleasePage();
/* 3117 */     ArrayList<PdfAnnotation.PdfImportedLink> result = new ArrayList();
/* 3118 */     PdfDictionary pageDic = this.pageRefs.getPageN(page);
/* 3119 */     if (pageDic.get(PdfName.ANNOTS) != null) {
/* 3120 */       PdfArray annots = pageDic.getAsArray(PdfName.ANNOTS);
/* 3121 */       for (int j = 0; j < annots.size(); j++) {
/* 3122 */         PdfDictionary annot = (PdfDictionary)getPdfObjectRelease(annots.getPdfObject(j));
/*      */         
/* 3124 */         if (PdfName.LINK.equals(annot.get(PdfName.SUBTYPE))) {
/* 3125 */           result.add(new PdfAnnotation.PdfImportedLink(annot));
/*      */         }
/*      */       }
/*      */     }
/* 3129 */     this.pageRefs.releasePage(page);
/* 3130 */     this.pageRefs.resetReleasePage();
/* 3131 */     return result;
/*      */   }
/*      */   
/*      */   private void iterateBookmarks(PdfObject outlineRef, HashMap<Object, PdfObject> names) {
/* 3135 */     while (outlineRef != null) {
/* 3136 */       replaceNamedDestination(outlineRef, names);
/* 3137 */       PdfDictionary outline = (PdfDictionary)getPdfObjectRelease(outlineRef);
/* 3138 */       PdfObject first = outline.get(PdfName.FIRST);
/* 3139 */       if (first != null) {
/* 3140 */         iterateBookmarks(first, names);
/*      */       }
/* 3142 */       outlineRef = outline.get(PdfName.NEXT);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void makeRemoteNamedDestinationsLocal()
/*      */   {
/* 3151 */     if (this.remoteToLocalNamedDestinations)
/* 3152 */       return;
/* 3153 */     this.remoteToLocalNamedDestinations = true;
/* 3154 */     HashMap<Object, PdfObject> names = getNamedDestination(true);
/* 3155 */     if (names.isEmpty())
/* 3156 */       return;
/* 3157 */     for (int k = 1; k <= this.pageRefs.size(); k++) {
/* 3158 */       PdfDictionary page = this.pageRefs.getPageN(k);
/*      */       PdfObject annotsRef;
/* 3160 */       PdfArray annots = (PdfArray)getPdfObject(annotsRef = page.get(PdfName.ANNOTS));
/* 3161 */       int annotIdx = this.lastXrefPartial;
/* 3162 */       releaseLastXrefPartial();
/* 3163 */       if (annots == null) {
/* 3164 */         this.pageRefs.releasePage(k);
/*      */       }
/*      */       else {
/* 3167 */         boolean commitAnnots = false;
/* 3168 */         for (int an = 0; an < annots.size(); an++) {
/* 3169 */           PdfObject objRef = annots.getPdfObject(an);
/* 3170 */           if ((convertNamedDestination(objRef, names)) && (!objRef.isIndirect()))
/* 3171 */             commitAnnots = true;
/*      */         }
/* 3173 */         if (commitAnnots)
/* 3174 */           setXrefPartialObject(annotIdx, annots);
/* 3175 */         if ((!commitAnnots) || (annotsRef.isIndirect())) {
/* 3176 */           this.pageRefs.releasePage(k);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean convertNamedDestination(PdfObject obj, HashMap<Object, PdfObject> names)
/*      */   {
/* 3188 */     obj = getPdfObject(obj);
/* 3189 */     int objIdx = this.lastXrefPartial;
/* 3190 */     releaseLastXrefPartial();
/* 3191 */     if ((obj != null) && (obj.isDictionary())) {
/* 3192 */       PdfObject ob2 = getPdfObject(((PdfDictionary)obj).get(PdfName.A));
/* 3193 */       if (ob2 != null) {
/* 3194 */         int obj2Idx = this.lastXrefPartial;
/* 3195 */         releaseLastXrefPartial();
/* 3196 */         PdfDictionary dic = (PdfDictionary)ob2;
/* 3197 */         PdfName type = (PdfName)getPdfObjectRelease(dic.get(PdfName.S));
/* 3198 */         if (PdfName.GOTOR.equals(type)) {
/* 3199 */           PdfObject ob3 = getPdfObjectRelease(dic.get(PdfName.D));
/* 3200 */           Object name = null;
/* 3201 */           if (ob3 != null) {
/* 3202 */             if (ob3.isName()) {
/* 3203 */               name = ob3;
/* 3204 */             } else if (ob3.isString())
/* 3205 */               name = ob3.toString();
/* 3206 */             PdfArray dest = (PdfArray)names.get(name);
/* 3207 */             if (dest != null) {
/* 3208 */               dic.remove(PdfName.F);
/* 3209 */               dic.remove(PdfName.NEWWINDOW);
/* 3210 */               dic.put(PdfName.S, PdfName.GOTO);
/* 3211 */               setXrefPartialObject(obj2Idx, ob2);
/* 3212 */               setXrefPartialObject(objIdx, obj);
/* 3213 */               return true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 3219 */     return false;
/*      */   }
/*      */   
/*      */   public void consolidateNamedDestinations()
/*      */   {
/* 3224 */     if (this.consolidateNamedDestinations)
/* 3225 */       return;
/* 3226 */     this.consolidateNamedDestinations = true;
/* 3227 */     HashMap<Object, PdfObject> names = getNamedDestination(true);
/* 3228 */     if (names.isEmpty())
/* 3229 */       return;
/* 3230 */     for (int k = 1; k <= this.pageRefs.size(); k++) {
/* 3231 */       PdfDictionary page = this.pageRefs.getPageN(k);
/*      */       PdfObject annotsRef;
/* 3233 */       PdfArray annots = (PdfArray)getPdfObject(annotsRef = page.get(PdfName.ANNOTS));
/* 3234 */       int annotIdx = this.lastXrefPartial;
/* 3235 */       releaseLastXrefPartial();
/* 3236 */       if (annots == null) {
/* 3237 */         this.pageRefs.releasePage(k);
/*      */       }
/*      */       else {
/* 3240 */         boolean commitAnnots = false;
/* 3241 */         for (int an = 0; an < annots.size(); an++) {
/* 3242 */           PdfObject objRef = annots.getPdfObject(an);
/* 3243 */           if ((replaceNamedDestination(objRef, names)) && (!objRef.isIndirect()))
/* 3244 */             commitAnnots = true;
/*      */         }
/* 3246 */         if (commitAnnots)
/* 3247 */           setXrefPartialObject(annotIdx, annots);
/* 3248 */         if ((!commitAnnots) || (annotsRef.isIndirect()))
/* 3249 */           this.pageRefs.releasePage(k);
/*      */       } }
/* 3251 */     PdfDictionary outlines = (PdfDictionary)getPdfObjectRelease(this.catalog.get(PdfName.OUTLINES));
/* 3252 */     if (outlines == null)
/* 3253 */       return;
/* 3254 */     iterateBookmarks(outlines.get(PdfName.FIRST), names);
/*      */   }
/*      */   
/*      */   private boolean replaceNamedDestination(PdfObject obj, HashMap<Object, PdfObject> names) {
/* 3258 */     obj = getPdfObject(obj);
/* 3259 */     int objIdx = this.lastXrefPartial;
/* 3260 */     releaseLastXrefPartial();
/* 3261 */     if ((obj != null) && (obj.isDictionary())) {
/* 3262 */       PdfObject ob2 = getPdfObjectRelease(((PdfDictionary)obj).get(PdfName.DEST));
/* 3263 */       Object name = null;
/* 3264 */       if (ob2 != null) {
/* 3265 */         if (ob2.isName()) {
/* 3266 */           name = ob2;
/* 3267 */         } else if (ob2.isString())
/* 3268 */           name = ob2.toString();
/* 3269 */         PdfArray dest = (PdfArray)names.get(name);
/* 3270 */         if (dest != null) {
/* 3271 */           ((PdfDictionary)obj).put(PdfName.DEST, dest);
/* 3272 */           setXrefPartialObject(objIdx, obj);
/* 3273 */           return true;
/*      */         }
/*      */       }
/* 3276 */       else if ((ob2 = getPdfObject(((PdfDictionary)obj).get(PdfName.A))) != null) {
/* 3277 */         int obj2Idx = this.lastXrefPartial;
/* 3278 */         releaseLastXrefPartial();
/* 3279 */         PdfDictionary dic = (PdfDictionary)ob2;
/* 3280 */         PdfName type = (PdfName)getPdfObjectRelease(dic.get(PdfName.S));
/* 3281 */         if (PdfName.GOTO.equals(type)) {
/* 3282 */           PdfObject ob3 = getPdfObjectRelease(dic.get(PdfName.D));
/* 3283 */           if (ob3 != null) {
/* 3284 */             if (ob3.isName()) {
/* 3285 */               name = ob3;
/* 3286 */             } else if (ob3.isString())
/* 3287 */               name = ob3.toString();
/*      */           }
/* 3289 */           PdfArray dest = (PdfArray)names.get(name);
/* 3290 */           if (dest != null) {
/* 3291 */             dic.put(PdfName.D, dest);
/* 3292 */             setXrefPartialObject(obj2Idx, ob2);
/* 3293 */             setXrefPartialObject(objIdx, obj);
/* 3294 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 3299 */     return false;
/*      */   }
/*      */   
/*      */   protected static PdfDictionary duplicatePdfDictionary(PdfDictionary original, PdfDictionary copy, PdfReader newReader) {
/* 3303 */     if (copy == null)
/* 3304 */       copy = new PdfDictionary(original.size());
/* 3305 */     for (Object element : original.getKeys()) {
/* 3306 */       PdfName key = (PdfName)element;
/* 3307 */       copy.put(key, duplicatePdfObject(original.get(key), newReader));
/*      */     }
/* 3309 */     return copy;
/*      */   }
/*      */   
/*      */   protected static PdfObject duplicatePdfObject(PdfObject original, PdfReader newReader) {
/* 3313 */     if (original == null)
/* 3314 */       return null;
/* 3315 */     switch (original.type()) {
/*      */     case 6: 
/* 3317 */       return duplicatePdfDictionary((PdfDictionary)original, null, newReader);
/*      */     
/*      */     case 7: 
/* 3320 */       PRStream org = (PRStream)original;
/* 3321 */       PRStream stream = new PRStream(org, null, newReader);
/* 3322 */       duplicatePdfDictionary(org, stream, newReader);
/* 3323 */       return stream;
/*      */     
/*      */     case 5: 
/* 3326 */       PdfArray originalArray = (PdfArray)original;
/* 3327 */       PdfArray arr = new PdfArray(originalArray.size());
/* 3328 */       for (Iterator<PdfObject> it = originalArray.listIterator(); it.hasNext();) {
/* 3329 */         arr.add(duplicatePdfObject((PdfObject)it.next(), newReader));
/*      */       }
/* 3331 */       return arr;
/*      */     
/*      */     case 10: 
/* 3334 */       PRIndirectReference org = (PRIndirectReference)original;
/* 3335 */       return new PRIndirectReference(newReader, org.getNumber(), org.getGeneration());
/*      */     }
/*      */     
/* 3338 */     return original;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/*      */     try
/*      */     {
/* 3347 */       this.tokens.close();
/*      */     }
/*      */     catch (IOException e) {
/* 3350 */       throw new ExceptionConverter(e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void removeUnusedNode(PdfObject obj, boolean[] hits)
/*      */   {
/* 3356 */     Stack<Object> state = new Stack();
/* 3357 */     state.push(obj);
/* 3358 */     while (!state.empty()) {
/* 3359 */       Object current = state.pop();
/* 3360 */       if (current != null)
/*      */       {
/* 3362 */         ArrayList<PdfObject> ar = null;
/* 3363 */         PdfDictionary dic = null;
/* 3364 */         PdfName[] keys = null;
/* 3365 */         Object[] objs = null;
/* 3366 */         int idx = 0;
/* 3367 */         if ((current instanceof PdfObject)) {
/* 3368 */           obj = (PdfObject)current;
/* 3369 */           switch (obj.type()) {
/*      */           case 6: 
/*      */           case 7: 
/* 3372 */             dic = (PdfDictionary)obj;
/* 3373 */             keys = new PdfName[dic.size()];
/* 3374 */             dic.getKeys().toArray(keys);
/* 3375 */             break;
/*      */           case 5: 
/* 3377 */             ar = ((PdfArray)obj).getArrayList();
/* 3378 */             break;
/*      */           case 10: 
/* 3380 */             PRIndirectReference ref = (PRIndirectReference)obj;
/* 3381 */             int num = ref.getNumber();
/* 3382 */             if (hits[num] != 0) continue;
/* 3383 */             hits[num] = true;
/* 3384 */             state.push(getPdfObjectRelease(ref)); break;
/*      */           
/*      */ 
/*      */           }
/*      */           
/*      */         }
/*      */         else
/*      */         {
/* 3392 */           objs = (Object[])current;
/* 3393 */           if ((objs[0] instanceof ArrayList)) {
/* 3394 */             ar = (ArrayList)objs[0];
/* 3395 */             idx = ((Integer)objs[1]).intValue();
/*      */           }
/*      */           else {
/* 3398 */             keys = (PdfName[])objs[0];
/* 3399 */             dic = (PdfDictionary)objs[1];
/* 3400 */             idx = ((Integer)objs[2]).intValue();
/*      */           }
/*      */           
/* 3403 */           if (ar != null) {
/* 3404 */             for (int k = idx; k < ar.size(); k++) {
/* 3405 */               PdfObject v = (PdfObject)ar.get(k);
/* 3406 */               if (v.isIndirect()) {
/* 3407 */                 int num = ((PRIndirectReference)v).getNumber();
/* 3408 */                 if ((num >= this.xrefObj.size()) || ((!this.partial) && (this.xrefObj.get(num) == null))) {
/* 3409 */                   ar.set(k, PdfNull.PDFNULL);
/* 3410 */                   continue;
/*      */                 }
/*      */               }
/* 3413 */               if (objs == null) {
/* 3414 */                 state.push(new Object[] { ar, Integer.valueOf(k + 1) });
/*      */               } else {
/* 3416 */                 objs[1] = Integer.valueOf(k + 1);
/* 3417 */                 state.push(objs);
/*      */               }
/* 3419 */               state.push(v);
/* 3420 */               break;
/*      */             }
/*      */             
/*      */           } else {
/* 3424 */             for (int k = idx; k < keys.length; k++) {
/* 3425 */               PdfName key = keys[k];
/* 3426 */               PdfObject v = dic.get(key);
/* 3427 */               if (v.isIndirect()) {
/* 3428 */                 int num = ((PRIndirectReference)v).getNumber();
/* 3429 */                 if ((num < 0) || (num >= this.xrefObj.size()) || ((!this.partial) && (this.xrefObj.get(num) == null))) {
/* 3430 */                   dic.put(key, PdfNull.PDFNULL);
/* 3431 */                   continue;
/*      */                 }
/*      */               }
/* 3434 */               if (objs == null) {
/* 3435 */                 state.push(new Object[] { keys, dic, Integer.valueOf(k + 1) });
/*      */               } else {
/* 3437 */                 objs[2] = Integer.valueOf(k + 1);
/* 3438 */                 state.push(objs);
/*      */               }
/* 3440 */               state.push(v);
/* 3441 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int removeUnusedObjects()
/*      */   {
/* 3452 */     boolean[] hits = new boolean[this.xrefObj.size()];
/* 3453 */     removeUnusedNode(this.trailer, hits);
/* 3454 */     int total = 0;
/* 3455 */     if (this.partial) {
/* 3456 */       for (int k = 1; k < hits.length; k++) {
/* 3457 */         if (hits[k] == 0) {
/* 3458 */           this.xref[(k * 2)] = -1L;
/* 3459 */           this.xref[(k * 2 + 1)] = 0L;
/* 3460 */           this.xrefObj.set(k, null);
/* 3461 */           total++;
/*      */         }
/*      */         
/*      */       }
/*      */     } else {
/* 3466 */       for (int k = 1; k < hits.length; k++) {
/* 3467 */         if (hits[k] == 0) {
/* 3468 */           this.xrefObj.set(k, null);
/* 3469 */           total++;
/*      */         }
/*      */       }
/*      */     }
/* 3473 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AcroFields getAcroFields()
/*      */   {
/* 3480 */     return new AcroFields(this, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getJavaScript(RandomAccessFileOrArray file)
/*      */     throws IOException
/*      */   {
/* 3490 */     PdfDictionary names = (PdfDictionary)getPdfObjectRelease(this.catalog.get(PdfName.NAMES));
/* 3491 */     if (names == null)
/* 3492 */       return null;
/* 3493 */     PdfDictionary js = (PdfDictionary)getPdfObjectRelease(names.get(PdfName.JAVASCRIPT));
/* 3494 */     if (js == null)
/* 3495 */       return null;
/* 3496 */     HashMap<String, PdfObject> jscript = PdfNameTree.readTree(js);
/* 3497 */     String[] sortedNames = new String[jscript.size()];
/* 3498 */     sortedNames = (String[])jscript.keySet().toArray(sortedNames);
/* 3499 */     Arrays.sort(sortedNames);
/* 3500 */     StringBuffer buf = new StringBuffer();
/* 3501 */     for (int k = 0; k < sortedNames.length; k++) {
/* 3502 */       PdfDictionary j = (PdfDictionary)getPdfObjectRelease((PdfObject)jscript.get(sortedNames[k]));
/* 3503 */       if (j != null)
/*      */       {
/* 3505 */         PdfObject obj = getPdfObjectRelease(j.get(PdfName.JS));
/* 3506 */         if (obj != null)
/* 3507 */           if (obj.isString()) {
/* 3508 */             buf.append(((PdfString)obj).toUnicodeString()).append('\n');
/* 3509 */           } else if (obj.isStream()) {
/* 3510 */             byte[] bytes = getStreamBytes((PRStream)obj, file);
/* 3511 */             if ((bytes.length >= 2) && (bytes[0] == -2) && (bytes[1] == -1)) {
/* 3512 */               buf.append(PdfEncodings.convertToString(bytes, "UnicodeBig"));
/*      */             } else
/* 3514 */               buf.append(PdfEncodings.convertToString(bytes, "PDF"));
/* 3515 */             buf.append('\n');
/*      */           }
/*      */       }
/*      */     }
/* 3519 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getJavaScript()
/*      */     throws IOException
/*      */   {
/* 3528 */     RandomAccessFileOrArray rf = getSafeFile();
/*      */     try {
/* 3530 */       rf.reOpen();
/* 3531 */       return getJavaScript(rf);
/*      */     } finally {
/*      */       try {
/* 3534 */         rf.close();
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectPages(String ranges)
/*      */   {
/* 3545 */     selectPages(SequenceList.expand(ranges, getNumberOfPages()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectPages(List<Integer> pagesToKeep)
/*      */   {
/* 3555 */     selectPages(pagesToKeep, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void selectPages(List<Integer> pagesToKeep, boolean removeUnused)
/*      */   {
/* 3566 */     this.pageRefs.selectPages(pagesToKeep);
/* 3567 */     if (removeUnused) { removeUnusedObjects();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setViewerPreferences(int preferences)
/*      */   {
/* 3575 */     this.viewerPreferences.setViewerPreferences(preferences);
/* 3576 */     setViewerPreferences(this.viewerPreferences);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addViewerPreference(PdfName key, PdfObject value)
/*      */   {
/* 3585 */     this.viewerPreferences.addViewerPreference(key, value);
/* 3586 */     setViewerPreferences(this.viewerPreferences);
/*      */   }
/*      */   
/*      */   public void setViewerPreferences(PdfViewerPreferencesImp vp) {
/* 3590 */     vp.addToCatalog(this.catalog);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSimpleViewerPreferences()
/*      */   {
/* 3599 */     return PdfViewerPreferencesImp.getViewerPreferences(this.catalog).getPageLayoutAndMode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAppendable()
/*      */   {
/* 3607 */     return this.appendable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAppendable(boolean appendable)
/*      */   {
/* 3615 */     this.appendable = appendable;
/* 3616 */     if (appendable) {
/* 3617 */       getPdfObject(this.trailer.get(PdfName.ROOT));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isNewXrefType()
/*      */   {
/* 3625 */     return this.newXrefType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getFileLength()
/*      */   {
/* 3633 */     return this.fileLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHybridXref()
/*      */   {
/* 3641 */     return this.hybridXref;
/*      */   }
/*      */   
/*      */ 
/*      */   static class PageRefs
/*      */   {
/*      */     private final PdfReader reader;
/*      */     
/*      */     private ArrayList<PRIndirectReference> refsn;
/*      */     
/*      */     private int sizep;
/*      */     private IntHashtable refsp;
/* 3653 */     private int lastPageRead = -1;
/*      */     
/*      */ 
/*      */     private ArrayList<PdfDictionary> pageInh;
/*      */     
/*      */     private boolean keepPages;
/*      */     
/* 3660 */     private Set<PdfObject> pagesNodes = new HashSet();
/*      */     
/*      */     private PageRefs(PdfReader reader) throws IOException {
/* 3663 */       this.reader = reader;
/* 3664 */       if (reader.partial) {
/* 3665 */         this.refsp = new IntHashtable();
/* 3666 */         PdfNumber npages = (PdfNumber)PdfReader.getPdfObjectRelease(reader.rootPages.get(PdfName.COUNT));
/* 3667 */         this.sizep = npages.intValue();
/*      */       }
/*      */       else {
/* 3670 */         readPages();
/*      */       }
/*      */     }
/*      */     
/*      */     PageRefs(PageRefs other, PdfReader reader) {
/* 3675 */       this.reader = reader;
/* 3676 */       this.sizep = other.sizep;
/* 3677 */       if (other.refsn != null) {
/* 3678 */         this.refsn = new ArrayList(other.refsn);
/* 3679 */         for (int k = 0; k < this.refsn.size(); k++) {
/* 3680 */           this.refsn.set(k, (PRIndirectReference)PdfReader.duplicatePdfObject((PdfObject)this.refsn.get(k), reader));
/*      */         }
/*      */       }
/*      */       else {
/* 3684 */         this.refsp = ((IntHashtable)other.refsp.clone());
/*      */       }
/*      */     }
/*      */     
/* 3688 */     int size() { if (this.refsn != null) {
/* 3689 */         return this.refsn.size();
/*      */       }
/* 3691 */       return this.sizep;
/*      */     }
/*      */     
/*      */     void readPages() throws IOException {
/* 3695 */       if (this.refsn != null)
/* 3696 */         return;
/* 3697 */       this.refsp = null;
/* 3698 */       this.refsn = new ArrayList();
/* 3699 */       this.pageInh = new ArrayList();
/* 3700 */       iteratePages((PRIndirectReference)this.reader.catalog.get(PdfName.PAGES));
/* 3701 */       this.pageInh = null;
/* 3702 */       this.reader.rootPages.put(PdfName.COUNT, new PdfNumber(this.refsn.size()));
/*      */     }
/*      */     
/*      */     void reReadPages() throws IOException {
/* 3706 */       this.refsn = null;
/* 3707 */       readPages();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfDictionary getPageN(int pageNum)
/*      */     {
/* 3715 */       PRIndirectReference ref = getPageOrigRef(pageNum);
/* 3716 */       return (PdfDictionary)PdfReader.getPdfObject(ref);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public PdfDictionary getPageNRelease(int pageNum)
/*      */     {
/* 3724 */       PdfDictionary page = getPageN(pageNum);
/* 3725 */       releasePage(pageNum);
/* 3726 */       return page;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public PRIndirectReference getPageOrigRefRelease(int pageNum)
/*      */     {
/* 3734 */       PRIndirectReference ref = getPageOrigRef(pageNum);
/* 3735 */       releasePage(pageNum);
/* 3736 */       return ref;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public PRIndirectReference getPageOrigRef(int pageNum)
/*      */     {
/*      */       try
/*      */       {
/*      */         
/*      */         
/* 3747 */         if ((pageNum < 0) || (pageNum >= size()))
/* 3748 */           return null;
/* 3749 */         if (this.refsn != null) {
/* 3750 */           return (PRIndirectReference)this.refsn.get(pageNum);
/*      */         }
/* 3752 */         int n = this.refsp.get(pageNum);
/* 3753 */         if (n == 0) {
/* 3754 */           PRIndirectReference ref = getSinglePage(pageNum);
/* 3755 */           if (this.reader.lastXrefPartial == -1) {
/* 3756 */             this.lastPageRead = -1;
/*      */           } else
/* 3758 */             this.lastPageRead = pageNum;
/* 3759 */           this.reader.lastXrefPartial = -1;
/* 3760 */           this.refsp.put(pageNum, ref.getNumber());
/* 3761 */           if (this.keepPages)
/* 3762 */             this.lastPageRead = -1;
/* 3763 */           return ref;
/*      */         }
/*      */         
/* 3766 */         if (this.lastPageRead != pageNum)
/* 3767 */           this.lastPageRead = -1;
/* 3768 */         if (this.keepPages)
/* 3769 */           this.lastPageRead = -1;
/* 3770 */         return new PRIndirectReference(this.reader, n);
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 3775 */         throw new ExceptionConverter(e);
/*      */       }
/*      */     }
/*      */     
/*      */     void keepPages() {
/* 3780 */       if ((this.refsp == null) || (this.keepPages))
/* 3781 */         return;
/* 3782 */       this.keepPages = true;
/* 3783 */       this.refsp.clear();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void releasePage(int pageNum)
/*      */     {
/* 3790 */       if (this.refsp == null)
/* 3791 */         return;
/* 3792 */       pageNum--;
/* 3793 */       if ((pageNum < 0) || (pageNum >= size()))
/* 3794 */         return;
/* 3795 */       if (pageNum != this.lastPageRead)
/* 3796 */         return;
/* 3797 */       this.lastPageRead = -1;
/* 3798 */       this.reader.lastXrefPartial = this.refsp.get(pageNum);
/* 3799 */       this.reader.releaseLastXrefPartial();
/* 3800 */       this.refsp.remove(pageNum);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void resetReleasePage()
/*      */     {
/* 3807 */       if (this.refsp == null)
/* 3808 */         return;
/* 3809 */       this.lastPageRead = -1;
/*      */     }
/*      */     
/*      */     void insertPage(int pageNum, PRIndirectReference ref) {
/*      */       
/* 3814 */       if (this.refsn != null) {
/* 3815 */         if (pageNum >= this.refsn.size()) {
/* 3816 */           this.refsn.add(ref);
/*      */         } else {
/* 3818 */           this.refsn.add(pageNum, ref);
/*      */         }
/*      */       } else {
/* 3821 */         this.sizep += 1;
/* 3822 */         this.lastPageRead = -1;
/* 3823 */         if (pageNum >= size()) {
/* 3824 */           this.refsp.put(size(), ref.getNumber());
/*      */         }
/*      */         else {
/* 3827 */           IntHashtable refs2 = new IntHashtable((this.refsp.size() + 1) * 2);
/* 3828 */           for (Iterator<IntHashtable.Entry> it = this.refsp.getEntryIterator(); it.hasNext();) {
/* 3829 */             IntHashtable.Entry entry = (IntHashtable.Entry)it.next();
/* 3830 */             int p = entry.getKey();
/* 3831 */             refs2.put(p >= pageNum ? p + 1 : p, entry.getValue());
/*      */           }
/* 3833 */           refs2.put(pageNum, ref.getNumber());
/* 3834 */           this.refsp = refs2;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void pushPageAttributes(PdfDictionary nodePages)
/*      */     {
/* 3844 */       PdfDictionary dic = new PdfDictionary();
/* 3845 */       if (!this.pageInh.isEmpty()) {
/* 3846 */         dic.putAll((PdfDictionary)this.pageInh.get(this.pageInh.size() - 1));
/*      */       }
/* 3848 */       for (int k = 0; k < PdfReader.pageInhCandidates.length; k++) {
/* 3849 */         PdfObject obj = nodePages.get(PdfReader.pageInhCandidates[k]);
/* 3850 */         if (obj != null)
/* 3851 */           dic.put(PdfReader.pageInhCandidates[k], obj);
/*      */       }
/* 3853 */       this.pageInh.add(dic);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private void popPageAttributes()
/*      */     {
/* 3860 */       this.pageInh.remove(this.pageInh.size() - 1);
/*      */     }
/*      */     
/*      */     private void iteratePages(PRIndirectReference rpage) throws IOException {
/* 3864 */       if (!this.pagesNodes.add(PdfReader.getPdfObject(rpage))) {
/* 3865 */         throw new InvalidPdfException(MessageLocalization.getComposedMessage("illegal.pages.tree", new Object[0]));
/*      */       }
/* 3867 */       PdfDictionary page = (PdfDictionary)PdfReader.getPdfObject(rpage);
/* 3868 */       if (page == null)
/* 3869 */         return;
/* 3870 */       PdfArray kidsPR = page.getAsArray(PdfName.KIDS);
/*      */       
/* 3872 */       if (kidsPR == null) {
/* 3873 */         page.put(PdfName.TYPE, PdfName.PAGE);
/* 3874 */         PdfDictionary dic = (PdfDictionary)this.pageInh.get(this.pageInh.size() - 1);
/*      */         
/* 3876 */         for (Object element : dic.getKeys()) {
/* 3877 */           PdfName key = (PdfName)element;
/* 3878 */           if (page.get(key) == null)
/* 3879 */             page.put(key, dic.get(key));
/*      */         }
/* 3881 */         if (page.get(PdfName.MEDIABOX) == null) {
/* 3882 */           PdfArray arr = new PdfArray(new float[] { 0.0F, 0.0F, PageSize.LETTER.getRight(), PageSize.LETTER.getTop() });
/* 3883 */           page.put(PdfName.MEDIABOX, arr);
/*      */         }
/* 3885 */         this.refsn.add(rpage);
/*      */       }
/*      */       else
/*      */       {
/* 3889 */         page.put(PdfName.TYPE, PdfName.PAGES);
/* 3890 */         pushPageAttributes(page);
/* 3891 */         for (int k = 0; k < kidsPR.size(); k++) {
/* 3892 */           PdfObject obj = kidsPR.getPdfObject(k);
/* 3893 */           if (!obj.isIndirect()) {
/* 3894 */             while (k < kidsPR.size()) {
/* 3895 */               kidsPR.remove(k);
/*      */             }
/*      */           }
/* 3898 */           iteratePages((PRIndirectReference)obj);
/*      */         }
/* 3900 */         popPageAttributes();
/*      */       }
/*      */     }
/*      */     
/*      */     protected PRIndirectReference getSinglePage(int n) {
/* 3905 */       PdfDictionary acc = new PdfDictionary();
/* 3906 */       PdfDictionary top = this.reader.rootPages;
/* 3907 */       int base = 0;
/*      */       Iterator<PdfObject> it;
/* 3909 */       for (;;) { for (int k = 0; k < PdfReader.pageInhCandidates.length; k++) {
/* 3910 */           PdfObject obj = top.get(PdfReader.pageInhCandidates[k]);
/* 3911 */           if (obj != null)
/* 3912 */             acc.put(PdfReader.pageInhCandidates[k], obj);
/*      */         }
/* 3914 */         PdfArray kids = (PdfArray)PdfReader.getPdfObjectRelease(top.get(PdfName.KIDS));
/* 3915 */         for (it = kids.listIterator(); it.hasNext();) {
/* 3916 */           PRIndirectReference ref = (PRIndirectReference)it.next();
/* 3917 */           PdfDictionary dic = (PdfDictionary)PdfReader.getPdfObject(ref);
/* 3918 */           int last = this.reader.lastXrefPartial;
/* 3919 */           PdfObject count = PdfReader.getPdfObjectRelease(dic.get(PdfName.COUNT));
/* 3920 */           this.reader.lastXrefPartial = last;
/* 3921 */           int acn = 1;
/* 3922 */           if ((count != null) && (count.type() == 2))
/* 3923 */             acn = ((PdfNumber)count).intValue();
/* 3924 */           if (n < base + acn) {
/* 3925 */             if (count == null) {
/* 3926 */               dic.mergeDifferent(acc);
/* 3927 */               return ref;
/*      */             }
/* 3929 */             this.reader.releaseLastXrefPartial();
/* 3930 */             top = dic;
/* 3931 */             break;
/*      */           }
/* 3933 */           this.reader.releaseLastXrefPartial();
/* 3934 */           base += acn;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     private void selectPages(List<Integer> pagesToKeep) {
/* 3940 */       IntHashtable pg = new IntHashtable();
/* 3941 */       ArrayList<Integer> finalPages = new ArrayList();
/* 3942 */       int psize = size();
/* 3943 */       for (Integer pi : pagesToKeep) {
/* 3944 */         int p = pi.intValue();
/* 3945 */         if ((p >= 1) && (p <= psize) && (pg.put(p, 1) == 0))
/* 3946 */           finalPages.add(pi);
/*      */       }
/* 3948 */       if (this.reader.partial) {
/* 3949 */         for (int k = 1; k <= psize; k++) {
/* 3950 */           getPageOrigRef(k);
/* 3951 */           resetReleasePage();
/*      */         }
/*      */       }
/* 3954 */       PRIndirectReference parent = (PRIndirectReference)this.reader.catalog.get(PdfName.PAGES);
/* 3955 */       PdfDictionary topPages = (PdfDictionary)PdfReader.getPdfObject(parent);
/* 3956 */       ArrayList<PRIndirectReference> newPageRefs = new ArrayList(finalPages.size());
/* 3957 */       PdfArray kids = new PdfArray();
/* 3958 */       for (int k = 0; k < finalPages.size(); k++) {
/* 3959 */         int p = ((Integer)finalPages.get(k)).intValue();
/* 3960 */         PRIndirectReference pref = getPageOrigRef(p);
/* 3961 */         resetReleasePage();
/* 3962 */         kids.add(pref);
/* 3963 */         newPageRefs.add(pref);
/* 3964 */         getPageN(p).put(PdfName.PARENT, parent);
/*      */       }
/* 3966 */       AcroFields af = this.reader.getAcroFields();
/* 3967 */       boolean removeFields = af.getFields().size() > 0;
/* 3968 */       for (int k = 1; k <= psize; k++) {
/* 3969 */         if (!pg.containsKey(k)) {
/* 3970 */           if (removeFields)
/* 3971 */             af.removeFieldsFromPage(k);
/* 3972 */           PRIndirectReference pref = getPageOrigRef(k);
/* 3973 */           int nref = pref.getNumber();
/* 3974 */           this.reader.xrefObj.set(nref, null);
/* 3975 */           if (this.reader.partial) {
/* 3976 */             this.reader.xref[(nref * 2)] = -1L;
/* 3977 */             this.reader.xref[(nref * 2 + 1)] = 0L;
/*      */           }
/*      */         }
/*      */       }
/* 3981 */       topPages.put(PdfName.COUNT, new PdfNumber(finalPages.size()));
/* 3982 */       topPages.put(PdfName.KIDS, kids);
/* 3983 */       this.refsp = null;
/* 3984 */       this.refsn = newPageRefs;
/*      */     }
/*      */   }
/*      */   
/*      */   PdfIndirectReference getCryptoRef() {
/* 3989 */     if (this.cryptoRef == null)
/* 3990 */       return null;
/* 3991 */     return new PdfIndirectReference(0, this.cryptoRef.getNumber(), this.cryptoRef.getGeneration());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasUsageRights()
/*      */   {
/* 4000 */     PdfDictionary perms = this.catalog.getAsDict(PdfName.PERMS);
/* 4001 */     if (perms == null)
/* 4002 */       return false;
/* 4003 */     return (perms.contains(PdfName.UR)) || (perms.contains(PdfName.UR3));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeUsageRights()
/*      */   {
/* 4012 */     PdfDictionary perms = this.catalog.getAsDict(PdfName.PERMS);
/* 4013 */     if (perms == null)
/* 4014 */       return;
/* 4015 */     perms.remove(PdfName.UR);
/* 4016 */     perms.remove(PdfName.UR3);
/* 4017 */     if (perms.size() == 0) {
/* 4018 */       this.catalog.remove(PdfName.PERMS);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCertificationLevel()
/*      */   {
/* 4032 */     PdfDictionary dic = this.catalog.getAsDict(PdfName.PERMS);
/* 4033 */     if (dic == null)
/* 4034 */       return 0;
/* 4035 */     dic = dic.getAsDict(PdfName.DOCMDP);
/* 4036 */     if (dic == null)
/* 4037 */       return 0;
/* 4038 */     PdfArray arr = dic.getAsArray(PdfName.REFERENCE);
/* 4039 */     if ((arr == null) || (arr.size() == 0))
/* 4040 */       return 0;
/* 4041 */     dic = arr.getAsDict(0);
/* 4042 */     if (dic == null)
/* 4043 */       return 0;
/* 4044 */     dic = dic.getAsDict(PdfName.TRANSFORMPARAMS);
/* 4045 */     if (dic == null)
/* 4046 */       return 0;
/* 4047 */     PdfNumber p = dic.getAsNumber(PdfName.P);
/* 4048 */     if (p == null)
/* 4049 */       return 0;
/* 4050 */     return p.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isOpenedWithFullPermissions()
/*      */   {
/* 4061 */     return (!this.encrypted) || (this.ownerPasswordUsed) || (unethicalreading);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getCryptoMode()
/*      */   {
/* 4068 */     if (this.decrypt == null) {
/* 4069 */       return -1;
/*      */     }
/* 4071 */     return this.decrypt.getCryptoMode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isMetadataEncrypted()
/*      */   {
/* 4078 */     if (this.decrypt == null) {
/* 4079 */       return false;
/*      */     }
/* 4081 */     return this.decrypt.isMetadataEncrypted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public byte[] computeUserPassword()
/*      */   {
/* 4088 */     if ((!this.encrypted) || (!this.ownerPasswordUsed)) return null;
/* 4089 */     return this.decrypt.computeUserPassword(this.password);
/*      */   }
/*      */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */