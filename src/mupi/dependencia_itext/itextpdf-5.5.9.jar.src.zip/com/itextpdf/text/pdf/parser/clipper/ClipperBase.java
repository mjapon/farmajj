/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClipperBase
/*     */   implements Clipper
/*     */ {
/*     */   private static final long LOW_RANGE = 1073741823L;
/*     */   private static final long HI_RANGE = 4611686018427387903L;
/*     */   protected LocalMinima minimaList;
/*     */   protected LocalMinima currentLM;
/*     */   private final List<List<Edge>> edges;
/*     */   protected boolean useFullRange;
/*     */   protected boolean hasOpenPaths;
/*     */   protected final boolean preserveCollinear;
/*     */   
/*     */   private static void initEdge(Edge e, Edge eNext, Edge ePrev, Point.LongPoint pt)
/*     */   {
/*  98 */     e.next = eNext;
/*  99 */     e.prev = ePrev;
/* 100 */     e.setCurrent(new Point.LongPoint(pt));
/* 101 */     e.outIdx = -1;
/*     */   }
/*     */   
/*     */   private static void initEdge2(Edge e, Clipper.PolyType polyType) {
/* 105 */     if (e.getCurrent().getY() >= e.next.getCurrent().getY()) {
/* 106 */       e.setBot(new Point.LongPoint(e.getCurrent()));
/* 107 */       e.setTop(new Point.LongPoint(e.next.getCurrent()));
/*     */     }
/*     */     else {
/* 110 */       e.setTop(new Point.LongPoint(e.getCurrent()));
/* 111 */       e.setBot(new Point.LongPoint(e.next.getCurrent()));
/*     */     }
/* 113 */     e.updateDeltaX();
/* 114 */     e.polyTyp = polyType;
/*     */   }
/*     */   
/*     */   private static boolean rangeTest(Point.LongPoint Pt, boolean useFullRange) {
/* 118 */     if (useFullRange) {
/* 119 */       if ((Pt.getX() > 4611686018427387903L) || (Pt.getY() > 4611686018427387903L) || (-Pt.getX() > 4611686018427387903L) || (-Pt.getY() > 4611686018427387903L))
/* 120 */         throw new IllegalStateException("Coordinate outside allowed range");
/* 121 */     } else if ((Pt.getX() > 1073741823L) || (Pt.getY() > 1073741823L) || (-Pt.getX() > 1073741823L) || (-Pt.getY() > 1073741823L)) {
/* 122 */       return rangeTest(Pt, true);
/*     */     }
/*     */     
/* 125 */     return useFullRange;
/*     */   }
/*     */   
/*     */   private static Edge removeEdge(Edge e)
/*     */   {
/* 130 */     e.prev.next = e.next;
/* 131 */     e.next.prev = e.prev;
/* 132 */     Edge result = e.next;
/* 133 */     e.prev = null;
/* 134 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */   private static final Logger LOGGER = Logger.getLogger(Clipper.class.getName());
/*     */   
/*     */   protected ClipperBase(boolean preserveCollinear)
/*     */   {
/* 157 */     this.preserveCollinear = preserveCollinear;
/* 158 */     this.minimaList = null;
/* 159 */     this.currentLM = null;
/* 160 */     this.hasOpenPaths = false;
/* 161 */     this.edges = new ArrayList();
/*     */   }
/*     */   
/*     */   public boolean addPath(Path pg, Clipper.PolyType polyType, boolean Closed)
/*     */   {
/* 166 */     if ((!Closed) && (polyType == Clipper.PolyType.CLIP)) {
/* 167 */       throw new IllegalStateException("AddPath: Open paths must be subject.");
/*     */     }
/*     */     
/* 170 */     int highI = pg.size() - 1;
/* 171 */     if (Closed) {
/* 172 */       while ((highI > 0) && (((Point.LongPoint)pg.get(highI)).equals(pg.get(0)))) {
/* 173 */         highI--;
/*     */       }
/*     */     }
/* 176 */     while ((highI > 0) && (((Point.LongPoint)pg.get(highI)).equals(pg.get(highI - 1)))) {
/* 177 */       highI--;
/*     */     }
/* 179 */     if (((Closed) && (highI < 2)) || ((!Closed) && (highI < 1))) {
/* 180 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 184 */     List<Edge> edges = new ArrayList(highI + 1);
/* 185 */     for (int i = 0; i <= highI; i++) {
/* 186 */       edges.add(new Edge());
/*     */     }
/*     */     
/* 189 */     boolean IsFlat = true;
/*     */     
/*     */ 
/* 192 */     ((Edge)edges.get(1)).setCurrent(new Point.LongPoint((Point.LongPoint)pg.get(1)));
/* 193 */     this.useFullRange = rangeTest((Point.LongPoint)pg.get(0), this.useFullRange);
/* 194 */     this.useFullRange = rangeTest((Point.LongPoint)pg.get(highI), this.useFullRange);
/* 195 */     initEdge((Edge)edges.get(0), (Edge)edges.get(1), (Edge)edges.get(highI), (Point.LongPoint)pg.get(0));
/* 196 */     initEdge((Edge)edges.get(highI), (Edge)edges.get(0), (Edge)edges.get(highI - 1), (Point.LongPoint)pg.get(highI));
/* 197 */     for (int i = highI - 1; i >= 1; i--) {
/* 198 */       this.useFullRange = rangeTest((Point.LongPoint)pg.get(i), this.useFullRange);
/* 199 */       initEdge((Edge)edges.get(i), (Edge)edges.get(i + 1), (Edge)edges.get(i - 1), (Point.LongPoint)pg.get(i));
/*     */     }
/* 201 */     Edge eStart = (Edge)edges.get(0);
/*     */     
/*     */ 
/* 204 */     Edge e = eStart;Edge eLoopStop = eStart;
/*     */     for (;;)
/*     */     {
/* 207 */       if ((e.getCurrent().equals(e.next.getCurrent())) && ((Closed) || (!e.next.equals(eStart)))) {
/* 208 */         if (e != e.next)
/*     */         {
/*     */ 
/* 211 */           if (e == eStart) {
/* 212 */             eStart = e.next;
/*     */           }
/* 214 */           e = removeEdge(e);
/* 215 */           eLoopStop = e;
/*     */         }
/*     */       }
/* 218 */       else if (e.prev != e.next)
/*     */       {
/*     */ 
/* 221 */         if ((Closed) && (Point.slopesEqual(e.prev.getCurrent(), e.getCurrent(), e.next.getCurrent(), this.useFullRange)) && (
/* 222 */           (!isPreserveCollinear()) || (!Point.isPt2BetweenPt1AndPt3(e.prev.getCurrent(), e.getCurrent(), e.next.getCurrent()))))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 227 */           if (e == eStart) {
/* 228 */             eStart = e.next;
/*     */           }
/* 230 */           e = removeEdge(e);
/* 231 */           e = e.prev;
/* 232 */           eLoopStop = e;
/*     */         }
/*     */         else {
/* 235 */           e = e.next;
/* 236 */           if (e != eLoopStop) if ((!Closed) && (e.next == eStart))
/*     */               break;
/*     */         }
/*     */       }
/*     */     }
/* 241 */     if (((!Closed) && (e == e.next)) || ((Closed) && (e.prev == e.next))) {
/* 242 */       return false;
/*     */     }
/*     */     
/* 245 */     if (!Closed) {
/* 246 */       this.hasOpenPaths = true;
/* 247 */       eStart.prev.outIdx = -2;
/*     */     }
/*     */     
/*     */ 
/* 251 */     e = eStart;
/*     */     do {
/* 253 */       initEdge2(e, polyType);
/* 254 */       e = e.next;
/* 255 */       if ((IsFlat) && (e.getCurrent().getY() != eStart.getCurrent().getY())) {
/* 256 */         IsFlat = false;
/*     */       }
/*     */       
/* 259 */     } while (e != eStart);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 265 */     if (IsFlat) {
/* 266 */       if (Closed) {
/* 267 */         return false;
/*     */       }
/* 269 */       e.prev.outIdx = -2;
/* 270 */       LocalMinima locMin = new LocalMinima();
/* 271 */       locMin.next = null;
/* 272 */       locMin.y = e.getBot().getY();
/* 273 */       locMin.leftBound = null;
/* 274 */       locMin.rightBound = e;
/* 275 */       locMin.rightBound.side = Edge.Side.RIGHT;
/* 276 */       locMin.rightBound.windDelta = 0;
/*     */       for (;;)
/*     */       {
/* 279 */         if (e.getBot().getX() != e.prev.getTop().getX()) e.reverseHorizontal();
/* 280 */         if (e.next.outIdx == -2) break;
/* 281 */         e.nextInLML = e.next;
/* 282 */         e = e.next;
/*     */       }
/* 284 */       insertLocalMinima(locMin);
/* 285 */       this.edges.add(edges);
/* 286 */       return true;
/*     */     }
/*     */     
/* 289 */     this.edges.add(edges);
/*     */     
/* 291 */     Edge EMin = null;
/*     */     
/*     */ 
/*     */ 
/* 295 */     if (e.prev.getBot().equals(e.prev.getTop())) {
/* 296 */       e = e.next;
/*     */     }
/*     */     for (;;)
/*     */     {
/* 300 */       e = e.findNextLocMin();
/* 301 */       if (e == EMin) {
/*     */         break;
/*     */       }
/* 304 */       if (EMin == null) {
/* 305 */         EMin = e;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 310 */       LocalMinima locMin = new LocalMinima();
/* 311 */       locMin.next = null;
/* 312 */       locMin.y = e.getBot().getY();
/* 313 */       boolean leftBoundIsForward; boolean leftBoundIsForward; if (e.deltaX < e.prev.deltaX) {
/* 314 */         locMin.leftBound = e.prev;
/* 315 */         locMin.rightBound = e;
/* 316 */         leftBoundIsForward = false;
/*     */       }
/*     */       else {
/* 319 */         locMin.leftBound = e;
/* 320 */         locMin.rightBound = e.prev;
/* 321 */         leftBoundIsForward = true;
/*     */       }
/* 323 */       locMin.leftBound.side = Edge.Side.LEFT;
/* 324 */       locMin.rightBound.side = Edge.Side.RIGHT;
/*     */       
/* 326 */       if (!Closed) {
/* 327 */         locMin.leftBound.windDelta = 0;
/*     */       }
/* 329 */       else if (locMin.leftBound.next == locMin.rightBound) {
/* 330 */         locMin.leftBound.windDelta = -1;
/*     */       }
/*     */       else {
/* 333 */         locMin.leftBound.windDelta = 1;
/*     */       }
/* 335 */       locMin.rightBound.windDelta = (-locMin.leftBound.windDelta);
/*     */       
/* 337 */       e = processBound(locMin.leftBound, leftBoundIsForward);
/* 338 */       if (e.outIdx == -2) {
/* 339 */         e = processBound(e, leftBoundIsForward);
/*     */       }
/*     */       
/* 342 */       Edge E2 = processBound(locMin.rightBound, !leftBoundIsForward);
/* 343 */       if (E2.outIdx == -2) {
/* 344 */         E2 = processBound(E2, !leftBoundIsForward);
/*     */       }
/*     */       
/* 347 */       if (locMin.leftBound.outIdx == -2) {
/* 348 */         locMin.leftBound = null;
/*     */       }
/* 350 */       else if (locMin.rightBound.outIdx == -2) {
/* 351 */         locMin.rightBound = null;
/*     */       }
/* 353 */       insertLocalMinima(locMin);
/* 354 */       if (!leftBoundIsForward) {
/* 355 */         e = E2;
/*     */       }
/*     */     }
/* 358 */     return true;
/*     */   }
/*     */   
/*     */   public boolean addPaths(Paths ppg, Clipper.PolyType polyType, boolean closed)
/*     */   {
/* 363 */     boolean result = false;
/* 364 */     for (int i = 0; i < ppg.size(); i++) {
/* 365 */       if (addPath((Path)ppg.get(i), polyType, closed)) {
/* 366 */         result = true;
/*     */       }
/*     */     }
/* 369 */     return result;
/*     */   }
/*     */   
/*     */   public void clear() {
/* 373 */     disposeLocalMinimaList();
/* 374 */     this.edges.clear();
/* 375 */     this.useFullRange = false;
/* 376 */     this.hasOpenPaths = false;
/*     */   }
/*     */   
/*     */   private void disposeLocalMinimaList() {
/* 380 */     while (this.minimaList != null) {
/* 381 */       LocalMinima tmpLm = this.minimaList.next;
/* 382 */       this.minimaList = null;
/* 383 */       this.minimaList = tmpLm;
/*     */     }
/* 385 */     this.currentLM = null;
/*     */   }
/*     */   
/*     */   private void insertLocalMinima(LocalMinima newLm) {
/* 389 */     if (this.minimaList == null) {
/* 390 */       this.minimaList = newLm;
/*     */     }
/* 392 */     else if (newLm.y >= this.minimaList.y) {
/* 393 */       newLm.next = this.minimaList;
/* 394 */       this.minimaList = newLm;
/*     */     }
/*     */     else {
/* 397 */       LocalMinima tmpLm = this.minimaList;
/* 398 */       while ((tmpLm.next != null) && (newLm.y < tmpLm.next.y)) {
/* 399 */         tmpLm = tmpLm.next;
/*     */       }
/* 401 */       newLm.next = tmpLm.next;
/* 402 */       tmpLm.next = newLm;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isPreserveCollinear() {
/* 407 */     return this.preserveCollinear;
/*     */   }
/*     */   
/*     */   protected void popLocalMinima() {
/* 411 */     LOGGER.entering(ClipperBase.class.getName(), "popLocalMinima");
/* 412 */     if (this.currentLM == null) {
/* 413 */       return;
/*     */     }
/* 415 */     this.currentLM = this.currentLM.next;
/*     */   }
/*     */   
/*     */   private Edge processBound(Edge e, boolean LeftBoundIsForward) {
/* 419 */     Edge result = e;
/*     */     
/*     */ 
/* 422 */     if (result.outIdx == -2)
/*     */     {
/*     */ 
/* 425 */       e = result;
/* 426 */       if (LeftBoundIsForward) {
/* 427 */         while (e.getTop().getY() == e.next.getBot().getY()) {
/* 428 */           e = e.next;
/*     */         }
/* 430 */         while ((e != result) && (e.deltaX == -3.4E38D)) {
/* 431 */           e = e.prev;
/*     */         }
/*     */       }
/*     */       
/* 435 */       while (e.getTop().getY() == e.prev.getBot().getY()) {
/* 436 */         e = e.prev;
/*     */       }
/* 438 */       while ((e != result) && (e.deltaX == -3.4E38D)) {
/* 439 */         e = e.next;
/*     */       }
/*     */       
/* 442 */       if (e == result) {
/* 443 */         if (LeftBoundIsForward) {
/* 444 */           result = e.next;
/*     */         }
/*     */         else {
/* 447 */           result = e.prev;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 452 */         if (LeftBoundIsForward) {
/* 453 */           e = result.next;
/*     */         }
/*     */         else {
/* 456 */           e = result.prev;
/*     */         }
/* 458 */         LocalMinima locMin = new LocalMinima();
/* 459 */         locMin.next = null;
/* 460 */         locMin.y = e.getBot().getY();
/* 461 */         locMin.leftBound = null;
/* 462 */         locMin.rightBound = e;
/* 463 */         e.windDelta = 0;
/* 464 */         result = processBound(e, LeftBoundIsForward);
/* 465 */         insertLocalMinima(locMin);
/*     */       }
/* 467 */       return result;
/*     */     }
/*     */     
/* 470 */     if (e.deltaX == -3.4E38D)
/*     */     {
/*     */       Edge EStart;
/*     */       Edge EStart;
/* 474 */       if (LeftBoundIsForward) {
/* 475 */         EStart = e.prev;
/*     */       }
/*     */       else {
/* 478 */         EStart = e.next;
/*     */       }
/* 480 */       if (EStart.deltaX == -3.4E38D)
/*     */       {
/* 482 */         if ((EStart.getBot().getX() != e.getBot().getX()) && (EStart.getTop().getX() != e.getBot().getX())) {
/* 483 */           e.reverseHorizontal();
/*     */         }
/* 485 */       } else if (EStart.getBot().getX() != e.getBot().getX()) {
/* 486 */         e.reverseHorizontal();
/*     */       }
/*     */     }
/* 489 */     Edge EStart = e;
/* 490 */     if (LeftBoundIsForward) {
/* 491 */       while ((result.getTop().getY() == result.next.getBot().getY()) && (result.next.outIdx != -2)) {
/* 492 */         result = result.next;
/*     */       }
/* 494 */       if ((result.deltaX == -3.4E38D) && (result.next.outIdx != -2))
/*     */       {
/*     */ 
/*     */ 
/* 498 */         Edge Horz = result;
/* 499 */         while (Horz.prev.deltaX == -3.4E38D) {
/* 500 */           Horz = Horz.prev;
/*     */         }
/* 502 */         if (Horz.prev.getTop().getX() > result.next.getTop().getX()) result = Horz.prev;
/*     */       }
/* 504 */       while (e != result) {
/* 505 */         e.nextInLML = e.next;
/* 506 */         if ((e.deltaX == -3.4E38D) && (e != EStart) && (e.getBot().getX() != e.prev.getTop().getX())) {
/* 507 */           e.reverseHorizontal();
/*     */         }
/* 509 */         e = e.next;
/*     */       }
/* 511 */       if ((e.deltaX == -3.4E38D) && (e != EStart) && (e.getBot().getX() != e.prev.getTop().getX())) {
/* 512 */         e.reverseHorizontal();
/*     */       }
/* 514 */       result = result.next;
/*     */     }
/*     */     else {
/* 517 */       while ((result.getTop().getY() == result.prev.getBot().getY()) && (result.prev.outIdx != -2)) {
/* 518 */         result = result.prev;
/*     */       }
/* 520 */       if ((result.deltaX == -3.4E38D) && (result.prev.outIdx != -2)) {
/* 521 */         Edge Horz = result;
/* 522 */         while (Horz.next.deltaX == -3.4E38D) {
/* 523 */           Horz = Horz.next;
/*     */         }
/* 525 */         if ((Horz.next.getTop().getX() == result.prev.getTop().getX()) || 
/* 526 */           (Horz.next.getTop().getX() > result.prev.getTop().getX())) { result = Horz.next;
/*     */         }
/*     */       }
/* 529 */       while (e != result) {
/* 530 */         e.nextInLML = e.prev;
/* 531 */         if ((e.deltaX == -3.4E38D) && (e != EStart) && (e.getBot().getX() != e.next.getTop().getX())) {
/* 532 */           e.reverseHorizontal();
/*     */         }
/* 534 */         e = e.prev;
/*     */       }
/* 536 */       if ((e.deltaX == -3.4E38D) && (e != EStart) && (e.getBot().getX() != e.next.getTop().getX())) {
/* 537 */         e.reverseHorizontal();
/*     */       }
/* 539 */       result = result.prev;
/*     */     }
/* 541 */     return result;
/*     */   }
/*     */   
/*     */   protected static Path.OutRec parseFirstLeft(Path.OutRec FirstLeft) {
/* 545 */     while ((FirstLeft != null) && (FirstLeft.getPoints() == null))
/* 546 */       FirstLeft = FirstLeft.firstLeft;
/* 547 */     return FirstLeft;
/*     */   }
/*     */   
/*     */   protected void reset() {
/* 551 */     this.currentLM = this.minimaList;
/* 552 */     if (this.currentLM == null) {
/* 553 */       return;
/*     */     }
/*     */     
/*     */ 
/* 557 */     LocalMinima lm = this.minimaList;
/* 558 */     while (lm != null) {
/* 559 */       Edge e = lm.leftBound;
/* 560 */       if (e != null) {
/* 561 */         e.setCurrent(new Point.LongPoint(e.getBot()));
/* 562 */         e.side = Edge.Side.LEFT;
/* 563 */         e.outIdx = -1;
/*     */       }
/* 565 */       e = lm.rightBound;
/* 566 */       if (e != null) {
/* 567 */         e.setCurrent(new Point.LongPoint(e.getBot()));
/* 568 */         e.side = Edge.Side.RIGHT;
/* 569 */         e.outIdx = -1;
/*     */       }
/* 571 */       lm = lm.next;
/*     */     }
/*     */   }
/*     */   
/*     */   protected class Scanbeam
/*     */   {
/*     */     long y;
/*     */     Scanbeam next;
/*     */     
/*     */     protected Scanbeam() {}
/*     */   }
/*     */   
/*     */   protected class LocalMinima
/*     */   {
/*     */     long y;
/*     */     Edge leftBound;
/*     */     Edge rightBound;
/*     */     LocalMinima next;
/*     */     
/*     */     protected LocalMinima() {}
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/ClipperBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */