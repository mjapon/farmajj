/*     */ package com.itextpdf.text.pdf.parser.clipper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PolyNode
/*     */ {
/*     */   private PolyNode parent;
/*     */   
/*     */   static enum NodeType
/*     */   {
/*  57 */     ANY,  OPEN,  CLOSED;
/*     */     
/*     */     private NodeType() {} }
/*     */   
/*  61 */   private final Path polygon = new Path();
/*     */   private int index;
/*     */   private Clipper.JoinType joinType;
/*     */   private Clipper.EndType endType;
/*  65 */   protected final List<PolyNode> childs = new ArrayList();
/*     */   private boolean isOpen;
/*     */   
/*     */   public void addChild(PolyNode child) {
/*  69 */     int cnt = this.childs.size();
/*  70 */     this.childs.add(child);
/*  71 */     child.parent = this;
/*  72 */     child.index = cnt;
/*     */   }
/*     */   
/*     */   public int getChildCount() {
/*  76 */     return this.childs.size();
/*     */   }
/*     */   
/*     */   public List<PolyNode> getChilds() {
/*  80 */     return Collections.unmodifiableList(this.childs);
/*     */   }
/*     */   
/*     */   public List<Point.LongPoint> getContour() {
/*  84 */     return this.polygon;
/*     */   }
/*     */   
/*     */   public Clipper.EndType getEndType() {
/*  88 */     return this.endType;
/*     */   }
/*     */   
/*     */   public Clipper.JoinType getJoinType() {
/*  92 */     return this.joinType;
/*     */   }
/*     */   
/*     */   public PolyNode getNext() {
/*  96 */     if (!this.childs.isEmpty()) {
/*  97 */       return (PolyNode)this.childs.get(0);
/*     */     }
/*     */     
/* 100 */     return getNextSiblingUp();
/*     */   }
/*     */   
/*     */   private PolyNode getNextSiblingUp()
/*     */   {
/* 105 */     if (this.parent == null) {
/* 106 */       return null;
/*     */     }
/* 108 */     if (this.index == this.parent.childs.size() - 1) {
/* 109 */       return this.parent.getNextSiblingUp();
/*     */     }
/*     */     
/* 112 */     return (PolyNode)this.parent.childs.get(this.index + 1);
/*     */   }
/*     */   
/*     */   public PolyNode getParent()
/*     */   {
/* 117 */     return this.parent;
/*     */   }
/*     */   
/*     */   public Path getPolygon() {
/* 121 */     return this.polygon;
/*     */   }
/*     */   
/*     */   public boolean isHole() {
/* 125 */     return isHoleNode();
/*     */   }
/*     */   
/*     */   private boolean isHoleNode() {
/* 129 */     boolean result = true;
/* 130 */     PolyNode node = this.parent;
/* 131 */     while (node != null) {
/* 132 */       result = !result;
/* 133 */       node = node.parent;
/*     */     }
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 139 */     return this.isOpen;
/*     */   }
/*     */   
/*     */   public void setEndType(Clipper.EndType value) {
/* 143 */     this.endType = value;
/*     */   }
/*     */   
/*     */   public void setJoinType(Clipper.JoinType value) {
/* 147 */     this.joinType = value;
/*     */   }
/*     */   
/*     */   public void setOpen(boolean isOpen) {
/* 151 */     this.isOpen = isOpen;
/*     */   }
/*     */   
/*     */   public void setParent(PolyNode n) {
/* 155 */     this.parent = n;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/parser/clipper/PolyNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */