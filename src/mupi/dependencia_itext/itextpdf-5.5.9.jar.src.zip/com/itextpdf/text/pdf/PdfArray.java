/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PdfArray
/*     */   extends PdfObject
/*     */   implements Iterable<PdfObject>
/*     */ {
/*     */   protected ArrayList<PdfObject> arrayList;
/*     */   
/*     */   public PdfArray()
/*     */   {
/*  81 */     super(5);
/*  82 */     this.arrayList = new ArrayList();
/*     */   }
/*     */   
/*     */   public PdfArray(int capacity) {
/*  86 */     super(5);
/*  87 */     this.arrayList = new ArrayList(capacity);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray(PdfObject object)
/*     */   {
/*  97 */     super(5);
/*  98 */     this.arrayList = new ArrayList();
/*  99 */     this.arrayList.add(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray(float[] values)
/*     */   {
/* 112 */     super(5);
/* 113 */     this.arrayList = new ArrayList();
/* 114 */     add(values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray(int[] values)
/*     */   {
/* 127 */     super(5);
/* 128 */     this.arrayList = new ArrayList();
/* 129 */     add(values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray(List<PdfObject> l)
/*     */   {
/* 143 */     this();
/* 144 */     for (PdfObject element : l) {
/* 145 */       add(element);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray(PdfArray array)
/*     */   {
/* 155 */     super(5);
/* 156 */     this.arrayList = new ArrayList(array.arrayList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toPdf(PdfWriter writer, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 170 */     PdfWriter.checkPdfIsoConformance(writer, 11, this);
/* 171 */     os.write(91);
/*     */     
/* 173 */     Iterator<PdfObject> i = this.arrayList.iterator();
/*     */     
/* 175 */     int type = 0;
/* 176 */     if (i.hasNext()) {
/* 177 */       PdfObject object = (PdfObject)i.next();
/* 178 */       if (object == null)
/* 179 */         object = PdfNull.PDFNULL;
/* 180 */       object.toPdf(writer, os);
/*     */     }
/* 182 */     while (i.hasNext()) {
/* 183 */       PdfObject object = (PdfObject)i.next();
/* 184 */       if (object == null)
/* 185 */         object = PdfNull.PDFNULL;
/* 186 */       type = object.type();
/* 187 */       if ((type != 5) && (type != 6) && (type != 4) && (type != 3))
/* 188 */         os.write(32);
/* 189 */       object.toPdf(writer, os);
/*     */     }
/* 191 */     os.write(93);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 206 */     return this.arrayList.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject set(int idx, PdfObject obj)
/*     */   {
/* 222 */     return (PdfObject)this.arrayList.set(idx, obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject remove(int idx)
/*     */   {
/* 236 */     return (PdfObject)this.arrayList.remove(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ArrayList<PdfObject> getArrayList()
/*     */   {
/* 247 */     return this.arrayList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 256 */     return this.arrayList.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 266 */     return this.arrayList.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean add(PdfObject object)
/*     */   {
/* 278 */     return this.arrayList.add(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean add(float[] values)
/*     */   {
/* 293 */     for (int k = 0; k < values.length; k++)
/* 294 */       this.arrayList.add(new PdfNumber(values[k]));
/* 295 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean add(int[] values)
/*     */   {
/* 309 */     for (int k = 0; k < values.length; k++)
/* 310 */       this.arrayList.add(new PdfNumber(values[k]));
/* 311 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int index, PdfObject element)
/*     */   {
/* 327 */     this.arrayList.add(index, element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFirst(PdfObject object)
/*     */   {
/* 340 */     this.arrayList.add(0, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(PdfObject object)
/*     */   {
/* 351 */     return this.arrayList.contains(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ListIterator<PdfObject> listIterator()
/*     */   {
/* 360 */     return this.arrayList.listIterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject getPdfObject(int idx)
/*     */   {
/* 375 */     return (PdfObject)this.arrayList.get(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfObject getDirectObject(int idx)
/*     */   {
/* 389 */     return PdfReader.getPdfObject(getPdfObject(idx));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfDictionary getAsDict(int idx)
/*     */   {
/* 409 */     PdfDictionary dict = null;
/* 410 */     PdfObject orig = getDirectObject(idx);
/* 411 */     if ((orig != null) && (orig.isDictionary()))
/* 412 */       dict = (PdfDictionary)orig;
/* 413 */     return dict;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfArray getAsArray(int idx)
/*     */   {
/* 430 */     PdfArray array = null;
/* 431 */     PdfObject orig = getDirectObject(idx);
/* 432 */     if ((orig != null) && (orig.isArray()))
/* 433 */       array = (PdfArray)orig;
/* 434 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfStream getAsStream(int idx)
/*     */   {
/* 451 */     PdfStream stream = null;
/* 452 */     PdfObject orig = getDirectObject(idx);
/* 453 */     if ((orig != null) && (orig.isStream()))
/* 454 */       stream = (PdfStream)orig;
/* 455 */     return stream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfString getAsString(int idx)
/*     */   {
/* 472 */     PdfString string = null;
/* 473 */     PdfObject orig = getDirectObject(idx);
/* 474 */     if ((orig != null) && (orig.isString()))
/* 475 */       string = (PdfString)orig;
/* 476 */     return string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfNumber getAsNumber(int idx)
/*     */   {
/* 493 */     PdfNumber number = null;
/* 494 */     PdfObject orig = getDirectObject(idx);
/* 495 */     if ((orig != null) && (orig.isNumber()))
/* 496 */       number = (PdfNumber)orig;
/* 497 */     return number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfName getAsName(int idx)
/*     */   {
/* 514 */     PdfName name = null;
/* 515 */     PdfObject orig = getDirectObject(idx);
/* 516 */     if ((orig != null) && (orig.isName()))
/* 517 */       name = (PdfName)orig;
/* 518 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfBoolean getAsBoolean(int idx)
/*     */   {
/* 535 */     PdfBoolean bool = null;
/* 536 */     PdfObject orig = getDirectObject(idx);
/* 537 */     if ((orig != null) && (orig.isBoolean()))
/* 538 */       bool = (PdfBoolean)orig;
/* 539 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PdfIndirectReference getAsIndirectObject(int idx)
/*     */   {
/* 554 */     PdfIndirectReference ref = null;
/* 555 */     PdfObject orig = getPdfObject(idx);
/* 556 */     if ((orig instanceof PdfIndirectReference))
/* 557 */       ref = (PdfIndirectReference)orig;
/* 558 */     return ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Iterator<PdfObject> iterator()
/*     */   {
/* 565 */     return this.arrayList.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long[] asLongArray()
/*     */   {
/* 574 */     long[] rslt = new long[size()];
/* 575 */     for (int k = 0; k < rslt.length; k++) {
/* 576 */       rslt[k] = getAsNumber(k).longValue();
/*     */     }
/* 578 */     return rslt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double[] asDoubleArray()
/*     */   {
/* 587 */     double[] rslt = new double[size()];
/* 588 */     for (int k = 0; k < rslt.length; k++) {
/* 589 */       rslt[k] = getAsNumber(k).doubleValue();
/*     */     }
/* 591 */     return rslt;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PdfArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */