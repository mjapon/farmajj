/*     */ package com.itextpdf.text.pdf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PRIndirectReference
/*     */   extends PdfIndirectReference
/*     */ {
/*     */   protected PdfReader reader;
/*     */   
/*     */   public PRIndirectReference(PdfReader reader, int number, int generation)
/*     */   {
/*  65 */     this.type = 10;
/*  66 */     this.number = number;
/*  67 */     this.generation = generation;
/*  68 */     this.reader = reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PRIndirectReference(PdfReader reader, int number)
/*     */   {
/*  79 */     this(reader, number, 0);
/*     */   }
/*     */   
/*     */   public void toPdf(PdfWriter writer, OutputStream os)
/*     */     throws IOException
/*     */   {
/*  85 */     if (writer != null) {
/*  86 */       int n = writer.getNewObjectNumber(this.reader, this.number, this.generation);
/*  87 */       os.write(PdfEncodings.convertToBytes(n + " " + (this.reader.isAppendable() ? this.generation : 0) + " R", null));
/*     */     }
/*     */     else {
/*  90 */       super.toPdf(null, os);
/*     */     }
/*     */   }
/*     */   
/*     */   public PdfReader getReader() {
/*  95 */     return this.reader;
/*     */   }
/*     */   
/*     */   public void setNumber(int number, int generation) {
/*  99 */     this.number = number;
/* 100 */     this.generation = generation;
/*     */   }
/*     */ }


/* Location:              /Users/mjapon/Documents/jarisyplusprint/IsyplusPrint/jar/printws.jar!/mupi/dependencia_itext/itextpdf-5.5.9.jar!/com/itextpdf/text/pdf/PRIndirectReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */